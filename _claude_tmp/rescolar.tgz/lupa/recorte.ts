// LUPA de las muestras (04/10/2026, pedido de Pablo). La muestra que ve la familia está apenas
// desenfocada y con la marca "PASÁ LA LUPA POR LA IMAGEN" (lupa/muestra.ts). Al pasar la lupa, el
// navegador pide al servidor SÓLO el pedacito de la foto nítida que está mirando; el servidor lo
// recorta de una copia de 1600 px (nunca del original entero; antes 800, ver LADO_LUPA). Así la foto limpia nunca llega entera al
// navegador. 04/10: a pedido de Pablo, los pedacitos van SIN sellos (antes llevaban "MUESTRA · código";
// svgSellos queda por si se quieren volver a poner: basta con pasar el texto a recortarConSello).
// Lo usan las dos galerías: colegios (server.ts, GET /api/fotos/:id/lupa) y eventos
// (eventos/servidor.ts, GET /api/eventos/publico/:codigo/lupa/:fotoId).
import sharp from 'sharp';
import crypto from 'crypto';
import { textoEnContornos } from './textoContornos.js';
import { LADO_MUESTRA } from './muestra.js';

/**
 * 17/10 (Pablo: "es como si tardara en cargar la imagen de la lupa", se veía borrosa): la copia nítida
 * pasó de 800 px (el mismo tamaño que la muestra, que en pantalla se estiraba) a 1600 px, y cada
 * pedacito sale achicado a LADO_MAXIMO_PEDACITO. Así dentro del círculo se ve nítido de verdad.
 */
export const LADO_LUPA = 1600;
/** Lado máximo (px) del pedacito que se manda: alcanza para pantallas retina sin mandar de más. */
export const LADO_MAXIMO_PEDACITO = 900;

export interface FuenteLupa {
  /** Foto nítida reducida (JPEG, lado mayor LADO_LUPA). Vive sólo en memoria del servidor. */
  buffer: Buffer;
  ancho: number;
  alto: number;
}
export interface PedidoRecorte {
  /** Centro pedido, de 0 a 1 (fracción del ancho y del alto de la foto). */
  cx: number;
  cy: number;
  /** Lado del recorte cuadrado, como fracción del ANCHO de la foto. */
  s: number;
}
export interface RegionRecorte {
  left: number;
  top: number;
  ancho: number;
  alto: number;
}

/** Lado máximo de un recorte (fracción del ancho): con la lupa grande hace falta pedir bastante. */
export const TAM_MAXIMO_RECORTE = 0.75;
export const TAM_MINIMO_RECORTE = 0.05;
/** Lado máximo del pedacito como fracción del lado CORTO de la foto (auditoría 08/10, A1). */
export const LADO_MAXIMO_RELATIVO = 0.8;
/** Encabezado con la región real devuelta (el servidor la acomoda para que no se salga de la foto). */
export const ENCABEZADO_REGION = 'X-Lupa-Region';

// ---------------- Copias nítidas en memoria ----------------
// Se arman a partir del original la primera vez que alguien usa la lupa en esa foto y quedan en la
// memoria de esa instancia del servidor. Con 40 fotos de ~80 KB son unos 3 MB.
// 09/10 (Pablo: "hasta que carga la imagen demora un segundo"): además, la copia de 800 px se guarda
// en el bucket PRIVADO, al lado del original (`rutaCopiaLupa`), así la primera vez en otra instancia
// baja ~100 KB en vez del original de varios MB. Al estar en la misma carpeta, los borrados por
// carpeta (cerrar año, vaciar) la incluyen; los borrados foto por foto la suman a mano.
const MAX_FUENTES = 40;
const fuentes = new Map<string, Promise<FuenteLupa>>();

/** Ruta de la copia nítida de 800 px guardada al lado del original (mismo bucket privado). */
export function rutaCopiaLupa(rutaOriginal: string): string {
  return `${rutaOriginal}.lupa.jpg`;
}

export interface CopiaGuardadaLupa {
  /** Devuelve la copia de 800 px ya guardada, o null si no hay. */
  leer: () => Promise<Buffer | null>;
  /** Guarda la copia recién armada (si falla, no pasa nada: se arma de nuevo la próxima vez). */
  guardar: (copia: Buffer) => Promise<void>;
}

/** Copia nítida para la lupa (lado mayor LADO_LUPA) a partir del original. 17/10: también la usa la importación desde Drive. */
export async function armarCopiaLupa(original: Buffer): Promise<{ data: Buffer; info: sharp.OutputInfo }> {
  return sharp(original, { failOn: 'none' })
    .rotate()
    .resize({ width: LADO_LUPA, height: LADO_LUPA, fit: 'inside', withoutEnlargement: true })
    .jpeg({ quality: 88, mozjpeg: true })
    .toBuffer({ resolveWithObject: true });
}

export function obtenerFuenteLupa(clave: string, cargarOriginal: () => Promise<Buffer>, copia?: CopiaGuardadaLupa): Promise<FuenteLupa> {
  const existente = fuentes.get(clave);
  if (existente) {
    // Se renueva su lugar: las más usadas quedan; las más viejas se van primero.
    fuentes.delete(clave);
    fuentes.set(clave, existente);
    return existente;
  }
  const promesa = (async () => {
    if (copia) {
      try {
        const guardada = await copia.leer();
        if (guardada && guardada.length > 0) {
          const meta = await sharp(guardada).metadata();
          // Sólo se acepta si es una copia de la lupa actual: nunca más grande que LADO_LUPA, y las
          // viejas de 800 px (de antes del 17/10) se rehacen desde el original y se pisan.
          const lado = meta.width && meta.height ? Math.max(meta.width, meta.height) : 0;
          if (lado > LADO_MUESTRA && lado <= LADO_LUPA) {
            return { buffer: guardada, ancho: meta.width, alto: meta.height };
          }
        }
      } catch {
        /* sin copia guardada: se arma desde el original */
      }
    }
    const { data, info } = await armarCopiaLupa(await cargarOriginal());
    if (copia) {
      // Como mucho 2 s esperando que se guarde (sólo la primera vez de cada foto).
      await Promise.race([copia.guardar(data).catch(() => undefined), new Promise((ok) => setTimeout(ok, 2000))]);
    }
    return { buffer: data, ancho: info.width, alto: info.height };
  })();
  fuentes.set(clave, promesa);
  // Si falla (original que no baja), no queda guardado el error: el próximo pedido reintenta.
  promesa.catch(() => {
    if (fuentes.get(clave) === promesa) fuentes.delete(clave);
  });
  while (fuentes.size > MAX_FUENTES) {
    const masVieja = fuentes.keys().next().value;
    if (masVieja === undefined) break;
    fuentes.delete(masVieja);
  }
  return promesa;
}

/** Sólo para las pruebas. */
export function olvidarFuentesLupa(): void {
  fuentes.clear();
}

// ---------------- Pedido y región ----------------
/** Lee cx, cy y s de la query. Devuelve null si faltan o no son números válidos. */
export function leerPedidoRecorte(query: Record<string, unknown>): PedidoRecorte | null {
  const numero = (v: unknown) => {
    const crudo = Array.isArray(v) ? v[0] : v;
    if (typeof crudo !== 'string' && typeof crudo !== 'number') return NaN;
    if (typeof crudo === 'string' && !/^\d*\.?\d+$/.test(crudo.trim())) return NaN;
    return Number(crudo);
  };
  const cx = numero(query.cx);
  const cy = numero(query.cy);
  const s = numero(query.s);
  if (![cx, cy, s].every(Number.isFinite)) return null;
  if (cx < 0 || cx > 1 || cy < 0 || cy > 1 || s <= 0 || s > 1) return null;
  return { cx, cy, s: Math.min(Math.max(s, TAM_MINIMO_RECORTE), TAM_MAXIMO_RECORTE) };
}

/** Región cuadrada en píxeles de la copia nítida, acomodada para que quede dentro de la foto. */
export function calcularRegion(fuente: { ancho: number; alto: number }, pedido: PedidoRecorte): RegionRecorte {
  // Auditoría 08/10 (A1): el pedacito nunca pasa el 80 % del lado CORTO de la foto. Antes (0,75 del
  // ancho, limitado sólo por el alto) dos pedidos cubrían una foto apaisada entera; ahora hacen falta
  // al menos 4 y la lupa del navegador pide apenas un poco más que el círculo.
  const ladoMaximo = Math.max(1, Math.round(LADO_MAXIMO_RELATIVO * Math.min(fuente.ancho, fuente.alto)));
  const lado = Math.max(1, Math.min(Math.round(pedido.s * fuente.ancho), fuente.ancho, fuente.alto, ladoMaximo));
  const left = Math.min(Math.max(Math.round(pedido.cx * fuente.ancho - lado / 2), 0), fuente.ancho - lado);
  const top = Math.min(Math.max(Math.round(pedido.cy * fuente.alto - lado / 2), 0), fuente.alto - lado);
  return { left, top, ancho: lado, alto: lado };
}

/** Valor del encabezado X-Lupa-Region: "left,top,ancho,alto,anchoFoto,altoFoto" (píxeles de la copia). */
export function valorEncabezadoRegion(region: RegionRecorte, fuente: { ancho: number; alto: number }): string {
  return [region.left, region.top, region.ancho, region.alto, fuente.ancho, fuente.alto].join(',');
}

// ---------------- Sellos ----------------
const ALFABETO_CODIGO = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
/**
 * Código corto y estable (5 letras) a partir de un id: va en el sello para saber de qué familia o
 * curso salió una captura (se recalcula con el mismo id; no sirve para entrar a ningún lado).
 */
export function codigoCorto(semilla: string): string {
  const hash = crypto.createHash('sha256').update(`lupa:${semilla}`).digest();
  let codigo = '';
  for (let i = 0; i < 5; i++) codigo += ALFABETO_CODIGO[hash[i] % ALFABETO_CODIGO.length];
  return codigo;
}

/**
 * SVG con sellos chicos "MUESTRA · código" para un recorte. Los sellos van en una grilla FIJA sobre la
 * foto (no sobre el recorte): al mover la lupa quedan quietos en su lugar, como una marca impresa.
 */
export function svgSellos(region: RegionRecorte, fuente: { ancho: number; alto: number }, texto: string): string {
  const t = textoEnContornos(texto);
  const tam = Math.max(9, Math.round(Math.max(fuente.ancho, fuente.alto) * 0.016));
  const anchoTexto = t.ancho * tam;
  const pasoX = Math.max(anchoTexto * 1.5, fuente.ancho * 0.3);
  const pasoY = Math.max(tam * 6, fuente.alto * 0.22);
  const n = (v: number) => v.toFixed(1);
  const piezas: string[] = [];
  let fila = 0;
  for (let y = pasoY / 2; y < fuente.alto + tam; y += pasoY, fila++) {
    const desfase = fila % 2 === 0 ? pasoX / 4 : (pasoX * 3) / 4;
    for (let x = desfase - pasoX; x < fuente.ancho + pasoX; x += pasoX) {
      const izq = x - anchoTexto / 2;
      // Sólo los que tocan el recorte.
      if (izq > region.left + region.ancho || izq + anchoTexto < region.left) continue;
      if (y - tam > region.top + region.alto || y + tam < region.top) continue;
      piezas.push(`<use xlink:href="#s" transform="translate(${n(izq - region.left)} ${n(y - region.top + tam * 0.36)}) scale(${tam})"/>`);
    }
  }
  const trazo = 1.1 / tam;
  return `<svg width="${region.ancho}" height="${region.alto}" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
  <defs><path id="s" d="${t.d}"/></defs>
  <g fill="white" fill-opacity="0.6" stroke="black" stroke-opacity="0.4" stroke-width="${trazo.toFixed(4)}" stroke-linejoin="round">${piezas.join('')}</g>
</svg>`;
}

/** Recorta la región de la copia nítida (con sellos sólo si se pasa un texto). Devuelve un JPEG chico. */
export async function recortarConSello(fuente: FuenteLupa, region: RegionRecorte, textoSello?: string): Promise<Buffer> {
  let recorte = sharp(fuente.buffer).extract({ left: region.left, top: region.top, width: region.ancho, height: region.alto });
  if (textoSello) {
    recorte = sharp(
      await recorte.composite([{ input: Buffer.from(svgSellos(region, fuente, textoSello)), top: 0, left: 0 }]).png().toBuffer()
    );
  }
  // 17/10: el pedacito nunca sale más grande que LADO_MAXIMO_PEDACITO (la región se sigue informando en
  // píxeles de la copia, así el navegador lo ubica igual).
  if (region.ancho > LADO_MAXIMO_PEDACITO || region.alto > LADO_MAXIMO_PEDACITO) {
    recorte = recorte.resize({ width: LADO_MAXIMO_PEDACITO, height: LADO_MAXIMO_PEDACITO, fit: 'inside' });
  }
  return recorte.jpeg({ quality: 82, mozjpeg: true }).toBuffer();
}

/** Encabezados de la respuesta de un recorte (el navegador lo guarda una hora, sólo para esa familia). */
export function encabezadosRecorte(region: RegionRecorte, fuente: { ancho: number; alto: number }): Record<string, string> {
  return {
    'Content-Type': 'image/jpeg',
    'Cache-Control': 'private, max-age=3600',
    [ENCABEZADO_REGION]: valorEncabezadoRegion(region, fuente),
    'X-Robots-Tag': 'noindex',
  };
}
