// Receta de las MUESTRAS (04/10/2026, pedido de Pablo): la foto con un desenfoque "muy suave" y la
// marca "PASÁ LA LUPA POR LA IMAGEN" en diagonal. La foto nítida se ve sólo dentro de la lupa, que
// pide al servidor el pedacito que se está mirando (ver lupa/recorte.ts): la foto limpia nunca sale
// entera hacia el navegador.
// Pablo probó con ChatGPT: ninguna marca ni desenfoque que deje reconocer al chico frena a la IA;
// esto se eligió porque se ve mejor e invita a usar la lupa. La protección real es que la foto
// limpia no se publica y que comprar sea más fácil que rehacerla.
// Se elige por evento y por colegio con el interruptor «Muestras con lupa» del panel (columna
// muestras_lupa, apagada por defecto). Apagado = la muestra CLÁSICA de siempre (sin desenfoque, con
// "MUESTRA · RETRATO ESCOLAR").
// Las mismas recetas se dibujan en el navegador al subir fotos (AdminLoteFotosTab.tsx y
// public/eventos/admin.js): si se cambian acá, cambiarlas allá también.
import sharp from 'sharp';
import { textoEnContornos } from './textoContornos.js';

export type EstiloMuestra = 'lupa' | 'clasica';
export const TEXTO_MARCA = 'PASÁ LA LUPA POR LA IMAGEN';
export const TEXTO_MARCA_CLASICA = 'MUESTRA · RETRATO ESCOLAR';
/** Lado mayor de la muestra (y de la foto nítida que usa la lupa). */
export const LADO_MUESTRA = 800;
export const CALIDAD_MUESTRA = 72;
/**
 * Desenfoque de la muestra con lupa, medido sobre una muestra de 800 px (sigma gaussiano).
 * 04/10: Pablo eligió "muy suave" (0,9) y, después de verlo en la galería real, pidió un 50% más (1,35).
 */
export const SIGMA_DESENFOQUE_800 = 1.35;

const MARCAS: Record<EstiloMuestra, ReturnType<typeof textoEnContornos>> = {
  lupa: textoEnContornos(TEXTO_MARCA),
  clasica: textoEnContornos(TEXTO_MARCA_CLASICA),
};

/** Sigma del desenfoque para una copia cuyo lado mayor es `lado` px (proporcional a la de 800 px). */
export function sigmaParaLado(lado: number): number {
  return Math.max(0.3, Math.round(SIGMA_DESENFOQUE_800 * (lado / LADO_MUESTRA) * 100) / 100);
}

/** SVG con el texto de la marca repetido en diagonal (el diseño de siempre; cambia sólo el texto). */
export function svgMarca(ancho: number, alto: number, estilo: EstiloMuestra = 'lupa'): string {
  const MARCA = MARCAS[estilo];
  const tam = Math.max(12, Math.round(ancho * 0.032));
  const pasoX = MARCA.ancho * tam * 1.25;
  const pasoY = alto * 0.26;
  const n = (v: number) => v.toFixed(1);
  const piezas: string[] = [];
  let fila = 0;
  for (let y = -alto * 1.1; y < alto * 1.1; y += pasoY) {
    const desfase = fila % 2 === 0 ? 0 : pasoX / 2;
    for (let x = -ancho * 1.1 + desfase; x < ancho * 1.1; x += pasoX) {
      piezas.push(`<use xlink:href="#t" transform="translate(${n(x - (MARCA.ancho * tam) / 2)} ${n(y + tam * 0.36)}) scale(${tam})"/>`);
    }
    fila++;
  }
  const trazo = 1.2 / tam; // en unidades em (el trazo también se escala)
  return `<svg width="${ancho}" height="${alto}" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
  <defs><path id="t" d="${MARCA.d}"/></defs>
  <g transform="translate(${n(ancho / 2)} ${n(alto / 2)}) rotate(-25)" fill="white" fill-opacity="0.6" stroke="black" stroke-opacity="0.5" stroke-width="${trazo.toFixed(4)}" stroke-linejoin="round">${piezas.join('')}</g>
</svg>`;
}

/** Igual que svgMarca con el texto de la lupa (se deja por compatibilidad). */
export function svgMarcaLupa(ancho: number, alto: number): string {
  return svgMarca(ancho, alto, 'lupa');
}

/**
 * Copia reducida (lado mayor `lado`) con la marca quemada en los píxeles. Con estilo 'lupa' lleva
 * además el desenfoque suave. Respeta la orientación EXIF de la cámara.
 */
export async function generarMuestraConMarca(
  original: Buffer,
  lado: number = LADO_MUESTRA,
  calidad: number = CALIDAD_MUESTRA,
  estilo: EstiloMuestra = 'lupa'
): Promise<Buffer> {
  const base = await sharp(original, { failOn: 'none' })
    .rotate()
    .resize({ width: lado, height: lado, fit: 'inside', withoutEnlargement: true })
    .toBuffer({ resolveWithObject: true });
  const { width, height } = base.info;
  const imagen = estilo === 'lupa' ? sharp(base.data).blur(sigmaParaLado(Math.max(width, height))) : sharp(base.data);
  return imagen
    .composite([{ input: Buffer.from(svgMarca(width, height, estilo)), top: 0, left: 0 }])
    .jpeg({ quality: calidad, mozjpeg: true })
    .toBuffer();
}
