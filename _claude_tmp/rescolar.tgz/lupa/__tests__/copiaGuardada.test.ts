import { beforeEach, describe, expect, it, vi } from 'vitest';
import sharp from 'sharp';
import { obtenerFuenteLupa, olvidarFuentesLupa, rutaCopiaLupa } from '../recorte';

// 09/10/2026 (Pablo: "hasta que carga la imagen demora un segundo"): la copia nítida de 800 px se
// guarda al lado del original para no tener que bajar el original entero la primera vez.
async function foto(ancho: number, alto: number): Promise<Buffer> {
  return sharp({ create: { width: ancho, height: alto, channels: 3, background: { r: 120, g: 90, b: 60 } } })
    .jpeg()
    .toBuffer();
}

beforeEach(() => olvidarFuentesLupa());

describe('copia de la lupa guardada en Storage', () => {
  it('la ruta va al lado del original', () => {
    expect(rutaCopiaLupa('2026/curso/foto.jpg')).toBe('2026/curso/foto.jpg.lupa.jpg');
  });

  it('si hay copia guardada la usa y NO baja el original', async () => {
    const copia = await sharp({ create: { width: 1067, height: 1600, channels: 3, background: { r: 1, g: 2, b: 3 } } }).jpeg().toBuffer();
    const cargarOriginal = vi.fn(async () => foto(4000, 6000));
    const guardar = vi.fn(async () => undefined);
    const fuente = await obtenerFuenteLupa('f-guardada', cargarOriginal, { leer: async () => copia, guardar });
    expect(cargarOriginal).not.toHaveBeenCalled();
    expect(guardar).not.toHaveBeenCalled();
    expect(fuente.ancho).toBe(1067);
    expect(fuente.alto).toBe(1600);
  });

  it('si no hay copia, la arma desde el original y la guarda', async () => {
    const cargarOriginal = vi.fn(async () => foto(3200, 2132));
    const guardar = vi.fn(async (_b: Buffer) => undefined);
    const fuente = await obtenerFuenteLupa('f-nueva', cargarOriginal, { leer: async () => null, guardar });
    expect(cargarOriginal).toHaveBeenCalledTimes(1);
    expect(guardar).toHaveBeenCalledTimes(1);
    expect(fuente.ancho).toBe(1600);
    const guardada = await sharp(guardar.mock.calls[0][0]).metadata();
    expect(guardada.width).toBe(1600);
  });

  it('si leer o guardar fallan, la lupa igual funciona', async () => {
    const fuente = await obtenerFuenteLupa('f-falla', async () => foto(3200, 2132), {
      leer: async () => {
        throw new Error('storage caído');
      },
      guardar: async () => {
        throw new Error('storage caído');
      },
    });
    expect(fuente.ancho).toBe(1600);
  });

  it('una "copia" más grande que 1600 px no se usa: se arma de nuevo desde el original', async () => {
    const cargarOriginal = vi.fn(async () => foto(3200, 2132));
    const fuente = await obtenerFuenteLupa('f-grande', cargarOriginal, { leer: async () => foto(2400, 1600), guardar: async () => undefined });
    expect(cargarOriginal).toHaveBeenCalledTimes(1);
    expect(fuente.ancho).toBe(1600);
    expect(fuente.alto).toBe(1066);
  });

  it('17/10: una copia vieja de 800 px se rehace en 1600 px (antes la lupa se veía borrosa)', async () => {
    const cargarOriginal = vi.fn(async () => foto(3200, 2132));
    const guardar = vi.fn(async (_b: Buffer) => undefined);
    const fuente = await obtenerFuenteLupa('f-vieja', cargarOriginal, { leer: async () => foto(800, 533), guardar });
    expect(cargarOriginal).toHaveBeenCalledTimes(1);
    expect(guardar).toHaveBeenCalledTimes(1);
    expect(fuente.ancho).toBe(1600);
  });
});
