// 04/10: lupa de las muestras (pedido de Pablo). Recortes, sellos y receta de la muestra.
import { describe, it, expect, beforeEach } from 'vitest';
import sharp from 'sharp';
import { textoEnContornos } from '../textoContornos';
import { generarMuestraConMarca, svgMarca, svgMarcaLupa, sigmaParaLado, TEXTO_MARCA, TEXTO_MARCA_CLASICA } from '../muestra';
import {
  calcularRegion,
  codigoCorto,
  encabezadosRecorte,
  leerPedidoRecorte,
  obtenerFuenteLupa,
  olvidarFuentesLupa,
  recortarConSello,
  svgSellos,
  TAM_MAXIMO_RECORTE,
} from '../recorte';

async function fotoDePrueba(ancho: number, alto: number): Promise<Buffer> {
  // Degradé con ruido: algo con detalle para que el desenfoque y el recorte se noten.
  const crudo = Buffer.alloc(ancho * alto * 3);
  for (let y = 0; y < alto; y++) {
    for (let x = 0; x < ancho; x++) {
      const i = (y * ancho + x) * 3;
      crudo[i] = (x * 255) / ancho;
      crudo[i + 1] = (y * 255) / alto;
      crudo[i + 2] = (x * 7 + y * 13) % 256;
    }
  }
  return sharp(crudo, { raw: { width: ancho, height: alto, channels: 3 } }).jpeg({ quality: 92 }).toBuffer();
}

beforeEach(() => olvidarFuentesLupa());

describe('texto como contornos', () => {
  it('mide el texto y no deja cuadraditos con letras raras', () => {
    const t = textoEnContornos('PASÁ LA LUPA');
    expect(t.ancho).toBeGreaterThan(5);
    expect(t.d).toMatch(/^M[\d.-]/);
    // Una letra sin contorno cuenta como espacio: mismo ancho que con un espacio.
    expect(textoEnContornos('A€B').ancho).toBeCloseTo(textoEnContornos('A B').ancho, 5);
    expect(textoEnContornos('abc').d).toBe(textoEnContornos('ABC').d);
  });

  it('la segunda letra queda corrida a la derecha', () => {
    const una = textoEnContornos('I');
    const dos = textoEnContornos('II');
    const xs = (d: string) => (d.match(/[ML]([\d.]+)/g) || []).map((m) => Number(m.slice(1)));
    expect(Math.max(...xs(dos.d))).toBeGreaterThan(Math.max(...xs(una.d)) + una.ancho * 0.9);
  });
});

describe('muestra nueva', () => {
  it('lleva el texto pedido por Pablo', () => {
    expect(TEXTO_MARCA).toBe('PASÁ LA LUPA POR LA IMAGEN');
    expect(svgMarcaLupa(800, 533)).toContain('<path id="t"');
  });

  it('desenfoque proporcional al tamaño (1,35 en 800 px: un 50% más que el "muy suave")', () => {
    expect(sigmaParaLado(800)).toBe(1.35);
    expect(sigmaParaLado(400)).toBe(0.68);
    expect(sigmaParaLado(100)).toBe(0.3);
  });

  it('la clásica (interruptor apagado) lleva la marca de siempre y sin desenfoque', async () => {
    expect(TEXTO_MARCA_CLASICA).toBe('MUESTRA · RETRATO ESCOLAR');
    expect(svgMarca(800, 533, 'clasica')).not.toBe(svgMarca(800, 533, 'lupa'));
    // Una foto con un borde bien marcado: la clásica lo deja nítido; la de lupa lo suaviza.
    const crudo = Buffer.alloc(800 * 400 * 3, 0);
    for (let y = 0; y < 400; y++) for (let x = 400; x < 800; x++) crudo.fill(255, (y * 800 + x) * 3, (y * 800 + x) * 3 + 3);
    const original = await sharp(crudo, { raw: { width: 800, height: 400, channels: 3 } }).png().toBuffer();
    const salto = async (estilo: 'lupa' | 'clasica') => {
      const jpg = await generarMuestraConMarca(original, 800, 95, estilo);
      const { data } = await sharp(jpg).extract({ left: 396, top: 390, width: 8, height: 1 }).raw().toBuffer({ resolveWithObject: true });
      return Math.abs(data[3 * 4] - data[3 * 3]); // salto entre x=399 y x=400 (justo en el borde)
    };
    expect(await salto('clasica')).toBeGreaterThan(await salto('lupa'));
  });

  it('achica a 800 px y devuelve JPEG', async () => {
    const original = await fotoDePrueba(1600, 1000);
    const muestra = await generarMuestraConMarca(original);
    const meta = await sharp(muestra).metadata();
    expect(meta.format).toBe('jpeg');
    expect(Math.max(meta.width || 0, meta.height || 0)).toBe(800);
  });
});

describe('pedido de recorte', () => {
  it('acepta números entre 0 y 1 y limita el tamaño', () => {
    expect(leerPedidoRecorte({ cx: '0.5', cy: '0.25', s: '0.4' })).toEqual({ cx: 0.5, cy: 0.25, s: 0.4 });
    expect(leerPedidoRecorte({ cx: '0.5', cy: '0.5', s: '1' })?.s).toBe(TAM_MAXIMO_RECORTE);
    expect(leerPedidoRecorte({ cx: '0.5', cy: '0.5', s: '0.001' })?.s).toBe(0.05);
  });

  it('rechaza lo que no es un número válido', () => {
    expect(leerPedidoRecorte({ cx: '0.5', cy: '0.5' })).toBeNull();
    expect(leerPedidoRecorte({ cx: '-0.1', cy: '0.5', s: '0.3' })).toBeNull();
    expect(leerPedidoRecorte({ cx: '1.5', cy: '0.5', s: '0.3' })).toBeNull();
    expect(leerPedidoRecorte({ cx: '1e3', cy: '0.5', s: '0.3' })).toBeNull();
    expect(leerPedidoRecorte({ cx: 'abc', cy: '0.5', s: '0.3' })).toBeNull();
    expect(leerPedidoRecorte({ cx: '0.5', cy: '0.5', s: '0' })).toBeNull();
  });

  it('la región es cuadrada y nunca se sale de la foto', () => {
    const fuente = { ancho: 800, alto: 533 };
    expect(calcularRegion(fuente, { cx: 0.5, cy: 0.5, s: 0.5 })).toEqual({ left: 200, top: 67, ancho: 400, alto: 400 });
    const esquina = calcularRegion(fuente, { cx: 1, cy: 1, s: 0.5 });
    expect(esquina).toEqual({ left: 400, top: 133, ancho: 400, alto: 400 });
    const grande = calcularRegion(fuente, { cx: 0.5, cy: 0.5, s: 0.75 });
    // Auditoría 08/10 (A1): como mucho el 80 % del lado corto (533 → 426): ya no alcanzan 2 pedidos.
    expect(grande.ancho).toBe(426);
    expect(grande.top).toBe(54);
  });
});

describe('recorte con sellos', () => {
  it('arma la copia nítida una sola vez y la reusa', async () => {
    const original = await fotoDePrueba(2400, 1600);
    let bajadas = 0;
    const cargar = async () => {
      bajadas++;
      return original;
    };
    const [a, b] = await Promise.all([obtenerFuenteLupa('f1', cargar), obtenerFuenteLupa('f1', cargar)]);
    expect(bajadas).toBe(1);
    expect(a).toBe(b);
    expect(a.ancho).toBe(1600);
    expect(a.alto).toBe(1067);
  });

  it('si el original no baja, el próximo pedido reintenta', async () => {
    let intentos = 0;
    await expect(obtenerFuenteLupa('f2', async () => {
      intentos++;
      throw new Error('no baja');
    })).rejects.toThrow('no baja');
    const original = await fotoDePrueba(400, 300);
    const fuente = await obtenerFuenteLupa('f2', async () => {
      intentos++;
      return original;
    });
    expect(intentos).toBe(2);
    expect(fuente.ancho).toBe(400);
  });

  it('devuelve sólo el pedacito pedido, como JPEG, con la región en el encabezado', async () => {
    const fuente = await obtenerFuenteLupa('f3', () => fotoDePrueba(1600, 1066));
    const region = calcularRegion(fuente, { cx: 0.3, cy: 0.4, s: 0.4 });
    const jpg = await recortarConSello(fuente, region, 'MUESTRA · FAM-ABCDE');
    const meta = await sharp(jpg).metadata();
    expect(meta.format).toBe('jpeg');
    expect(meta.width).toBe(640);
    expect(meta.height).toBe(640);
    const enc = encabezadosRecorte(region, fuente);
    expect(enc['X-Lupa-Region']).toBe(`${region.left},${region.top},640,640,1600,1066`);
    expect(enc['Cache-Control']).toBe('private, max-age=3600');
  });

  it('17/10: un pedacito grande sale achicado a 900 px como mucho, con la región real en el encabezado', async () => {
    const fuente = await obtenerFuenteLupa('f5', () => fotoDePrueba(3000, 3000));
    const region = calcularRegion(fuente, { cx: 0.5, cy: 0.5, s: 0.75 });
    expect(region.ancho).toBeGreaterThan(900);
    const meta = await sharp(await recortarConSello(fuente, region)).metadata();
    expect(meta.width).toBe(900);
    expect(meta.height).toBe(900);
  });

  it('sin texto de sello devuelve el pedacito limpio (04/10: la lupa va sin sellos)', async () => {
    const fuente = await obtenerFuenteLupa('f4', () => fotoDePrueba(1600, 1066));
    const region = calcularRegion(fuente, { cx: 0.5, cy: 0.5, s: 0.3 });
    const limpio = await recortarConSello(fuente, region);
    const igual = await sharp(fuente.buffer)
      .extract({ left: region.left, top: region.top, width: region.ancho, height: region.alto })
      .jpeg({ quality: 82, mozjpeg: true })
      .toBuffer();
    expect(limpio.equals(igual)).toBe(true);
    expect((await recortarConSello(fuente, region, 'MUESTRA · X')).equals(limpio)).toBe(false);
  });

  it('los sellos quedan fijos sobre la foto: dos recortes vecinos coinciden en el sello compartido', () => {
    const fuente = { ancho: 800, alto: 533 };
    const a = svgSellos({ left: 0, top: 0, ancho: 400, alto: 400 }, fuente, 'MUESTRA · X');
    const b = svgSellos({ left: 100, top: 0, ancho: 400, alto: 400 }, fuente, 'MUESTRA · X');
    const pos = (svg: string) => Array.from(svg.matchAll(/translate\(([-\d.]+) ([-\d.]+)\)/g)).map((m) => [Number(m[1]), Number(m[2])]);
    const enA = pos(a).map(([x, y]) => `${x.toFixed(1)},${y.toFixed(1)}`);
    const enB = pos(b).map(([x, y]) => `${(x + 100).toFixed(1)},${y.toFixed(1)}`);
    expect(enA.length).toBeGreaterThan(0);
    expect(enB.some((p) => enA.includes(p))).toBe(true);
  });

  it('código corto estable, de 5 letras sin confusiones (sin I, O, 0, 1)', () => {
    expect(codigoCorto('familia-1')).toBe(codigoCorto('familia-1'));
    expect(codigoCorto('familia-1')).not.toBe(codigoCorto('familia-2'));
    expect(codigoCorto('x')).toMatch(/^[A-HJ-NP-Z2-9]{5}$/);
  });
});
