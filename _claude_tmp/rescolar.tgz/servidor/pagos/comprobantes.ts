// Transferencia: comprobantes (subir, ver desde el panel), plazo de 48 h y medios de pago habilitados
// (división de server.ts, etapa 6, 10/10/2026). El código es el mismo que estaba en la sección 5 de
// server.ts: sólo se movió de lugar.
import type { SupabaseClient } from '@supabase/supabase-js';
import express from 'express';
import type { Request, Response } from 'express';
import { llaveRecibida, tokenAccesoValido } from '../nucleo/accesoPedidos.js';
import { requireAdminAuth } from '../nucleo/auth.js';
import { casillaAvisosAdmin, getResendClient, getServerSupabase, naveHabilitado } from '../nucleo/clientes.js';
import { buscarSeccionPorCodigoSecreto, determinarCodigoCursoServidor } from '../nucleo/codigosCurso.js';
import { limitarFrecuencia } from '../nucleo/limites.js';
import { escapeHtml } from '../nucleo/utilidades.js';

const rutas = express.Router();

// Comprobante de transferencia (pedido de Pablo 25/9): la familia que paga por transferencia sube
// la foto/PDF del comprobante desde la web (antes lo tenía que mandar por mail a fotos@). Se guarda
// en el bucket privado "comprobantes", se marca en todas las filas del pago (un grupo de hermanos
// comparte comprobante) y llega un aviso por email con el archivo adjunto.
const COMPROBANTE_TIPOS: Record<string, string> = {
  'image/jpeg': 'jpg',
  'image/png': 'png',
  'image/webp': 'webp',
  'image/heic': 'heic',
  'image/heif': 'heif',
  'application/pdf': 'pdf',
};
// 2,5 MB: el archivo viaja en base64 dentro del JSON y Vercel corta los cuerpos de más de 4,5 MB. Las fotos
// se achican en el navegador antes de subir (ver SubirComprobante.tsx), así que esto alcanza de sobra.
const COMPROBANTE_MAX_BYTES = Math.floor(2.5 * 1024 * 1024);

async function filasDelPagoPorReferencia(supabase: SupabaseClient, ref: { pedidoId?: unknown; grupoPagoId?: unknown }) {
  const esUuid = (v: unknown) => typeof v === 'string' && /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(v);
  const columna = esUuid(ref.grupoPagoId) ? 'grupo_pago_id' : esUuid(ref.pedidoId) ? 'id' : null;
  if (!columna) return { filas: [] as any[], referencia: '' };
  const valor = String(columna === 'grupo_pago_id' ? ref.grupoPagoId : ref.pedidoId);
  let { data } = await supabase
    .from('pedidos')
    .select('id, estado, metodo_pago, total, grupo_pago_id, pedido_friendly_id, alumno_nombre, colegio_nombre, colegio_id, curso_codigo, comprobante_path, comprobante_subido_at, transferencia_desde, transferencia_vencida_at, cancelado_definitivo, archivado, en_espera, familias(nombre, email)')
    .eq(columna, valor);
  // Un pedido suelto que en realidad es parte de un grupo: se toma el grupo entero.
  const grupo = (data || [])[0]?.grupo_pago_id;
  if (columna === 'id' && grupo) {
    const r = await supabase
      .from('pedidos')
      .select('id, estado, metodo_pago, total, grupo_pago_id, pedido_friendly_id, alumno_nombre, colegio_nombre, colegio_id, curso_codigo, comprobante_path, comprobante_subido_at, transferencia_desde, transferencia_vencida_at, cancelado_definitivo, archivado, en_espera, familias(nombre, email)')
      .eq('grupo_pago_id', grupo);
    data = r.data;
  }
  return {
    filas: (data || []).filter((f: any) => f.estado !== 'cancelado'),
    referencia: grupo || valor,
    // Pedido cancelado solo por no subir el comprobante a tiempo (ver PLAZO_TRANSFERENCIA_HORAS).
    vencidoPorPlazo: (data || []).length > 0 && (data || []).every((f: any) => f.estado === 'cancelado' && f.transferencia_vencida_at),
  };
}

// Plazo para subir el comprobante de una transferencia (pedido de Pablo 29/9): la familia lo ve
// antes de confirmar el pedido (AvisoPlazoTransferencia.tsx, con casilla obligatoria) y en la
// pantalla de subida (SubirComprobante.tsx, con fecha y hora). Si vence sin comprobante, el
// pedido se cancela solo (ver /api/cron/recordar-pagos-pendientes). El reloj arranca cuando el
// pedido pasa a transferencia (columna pedidos.transferencia_desde, la completa un trigger de la
// base); los pedidos anteriores a esta regla no la tienen y nunca se cancelan solos. Tiene que
// coincidir con src/utils/plazoTransferencia.ts.
export const PLAZO_TRANSFERENCIA_HORAS = 48;
const MENSAJE_TRANSFERENCIA_VENCIDA =
  `Este pedido se canceló porque pasaron ${PLAZO_TRANSFERENCIA_HORAS} horas sin recibir el comprobante de la transferencia. Si ya habías transferido, escribinos a contacto@retratoescolar.com.ar con el comprobante y lo revisamos; si no, podés hacer el pedido de nuevo.`;

export function venceTransferenciaDe(filas: any[]): Date | null {
  const inicios = filas
    .filter((f: any) => f.metodo_pago === 'transferencia' && f.transferencia_desde)
    .map((f: any) => new Date(f.transferencia_desde).getTime())
    .filter((n: number) => Number.isFinite(n));
  if (inicios.length === 0) return null;
  return new Date(Math.min(...inicios) + PLAZO_TRANSFERENCIA_HORAS * 60 * 60 * 1000);
}

/** "miércoles 1/10 a las 15:30" en hora de Argentina (para los emails). */
export function fechaHoraArgentina(fecha: Date): string {
  const partes = new Intl.DateTimeFormat('es-AR', {
    timeZone: 'America/Argentina/Buenos_Aires',
    weekday: 'long',
    day: 'numeric',
    month: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    hourCycle: 'h23',
  }).formatToParts(fecha);
  const p = (tipo: string) => partes.find((x) => x.type === tipo)?.value || '';
  return `${p('weekday')} ${p('day')}/${p('month')} a las ${p('hour')}:${p('minute')}`;
}

rutas.get('/api/pagos/comprobante', limitarFrecuencia('comprobante-estado', 600, 10 * 60 * 1000), async (req: Request, res: Response) => {
  const supabase = getServerSupabase();
  if (!supabase) return res.status(500).json({ success: false, error: 'Supabase no configurado' });
  const { filas, vencidoPorPlazo } = await filasDelPagoPorReferencia(supabase, { pedidoId: req.query.pedidoId, grupoPagoId: req.query.grupoPagoId });
  if (filas.length === 0) {
    if (vencidoPorPlazo) return res.status(410).json({ success: false, vencido: true, error: MENSAJE_TRANSFERENCIA_VENCIDA });
    return res.status(404).json({ success: false, error: 'Pedido no encontrado' });
  }
  const subido = filas.find((f: any) => f.comprobante_subido_at);
  const vence = venceTransferenciaDe(filas);
  return res.json({
    success: true,
    subido: Boolean(subido),
    fecha: subido?.comprobante_subido_at || null,
    pagado: filas.some((f: any) => f.estado === 'pagado'),
    venceAt: vence ? vence.toISOString() : null,
  });
});

rutas.post('/api/pagos/comprobante', limitarFrecuencia('comprobante-subir', 30, 10 * 60 * 1000), async (req: Request, res: Response) => {
  try {
    const supabase = getServerSupabase();
    if (!supabase) return res.status(500).json({ success: false, error: 'Supabase no configurado' });
    const { pedidoId, grupoPagoId, archivo, nombreArchivo } = req.body || {};
    const { filas, referencia, vencidoPorPlazo } = await filasDelPagoPorReferencia(supabase, { pedidoId, grupoPagoId });
    if (filas.length === 0 && vencidoPorPlazo) return res.status(410).json({ success: false, error: MENSAJE_TRANSFERENCIA_VENCIDA });
    if (filas.length === 0) return res.status(404).json({ success: false, error: 'No encontramos el pedido. Revisá el número o escribinos.' });
    if (filas.some((f: any) => f.estado === 'pagado' || f.estado === 'entregado')) {
      return res.status(409).json({ success: false, error: 'Este pedido ya está pago: no hace falta subir comprobante.' });
    }
    if (!filas.every((f: any) => f.metodo_pago === 'transferencia')) {
      return res.status(409).json({ success: false, error: 'Este pedido no es por transferencia.' });
    }
    // Auditoría 03/10 noche (P9): subir un comprobante exige la llave del pedido (la guarda el
    // navegador de quien lo creó) o el código del curso del pedido. Antes alcanzaba con el UUID: con
    // un archivo cualquiera se frenaba la cancelación de las 48 h de un pedido ajeno.
    const conLlave = tokenAccesoValido(llaveRecibida(req), [referencia, ...filas.map((f: any) => f.id), ...filas.map((f: any) => f.grupo_pago_id)]);
    let conCodigo = false;
    if (!conLlave && req.body?.codigo) {
      const seccion = await buscarSeccionPorCodigoSecreto(supabase, String(req.body.codigo).slice(0, 40));
      if (seccion) {
        const cursoSeccion = determinarCodigoCursoServidor(seccion.grado, seccion.turno, seccion.division);
        conCodigo = filas.some((f: any) => f.colegio_id === seccion.colegioId && f.curso_codigo === cursoSeccion);
      }
    }
    if (!conLlave && !conCodigo) {
      return res.status(403).json({ success: false, error: 'Abrí el portal con el código de tu curso para subir el comprobante.' });
    }
    // Auditoría 03/10 (bajo "comprobante sobre un pedido recién vencido"): pasado el plazo de 48 h el
    // pedido ya está vencido aunque el control automático todavía no lo haya cancelado. Auditoría
    // 03/10 (2ª vuelta): salvo que alguna fila esté en espera o archivada — el control automático
    // las exceptúa y nunca las va a cancelar, así que la familia tiene que poder subir el comprobante.
    const venceAntes = venceTransferenciaDe(filas);
    const exceptuadoDelPlazo = filas.some((f: any) => f.en_espera || f.archivado);
    if (filas.some((f: any) => f.cancelado_definitivo) || (!exceptuadoDelPlazo && venceAntes && venceAntes.getTime() < Date.now())) {
      return res.status(410).json({ success: false, error: MENSAJE_TRANSFERENCIA_VENCIDA });
    }
    const coincidencia = /^data:([\w/+.-]+);base64,(.+)$/s.exec(String(archivo || ''));
    const tipo = coincidencia?.[1]?.toLowerCase() || '';
    const extension = COMPROBANTE_TIPOS[tipo];
    if (!coincidencia || !extension) {
      return res.status(400).json({ success: false, error: 'Subí una foto (JPG, PNG) o un PDF del comprobante.' });
    }
    const buffer = Buffer.from(coincidencia[2], 'base64');
    if (buffer.length === 0 || buffer.length > COMPROBANTE_MAX_BYTES) {
      return res.status(400).json({ success: false, error: 'El archivo es muy grande (máximo 2,5 MB). Probá con una captura de pantalla del comprobante.' });
    }
    // Auditoría 2026-09-26 (B3): el tipo lo declaraba el navegador y no se revisaba el contenido
    // (el archivo va adjunto al email del panel). Ahora se controla la "firma" real del archivo.
    const cabecera = buffer.subarray(0, 16);
    const firmaValida =
      (extension === 'jpg' && cabecera[0] === 0xff && cabecera[1] === 0xd8 && cabecera[2] === 0xff) ||
      (extension === 'png' && cabecera.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))) ||
      (extension === 'webp' && cabecera.subarray(0, 4).toString('latin1') === 'RIFF' && cabecera.subarray(8, 12).toString('latin1') === 'WEBP') ||
      // Auditoría 03/10 noche (P9): además de "ftyp", la marca tiene que ser de HEIC/HEIF (antes pasaba
      // también un video MP4/MOV).
      ((extension === 'heic' || extension === 'heif') &&
        cabecera.subarray(4, 8).toString('latin1') === 'ftyp' &&
        ['heic', 'heix', 'hevc', 'hevx', 'heim', 'heis', 'mif1', 'msf1', 'avif'].includes(cabecera.subarray(8, 12).toString('latin1'))) ||
      (extension === 'pdf' && cabecera.subarray(0, 5).toString('latin1') === '%PDF-');
    if (!firmaValida) {
      return res.status(400).json({ success: false, error: 'El archivo no parece ser una imagen o PDF válido. Subí una foto o captura del comprobante.' });
    }
    // Un comprobante cada 2 minutos por pago: evita llenar la casilla del panel con reenvíos.
    const ultimoSubido = filas.map((f: any) => Date.parse(f.comprobante_subido_at || '')).filter(Number.isFinite).sort((x, y) => y - x)[0];
    if (ultimoSubido && Date.now() - ultimoSubido < 2 * 60 * 1000) {
      return res.status(429).json({ success: false, error: 'Ya recibimos un comprobante hace un momento. Si te equivocaste de archivo, esperá 2 minutos y volvé a subirlo.' });
    }
    const ruta = `${referencia}/${Date.now()}.${extension}`;
    const { error: errorSubida } = await supabase.storage.from('comprobantes').upload(ruta, buffer, { contentType: tipo, upsert: false });
    if (errorSubida) throw errorSubida;
    const ahora = new Date().toISOString();
    // Auditoría 03/10: UPDATE condicional — sólo si todas las filas siguen pendientes de pago y por
    // transferencia (el cron de vencimiento o una aprobación pueden haber corrido entre la lectura de
    // arriba y este momento: si las canceló, ya no están en pendiente_pago). No se exige
    // transferencia_vencida_at nulo: un pedido reactivado por el admin puede conservarlo y el estado
    // cobrable alcanza. Si no, se borra el archivo recién subido.
    const idsFilas = filas.map((f: any) => f.id);
    const { data: marcadas, error: errorUpdate } = await supabase
      .from('pedidos')
      .update({ comprobante_path: ruta, comprobante_subido_at: ahora })
      .in('id', idsFilas)
      .eq('estado', 'pendiente_pago')
      .eq('metodo_pago', 'transferencia')
      .eq('cancelado_definitivo', false)
      .select('id');
    if (errorUpdate) throw errorUpdate;
    if ((marcadas || []).length !== idsFilas.length) {
      for (const marcada of marcadas || []) {
        const previa: any = filas.find((f: any) => f.id === marcada.id) || {};
        await supabase.from('pedidos').update({ comprobante_path: previa.comprobante_path || null, comprobante_subido_at: previa.comprobante_subido_at || null }).eq('id', marcada.id).eq('comprobante_path', ruta);
      }
      await supabase.storage.from('comprobantes').remove([ruta]).catch(() => undefined);
      return res.status(409).json({ success: false, error: 'El estado de tu pedido cambió mientras subías el comprobante (puede que ya esté aprobado o vencido). Recargá la página para ver cómo quedó.' });
    }

    const resend = getResendClient();
    if (resend) {
      const destino = casillaAvisosAdmin();
      const total = (filas as any[]).reduce((acc: number, f: any) => acc + (Number(f.total) || 0), 0);
      const numeros = filas.map((f: any) => f.pedido_friendly_id).filter(Boolean).join(', ');
      const alumnos = filas.map((f: any) => f.alumno_nombre).filter(Boolean).join(', ');
      const familia: any = (filas[0] as any).familias || {};
      const nombreSeguro = String(nombreArchivo || `comprobante.${extension}`).replace(/[^\w.\- ]/g, '_').slice(0, 80);
      const aviso = await resend.emails.send({
        from: process.env.RESEND_FROM_EMAIL || 'Retrato Escolar <fotos@retratoescolar.com.ar>',
        ...(familia.email ? { replyTo: familia.email } : {}),
        to: [destino],
        subject: `🧾 Comprobante de transferencia ${numeros} · $${total.toLocaleString('es-AR')}`,
        html: `<div style="font-family:Arial,sans-serif;max-width:640px;margin:auto;color:#0f172a"><h2>Nuevo comprobante de transferencia</h2><p><strong>Pedido:</strong> ${escapeHtml(numeros)}</p><p><strong>Alumno/s:</strong> ${escapeHtml(alumnos)}</p><p><strong>Familia:</strong> ${escapeHtml(familia.nombre || '')} ${familia.email ? `(${escapeHtml(familia.email)})` : ''}</p><p><strong>Monto a verificar:</strong> $${total.toLocaleString('es-AR')}</p><p>El comprobante va adjunto. Si la transferencia está acreditada, aprobalo desde el panel → Pedidos → <strong>Aprobar Pago</strong>.</p></div>`,
        attachments: [{ filename: nombreSeguro, content: buffer.toString('base64') }],
      });
      if (aviso.error) console.error('[Comprobantes] No se pudo enviar el aviso por email:', aviso.error);
    }
    return res.status(201).json({ success: true, fecha: ahora });
  } catch (err: any) {
    console.error('[Comprobantes] Error al subir comprobante:', err);
    return res.status(500).json({ success: false, error: 'No pudimos guardar el comprobante. Probá de nuevo en unos segundos.' });
  }
});

// Link temporal (10 min) para ver el comprobante desde el panel.
rutas.get('/api/admin/pedidos/:id/comprobante', requireAdminAuth, async (req: Request, res: Response) => {
  const supabase = getServerSupabase();
  if (!supabase) return res.status(500).json({ success: false, error: 'Supabase no configurado' });
  const { data } = await supabase.from('pedidos').select('comprobante_path').eq('id', req.params.id).maybeSingle();
  if (!data?.comprobante_path) return res.status(404).json({ success: false, error: 'Este pedido todavía no tiene comprobante.' });
  const { data: firmado, error } = await supabase.storage.from('comprobantes').createSignedUrl(data.comprobante_path, 600);
  if (error || !firmado?.signedUrl) return res.status(500).json({ success: false, error: error?.message || 'No se pudo abrir el comprobante.' });
  return res.json({ success: true, url: firmado.signedUrl });
});

// Medios de pago habilitados para las familias. Nave se ofrece solo en producción: en sandbox
// rechaza toda tarjeta real (caso real 25/9) y la familia se frustraba. Al cargar las credenciales
// de producción y NAVE_ENVIRONMENT=production vuelve a aparecer solo.
rutas.get('/api/pagos/medios', (_req: Request, res: Response) => {
  res.setHeader('Cache-Control', 'public, max-age=60');
  res.json({ success: true, nave: naveHabilitado() });
});

export { rutas as rutasComprobantes };
