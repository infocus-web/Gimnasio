// Mejora de Solo Digital a Kit Impreso (/api/pedidos/:id/mejorar-a-impreso) (división de server.ts,
// etapa 6, 10/10/2026). El código es el mismo que estaba en la sección "MEJORA A KIT IMPRESO" de
// server.ts: sólo se movió de lugar.
import express from 'express';
import type { Request, Response } from 'express';
import { hijosDeFamiliaConAcceso } from '../familias/inscripciones.js';
import { llaveRecibida, tokenAccesoPedido, tokenAccesoValido } from '../nucleo/accesoPedidos.js';
import { getServerSupabase } from '../nucleo/clientes.js';
import { buscarSeccionPorCodigoSecreto, determinarCodigoCursoServidor } from '../nucleo/codigosCurso.js';
import { limitarFrecuencia, tocaTurnoDistribuido } from '../nucleo/limites.js';
import { ESTADOS_COBRABLES, tipoChoqueUnicoPedido } from '../nucleo/pedidos.js';
import { exigirPreciosCargados, precioMejoraAImpreso } from '../nucleo/precios.js';
import { asegurarFriendlyIdUnico, hijosQueSonElAlumno, insertarPedidosConReintento } from './crearPedido.js';
import { exigirPlazoMejoraImpreso } from './plazoKitImpreso.js'; // 26/10: Kit Impreso hasta el 15/11
import { metodoPagoAdicional } from '../nucleo/fotosExtra.js';
import { ajustarMetodoPagoPendiente } from './fotosExtra.js';
import { enviarAvisoTransferenciaRegistrada } from './avisoPedidoPendiente.js';

const rutas = express.Router();

// Auditoría 2026-09-22 (pedido de Pablo, viendo la galería de Benjamin Alderete con un pedido
// previo ya hecho: "por qué me deja volver a comprar si ya tengo un pedido hecho? está bien que
// me permita hacer otro pedido, pero primero debería mostrarme el pedido que ya realicé, y un
// cartel preguntarme si deseo hacer otro pedido"). Antes, tocar "Abrir Galería de Fotos" llevaba
// directo al Paso 2 sin importar si ese alumno/a ya tenía un pedido — una familia podía terminar
// pagando dos veces por accidente sin darse cuenta de que ya tenía uno hecho.
//
// Este endpoint se llama justo antes de abrir la galería (ver `handleAbrirGaleria` en
// PortalFamiliasModal.tsx) para avisar si ya existe un pedido para ese alumno puntual en ese
// curso. No requiere login porque, para llegar a este punto, la familia ya pasó por el único
// camino real que desbloquea la galería de ese alumno (código de sección real, o identificación
// por nombre+DNI del tutor) — este chequeo no expone nada que esa familia no pueda ya ver. Aun
// así se devuelve sólo un resumen mínimo (sin teléfono/email/link de descarga) y se rate-limitea
// como el resto de los endpoints públicos de pedidos.
// ==============================================================================
// MEJORA A KIT IMPRESO (27/9/2026, pedido de Pablo): una familia que compró (o reservó) el Kit
// Solo Digital puede pasar al Kit Impreso pagando sólo la diferencia. Se registra como un pedido
// aparte (sólo la carpeta impresa, con las mismas 3 fotos) que apunta al original con
// `mejora_de_pedido_id`: así el laboratorio lo ve como un impreso más y el digital no se toca.
// ==============================================================================

export function pedidoPuedeMejorarAImpreso(p: any): boolean {
  return (
    !p?.mejora_de_pedido_id &&
    p?.tipo_kit === 'solo_digital' &&
    (p?.estado === 'pagado' || p?.estado === 'entregado') &&
    !p?.seleccion_pendiente
  );
}

rutas.post('/api/pedidos/:id/mejorar-a-impreso', limitarFrecuencia('pedidos-mejorar-impreso', 60, 10 * 60 * 1000), exigirPreciosCargados, exigirPlazoMejoraImpreso, async (req: Request, res: Response) => {
  try {
    const esUuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
    const pedidoId = String(req.params.id || '');
    if (!esUuid.test(pedidoId)) return res.status(400).json({ success: false, error: 'Pedido inválido.' });
    const supabase = getServerSupabase();
    if (!supabase) return res.status(503).json({ success: false, error: 'Servicio no disponible' });
    const seccion = await buscarSeccionPorCodigoSecreto(supabase, String(req.body?.codigo || '').slice(0, 40));
    if (!seccion) return res.status(403).json({ success: false, error: 'No pudimos validar tu acceso. Volvé a ingresar con tu código.' });
    const cursoCodigo = determinarCodigoCursoServidor(seccion.grado, seccion.turno, seccion.division);

    const { data: original, error } = await supabase.from('pedidos').select('*').eq('id', pedidoId).maybeSingle();
    if (error) throw error;
    if (!original || original.colegio_id !== seccion.colegioId || original.curso_codigo !== cursoCodigo) {
      return res.status(404).json({ success: false, error: 'No encontramos tu pedido.' });
    }
    // Auditoría 05/10 (medio): pasar a impreso el kit de otra familia ya no se puede con sólo el
    // código del curso: hace falta la llave de la familia (hijo compatible) o la del pedido original.
    const hijosConLlave = await hijosDeFamiliaConAcceso(supabase, req.body?.familia, req.body?.acceso);
    // Auditoría 08/10 (M5): sólo el hijo que ES el chico del pedido (no uno de nombre parecido).
    const esDeLaFamilia = (await hijosQueSonElAlumno(supabase, req.body?.familia, hijosConLlave, original.alumno_nombre, seccion.colegioId, cursoCodigo)).length > 0;
    if (!esDeLaFamilia && !tokenAccesoValido(llaveRecibida(req), [original.id, original.grupo_pago_id])) {
      return res.status(403).json({ success: false, codigo: 'LLAVE_REQUERIDA', error: 'Para pasar tu kit a impreso volvé a ingresar al portal con los datos de tu familia (DNI del tutor).' });
    }
    if (original.seleccion_pendiente) {
      return res.status(409).json({ success: false, error: 'Primero elegí las 3 fotos de tu kit; después podés pasarlo a impreso.' });
    }
    if (!pedidoPuedeMejorarAImpreso(original)) {
      return res.status(409).json({ success: false, error: 'Este pedido no se puede pasar a Kit Impreso.' });
    }

    // Auditoría 03/10 (alto 13): la mejora se podía crear (y pagar) dos veces: dos toques/pestañas a
    // la vez creaban dos filas, y una mejora "cancelada" por un rechazo de tarjeta (que todavía se
    // puede pagar) no se reutilizaba. Ahora se reutiliza cualquier mejora cobrable del pedido, y la
    // creación toma el turno del pedido (un solo proceso a la vez entre todas las instancias).
    const precioMejora = precioMejoraAImpreso();
    // 29/10/2026 (Pablo): se paga con los mismos medios que el kit (Mercado Pago, Nave o transferencia).
    const metodo = metodoPagoAdicional(req.body?.metodoPago);
    const buscarMejoras = async () => {
      const { data, error: errMejoras } = await supabase
        .from('pedidos')
        .select('id, estado, pedido_friendly_id, total, metodo_pago, comprobante_subido_at, transferencia_vencida_at')
        .eq('mejora_de_pedido_id', original.id)
        .eq('cancelado_definitivo', false);
      if (errMejoras) throw errMejoras;
      return (data || []) as any[];
    };
    const responderMejora = async (m: any) => {
      const problema = await ajustarMetodoPagoPendiente(supabase, m, metodo);
      if (problema) return res.status(problema.status).json({ success: false, error: problema.error });
      if (metodo === 'transferencia') await enviarAvisoTransferenciaRegistrada(supabase, 'id', m.id);
      return res.json({
        success: true,
        pedidoId: m.id,
        pedidoFriendlyId: m.pedido_friendly_id,
        total: precioMejora,
        metodoPago: metodo,
        accesoToken: tokenAccesoPedido(m.id),
      });
    };
    const reutilizableDe = (lista: any[]) => lista.find((m: any) => ESTADOS_COBRABLES.includes(String(m.estado)) && Number(m.total) === precioMejora);
    let mejoras = await buscarMejoras();
    if (mejoras.some((m: any) => m.estado === 'pagado' || m.estado === 'entregado')) {
      return res.status(409).json({ success: false, error: 'Este kit ya fue pasado a impreso.' });
    }
    // Si ya había una mejora sin pagar (volvió de la pasarela sin pagar), se reutiliza.
    const pendiente = reutilizableDe(mejoras);
    if (pendiente) return responderMejora(pendiente);
    if (!(await tocaTurnoDistribuido(`mejora-impreso:${original.id}`, 20))) {
      // Otro pedido de mejora del mismo kit se está creando en este momento: se espera un poco y se
      // devuelve ese.
      await new Promise((resolve) => setTimeout(resolve, 1500));
      mejoras = await buscarMejoras();
      if (mejoras.some((m: any) => m.estado === 'pagado' || m.estado === 'entregado')) {
        return res.status(409).json({ success: false, error: 'Este kit ya fue pasado a impreso.' });
      }
      const enCurso = reutilizableDe(mejoras);
      if (enCurso) return responderMejora(enCurso);
      return res.status(409).json({ success: false, error: 'Estamos preparando el cambio a Kit Impreso. Probá de nuevo en unos segundos.' });
    }
    // Una mejora vieja sin pagar con OTRO precio (cambió la lista de precios) se da de baja definitiva
    // antes de crear la nueva: así no quedan dos links vivos para la misma carpeta.
    const viejasSinPagar = mejoras.filter((m: any) => ESTADOS_COBRABLES.includes(String(m.estado))).map((m: any) => m.id);
    if (viejasSinPagar.length > 0) {
      await supabase.from('pedidos').update({ estado: 'cancelado', cancelado_definitivo: true, updated_at: new Date().toISOString() }).in('id', viejasSinPagar).in('estado', ESTADOS_COBRABLES);
    }

    const fila: Record<string, any> = {
      familia_id: original.familia_id,
      alumno_id: original.alumno_id,
      evento_id: original.evento_id,
      tipo_kit: 'impreso_digital',
      estado: 'pendiente_pago',
      total: precioMejoraAImpreso(),
      carpetas_impresas: 1,
      metodo_pago: metodo,
      pedido_friendly_id: await asegurarFriendlyIdUnico(supabase, '', new Set()),
      colegio_id: original.colegio_id,
      colegio_nombre: original.colegio_nombre,
      curso_codigo: original.curso_codigo,
      grado: original.grado,
      division: original.division,
      turno: original.turno,
      alumno_nombre: original.alumno_nombre,
      alumno_numero_lista: original.alumno_numero_lista,
      codigo_alumno: original.codigo_alumno,
      kit_nombre: `Kit Impreso (mejora de ${original.pedido_friendly_id || 'pedido digital'})`,
      // Auditoría 28/10 (M6): la mejora es sólo la carpeta con las 3 fotos del kit. Las «Otras Fotos» sueltas
      // del digital se pagaron como digitales: si se copiaban, el laboratorio las imprimía sin cobrarlas.
      fotos_seleccionadas: { ...(original.fotos_seleccionadas || {}), otrasIds: [] },
      copias_extras: {},
      link_descarga_hd: null,
      seleccion_pendiente: false,
      mejora_de_pedido_id: original.id,
    };
    const { data: creada, error: errInsert } = await insertarPedidosConReintento(supabase, [fila], 'id, pedido_friendly_id');
    if (errInsert) {
      // 08/10: la base no admite dos mejoras vivas del mismo pedido (índice pedidos_mejora_viva_unica).
      // Si otro pedido la creó justo en el medio, se devuelve ésa en vez de un error.
      if (tipoChoqueUnicoPedido(errInsert) === 'mejora') {
        const actuales = await buscarMejoras();
        if (actuales.some((m: any) => m.estado === 'pagado' || m.estado === 'entregado')) {
          return res.status(409).json({ success: false, error: 'Este kit ya fue pasado a impreso.' });
        }
        const existente = reutilizableDe(actuales);
        if (existente) return responderMejora(existente);
        return res.status(409).json({ success: false, error: 'Estamos preparando el cambio a Kit Impreso. Probá de nuevo en unos segundos.' });
      }
      throw errInsert;
    }
    const nueva = creada?.[0];
    if (metodo === 'transferencia' && nueva?.id) await enviarAvisoTransferenciaRegistrada(supabase, 'id', nueva.id);
    return res.json({
      success: true,
      pedidoId: nueva?.id,
      pedidoFriendlyId: nueva?.pedido_friendly_id || fila.pedido_friendly_id,
      total: precioMejoraAImpreso(),
      metodoPago: metodo,
      accesoToken: tokenAccesoPedido(nueva?.id),
    });
  } catch (err: any) {
    console.error('[Mejora a impreso] Error:', err);
    return res.status(500).json({ success: false, error: 'No pudimos preparar el cambio a Kit Impreso. Intentá nuevamente.' });
  }
});

export { rutas as rutasMejoraImpreso };
