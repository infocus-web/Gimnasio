// Email de «pedido pendiente de pago» con el link a la web (con la llave del pedido) para pagar o subir el
// comprobante. Lo usa el recordatorio de las 12 h (tareasProgramadas.ts, de donde se movió el 14/10/2026)
// y, desde el 14/10/2026, sale también apenas se registra un pedido por TRANSFERENCIA
// (enviarAvisoTransferenciaRegistrada): la familia se va a la app del banco y, si después entra desde
// otro dispositivo, tiene en el email los datos, el plazo de 48 h y el botón para subir el comprobante.
// Con tarjeta (Mercado Pago/Nave) no se manda al crear: casi todos pagan en el momento (sería un email de
// más por pedido contra el cupo diario de Resend); para pagar desde otro dispositivo, el portal entrega la
// llave a la familia identificada (/api/pedidos/existente) y el recordatorio de las 12 h trae el link.
import crypto from 'crypto';
import type { SupabaseClient } from '@supabase/supabase-js';
import { tokenAccesoPedido } from '../nucleo/accesoPedidos.js';
import { getResendClient, resendReplyTo } from '../nucleo/clientes.js';
import { escapeHtml } from '../nucleo/utilidades.js';
import { fechaHoraArgentina, venceTransferenciaDe } from './comprobantes.js';

export function urlPedidoPendiente(fila: { id: string; grupo_pago_id?: string | null }): string {
  const appUrl = (process.env.APP_URL || 'https://www.retratoescolar.com.ar').replace(/\/+$/, '');
  const referencia = fila.grupo_pago_id || fila.id;
  const parametro = fila.grupo_pago_id ? 'grupo_pago_id' : 'pedido_id';
  const llave = tokenAccesoPedido(String(referencia));
  return `${appUrl}/?pago_pendiente=1&${parametro}=${encodeURIComponent(String(referencia))}${llave ? `&t=${llave}` : ''}`;
}

// `ultimoAviso` (10/10, pedido de Pablo): el aviso a la familia unas horas antes de que venza el plazo de
// la transferencia (ver avisarTransferenciasPorVencer). Sin esa opción el email sale igual que antes.
// 14/10/2026: `recienRegistrado` = el mismo email, apenas se registra un pedido por transferencia.
export function htmlRecordatorioPago(datos: { tutorNombre: string; numeros: string; alumnos: string; total: number; metodo: string; url: string; vence?: Date | null; ultimoAviso?: boolean; recienRegistrado?: boolean }): { subject: string; html: string } {
  const esTransferencia = datos.metodo === 'transferencia';
  const ultimoAviso = Boolean(datos.ultimoAviso && esTransferencia && datos.vence);
  const monto = `$${datos.total.toLocaleString('es-AR')}`;
  const boton = (texto: string) =>
    `<p style="text-align:center;margin:24px 0"><a href="${escapeHtml(datos.url)}" style="background:#f59e0b;color:#0f172a;text-decoration:none;font-weight:bold;padding:12px 22px;border-radius:10px;display:inline-block">${texto}</a></p>`;
  const datosBanco = `<div style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:10px;padding:12px 14px;font-size:13px;margin:12px 0"><strong>Alias:</strong> <span style="font-family:monospace">RETRATO.ESCOLAR</span><br><strong>CBU:</strong> <span style="font-family:monospace">0070313830004052956749</span> · Banco Galicia<br><strong>Monto:</strong> ${monto}</div>`;
  const cuerpo = esTransferencia
    ? `<p>Registramos tu pedido <strong>${escapeHtml(datos.numeros)}</strong> (${escapeHtml(datos.alumnos)}) por <strong>${monto}</strong> con pago por <strong>transferencia</strong>${datos.recienRegistrado ? '. Para confirmarlo necesitamos el comprobante de la transferencia.' : ', pero todavía no recibimos el comprobante.'}</p>
<p><strong>¿Ya transferiste?</strong> Subí una captura o foto del comprobante desde este botón, así lo verificamos y confirmamos tu pedido:</p>
${boton('Subir mi comprobante')}
<p><strong>¿Todavía no transferiste?</strong> Estos son los datos:</p>${datosBanco}
<p>Después de transferir, subí el comprobante con el mismo botón.</p>${
        datos.vence && !ultimoAviso
          ? `<p style="background:#fff7ed;border:1px solid #fdba74;border-radius:10px;padding:10px 12px"><strong>Importante:</strong> si no recibimos el comprobante antes del <strong>${escapeHtml(fechaHoraArgentina(datos.vence))}</strong>, el pedido se cancela automáticamente.</p>`
          : ''
      }`
    : `<p>Registramos tu pedido <strong>${escapeHtml(datos.numeros)}</strong> (${escapeHtml(datos.alumnos)}) por <strong>${monto}</strong>, pero todavía no se acreditó el pago.</p>
<p>Podés completarlo ahora con Mercado Pago o elegir transferencia desde este botón:</p>
${boton('Completar mi pago')}
<p>Si ya pagaste por transferencia, entrá con el mismo botón, elegí <strong>Transferencia</strong> y subí el comprobante.</p>`;
  const bannerUltimoAviso = ultimoAviso
    ? `<p style="background:#fef2f2;border:1px solid #fca5a5;border-radius:10px;padding:10px 12px"><strong>Último aviso:</strong> si no recibimos el comprobante antes del <strong>${escapeHtml(fechaHoraArgentina(datos.vence as Date))}</strong>, el pedido se cancela automáticamente.</p>\n`
    : '';
  return {
    subject: datos.recienRegistrado && esTransferencia
      ? `Retrato Escolar: datos para transferir y subir el comprobante de tu pedido ${datos.numeros}`
      : ultimoAviso
      ? `Retrato Escolar: último aviso, falta el comprobante de tu pedido ${datos.numeros}`
      : esTransferencia
        ? `Retrato Escolar: nos falta el comprobante de tu pedido ${datos.numeros}`
        : `Retrato Escolar: tu pedido ${datos.numeros} está pendiente de pago`,
    html: `<div style="font-family:Arial,sans-serif;max-width:560px;margin:auto;color:#1e293b">
<p>Hola <strong>${escapeHtml(datos.tutorNombre)}</strong>,</p>
${bannerUltimoAviso}${cuerpo}
<p>Si ya lo hiciste en las últimas horas, ignorá este mensaje. Ante cualquier duda, respondé este email.</p>
<p style="font-size:12px;color:#64748b">Pedido ${escapeHtml(datos.numeros)} · Retrato Escolar · retratoescolar.com.ar</p></div>`,
  };
}

/**
 * Email inmediato de un pedido recién registrado por transferencia (un pedido suelto o el carrito entero).
 * Idempotente (`pedido-pendiente-<grupo o id>`: un reintento del mismo checkout no manda otro). Nunca
 * corta la creación del pedido: con tope de 3 s (14/10/2026: antes 5 s, sumaba demora al crear el pedido;
 * en Vercel la función se congela al responder) y sin propagar errores. Devuelve si se mandó.
 * 14/10/2026: `claveConIds` (reservas que se suman a un carrito ya creado, en dos pasos): la clave lleva un
 * resumen de los ids de las filas, así otro lote del mismo grupo (otro contenido) no reusa la clave.
 */
export async function enviarAvisoTransferenciaRegistrada(supabase: SupabaseClient, columna: 'id' | 'grupo_pago_id', valor: string, opciones: { claveConIds?: boolean } = {}): Promise<boolean> {
  const envio = async (): Promise<boolean> => {
    const resend = getResendClient();
    if (!resend || !valor) return false;
    const { data, error } = await supabase
      .from('pedidos')
      .select('id, estado, total, metodo_pago, grupo_pago_id, pedido_friendly_id, alumno_nombre, transferencia_desde, comprobante_subido_at, cancelado_definitivo, familias(nombre, email)')
      .eq(columna, valor);
    if (error) throw error;
    const filas = (data || []).filter((f: any) => f.estado === 'pendiente_pago' && !f.cancelado_definitivo);
    if (filas.length === 0 || filas.some((f: any) => f.metodo_pago !== 'transferencia' || f.comprobante_subido_at)) return false;
    const email = String(filas.map((f: any) => f.familias?.email).find((e: any) => e && String(e).includes('@')) || '');
    if (!email) return false;
    const { subject, html } = htmlRecordatorioPago({
      tutorNombre: filas.map((f: any) => f.familias?.nombre).find(Boolean) || 'Familia',
      numeros: [...new Set(filas.map((f: any) => f.pedido_friendly_id || String(f.id).slice(0, 8)))].join(', '),
      alumnos: [...new Set(filas.map((f: any) => f.alumno_nombre).filter(Boolean))].join(', ') || 'tu pedido',
      total: filas.reduce((acc: number, f: any) => acc + (Number(f.total) || 0), 0),
      metodo: 'transferencia',
      url: urlPedidoPendiente(filas[0]),
      vence: venceTransferenciaDe(filas),
      recienRegistrado: true,
    });
    const r = await resend.emails.send(
      { from: process.env.RESEND_FROM_EMAIL || 'Retrato Escolar <fotos@retratoescolar.com.ar>', replyTo: resendReplyTo, to: [email], subject, html },
      { idempotencyKey: `pedido-pendiente-${filas[0].grupo_pago_id || filas[0].id}${opciones.claveConIds ? `-${crypto.createHash('sha256').update(filas.map((f: any) => String(f.id)).sort().join(',')).digest('hex').slice(0, 16)}` : ''}` }
    );
    if (r.error) console.warn('[aviso pedido pendiente] No se pudo enviar:', r.error);
    return !r.error;
  };
  let temporizador: ReturnType<typeof setTimeout> | undefined;
  try {
    // El envío rechazado después del tope no queda como promesa sin manejar.
    const enCurso = envio().catch((err) => (console.warn('[aviso pedido pendiente] Error:', err), false));
    return await Promise.race([enCurso, new Promise<boolean>((ok) => { temporizador = setTimeout(() => ok(false), 3000); })]);
  } catch (err) {
    console.warn('[aviso pedido pendiente] Error:', err);
    return false;
  } finally {
    if (temporizador) clearTimeout(temporizador);
  }
}
