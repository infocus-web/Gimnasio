// Mercado Pago Checkout Pro: preferencias (un pedido y carrito de hermanos) y el webhook (firma
// obligatoria) (división de server.ts, etapa 6, 10/10/2026). El código es el mismo que estaba en la
// sección "7. INTEGRACIÓN MERCADO PAGO" de server.ts: sólo se movió. En server.ts eran dos tramos: por
// eso hay dos routers.
import crypto from 'crypto';
import express from 'express';
import { Payment, Preference } from 'mercadopago';
import { procesarPedidosRecienPagados } from '../entrega/pedidosPagados.js';
import { llaveRecibida, tokenAccesoPedido, tokenAccesoValido } from '../nucleo/accesoPedidos.js';
import { registrarAlertaPago } from '../nucleo/alertas.js';
import { compararTimingSafe } from '../nucleo/auth.js';
import { getMercadoPagoConfig, getServerSupabase } from '../nucleo/clientes.js';
import { limitarFrecuencia } from '../nucleo/limites.js';
import { marcarReferenciaComoPagada, obtenerPedidosPendientesParaCobro, comprobanteFrenaCobro, RESPUESTA_COMPROBANTE_YA_SUBIDO } from './cobros.js';

// Un router por cada tramo de server.ts donde estaban estas rutas (así el orden de Express no cambia).
const rutasPreferencias = express.Router();
const rutasWebhook = express.Router();

// Crear preferencia de pago en Mercado Pago
rutasPreferencias.post('/api/mercadopago/crear-preferencia', limitarFrecuencia('crear-preferencia', 200, 10 * 60 * 1000), async (req, res) => {
  try {
    const {
      pedidoId,
      kitId,
      kitNombre,
      alumnoNombre,
      colegioNombre,
      carpetasExtras,
      cantidadFotosSueltas,
      tutorNombre,
      tutorEmail,
      tutorTelefono,
    } = req.body;

    // Auditoría 2026-09-23 (bug CRÍTICO de cobro): el monto se toma del pedido YA REGISTRADO
    // en la base (columna `total`, calculada por el servidor en /api/pedidos/crear), nunca de
    // kitId/carpetasExtras/cantidadFotosSueltas que mande el navegador acá. Antes se recalculaba
    // con esos datos sueltos: bastaba registrar un Kit Impreso con 3 carpetas extra ($75.000) y
    // después pedir la preferencia de ESE MISMO pedido diciendo "kit-evento-suelto" ($5.000) —
    // el webhook marcaba el pedido como pagado igual y la familia recibía todo por $5.000.
    void kitId; void carpetasExtras; void cantidadFotosSueltas;
    const supabaseCobro = getServerSupabase();
    if (!supabaseCobro) {
      return res.status(500).json({ success: false, error: 'Supabase no configurado en el servidor' });
    }
    const cobro = await obtenerPedidosPendientesParaCobro(supabaseCobro, { pedidoId });
    if (cobro.error) {
      return res.status(cobro.status || 400).json({ success: false, error: cobro.error });
    }
    // 14/10/2026: con el comprobante de una transferencia ya subido no se genera un link sin confirmación.
    if (comprobanteFrenaCobro(cobro.filas, req.body)) return res.status(409).json(RESPUESTA_COMPROBANTE_YA_SUBIDO);
    const totalCalculado = Number(cobro.filas[0].total);

    const mpConfig = getMercadoPagoConfig();
    if (!mpConfig) {
      return res.status(200).json({
        success: false,
        notConfigured: true,
        error: 'MERCADOPAGO_ACCESS_TOKEN no está configurada en las variables de entorno del servidor.',
      });
    }

    // Mercado Pago exige que "back_urls.success" sea una URL https válida cuando se usa
    // "auto_return" — si no, devuelve el error engañoso "auto_return invalid. back_url.success
    // must be defined" aunque la URL sí esté definida. En producción (fuera de localhost)
    // forzamos https siempre, sin depender de que el proxy haya informado bien el protocolo.
    const hostDetectado = req.get('host') || '';
    const esLocal = /^(localhost|127\.0\.0\.1)(:\d+)?$/i.test(hostDetectado);
    const protocoloFinal = esLocal ? req.protocol : 'https';
    const appUrl = (process.env.APP_URL || `${protocoloFinal}://${hostDetectado}`).replace(/\/+$/, '');
    const preference = new Preference(mpConfig);
    // Llave de acceso del pedido (ver tokenAccesoPedido): viaja en la URL de vuelta para que el
    // portal pueda mostrar la descarga al volver del pago.
    // Auditoría 30/9 (A4): la llave viaja en la URL de vuelta sólo si quien pide el pago ya la tiene.
    // Antes bastaba el UUID del pedido (lo ven los compañeros del curso) para que la pasarela le
    // devolviera la llave, y con ella la descarga HD cuando la familia pagaba.
    const llave = tokenAccesoValido(llaveRecibida(req), [String(pedidoId), cobro.filas[0]?.grupo_pago_id]) ? tokenAccesoPedido(String(pedidoId)) : null;
    const sufijoLlave = llave ? `&t=${llave}` : '';

    const preferenceData = {
      body: {
        items: [
          {
            id: pedidoId || `PED-${Date.now()}`,
            title: `Retrato Escolar 2026 - ${kitNombre || 'Kit Fotográfico'} (${alumnoNombre || 'Alumno'})`,
            description: `Fotos escolares para ${alumnoNombre} en ${colegioNombre}`,
            quantity: 1,
            unit_price: totalCalculado,
            currency_id: 'ARS',
          },
        ],
        payer: {
          name: tutorNombre || 'Familia',
          email: tutorEmail && tutorEmail.includes('@') ? tutorEmail : 'pagos@retratoescolar.com.ar',
          phone: {
            number: tutorTelefono || '',
          },
        },
        back_urls: {
          success: `${appUrl}/?mp_status=approved&pedido_id=${pedidoId}${sufijoLlave}`,
          failure: `${appUrl}/?mp_status=rejected&pedido_id=${pedidoId}${sufijoLlave}`,
          pending: `${appUrl}/?mp_status=pending&pedido_id=${pedidoId}${sufijoLlave}`,
        },
        auto_return: 'approved',
        external_reference: pedidoId,
        notification_url: `${appUrl}/api/mercadopago/webhook`,
        statement_descriptor: 'RETRATO ESCOLAR',
        // Auditoría 2026-09-26 (M1): el link de pago vence a los 3 días. Antes no vencía nunca:
        // la familia podía pagarlo después de haber pagado por otro medio (pago doble). Si vence,
        // el portal genera uno nuevo con el mismo pedido.
        expires: true,
        expiration_date_from: new Date(Date.now() - 60 * 1000).toISOString(),
        expiration_date_to: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000).toISOString(),
      },
    };

    const result = await preference.create(preferenceData);

    // Auditoría 2026-09-23: mp_preference_id nunca se grababa — y el respaldo de reconciliación
    // de /api/pedidos/:id/status sólo corre si esa columna tiene valor, así que ese respaldo
    // (pensado para cuando el webhook de Mercado Pago se pierde) no se ejecutaba nunca.
    if (result.id) {
      // Auditoría 03/10 noche (M2): link_pago_at = cuándo se generó el último link; la conciliación
      // automática revisa por esa fecha (antes miraba updated_at, que crear un link no actualiza).
      const { error: errorLink } = await supabaseCobro.from('pedidos').update({ mp_preference_id: String(result.id), link_pago_at: new Date().toISOString() }).eq('id', pedidoId);
      // Auditoría 11/10: sin el id del link guardado, un pago con el aviso perdido no lo encuentra la conciliación.
      if (errorLink) throw errorLink;
    }

    return res.json({
      success: true,
      preferenceId: result.id,
      initPoint: result.init_point,
      sandboxInitPoint: result.sandbox_init_point,
    });
  } catch (error: any) {
    console.error('[Mercado Pago Preference Error]:', error);
    return res.status(500).json({
      success: false,
      error: error?.message || 'Error al crear la preferencia de pago en Mercado Pago',
    });
  }
});

// Auditoría 2026-09-16 (carrito multi-hijo, "un solo pago"): equivalente a
// /api/mercadopago/crear-preferencia, pero arma UNA sola preferencia con un ítem de línea por
// cada hijo del carrito (mismo total combinado que se le va a cobrar a la familia en un único
// checkout). Mismo criterio de seguridad: el monto de cada línea se recalcula siempre acá con
// calcularTotalPedido, nunca se usa un total mandado por el cliente. "external_reference" es el
// grupoPagoId compartido por todos los pedidos de este carrito (ver /api/pedidos/crear-multiple),
// no el id de un pedido puntual — así el webhook sabe que tiene que marcar varias filas como
// pagadas, no una sola.
rutasPreferencias.post('/api/mercadopago/crear-preferencia-multiple', limitarFrecuencia('crear-preferencia-multiple', 200, 10 * 60 * 1000), async (req, res) => {
  try {
    const { grupoPagoId, items, tutorNombre, tutorEmail, tutorTelefono } = req.body || {};

    // Los ítems que manda el navegador ya no se usan para cobrar (ver abajo: se cobra lo registrado
    // en la base para este grupo) — sólo hace falta el grupo. Así el portal puede regenerar el link
    // de un carrito sin tener que reconstruir la lista de hijos.
    void items;
    if (!grupoPagoId) {
      return res.status(400).json({ success: false, error: 'Falta el grupo de pago del carrito.' });
    }

    // Auditoría 2026-09-23: igual que en /api/mercadopago/crear-preferencia, cada línea se cobra
    // con el `total` de la fila YA REGISTRADA en la base para este grupo_pago_id — nunca con los
    // datos de kit/carpetas/fotos que mande el navegador en este request.
    const supabaseCobro = getServerSupabase();
    if (!supabaseCobro) {
      return res.status(500).json({ success: false, error: 'Supabase no configurado en el servidor' });
    }
    const cobro = await obtenerPedidosPendientesParaCobro(supabaseCobro, { grupoPagoId });
    if (cobro.error) {
      return res.status(cobro.status || 400).json({ success: false, error: cobro.error });
    }
    // 14/10/2026: con el comprobante de una transferencia ya subido no se genera un link sin confirmación.
    if (comprobanteFrenaCobro(cobro.filas, req.body)) return res.status(409).json(RESPUESTA_COMPROBANTE_YA_SUBIDO);
    // Pago anticipado: al volver del pago se muestra la pantalla de "reserva confirmada".
    // Pantalla de "reserva confirmada" sólo si TODO el pago son reservas; una compra con fotos más
    // la reserva de un hermano vuelve a la confirmación normal de compra.
    const sufijoReserva = cobro.filas.length > 0 && cobro.filas.every((fila: any) => fila.seleccion_pendiente) ? '&reserva=1' : '';
    const mpItems: any[] = cobro.filas.map((fila: any) => ({
      id: fila.id,
      title: `Retrato Escolar 2026 - ${fila.kit_nombre || 'Kit Fotográfico'} (${fila.alumno_nombre || 'Alumno'})`,
      description: `Fotos escolares para ${fila.alumno_nombre || 'alumno'} en ${fila.colegio_nombre || 'el colegio'}`,
      quantity: 1,
      unit_price: Number(fila.total),
      currency_id: 'ARS',
    }));

    const mpConfig = getMercadoPagoConfig();
    if (!mpConfig) {
      return res.status(200).json({
        success: false,
        notConfigured: true,
        error: 'MERCADOPAGO_ACCESS_TOKEN no está configurada en las variables de entorno del servidor.',
      });
    }

    const hostDetectado = req.get('host') || '';
    const esLocal = /^(localhost|127\.0\.0\.1)(:\d+)?$/i.test(hostDetectado);
    const protocoloFinal = esLocal ? req.protocol : 'https';
    const appUrl = (process.env.APP_URL || `${protocoloFinal}://${hostDetectado}`).replace(/\/+$/, '');
    const preference = new Preference(mpConfig);
    // Auditoría 30/9 (A4): la llave vuelve en la URL sólo si quien pide el pago ya la tiene.
    const llave = tokenAccesoValido(llaveRecibida(req), [String(grupoPagoId)]) ? tokenAccesoPedido(String(grupoPagoId)) : null;
    const sufijoLlave = llave ? `&t=${llave}` : '';

    const preferenceData = {
      body: {
        items: mpItems,
        payer: {
          name: tutorNombre || 'Familia',
          email: tutorEmail && tutorEmail.includes('@') ? tutorEmail : 'pagos@retratoescolar.com.ar',
          phone: { number: tutorTelefono || '' },
        },
        back_urls: {
          success: `${appUrl}/?mp_status=approved&grupo_pago_id=${grupoPagoId}${sufijoReserva}${sufijoLlave}`,
          failure: `${appUrl}/?mp_status=rejected&grupo_pago_id=${grupoPagoId}${sufijoReserva}${sufijoLlave}`,
          pending: `${appUrl}/?mp_status=pending&grupo_pago_id=${grupoPagoId}${sufijoReserva}${sufijoLlave}`,
        },
        auto_return: 'approved',
        external_reference: grupoPagoId,
        notification_url: `${appUrl}/api/mercadopago/webhook`,
        statement_descriptor: 'RETRATO ESCOLAR',
        // Auditoría 2026-09-26 (M1): el link de pago vence a los 3 días. Antes no vencía nunca:
        // la familia podía pagarlo después de haber pagado por otro medio (pago doble). Si vence,
        // el portal genera uno nuevo con el mismo pedido.
        expires: true,
        expiration_date_from: new Date(Date.now() - 60 * 1000).toISOString(),
        expiration_date_to: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000).toISOString(),
      },
    };

    const result = await preference.create(preferenceData);

    if (result.id) {
      // Auditoría 03/10 (alto 10): sólo las filas que este link cobra (no los hermanos cancelados).
      const { error: errorLink } = await supabaseCobro.from('pedidos').update({ mp_preference_id: String(result.id), link_pago_at: new Date().toISOString() }).in('id', cobro.filas.map((f: any) => f.id));
      if (errorLink) throw errorLink; // Auditoría 11/10: ver crear-preferencia
    }

    return res.json({
      success: true,
      preferenceId: result.id,
      initPoint: result.init_point,
      sandboxInitPoint: result.sandbox_init_point,
    });
  } catch (error: any) {
    console.error('[Mercado Pago Preference Multiple Error]:', error);
    return res.status(500).json({
      success: false,
      error: error?.message || 'Error al crear la preferencia de pago combinada en Mercado Pago',
    });
  }
});

/** Aviso IPN de Mercado Pago (`?topic=…&id=…`, sin `data.id`): no se puede validar con la clave secreta. */
export function esAvisoIpn(query: Record<string, unknown>): boolean {
  return typeof query.topic === 'string' && query['data.id'] === undefined;
}

// Webhook de Mercado Pago
rutasWebhook.post(['/api/mercadopago/webhook', '/mercadopago/webhook'], async (req, res) => {
  try {
    const mpConfig = getMercadoPagoConfig();
    if (!mpConfig) {
      console.warn('[Mercado Pago Webhook] Notificación recibida pero MERCADOPAGO_ACCESS_TOKEN no está configurada.');
      return res.status(200).send('OK');
    }

    // 10/10: Mercado Pago avisa cada pago dos veces. Por Webhooks (`?data.id=…&type=payment`, firmado
    // con la clave secreta: es el que se procesa más abajo) y por IPN (`?topic=payment|merchant_order&id=…`).
    // Los IPN traen x-signature, pero Mercado Pago aclara que NO se pueden validar con la clave secreta:
    // antes se contestaban 401 y Mercado Pago los reintentaba durante días (ruido en los registros, sin
    // efecto: el pago ya lo había registrado el aviso firmado). Ahora se contestan 200 sin procesar nada.
    // Si se pierde el aviso firmado, el pago lo registra igual la conciliación cada 10 minutos o /status.
    if (esAvisoIpn(req.query)) {
      return res.status(200).send('OK');
    }

    const topic = req.query.topic || req.body?.type || req.body?.topic;
    const paymentId = req.query.id || req.body?.data?.id || req.query['data.id'];

    console.log(`[Mercado Pago Webhook] Notificación recibida: topic=${topic}, paymentId=${paymentId}`);

    // Verificación de firma del webhook de Mercado Pago.
    // Auditoría 03/10: sin MERCADOPAGO_WEBHOOK_SECRET el aviso se rechaza (antes se procesaba sin
    // verificar nada). Los pagos igual se registran por el control automático cada 10 minutos.
    const webhookSecret = process.env.MERCADOPAGO_WEBHOOK_SECRET;
    if (!webhookSecret || !webhookSecret.trim()) {
      console.error('[Mercado Pago Webhook] Falta MERCADOPAGO_WEBHOOK_SECRET en el servidor: aviso rechazado. Cargala en Vercel (Mercado Pago → Tus integraciones → Webhooks → Clave secreta).');
      return res.status(401).send('Webhook secret not configured');
    }
    {
      const xSignature = req.headers['x-signature'] as string;
      const xRequestId = req.headers['x-request-id'] as string;
      // Auditoría 2026-09-19 (bug real encontrado en auditoría de código, BAJO): si faltaba el
      // header x-signature (o venía sin las partes "ts"/"v1" reconocibles), este bloque no
      // hacía nada — ni rechazaba ni advertía — y la notificación se procesaba como si la firma
      // hubiera sido válida. Con MERCADOPAGO_WEBHOOK_SECRET configurado, la intención es
      // rechazar cualquier notificación que no pueda verificarse, no sólo la que tiene una firma
      // presente pero incorrecta.
      if (!xSignature) {
        console.warn('[Mercado Pago Webhook] Falta el header x-signature (con MERCADOPAGO_WEBHOOK_SECRET configurado) — notificación rechazada.');
        return res.status(401).send('Missing signature');
      }
      const parts = xSignature.split(',');
      let ts = '';
      let hash = '';
      for (const part of parts) {
        const [k, v] = part.split('=');
        if (k && k.trim() === 'ts') ts = (v || '').trim();
        if (k && k.trim() === 'v1') hash = (v || '').trim();
      }
      if (!ts || !hash) {
        console.warn('[Mercado Pago Webhook] Header x-signature con formato inesperado — notificación rechazada.');
        return res.status(401).send('Invalid signature format');
      }
      const manifest = `id:${paymentId};request-id:${xRequestId || ''};ts:${ts};`;
      const expectedHash = crypto
        .createHmac('sha256', webhookSecret.trim())
        .update(manifest)
        .digest('hex');
      // Antes esto solo dejaba un warning en el log y SEGUÍA procesando la notificación
      // igual. El impacto real de una firma inválida era acotado (después igual se
      // reconsulta el pago directo contra la API de Mercado Pago con el access token
      // propio, así que no se puede "inventar" un pago aprobado), pero no hay motivo para
      // aceptar una notificación que dice no venir de Mercado Pago: se rechaza.
      if (!compararTimingSafe(hash, expectedHash)) {
        console.warn('[Mercado Pago Webhook] Firma x-signature inválida — notificación rechazada.');
        return res.status(401).send('Invalid signature');
      }
      // Auditoría 03/10: un aviso firmado pero muy viejo (más de 72 h) se rechaza: sin esto, un aviso
      // capturado se podía reenviar para siempre. La ventana es amplia a propósito: Mercado Pago
      // reintenta el MISMO aviso (mismo ts firmado) durante horas/días si no le respondimos 200, y
      // reprocesarlo es idempotente porque el estado real siempre se reconsulta a la API de MP (el
      // cuerpo del aviso no decide nada); un reenvío malicioso sólo provoca una consulta de más.
      const tsNumero = Number(ts);
      const tsMs = tsNumero > 1e12 ? tsNumero : tsNumero * 1000;
      if (!Number.isFinite(tsMs) || Math.abs(Date.now() - tsMs) > 72 * 60 * 60 * 1000) {
        console.warn('[Mercado Pago Webhook] Aviso con ts vencido — notificación rechazada.');
        return res.status(401).send('Stale notification');
      }
    }

    if ((topic === 'payment' || req.body?.action?.includes('payment')) && paymentId) {
      const payment = new Payment(mpConfig);
      const paymentInfo = await payment.get({ id: String(paymentId), requestOptions: { timeout: 8000 } });

      console.log(`[Mercado Pago Webhook] Estado de pago: ${paymentInfo.status}, Ref: ${paymentInfo.external_reference}`);

      const pedidoId = paymentInfo.external_reference;
      const supabase = getServerSupabase();

      // Auditoría 03/10 (alto 11): ¿este pago ya había pagado filas? Si después llega "cancelled" o
      // "rejected" para ESE mismo pago, es una reversión (no un intento fallido antes de pagar).
      // Auditoría 11/10: si la lectura falla, 500 (MP reintenta) en vez de tomar una reversión por un rechazo.
      const lecturaPago = supabase && ['cancelled', 'rejected', 'approved'].includes(String(paymentInfo.status))
        ? await supabase.from('pedidos').select('id, estado, cancelado_definitivo').eq('mp_payment_id', String(paymentId))
        : null;
      if (lecturaPago?.error) throw lecturaPago.error;
      const filasDeEstePago: any[] = lecturaPago?.data || [];
      const yaHabiaPagado = filasDeEstePago.some((f: any) => f.estado === 'pagado' || f.estado === 'entregado');

      if (paymentInfo.status === 'approved') {
        // 29/10: Mercado Pago a veces avisa un pago "aprobado" por $0 sin referencia (validación de la
        // tarjeta justo antes del cobro real): no movió plata, así que no es una alerta.
        if (!pedidoId && supabase && Number(paymentInfo.transaction_amount) > 0) {
          // Auditoría 03/10 (alto 9): pago aprobado sin referencia a un pedido: nadie lo iba a ver.
          await registrarAlertaPago(supabase, `pago-huerfano:${paymentId}`, `PAGO SIN PEDIDO: Mercado Pago aprobó el pago ${paymentId} por $${paymentInfo.transaction_amount} sin referencia a ningún pedido. Revisalo y devolvé el dinero si corresponde.`, { paymentId, monto: paymentInfo.transaction_amount, payer: paymentInfo.payer?.email || null });
        }
        // Reembolso PARCIAL (el pago sigue "approved"): si no fue una cancelación hecha desde el panel
        // (que deja la fila cancelada definitivo), queda aviso para revisar.
        if (supabase && Number((paymentInfo as any).transaction_amount_refunded) > 0 && !filasDeEstePago.some((f: any) => f.cancelado_definitivo)) {
          await registrarAlertaPago(supabase, `reembolso-parcial-mp:${paymentId}`, `Mercado Pago informa un reembolso parcial de $${(paymentInfo as any).transaction_amount_refunded} en el pago ${paymentId} (referencia ${pedidoId || '—'}). Revisá qué pedido corresponde cancelar.`, { paymentId, referencia: pedidoId || null });
        }
        if (pedidoId && supabase) {
          // Auditoría 2026-09-23: toda la lógica de "qué pedidos corresponden a esta referencia"
          // (un pedido suelto por su UUID, o un carrito multi-hijo por grupo_pago_id) + control de
          // monto + marcado idempotente (.neq('estado','pagado'), así un reenvío de Mercado Pago no
          // duplica correos) vive en marcarReferenciaComoPagada — la comparten el webhook de Nave y
          // el respaldo de /api/pedidos/:id/status.
          const orderRows = await marcarReferenciaComoPagada(supabase, String(pedidoId), Number(paymentInfo.transaction_amount), {
            mp_payment_id: String(paymentId),
          });
          await procesarPedidosRecienPagados(supabase, orderRows, paymentInfo.payer?.email, paymentInfo.payer?.first_name);
        }
      } else if (paymentInfo.status === 'in_mediation') {
        // Auditoría 03/10 (alto 11): una disputa abierta todavía no es un contracargo: sólo aviso.
        if (supabase) {
          await registrarAlertaPago(supabase, `mediacion-mp:${paymentId}`, `Mercado Pago abrió una MEDIACIÓN/disputa por el pago ${paymentId} (referencia ${pedidoId || '—'}). El pedido no se canceló: respondé la disputa en Mercado Pago y, si se pierde, va a llegar el contracargo.`, { paymentId, referencia: pedidoId || null });
        }
      } else if ((paymentInfo.status === 'rejected' || paymentInfo.status === 'cancelled') && !yaHabiaPagado) {
        if (pedidoId && supabase) {
          // Auditoría 2026-09-19: ".neq('estado','pagado')" para que un rechazo tardío de un intento
          // viejo no revierta un pedido ya pagado.
          // Auditoría 2026-09-26 (M4): además, un rechazo sólo cancela si (a) el pedido sigue siendo
          // de Mercado Pago (si la familia pasó a transferencia/Nave, un rechazo viejo de MP no lo
          // anula — antes eso además le impedía subir el comprobante) y (b) no hay OTRO intento de
          // MP aprobado o todavía en curso para la misma referencia (ej. la tarjeta rebotó y pagó
          // en efectivo en Rapipago, que queda "pending" hasta acreditarse).
          let hayOtroIntentoVivo = false;
          try {
            const busqueda = await payment.search({ options: { external_reference: String(pedidoId), sort: 'date_created', criteria: 'desc' }, requestOptions: { timeout: 8000 } });
            hayOtroIntentoVivo = (busqueda?.results || []).some((p) =>
              String(p.id) !== String(paymentId) && ['approved', 'pending', 'in_process', 'authorized'].includes(String(p.status))
            );
          } catch (errBusqueda) {
            console.warn('[Mercado Pago Webhook] No se pudieron revisar otros intentos; no se cancela por las dudas.', errBusqueda);
            hayOtroIntentoVivo = true;
          }
          if (!hayOtroIntentoVivo) {
            console.log(`[Mercado Pago Webhook] Marcando pedido ${pedidoId} como rechazado/cancelado.`);
            const { data: dataCancelado } = await supabase
              .from('pedidos')
              .update({ estado: 'cancelado', updated_at: new Date().toISOString() })
              .eq('id', pedidoId)
              .eq('metodo_pago', 'mercadopago')
              .eq('estado', 'pendiente_pago') // Auditoría 08/10 (M6): antes .neq('pagado') también cancelaba 'entregado'
              .eq('cancelado_definitivo', false)
              .select('id');
            if (!dataCancelado || dataCancelado.length === 0) {
              await supabase
                .from('pedidos')
                .update({ estado: 'cancelado', updated_at: new Date().toISOString() })
                .eq('grupo_pago_id', pedidoId)
                .eq('metodo_pago', 'mercadopago')
                .eq('estado', 'pendiente_pago') // Auditoría 08/10 (M6): antes .neq('pagado') también cancelaba 'entregado'
                .eq('cancelado_definitivo', false);
            }
          }
        }
      } else if (paymentInfo.status === 'refunded' || paymentInfo.status === 'charged_back' || paymentInfo.status === 'cancelled' || paymentInfo.status === 'rejected') {
        // Auditoría 2026-09-26 (A4): un pago reembolsado o con contracargo deja de ser un pago. Antes
        // se ignoraba y el pedido seguía "pagado" con el link HD renovándose. Se cancelan sólo las
        // filas que se pagaron con ESTE pago, y queda una alerta (puede haber un kit impreso en curso).
        // Auditoría 03/10 (alto 11): además queda cancelado_definitivo, así la conciliación no lo
        // vuelve a "pagado" (antes un reembolso podía revivir con el control automático).
        if (supabase) {
          const { data: revertidos, error: errorRevertir } = await supabase
            .from('pedidos')
            .update({ estado: 'cancelado', cancelado_definitivo: true, updated_at: new Date().toISOString() })
            .eq('mp_payment_id', String(paymentId))
            .select('id, pedido_friendly_id, estado_lab');
          // Auditoría 11/10: sin esto, un error de la base respondía 200 y el pedido seguía pagado (con HD).
          if (errorRevertir) throw errorRevertir;
          if (revertidos && revertidos.length > 0) {
            await registrarAlertaPago(supabase, `reembolso-mp:${paymentId}`, `Mercado Pago informó "${paymentInfo.status}" para el pago ${paymentId}: se cancelaron ${revertidos.map((r: any) => r.pedido_friendly_id || r.id).join(', ')} (la descarga HD dejó de estar disponible). Si ya estaba en laboratorio, frenalo.`, { paymentId, pedidos: revertidos });
          }
        }
      }
    }

    return res.status(200).send('OK');
  } catch (error: any) {
    // Preparación temporada (25/9): antes se respondía 200 también ante un error, así que Mercado
    // Pago daba el aviso por entregado y NO reintentaba — un fallo pasajero (base de datos lenta,
    // timeout) dejaba un pago acreditado sin registrar. Con 500, Mercado Pago reintenta, y el
    // procesamiento es idempotente (marcar pagado con .neq('estado','pagado'): sin correos dobles).
    console.error('[Mercado Pago Webhook Error]:', error);
    return res.status(500).send('Error');
  }
});

export { rutasPreferencias as rutasMercadoPagoPreferencias, rutasWebhook as rutasMercadoPagoWebhook };
