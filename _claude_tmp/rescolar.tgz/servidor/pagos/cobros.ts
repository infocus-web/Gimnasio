// Núcleo de los cobros (división de server.ts, etapa 6, 10/10/2026): marcar una referencia como pagada
// (`marcarReferenciaComoPagada`, con sus alertas), si el monto cubre los pedidos, pedidos pendientes de
// cobro, estado de Nave, `claveCheckout` (idempotencia), «ya pagaste este kit» y copias extras. El
// código es el mismo que estaba en la sección "5. HELPER PARA ENVÍO DE EMAIL CON RESEND" de server.ts.
import type { SupabaseClient } from '@supabase/supabase-js';
import crypto from 'crypto';
import { registrarAlertaPago } from '../nucleo/alertas.js';
import { compararTimingSafe } from '../nucleo/auth.js';
import { esPedidoAdicional } from '../nucleo/fotosExtra.js';
import { ESTADOS_COBRABLES } from '../nucleo/pedidos.js';
import { normalizarNombrePorPalabras } from '../nucleo/utilidades.js';

// ==============================================================================
// 5. HELPER PARA ENVÍO DE EMAIL CON RESEND
// ==============================================================================


// Auditoría 30/9 (A4): copias impresas que arma el laboratorio. Las calcula SIEMPRE el servidor con
// lo que se cobró (carpetas extra validadas + fotos sueltas validadas); antes se guardaba el objeto
// que mandaba el navegador y se podían pedir copias sin pagarlas.
export function copiasExtrasServidor(extrasValidados: number, cantidadSueltas: number): Record<string, number> {
  const carpetas = Math.max(0, Math.floor(Number(extrasValidados) || 0));
  return { carpetasExtras: carpetas, individual15x21: carpetas, grupal20x30: carpetas, docente15x21: carpetas, otras15x21: Math.max(0, Math.floor(Number(cantidadSueltas) || 0)) };
}


/**
 * Auditoría 2026-09-23 (bug CRÍTICO de cobro): trae los pedidos pendientes de pago que
 * corresponden a una referencia de pago (el UUID de un pedido, o el grupo_pago_id de un carrito
 * multi-hijo). El monto a cobrar en Mercado Pago / Nave sale SIEMPRE de acá (la columna `total`
 * que calculó el servidor al registrar el pedido) — antes se volvía a calcular con el kit, las
 * carpetas y las fotos sueltas que mandara el navegador en ese momento, sin relación con lo que
 * había quedado guardado en el pedido. Ver /api/mercadopago/crear-preferencia.
 */
export async function obtenerPedidosPendientesParaCobro(
  supabase: SupabaseClient,
  ref: { pedidoId?: unknown; grupoPagoId?: unknown }
): Promise<{ filas: any[]; error?: string; status?: number }> {
  const esUuid = (v: unknown) => typeof v === 'string' && /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(v);
  const columna = ref.grupoPagoId !== undefined ? 'grupo_pago_id' : 'id';
  const valor = ref.grupoPagoId !== undefined ? ref.grupoPagoId : ref.pedidoId;
  if (!esUuid(valor)) {
    return { filas: [], status: 400, error: 'Falta la referencia del pedido a cobrar.' };
  }
  const { data, error } = await supabase
    .from('pedidos')
    .select('id, estado, total, kit_nombre, alumno_nombre, colegio_nombre, grupo_pago_id, seleccion_pendiente, cancelado_definitivo, comprobante_subido_at')
    .eq(columna, valor as string);
  if (error) return { filas: [], status: 500, error: error.message };
  if (!data || data.length === 0) {
    return { filas: [], status: 404, error: 'No encontramos el pedido registrado. Volvé a armar el pedido desde el portal.' };
  }
  // 'cancelado' se permite a propósito: un intento de pago rechazado (tarjeta sin fondos, etc.)
  // deja el pedido "cancelado", y la familia tiene que poder reintentar con otro medio.
  if (data.some((p: any) => p.estado === 'pagado' || p.estado === 'entregado')) {
    return { filas: [], status: 409, error: 'Este pedido ya está pagado.' };
  }
  // Auditoría 03/10 (altos 9 y 10): sólo se cobran las filas que todavía se pueden pagar. Antes el
  // link de un carrito de hermanos incluía al hermano cancelado (por el fotógrafo, arrepentimiento o
  // reserva reemplazada) y se podía generar un link para un pedido con cancelado_definitivo: la
  // familia pagaba algo que el sistema nunca iba a marcar como pagado.
  const cobrables = data.filter((p: any) => ESTADOS_COBRABLES.includes(String(p.estado)) && !p.cancelado_definitivo);
  if (cobrables.length === 0) {
    return { filas: [], status: 409, error: 'Este pedido fue cancelado y ya no se puede pagar. Si querés las fotos, armá un pedido nuevo desde el portal.' };
  }
  if (cobrables.some((p: any) => !(Number(p.total) > 0))) {
    return { filas: [], status: 409, error: 'El pedido no tiene un monto válido para cobrar.' };
  }
  // Auditoría 05/10 (bajo): un pedido que es parte de un carrito de hermanos no se cobra suelto por su
  // id (quedaba pagado un hermano y los otros pendientes, con el link del carrito todavía vivo). Si
  // el carrito tiene otras filas cobrables, el link se arma por el grupo.
  if (columna === 'id' && cobrables[0]?.grupo_pago_id) {
    const { data: hermanos } = await supabase
      .from('pedidos')
      .select('id, estado, cancelado_definitivo')
      .eq('grupo_pago_id', cobrables[0].grupo_pago_id)
      .neq('id', cobrables[0].id)
      .limit(20);
    const otrosCobrables = (hermanos || []).filter((p: any) => ESTADOS_COBRABLES.includes(String(p.estado)) && !p.cancelado_definitivo);
    if (otrosCobrables.length > 0) {
      return { filas: [], status: 409, error: 'Este pedido es parte de un carrito con hermanos: se paga todo junto desde el portal (pantalla de tu pedido).' };
    }
  }
  return { filas: cobrables };
}

// 14/10/2026: la familia ya subió el comprobante de una transferencia y después quiere pagar con tarjeta
// (caso real: «Pendiente de pago» + «¿Preferís pagar de otra forma?» → cobro doble). Cambiar el medio o
// pedir un link de Mercado Pago/Nave exige `confirmarIgual: true` (la familia confirmó que ya transfirió
// y quiere pagar igual); si no, 409 COMPROBANTE_YA_SUBIDO y el portal muestra «comprobante en revisión».
export const RESPUESTA_COMPROBANTE_YA_SUBIDO = {
  success: false,
  codigo: 'COMPROBANTE_YA_SUBIDO',
  error: 'Ya subiste el comprobante de la transferencia de este pedido y lo estamos revisando (lo confirmamos en el día). Si igual querés pagar con tarjeta, confirmalo: puede generar un cobro doble.',
};

export function comprobanteFrenaCobro(filas: { comprobante_subido_at?: string | null }[], cuerpo: any): boolean {
  return cuerpo?.confirmarIgual !== true && filas.some((f) => Boolean(f?.comprobante_subido_at));
}

// Auditoría 03/10 (altos 13, 14 y 17): "le toca a esta llamada" distribuido entre todas las
// instancias de Vercel (tabla limites_intentos vía registrar_intento, ventana fija). Sirve de freno
// ("consultar la pasarela como mucho una vez cada 30 s por pedido") y de lock con vencimiento ("un
// solo cron arma el .zip de este pedido"). Si la base no responde se permite: es preferible una
// consulta de más que trabar un cobro o una entrega.
// Auditoría 03/10: Nave manda el estado a veces como objeto ({ status: { name } }) y a veces como
// texto plano; este lector unifica los dos formatos (en mayúsculas).
export function estadoPagoNave(p: any): string {
  return String(p?.status?.name ?? p?.status ?? '').toUpperCase();
}

// Una intención "procesada" cuyo pago fue reembolsado / revertido / contracargado (estado de reversión
// EXPLÍCITO en algún intento) y sin ningún intento aprobado. Un estado desconocido no cuenta.
export function intencionNaveRevertida(intentos: any[]): boolean {
  const aprobado = intentos.some((p: any) => estadoPagoNave(p) === 'APPROVED');
  return !aprobado && intentos.some((p: any) => ['REFUNDED', 'CHARGED_BACK', 'PURCHASE_REVERSED'].includes(estadoPagoNave(p)));
}

/**
 * Auditoría 03/10 noche (A1): secreto del checkout. El navegador genera `claveCheckout` (al azar,
 * estable durante los reintentos de un mismo checkout) y el servidor guarda su hash en la fila. Un
 * reintento idempotente (mismo pedidoId/reservaId) sólo devuelve la llave del pedido si trae la
 * misma clave: el UUID del pedido (que sale en /api/pedidos/existente, en el QR del sobre, etc.) +
 * el nombre del chico + el email del tutor ya no alcanzan para quedarse con la llave (y el HD).
 */
export function hashClaveCheckout(clave: unknown): string | null {
  const c = String(clave || '').trim();
  if (!/^[0-9a-f]{32,64}$/i.test(c)) return null;
  return crypto.createHash('sha256').update(`clave-checkout:${c.toLowerCase()}`).digest('hex');
}

export function claveCheckoutValida(fila: { clave_checkout_hash?: string | null; created_at?: string | null; estado?: string | null; cancelado_definitivo?: boolean | null } | null | undefined, clave: unknown): boolean {
  if (!fila) return false;
  const hash = hashClaveCheckout(clave);
  if (fila.clave_checkout_hash) return Boolean(hash) && compararTimingSafe(String(hash), String(fila.clave_checkout_hash));
  // Transición del deploy: un navegador con la versión anterior (sin claveCheckout) que reintenta un
  // pedido que él mismo acaba de crear. Sólo vale para pedidos sin pagar de menos de 30 minutos.
  const creado = fila.created_at ? Date.parse(fila.created_at) : NaN;
  return (
    !hash &&
    fila.estado === 'pendiente_pago' &&
    !fila.cancelado_definitivo &&
    Number.isFinite(creado) &&
    Date.now() - creado < 30 * 60 * 1000
  );
}

// Auditoría 03/10 (crítico 2): ¿el pedido ya registrado con este id es de quien lo está volviendo a
// mandar? Mismo chico y mismo email (o, si ninguno de los dos tiene email, mismo teléfono y tutor).
// Si coincide, el reintento devuelve el mismo pedido; si no, nunca se entrega su llave.
export function mismoDuenoDePedido(
  fila: { alumno_nombre?: string | null; familias?: any },
  datos: { email: unknown; telefono: unknown; nombre: unknown; alumno: unknown }
): boolean {
  const familia = Array.isArray(fila?.familias) ? fila.familias[0] : fila?.familias;
  const alumnoFila = normalizarNombrePorPalabras(fila?.alumno_nombre);
  if (!alumnoFila || alumnoFila !== normalizarNombrePorPalabras(datos.alumno)) return false;
  // Igual que al registrar: un email sin "@" no se guarda, así que tampoco cuenta acá.
  const emailValido = (valor: unknown) => {
    const email = String(valor || '').trim().toLowerCase().slice(0, 200);
    return email.includes('@') ? email : '';
  };
  const emailFila = emailValido(familia?.email);
  const emailNuevo = emailValido(datos.email);
  if (emailFila || emailNuevo) return Boolean(emailFila) && emailFila === emailNuevo;
  const telFila = String(familia?.whatsapp || '').replace(/\D/g, '');
  const telNuevo = String(datos.telefono || '').replace(/\D/g, '');
  return telFila.length >= 6 && telFila === telNuevo && normalizarNombrePorPalabras(familia?.nombre) === normalizarNombrePorPalabras(datos.nombre);
}

// Auditoría 03/10 (alto 8): chicos del pedido que YA tienen un kit pagado (no mejora a impreso) en
// el mismo colegio y curso. Mismo criterio de identificación que el resto del sistema (colegio +
// código de curso + nombre normalizado por palabras). Devuelve los nombres tal como los escribió
// la familia, sin repetir.
export async function alumnosConKitPagado(
  supabase: SupabaseClient,
  chicos: { colegioId: string; cursoCodigo: string; alumnoNombre: string }[],
  excluirIds: string[] = []
): Promise<string[]> {
  const encontrados: string[] = [];
  const porCurso = new Map<string, { colegioId: string; cursoCodigo: string; nombres: string[] }>();
  for (const c of chicos) {
    if (!c.colegioId || !c.cursoCodigo || !normalizarNombrePorPalabras(c.alumnoNombre)) continue;
    const clave = `${c.colegioId}|${c.cursoCodigo}`;
    const grupo = porCurso.get(clave) || { colegioId: c.colegioId, cursoCodigo: c.cursoCodigo, nombres: [] };
    grupo.nombres.push(c.alumnoNombre);
    porCurso.set(clave, grupo);
  }
  for (const grupo of porCurso.values()) {
    const { data, error } = await supabase
      .from('pedidos')
      .select('id, alumno_nombre')
      .eq('colegio_id', grupo.colegioId)
      .eq('curso_codigo', grupo.cursoCodigo)
      .in('estado', ['pagado', 'entregado'])
      .is('mejora_de_pedido_id', null)
      .neq('tipo_kit', 'fotos_extra') // 29/10: un pedido de fotos extra no es un kit
      // Auditoría 03/10 (2ª vuelta): los archivados (conservados por el cierre de temporada) son de
      // un año anterior: no cuentan como "ya tiene un kit pagado".
      .eq('archivado', false)
      .limit(2000);
    if (error) throw error;
    const pagados = new Set((data || []).filter((p: any) => !excluirIds.includes(String(p.id))).map((p: any) => normalizarNombrePorPalabras(p.alumno_nombre)));
    for (const nombre of grupo.nombres) {
      if (pagados.has(normalizarNombrePorPalabras(nombre)) && !encontrados.includes(nombre)) encontrados.push(nombre);
    }
  }
  return encontrados;
}

export function respuestaKitYaPagado(alumnos: string[]) {
  const lista = alumnos.join(', ');
  return {
    success: false,
    codigo: 'KIT_YA_PAGADO',
    error: alumnos.length > 1
      ? `${lista} ya tienen un kit pagado. Si igual querés comprar otro kit, confirmalo y seguimos; si no, revisá tus pedidos en "Consultar Mi Pedido".`
      : `${lista} ya tiene un kit pagado. Si igual querés comprar otro kit, confirmalo y seguimos; si no, revisá tu pedido en "Consultar Mi Pedido".`,
    alumnos,
  };
}

async function montoCubrePedidos(supabase: SupabaseClient, columna: 'id' | 'grupo_pago_id', valor: string, montoPagado: number): Promise<boolean> {
  const { data, error } = await supabase.from('pedidos').select('total').eq(columna, valor).in('estado', ESTADOS_COBRABLES).eq('cancelado_definitivo', false);
  // Auditoría 03/10 noche (P7): si la lectura falla, NO se da el pago por bueno (antes devolvía true
  // y el update siguiente marcaba pagado sin controlar el monto). El webhook responde error y la
  // pasarela reintenta; la conciliación también lo vuelve a probar.
  if (error) throw error;
  if (!data || data.length === 0) return true; // nada pendiente con esa referencia: el update posterior no toca nada
  const esperado = data.reduce((acc: number, p: any) => acc + (Number(p.total) || 0), 0);
  if (!Number.isFinite(montoPagado)) {
    await registrarAlertaPago(supabase, `monto-ilegible:${valor}`, `No se pudo leer el monto cobrado para ${columna}=${valor} (vale $${esperado}). No se marcó como pagado: verificá el pago en la pasarela y aprobalo a mano si corresponde.`, { referencia: valor, esperado });
    return false;
  }
  if (montoPagado + 1 < esperado) {
    await registrarAlertaPago(supabase, `monto-insuficiente:${valor}`, `Pago con monto insuficiente para ${columna}=${valor}: se cobró $${montoPagado} y el pedido vale $${esperado}. No se marcó como pagado — revisar a mano (¿reembolso o diferencia?).`, { referencia: valor, esperado, montoPagado });
    return false;
  }
  // Auditoría 03/10 (altos 9 y 10): se cobró MÁS de lo que valen los pedidos que siguen vivos (p. ej.
  // el link de un carrito se pagó después de cancelar a un hermano): se marca lo que corresponde y
  // queda aviso para devolver la diferencia.
  if (montoPagado > esperado + 1) {
    await registrarAlertaPago(supabase, `monto-sobrante:${valor}`, `Pago con SOBRANTE para ${columna}=${valor}: se cobró $${montoPagado} y los pedidos activos valen $${esperado}. Devolvé la diferencia ($${montoPagado - esperado}).`, { referencia: valor, esperado, montoPagado });
  }
  return true;
}

/**
 * Marca como pagados los pedidos de una referencia de pago (UUID de un pedido suelto, o
 * grupo_pago_id de un carrito multi-hijo), sólo si el monto cobrado alcanza, y devuelve SOLO las
 * filas que pasaron a "pagado" en esta llamada (con los datos de la familia para el correo).
 * Idempotente: un segundo llamado con la misma referencia devuelve [] y no hace nada.
 * Auditoría 2026-09-26 (A1/M1): un mismo id de pago de la pasarela no puede pagar dos pedidos
 * distintos (se rechaza y queda alerta), y si llega un pago aprobado DISTINTO para un pedido que
 * ya estaba pagado (pago doble: MP + Nave, o MP después de aprobar la transferencia), queda una
 * alerta para reembolsarlo.
 */
export async function marcarReferenciaComoPagada(
  supabase: SupabaseClient,
  referencia: string,
  montoPagado: number,
  extras: Record<string, any>
): Promise<any[]> {
  // Auditoría 03/10: los pagos del módulo de eventos (referencia "ev:...") los procesa su propio
  // webhook; si llegan acá (webhook general de la cuenta) no son pagos huérfanos de la escuela.
  if (String(referencia).startsWith('ev:')) return [];
  const { data: individual, error: errorIndividual } = await supabase.from('pedidos').select('id').eq('id', referencia).limit(1);
  if (errorIndividual) throw errorIndividual;
  const columna: 'id' | 'grupo_pago_id' = individual && individual.length > 0 ? 'id' : 'grupo_pago_id';
  // Auditoría 03/10 noche (M1): una referencia que es a la vez el id de un pedido y el grupo de pago
  // de OTROS pedidos es ambigua (un id elegido igual al grupo de otra familia): no se marca nada.
  if (columna === 'id') {
    const { data: tambienGrupo, error: errorGrupo } = await supabase.from('pedidos').select('id').eq('grupo_pago_id', referencia).neq('id', referencia).limit(1);
    if (errorGrupo) throw errorGrupo;
    if (tambienGrupo && tambienGrupo.length > 0) {
      await registrarAlertaPago(supabase, `referencia-ambigua:${referencia}`, `La referencia de pago ${referencia} coincide con un pedido Y con el grupo de pago de otros pedidos. No se marcó nada: revisá a quién corresponde el pago y aprobalo a mano.`, { referencia, ...extras });
      return [];
    }
  }

  const columnaPago = extras.mp_payment_id ? 'mp_payment_id' : extras.nave_payment_id ? 'nave_payment_id' : null;
  const idPago = columnaPago ? String(extras[columnaPago]) : null;
  if (columnaPago && idPago) {
    const { data: usadoPor } = await supabase
      .from('pedidos')
      .select('id, grupo_pago_id')
      .eq(columnaPago, idPago)
      .limit(20);
    const ajenos = (usadoPor || []).filter((p: any) => p.id !== referencia && p.grupo_pago_id !== referencia);
    if (ajenos.length > 0) {
      await registrarAlertaPago(supabase, `pago-reusado:${idPago}`, `El pago ${idPago} (${columnaPago}) ya está asignado a otro pedido y se intentó usar para ${referencia}. No se marcó como pagado.`, { referencia, idPago, pedidosQueYaLoTienen: ajenos.map((p: any) => p.id) });
      return [];
    }
  }

  if (!(await montoCubrePedidos(supabase, columna, referencia, montoPagado))) return [];

  // Auditoría 05/10 (bajo): el medio con el que se cobró de verdad (la familia pudo cambiar de Nave a
  // Mercado Pago, o pagar el link viejo después de pasar a transferencia). Antes quedaba el elegido
  // al crear el pedido y el reporte de comisiones/el panel lo mostraban mal.
  const metodoReal = extras.mp_payment_id ? 'mercadopago' : extras.nave_payment_id ? 'nave' : null;
  const { data, error } = await supabase
    .from('pedidos')
    .update({ estado: 'pagado', ...(metodoReal ? { metodo_pago: metodoReal } : {}), ...extras, updated_at: new Date().toISOString() })
    .eq(columna, referencia)
    .in('estado', ESTADOS_COBRABLES)
    .eq('cancelado_definitivo', false)
    .select('*, familias(nombre, whatsapp, email)');
  if (error) {
    console.error(`[Pagos] Error al marcar pagada la referencia ${referencia}:`, error);
    return [];
  }
  if (!data || data.length === 0) {
    // ¿Pago doble? La referencia ya estaba pagada, pero con OTRO id de pago (o sin id de pasarela:
    // transferencia/efectivo aprobados a mano) — la familia pagó dos veces.
    if (columnaPago && idPago) {
      const { data: filasRef, error: errorFilasRef } = await supabase
        .from('pedidos')
        .select('id, pedido_friendly_id, estado, metodo_pago, mp_payment_id, nave_payment_id, total, cancelado_definitivo')
        .eq(columna, referencia);
      const yaPagadas = (filasRef || []).filter((p: any) => p.estado === 'pagado' || p.estado === 'entregado');
      const conOtroPago = yaPagadas.filter((p: any) => String(p[columnaPago] || '') !== idPago);
      if (conOtroPago.length > 0) {
        await registrarAlertaPago(supabase, `pago-doble:${idPago}`, `Posible PAGO DOBLE: llegó el pago aprobado ${idPago} (${columnaPago}) para ${conOtroPago.map((p: any) => p.pedido_friendly_id || p.id).join(', ')}, que ya estaba pagado por otro medio. Revisá y reembolsá el pago que sobra.`, { referencia, idPago, pedidos: conOtroPago });
      } else if (!errorFilasRef && yaPagadas.length === 0 && !(filasRef || []).some((p: any) => String(p[columnaPago] || '') === idPago)) {
        // Auditoría 03/10 (alto 9): pago aprobado que no puede marcar ninguna fila (pedido borrado,
        // cancelado por el fotógrafo / arrepentimiento, reserva reemplazada, cierre de temporada).
        // Antes pasaba sin aviso y la familia pagaba sin recibir nada. (Si las filas ya tienen ESTE
        // mismo pago, es un reembolso/contracargo ya registrado: no se avisa de nuevo.)
        await registrarAlertaPago(
          supabase,
          `pago-huerfano:${idPago}`,
          (filasRef || []).length === 0
            ? `PAGO SIN PEDIDO: llegó el pago aprobado ${idPago} (${columnaPago}) por $${montoPagado} para la referencia ${referencia}, que no existe (¿pedido borrado o cierre de temporada?). Devolvé el dinero o registrá el pedido a mano.`
            : `PAGO DE UN PEDIDO CANCELADO: llegó el pago aprobado ${idPago} (${columnaPago}) por $${montoPagado} para ${(filasRef || []).map((p: any) => p.pedido_friendly_id || p.id).join(', ')}, que está cancelado y no se puede marcar como pagado. Devolvé el dinero o reactivá el pedido a mano.`,
          { referencia, idPago, montoPagado, pedidos: filasRef || [] }
        );
      }
    }
    console.log(`[Pagos] Referencia ${referencia}: nada para actualizar (no existe, ya estaba pagada o está cancelada).`);
  } else {
    // 14/10/2026: se cobró por la pasarela un pedido que ya tenía el comprobante de una transferencia
    // subido: casi seguro la familia pagó dos veces. Queda alerta para revisar el banco y devolver uno.
    const conComprobante = metodoReal ? (data as any[]).filter((f: any) => f.comprobante_subido_at) : [];
    if (conComprobante.length > 0) {
      await registrarAlertaPago(supabase, `pago-doble-transferencia:${referencia}`, `Posible PAGO DOBLE: ${conComprobante.map((f: any) => f.pedido_friendly_id || f.id).join(', ')} se pagó con ${metodoReal === 'mercadopago' ? 'Mercado Pago' : 'Nave'} pero ya tenía subido el comprobante de una transferencia. Revisá el banco y devolvé el pago que sobra.`, { referencia, metodoReal, idPago, pedidos: conComprobante.map((f: any) => f.id) });
    }
    // Auditoría 03/10 (alto 8): mamá y papá pagando a la vez (o una reserva con link vivo más un
    // pedido normal) terminan con dos kits pagados del mismo chico. Al crear el pedido se avisa,
    // pero dos compras simultáneas pasan las dos: acá queda la alerta para devolver una.
    try {
      for (const fila of data as any[]) {
        if (esPedidoAdicional(fila)) continue; // 29/10: + fotos extra
        const otros = await alumnosConKitPagado(supabase, [{ colegioId: fila.colegio_id, cursoCodigo: fila.curso_codigo, alumnoNombre: fila.alumno_nombre }], (data as any[]).map((f: any) => String(f.id)));
        if (otros.length > 0) {
          await registrarAlertaPago(supabase, `kit-duplicado:${fila.id}`, `Posible KIT DUPLICADO: ${fila.alumno_nombre} (${fila.colegio_nombre || fila.colegio_id}, ${fila.curso_codigo}) ya tenía otro kit pagado y ahora se pagó ${fila.pedido_friendly_id || fila.id}. Si no fue a propósito, devolvé uno de los dos.`, { pedido: fila.id, referencia });
        }
      }
    } catch (err) {
      console.warn('[Pagos] No se pudo revisar si había un kit duplicado:', err);
    }
  }
  return data || [];
}
