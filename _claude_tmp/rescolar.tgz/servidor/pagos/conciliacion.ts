// Conciliación con las pasarelas (`conciliarPagoPendiente`): reconsulta a Mercado Pago / Nave un
// pedido con link de pago, con freno de 30 s por referencia; y `guardarIntencionNave` (división de
// server.ts, etapa 6, 10/10/2026). El código es el mismo que estaba en server.ts: sólo se movió.
import type { SupabaseClient } from '@supabase/supabase-js';
import { Payment } from 'mercadopago';
import { leerMontoNave } from '../comisionesCobro.js';
import { procesarPedidosRecienPagados } from '../entrega/pedidosPagados.js';
import { registrarAlertaPago } from '../nucleo/alertas.js';
import { fetchNave, getMercadoPagoConfig, getNaveUrls, naveHabilitado, obtenerNaveAccessToken } from '../nucleo/clientes.js';
import { tocaTurnoDistribuido } from '../nucleo/limites.js';
import { estadoPagoNave, intencionNaveRevertida, marcarReferenciaComoPagada } from './cobros.js';

// Auditoría 2026-09-26 (B1): el portal consulta /status cada ~10 s mientras la familia espera, y
// cada consulta le preguntaba a Mercado Pago / Nave. Con cientos de familias a la vez eso choca
// con los límites de las pasarelas. Se consulta a la pasarela como mucho cada 30 s por referencia
// (el control automático cada 10 minutos fuerza la consulta igual).
const ultimaConsultaPasarela = new Map<string, number>();
setInterval(() => {
  const limite = Date.now() - 10 * 60 * 1000;
  for (const [clave, ts] of ultimaConsultaPasarela.entries()) if (ts < limite) ultimaConsultaPasarela.delete(clave);
}, 5 * 60 * 1000).unref?.();

// Respaldo de pagos (Nave y Mercado Pago): si un pedido sigue "pendiente_pago" (o "cancelado") pero
// ya se generó un link de pago, se reconsulta directo a la pasarela y se autocorrige (marcar
// pagado + .zip + correo, o cancelado). Lo usan /api/pedidos/:id/status (mientras la familia mira
// la pantalla) y el control automático /api/cron/conciliar-pagos (cada 10 minutos, aunque nadie
// tenga la web abierta). Devuelve el estado final del pedido.
//
// Auditoría 2026-09-26:
//  - C3: Nave ya no pasa monto NaN (que salteaba el control): se lee el monto real de la intención.
//  - M3: se revisa CADA pasarela en la que hubo un intento (mp_preference_id / nave_payment_request_id),
//    aunque la familia después haya cambiado de medio de pago: si terminó pagando el link viejo,
//    el pago igual se registra. Pero sólo se CANCELA por un rechazo si el pedido sigue siendo de
//    esa pasarela (un rechazo viejo de MP no anula un pedido que ahora es por transferencia).
/**
 * Auditoría 03/10 noche (M3): cada intención nueva de Nave pisaba el id de la anterior, y la
 * conciliación sólo miraba la última: si la familia pagaba una intención anterior y se perdía el
 * aviso de Nave, ese pago no se veía nunca (y al vencer la última, el pedido se cancelaba). Ahora la
 * anterior queda en nave_intenciones_previas (hasta 5) y la conciliación las revisa todas.
 */
export async function guardarIntencionNave(supabase: SupabaseClient, ids: string[], nuevaIntencion: string) {
  const idsValidos = ids.filter(Boolean);
  if (idsValidos.length === 0 || !nuevaIntencion) return;
  const { data: filas, error: errorFilas } = await supabase.from('pedidos').select('id, nave_payment_request_id, nave_intenciones_previas').in('id', idsValidos);
  const ahora = new Date().toISOString();
  if (errorFilas) {
    // Sin poder leer las anteriores, al menos se guarda la nueva (sin borrar la lista existente).
    await supabase.from('pedidos').update({ nave_payment_request_id: nuevaIntencion, link_pago_at: ahora }).in('id', idsValidos);
    return;
  }
  for (const id of idsValidos) {
    const fila: any = (filas || []).find((f: any) => f.id === id);
    const previas = [fila?.nave_payment_request_id, ...(Array.isArray(fila?.nave_intenciones_previas) ? fila.nave_intenciones_previas : [])]
      .map((x: unknown) => String(x || ''))
      .filter((x: string) => x && x !== nuevaIntencion);
    const unicas = Array.from(new Set(previas)).slice(0, 5);
    await supabase.from('pedidos').update({ nave_payment_request_id: nuevaIntencion, nave_intenciones_previas: unicas, link_pago_at: ahora }).eq('id', id);
  }
}

export async function conciliarPagoPendiente(supabase: SupabaseClient, data: any, opciones: { forzar?: boolean; hastaMs?: number } = {}): Promise<string> {
  let estadoFinal: string = data.estado;
  const esRevisable = (estado: string) => estado === 'pendiente_pago' || estado === 'cancelado';
  if (!esRevisable(estadoFinal)) return estadoFinal;
  const referencia: string = data.grupo_pago_id || data.id;
  if (!opciones.forzar) {
    const ultima = ultimaConsultaPasarela.get(referencia);
    if (ultima && Date.now() - ultima < 30000) return estadoFinal;
    // Auditoría 03/10 (alto 14): el freno en memoria vale por instancia (con muchas instancias de
    // Vercel cada encuesta de cada familia pegaba contra Mercado Pago y Nave). Ahora además hay un
    // freno distribuido: como mucho una consulta a la pasarela cada 30 s por pedido; si no toca, se
    // responde con el estado de la base.
    ultimaConsultaPasarela.set(referencia, Date.now());
    if (!(await tocaTurnoDistribuido(`pasarela:${referencia}`, 30))) return estadoFinal;
  }
  ultimaConsultaPasarela.set(referencia, Date.now());
  const columnaReferencia: 'id' | 'grupo_pago_id' = data.grupo_pago_id ? 'grupo_pago_id' : 'id';
  const releerEstado = async () => {
    const { data: releido } = await supabase.from('pedidos').select('estado').eq('id', data.id).maybeSingle();
    return releido?.estado || estadoFinal;
  };

  // Nave no firma sus webhooks y la propia documentación recomienda esta consulta activa como
  // respaldo ("Consultar una intención de pago... alternativa cuando la notificación no se recibe").
  const intencionesNave = Array.from(
    new Set(
      [data.nave_payment_request_id, ...(Array.isArray(data.nave_intenciones_previas) ? data.nave_intenciones_previas : [])]
        .map((x: unknown) => String(x || ''))
        .filter(Boolean)
    )
  ).slice(0, 6);
  if (intencionesNave.length > 0 && naveHabilitado()) {
    try {
      const accessToken = await obtenerNaveAccessToken();
      if (accessToken) {
        const { intenciones } = getNaveUrls();
        const ESTADOS_FINALES_FALLIDOS = ['FAILURE_PROCESSED', 'EXPIRED', 'BLOCKED'];
        let ultimaFallida = false; // la intención vigente (la primera) terminó sin pagar
        let otraViva = false; // alguna anterior sigue abierta o no se pudo consultar
        for (let i = 0; i < intencionesNave.length; i++) {
          if (!esRevisable(estadoFinal)) break;
          // Revisión 03/10 noche: dentro del presupuesto de tiempo de quien llama (cron).
          if (opciones.hastaMs && Date.now() > opciones.hastaMs) {
            otraViva = true;
            break;
          }
          const resp = await fetchNave(`${intenciones}/${encodeURIComponent(intencionesNave[i])}`, {
            headers: { Authorization: `Bearer ${accessToken}` },
          });
          const intencion: any = await resp.json().catch(() => null);
          const estadoIntencion = estadoPagoNave(intencion);
          const intentosNave: any[] = Array.isArray(intencion?.payment_attempts?.payments) ? intencion.payment_attempts.payments : [];
          const pagoAprobado = intentosNave.find((p: any) => estadoPagoNave(p) === 'APPROVED');
          // Revisión 03/10 noche: el nombre del campo del id no está documentado: se prueban los habituales.
          const idPagoAprobado = pagoAprobado ? String(pagoAprobado.payment_id || pagoAprobado.id || pagoAprobado.payment?.id || pagoAprobado.transaction_id || '') : '';
          // Auditoría 03/10 (alto 11): una intención "procesada" cuyo pago fue reembolsado / revertido /
          // contracargado no se vuelve a dar por pagada. Sólo cuenta un estado de reversión EXPLÍCITO:
          // un intento con estado desconocido o con otro formato no bloquea una aprobación real.
          const intencionRevertida = intencionNaveRevertida(intentosNave);
          if (resp.ok && estadoIntencion === 'SUCCESS_PROCESSED' && !intencionRevertida) {
            // Auditoría 03/10 noche (M4): sin el id del pago no se marca (si no, un reembolso o
            // contracargo posterior no encontraba la fila y el pedido seguía pagado). Queda alerta y
            // el webhook APPROVED de Nave lo completa.
            if (!idPagoAprobado) {
              await registrarAlertaPago(supabase, `nave-sin-id-pago:${referencia}`, `Nave da por procesada la intención ${intencionesNave[i]} (referencia ${referencia}) pero no informa el id del pago. No se marcó como pagado: verificalo en el portal de Nave y aprobalo a mano si corresponde.`, { referencia, intencion: intencionesNave[i] });
              otraViva = true;
              continue;
            }
            const montoCobrado = Number.isFinite(leerMontoNave(pagoAprobado)) ? leerMontoNave(pagoAprobado) : leerMontoNave(intencion);
            const filasPagadas = await marcarReferenciaComoPagada(supabase, referencia, montoCobrado, { nave_payment_id: idPagoAprobado });
            await procesarPedidosRecienPagados(supabase, filasPagadas);
            estadoFinal = await releerEstado();
          } else if (resp.ok && ESTADOS_FINALES_FALLIDOS.includes(estadoIntencion)) {
            if (i === 0) ultimaFallida = true;
          } else if (i > 0) {
            otraViva = true;
          }
        }
        if (
          ultimaFallida &&
          !otraViva &&
          esRevisable(estadoFinal) &&
          data.estado === 'pendiente_pago' &&
          data.metodo_pago === 'nave'
        ) {
          await supabase
            .from('pedidos')
            .update({ estado: 'cancelado', updated_at: new Date().toISOString() })
            .eq(columnaReferencia, referencia)
            .eq('metodo_pago', 'nave')
            .eq('estado', 'pendiente_pago');
          estadoFinal = await releerEstado();
        }
      }
    } catch (errNave) {
      console.warn('[Nave] No se pudo reconsultar la intención de pago como respaldo:', errNave);
    }
  }

  // Mercado Pago SÍ firma sus webhooks, pero un webhook igual puede perderse. Se busca por
  // external_reference (el id del pedido, o el grupo_pago_id si es un carrito multi-hijo).
  if (esRevisable(estadoFinal) && data.mp_preference_id) {
    try {
      const mpConfig = getMercadoPagoConfig();
      if (mpConfig) {
        const resultadoBusqueda = await new Payment(mpConfig).search({
          options: { external_reference: referencia, sort: 'date_created', criteria: 'desc' },
          requestOptions: { timeout: 8000, maxRetries: 1 },
        });
        const pagos = resultadoBusqueda?.results || [];
        const pagoAprobado = pagos.find((p) => p.status === 'approved');
        // Sólo cuenta el intento MÁS RECIENTE para cancelar, y nunca si hay otro intento todavía en
        // curso (ej. pago en efectivo en Rapipago/Pago Fácil, que queda "pending" hasta acreditarse).
        const ultimoPago = pagos[0];
        const hayPagoEnCurso = pagos.some((p) => p.status === 'pending' || p.status === 'in_process' || p.status === 'authorized');
        const pagoRechazado = !hayPagoEnCurso && ultimoPago && (ultimoPago.status === 'rejected' || ultimoPago.status === 'cancelled') ? ultimoPago : undefined;
        if (pagoAprobado) {
          const filasPagadas = await marcarReferenciaComoPagada(
            supabase,
            referencia,
            Number(pagoAprobado.transaction_amount),
            pagoAprobado.id ? { mp_payment_id: String(pagoAprobado.id) } : {}
          );
          await procesarPedidosRecienPagados(supabase, filasPagadas, pagoAprobado.payer?.email);
          estadoFinal = await releerEstado();
        } else if (pagoRechazado && estadoFinal === 'pendiente_pago' && data.metodo_pago === 'mercadopago') {
          await supabase
            .from('pedidos')
            .update({ estado: 'cancelado', updated_at: new Date().toISOString() })
            .eq(columnaReferencia, referencia)
            .eq('metodo_pago', 'mercadopago')
            .eq('estado', 'pendiente_pago') // Auditoría 08/10 (M6): antes .neq('pagado') también cancelaba 'entregado'
            .eq('cancelado_definitivo', false);
          estadoFinal = 'cancelado';
        }
      }
    } catch (errMp) {
      console.warn('[Mercado Pago] No se pudo reconsultar el pago como respaldo:', errMp);
    }
  }
  return estadoFinal;
}
