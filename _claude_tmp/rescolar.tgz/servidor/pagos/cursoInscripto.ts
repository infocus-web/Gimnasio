// 14/10/2026 (caso Noguera Cabral): el portal guarda en el navegador la familia con la que se entró la última
// vez, código incluido. A Adriana le corregimos el curso (6° A → 6° B) el 13/10 y su código cambió; la mamá
// abrió el portal con la sesión vieja y pagó un kit en 6° A con el código viejo (que sigue siendo un código
// válido: el de OTRO curso). El servidor sólo miraba que el código existiera. Ahora, antes de registrar un
// pedido o una reserva, se compara el curso de cada chico con el de su inscripción aprobada (mismo email y
// colegio, nombre compatible). Si el chico no aparece en ninguna inscripción de ese email, no se frena nada.
import type { SupabaseClient } from '@supabase/supabase-js';
import { determinarCodigoCursoServidor } from '../nucleo/codigosCurso.js';
import { nombresCompatibles } from '../nucleo/nombres.js';

export type ItemCurso = { colegioId: string; cursoCodigo: string; alumnoNombre: string };

/** Chicos (principal + hermanos) de las inscripciones aprobadas de un email, con su curso actual. */
async function chicosInscriptos(supabase: SupabaseClient, email: string) {
  const limpio = String(email || '').trim().toLowerCase();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(limpio)) return [];
  const patron = limpio.replace(/[%_\\]/g, (c) => `\\${c}`).replace(/\*/g, ''); // FAM-3: PostgREST toma «*» como «%»
  const { data, error } = await supabase
    .from('inscripciones')
    .select('colegio_id, alumno_nombre, alumno_apellido, grado, turno, division, hermanos')
    .eq('estado', 'aceptado')
    .ilike('email', patron);
  if (error) throw error;
  const chicos: { nombre: string; colegioId: string; grado: string; turno: string; division: string }[] = [];
  for (const insc of data || []) {
    chicos.push({ nombre: `${insc.alumno_nombre || ''} ${insc.alumno_apellido || ''}`.trim(), colegioId: String(insc.colegio_id || ''), grado: insc.grado, turno: insc.turno, division: insc.division });
    for (const h of Array.isArray(insc.hermanos) ? insc.hermanos : []) {
      if (!h || typeof h !== 'object') continue;
      chicos.push({
        nombre: `${h.alumnoNombre || h.alumno_nombre || ''} ${h.alumnoApellido || h.alumno_apellido || ''}`.trim(),
        colegioId: String(h.colegioId || insc.colegio_id || ''),
        grado: h.grado,
        turno: h.turno,
        division: h.division,
      });
    }
  }
  return chicos.filter((c) => c.nombre && c.grado);
}

/**
 * El primer chico del pedido cuyo curso no es el de su inscripción actual (con el curso inscripto), o null.
 * Si el chico figura en varias inscripciones del mismo email, alcanza con que una coincida.
 */
export async function cursoDistintoAlInscripto(
  supabase: SupabaseClient,
  email: unknown,
  items: ItemCurso[]
): Promise<{ alumno: string; curso: string } | null> {
  const chicos = await chicosInscriptos(supabase, String(email || ''));
  if (chicos.length === 0) return null;
  for (const item of items) {
    const suyos = chicos.filter((c) => c.colegioId === String(item.colegioId) && nombresCompatibles(c.nombre, item.alumnoNombre));
    if (suyos.length === 0) continue;
    const coincide = suyos.some((c) => determinarCodigoCursoServidor(String(c.grado || ''), String(c.turno || ''), String(c.division || '')) === item.cursoCodigo);
    if (!coincide) {
      const c = suyos[0];
      return { alumno: item.alumnoNombre, curso: `${c.grado} "${c.division}"${c.turno ? ` ${c.turno}` : ''}` };
    }
  }
  return null;
}

/** Respuesta 409 para el portal: tiene que volver a entrar con el código nuevo. */
export function respuestaCursoCambiado(distinto: { alumno: string; curso: string }) {
  return {
    success: false,
    codigo: 'CURSO_CAMBIADO',
    error: `El curso de ${distinto.alumno} cambió: ahora figura en ${distinto.curso} y su código de acceso es otro. Cerrá sesión y volvé a ingresar con el código nuevo que te mandamos por email (si no lo encontrás, pedilo en «¿Ya te inscribiste? Consultar código»). No se registró ningún pago.`,
  };
}
