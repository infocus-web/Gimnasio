// 26/10/2026 (Pablo): «para la elección de la foto digital no puse límite de tiempo»; las fotos del KIT IMPRESO se
// eligen hasta el 15/11/2026 inclusive (hora de Argentina), para que entren en la impresión. Después de esa fecha
// no se puede comprar un Kit Impreso, ni confirmar las fotos de uno pagado por adelantado, ni pasar de digital a
// impreso. El Solo Digital sigue sin límite. Debe coincidir con src/utils/plazoKitImpreso.ts.
// 30/10/2026: la fecha se edita desde el panel → Configuración (servidor/nucleo/plazosTemporada.ts).
import type { NextFunction, Request, Response } from 'express';
import { getServerSupabase } from '../nucleo/clientes.js';
import { asegurarPlazosActualizados, conPlazosActualizados, finDelDia, plazosVigentes, textoFechaLarga } from '../nucleo/plazosTemporada.js';

export function errorPlazoKitImpreso(): string {
  return `El plazo para elegir las fotos del Kit Impreso terminó el ${textoFechaLarga(plazosVigentes().kitImpreso)}. Podés elegir el kit Solo Digital (sin límite de tiempo) o, si ya pagaste el Kit Impreso, escribinos desde «Consultas».`;
}

export function plazoKitImpresoAbierto(ahora: Date = new Date()): boolean {
  return ahora.getTime() <= finDelDia(plazosVigentes().kitImpreso);
}

const esKitImpreso = (kitId: unknown) => {
  const k = String(kitId || '');
  return Boolean(k) && k !== 'kit-digital' && k !== 'kit-evento-suelto';
};

const rechazar = (res: Response) => res.status(410).json({ success: false, codigo: 'PLAZO_KIT_IMPRESO', error: errorPlazoKitImpreso() });

/** Compra o reserva nueva (`kitId` o `items[].kitId`): frena el Kit Impreso pasado el plazo. */
export function exigirPlazoKitImpreso(req: Request, res: Response, next: NextFunction) {
  conPlazosActualizados(() => {
    if (plazoKitImpresoAbierto()) return next();
    const items: any[] = Array.isArray(req.body?.items) ? req.body.items : [];
    const kits = [req.body?.kitId, ...items.map((it) => it?.kitId)];
    return kits.some(esKitImpreso) ? rechazar(res) : next();
  });
}

/** Pasar de Solo Digital a Kit Impreso: no se puede pasado el plazo. */
export function exigirPlazoMejoraImpreso(_req: Request, res: Response, next: NextFunction) {
  conPlazosActualizados(() => (plazoKitImpresoAbierto() ? next() : rechazar(res)));
}

/** Confirmar las fotos de una reserva pagada (`/api/reservas/:id/elegir-fotos`): si es Kit Impreso, pasado el plazo no. */
export async function exigirPlazoReservaImpreso(req: Request, res: Response, next: NextFunction) {
  await asegurarPlazosActualizados();
  if (plazoKitImpresoAbierto()) return next();
  try {
    const supabase = getServerSupabase();
    if (!supabase) return next(); // la ruta responde el error de servicio
    const { data } = await supabase.from('pedidos').select('tipo_kit').eq('id', String(req.params.id || '')).maybeSingle();
    return data && data.tipo_kit !== 'solo_digital' ? rechazar(res) : next();
  } catch {
    return next();
  }
}
