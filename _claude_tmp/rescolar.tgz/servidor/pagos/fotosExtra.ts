// Fotos extra (29/10/2026, pedido de Pablo): una familia con el kit PAGADO compra copias impresas sueltas (15x21 o
// 20x30) de cualquier foto que ve en la galería. Es un pedido APARTE que apunta al kit (extras_de_pedido_id), con su
// propio cobro (Mercado Pago, igual que la mejora a Kit Impreso) y su propio lote en el laboratorio. Hasta el 15/11
// (como el Kit Impreso). Reglas y helpers en servidor/nucleo/fotosExtra.ts.
import express from 'express';
import type { NextFunction, Request, Response } from 'express';
import { hijosDeFamiliaConAcceso } from '../familias/inscripciones.js';
import { llaveRecibida, tokenAccesoPedido, tokenAccesoValido } from '../nucleo/accesoPedidos.js';
import { getServerSupabase } from '../nucleo/clientes.js';
import { buscarSeccionPorCodigoSecreto, determinarCodigoCursoServidor } from '../nucleo/codigosCurso.js';
import {
  itemsFotosExtra,
  metodoPagoAdicional,
  kitPuedeSumarFotosExtra,
  nombrePedidoFotosExtra,
  normalizarItemsFotosExtra,
  totalFotosExtra,
  TIPO_KIT_FOTOS_EXTRA,
  type ItemFotoExtra,
  type MetodoPagoAdicional,
} from '../nucleo/fotosExtra.js';
import { enviarAvisoTransferenciaRegistrada } from './avisoPedidoPendiente.js';
import { limitarFrecuencia, tocaTurnoDistribuido } from '../nucleo/limites.js';
import { ESTADOS_COBRABLES } from '../nucleo/pedidos.js';
import { exigirPreciosCargados, preciosFotosExtraActuales } from '../nucleo/precios.js';
import { asegurarFriendlyIdUnico, etiquetaEsDelAlumno, hijosQueSonElAlumno, insertarPedidosConReintento } from './crearPedido.js';
import { plazoKitImpresoAbierto } from './plazoKitImpreso.js';
import { conPlazosActualizados, plazosVigentes, textoFechaLarga } from '../nucleo/plazosTemporada.js';

const rutas = express.Router();
const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

export function errorPlazoFotosExtra(): string {
  return `El plazo para pedir fotos extra terminó el ${textoFechaLarga(plazosVigentes().kitImpreso)} (se imprimen junto con las entregas de esta temporada). Si necesitás algo, escribinos desde «Consultas».`;
}

/** Hasta la fecha límite del Kit Impreso inclusive (panel → Configuración; servidor/pagos/plazoKitImpreso.ts). */
export function exigirPlazoFotosExtra(_req: Request, res: Response, next: NextFunction) {
  conPlazosActualizados(() => {
    if (plazoKitImpresoAbierto()) return next();
    return res.status(410).json({ success: false, codigo: 'PLAZO_FOTOS_EXTRA', error: errorPlazoFotosExtra() });
  });
}

/**
 * 29/10/2026: un pedido adicional (fotos extra o mejora a impreso) sin pagar que se reutiliza con OTRO medio de pago.
 * Con el comprobante de una transferencia ya subido no se cambia (lo está revisando Pablo); una transferencia que
 * venció no se reabre desde acá (como en cambiar-metodo-pago). Devuelve un error para la familia o null si quedó bien.
 */
export async function ajustarMetodoPagoPendiente(supabase: any, fila: any, metodo: MetodoPagoAdicional): Promise<{ status: number; error: string } | null> {
  if (metodo === 'transferencia' && fila.transferencia_vencida_at) {
    return { status: 409, error: 'El plazo de la transferencia de este pedido venció. Elegí pagar con tarjeta o escribinos desde «Consultas».' };
  }
  if (fila.metodo_pago === metodo) return null;
  if (fila.comprobante_subido_at) {
    return { status: 409, error: 'Ya subiste el comprobante de la transferencia de este pedido: lo estamos revisando y te avisamos por email. No hace falta pagarlo de nuevo.' };
  }
  // Igual que cambiar-metodo-pago (aplicarMetodoPagoPendiente): vuelve a «pendiente de pago» con el medio nuevo.
  const { error } = await supabase
    .from('pedidos')
    .update({ metodo_pago: metodo, estado: 'pendiente_pago', updated_at: new Date().toISOString() })
    .eq('id', fila.id)
    .in('estado', ESTADOS_COBRABLES)
    .is('comprobante_subido_at', null);
  if (error) throw error;
  return null;
}

/** Misma lista de ítems (sin importar el orden). */
export function mismosItems(a: ItemFotoExtra[], b: ItemFotoExtra[]): boolean {
  const clave = (l: ItemFotoExtra[]) => l.map((it) => `${it.fotoId.toLowerCase()}|${it.tamano}|${it.cantidad}`).sort().join(',');
  return a.length === b.length && clave(a) === clave(b);
}

/**
 * Las fotos tienen que ser del curso del kit y estar publicadas. Una individual CON nombre sólo la compra la
 * familia de ese chico (misma regla que el kit, validarSeleccionFotos); sin nombre, cualquiera del curso.
 */
export async function validarFotosExtra(supabase: any, original: any, items: ItemFotoExtra[]): Promise<string | null> {
  const ids = [...new Set(items.map((it) => it.fotoId))];
  const { data: fotos, error } = await supabase
    .from('fotos')
    .select('id, categoria, alumno_nombre, colegio_id, codigo_curso, publicada_at')
    .in('id', ids);
  if (error) throw error;
  const porId = new Map<string, any>((fotos || []).map((f: any) => [String(f.id).toLowerCase(), f]));
  for (const id of ids) {
    const f = porId.get(id);
    if (!f || !f.publicada_at || String(f.colegio_id) !== String(original.colegio_id) || String(f.codigo_curso) !== String(original.curso_codigo)) {
      return 'Alguna de las fotos elegidas ya no está disponible. Volvé a abrir la galería y elegilas de nuevo.';
    }
  }
  const conNombre = [...porId.values()].filter((f: any) => f.categoria === 'individual' && f.alumno_nombre);
  if (conNombre.length === 0) return null;
  const { data: etiquetas, error: errEtiquetas } = await supabase
    .from('fotos')
    .select('alumno_nombre')
    .eq('colegio_id', original.colegio_id)
    .eq('codigo_curso', original.curso_codigo)
    .eq('categoria', 'individual')
    .not('alumno_nombre', 'is', null)
    .limit(2000);
  if (errEtiquetas) throw errEtiquetas;
  const etiquetasCurso = (etiquetas || []).map((f: any) => f.alumno_nombre);
  if (conNombre.some((f: any) => !etiquetaEsDelAlumno(f.alumno_nombre, original.alumno_nombre, etiquetasCurso))) {
    return `Alguna foto individual elegida es de otro alumno. Las fotos extra son de ${original.alumno_nombre || 'tu hijo/a'}.`;
  }
  return null;
}

rutas.post(
  '/api/pedidos/:id/fotos-extra',
  limitarFrecuencia('pedidos-fotos-extra', 60, 10 * 60 * 1000),
  exigirPreciosCargados,
  exigirPlazoFotosExtra,
  async (req: Request, res: Response) => {
    try {
      const pedidoId = String(req.params.id || '');
      if (!UUID_RE.test(pedidoId)) return res.status(400).json({ success: false, error: 'Pedido inválido.' });
      const supabase = getServerSupabase();
      if (!supabase) return res.status(503).json({ success: false, error: 'Servicio no disponible' });
      const seccion = await buscarSeccionPorCodigoSecreto(supabase, String(req.body?.codigo || '').slice(0, 40));
      if (!seccion) return res.status(403).json({ success: false, error: 'No pudimos validar tu acceso. Volvé a ingresar con tu código.' });
      const cursoCodigo = determinarCodigoCursoServidor(seccion.grado, seccion.turno, seccion.division);

      const { data: original, error } = await supabase.from('pedidos').select('*').eq('id', pedidoId).maybeSingle();
      if (error) throw error;
      if (!original || original.colegio_id !== seccion.colegioId || original.curso_codigo !== cursoCodigo) {
        return res.status(404).json({ success: false, error: 'No encontramos tu pedido.' });
      }
      // Igual que la mejora a impreso: hace falta la llave de la familia (el hijo ES el chico) o la del pedido.
      const hijosConLlave = await hijosDeFamiliaConAcceso(supabase, req.body?.familia, req.body?.acceso);
      const esDeLaFamilia = (await hijosQueSonElAlumno(supabase, req.body?.familia, hijosConLlave, original.alumno_nombre, seccion.colegioId, cursoCodigo)).length > 0;
      if (!esDeLaFamilia && !tokenAccesoValido(llaveRecibida(req), [original.id, original.grupo_pago_id])) {
        return res.status(403).json({ success: false, codigo: 'LLAVE_REQUERIDA', error: 'Para pedir fotos extra volvé a ingresar al portal con los datos de tu familia (DNI del tutor).' });
      }
      if (!kitPuedeSumarFotosExtra(original)) {
        return res.status(409).json({ success: false, error: 'Las fotos extra se piden sobre un kit ya pagado y con sus fotos elegidas.' });
      }

      const normalizados = normalizarItemsFotosExtra(req.body?.items);
      if ('error' in normalizados) return res.status(400).json({ success: false, error: normalizados.error });
      const items = normalizados.items;
      const errorFotos = await validarFotosExtra(supabase, original, items);
      if (errorFotos) return res.status(400).json({ success: false, error: errorFotos });
      const total = totalFotosExtra(items, preciosFotosExtraActuales());
      const metodo = metodoPagoAdicional(req.body?.metodoPago);

      // Si la familia vuelve de la pasarela sin pagar y pide lo mismo, se reutiliza ese pedido (no se duplica).
      const buscarPendientes = async () => {
        const { data, error: errPend } = await supabase
          .from('pedidos')
          .select('id, pedido_friendly_id, total, estado, fotos_seleccionadas, metodo_pago, comprobante_subido_at, transferencia_vencida_at')
          .eq('extras_de_pedido_id', original.id)
          .eq('cancelado_definitivo', false)
          .eq('estado', 'pendiente_pago');
        if (errPend) throw errPend;
        return ((data || []) as any[]).find((p) => Number(p.total) === total && mismosItems(itemsFotosExtra(p), items));
      };
      const responder = async (p: { id: string; pedido_friendly_id?: string | null }) => {
        // Por transferencia: el mail con los datos de la cuenta y el plazo de 48 h, igual que el kit.
        if (metodo === 'transferencia') await enviarAvisoTransferenciaRegistrada(supabase, 'id', p.id);
        return res.json({ success: true, pedidoId: p.id, pedidoFriendlyId: p.pedido_friendly_id || undefined, total, metodoPago: metodo, accesoToken: tokenAccesoPedido(p.id) });
      };
      const reutilizar = async (p: any) => {
        const problema = await ajustarMetodoPagoPendiente(supabase, p, metodo);
        if (problema) return res.status(problema.status).json({ success: false, error: problema.error });
        return responder(p);
      };
      const existente = await buscarPendientes();
      if (existente) return reutilizar(existente);
      // Dos toques seguidos (o dos pestañas) no crean dos pedidos.
      if (!(await tocaTurnoDistribuido(`fotos-extra:${original.id}`, 20))) {
        await new Promise((resolve) => setTimeout(resolve, 1500));
        const enCurso = await buscarPendientes();
        if (enCurso) return reutilizar(enCurso);
        return res.status(409).json({ success: false, error: 'Estamos preparando tu pedido de fotos extra. Probá de nuevo en unos segundos.' });
      }

      // Revisión 29/10: los pedidos viejos de este kit que quedaron SIN pagar (la familia volvió de la pasarela y
      // cambió la selección) se dan de baja, como hace la mejora a impreso: si no, el recordatorio de pago la invitaba
      // a pagar también el viejo (copias de más) y un pendiente viejo se podía pagar con precios viejos. Uno con el
      // comprobante de una transferencia subido no se toca. Si igual le llega un pago, queda la alerta «pago de un
      // pedido cancelado» para devolverlo (cobros.ts).
      const { error: errViejos } = await supabase
        .from('pedidos')
        .update({ estado: 'cancelado', cancelado_definitivo: true, updated_at: new Date().toISOString() })
        .eq('extras_de_pedido_id', original.id)
        .eq('cancelado_definitivo', false)
        .in('estado', ESTADOS_COBRABLES)
        .is('comprobante_subido_at', null);
      if (errViejos) throw errViejos;

      const fila: Record<string, any> = {
        familia_id: original.familia_id,
        alumno_id: original.alumno_id,
        evento_id: original.evento_id,
        tipo_kit: TIPO_KIT_FOTOS_EXTRA,
        estado: 'pendiente_pago',
        total,
        carpetas_impresas: 0,
        metodo_pago: metodo,
        pedido_friendly_id: await asegurarFriendlyIdUnico(supabase, '', new Set()),
        colegio_id: original.colegio_id,
        colegio_nombre: original.colegio_nombre,
        curso_codigo: original.curso_codigo,
        grado: original.grado,
        division: original.division,
        turno: original.turno,
        alumno_nombre: original.alumno_nombre,
        // Sin número de lista propio (el índice único es por pedido de kit); el lote usa el del kit original.
        alumno_numero_lista: null,
        codigo_alumno: original.codigo_alumno,
        kit_nombre: nombrePedidoFotosExtra(items),
        fotos_seleccionadas: { extras: items },
        copias_extras: {},
        link_descarga_hd: null,
        seleccion_pendiente: false,
        extras_de_pedido_id: original.id,
      };
      const { data: creada, error: errInsert } = await insertarPedidosConReintento(supabase, [fila], 'id, pedido_friendly_id');
      if (errInsert) throw errInsert;
      const nueva = creada?.[0];
      if (!nueva?.id) throw new Error('No se pudo registrar el pedido de fotos extra');
      return responder(nueva);
    } catch (err: any) {
      console.error('[Fotos extra] Error:', err);
      return res.status(500).json({ success: false, error: 'No pudimos preparar tu pedido de fotos extra. Intentá nuevamente.' });
    }
  }
);

export { rutas as rutasFotosExtra };
