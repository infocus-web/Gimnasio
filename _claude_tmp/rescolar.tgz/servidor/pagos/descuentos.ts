// Códigos de descuento (22/10/2026, pedido de Pablo: «ofrecer un código de descuento que yo desde el panel pueda
// generar y elegir qué porcentaje de descuento ofrecer»). Decisiones de Pablo: hasta 100% (sin cargo); sólo sobre
// el kit (carpetas extra y fotos sueltas se cobran completas); usos máximos y vencimiento los elige al crearlo;
// la comisión del colegio se calcula normal sobre lo cobrado y un pedido sin cargo no suma ni resta (se excluye en
// servidor/convenioLiquidacion.ts). El monto lo calcula SIEMPRE el servidor (crearPedido.ts usa `prepararDescuento`).
// Un pedido (o carrito) que queda en $0 nace pagado con metodo_pago 'bonificado'. Tabla `codigos_descuento` y
// columnas pedidos.codigo_descuento / descuento_pct / descuento_monto (migración 20261022200000).
import type { SupabaseClient } from '@supabase/supabase-js';
import crypto from 'crypto';
import express from 'express';
import type { Request, Response } from 'express';
import { requireAdminAuth } from '../nucleo/auth.js';
import { getServerSupabase } from '../nucleo/clientes.js';
import { hayCupoPorClave, limitarFrecuenciaPersistente } from '../nucleo/limites.js';
import { PRECIOS_KITS } from '../nucleo/precios.js';
import { traerTodasLasFilas } from '../nucleo/utilidades.js';
import { procesarPedidosRecienPagados } from '../entrega/pedidosPagados.js';

const rutas = express.Router();
const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const CODIGO_RE = /^[A-Z0-9-]{4,32}$/;
// 27/10: `ambito` = dónde vale el código: 'kit' (kit del colegio, como siempre) o 'eventos' (pedidos de eventos,
// ver eventos/descuentos.ts). Un código de eventos NO sirve en el kit y viceversa.
const COLUMNAS = 'id, created_at, codigo, porcentaje, usos_max, usos, vence_at, activo, nota, sin_tope_impreso, ambito';
export const AMBITOS_DESCUENTO = ['kit', 'eventos'] as const;
export const ERROR_DESCUENTO_INVALIDO = 'El código de descuento no es válido o ya no está disponible. Quitalo para seguir con la compra.';
const ERROR_DEMASIADOS_INTENTOS = 'Demasiados intentos con códigos. Esperá unos minutos o quitá el código para seguir.';
/** Revisión 22/10: un carrito no puede mezclar un kit que queda en $0 con otros que se pagan (ver crear-multiple). */
export const ERROR_DESCUENTO_COMBINADO = 'Con este código el kit queda sin cargo y no se puede pagar junto con otros kits, carpetas extra ni fotos sueltas. Hacé esa compra sola (sin extras ni otros chicos), o quitá el código para seguir.';

export const normalizarCodigoDescuento = (valor: unknown) => String(valor ?? '').trim().toUpperCase().replace(/\s+/g, '');

/** 22/10 (Pablo): «el 100% será sobre los archivos digitales; si quiere imprimir un kit, la bonificación será al 70%,
 * no quiero poner un peso de mi bolsillo». El kit digital acepta hasta 100%; los kits impresos, hasta 70%. */
// 27/10 (Pablo): «necesito crear un código al 100% en el kit impreso». Cada código puede venir marcado
// `sin_tope_impreso`: entonces el impreso también acepta hasta 100%. Los demás siguen con el tope.
export const TOPE_DESCUENTO_IMPRESO = 70;
export const porcentajeParaKit = (kitId: string, porcentaje: number, sinTopeImpreso = false) => Math.max(0, Math.min(kitId === 'kit-digital' || sinTopeImpreso ? 100 : TOPE_DESCUENTO_IMPRESO, porcentaje));

/** Cuánto se descuenta de UN kit con ese porcentaje (redondeado a pesos). Igual que en el portal. */
export function descuentoDeKit(kitId: string, porcentaje: number, sinTopeImpreso = false): number {
  const precio = PRECIOS_KITS[kitId];
  if (!precio || !(porcentaje > 0)) return 0;
  return Math.round((precio * porcentajeParaKit(kitId, porcentaje, sinTopeImpreso)) / 100);
}

/** El código si se puede usar ahora (activo, vigente y con usos libres); si no, null. */
async function codigoVigente(supabase: SupabaseClient, valor: unknown): Promise<{ codigo: string; porcentaje: number; usosLibres: number | null; sinTopeImpreso: boolean } | null> {
  const codigo = normalizarCodigoDescuento(valor);
  if (!CODIGO_RE.test(codigo)) return null;
  const { data, error } = await supabase.from('codigos_descuento').select(COLUMNAS).eq('codigo', codigo).maybeSingle();
  if (error) {
    if (['42P01', 'PGRST205'].includes(String((error as any).code || ''))) return null; // migración sin aplicar
    throw error;
  }
  if (!data || !data.activo) return null;
  if ((data.ambito || 'kit') !== 'kit') return null; // 27/10: código de eventos
  if (data.vence_at && Date.parse(data.vence_at) < Date.now()) return null;
  if (data.usos_max && Number(data.usos) >= Number(data.usos_max)) return null;
  return { codigo, porcentaje: Number(data.porcentaje), usosLibres: data.usos_max ? Number(data.usos_max) - Number(data.usos) : null, sinTopeImpreso: data.sin_tope_impreso === true };
}

/**
 * 24/10 (auditoría + Pablo): cada kit descontado gasta un uso. Con un código de 1 uso y 3 kits en el carrito se descuenta
 * UN kit (el de mayor descuento) y los otros se cobran completos. Devuelve los índices de los kits que llevan descuento.
 */
export function kitsConDescuento(kitIds: string[], descuento: { porcentaje: number; usosLibres?: number | null; sinTopeImpreso?: boolean } | null): Set<number> {
  if (!descuento) return new Set();
  const cupo = descuento.usosLibres == null ? kitIds.length : Math.max(0, descuento.usosLibres);
  const orden = kitIds.map((kitId, i) => ({ i, monto: descuentoDeKit(kitId, descuento.porcentaje, descuento.sinTopeImpreso) })).sort((a, b) => b.monto - a.monto || a.i - b.i);
  return new Set(orden.slice(0, cupo).map((k) => k.i));
}

/**
 * Para /api/pedidos/crear y /crear-multiple, ANTES de escribir nada. Sin código → descuento null (todo igual que
 * antes). Con código no válido → { error }. Revisión 22/10: tope de intentos por IP en la base (todas las instancias),
 * así no se pueden adivinar códigos probando compras.
 */
export async function prepararDescuento(supabase: SupabaseClient, valor: unknown, ip: unknown): Promise<{ descuento: { codigo: string; porcentaje: number; sinTopeImpreso?: boolean } | null; error?: string }> {
  if (valor === undefined || valor === null || String(valor).trim() === '') return { descuento: null };
  if (!(await hayCupoPorClave(`descuento-intento:${String(ip || 'desconocida')}`, 60, 600))) return { descuento: null, error: ERROR_DEMASIADOS_INTENTOS }; // 60: WiFi del colegio / CGNAT
  const vigente = await codigoVigente(supabase, valor);
  return vigente ? { descuento: vigente } : { descuento: null, error: ERROR_DESCUENTO_INVALIDO };
}

/**
 * Revisión 22/10: suma el uso de forma atómica justo antes de registrar el pedido (RPC `usar_codigo_descuento`): dos
 * compras simultáneas no pueden pasar el límite. Un uso se gasta al registrar la compra (aunque después no se pague).
 * false = ya no está disponible.
 */
export async function consumirUsoDescuento(supabase: SupabaseClient, descuento: { codigo: string; porcentaje: number } | null, veces = 1): Promise<boolean> {
  if (!descuento) return true;
  // 24/10: un uso por kit descontado. Si a mitad de camino se acaban (otra compra al mismo tiempo), se devuelven los ya gastados.
  for (let gastados = 0; gastados < veces; gastados++) {
    const { data, error } = await supabase.rpc('usar_codigo_descuento', { p_codigo: descuento.codigo });
    const porcentaje = Array.isArray(data) ? data[0] : data;
    if (error || Number(porcentaje) !== descuento.porcentaje) {
      await devolverUsoDescuento(supabase, descuento, gastados);
      if (error) throw error;
      return false;
    }
  }
  return true;
}

/** Si el pedido no se llegó a registrar, el uso se devuelve. */
export async function devolverUsoDescuento(supabase: SupabaseClient, descuento: { codigo: string } | null, veces = 1): Promise<void> {
  if (!descuento) return;
  for (let i = 0; i < veces; i++) {
    const { error } = await supabase.rpc('devolver_uso_codigo_descuento', { p_codigo: descuento.codigo });
    if (error) console.warn('[descuentos] No se pudo devolver el uso del código:', error.message);
  }
}

/** Columnas del pedido con el descuento aplicado (vacío si no hay). */
export function columnasDescuento(descuento: { codigo: string; porcentaje: number; sinTopeImpreso?: boolean } | null, kitId: string): Record<string, unknown> {
  if (!descuento) return {};
  return { codigo_descuento: descuento.codigo, descuento_pct: porcentajeParaKit(kitId, descuento.porcentaje, descuento.sinTopeImpreso), descuento_monto: descuentoDeKit(kitId, descuento.porcentaje, descuento.sinTopeImpreso) };
}

/** Si la compra completa quedó en $0 POR un código: nace pagada, «bonificado», sin pasar por la pasarela. */
export function columnasSiQuedaSinCargo(totalCompra: number, descuento: { codigo: string } | null): Record<string, unknown> {
  return descuento && totalCompra === 0 ? { estado: 'pagado', metodo_pago: 'bonificado', pagado_at: new Date().toISOString() } : {};
}

// ---------------------------------------------------------------------------------------------
// Familias: validar el código en el Paso 4 (el monto final lo vuelve a calcular el servidor al crear el pedido).
// ---------------------------------------------------------------------------------------------
// Revisión 22/10: tope por IP en la base (todas las instancias de Vercel suman), contra adivinar códigos. Sin tope
// total a propósito: con unas pocas IPs un tercero podría bloquear los códigos para todas las familias.
rutas.post('/api/descuentos/validar', limitarFrecuenciaPersistente('descuentos-validar', 15, 10 * 60 * 1000), async (req: Request, res: Response) => {
  try {
    const supabase = getServerSupabase();
    if (!supabase) return res.status(503).json({ success: false, error: 'Servicio no disponible' });
    const vigente = await codigoVigente(supabase, req.body?.codigo);
    if (!vigente) return res.status(404).json({ success: false, error: ERROR_DESCUENTO_INVALIDO });
    return res.json({ success: true, codigo: vigente.codigo, porcentaje: vigente.porcentaje, usosLibres: vigente.usosLibres, sinTopeImpreso: vigente.sinTopeImpreso });
  } catch (err: any) {
    console.error('[descuentos] Error al validar:', err);
    return res.status(500).json({ success: false, error: 'No pudimos validar el código. Probá de nuevo.' });
  }
});

// ---------------------------------------------------------------------------------------------
// Panel (pestaña «Descuentos»)
// ---------------------------------------------------------------------------------------------
rutas.get('/api/admin/descuentos', requireAdminAuth, async (_req: Request, res: Response) => {
  try {
    const supabase = getServerSupabase();
    if (!supabase) return res.status(500).json({ success: false, error: 'Supabase no configurado en el servidor' });
    const codigos = await traerTodasLasFilas<any>((desde, hasta) =>
      supabase.from('codigos_descuento').select(COLUMNAS).order('created_at', { ascending: false }).order('id').range(desde, hasta)
    );
    return res.json({ success: true, codigos });
  } catch (err: any) {
    console.error('[descuentos] Error al listar:', err);
    return res.status(500).json({ success: false, error: err?.message || 'No se pudieron cargar los códigos.' });
  }
});

/** Código al azar (sin 0/O/1/I/L, para que no se confundan al dictarlo). */
function codigoAlAzar(): string {
  const letras = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';
  const bytes = crypto.randomBytes(8);
  let s = '';
  for (let i = 0; i < 8; i++) s += letras[bytes[i] % letras.length];
  return `RE-${s}`;
}

/** Porcentaje, usos, vencimiento, tope y ámbito de un código nuevo (igual para uno solo o para un lote). */
function leerConfiguracionCodigo(body: any): { error: string } | { config: { porcentaje: number; usos_max: number | null; vence_at: string | null; sin_tope_impreso: boolean; ambito: string } } {
  const porcentaje = Math.floor(Number(body?.porcentaje));
  if (!(porcentaje >= 1 && porcentaje <= 100)) return { error: 'El porcentaje tiene que ser entre 1 y 100.' };
  const usosCrudo = body?.usosMax;
  const usosMax = usosCrudo === null || usosCrudo === undefined || usosCrudo === '' ? null : Math.floor(Number(usosCrudo));
  if (usosMax !== null && !(usosMax >= 1 && usosMax <= 100000)) return { error: 'Los usos tienen que ser 1 o más (o vacío = sin límite).' };
  const venceCrudo = String(body?.vence || '').trim();
  let venceAt: string | null = null;
  if (venceCrudo) {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(venceCrudo)) return { error: 'Fecha de vencimiento no válida.' };
    venceAt = new Date(`${venceCrudo}T23:59:59.999-03:00`).toISOString(); // vence al final de ese día (hora de Argentina)
    if (Date.parse(venceAt) < Date.now()) return { error: 'La fecha de vencimiento ya pasó.' };
  }
  const sinTopeImpreso = body?.sinTopeImpreso === true; // 27/10: el impreso también hasta 100%
  const ambito = body?.ambito === undefined ? 'kit' : String(body.ambito);
  if (!(AMBITOS_DESCUENTO as readonly string[]).includes(ambito)) return { error: 'Elegí si el código vale para el kit o para los eventos.' };
  return { config: { porcentaje, usos_max: usosMax, vence_at: venceAt, sin_tope_impreso: sinTopeImpreso, ambito } };
}

rutas.post('/api/admin/descuentos', requireAdminAuth, async (req: Request, res: Response) => {
  try {
    const leido = leerConfiguracionCodigo(req.body);
    if ('error' in leido) return res.status(400).json({ success: false, error: leido.error });
    const nota = String(req.body?.nota || '').trim().slice(0, 200);
    const pedido = normalizarCodigoDescuento(req.body?.codigo);
    if (pedido && !CODIGO_RE.test(pedido)) return res.status(400).json({ success: false, error: 'El código puede tener de 4 a 32 letras, números o guiones.' });
    const supabase = getServerSupabase();
    if (!supabase) return res.status(500).json({ success: false, error: 'Supabase no configurado en el servidor' });
    for (let intento = 0; intento < 3; intento++) {
      const codigo = pedido || codigoAlAzar();
      const { data, error } = await supabase
        .from('codigos_descuento')
        .insert({ id: crypto.randomUUID(), activo: true, usos: 0, codigo, ...leido.config, nota: nota || null })
        .select(COLUMNAS)
        .maybeSingle();
      if (!error) return res.json({ success: true, codigo: data });
      if (String((error as any).code) !== '23505') throw error;
      if (pedido) return res.status(409).json({ success: false, error: 'Ese código ya existe. Elegí otro.' });
    }
    return res.status(500).json({ success: false, error: 'No se pudo generar un código. Probá de nuevo.' });
  } catch (err: any) {
    console.error('[descuentos] Error al crear:', err);
    return res.status(500).json({ success: false, error: err?.message || 'No se pudo crear el código.' });
  }
});

// 28/10 (Pablo): «hacer códigos de descuento por lotes, tengo el listado de profesores y administrativos». Un código
// al azar por persona, con la misma configuración; el nombre queda en la nota. Se insertan todos juntos (todo o nada).
export const MAX_CODIGOS_POR_LOTE = 500;
rutas.post('/api/admin/descuentos/lote', requireAdminAuth, async (req: Request, res: Response) => {
  try {
    const leido = leerConfiguracionCodigo(req.body);
    if ('error' in leido) return res.status(400).json({ success: false, error: leido.error });
    const crudos: unknown[] = Array.isArray(req.body?.nombres) ? req.body.nombres : [];
    const vistos = new Set<string>();
    const nombres: string[] = [];
    for (const n of crudos) {
      const nombre = String(n ?? '').replace(/\s+/g, ' ').trim().slice(0, 200);
      if (!nombre || vistos.has(nombre.toLowerCase())) continue;
      vistos.add(nombre.toLowerCase());
      nombres.push(nombre);
    }
    if (nombres.length === 0) return res.status(400).json({ success: false, error: 'Pegá al menos un nombre (uno por línea).' });
    if (nombres.length > MAX_CODIGOS_POR_LOTE) return res.status(400).json({ success: false, error: `Como máximo ${MAX_CODIGOS_POR_LOTE} códigos por lote.` });
    const supabase = getServerSupabase();
    if (!supabase) return res.status(500).json({ success: false, error: 'Supabase no configurado en el servidor' });
    for (let intento = 0; intento < 3; intento++) {
      const codigos = new Set<string>();
      while (codigos.size < nombres.length) codigos.add(codigoAlAzar());
      const lista = [...codigos];
      const filas = nombres.map((nombre, i) => ({ id: crypto.randomUUID(), activo: true, usos: 0, codigo: lista[i], ...leido.config, nota: nombre }));
      const { data, error } = await supabase.from('codigos_descuento').insert(filas).select(COLUMNAS);
      if (!error) {
        const porCodigo = new Map((data || []).map((c: any) => [c.codigo, c]));
        return res.json({ success: true, codigos: filas.map((f) => porCodigo.get(f.codigo)).filter(Boolean) });
      }
      if (String((error as any).code) !== '23505') throw error; // choque con un código existente: se vuelve a sortear todo
    }
    return res.status(500).json({ success: false, error: 'No se pudieron generar los códigos. Probá de nuevo.' });
  } catch (err: any) {
    console.error('[descuentos] Error al crear lote:', err);
    return res.status(500).json({ success: false, error: err?.message || 'No se pudieron crear los códigos.' });
  }
});

rutas.post('/api/admin/descuentos/:id/activo', requireAdminAuth, async (req: Request, res: Response) => {
  try {
    if (!UUID_RE.test(req.params.id)) return res.status(400).json({ success: false, error: 'Código no válido.' });
    if (typeof req.body?.activo !== 'boolean') return res.status(400).json({ success: false, error: 'Falta indicar si queda activo.' });
    const supabase = getServerSupabase();
    if (!supabase) return res.status(500).json({ success: false, error: 'Supabase no configurado en el servidor' });
    const { data, error } = await supabase.from('codigos_descuento').update({ activo: req.body.activo }).eq('id', req.params.id).select(COLUMNAS);
    if (error) throw error;
    if (!data || data.length === 0) return res.status(404).json({ success: false, error: 'No encontramos ese código.' });
    return res.json({ success: true, codigo: data[0] });
  } catch (err: any) {
    console.error('[descuentos] Error al activar/desactivar:', err);
    return res.status(500).json({ success: false, error: err?.message || 'No se pudo actualizar el código.' });
  }
});

export { rutas as rutasDescuentos };

/** Pedido(s) que nacieron pagados sin cargo: se manda el mail con la descarga HD como en cualquier pago (hasta 8 s; si no, lo termina el reintento horario). */
export async function entregarSinCargo(supabase: SupabaseClient, ids: string[]): Promise<void> {
  const { data, error } = await supabase.from('pedidos').select('*, familias(nombre, whatsapp, email)').in('id', ids).eq('estado', 'pagado');
  if (error || !data || data.length === 0) return;
  await Promise.race([procesarPedidosRecienPagados(supabase, data), new Promise((ok) => setTimeout(ok, 8000))]);
}
