// Estado de un pedido para el portal (/api/pedidos/:id/status, con conciliación) y cambiar el medio de
// pago (división de server.ts, etapa 6, 10/10/2026). El código es el mismo que estaba en server.ts.
import type { SupabaseClient } from '@supabase/supabase-js';
import express from 'express';
import { urlDescargaSeguida } from '../entrega/correos.js';
import { refirmarLinkDescargaHDSiExiste } from '../entrega/descargas.js';
import { llaveRecibida, pedidoHabilitaDescarga, tokenAccesoValido } from '../nucleo/accesoPedidos.js';
import { getServerSupabase } from '../nucleo/clientes.js';
import { limitarFrecuencia } from '../nucleo/limites.js';
import { esPedidoAdicional, esPedidoFotosExtra } from '../nucleo/fotosExtra.js';
import { ESTADOS_COBRABLES } from '../nucleo/pedidos.js';
import { comprobanteFrenaCobro, RESPUESTA_COMPROBANTE_YA_SUBIDO } from './cobros.js';
import { conciliarPagoPendiente } from './conciliacion.js';

const rutas = express.Router();

// Endpoint público para que el cliente consulte el estado de pago actualizado de su pedido
// Auditoría 2026-09-21 (refuerzo): la pantalla de "preparando tu descarga" lo consulta en un
// intervalo corto mientras espera, así que el límite tiene que ser generoso para no cortar esa
// consulta legítima — pero sin límite, se podía usar para probar IDs de pedido al voleo.
rutas.get('/api/pedidos/:id/status', limitarFrecuencia('pedidos-status', 1500, 10 * 60 * 1000), async (req, res) => {
  try {
    const { id } = req.params;
    const supabase = getServerSupabase();
    if (!supabase) {
      return res.status(503).json({ success: false, error: 'Servicio de base de datos no disponible' });
    }

    // OJO: la tabla "pedidos" solo tiene una columna de estado ("estado": pendiente_pago |
    // pagado | entregado | cancelado) — no existen "estado_pago" ni "mercadopago_payment_id".
    // Antes este select pedía esas columnas inexistentes, Postgres devolvía error, y este
    // endpoint (que usa el Portal de Familias para avisar automáticamente "tu pago fue
    // aprobado" apenas vuelven de Mercado Pago) fallaba siempre con 400 — ninguna familia veía
    // la confirmación automática, aunque el pago sí se hubiera acreditado bien. Ver auditoría
    // 2026-09-09.
    // Un id que no tiene forma de UUID nunca puede existir (y Postgres respondería con un error de
    // sintaxis en vez de "no encontrado").
    if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(String(id))) {
      return res.status(404).json({ success: false, error: 'Pedido no encontrado' });
    }
    const columnasStatus = 'id, estado, total, updated_at, mp_payment_id, metodo_pago, nave_payment_request_id, nave_intenciones_previas, mp_preference_id, grupo_pago_id, pedido_friendly_id, link_descarga_hd, seleccion_pendiente, mejora_de_pedido_id, extras_de_pedido_id, tipo_kit, cancelado_definitivo, created_at, comprobante_subido_at';
    let { data, error } = await supabase
      .from('pedidos')
      .select(columnasStatus)
      .eq('id', id)
      .maybeSingle();
    // Auditoría 2026-09-23 (bug real): al volver de Mercado Pago/Nave con un carrito multi-hijo en
    // otro dispositivo (sin los pedidos en localStorage), el portal sólo conoce el grupo_pago_id y
    // consulta con ese valor — antes eso daba 404 para siempre (y el portal seguía consultando
    // cada 4 s hasta chocar con el límite de frecuencia). Ahora se resuelve por el grupo.
    if (!error && !data) {
      // Auditoría 03/10 noche (M5): antes se tomaba la fila más vieja del grupo; si era un hermano
      // cancelado (o una reserva reemplazada), la familia veía "rechazado" justo después de pagar.
      // Ahora: una fila viva ya pagada; si no, una viva con link de pago; si no, cualquiera viva.
      const { data: filasGrupo, error: errorGrupo } = await supabase
        .from('pedidos')
        .select(columnasStatus)
        .eq('grupo_pago_id', id)
        .order('created_at', { ascending: true })
        .limit(20);
      error = errorGrupo;
      const vivas = (filasGrupo || []).filter((f: any) => !f.cancelado_definitivo);
      data =
        (vivas.find((f: any) => f.estado === 'pagado' || f.estado === 'entregado') ||
          vivas.find((f: any) => f.mp_preference_id || f.nave_payment_request_id) ||
          vivas[0] ||
          (filasGrupo || [])[0] ||
          null) as any;
    }

    if (error) {
      return res.status(400).json({ success: false, error: error.message });
    }

    if (!data) {
      return res.status(404).json({ success: false, error: 'Pedido no encontrado' });
    }

    const estadoFinal = await conciliarPagoPendiente(supabase, data);

    const esAprobado = estadoFinal === 'pagado' || estadoFinal === 'entregado';
    const esRechazado = estadoFinal === 'cancelado';

    // Auditoría 2026-09-26 (C2 + A4): el link HD sólo viaja con la llave de acceso del pedido
    // (tokenAccesoPedido) y sólo si está cobrado. Antes alcanzaba con el UUID.
    const tieneLlave = tokenAccesoValido(req.query.t, [data.id, data.grupo_pago_id, String(id)]);
    let linkDescargaHD: string | undefined;
    // Auditoría 30/9 (A3): una "mejora a impreso" no tiene descarga propia (la tiene el pedido
    // original). Antes cualquiera con el código del curso podía crear la mejora del pedido de otro
    // chico, pagar la diferencia y bajarse su foto individual con la llave de la mejora.
    if (tieneLlave && pedidoHabilitaDescarga(estadoFinal) && !esPedidoAdicional(data)) { // 29/10: + fotos extra
      // El link se genera cuando el pago se confirma, así que puede no estar en la fila leída arriba.
      const { data: conLink } = await supabase.from('pedidos').select('id, pedido_friendly_id, link_descarga_hd').eq('id', data.id).maybeSingle();
      linkDescargaHD = await refirmarLinkDescargaHDSiExiste(supabase, conLink || data);
      // El botón "Descarga inmediata" del portal también pasa por el registro de descargas.
      if (linkDescargaHD) linkDescargaHD = urlDescargaSeguida(data.id) || linkDescargaHD;
    }

    // Monto del pedido (o de todo el carrito, si es un pago combinado): el portal lo usa para
    // completar la pantalla de confirmación cuando la familia vuelve del pago en otro navegador
    // y no tiene el pedido guardado (antes mostraba "$0").
    let totalReferencia = Number(data.total) || 0;
    // 14/10/2026: si ya subieron el comprobante de una transferencia, el portal no ofrece pagar de otra forma.
    let comprobanteSubido = Boolean((data as any).comprobante_subido_at);
    if (data.grupo_pago_id) {
      // Revisión 03/10 noche: sólo las filas vivas (un hermano cancelado no se cobra; el portal ahora
      // muestra este total como el monto a pagar).
      // Auditoría 05/10 (medio): el "cancelado" por rechazo de tarjeta (no definitivo) sigue siendo parte
      // del monto a pagar; antes un carrito rechazado entero mostraba el total de un solo hermano.
      const { data: filasGrupo } = await supabase.from('pedidos').select('total, estado, cancelado_definitivo, comprobante_subido_at').eq('grupo_pago_id', data.grupo_pago_id);
      const vivasGrupo = (filasGrupo || []).filter((f: any) => !f.cancelado_definitivo);
      comprobanteSubido = comprobanteSubido || vivasGrupo.some((f: any) => f.comprobante_subido_at);
      if (vivasGrupo.length > 0) {
        totalReferencia = vivasGrupo.reduce((acc: number, f: any) => acc + (Number(f.total) || 0), 0);
      }
    }

    // Auditoría 2026-09-18 (reporte de Pablo): el Portal de Familias deja de consultar este
    // endpoint apenas el pago queda "aprobado" (ver PortalFamiliasModal.tsx), así que el botón
    // "Descarga Inmediata" se quedaba para siempre en "Preparando..." si el .zip HD tardaba
    // aunque sea unos segundos más que el pago en confirmarse — nunca había una segunda consulta
    // que pudiera enterarse de que el link ya estaba listo. Se agrega el link acá para que el
    // portal pueda activarlo sin esperar al email.
    return res.json({
      success: true,
      pedidoId: data.id,
      estado: estadoFinal,
      estadoPago: esAprobado ? 'aprobado' : esRechazado ? 'rechazado' : 'pendiente',
      actualizadoEl: data.updated_at,
      total: totalReferencia,
      pedidoFriendlyId: data.pedido_friendly_id || undefined,
      linkDescargaHD: linkDescargaHD || undefined,
      metodoPago: (data as any).metodo_pago || undefined,
      // Pago anticipado: el pedido está pagado pero todavía sin fotos elegidas (no hay HD que esperar).
      reservaAnticipada: Boolean((data as any).seleccion_pendiente),
      // Auditoría 05/10: una mejora a Kit Impreso no tiene .zip propio; el portal no espera un link.
      // 29/10/2026: las fotos extra tampoco llevan .zip (esMejora = «no esperes un link»); esFotosExtra cambia el texto.
      esMejora: esPedidoAdicional(data),
      esFotosExtra: esPedidoFotosExtra(data),
      comprobanteSubido,
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err?.message || 'Error al consultar estado del pedido' });
  }
});

// Auditoría 2026-09-21 (pedido real de Pablo, probado en producción): empezó a pagar con
// Mercado Pago, canceló la ventana de pago justo antes de confirmar, y volvió a la pantalla de
// "Pendiente de Pago" del Portal de Familias — pero ahí el único botón disponible era "Ir a
// Pagar en Mercado Pago" (regenera el mismo link), sin ninguna forma de elegir Nave o
// Transferencia en su lugar. El método de pago quedaba fijo para siempre en lo que se haya
// elegido al crear el pedido, aunque el pago nunca se hubiera completado. Este endpoint permite
// cambiar el método de pago de un pedido TODAVÍA NO PAGADO — el Portal de Familias lo llama
// cuando la familia elige otro método desde esa misma pantalla de "Pendiente de Pago".
// Cambia el medio de pago de un pago (pedido suelto o carrito entero) que sigue pendiente. Lo usan
// /cambiar-metodo-pago y el reintento idempotente de /api/pedidos/crear y /crear-multiple (Auditoría
// 03/10, 2ª vuelta: la familia vuelve a confirmar el mismo checkout con otro medio). El
// transferencia_desde lo completa el trigger de la base al pasar a transferencia.
// Auditoría 05/10 (medio): un rechazo de tarjeta deja el pedido en "cancelado" (no definitivo: sigue
// cobrable, ver ESTADOS_COBRABLES), pero acá sólo se tocaban los "pendiente_pago": la familia tocaba
// "Quiero pagar de otra forma" y recibía "ya no está pendiente de pago". Ahora el cambio de medio
// alcanza a todo lo cobrable y lo devuelve a pendiente_pago.
export async function aplicarMetodoPagoPendiente(supabase: SupabaseClient, columna: 'id' | 'grupo_pago_id', valor: string, metodoPago: string) {
  return supabase
    .from('pedidos')
    .update({ metodo_pago: metodoPago, estado: 'pendiente_pago', updated_at: new Date().toISOString() })
    .eq(columna, valor)
    .in('estado', ESTADOS_COBRABLES)
    .eq('cancelado_definitivo', false);
}

rutas.post('/api/pedidos/:id/cambiar-metodo-pago', limitarFrecuencia('pedidos-cambiar-metodo-pago', 150, 10 * 60 * 1000), async (req, res) => {
  try {
    const { id } = req.params;
    const { metodoPago } = req.body;
    const metodosPermitidos = ['mercadopago', 'nave', 'transferencia'];
    if (!metodosPermitidos.includes(metodoPago)) {
      return res.status(400).json({ success: false, error: 'Método de pago no reconocido.' });
    }

    const supabase = getServerSupabase();
    if (!supabase) {
      return res.status(503).json({ success: false, error: 'Servicio de base de datos no disponible' });
    }

    const { data: pedidoActual, error: errorLectura } = await supabase
      .from('pedidos')
      .select('id, estado, metodo_pago, grupo_pago_id, cancelado_definitivo, transferencia_vencida_at, comprobante_subido_at')
      .eq('id', id)
      .maybeSingle();

    if (errorLectura) {
      console.error('[cambiar-metodo-pago]', errorLectura);
      return res.status(400).json({ success: false, error: 'No pudimos leer el pedido.' });
    }
    if (!pedidoActual) {
      return res.status(404).json({ success: false, error: 'Pedido no encontrado' });
    }
    // Auditoría 30/9: sólo la familia del pedido (con su llave) puede cambiar el medio de pago.
    // Antes alcanzaba el UUID: un compañero podía pasar el pedido de otro a transferencia y, a las
    // 48 hs sin comprobante, se cancelaba solo.
    if (!tokenAccesoValido(llaveRecibida(req), [pedidoActual.id, pedidoActual.grupo_pago_id])) {
      return res.status(403).json({ success: false, error: 'No pudimos validar tu pedido desde este dispositivo. Entrá con el link del email del pedido.' });
    }
    // Nunca se permite tocar el método de pago de un pedido que ya se cobró (o que ya se
    // canceló/entregó) — solo tiene sentido mientras sigue "pendiente_pago".
    // Auditoría 03/10 (alto 9): un pedido cancelado definitivo nunca vuelve a tener un medio de pago.
    // Auditoría 05/10 (medio): "cancelado" por un rechazo de tarjeta sigue cobrable (ESTADOS_COBRABLES).
    // Auditoría 11/10: una transferencia vencida por plazo sólo la reabre Pablo desde el panel (si la familia
    // la revivía quedaba "pendiente" con el plazo ya vencido: el comprobante se rechazaba y el control la volvía a cancelar).
    if (pedidoActual.estado === 'cancelado' && pedidoActual.transferencia_vencida_at && metodoPago === 'transferencia') { // con tarjeta puede pagar
      return res.status(409).json({ success: false, codigo: 'TRANSFERENCIA_VENCIDA', error: 'El plazo para pagar este pedido venció. Escribinos y lo reabrimos.' });
    }
    if (!ESTADOS_COBRABLES.includes(String(pedidoActual.estado)) || pedidoActual.cancelado_definitivo) {
      return res.status(409).json({
        success: false,
        error: 'Este pedido ya no está pendiente de pago, así que no se puede cambiar el método.',
      });
    }

    // 14/10/2026: ya subió el comprobante de una transferencia (en cualquier fila del carrito): pasar a
    // tarjeta sólo con la confirmación expresa de la familia (`confirmarIgual`), si no es un cobro doble.
    if (metodoPago !== 'transferencia') {
      let filasPago: any[] = [pedidoActual];
      if (pedidoActual.grupo_pago_id) {
        const { data: grupo, error: errorGrupo } = await supabase.from('pedidos').select('id, comprobante_subido_at, cancelado_definitivo').eq('grupo_pago_id', pedidoActual.grupo_pago_id);
        if (errorGrupo) return res.status(400).json({ success: false, error: 'No pudimos leer el pedido.' });
        filasPago = [pedidoActual, ...(grupo || []).filter((f: any) => !f.cancelado_definitivo)];
      }
      if (comprobanteFrenaCobro(filasPago, req.body)) return res.status(409).json(RESPUESTA_COMPROBANTE_YA_SUBIDO);
    }

    // Un carrito multi-hijo comparte grupo_pago_id entre varias filas de "pedidos" que se cobran
    // juntas en un solo pago — el cambio de método tiene que aplicarse a todo el grupo, no solo a
    // la fila que la familia tenía en pantalla, para no terminar con hermanos del mismo carrito
    // apuntando a métodos de pago distintos.
    const filtroActualizacion = pedidoActual.grupo_pago_id
      ? { columna: 'grupo_pago_id' as const, valor: pedidoActual.grupo_pago_id }
      : { columna: 'id' as const, valor: pedidoActual.id };

    // Auditoría 2026-09-26 (M3): antes acá se BORRABAN los ids del intento anterior
    // (mp_preference_id / nave_payment_request_id). Pero ese link viejo sigue siendo pagable: si la
    // familia terminaba pagándolo y el aviso de la pasarela se perdía, el control automático ya no
    // tenía cómo encontrar el pago. Ahora se conservan; la conciliación registra un pago aprobado
    // en cualquier pasarela donde hubo intento, pero sólo cancela por un rechazo de la pasarela
    // que el pedido tiene elegida en ese momento.
    const { error: errorUpdate } = await aplicarMetodoPagoPendiente(supabase, filtroActualizacion.columna, filtroActualizacion.valor, metodoPago);

    if (errorUpdate) {
      return res.status(400).json({ success: false, error: errorUpdate.message });
    }

    return res.json({ success: true, metodoPago });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err?.message || 'Error al cambiar el método de pago' });
  }
});

export { rutas as rutasEstadoPedido };
