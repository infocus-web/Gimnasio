// Crear pedidos (uno y carrito de hermanos, idempotentes por id del navegador + claveCheckout) y las
// reservas de pago anticipado (crear, pendiente, elegir fotos), con la validación de la selección de
// fotos (división de server.ts, etapa 6, 10/10/2026). El código es el mismo que estaba en la sección 7
// de server.ts: sólo se movió. Pedidos y reservas van juntos porque comparten casi todo; en server.ts
// eran dos tramos: por eso hay dos routers.
import type { SupabaseClient } from '@supabase/supabase-js';
import crypto from 'crypto';
import express from 'express';
import type { Request, Response } from 'express';
import { procesarPedidosRecienPagados } from '../entrega/pedidosPagados.js';
import { errorLugarSinFotoVacio } from '../familias/faltantesPendientes.js'; import { exigirPlazoKitImpreso, exigirPlazoReservaImpreso } from './plazoKitImpreso.js'; // 26/10: Kit Impreso hasta el 15/11
import { calcularCodigoAlumnoServidor, claveCursoNumeroLista, hijosDeFamiliaConAcceso, obtenerNumeroListaSecuencial, renumerarFilasPorCurso, ultimoNumeroLista } from '../familias/inscripciones.js';
import { llaveRecibida, tokenAccesoPedido, tokenAccesoValido } from '../nucleo/accesoPedidos.js';
import { getServerSupabase } from '../nucleo/clientes.js';
import { buscarSeccionPorCodigoSecreto, determinarCodigoCursoServidor } from '../nucleo/codigosCurso.js';
import { buscarColegioReal, ERROR_COLEGIO_NO_VALIDO } from '../nucleo/colegios.js';
import { VERSION_TERMINOS_SERVIDOR } from '../nucleo/legal.js';
import { limitarFrecuencia } from '../nucleo/limites.js';
import { etiquetasDelAlumno, nombresCompatibles } from '../nucleo/nombres.js';
import { categoriaValeEnLugar, lugaresSinFoto, type LugarPack } from '../nucleo/fotosFaltantes.js';
import { esCategoriaTerceraFoto, ESTADOS_COBRABLES, tipoChoqueUnicoPedido } from '../nucleo/pedidos.js';
import { exigirPreciosCargados } from '../nucleo/precios.js';
import { normalizarNombrePorPalabras, traerTodasLasFilas } from '../nucleo/utilidades.js';
import { aceptacionDeTerminos, ERROR_TERMINOS_NO_ACEPTADOS } from './arrepentimiento.js';
import { enviarAvisoTransferenciaRegistrada } from './avisoPedidoPendiente.js';
import { alumnosConKitPagado, claveCheckoutValida, copiasExtrasServidor, hashClaveCheckout, mismoDuenoDePedido, respuestaKitYaPagado } from './cobros.js';
import { cursoDistintoAlInscripto, respuestaCursoCambiado } from './cursoInscripto.js';
import { columnasDescuento, columnasSiQuedaSinCargo, consumirUsoDescuento, descuentoDeKit, devolverUsoDescuento, entregarSinCargo, ERROR_DESCUENTO_COMBINADO, ERROR_DESCUENTO_INVALIDO, kitsConDescuento, prepararDescuento } from './descuentos.js';
import { aplicarMetodoPagoPendiente } from './estadoPedido.js';
import { calcularTotalPedido, carpetasExtrasValidas, MAX_FOTOS_SUELTAS, ERROR_DIGITAL_SECUNDARIA, kitPermitidoParaGrado } from './totales.js';

// Un router por cada tramo de server.ts donde estaban estas rutas (así el orden de Express no cambia).
const rutas = express.Router();
const rutasReservas = express.Router();

// Auditoría 2026-09-23: kits que se pueden COMPRAR desde el portal. "kit-evento-suelto" ($5.000)
// existe en el catálogo para mostrarse en la landing, pero el portal nunca lo ofrece — y como el
// .zip HD arma TODAS las fotos elegidas (individual/grupal/docente) sin mirar el kit, un pedido
// armado a mano con ese kit recibía el pack completo por $5.000 (y además quedaba marcado como
// "impreso_digital" para el laboratorio). Se rechaza al registrar el pedido.
const KITS_COMPRABLES_PORTAL = new Set(['kit-clasico', 'kit-digital']);

// Inserta filas en "pedidos" y, si dos compras simultáneas chocaron con el mismo número amigable
// (índice único pedidos_pedido_friendly_id_unico, error 23505), les asigna números nuevos y
// reintenta. Las filas se modifican en el lugar, así quien llama devuelve el número definitivo.
// 08/10/2026: lo mismo con el número de lista del curso (índice pedidos_numero_lista_unico): se
// renumeran las filas desde el último número usado y se reintenta.
export async function insertarPedidosConReintento(supabase: SupabaseClient, filas: Record<string, any>[], columnas = 'id') {
  let resultado: { data: any[] | null; error: any } = { data: null, error: null };
  for (let intento = 0; intento < 4; intento++) {
    resultado = await supabase.from('pedidos').insert(filas).select(columnas);
    const choque = tipoChoqueUnicoPedido(resultado.error);
    if (choque === 'friendly') {
      const usados = new Set<string>();
      for (const fila of filas) fila.pedido_friendly_id = await asegurarFriendlyIdUnico(supabase, '', usados);
    } else if (choque === 'numero_lista') {
      const ultimos = new Map<string, number>();
      try {
        for (const fila of filas) {
          if (fila.mejora_de_pedido_id || fila.extras_de_pedido_id || !fila.curso_codigo) continue;
          const clave = claveCursoNumeroLista(fila.colegio_id, fila.curso_codigo);
          if (!ultimos.has(clave)) ultimos.set(clave, await ultimoNumeroLista(supabase, String(fila.curso_codigo), fila.colegio_id));
        }
      } catch {
        return resultado;
      }
      renumerarFilasPorCurso(filas, ultimos);
    } else {
      return resultado;
    }
  }
  return resultado;
}

export async function asegurarFriendlyIdUnico(supabase: SupabaseClient, propuesto: unknown, yaUsados: Set<string>): Promise<string> {
  const formato = /^IFS-\d{4}-\d{4,5}$/; // debe seguir matcheando FORMATO_PEDIDO_FRIENDLY_ID (buscador)
  let candidato = String(propuesto || '').trim().toUpperCase().slice(0, 40);
  for (let intento = 0; intento < 8; intento++) {
    if (formato.test(candidato) && !yaUsados.has(candidato)) {
      const { data } = await supabase.from('pedidos').select('id').eq('pedido_friendly_id', candidato).limit(1);
      if (!data || data.length === 0) {
        yaUsados.add(candidato);
        return candidato;
      }
    }
    // A partir del 3er intento se agranda a 5 dígitos para salir rápido de zonas ya ocupadas.
    const digitos = intento < 3 ? 4 : 5;
    const min = 10 ** (digitos - 1);
    candidato = `IFS-${new Date().getFullYear()}-${crypto.randomInt(min, 10 ** digitos)}`;
  }
  yaUsados.add(candidato);
  return candidato;
}

// Registra un pedido nuevo (lo llama el portal al iniciar el checkout). Auditoría 09/09: antes lo hacía el navegador
// directo contra Supabase con RLS abierta (cualquiera leía familias o insertaba pedidos "pagados"); ahora pasa por
// acá: total siempre del servidor y el pedido nace pendiente de pago (salvo $0 con código de descuento, 22/10).
// Cuando un chico pasa a tener un pedido normal (con sus fotos elegidas), sus reservas de pago
// anticipado que quedaron SIN pagar ya no sirven: se cancelan para que no queden colgadas en el
// panel (caso real 25/9: IFS-2026-1756). Nunca toca reservas pagadas.
async function cancelarReservasSinPagarDe(supabase: SupabaseClient, filas: { colegio_id?: string; curso_codigo?: string; alumno_nombre?: string | null }[], emailFamilia: unknown) {
  for (const fila of filas) {
    if (!fila.colegio_id || !fila.curso_codigo || !fila.alumno_nombre) continue;
    const { data: reservas } = await supabase
      .from('pedidos')
      .select('id, alumno_nombre, comprobante_subido_at, familias(email)')
      .eq('colegio_id', fila.colegio_id)
      .eq('curso_codigo', fila.curso_codigo)
      .eq('seleccion_pendiente', true)
      .in('estado', ESTADOS_COBRABLES)
      .eq('cancelado_definitivo', false);
    // Auditoría 03/10 noche (A2): sólo las reservas de la MISMA familia (mismo email) y nunca una con
    // comprobante de transferencia ya subido. Antes alcanzaba con el nombre del chico: un pedido de
    // otra persona (mamá/papá con otro email, o cualquiera con el código del curso) cancelaba para
    // siempre la reserva de esta familia, aunque ya hubiera transferido. Las PAGADAS no se tocan nunca.
    const ids = (reservas || [])
      .filter((r: any) => normalizarNombrePorPalabras(r.alumno_nombre) === normalizarNombrePorPalabras(fila.alumno_nombre))
      .filter((r: any) => reservaEsDeLaFamilia(r, emailFamilia) && !r.comprobante_subido_at)
      .map((r: any) => r.id);
    if (ids.length > 0) {
      // Auditoría 03/10 (alto 8): la reserva reemplazada queda cancelado_definitivo: antes quedaba
      // "cancelado" a secas, que la conciliación todavía podía pasar a "pagado" si la familia pagaba
      // el link viejo (dos kits). Si igual lo paga, queda la alerta de pago huérfano para devolverlo.
      const { error } = await supabase.from('pedidos').update({ estado: 'cancelado', cancelado_definitivo: true, updated_at: new Date().toISOString() }).in('id', ids).in('estado', ESTADOS_COBRABLES);
      if (error) console.error('[Pedidos] No se pudieron cancelar reservas sin pagar:', error);
    }
  }
}

/** Auditoría 03/10 noche (A2): ¿la reserva (con su join a familias) es de quien usa este email? */
function reservaEsDeLaFamilia(reserva: { familias?: any }, email: unknown): boolean {
  const familia = Array.isArray(reserva?.familias) ? reserva.familias[0] : reserva?.familias;
  const emailReserva = String(familia?.email || '').trim().toLowerCase();
  const emailNuevo = String(email || '').trim().toLowerCase().slice(0, 200);
  return Boolean(emailReserva) && emailReserva.includes('@') && emailReserva === emailNuevo;
}

/**
 * Auditoría 08/10 (M5): de los hijos de la llave de galería, cuáles son el alumno `alumno` de un pedido
 * o reserva. Antes alcanzaba con nombres "compatibles" (subconjunto de palabras): la familia de
 * "Juan Pérez" llegaba a la reserva pagada de "Juan Ignacio Pérez" y le elegía las fotos. Ahora:
 * mismo nombre, o compatible SÓLO si ningún otro chico inscripto en ese curso coincide mejor.
 * Si no se puede leer el curso, falla cerrado (devuelve sólo las coincidencias exactas).
 */
export async function hijosQueSonElAlumno(
  supabase: SupabaseClient,
  familiaId: unknown,
  hijos: string[] | null,
  alumno: unknown,
  colegioId: string,
  cursoCodigo: string
): Promise<string[]> {
  if (!hijos || hijos.length === 0) return [];
  const objetivo = normalizarNombrePorPalabras(alumno);
  if (!objetivo) return [];
  const exactos = hijos.filter((n) => normalizarNombrePorPalabras(n) === objetivo);
  if (exactos.length > 0) return exactos;
  const compatibles = hijos.filter((n) => nombresCompatibles(n, alumno));
  if (compatibles.length === 0) return [];
  try {
    const { data, error } = await supabase
      .from('inscripciones')
      .select('id, alumno_nombre, alumno_apellido, grado, turno, division, hermanos')
      .eq('colegio_id', colegioId)
      .limit(3000);
    if (error) throw error;
    const otros: string[] = [];
    const delCurso = (g: unknown, t: unknown, d: unknown) =>
      !g || determinarCodigoCursoServidor(String(g || ''), String(t || ''), String(d || '')) === cursoCodigo;
    for (const fila of data || []) {
      if (String(fila.id) === String(familiaId || '')) continue;
      if (delCurso(fila.grado, fila.turno, fila.division)) otros.push(`${fila.alumno_nombre || ''} ${fila.alumno_apellido || ''}`.trim());
      for (const h of Array.isArray(fila.hermanos) ? fila.hermanos : []) {
        if (delCurso(h?.grado, h?.turno, h?.division)) otros.push(`${h?.alumnoNombre || ''} ${h?.alumnoApellido || ''}`.trim());
      }
    }
    return compatibles.filter((h) => etiquetasDelAlumno(alumno, [h, ...otros.filter(Boolean)]).has(normalizarNombrePorPalabras(h)));
  } catch (e) {
    console.warn('[nombres] No se pudo leer el curso para comparar nombres:', e);
    return [];
  }
}

/** ¿La etiqueta `etiqueta` es (una de) la(s) del alumno `nombre`, entre todas las del curso? */
export function etiquetaEsDelAlumno(etiqueta: unknown, nombre: unknown, etiquetasCurso: unknown[]): boolean {
  if (!nombresCompatibles(etiqueta, nombre)) return false;
  return etiquetasDelAlumno(nombre, [...etiquetasCurso, etiqueta]).has(normalizarNombrePorPalabras(etiqueta));
}

/** Cómo se nombra la 3ª foto en los mensajes, según lo que tenga el curso. */
function nombreTerceraFoto(fotosCurso: any[]): string {
  const hayDocente = fotosCurso.some((f: any) => f?.categoria === 'docente');
  const hayFamilia = fotosCurso.some((f: any) => f?.categoria === 'familia');
  if (hayFamilia && !hayDocente) return 'la foto con familia y/o amigos';
  if (hayFamilia && hayDocente) return 'la 3ª foto (con la seño o con familia/amigos)';
  return 'la foto con la seño';
}

export async function validarSeleccionFotos(
  supabase: SupabaseClient,
  colegioId: string,
  cursoCodigo: string,
  seleccionCruda: any,
  alumnoNombre: string,
  otrosNombres: string[] = []
): Promise<{ ok: true; seleccion: { individualId: string; grupalId: string; docenteId?: string; otrasIds: string[]; sinFoto?: LugarPack[] } } | { ok: false; error: string }> {
  const sel = seleccionCruda && typeof seleccionCruda === 'object' ? seleccionCruda : {};
  // 06/10: sólo las fotos publicadas (una sin publicar no se puede elegir ni cuenta como 3ª foto).
  // 22/10: paginado (un curso con más de 1000 fotos publicadas no deja afuera la elegida).
  const fotosCurso = await traerTodasLasFilas<any>((desde, hasta) =>
    supabase.from('fotos').select('id, categoria, alumno_nombre').eq('colegio_id', colegioId).eq('codigo_curso', cursoCodigo).not('publicada_at', 'is', null).order('id').range(desde, hasta)
  );
  const porId = new Map<string, any>((fotosCurso || []).map((f: any) => [String(f.id), f]));
  const nombreAlumno = alumnoNombre ? ` de ${alumnoNombre}` : '';
  const cursoTieneTercera = (fotosCurso || []).some((f: any) => esCategoriaTerceraFoto(f.categoria));
  // 22/10 (Pablo): un lugar marcado «no tiene esta foto» (sinFoto) va con otra foto del curso en su lugar
  // (servidor/nucleo/fotosFaltantes.ts; 26/10: ya no queda vacío). Si el curso no tiene 3ª foto, ese lugar no existe.
  const sinFoto = lugaresSinFoto(sel).filter((lugar) => lugar !== 'docente' || cursoTieneTercera);
  const elegida = (lugar: LugarPack): { foto?: any; error?: boolean } => {
    const id = String(sel[`${lugar}Id`] || '');
    if (!id) return {};
    const foto = porId.get(id);
    return foto && categoriaValeEnLugar(foto.categoria, lugar, sinFoto) ? { foto } : { error: true };
  };
  const individual = elegida('individual');
  const grupal = elegida('grupal');
  // 26/10 (Pablo): «el kit sí o sí lleva 3 fotos»: un lugar «no tiene esta foto» vacío no pasa (o espera la foto pedida).
  const lugarVacio = await errorLugarSinFotoVacio(supabase, colegioId, cursoCodigo, [alumnoNombre, ...otrosNombres], sinFoto.filter((l) => !sel[`${l}Id`]), cursoTieneTercera ? 3 : 2, nombreAlumno);
  if (lugarVacio) return { ok: false, error: lugarVacio };
  const faltaIndividual = !individual.foto && (individual.error || !sinFoto.includes('individual'));
  const faltaGrupal = !grupal.foto && (grupal.error || !sinFoto.includes('grupal'));
  if (faltaIndividual || faltaGrupal) {
    return { ok: false, error: `Falta elegir la foto individual y la grupal${nombreAlumno} (o alguna ya no está disponible). Volvé a elegirlas en la galería.` };
  }
  // 06/10: la 3ª foto puede ser con la seño o con familia/amigos (ver esCategoriaTerceraFoto). Es
  // obligatoria sólo si el curso tiene alguna (un curso sin ninguna: el kit va con 2 fotos).
  const docente = elegida('docente');
  if (docente.error || (cursoTieneTercera && !docente.foto && !sinFoto.includes('docente'))) {
    return { ok: false, error: `Falta elegir ${nombreTerceraFoto(fotosCurso || [])}${nombreAlumno} (o ya no está disponible). Volvé a elegirla en la galería.` };
  }
  const delPack = [individual.foto, grupal.foto, docente.foto].filter(Boolean);
  if (delPack.length === 0) {
    return { ok: false, error: `Elegí al menos una foto del curso${nombreAlumno} para el kit.` };
  }
  if (new Set(delPack.map((f: any) => String(f.id))).size !== delPack.length) {
    return { ok: false, error: `Elegiste la misma foto en dos lugares del kit${nombreAlumno}. Elegí una distinta para cada lugar.` };
  }
  const etiquetasCurso = (fotosCurso || []).filter((f: any) => f.categoria === 'individual' && f.alumno_nombre).map((f: any) => f.alumno_nombre);
  // 11/10 (Pablo): una individual sin nombre la puede elegir todo el curso; con nombre, sólo la familia de ese
  // chico (22/10: también si va en el lugar de otra foto que le falta).
  const esDelAlumno = (etiqueta: string) => [alumnoNombre, ...otrosNombres].some((n) => n && etiquetaEsDelAlumno(etiqueta, n, etiquetasCurso));
  if (delPack.some((f: any) => f.categoria === 'individual' && f.alumno_nombre && !esDelAlumno(f.alumno_nombre))) {
    return { ok: false, error: `La foto individual elegida${nombreAlumno} corresponde a otro alumno. Elegí la foto individual de tu hijo/a.` };
  }
  const otrasCrudas: unknown[] = Array.isArray(sel.otrasIds) ? sel.otrasIds : [];
  const otrasIds = Array.from(new Set(otrasCrudas.map((id) => String(id || '')).filter(Boolean)));
  // Auditoría 05/10 (bajo): calcularTotalPedido cobra como mucho MAX_FOTOS_SUELTAS; con más ids se
  // guardaban (y se entregaban en el .zip) fotos que no se cobraron.
  if (otrasIds.length > MAX_FOTOS_SUELTAS) {
    return { ok: false, error: `Se pueden elegir hasta ${MAX_FOTOS_SUELTAS} fotos sueltas${nombreAlumno}. Sacá algunas y volvé a confirmar.` };
  }
  if (otrasIds.some((id) => porId.get(id)?.categoria !== 'patio')) {
    return { ok: false, error: `Alguna de las fotos sueltas elegidas${nombreAlumno} ya no está disponible. Volvé a elegirlas en la galería.` };
  }
  return {
    ok: true,
    seleccion: {
      individualId: individual.foto ? String(individual.foto.id) : '',
      grupalId: grupal.foto ? String(grupal.foto.id) : '',
      ...(docente.foto ? { docenteId: String(docente.foto.id) } : {}),
      otrasIds,
      ...(sinFoto.length > 0 ? { sinFoto } : {}),
    },
  };
}

rutas.post('/api/pedidos/crear', limitarFrecuencia('pedidos-crear', 200, 10 * 60 * 1000), exigirPreciosCargados, exigirPlazoKitImpreso, async (req, res) => {
  try {
    const {
      pedidoId, kitId, carpetasExtras, tutorNombre, tutorTelefono, metodoPago,
      // Auditoría 2026-09-09: datos descriptivos del pedido (acotados); el monto lo calcula SIEMPRE el servidor.
      pedidoFriendlyId, tutorEmail, colegioId, colegioNombre, cursoCodigo, grado, division, turno,
      alumnoNombre, alumnoNumeroLista, codigoAlumno, kitNombre, fotosSeleccionadas, copiasExtras,
      linkDescargaHD, confirmarOtroKit, codigoDescuento,
    } = req.body || {};

    // Auditoría 2026-09-19: la cantidad de "Otras Fotos" sale de la lista de ids (fotosSeleccionadas.otrasIds), no de un número aparte.
    const cantidadFotosSueltas = Array.isArray((fotosSeleccionadas as any)?.otrasIds)
      ? (fotosSeleccionadas as any).otrasIds.length
      : 0;
    const totalCalculado = KITS_COMPRABLES_PORTAL.has(String(kitId)) ? calcularTotalPedido(kitId, carpetasExtras, cantidadFotosSueltas) : null;
    if (totalCalculado === null) {
      return res.status(400).json({ success: false, error: 'Kit no reconocido. No se puede registrar el pedido.' });
    }
    if (!kitPermitidoParaGrado(kitId, grado)) return res.status(400).json({ success: false, error: ERROR_DIGITAL_SECUNDARIA });
    // Marco legal (27/9): no se registra ninguna compra sin la aceptación de los términos vigentes.
    const aceptacion = aceptacionDeTerminos(req);
    if (!aceptacion) return res.status(400).json({ success: false, error: ERROR_TERMINOS_NO_ACEPTADOS });

    const supabase = getServerSupabase();
    if (!supabase) {
      return res.status(500).json({ success: false, error: 'Supabase no configurado en el servidor' });
    }

    // Auditoría 03/10 (crítico 2): "crear pedido" es idempotente por el id que manda el navegador
    // (`pedidoId`, estable durante todo el checkout). Antes un reintento (red lenta, doble toque,
    // respuesta perdida) creaba OTRO pedido: doble cobro y recordatorios por el duplicado. Si la fila
    // ya existe y es del mismo dueño (mismo chico y mismo email), se devuelve exactamente la misma
    // respuesta de éxito (con su llave) sin insertar ni mandar nada; si es de otro, 409 genérico.
    const esUuidPedido = typeof pedidoId === 'string' && /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(pedidoId);
    const reintentoDePedido = async (): Promise<{ status: number; body: Record<string, any> } | null> => {
      if (!esUuidPedido) return null;
      const { data: previo, error: errorPrevio } = await supabase
        .from('pedidos')
        .select('id, pedido_friendly_id, total, alumno_nombre, grupo_pago_id, estado, metodo_pago, cancelado_definitivo, created_at, clave_checkout_hash, familias(nombre, email, whatsapp)')
        .eq('id', pedidoId)
        .maybeSingle();
      if (errorPrevio) throw errorPrevio;
      if (!previo) return null;
      if (
        previo.grupo_pago_id ||
        !mismoDuenoDePedido(previo as any, { email: tutorEmail, telefono: tutorTelefono, nombre: tutorNombre, alumno: alumnoNombre }) ||
        !claveCheckoutValida(previo as any, req.body?.claveCheckout)
      ) {
        return { status: 409, body: { success: false, error: 'No pudimos registrar el pedido. Probá de nuevo.' } };
      }
      // Auditoría 05/10 (bajo): un pedido cancelado definitivo (por el fotógrafo, un reembolso o una
      // reserva reemplazada) ya no se "reintenta" como si estuviera vivo: antes se devolvía 200 con su
      // llave y la familia seguía a una pantalla de pago que nunca iba a cobrarse.
      if (previo.cancelado_definitivo) {
        return { status: 409, body: { success: false, codigo: 'PEDIDO_CANCELADO', error: 'Este pedido fue cancelado y ya no se puede pagar. Recargá la página y armá el pedido de nuevo.' } };
      }
      // Auditoría 03/10 (2ª vuelta): si la familia volvió atrás y confirmó el mismo checkout con OTRO
      // medio de pago, se actualiza el medio (igual que /cambiar-metodo-pago) antes de responder; si
      // no, el pedido quedaba con el medio viejo (p. ej. transferencia con su plazo de 48 h).
      const metodoReintento = ['mercadopago', 'transferencia', 'efectivo', 'nave'].includes(metodoPago) ? metodoPago : 'mercadopago';
      if (previo.estado === 'pendiente_pago' && !previo.cancelado_definitivo && previo.metodo_pago !== metodoReintento) {
        const { error: errorMetodo } = await aplicarMetodoPagoPendiente(supabase, 'id', previo.id, metodoReintento);
        if (errorMetodo) throw errorMetodo;
      }
      return { status: 200, body: { success: true, pedidoId: previo.id, pedidoFriendlyId: previo.pedido_friendly_id, total: Number(previo.total) || 0, accesoToken: tokenAccesoPedido(previo.id), ...(previo.metodo_pago === 'bonificado' ? { bonificado: true } : {}) } };
    };
    const reintento = await reintentoDePedido();
    if (reintento) return res.status(reintento.status).json(reintento.body);

    // Ver buscarColegioReal: un pedido con un colegio inexistente nunca cruza con sus fotos.
    const colegioReal = await buscarColegioReal(supabase, colegioId);
    if (!colegioReal) {
      return res.status(400).json({ success: false, error: ERROR_COLEGIO_NO_VALIDO });
    }
    const cursoMal = await cursoDistintoAlInscripto(supabase, tutorEmail, [{ colegioId: colegioReal.id, cursoCodigo: determinarCodigoCursoServidor(String(grado || ''), String(turno || ''), String(division || '')), alumnoNombre: String(alumnoNombre ?? '').trim().slice(0, 200) }]);
    if (cursoMal) return res.status(409).json(respuestaCursoCambiado(cursoMal)); // 14/10: código viejo guardado en el navegador (ver cursoInscripto.ts)
    // Auditoría 03/10 (alto 8): si el chico ya tiene un kit pagado se avisa antes de registrar otro
    // (contrato con el portal: 409 codigo KIT_YA_PAGADO; si la familia confirma, vuelve con
    // confirmarOtroKit: true).
    if (confirmarOtroKit !== true) {
      const conKit = await alumnosConKitPagado(supabase, [{
        colegioId: colegioReal.id,
        cursoCodigo: determinarCodigoCursoServidor(String(grado || ''), String(turno || ''), String(division || '')),
        alumnoNombre: String(alumnoNombre ?? '').trim().slice(0, 200),
      }]);
      if (conKit.length > 0) return res.status(409).json(respuestaKitYaPagado(conKit));
    }

    // Recorta cualquier texto libre a una longitud razonable (un campo desbordado no llena la base de basura).
    const acotar = (valor: unknown, maxLen: number): string => String(valor ?? '').trim().slice(0, maxLen);
    // Sólo acepta objetos planos chicos (no arrays, no anidados demasiado grandes) para las
    // columnas jsonb — si viene otra cosa, se guarda un objeto vacío en vez de fallar el pedido.
    const acotarJson = (valor: unknown): Record<string, any> => {
      if (!valor || typeof valor !== 'object' || Array.isArray(valor)) return {};
      const entradas = Object.entries(valor as Record<string, any>).slice(0, 20);
      const limpio: Record<string, any> = {};
      for (const [clave, val] of entradas) {
        if (typeof val === 'string') limpio[clave] = val.slice(0, 200);
        else if (typeof val === 'number' && Number.isFinite(val)) limpio[clave] = val;
        else if (typeof val === 'boolean') limpio[clave] = val;
        else if (Array.isArray(val)) {
          // Auditoría 19/09: sin esta rama los arrays (p. ej. "otrasIds", fotos sueltas pagadas) se descartaban en silencio.
          const limpioArray = val
            .filter((item) => typeof item === 'string')
            .map((item) => String(item).slice(0, 200))
            .slice(0, 50);
          if (limpioArray.length > 0) limpio[clave] = limpioArray;
        }
      }
      return limpio;
    };

    // 22/10: código de descuento (servidor/pagos/descuentos.ts), validado ANTES de escribir nada: sólo sobre el kit
    // (en el carrito, sobre cada kit, un solo uso); el monto lo calcula el servidor.
    const { descuento, error: errorDescuento } = await prepararDescuento(supabase, codigoDescuento, req.ip);
    if (errorDescuento) return res.status(400).json({ success: false, codigo: 'DESCUENTO_INVALIDO', error: errorDescuento });
    let familiaId: string | null = null;
    const nombreTutor = String(tutorNombre || '').trim();
    const telefonoTutor = String(tutorTelefono || '').trim();
    const emailTutor = acotar(tutorEmail, 200);
    if (nombreTutor || telefonoTutor || emailTutor) {
      // OJO: familias.colegio_id es un uuid de un modelo viejo: no se toca (el colegio va en pedidos.colegio_id).
      const { data: famData, error: famError } = await supabase
        .from('familias')
        .insert({
          nombre: (nombreTutor || 'Familia').slice(0, 200),
          whatsapp: telefonoTutor.slice(0, 40),
          email: emailTutor.includes('@') ? emailTutor : null,
        })
        .select('id')
        .single();
      if (!famError && famData) familiaId = famData.id;
    }

    const tipoKit = kitId === 'kit-digital' ? 'solo_digital' : 'impreso_digital';
    const extrasValidados = carpetasExtrasValidas(String(kitId), carpetasExtras);
    const metodosValidos = ['mercadopago', 'transferencia', 'efectivo', 'nave'];
    const metodoPagoValido = metodosValidos.includes(metodoPago) ? metodoPago : 'mercadopago';
    const cursoCodigoServidor = determinarCodigoCursoServidor(String(grado || ''), String(turno || ''), String(division || ''));
    const validacionFotos = await validarSeleccionFotos(supabase, colegioReal.id, cursoCodigoServidor, fotosSeleccionadas, acotar(alumnoNombre, 200));
    if (!validacionFotos.ok) {
      return res.status(400).json({ success: false, error: (validacionFotos as { error: string }).error });
    }
    // El total se recalcula con la selección ya validada (fotos sueltas sin repetir).
    const totalFinal = (calcularTotalPedido(String(kitId), carpetasExtras, validacionFotos.seleccion.otrasIds.length) as number) - (descuento ? descuentoDeKit(String(kitId), descuento.porcentaje, descuento.sinTopeImpreso) : 0);
    // Auditoría 2026-09-22 (Pablo: "¿por qué el código minilab no figura?"): mismo refuerzo que
    // ya se aplicó a curso_codigo — codigo_alumno y alumno_numero_lista se calculan siempre acá,
    // nunca se acepta lo que mande el navegador (ver `calcularCodigoAlumnoServidor` y
    // `obtenerNumeroListaSecuencial` más arriba en este archivo).
    const numeroListaServidor = await obtenerNumeroListaSecuencial(supabase, cursoCodigoServidor, colegioReal.id);
    const codigoAlumnoServidor = calcularCodigoAlumnoServidor(cursoCodigoServidor, numeroListaServidor, acotar(alumnoNombre, 200));

    const filaPedido: Record<string, any> = {
      ...aceptacion,
      clave_checkout_hash: hashClaveCheckout(req.body?.claveCheckout),
      familia_id: familiaId,
      tipo_kit: tipoKit,
      // Nace SIEMPRE en pendiente_pago — nunca se acepta un "estado" mandado por el cliente.
      // Sólo el webhook de Mercado Pago o el panel de admin (con sesión) lo pueden pasar a
      // "pagado". Ver comentario de auditoría arriba de este endpoint.
      estado: 'pendiente_pago',
      total: totalFinal,
      // Un kit sólo digital no lleva carpeta impresa.
      carpetas_impresas: kitId === 'kit-clasico' ? extrasValidados + 1 : 0,
      metodo_pago: metodoPagoValido,
      pedido_friendly_id: await asegurarFriendlyIdUnico(supabase, pedidoFriendlyId, new Set()),
      colegio_id: colegioReal.id,
      colegio_nombre: colegioReal.nombre,
      // 21/09: el curso se recalcula siempre con determinarCodigoCursoServidor (nunca el `cursoCodigo` del navegador).
      curso_codigo: cursoCodigoServidor,
      grado: acotar(grado, 60) || null,
      division: acotar(division, 60) || null,
      turno: acotar(turno, 60) || null,
      alumno_nombre: acotar(alumnoNombre, 200) || null,
      alumno_numero_lista: numeroListaServidor,
      codigo_alumno: codigoAlumnoServidor,
      // Auditoría 05/10 (bajo): el nombre del kit sale del id validado (lo que se cobra), no del texto
      // que manda el navegador (podía decir "Kit Impreso" en un pedido cobrado como Solo Digital).
      kit_nombre: NOMBRES_KITS_RESERVA[String(kitId)] || acotar(kitNombre, 120) || null,
      fotos_seleccionadas: validacionFotos.seleccion,
      copias_extras: copiasExtrasServidor(extrasValidados, validacionFotos.seleccion.otrasIds.length),
      // Auditoría 2026-09-23: el link de descarga HD lo genera SIEMPRE el servidor al confirmarse
      // el pago. Antes se aceptaba el que mandara el navegador: un pedido podía nacer con un link
      // cualquiera, el panel lo mostraba como "HD enviado" y el cron de reintento lo salteaba.
      link_descarga_hd: null,
      ...columnasDescuento(descuento, String(kitId)),
      ...columnasSiQuedaSinCargo(totalFinal, descuento), // 22/10: en $0 por un código nace pagado («bonificado»)
    };
    void linkDescargaHD; void copiasExtras;
    // Se respeta el UUID generado en el navegador (para poder correlacionarlo con el tracking
    // local y con Mercado Pago vía external_reference) sólo si tiene forma de UUID válido.
    if (esUuidPedido) {
      // Auditoría 30/9: la llave de un pedido y la de un grupo de pago se calculan igual, así que un
      // id elegido igual al grupo_pago_id de otra familia le daba la llave de ese grupo.
      const { data: choca, error: errorChoca } = await supabase.from('pedidos').select('id').eq('grupo_pago_id', pedidoId).limit(1);
      if (errorChoca) throw errorChoca;
      if (choca && choca.length > 0) return res.status(409).json({ success: false, error: 'No pudimos registrar el pedido. Probá de nuevo.' });
      filaPedido.id = pedidoId;
    }

    if (!(await consumirUsoDescuento(supabase, descuento))) return res.status(400).json({ success: false, codigo: 'DESCUENTO_INVALIDO', error: ERROR_DESCUENTO_INVALIDO });
    const { data: insertados, error: errorPedido } = await insertarPedidosConReintento(supabase, [filaPedido]).catch(async (e) => { await devolverUsoDescuento(supabase, descuento); throw e; });
    if (errorPedido) {
      await devolverUsoDescuento(supabase, descuento);
      // Dos envíos simultáneos con el mismo id: el segundo choca con la clave primaria y se responde
      // como un reintento del primero.
      if (errorPedido.code === '23505') {
        const enCarrera = await reintentoDePedido();
        if (enCarrera) return res.status(enCarrera.status).json(enCarrera.body);
      }
      throw errorPedido;
    }
    const pedidoCreado = insertados![0];
    await cancelarReservasSinPagarDe(supabase, [filaPedido as any], tutorEmail);
    if (filaPedido.metodo_pago === 'transferencia') await enviarAvisoTransferenciaRegistrada(supabase, 'id', pedidoCreado.id); // 14/10/2026: datos y link al toque
    if (filaPedido.metodo_pago === 'bonificado') await entregarSinCargo(supabase, [pedidoCreado.id]);

    return res.json({ success: true, pedidoId: pedidoCreado.id, pedidoFriendlyId: filaPedido.pedido_friendly_id, total: totalFinal, accesoToken: tokenAccesoPedido(pedidoCreado.id), ...(filaPedido.metodo_pago === 'bonificado' ? { bonificado: true } : {}) });
  } catch (err: any) {
    console.error('Error al registrar pedido:', err);
    return res.status(500).json({ success: false, error: err?.message || 'Error al registrar el pedido' });
  }
});

// 16/09 (Pablo: «múltiple pedido, un solo pago»): como /api/pedidos/crear, pero una fila por hijo con el mismo
// `grupo_pago_id` (lo que el webhook de MP/Nave marca pagado de una vez). Monto siempre del servidor; nace pendiente
// de pago (salvo carrito entero en $0 con código de descuento, 22/10).
rutas.post('/api/pedidos/crear-multiple', limitarFrecuencia('pedidos-crear-multiple', 200, 10 * 60 * 1000), exigirPreciosCargados, exigirPlazoKitImpreso, async (req, res) => {
  try {
    const { tutorNombre, tutorTelefono, tutorEmail, items, confirmarOtroKit, codigoDescuento } = req.body || {};

    // Desde el 25/9 puede venir un solo hijo con fotos (la reserva de un hermano se suma después: grupoPagoId en /api/reservas/crear).
    if (!Array.isArray(items) || items.length < 1 || items.length > 10) {
      return res.status(400).json({
        success: false,
        error: 'El carrito debe tener entre 1 y 10 hijos.',
      });
    }
    // Marco legal (27/9): ver /api/pedidos/crear.
    const aceptacion = aceptacionDeTerminos(req);
    if (!aceptacion) return res.status(400).json({ success: false, error: ERROR_TERMINOS_NO_ACEPTADOS });

    const supabase = getServerSupabase();
    if (!supabase) {
      return res.status(500).json({ success: false, error: 'Supabase no configurado en el servidor' });
    }

    // Auditoría 03/10 (crítico 2): idempotente por los ids que manda el navegador para cada hijo
    // (`items[i].pedidoId`, estables durante todo el checkout). Si el carrito ya quedó registrado
    // (todos los ids, mismo grupo de pago, mismo dueño), se devuelve la misma respuesta de éxito con
    // el grupo y su llave, sin insertar ni mandar nada. Si algún id es de otra familia: 409 genérico.
    const idsNavegador: (string | null)[] = items.map((item: any) =>
      typeof item?.pedidoId === 'string' && /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(item.pedidoId) ? item.pedidoId : null
    );
    const reintentoDeCarrito = async (): Promise<{ status: number; body: Record<string, any> } | null> => {
      const ids = idsNavegador.filter((id): id is string => Boolean(id));
      if (ids.length === 0) return null;
      const { data: previos, error: errorPrevios } = await supabase
        .from('pedidos')
        .select('id, pedido_friendly_id, total, alumno_nombre, grupo_pago_id, estado, metodo_pago, cancelado_definitivo, created_at, clave_checkout_hash, familias(nombre, email, whatsapp)')
        .in('id', ids);
      if (errorPrevios) throw errorPrevios;
      if (!previos || previos.length === 0) return null;
      const grupo = (previos[0] as any).grupo_pago_id;
      const filasEnOrden = idsNavegador.map((id) => (previos as any[]).find((p: any) => p.id === id));
      const coincide =
        Boolean(grupo) &&
        new Set(ids).size === items.length &&
        previos.length === items.length &&
        (previos as any[]).every((p: any) => p.grupo_pago_id === grupo) &&
        (previos as any[]).every((p: any) => claveCheckoutValida(p, req.body?.claveCheckout)) &&
        items.every((item: any, i: number) => filasEnOrden[i] && mismoDuenoDePedido(filasEnOrden[i], { email: tutorEmail, telefono: tutorTelefono, nombre: tutorNombre, alumno: item?.alumnoNombre }));
      if (!coincide) return { status: 409, body: { success: false, error: 'No pudimos registrar el pedido. Probá de nuevo.' } };
      // Auditoría 05/10 (bajo): carrito con alguna fila cancelada definitiva → no se reintenta como vivo.
      if ((previos as any[]).some((p: any) => p.cancelado_definitivo)) {
        return { status: 409, body: { success: false, codigo: 'PEDIDO_CANCELADO', error: 'Este pedido fue cancelado y ya no se puede pagar. Recargá la página y armá el pedido de nuevo.' } };
      }
      // Auditoría 03/10 (2ª vuelta): mismo carrito confirmado con otro medio de pago → se actualiza el
      // medio de todo el grupo (igual que /cambiar-metodo-pago) si sigue entero pendiente de pago.
      const metodoReintento = ['mercadopago', 'transferencia', 'efectivo', 'nave'].includes(items[0]?.metodoPago) ? items[0].metodoPago : 'mercadopago';
      if (
        (previos as any[]).every((p: any) => p.estado === 'pendiente_pago' && !p.cancelado_definitivo) &&
        (previos as any[]).some((p: any) => p.metodo_pago !== metodoReintento)
      ) {
        const { error: errorMetodo } = await aplicarMetodoPagoPendiente(supabase, 'grupo_pago_id', grupo, metodoReintento);
        if (errorMetodo) throw errorMetodo;
      }
      return {
        status: 200,
        body: {
          success: true,
          grupoPagoId: grupo,
          pedidoIds: filasEnOrden.map((f: any) => f.id),
          pedidoFriendlyIds: filasEnOrden.map((f: any) => f.pedido_friendly_id),
          total: filasEnOrden.reduce((acc: number, f: any) => acc + (Number(f.total) || 0), 0),
          accesoToken: tokenAccesoPedido(grupo),
          ...((previos as any[]).every((p: any) => p.metodo_pago === 'bonificado') ? { bonificado: true } : {}),
        },
      };
    };
    const reintento = await reintentoDeCarrito();
    if (reintento) return res.status(reintento.status).json(reintento.body);

    const acotar = (valor: unknown, maxLen: number): string => String(valor ?? '').trim().slice(0, maxLen);

    // Ver buscarColegioReal: cada hijo del carrito tiene que estar en un colegio real.
    const colegiosReales = new Map<string, { id: string; nombre: string }>();
    for (const item of items) {
      const clave = String(item?.colegioId || '');
      if (colegiosReales.has(clave)) continue;
      const colegio = await buscarColegioReal(supabase, clave);
      if (!colegio) {
        return res.status(400).json({ success: false, error: ERROR_COLEGIO_NO_VALIDO });
      }
      colegiosReales.set(clave, colegio);
    }
    const cursoMalCarrito = await cursoDistintoAlInscripto(supabase, tutorEmail, items.map((item: any) => ({ colegioId: colegiosReales.get(String(item?.colegioId || ''))!.id, cursoCodigo: determinarCodigoCursoServidor(String(item?.grado || ''), String(item?.turno || ''), String(item?.division || '')), alumnoNombre: acotar(item?.alumnoNombre, 200) })));
    if (cursoMalCarrito) return res.status(409).json(respuestaCursoCambiado(cursoMalCarrito)); // 14/10: ver cursoInscripto.ts
    // Auditoría 03/10 (alto 8): ver /api/pedidos/crear (409 KIT_YA_PAGADO salvo confirmarOtroKit).
    if (confirmarOtroKit !== true) {
      const conKit = await alumnosConKitPagado(supabase, items.map((item: any) => ({
        colegioId: colegiosReales.get(String(item?.colegioId || ''))!.id,
        cursoCodigo: determinarCodigoCursoServidor(String(item?.grado || ''), String(item?.turno || ''), String(item?.division || '')),
        alumnoNombre: acotar(item?.alumnoNombre, 200),
      })));
      if (conKit.length > 0) return res.status(409).json(respuestaKitYaPagado(conKit));
    }

    // Un total válido para CADA ítem, calculado en el servidor: un kit no reconocido corta todo el carrito antes de escribir.
    // Auditoría 2026-09-19: como en /api/pedidos/crear, las "Otras Fotos" se cuentan de la lista de ids de cada ítem.
    const cantidadFotosSueltasDe = (item: any): number =>
      Array.isArray(item?.fotosSeleccionadas?.otrasIds) ? item.fotosSeleccionadas.otrasIds.length : 0;

    let totalGrupo = 0;
    for (const item of items) {
      const totalItem = KITS_COMPRABLES_PORTAL.has(String(item?.kitId)) ? calcularTotalPedido(item?.kitId, item?.carpetasExtras, cantidadFotosSueltasDe(item)) : null;
      if (totalItem === null) {
        return res.status(400).json({
          success: false,
          error: `Kit no reconocido para ${item?.alumnoNombre || 'uno de los hijos'}. No se puede registrar el carrito.`,
        });
      }
      if (!kitPermitidoParaGrado(item?.kitId, item?.grado)) {
        return res.status(400).json({ success: false, error: `${ERROR_DIGITAL_SECUNDARIA} (${acotar(item?.alumnoNombre, 200) || 'uno de los hijos'})` });
      }
      totalGrupo += totalItem;
    }

    // 22/10: código de descuento (servidor/pagos/descuentos.ts), validado ANTES de escribir nada: sólo sobre el kit
    // (en el carrito, un uso por kit descontado desde el 24/10); el monto lo calcula el servidor.
    const { descuento, error: errorDescuento } = await prepararDescuento(supabase, codigoDescuento, req.ip);
    if (errorDescuento) return res.status(400).json({ success: false, codigo: 'DESCUENTO_INVALIDO', error: errorDescuento });
    let familiaId: string | null = null;
    const nombreTutor = String(tutorNombre || '').trim();
    const telefonoTutor = String(tutorTelefono || '').trim();
    const emailTutor = acotar(tutorEmail, 200);
    if (nombreTutor || telefonoTutor || emailTutor) {
      const { data: famData, error: famError } = await supabase
        .from('familias')
        .insert({
          nombre: (nombreTutor || 'Familia').slice(0, 200),
          whatsapp: telefonoTutor.slice(0, 40),
          email: emailTutor.includes('@') ? emailTutor : null,
        })
        .select('id')
        .single();
      if (!famError && famData) familiaId = famData.id;
    }

    // Referencia compartida por todos los pedidos de este carrito — es lo que Mercado Pago/Nave
    // nos va a devolver como external_reference / external_payment_id de un único pago.
    const grupoPagoId = typeof crypto !== 'undefined' && crypto.randomUUID
      ? crypto.randomUUID()
      : `GRP-${Date.now()}-${Math.floor(Math.random() * 1e6)}`;

    const metodosValidos = ['mercadopago', 'transferencia', 'efectivo', 'nave'];
    const filasPedido: Record<string, any>[] = [];
    // Auditoría 2026-09-22: `codigo_alumno` se calcula siempre acá (código Minilab). El contador va por curso
    // DENTRO del carrito, para que dos hermanos de la misma sección (mellizos) no repitan número.
    const numeroListaBasePorCurso: Record<string, number> = {};
    const friendlyIdsUsados = new Set<string>();
    // Auditoría 2026-09-26 (M5/M6): la selección de fotos de CADA hijo se valida contra su curso
    // antes de escribir nada; el total se recalcula con las fotos sueltas ya validadas.
    const seleccionesValidadas: any[] = [];
    for (const item of items) {
      const cursoItem = determinarCodigoCursoServidor(String(item?.grado || ''), String(item?.turno || ''), String(item?.division || ''));
      const colegioItem = colegiosReales.get(String(item?.colegioId || ''))!;
      const validacion = await validarSeleccionFotos(supabase, colegioItem.id, cursoItem, item?.fotosSeleccionadas, acotar(item?.alumnoNombre, 200));
      if (!validacion.ok) return res.status(400).json({ success: false, error: (validacion as { error: string }).error });
      seleccionesValidadas.push(validacion.seleccion);
    }
    totalGrupo = 0; const conDescuento = kitsConDescuento(items.map((it: any) => String(it?.kitId)), descuento); // 24/10: un uso por kit
    for (const [indiceItem, item] of items.entries()) {
      const totalItem = (calcularTotalPedido(item?.kitId, item?.carpetasExtras, seleccionesValidadas[indiceItem].otrasIds.length) as number) - (descuento && conDescuento.has(indiceItem) ? descuentoDeKit(String(item?.kitId), descuento.porcentaje, descuento.sinTopeImpreso) : 0);
      totalGrupo += totalItem;
      const tipoKit = item?.kitId === 'kit-digital' ? 'solo_digital' : 'impreso_digital';
      const extrasValidados = carpetasExtrasValidas(String(item?.kitId), item?.carpetasExtras);
      const metodoPagoValida = metodosValidos.includes(item?.metodoPago) ? item.metodoPago : 'mercadopago';
      const cursoCodigoServidor = determinarCodigoCursoServidor(String(item?.grado || ''), String(item?.turno || ''), String(item?.division || ''));
      // 08/10: la cuenta es por colegio + curso (el mismo código de curso existe en varios colegios).
      const claveNumero = claveCursoNumeroLista(colegiosReales.get(String(item?.colegioId || ''))!.id, cursoCodigoServidor);
      if (numeroListaBasePorCurso[claveNumero] === undefined) {
        numeroListaBasePorCurso[claveNumero] = await obtenerNumeroListaSecuencial(supabase, cursoCodigoServidor, colegiosReales.get(String(item?.colegioId || ''))!.id) - 1;
      }
      const numeroListaServidor = ++numeroListaBasePorCurso[claveNumero];
      const codigoAlumnoServidor = calcularCodigoAlumnoServidor(cursoCodigoServidor, numeroListaServidor, acotar(item?.alumnoNombre, 200));

      const fila: Record<string, any> = {
        ...aceptacion,
        clave_checkout_hash: hashClaveCheckout(req.body?.claveCheckout),
        familia_id: familiaId,
        tipo_kit: tipoKit,
        estado: 'pendiente_pago',
        total: totalItem,
        carpetas_impresas: item?.kitId === 'kit-clasico' ? extrasValidados + 1 : 0,
        metodo_pago: metodoPagoValida,
        grupo_pago_id: grupoPagoId,
        pedido_friendly_id: await asegurarFriendlyIdUnico(supabase, item?.pedidoFriendlyId, friendlyIdsUsados),
        colegio_id: colegiosReales.get(String(item?.colegioId || ''))!.id,
        colegio_nombre: colegiosReales.get(String(item?.colegioId || ''))!.nombre,
        // Auditoría 2026-09-21: mismo refuerzo que en /api/pedidos/crear — nunca se confía en el
        // curso_codigo que manda el cliente, se deriva siempre de grado/turno/división acá.
        curso_codigo: cursoCodigoServidor,
        grado: acotar(item?.grado, 60) || null,
        division: acotar(item?.division, 60) || null,
        turno: acotar(item?.turno, 60) || null,
        alumno_nombre: acotar(item?.alumnoNombre, 200) || null,
        alumno_numero_lista: numeroListaServidor,
        codigo_alumno: codigoAlumnoServidor,
        // Auditoría 05/10 (bajo): nombre del kit según el id validado, no según el navegador.
        kit_nombre: NOMBRES_KITS_RESERVA[String(item?.kitId)] || acotar(item?.kitNombre, 120) || null,
        fotos_seleccionadas: seleccionesValidadas[indiceItem],
        copias_extras: copiasExtrasServidor(extrasValidados, seleccionesValidadas[indiceItem].otrasIds.length),
        link_descarga_hd: null, // ver /api/pedidos/crear: el link lo genera sólo el servidor
        ...columnasDescuento(conDescuento.has(indiceItem) ? descuento : null, String(item?.kitId)),
      };
      if (typeof item?.pedidoId === 'string' && /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(item.pedidoId)) {
        fila.id = item.pedidoId;
      }
      filasPedido.push(fila);
    }
    // Auditoría 03/10 noche (M1): igual que /api/pedidos/crear y /api/reservas/crear, ningún id
    // elegido por el navegador puede coincidir con el grupo de pago de otra familia (si no, cuando
    // esa familia pagaba su grupo, el pago se aplicaba a ESTA fila) ni repetirse dentro del carrito.
    const idsElegidos = filasPedido.map((f: any) => f.id).filter(Boolean) as string[];
    if (idsElegidos.length > 0) {
      if (new Set(idsElegidos).size !== idsElegidos.length) {
        return res.status(400).json({ success: false, error: 'No pudimos registrar el pedido. Probá de nuevo.' });
      }
      const { data: choca, error: errorChoca } = await supabase.from('pedidos').select('id').in('grupo_pago_id', idsElegidos).limit(1);
      if (errorChoca) throw errorChoca;
      if (choca && choca.length > 0) return res.status(409).json({ success: false, error: 'No pudimos registrar el pedido. Probá de nuevo.' });
    }

    // 22/10: carrito entero en $0 (y sin reservas que se sumen después): nace pagado, «bonificado».
    // Revisión 22/10: un kit en $0 no puede ir con otros que se pagan (la pasarela no cobra filas en $0).
    if (descuento && filasPedido.some((f) => f.total === 0) && (totalGrupo > 0 || req.body?.sumaReservas === true)) {
      return res.status(400).json({ success: false, codigo: 'DESCUENTO_COMBINADO', error: ERROR_DESCUENTO_COMBINADO });
    }
    for (const f of filasPedido) Object.assign(f, columnasSiQuedaSinCargo(totalGrupo, descuento));
    if (!(await consumirUsoDescuento(supabase, descuento, conDescuento.size))) return res.status(400).json({ success: false, codigo: 'DESCUENTO_INVALIDO', error: ERROR_DESCUENTO_INVALIDO });
    const { data: pedidosCreados, error: errorPedidos } = await insertarPedidosConReintento(supabase, filasPedido).catch(async (e) => { await devolverUsoDescuento(supabase, descuento, conDescuento.size); throw e; });
    if (errorPedidos) {
      await devolverUsoDescuento(supabase, descuento, conDescuento.size);
      // Dos envíos simultáneos del mismo carrito: el segundo choca con la clave primaria.
      if (errorPedidos.code === '23505') {
        const enCarrera = await reintentoDeCarrito();
        if (enCarrera) return res.status(enCarrera.status).json(enCarrera.body);
      }
      throw errorPedidos;
    }
    await cancelarReservasSinPagarDe(supabase, filasPedido as any[], tutorEmail);
    // 14/10/2026: email con datos y link al toque; si después se suman reservas al grupo, sale desde /api/reservas/crear (con el total final).
    if (req.body?.sumaReservas !== true && filasPedido.every((f) => f.metodo_pago === 'transferencia')) await enviarAvisoTransferenciaRegistrada(supabase, 'grupo_pago_id', grupoPagoId);
    const sinCargo = filasPedido.every((f) => f.metodo_pago === 'bonificado');
    if (sinCargo) await entregarSinCargo(supabase, (pedidosCreados || []).map((p: any) => p.id));

    return res.json({
      success: true,
      grupoPagoId,
      pedidoIds: (pedidosCreados || []).map((p: any) => p.id),
      // Mismo orden que `items`: el número amigable final de cada hijo (puede diferir del que
      // propuso el navegador si ese ya estaba usado — ver asegurarFriendlyIdUnico).
      pedidoFriendlyIds: filasPedido.map((f) => f.pedido_friendly_id),
      total: totalGrupo,
      accesoToken: tokenAccesoPedido(grupoPagoId),
      ...(sinCargo ? { bonificado: true } : {}),
    });
  } catch (err: any) {
    console.error('Error al registrar carrito multi-hijo:', err);
    return res.status(500).json({ success: false, error: err?.message || 'Error al registrar el carrito' });
  }
});

// ==============================================================================
// PAGO ANTICIPADO — "Reservá tu kit ahora, elegí las fotos después" (pedido de Pablo, 24/9:
// "muchos padres están acostumbrados a pagar por adelantado"). La familia paga el kit antes de
// que se suban las fotos de su curso: el pedido nace con seleccion_pendiente = true y sin fotos.
// Al pagarse le llega un email de "reserva confirmada" (no el de fotos HD). Cuando las fotos están
// online, las elige desde el portal sin volver a pagar (/api/reservas/:id/elegir-fotos): recién
// ahí se arma el .zip HD, se le manda el email con la descarga y el pedido pasa al laboratorio.
// ==============================================================================
const NOMBRES_KITS_RESERVA: Record<string, string> = {
  'kit-clasico': 'Kit Impreso + Digital',
  'kit-digital': 'Solo Digital HD',
};

rutasReservas.post('/api/reservas/crear', limitarFrecuencia('reservas-crear', 150, 10 * 60 * 1000), exigirPreciosCargados, exigirPlazoKitImpreso, async (req: Request, res: Response) => {
  try {
    const { tutorNombre, tutorTelefono, tutorEmail, metodoPago, items, grupoPagoId: grupoExistente, confirmarOtroKit } = req.body || {};
    if (!Array.isArray(items) || items.length < 1 || items.length > 10) {
      return res.status(400).json({ success: false, error: 'Elegí el kit de al menos un hijo/a.' });
    }
    // Marco legal (27/9): ver /api/pedidos/crear.
    const aceptacion = aceptacionDeTerminos(req);
    if (!aceptacion) return res.status(400).json({ success: false, error: ERROR_TERMINOS_NO_ACEPTADOS });
    const emailTutor = String(tutorEmail || '').trim().toLowerCase().slice(0, 200);
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(emailTutor)) {
      return res.status(400).json({ success: false, error: 'Necesitamos un email válido para confirmarte la reserva.' });
    }
    const metodosValidos = ['mercadopago', 'transferencia', 'nave'];
    const metodo = metodosValidos.includes(metodoPago) ? metodoPago : 'mercadopago';

    const supabase = getServerSupabase();
    if (!supabase) return res.status(500).json({ success: false, error: 'Supabase no configurado en el servidor' });

    // Auditoría 03/10: idempotente por `items[i].reservaId` (UUID estable por intento que manda el
    // navegador, ver src/utils/checkoutEstable.ts), igual que /api/pedidos/crear-multiple. Antes un
    // reintento (respuesta perdida, doble toque) anulaba la reserva recién creada (paso "reserva
    // vieja sin pagar" de abajo) y creaba otra: si la familia ya estaba pagando la primera, quedaba un
    // pago huérfano. Si todas las filas ya existen, son reservas del mismo grupo y del mismo dueño, se
    // devuelve la misma respuesta de éxito sin tocar nada (ni números amigables nuevos); si algún id
    // es de otra familia o no coincide: 409 genérico. Este chequeo va ANTES de cualquier escritura.
    const UUID_RESERVA_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
    const idsReserva: (string | null)[] = items.map((item: any) =>
      typeof item?.reservaId === 'string' && UUID_RESERVA_RE.test(item.reservaId) ? item.reservaId : null
    );
    const reintentoDeReserva = async (): Promise<{ status: number; body: Record<string, any> } | null> => {
      const ids = idsReserva.filter((id): id is string => Boolean(id));
      if (ids.length === 0) return null;
      const { data: previos, error: errorPrevios } = await supabase
        .from('pedidos')
        .select('id, pedido_friendly_id, total, alumno_nombre, grupo_pago_id, seleccion_pendiente, estado, cancelado_definitivo, created_at, clave_checkout_hash, familias(nombre, email, whatsapp)')
        .in('id', ids);
      if (errorPrevios) throw errorPrevios;
      if (!previos || previos.length === 0) return null;
      const grupo = (previos[0] as any).grupo_pago_id;
      const filasEnOrden = idsReserva.map((id) => (previos as any[]).find((p: any) => p.id === id));
      const coincide =
        Boolean(grupo) &&
        (!grupoExistente || String(grupoExistente) === grupo) &&
        new Set(ids).size === items.length &&
        previos.length === items.length &&
        (previos as any[]).every((p: any) => p.grupo_pago_id === grupo && p.seleccion_pendiente === true) &&
        (previos as any[]).every((p: any) => claveCheckoutValida(p, req.body?.claveCheckout)) &&
        items.every((item: any, i: number) => filasEnOrden[i] && mismoDuenoDePedido(filasEnOrden[i], { email: emailTutor, telefono: tutorTelefono, nombre: tutorNombre, alumno: String(item?.alumnoNombre || '').trim().slice(0, 200) }));
      if (!coincide) return { status: 409, body: { success: false, error: 'No pudimos registrar la reserva. Volvé a intentarlo.' } };
      // Auditoría 05/10 (bajo): una reserva reemplazada o cancelada (cancelado_definitivo) no se reintenta.
      if ((previos as any[]).some((p: any) => p.cancelado_definitivo)) {
        return { status: 409, body: { success: false, codigo: 'PEDIDO_CANCELADO', error: 'Esta reserva fue cancelada o reemplazada. Recargá la página y volvé a reservar.' } };
      }
      return {
        status: 200,
        body: {
          success: true,
          grupoPagoId: grupo,
          total: filasEnOrden.reduce((acc: number, f: any) => acc + (Number(f.total) || 0), 0),
          pedidoFriendlyIds: filasEnOrden.map((f: any) => f.pedido_friendly_id),
          accesoToken: tokenAccesoPedido(grupo),
        },
      };
    };
    const reintento = await reintentoDeReserva();
    if (reintento) return res.status(reintento.status).json(reintento.body);
    // Auditoría 03/10 noche (M1): sumar una reserva a una compra existente exige la llave de esa
    // compra (antes alcanzaba con su id y la respuesta devolvía su llave: con eso se podían cambiar
    // el medio de pago y bajar el HD de los hijos de otra familia). Va antes de cualquier escritura.
    if (grupoExistente && !tokenAccesoValido(llaveRecibida(req), [String(grupoExistente)])) {
      return res.status(403).json({ success: false, error: 'No pudimos sumar la reserva a tu compra. Volvé a intentarlo desde el mismo dispositivo.' });
    }
    // Ids nuevos: sin repetirse y, como en /api/pedidos/crear, sin coincidir con el grupo de pago de
    // otra familia (la llave de un pedido y la de un grupo se calculan igual).
    const idsReservaNuevos = idsReserva.filter((id): id is string => Boolean(id));
    if (idsReservaNuevos.length > 0) {
      if (new Set(idsReservaNuevos).size !== idsReservaNuevos.length) return res.status(400).json({ success: false, error: 'No pudimos registrar la reserva. Volvé a intentarlo.' });
      const { data: choca } = await supabase.from('pedidos').select('id').in('grupo_pago_id', idsReservaNuevos).limit(1);
      if (choca && choca.length > 0) return res.status(409).json({ success: false, error: 'No pudimos registrar la reserva. Volvé a intentarlo.' });
    }

    // El curso de cada hijo sale SIEMPRE del código secreto de su sección (el mismo que usa la
    // galería), nunca de un grado/turno/división mandado por el navegador.
    const resueltos: { seccion: { colegioId: string; grado: string; turno: string; division: string }; colegio: { id: string; nombre: string }; alumnoNombre: string; kitId: string; cursoCodigo: string; carpetasExtras: number }[] = [];
    for (const item of items) {
      const kitId = String(item?.kitId || '');
      if (!NOMBRES_KITS_RESERVA[kitId]) return res.status(400).json({ success: false, error: 'Kit no reconocido.' });
      const alumnoNombre = String(item?.alumnoNombre || '').trim().slice(0, 200);
      if (alumnoNombre.length < 2) return res.status(400).json({ success: false, error: 'Falta el nombre de uno de los chicos.' });
      const seccion = await buscarSeccionPorCodigoSecreto(supabase, String(item?.codigoSeccion || ''));
      if (!seccion) return res.status(400).json({ success: false, error: `No pudimos identificar el curso de ${alumnoNombre}.` });
      const colegio = await buscarColegioReal(supabase, seccion.colegioId);
      if (!colegio) return res.status(400).json({ success: false, error: ERROR_COLEGIO_NO_VALIDO });
      if (!kitPermitidoParaGrado(kitId, seccion.grado)) return res.status(400).json({ success: false, error: `${ERROR_DIGITAL_SECUNDARIA} (${alumnoNombre})` });
      const cursoCodigo = determinarCodigoCursoServidor(seccion.grado, seccion.turno, seccion.division);
      if (await cursoTieneFotosDelPack(supabase, seccion.colegioId, cursoCodigo)) {
        return res.status(409).json({ success: false, error: `Las fotos de ${alumnoNombre} ya están online: elegilas en su galería y comprá desde ahí (el pago anticipado es sólo para cursos sin fotos).` });
      }

      // Un mismo chico no puede quedar con dos kits pagados sin querer.
      // Auditoría 03/10 (alto 8): mismo contrato que /api/pedidos/crear (409 KIT_YA_PAGADO con la
      // lista de chicos; si la familia confirma, vuelve con confirmarOtroKit: true).
      if (confirmarOtroKit !== true) {
        const conKit = await alumnosConKitPagado(supabase, [{ colegioId: colegio.id, cursoCodigo, alumnoNombre }]);
        if (conKit.length > 0) return res.status(409).json(respuestaKitYaPagado(conKit));
      }
      // Pedido de Pablo (27/9): copias extra de la carpeta también en el pago anticipado (sólo Kit Impreso).
      resueltos.push({ seccion, colegio, alumnoNombre, kitId, cursoCodigo, carpetasExtras: carpetasExtrasValidas(kitId, item?.carpetasExtras) });
    }
    const cursoMalReserva = await cursoDistintoAlInscripto(supabase, emailTutor, resueltos.map((r) => ({ colegioId: r.colegio.id, cursoCodigo: r.cursoCodigo, alumnoNombre: r.alumnoNombre })));
    if (cursoMalReserva) return res.status(409).json(respuestaCursoCambiado(cursoMalReserva)); // 14/10 (caso Noguera Cabral): ver cursoInscripto.ts

    // Pedido de Pablo (25/9): "sí o sí deben elegir las fotos del alumno que sí tiene fotos". Una
    // reserva suelta (no sumada a una compra) se rechaza si algún hijo inscripto de esta familia
    // (mismo email) tiene fotos online y todavía no las compró: primero se eligen esas fotos y la
    // reserva se suma a esa compra (grupoPagoId). Se controla acá además de en la pantalla.
    // 10/10 (pedido de Pablo): sólo cuentan los hijos del MISMO colegio que la reserva. Antes un hijo de
    // otro colegio (con el mismo email) frenaba la reserva con un aviso que la familia no podía resolver
    // desde esa pantalla (no ve a ese hijo ahí).
    if (!grupoExistente) {
      const colegiosDeLaReserva = new Set(resueltos.map((r) => String(r.colegio.id)));
      const emailParaIlike = emailTutor.replace(/[%_\\]/g, (c) => `\\${c}`).replace(/\*/g, ''); // FAM-3: PostgREST toma «*» como «%»
      const { data: inscripcionesFamilia } = await supabase
        .from('inscripciones')
        .select('colegio_id, alumno_nombre, alumno_apellido, grado, turno, division, hermanos')
        .eq('estado', 'aceptado')
        .ilike('email', emailParaIlike);
      const reservados = new Set(resueltos.map((r) => normalizarNombrePorPalabras(r.alumnoNombre)));
      for (const insc of inscripcionesFamilia || []) {
        const chicos = [
          { nombre: `${insc.alumno_nombre || ''} ${insc.alumno_apellido || ''}`.trim(), colegioId: insc.colegio_id, grado: insc.grado, turno: insc.turno, division: insc.division },
          ...(Array.isArray(insc.hermanos) ? insc.hermanos.map((h: any) => ({
            nombre: `${h.alumnoNombre || h.alumno_nombre || ''} ${h.alumnoApellido || h.alumno_apellido || ''}`.trim(),
            colegioId: h.colegioId || insc.colegio_id,
            grado: h.grado, turno: h.turno, division: h.division,
          })) : []),
        ];
        for (const chico of chicos) {
          if (!chico.nombre || !chico.grado || !chico.turno || reservados.has(normalizarNombrePorPalabras(chico.nombre))) continue;
          if (!colegiosDeLaReserva.has(String(chico.colegioId))) continue;
          const cursoChico = determinarCodigoCursoServidor(chico.grado, chico.turno, chico.division || '');
          if (!(await cursoTieneFotosDelPack(supabase, chico.colegioId, cursoChico))) continue;
          const { data: pagadosChico } = await supabase
            .from('pedidos')
            .select('alumno_nombre')
            .eq('colegio_id', chico.colegioId)
            .eq('curso_codigo', cursoChico)
            .in('estado', ['pagado', 'entregado']);
          const yaCompro = (pagadosChico || []).some((p: any) => normalizarNombrePorPalabras(p.alumno_nombre) === normalizarNombrePorPalabras(chico.nombre));
          if (!yaCompro) {
            return res.status(409).json({
              success: false,
              // 10/10: el aviso dice cómo seguir (antes no quedaba claro qué hacer desde la reserva).
              error: `Antes de reservar: las fotos de ${chico.nombre} ya están online y todavía no las compraste. Elegí primero sus fotos (botón «Ver sus fotos» de ${chico.nombre}, o entrando con el código de su curso) y, al pagar esa compra, sumá esta reserva: pagás todo junto.`,
            });
          }
        }
      }
    }

    const { data: famData } = await supabase
      .from('familias')
      .insert({
        nombre: String(tutorNombre || 'Familia').trim().slice(0, 200) || 'Familia',
        whatsapp: String(tutorTelefono || '').trim().slice(0, 40),
        email: emailTutor,
      })
      .select('id')
      .single();

    // Pedido de Pablo (25/9): si un hermano ya tiene fotos, primero se eligen las suyas y la reserva
    // del hermano sin fotos se SUMA a esa misma compra (un solo pago). Se acepta el grupo sólo si ya
    // existe y está entero sin pagar, así no se puede colgar una reserva de un pago ajeno o cerrado.
    let grupoPagoId: string = crypto.randomUUID();
    if (grupoExistente) {
      const { data: filasGrupo, error: errorGrupo } = await supabase
        .from('pedidos')
        .select('id, estado, mp_preference_id, nave_payment_request_id, cancelado_definitivo')
        .eq('grupo_pago_id', String(grupoExistente));
      if (errorGrupo) throw errorGrupo;
      // Auditoría 03/10: las filas canceladas definitivo (p. ej. un hermano cancelado o una reserva
      // reemplazada antes) ya no cuentan para el grupo.
      const filasVivasGrupo = (filasGrupo || []).filter((f: any) => !f.cancelado_definitivo);
      if (filasVivasGrupo.length === 0 || filasVivasGrupo.some((f: any) => f.estado !== 'pendiente_pago')) {
        return res.status(409).json({ success: false, error: 'No pudimos sumar la reserva a tu compra. Volvé a intentarlo.' });
      }
      // Auditoría 2026-09-26 (C3, CRÍTICO): si el grupo ya tiene un link de pago generado, ese link
      // cobra el total VIEJO. Sumarle filas después permitía pagar $15.000 y quedar con varios kits
      // pagados. En el flujo normal del portal la reserva se suma ANTES de generar el link.
      if (filasVivasGrupo.some((f: any) => f.mp_preference_id || f.nave_payment_request_id)) {
        return res.status(409).json({ success: false, error: 'Esta compra ya tiene un link de pago generado. Armá la reserva como una compra aparte.' });
      }
      grupoPagoId = String(grupoExistente);
    }
    const friendlyIdsUsados = new Set<string>();
    const numeroListaBasePorCurso: Record<string, number> = {};
    const filas: Record<string, any>[] = [];
    let totalGrupo = 0;
    for (const r of resueltos) {
      const total = calcularTotalPedido(r.kitId, r.carpetasExtras, 0) as number;
      totalGrupo += total;
      const claveNumero = claveCursoNumeroLista(r.colegio.id, r.cursoCodigo);
      if (numeroListaBasePorCurso[claveNumero] === undefined) {
        numeroListaBasePorCurso[claveNumero] = await obtenerNumeroListaSecuencial(supabase, r.cursoCodigo, r.colegio.id) - 1;
      }
      const numeroLista = ++numeroListaBasePorCurso[claveNumero];
      filas.push({
        ...aceptacion,
        clave_checkout_hash: hashClaveCheckout(req.body?.claveCheckout),
        familia_id: famData?.id || null,
        tipo_kit: r.kitId === 'kit-digital' ? 'solo_digital' : 'impreso_digital',
        estado: 'pendiente_pago',
        total,
        carpetas_impresas: r.kitId === 'kit-clasico' ? r.carpetasExtras + 1 : 0,
        metodo_pago: metodo,
        grupo_pago_id: grupoPagoId,
        pedido_friendly_id: await asegurarFriendlyIdUnico(supabase, '', friendlyIdsUsados),
        colegio_id: r.colegio.id,
        colegio_nombre: r.colegio.nombre,
        curso_codigo: r.cursoCodigo,
        grado: r.seccion.grado,
        division: r.seccion.division,
        turno: r.seccion.turno,
        alumno_nombre: r.alumnoNombre,
        alumno_numero_lista: numeroLista,
        codigo_alumno: calcularCodigoAlumnoServidor(r.cursoCodigo, numeroLista, r.alumnoNombre),
        kit_nombre: NOMBRES_KITS_RESERVA[r.kitId],
        fotos_seleccionadas: {},
        copias_extras: r.carpetasExtras > 0 ? { carpetasExtras: r.carpetasExtras, individual15x21: r.carpetasExtras, grupal20x30: r.carpetasExtras, docente15x21: r.carpetasExtras, otras15x21: 0 } : {},
        link_descarga_hd: null,
        seleccion_pendiente: true,
      });
    }
    // Auditoría 03/10: el id de cada fila es el `reservaId` del navegador (validado arriba).
    filas.forEach((fila, i) => { if (idsReserva[i]) fila.id = idsReserva[i]; });
    const { data: insertadas, error } = await insertarPedidosConReintento(supabase, filas);
    if (error) {
      // Dos envíos simultáneos con los mismos ids: el segundo choca con la clave primaria y se
      // responde como un reintento del primero.
      if (error.code === '23505') {
        const enCarrera = await reintentoDeReserva();
        if (enCarrera) return res.status(enCarrera.status).json(enCarrera.body);
      }
      throw error;
    }
    // Si la familia había empezado una reserva y no la pagó (cerró Mercado Pago, cambió de medio,
    // etc.), esa reserva vieja se anula: queda sólo la nueva y el panel no se llena de pendientes.
    // Auditoría 11/10: recién después del insert (antes un 409 de más arriba la dejaba anulada igual).
    for (const r of resueltos) {
      const { data: viejas } = await supabase
        .from('pedidos')
        .select('id, alumno_nombre, comprobante_subido_at, familias(email)')
        .eq('colegio_id', r.colegio.id)
        .eq('curso_codigo', r.cursoCodigo)
        .eq('seleccion_pendiente', true)
        .in('estado', ESTADOS_COBRABLES)
        .eq('cancelado_definitivo', false);
      // Auditoría 03/10 noche (A2): ver cancelarReservasSinPagarDe — sólo de esta misma familia y
      // nunca con comprobante subido.
      // Auditoría 05/10 (bajo): nunca las filas de ESTA misma reserva (ni las de un doble toque simultáneo).
      const idsNuevos = new Set([...idsReserva.filter(Boolean), ...(insertadas || []).map((f: any) => f.id)].map((id) => String(id)));
      const ids = (viejas || [])
        .filter((p: any) => !idsNuevos.has(String(p.id)))
        .filter((p: any) => normalizarNombrePorPalabras(p.alumno_nombre) === normalizarNombrePorPalabras(r.alumnoNombre))
        .filter((p: any) => reservaEsDeLaFamilia(p, emailTutor) && !p.comprobante_subido_at)
        .map((p: any) => p.id);
      if (ids.length > 0) {
        // Auditoría 03/10 (alto 8): cancelado_definitivo para que la reserva vieja no reviva si se
        // paga su link (queda alerta de pago huérfano para devolverlo).
        await supabase.from('pedidos').update({ estado: 'cancelado', cancelado_definitivo: true, updated_at: new Date().toISOString() }).in('id', ids).in('estado', ESTADOS_COBRABLES);
      }
    }

    if (metodo === 'transferencia') await enviarAvisoTransferenciaRegistrada(supabase, 'grupo_pago_id', grupoPagoId, { claveConIds: true }); // 14/10/2026 (ver crear-multiple); clave con los ids del lote
    return res.json({
      success: true,
      grupoPagoId,
      total: totalGrupo,
      pedidoFriendlyIds: filas.map((f) => f.pedido_friendly_id),
      accesoToken: tokenAccesoPedido(grupoPagoId),
    });
  } catch (err: any) {
    console.error('[Reservas] Error al crear la reserva:', err);
    return res.status(500).json({ success: false, error: 'No pudimos registrar la reserva. Intentá nuevamente.' });
  }
});

// ¿Este chico tiene un kit pagado por adelantado esperando que elijan sus fotos?
// ¿El curso ya tiene fotos del pack online? Mismo criterio que /api/fotos (colegio + código de curso).
// Caso real (25/9): el pago anticipado se ofrecía también para un hijo cuyo curso YA tenía fotos.
async function cursoTieneFotosDelPack(supabase: SupabaseClient, colegioId: string, cursoCodigo: string): Promise<boolean> {
  const { count, error } = await supabase
    .from('fotos')
    .select('id', { count: 'exact', head: true })
    .eq('colegio_id', colegioId)
    .eq('codigo_curso', cursoCodigo)
    .in('categoria', ['individual', 'grupal', 'docente', 'familia'])
    .not('publicada_at', 'is', null);
  if (error) throw error;
  return (count || 0) > 0;
}

rutasReservas.get('/api/reservas/pendiente', limitarFrecuencia('reservas-pendiente', 1500, 10 * 60 * 1000), async (req: Request, res: Response) => {
  try {
    const codigo = String(req.query.codigo || '').trim().slice(0, 40);
    const alumnoNombre = String(req.query.alumnoNombre || '').trim().slice(0, 200);
    if (!codigo || !alumnoNombre) return res.status(400).json({ success: false, error: 'Faltan datos.' });
    const supabase = getServerSupabase();
    if (!supabase) return res.status(503).json({ success: false, error: 'Servicio no disponible' });
    const seccion = await buscarSeccionPorCodigoSecreto(supabase, codigo);
    if (!seccion) return res.json({ success: true, reserva: null });
    const cursoCodigo = determinarCodigoCursoServidor(seccion.grado, seccion.turno, seccion.division);
    const fotosDisponibles = await cursoTieneFotosDelPack(supabase, seccion.colegioId, cursoCodigo);
    const { data: pagados } = await supabase
      .from('pedidos')
      .select('alumno_nombre')
      .eq('colegio_id', seccion.colegioId)
      .eq('curso_codigo', cursoCodigo)
      .in('estado', ['pagado', 'entregado']);
    const tienePedidoPagado = (pagados || []).some((p: any) => normalizarNombrePorPalabras(p.alumno_nombre) === normalizarNombrePorPalabras(alumnoNombre));
    // Auditoría 03/10 noche (A2): las reservas SIN PAGAR (y si el chico tiene un pedido esperando el
    // pago) sólo se le muestran a la familia de ese chico, identificada con su llave de galería. Antes
    // cualquiera con el código del curso veía el kit, el monto y el id de la reserva de otra familia.
    // Las reservas PAGADAS se siguen devolviendo como siempre (la familia elige ahí sus fotos, también
    // desde otro dispositivo).
    const hijosFamilia = await hijosDeFamiliaConAcceso(supabase, req.query.familia, req.query.acceso);
    // Auditoría 08/10 (M5): nombre igual, o compatible sólo si ningún otro chico del curso coincide mejor.
    const esDeLaFamilia = (await hijosQueSonElAlumno(supabase, req.query.familia, hijosFamilia, alumnoNombre, seccion.colegioId, cursoCodigo)).length > 0;
    let tienePedidoPendiente = false;
    if (esDeLaFamilia) {
      const { data: pendientes } = await supabase
        .from('pedidos')
        .select('alumno_nombre')
        .eq('colegio_id', seccion.colegioId)
        .eq('curso_codigo', cursoCodigo)
        .eq('estado', 'pendiente_pago')
        .eq('seleccion_pendiente', false)
        .eq('cancelado_definitivo', false)
        .is('mejora_de_pedido_id', null).neq('tipo_kit', 'fotos_extra') // 29/10: tampoco las fotos extra
        .limit(200);
      tienePedidoPendiente = (pendientes || []).some((p: any) => normalizarNombrePorPalabras(p.alumno_nombre) === normalizarNombrePorPalabras(alumnoNombre));
    }
    const { data, error } = await supabase
      .from('pedidos')
      .select('id, pedido_friendly_id, alumno_nombre, kit_nombre, total, estado, metodo_pago, grupo_pago_id')
      .eq('colegio_id', seccion.colegioId)
      .eq('curso_codigo', cursoCodigo)
      .eq('seleccion_pendiente', true)
      .in('estado', ['pagado', 'pendiente_pago'])
      .order('created_at', { ascending: false })
      .limit(100);
    if (error) throw error;
    const buscado = normalizarNombrePorPalabras(alumnoNombre);
    const propias = (data || [])
      .filter((p: any) => normalizarNombrePorPalabras(p.alumno_nombre) === buscado)
      .filter((p: any) => p.estado === 'pagado' || esDeLaFamilia);
    const pagada = propias.find((p: any) => p.estado === 'pagado');
    const elegida = pagada || propias[0];
    const extraFamilia = esDeLaFamilia ? { tienePedidoPendiente } : {};
    if (!elegida) return res.json({ success: true, reserva: null, fotosDisponibles, tienePedidoPagado, ...extraFamilia });
    // Auditoría 05/10 (alto): el id de una reserva PAGADA ya no sale con sólo el código del curso y
    // el nombre del chico (cualquiera del curso podía elegirle las fotos a otra familia). Sin la
    // llave de la familia se informa que el kit está pagado pero sin el id; el portal pide reingresar.
    const idVisible = esDeLaFamilia || elegida.estado !== 'pagado';
    return res.json({
      success: true,
      fotosDisponibles,
      tienePedidoPagado,
      ...extraFamilia,
      reserva: {
        id: idVisible ? elegida.id : null,
        requiereLlave: !idVisible,
        grupoPagoId: idVisible ? elegida.grupo_pago_id || null : null,
        pedidoFriendlyId: elegida.pedido_friendly_id,
        kitNombre: elegida.kit_nombre,
        total: Number(elegida.total) || 0,
        pagada: elegida.estado === 'pagado',
        metodoPago: elegida.metodo_pago || 'mercadopago',
      },
    });
  } catch (err: any) {
    console.error('[Reservas] Error al buscar reserva pendiente:', err);
    return res.status(500).json({ success: false, error: 'No pudimos verificar tu reserva.' });
  }
});

// La familia elige las 3 fotos de un kit que ya pagó por adelantado. Sin cobro: se guardan las
// fotos, se arma el .zip HD y se le manda el email con la descarga, igual que en un pago normal.
rutasReservas.post('/api/reservas/:id/elegir-fotos', limitarFrecuencia('reservas-elegir', 150, 10 * 60 * 1000), exigirPlazoReservaImpreso, async (req: Request, res: Response) => {
  try {
    const { codigo, fotos, confirmaPersonalizacion, versionTerminos } = req.body || {};
    // Marco legal (27/9): confirmar las fotos convierte el kit en un producto personalizado y
    // dispara el envío del digital (excepciones del art. 1116 CCyC). Se exige la confirmación
    // expresa de la familia y se guarda cuándo la dio.
    if (confirmaPersonalizacion !== true || versionTerminos !== VERSION_TERMINOS_SERVIDOR) {
      return res.status(400).json({ success: false, error: 'Para confirmar tus fotos tildá la casilla de confirmación. Si ya la tildaste, recargá la página e intentá de nuevo.' });
    }
    const supabase = getServerSupabase();
    if (!supabase) return res.status(503).json({ success: false, error: 'Servicio no disponible' });
    const seccion = await buscarSeccionPorCodigoSecreto(supabase, String(codigo || ''));
    if (!seccion) return res.status(403).json({ success: false, error: 'No pudimos validar tu acceso. Volvé a ingresar con tu código.' });
    const cursoCodigo = determinarCodigoCursoServidor(seccion.grado, seccion.turno, seccion.division);

    const { data: pedido, error } = await supabase
      .from('pedidos')
      .select('id, estado, seleccion_pendiente, colegio_id, curso_codigo, alumno_nombre, grupo_pago_id')
      .eq('id', String(req.params.id))
      .single();
    if (error || !pedido) return res.status(404).json({ success: false, error: 'No encontramos tu reserva.' });
    if (pedido.colegio_id !== seccion.colegioId || pedido.curso_codigo !== cursoCodigo) {
      return res.status(403).json({ success: false, error: 'Esta reserva no corresponde a este curso.' });
    }
    // Auditoría 05/10 (alto): confirmar las fotos de un kit pagado exige la llave de la familia
    // (la de galería, con un hijo compatible con el chico de la reserva) o la llave del pedido
    // (`t`, la que recibió quien lo reservó). Antes alcanzaba con el código del curso y el UUID.
    const hijosConLlave = await hijosDeFamiliaConAcceso(supabase, req.body?.familia, req.body?.acceso);
    // Auditoría 08/10 (M5): sólo el hijo que ES el chico de la reserva (no uno de nombre parecido).
    const hijosDelPedido = await hijosQueSonElAlumno(supabase, req.body?.familia, hijosConLlave, pedido.alumno_nombre, seccion.colegioId, cursoCodigo);
    const esDeLaFamilia = hijosDelPedido.length > 0;
    const conLlavePedido = tokenAccesoValido(llaveRecibida(req), [pedido.id, pedido.grupo_pago_id]);
    if (!esDeLaFamilia && !conLlavePedido) {
      return res.status(403).json({ success: false, codigo: 'LLAVE_REQUERIDA', error: 'Para confirmar las fotos de tu kit pagado tenés que ingresar al portal con los datos de tu familia (DNI del tutor). Volvé a ingresar e intentá de nuevo.' });
    }
    if (pedido.estado !== 'pagado') return res.status(409).json({ success: false, error: 'Tu reserva todavía no figura como pagada.' });
    if (!pedido.seleccion_pendiente) return res.status(409).json({ success: false, error: 'Las fotos de este kit ya fueron elegidas.' });

    // 22/10: misma validación que al comprar (validarSeleccionFotos: 3ª foto según el curso, individual con
    // nombre sólo del chico —o de un hijo con llave—, lugares «no tiene esta foto»). Una reserva no suma
    // fotos sueltas (no se cobraron): `otrasIds` va siempre vacío.
    const validacion = await validarSeleccionFotos(supabase, seccion.colegioId, cursoCodigo, { ...(fotos && typeof fotos === 'object' ? fotos : {}), otrasIds: [] }, '', [pedido.alumno_nombre, ...hijosDelPedido]);
    if (!validacion.ok) return res.status(400).json({ success: false, error: (validacion as { error: string }).error });
    const { otrasIds: _sinSueltas, ...ids } = validacion.seleccion;

    const { data: actualizado, error: errorUpdate } = await supabase
      .from('pedidos')
      // Auditoría 05/10 (alto): la reserva ya tenía email_enviado=true por el correo del pago; si el
      // correo con el link HD falla acá, el reintento horario lo ignoraba para siempre. Se reinicia.
      .update({ fotos_seleccionadas: ids, seleccion_pendiente: false, email_enviado: false, fecha_envio_email: null, seleccion_confirmada_at: new Date().toISOString(), seleccion_confirmada_version: VERSION_TERMINOS_SERVIDOR, updated_at: new Date().toISOString() })
      .eq('id', pedido.id)
      .eq('seleccion_pendiente', true)
      .eq('estado', 'pagado').eq('cancelado_definitivo', false) // Auditoría 11/10: si entró un reembolso en el medio, no sale el HD
      .select('*, familias(nombre, whatsapp, email)');
    if (errorUpdate) throw errorUpdate;
    if (!actualizado || actualizado.length === 0) {
      return res.status(409).json({ success: false, error: 'Las fotos de este kit ya fueron elegidas.' });
    }
    // 14/10/2026: se responde a los 8 s aunque el .zip siga armándose (antes se esperaba hasta 30 s y el portal cortaba a
    // los 15 con «Error de conexión» sobre fotos ya guardadas). Si la función se congela, el reintento horario (email_enviado=false) lo termina.
    await Promise.race([procesarPedidosRecienPagados(supabase, actualizado), new Promise((ok) => setTimeout(ok, 8000))]);
    return res.json({ success: true, pedidoFriendlyId: actualizado[0].pedido_friendly_id });
  } catch (err: any) {
    console.error('[Reservas] Error al elegir fotos de la reserva:', err);
    return res.status(500).json({ success: false, error: 'No pudimos guardar tu elección. Intentá nuevamente.' });
  }
});

export { rutas as rutasCrearPedido, rutasReservas as rutasReservas };
