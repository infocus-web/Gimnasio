// Marco legal de la compra: aceptación de términos (`aceptacionDeTerminos`), botón de arrepentimiento y
// su bandeja en el panel (resolver cancelación) (división de server.ts, etapa 6, 10/10/2026). El código
// es el mismo que estaba en la sección "MARCO LEGAL" de server.ts: sólo se movió de lugar.
import crypto from 'crypto';
import express from 'express';
import type { Request, Response } from 'express';
import { PaymentRefund } from 'mercadopago';
import { registrarAlertaPago } from '../nucleo/alertas.js';
import { requireAdminAuth } from '../nucleo/auth.js';
import { getMercadoPagoConfig, getResendClient, getServerSupabase, resendReplyTo } from '../nucleo/clientes.js';
import { VERSION_TERMINOS_SERVIDOR } from '../nucleo/legal.js';
import { hayCupoGlobal, limitarFrecuenciaPersistente } from '../nucleo/limites.js';
import { escapeHtml, ipDelCliente } from '../nucleo/utilidades.js';

const rutas = express.Router();

// ==============================================================================
// MARCO LEGAL (27/9): aceptación de términos y BOTÓN DE ARREPENTIMIENTO
// ==============================================================================


export const ERROR_TERMINOS_NO_ACEPTADOS =
  'Para continuar tenés que aceptar los Términos y Condiciones: tildá la casilla que está arriba del botón de pago. Si ya la tildaste, recargá la página e intentá de nuevo.';

/** Datos de aceptación para guardar en el pedido, o null si la familia no aceptó la versión vigente. */
export function aceptacionDeTerminos(req: Request): Record<string, string | null> | null {
  const cuerpo = req.body || {};
  if (cuerpo.aceptaTerminos !== true || cuerpo.versionTerminos !== VERSION_TERMINOS_SERVIDOR) return null;
  return {
    terminos_version: VERSION_TERMINOS_SERVIDOR,
    terminos_aceptados_at: new Date().toISOString(),
    terminos_ip: ipDelCliente(req),
  };
}

// Disposición 954/2025 (Botón de arrepentimiento): sin registro previo, y dentro de las 24 h hay que
// darle a la familia un código que identifique su solicitud. Se manda en el acto, en pantalla y por
// email. La Disposición 3/2026 permite una verificación razonable de identidad: se pide el número de
// pedido y el email con el que se compró; si no coinciden, la solicitud igual se registra (no se
// puede rechazar por eso) y queda para revisar a mano.
// Auditoría 03/10 (alto 25): el límite por IP pasa a ser persistente (vale para todas las instancias)
// y el email con el código sólo sale a la dirección de un pedido real (y como mucho 3 por día a la
// misma casilla). Antes se podía mandar un mail con la marca de Retrato Escolar, y texto elegido por
// el atacante, a cualquier dirección.
rutas.post('/api/arrepentimiento', limitarFrecuenciaPersistente('arrepentimiento', 10, 60 * 60 * 1000), async (req: Request, res: Response) => {
  try {
    const acotar = (valor: unknown, max: number) => String(valor ?? '').trim().slice(0, max);
    const pedidoRef = acotar(req.body?.pedido, 60).toUpperCase();
    const nombre = acotar(req.body?.nombre, 200);
    const email = acotar(req.body?.email, 200).toLowerCase();
    const motivo = acotar(req.body?.motivo, 1000);
    if (pedidoRef.length < 3) return res.status(400).json({ success: false, error: 'Ingresá el número de pedido (por ejemplo IFS-2026-1234). Lo encontrás en el email de tu compra.' });
    if (nombre.length < 2) return res.status(400).json({ success: false, error: 'Ingresá tu nombre y apellido.' });
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return res.status(400).json({ success: false, error: 'Ingresá un email válido: ahí te mandamos el código de tu solicitud.' });

    const supabase = getServerSupabase();
    if (!supabase) return res.status(503).json({ success: false, error: `No pudimos registrar tu solicitud. Escribinos a contacto@retratoescolar.com.ar indicando tu número de pedido.` });

    // Pedido y verificación de identidad (email de la compra).
    const { data: pedidos } = await supabase
      .from('pedidos')
      .select('id, pedido_friendly_id, estado, alumno_nombre, kit_nombre, total, seleccion_pendiente, link_descarga_hd, email_enviado, grupo_pago_id, familias(email)')
      .eq('pedido_friendly_id', pedidoRef)
      .limit(1);
    const pedido: any = pedidos?.[0] || null;
    const emailPedido = String(pedido?.familias?.email || '').trim().toLowerCase();
    const identidadVerificada = Boolean(pedido && emailPedido && emailPedido === email);

    // 14/10/2026: un reintento tras un corte (o un doble toque) creaba otro código ARR y otro email. Si la
    // misma casilla pidió lo mismo para el mismo pedido en los últimos 10 minutos, se devuelve ese código.
    const { data: recientes, error: errorRecientes } = await supabase
      .from('solicitudes_arrepentimiento')
      .select('codigo, created_at')
      .eq('pedido_ref', pedidoRef)
      .eq('email', email)
      .gte('created_at', new Date(Date.now() - 10 * 60 * 1000).toISOString())
      .order('created_at', { ascending: false })
      .limit(1);
    if (errorRecientes) throw errorRecientes;
    const repetida = Boolean(recientes?.[0]?.codigo);

    // Código único de la solicitud.
    let codigo = repetida ? String(recientes![0].codigo) : '';
    let insertado = repetida;
    for (let intento = 0; intento < 5 && !insertado; intento++) {
      codigo = `ARR-${new Date().getFullYear()}-${crypto.randomBytes(4).toString('hex').slice(0, 6).toUpperCase()}`;
      const { error } = await supabase.from('solicitudes_arrepentimiento').insert({
        codigo,
        pedido_ref: pedidoRef,
        pedido_id: identidadVerificada ? pedido.id : null,
        nombre,
        email,
        motivo: motivo || null,
        ip: ipDelCliente(req),
        user_agent: acotar(req.headers['user-agent'], 300) || null,
      });
      if (!error) insertado = true;
      else if (error.code !== '23505') throw error;
    }
    if (!insertado) throw new Error('No se pudo generar un código único');

    // Se frena la producción mientras se revisa (el laboratorio no toma pedidos "En espera").
    // 14/10/2026: todo el pago (carrito de hermanos, mismo grupo_pago_id): antes sólo la fila escrita y
    // los hermanos seguían a producción o se podían seguir cobrando. (También en la solicitud repetida:
    // si el primer intento se cortó antes de llegar acá.)
    if (identidadVerificada && ['pagado', 'pendiente_pago'].includes(String(pedido.estado))) {
      const { error: errorEspera } = await supabase
        .from('pedidos')
        .update({ en_espera: true, nota_espera: `Arrepentimiento ${codigo} (${new Date().toLocaleDateString('es-AR', { timeZone: 'America/Argentina/Buenos_Aires' })})` })
        .eq(pedido.grupo_pago_id ? 'grupo_pago_id' : 'id', pedido.grupo_pago_id || pedido.id)
        .in('estado', ['pagado', 'pendiente_pago']);
      if (errorEspera) throw errorEspera;
    }
    // 14/10/2026: la solicitud repetida ya no corta acá: si el primer intento se cayó después de insertar,
    // Pablo nunca recibía la alerta ni la familia el email. registrarAlertaPago no repite (misma clave
    // `arrepentimiento:${codigo}`) y el email lleva la clave de idempotencia de Resend del código.

    // Referencia para quien revisa: si ya aplica alguna excepción del art. 1116 CCyC.
    const fotosConfirmadas = Boolean(pedido && pedido.seleccion_pendiente === false);
    const digitalEnviado = Boolean(pedido && (pedido.email_enviado || pedido.link_descarga_hd));
    // Las solicitudes sin pedido verificado igual quedan registradas (pestaña Cancelaciones), pero su
    // aviso por email al panel tiene tope diario: si no, servían para llenar la casilla de Pablo.
    if (identidadVerificada || (await hayCupoGlobal('arrepentimiento-alertas-sin-verificar', 20, 24 * 60 * 60))) await registrarAlertaPago(
      supabase,
      `arrepentimiento:${codigo}`,
      `BOTÓN DE ARREPENTIMIENTO ${codigo}: ${nombre} pidió arrepentirse del pedido ${pedidoRef}.${identidadVerificada ? '' : ' OJO: no encontramos el pedido o el email no coincide con el de la compra — verificar a mano.'}`,
      {
        codigo,
        pedido: pedidoRef,
        email,
        motivo: motivo || '(sin motivo)',
        identidadVerificada,
        estadoPedido: pedido?.estado || 'no encontrado',
        total: pedido?.total ?? null,
        fotosConfirmadas,
        digitalEnviado,
        nota: 'Responder dentro de los 10 días. Si el pedido no tenía fotos confirmadas ni digital enviado, corresponde devolver el total por el mismo medio de pago.',
      }
    );

    // Código a la familia (en pantalla y por email). El email sólo sale si coincide con el de la compra
    // (pedido real) y con tope de 3 por día por casilla; el nombre va escapado y recortado.
    const resend = getResendClient();
    let emailEnviado = false;
    // 14/10/2026: la repetida no gasta el tope diario de la casilla (la clave de idempotencia evita el duplicado).
    // La fecha va sin hora y sale de la solicitud original: el mismo contenido con la misma clave (si no,
    // Resend rechaza el reintento por «misma clave, otro contenido»).
    if (resend && identidadVerificada && (repetida || (await hayCupoGlobal(`arrepentimiento-dest:${email}`, 3, 24 * 60 * 60)))) {
      const fecha = new Date(repetida ? String(recientes![0].created_at) : Date.now()).toLocaleDateString('es-AR', { timeZone: 'America/Argentina/Buenos_Aires' });
      try {
        const envio = await resend.emails.send({
          from: process.env.RESEND_FROM_EMAIL || 'Retrato Escolar <fotos@retratoescolar.com.ar>',
          to: [email],
          subject: `Recibimos tu solicitud de cancelación ${codigo}`,
          html: `<div style="font-family:Arial,sans-serif;max-width:600px;margin:auto;color:#0f172a"><h2>Recibimos tu solicitud de cancelación</h2><p>Hola ${escapeHtml(nombre.slice(0, 80))}:</p><p>Registramos tu pedido de cancelación de la compra <strong>${escapeHtml(pedido?.pedido_friendly_id || pedidoRef)}</strong>.</p><p style="font-size:18px">Código de tu solicitud: <strong>${escapeHtml(codigo)}</strong></p><p>Guardalo: identifica tu trámite (Disposición 954/2025). Vamos a revisar tu pedido y te respondemos por este medio. Si corresponde, te devolvemos el dinero por el mismo medio con el que pagaste.</p><p style="font-size:12px;color:#64748b">Fecha: ${escapeHtml(fecha)}. Retrato Escolar · Infocus Producciones · contacto@retratoescolar.com.ar</p></div>`,
        }, { idempotencyKey: `arrepentimiento-codigo-${codigo}` });
        if (envio.error) console.error('[Arrepentimiento] No se pudo enviar el código por email:', envio.error);
        else emailEnviado = true;
      } catch (errEnvio) {
        console.error('[Arrepentimiento] No se pudo enviar el código por email:', errEnvio);
      }
    }

    return res.status(201).json({ success: true, codigo, pedidoEncontrado: identidadVerificada, emailEnviado, ...(repetida ? { repetida: true } : {}) });
  } catch (err: any) {
    console.error('[Arrepentimiento] Error al registrar la solicitud:', err);
    return res.status(500).json({ success: false, error: 'No pudimos registrar tu solicitud. Intentá de nuevo o escribinos a contacto@retratoescolar.com.ar con tu número de pedido.' });
  }
});

// Auditoría 28/9: pestaña "Cancelaciones" del panel. Lista las solicitudes del link "Botón de
// arrepentimiento" con su pedido y permite resolverlas sin ir y venir entre Zoho, Mercado Pago y
// Supabase: aprobar (con devolución automática por Mercado Pago si se pagó por ahí) o rechazar con
// un motivo. En los dos casos la familia recibe un email con la respuesta.
rutas.get('/api/admin/cancelaciones', requireAdminAuth, async (_req, res) => {
  try {
    const supabase = getServerSupabase();
    if (!supabase) return res.status(500).json({ success: false, error: 'Supabase no configurado en el servidor' });
    const { data, error } = await supabase
      .from('solicitudes_arrepentimiento')
      .select('id, created_at, codigo, pedido_ref, pedido_id, nombre, email, motivo, estado, nota_admin, atendida_at, pedidos(id, pedido_friendly_id, estado, total, metodo_pago, mp_payment_id, kit_nombre, alumno_nombre, colegio_nombre, seleccion_pendiente, email_enviado, grupo_pago_id, created_at, pagado_at)')
      .order('created_at', { ascending: false })
      .limit(300);
    if (error) throw error;
    return res.json({ success: true, solicitudes: data || [] });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err?.message || 'No se pudieron traer las cancelaciones.' });
  }
});

rutas.post('/api/admin/cancelaciones/:id/resolver', requireAdminAuth, async (req, res) => {
  try {
    const supabase = getServerSupabase();
    if (!supabase) return res.status(500).json({ success: false, error: 'Supabase no configurado en el servidor' });
    const accion = req.body?.accion === 'aprobar' ? 'aprobar' : req.body?.accion === 'rechazar' ? 'rechazar' : null;
    const nota = String(req.body?.nota || '').trim().slice(0, 1500);
    const devolverPorMP = Boolean(req.body?.devolverPorMercadoPago);
    if (!accion) return res.status(400).json({ success: false, error: 'Acción inválida.' });
    if (accion === 'rechazar' && nota.length < 5) return res.status(400).json({ success: false, error: 'Escribí el motivo: se lo mandamos a la familia.' });

    const { data: sol, error: errSol } = await supabase
      .from('solicitudes_arrepentimiento')
      .select('id, codigo, pedido_ref, pedido_id, nombre, email, estado')
      .eq('id', req.params.id)
      .maybeSingle();
    if (errSol) throw errSol;
    if (!sol) return res.status(404).json({ success: false, error: 'No encontramos la solicitud.' });
    if (sol.estado !== 'nueva') return res.status(409).json({ success: false, error: 'Esta solicitud ya fue resuelta.' });

    let pedido: any = null;
    if (sol.pedido_id) {
      const { data } = await supabase.from('pedidos').select('id, pedido_friendly_id, estado, total, metodo_pago, mp_payment_id, grupo_pago_id').eq('id', sol.pedido_id).maybeSingle();
      pedido = data;
    }

    // 25/10 (auditoría): sin pedido verificado (el email no coincide con el de la compra) no se aprueba: no se cancela
    // nada y el email «mandanos el CBU» le llegaría a quien escribió la solicitud, que puede no ser la familia.
    if (accion === 'aprobar' && !pedido) {
      return res.status(400).json({ success: false, error: 'Esta solicitud no está vinculada a un pedido (el email o el número no coinciden con una compra). Revisala a mano: si corresponde, cancelá el pedido desde Pedidos y rechazá esta solicitud con una nota.' });
    }
    const nadaCobrado = pedido?.estado === 'pendiente_pago';
    let devolucion: { hecha: boolean; monto?: number; error?: string } = { hecha: false };
    const mpConfig = accion === 'aprobar' && devolverPorMP ? getMercadoPagoConfig() : null;
    if (accion === 'aprobar' && devolverPorMP) {
      if (!pedido || pedido.estado !== 'pagado' || pedido.metodo_pago !== 'mercadopago' || !pedido.mp_payment_id) {
        return res.status(400).json({ success: false, error: 'Este pedido no tiene un pago de Mercado Pago para devolver automáticamente. Aprobalo sin devolución automática y devolvé a mano.' });
      }
      if (!mpConfig) return res.status(500).json({ success: false, error: 'Mercado Pago no está configurado en el servidor.' });
    }

    // Auditoría 03/10 (alto 12): la solicitud se RECLAMA con un UPDATE condicional (sólo si sigue
    // "nueva") ANTES de devolver plata. Antes, un doble clic (o dos pestañas) pasaban las dos el
    // control de arriba y Mercado Pago devolvía dos veces. Si la devolución falla, se libera.
    const ahora = new Date().toISOString();
    const estadoResuelto = accion === 'aprobar' ? 'aceptada' : 'rechazada_excepcion';
    const { data: reclamada, error: errReclamo } = await supabase
      .from('solicitudes_arrepentimiento')
      .update({ estado: estadoResuelto, nota_admin: nota || null, atendida_at: ahora })
      .eq('id', sol.id)
      .eq('estado', 'nueva')
      .select('id');
    if (errReclamo) throw errReclamo;
    if (!reclamada || reclamada.length === 0) return res.status(409).json({ success: false, error: 'Esta solicitud ya fue resuelta (o se está resolviendo en otra pestaña).' });

    if (accion === 'aprobar' && devolverPorMP && mpConfig) {
      // Un mismo pago puede cubrir a varios hermanos: se devuelve sólo lo de este pedido.
      const { count, error: errorCount } = await supabase.from('pedidos').select('id', { count: 'exact', head: true }).eq('mp_payment_id', pedido.mp_payment_id);
      // Auditoría 03/10 noche (H7): si no se pudo contar, no se devuelve nada (antes un error dejaba
      // count en null y se devolvía el pago ENTERO del carrito por el arrepentimiento de un solo hijo).
      if (errorCount || typeof count !== 'number') {
        await supabase.from('solicitudes_arrepentimiento').update({ estado: 'nueva', nota_admin: null, atendida_at: null }).eq('id', sol.id).eq('estado', estadoResuelto);
        return res.status(503).json({ success: false, error: 'No pudimos verificar el pago en la base. No se devolvió nada: probá de nuevo en unos minutos.' });
      }
      const monto = Number(pedido.total) || 0;
      // Clave de idempotencia derivada de la solicitud (header X-Idempotency-Key de Mercado Pago): un
      // reintento de la misma devolución nunca genera una segunda.
      // Auditoría 03/10 (2ª vuelta): 10 s y como mucho 1 reintento del SDK (maxRetries existe en
      // mercadopago 3.6), así entra holgado en los 60 s de la función.
      const requestOptions = { idempotencyKey: `arrepentimiento-${sol.id}`, timeout: 10000, maxRetries: 1 };
      try {
        const reintegros = new PaymentRefund(mpConfig);
        if ((count || 1) > 1) await reintegros.create({ payment_id: pedido.mp_payment_id, body: { amount: monto }, requestOptions });
        else await reintegros.total({ payment_id: pedido.mp_payment_id, requestOptions });
        devolucion = { hecha: true, monto };
      } catch (e: any) {
        await supabase
          .from('solicitudes_arrepentimiento')
          .update({ estado: 'nueva', nota_admin: null, atendida_at: null })
          .eq('id', sol.id)
          .eq('estado', estadoResuelto);
        // Timeout / corte de conexión (MPConnectionError) o error 5xx de Mercado Pago: la devolución
        // pudo haberse hecho igual. No se afirma "no se cambió nada": hay que mirar MP antes de
        // devolver a mano (si se reintenta desde acá, la clave de idempotencia evita una segunda).
        const resultadoIncierto = e?.error === 'connection_error' || e?.name === 'MPConnectionError' || e?.name === 'AbortError' || Number(e?.status) >= 500;
        if (resultadoIncierto) {
          return res.status(504).json({ success: false, error: 'No sabemos si la devolución salió: verificá en Mercado Pago antes de devolver a mano.' });
        }
        return res.status(502).json({ success: false, error: `Mercado Pago no aceptó la devolución: ${e?.message || 'error desconocido'}. No se cambió nada; podés devolver desde Mercado Pago y aprobar sin devolución automática.` });
      }
    }
    if (pedido) {
      const { error: errorPedido } = await supabase
        .from('pedidos')
        .update(
          accion === 'aprobar'
            ? { estado: 'cancelado', cancelado_definitivo: true, en_espera: false, nota_espera: `Cancelado por solicitud ${sol.codigo}`, updated_at: ahora }
            : { en_espera: false, nota_espera: null, updated_at: ahora }
        )
        .eq('id', pedido.id);
      // Auditoría 03/10 noche (H7): si la devolución salió pero el pedido no se pudo cancelar, el
      // pedido seguiría "pagado" (y en el laboratorio) con la plata devuelta: queda alerta.
      // 25/10 (auditoría): al registrar la solicitud se frenó TODO el carrito (grupo_pago_id); al resolverla se
      // liberan también los kits de los hermanos que frenó esta solicitud (si no, quedaban «en espera» para siempre).
      if (!errorPedido && pedido.grupo_pago_id) {
        const { data: grupo, error: errGrupo } = await supabase.from('pedidos').select('id, nota_espera').eq('grupo_pago_id', pedido.grupo_pago_id).eq('en_espera', true);
        const candidatos = (grupo || []).filter((p: any) => p.id !== pedido.id && String(p.nota_espera || '').startsWith(`Arrepentimiento ${sol.codigo}`)).map((p: any) => p.id);
        // Un hermano con SU propia solicitud todavía abierta sigue en espera (la solicitud nueva pisó la nota de todo el grupo).
        const { data: abiertas } = candidatos.length ? await supabase.from('solicitudes_arrepentimiento').select('pedido_id').eq('estado', 'nueva').in('pedido_id', candidatos) : { data: [] as any[] };
        const conSolicitud = new Set((abiertas || []).map((a: any) => a.pedido_id));
        const hermanos = candidatos.filter((id: string) => !conSolicitud.has(id));
        const { error: errLiberar } = errGrupo || hermanos.length === 0 ? { error: errGrupo } : await supabase.from('pedidos').update({ en_espera: false, nota_espera: null, updated_at: ahora }).in('id', hermanos);
        if (errLiberar) await registrarAlertaPago(supabase, `cancelacion-hermanos-en-espera:${sol.id}`, `La solicitud ${sol.codigo} se resolvió pero no se pudieron sacar de «en espera» los otros kits del mismo pago (${pedido.pedido_friendly_id || pedido.id}). Sacalos a mano desde Pedidos.`, { solicitud: sol.id, grupo: pedido.grupo_pago_id });
      }
      if (errorPedido) {
        await registrarAlertaPago(supabase, `cancelacion-sin-actualizar:${sol.id}`, `La solicitud ${sol.codigo} se resolvió (${accion}${devolucion.hecha ? `, se devolvieron $${devolucion.monto}` : ''}) pero NO se pudo actualizar el pedido ${pedido.pedido_friendly_id || pedido.id}. Cancelalo a mano y frenalo en el laboratorio.`, { solicitud: sol.id, pedido: pedido.id });
      }
    }

    // 14/10/2026 (auditoría «día de trabajo»): el panel dice «la familia recibió el email» sólo si salió de verdad.
    let emailEnviado = false;
    const resend = getResendClient();
    if (resend) {
      const monto = devolucion.monto ? ` de $${devolucion.monto.toLocaleString('es-AR')}` : '';
      const cuerpo =
        accion === 'aprobar'
          ? `<p>Aprobamos la cancelación de tu compra <strong>${escapeHtml(sol.pedido_ref)}</strong> (solicitud ${escapeHtml(sol.codigo)}).</p>` +
            (devolucion.hecha
              ? `<p>Ya iniciamos la devolución${monto} por Mercado Pago, al mismo medio con el que pagaste. Según tu banco o tarjeta, puede tardar unos días en verse reflejada.</p>`
              : nadaCobrado
                ? `<p>Como ese pedido todavía no estaba pago, no hay ningún cobro para devolver.</p>`
                : `<p>Te devolvemos el dinero por el mismo medio con el que pagaste. Si pagaste por transferencia, respondé este email con el CBU o alias donde querés recibirlo.</p>`) +
            (nota ? `<p>${escapeHtml(nota)}</p>` : '')
          : `<p>Revisamos tu solicitud ${escapeHtml(sol.codigo)} sobre la compra <strong>${escapeHtml(sol.pedido_ref)}</strong>.</p><p>${escapeHtml(nota)}</p><p>Si tenés alguna duda, respondé este email y lo vemos juntos.</p>`;
      try {
        const envio = await resend.emails.send({
          from: process.env.RESEND_FROM_EMAIL || 'Retrato Escolar <fotos@retratoescolar.com.ar>',
          to: [sol.email],
          replyTo: resendReplyTo,
          subject: accion === 'aprobar' ? `Tu cancelación fue aprobada (${sol.codigo})` : `Respuesta a tu solicitud ${sol.codigo}`,
          html: `<div style="font-family:Arial,sans-serif;max-width:600px;margin:auto;color:#0f172a"><p>Hola ${escapeHtml(sol.nombre)}:</p>${cuerpo}<p>Saludos,<br>Equipo de Retrato Escolar</p></div>`,
        }, { idempotencyKey: `cancelacion-${sol.id}-${accion}` });
        if (envio.error) console.error('[Cancelaciones] No se pudo avisar a la familia:', envio.error);
        else emailEnviado = true;
      } catch (errEnvio) {
        console.error('[Cancelaciones] No se pudo avisar a la familia:', errEnvio);
      }
    }

    return res.json({ success: true, devolucion, emailEnviado });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err?.message || 'No se pudo resolver la solicitud.' });
  }
});

export { rutas as rutasArrepentimiento };
