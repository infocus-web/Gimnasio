// Nave (Galicia): intención de pago (un pedido y carrito) y el webhook (división de server.ts, etapa 6,
// 10/10/2026). El código es el mismo que estaba en la sección 7 de server.ts: sólo se movió de lugar.
import express from 'express';
import { leerMontoNave } from '../comisionesCobro.js';
import { procesarPedidosRecienPagados } from '../entrega/pedidosPagados.js';
import { llaveRecibida, tokenAccesoPedido, tokenAccesoValido } from '../nucleo/accesoPedidos.js';
import { registrarAlertaPago } from '../nucleo/alertas.js';
import { crearIntencionNaveConReintento, fetchNave, getNaveCredenciales, getNaveUrls, getServerSupabase, naveHabilitado, obtenerNaveAccessToken } from '../nucleo/clientes.js';
import { limitarFrecuencia, tocaTurnoDistribuido } from '../nucleo/limites.js';
import { estadoPagoNave, marcarReferenciaComoPagada, obtenerPedidosPendientesParaCobro, comprobanteFrenaCobro, RESPUESTA_COMPROBANTE_YA_SUBIDO } from './cobros.js';
import { guardarIntencionNave } from './conciliacion.js';

const rutas = express.Router();

// Crear intención de pago en Nave (Banco Galicia) — equivalente a
// /api/mercadopago/crear-preferencia, mismo criterio de recalcular siempre el monto en el
// servidor (nunca confiar en un total mandado por el cliente).
rutas.post('/api/nave/crear-intencion', limitarFrecuencia('nave-crear-intencion', 200, 10 * 60 * 1000), async (req, res) => {
  try {
    const {
      pedidoId, kitId, kitNombre, alumnoNombre, colegioNombre, carpetasExtras, cantidadFotosSueltas,
      tutorNombre, tutorEmail, tutorTelefono,
    } = req.body || {};

    // Auditoría 2026-09-23: el monto sale del pedido ya registrado (ver crear-preferencia de MP).
    void kitId; void carpetasExtras; void cantidadFotosSueltas;
    const supabaseCobro = getServerSupabase();
    if (!supabaseCobro) {
      return res.status(500).json({ success: false, error: 'Supabase no configurado en el servidor' });
    }
    const cobro = await obtenerPedidosPendientesParaCobro(supabaseCobro, { pedidoId });
    if (cobro.error) {
      return res.status(cobro.status || 400).json({ success: false, error: cobro.error });
    }
    // 14/10/2026: con el comprobante de una transferencia ya subido no se genera un link sin confirmación.
    if (comprobanteFrenaCobro(cobro.filas, req.body)) return res.status(409).json(RESPUESTA_COMPROBANTE_YA_SUBIDO);
    const totalCalculado = Number(cobro.filas[0].total);

    const credenciales = getNaveCredenciales();
    // Ver naveHabilitado (C1): fuera de producción Nave no se ofrece ni se puede usar a mano.
    if (!credenciales || !naveHabilitado()) {
      return res.status(200).json({
        success: false,
        notConfigured: true,
        error: 'El pago con Nave no está disponible en este momento. Elegí Mercado Pago o transferencia.',
      });
    }

    const accessToken = await obtenerNaveAccessToken();
    if (!accessToken) {
      return res.status(502).json({ success: false, error: 'No se pudo autenticar contra la API de Nave.' });
    }

    const hostDetectado = req.get('host') || '';
    const esLocal = /^(localhost|127\.0\.0\.1)(:\d+)?$/i.test(hostDetectado);
    const protocoloFinal = esLocal ? req.protocol : 'https';
    const appUrl = (process.env.APP_URL || `${protocoloFinal}://${hostDetectado}`).replace(/\/+$/, '');

    const montoStr = totalCalculado.toFixed(2);
    const { crearIntencion } = getNaveUrls();

    const body: Record<string, any> = {
      // Nave exige un máximo de 36 caracteres para este campo (ver documentación) — un uuid de
      // pedido (36 caracteres exactos) entra justo.
      external_payment_id: String(pedidoId || `PED-${Date.now()}`).slice(0, 36),
      seller: { pos_id: credenciales.posId },
      transactions: [
        {
          amount: { currency: 'ARS', value: montoStr },
          products: [
            {
              name: (kitNombre || 'Kit Fotográfico').slice(0, 100),
              description: `Fotos escolares para ${alumnoNombre || 'alumno'} en ${colegioNombre || 'el colegio'}`.slice(0, 200),
              quantity: 1,
              unit_price: { currency: 'ARS', value: montoStr },
            },
          ],
        },
      ],
      buyer: {
        name: (tutorNombre || 'Familia').slice(0, 100),
        user_id: pedidoId,
      },
      additional_info: {
        // Auditoría 30/9 (A4): la llave sólo vuelve si quien pide el pago ya la tiene.
        callback_url: `${appUrl}/?nave_status=vuelta&pedido_id=${pedidoId}${tokenAccesoValido(llaveRecibida(req), [String(pedidoId)]) ? `&t=${tokenAccesoPedido(String(pedidoId))}` : ''}`,
      },
    };
    if (tutorEmail && String(tutorEmail).includes('@')) body.buyer.user_email = tutorEmail;
    if (tutorTelefono) body.buyer.phone = tutorTelefono;

    const { resp, data } = await crearIntencionNaveConReintento(crearIntencion, accessToken, body);
    if (!resp || !resp.ok || !data?.checkout_url) {
      console.error('[Nave Crear Intención Error]:', resp?.status, data);
      return res.status(502).json({
        success: false,
        error: (data && (data.message || data.error)) || 'Nave no respondió. Probá de nuevo en unos segundos o elegí otro medio de pago.',
      });
    }

    // Se guarda el id de la intención (payment_request_id) para poder reconsultarla o cancelarla
    // más adelante — mismo rol que mp_preference_id para Mercado Pago.
    const supabase = getServerSupabase();
    if (supabase && pedidoId) {
      await guardarIntencionNave(supabase, [String(pedidoId)], String(data.id));
    }

    return res.json({
      success: true,
      checkoutUrl: data.checkout_url,
      qrData: data.qr_data,
      naveId: data.id,
    });
  } catch (error: any) {
    console.error('[Nave Crear Intención Error]:', error);
    return res.status(500).json({ success: false, error: error?.message || 'Error al crear la intención de pago en Nave' });
  }
});

// Auditoría 2026-09-16 (carrito multi-hijo, "un solo pago"): equivalente a
// /api/nave/crear-intencion, pero arma UNA sola intención de pago con un "product" de línea por
// cada hijo del carrito, dentro de la MISMA transacción (Nave sí soporta varios productos por
// transacción) — así Nave cobra el total combinado en un único checkout. Mismo criterio de
// seguridad: cada monto se recalcula siempre acá con calcularTotalPedido. "external_payment_id"
// es el grupoPagoId compartido por todos los pedidos del carrito (ver
// /api/pedidos/crear-multiple) — un uuid entra justo en el límite de 36 caracteres de Nave.
rutas.post('/api/nave/crear-intencion-multiple', limitarFrecuencia('nave-crear-intencion-multiple', 200, 10 * 60 * 1000), async (req, res) => {
  try {
    const { grupoPagoId, items, tutorNombre, tutorEmail, tutorTelefono } = req.body || {};

    // Los ítems que manda el navegador ya no se usan para cobrar (ver abajo: se cobra lo registrado
    // en la base para este grupo) — sólo hace falta el grupo. Así el portal puede regenerar el link
    // de un carrito sin tener que reconstruir la lista de hijos.
    void items;
    if (!grupoPagoId) {
      return res.status(400).json({ success: false, error: 'Falta el grupo de pago del carrito.' });
    }

    // Auditoría 2026-09-23: montos tomados de las filas ya registradas del carrito (ver MP).
    const supabaseCobro = getServerSupabase();
    if (!supabaseCobro) {
      return res.status(500).json({ success: false, error: 'Supabase no configurado en el servidor' });
    }
    const cobro = await obtenerPedidosPendientesParaCobro(supabaseCobro, { grupoPagoId });
    if (cobro.error) {
      return res.status(cobro.status || 400).json({ success: false, error: cobro.error });
    }
    // 14/10/2026: con el comprobante de una transferencia ya subido no se genera un link sin confirmación.
    if (comprobanteFrenaCobro(cobro.filas, req.body)) return res.status(409).json(RESPUESTA_COMPROBANTE_YA_SUBIDO);
    // Pago anticipado: al volver del pago se muestra la pantalla de "reserva confirmada".
    // Pantalla de "reserva confirmada" sólo si TODO el pago son reservas; una compra con fotos más
    // la reserva de un hermano vuelve a la confirmación normal de compra.
    const sufijoReserva = cobro.filas.length > 0 && cobro.filas.every((fila: any) => fila.seleccion_pendiente) ? '&reserva=1' : '';
    let totalGrupo = 0;
    const products: any[] = cobro.filas.map((fila: any) => {
      const totalItem = Number(fila.total);
      totalGrupo += totalItem;
      return {
        name: (fila.kit_nombre || 'Kit Fotográfico').slice(0, 100),
        description: `Fotos escolares para ${fila.alumno_nombre || 'alumno'} en ${fila.colegio_nombre || 'el colegio'}`.slice(0, 200),
        quantity: 1,
        unit_price: { currency: 'ARS', value: totalItem.toFixed(2) },
      };
    });

    const credenciales = getNaveCredenciales();
    // Ver naveHabilitado (C1): fuera de producción Nave no se ofrece ni se puede usar a mano.
    if (!credenciales || !naveHabilitado()) {
      return res.status(200).json({
        success: false,
        notConfigured: true,
        error: 'El pago con Nave no está disponible en este momento. Elegí Mercado Pago o transferencia.',
      });
    }

    const accessToken = await obtenerNaveAccessToken();
    if (!accessToken) {
      return res.status(502).json({ success: false, error: 'No se pudo autenticar contra la API de Nave.' });
    }

    const hostDetectado = req.get('host') || '';
    const esLocal = /^(localhost|127\.0\.0\.1)(:\d+)?$/i.test(hostDetectado);
    const protocoloFinal = esLocal ? req.protocol : 'https';
    const appUrl = (process.env.APP_URL || `${protocoloFinal}://${hostDetectado}`).replace(/\/+$/, '');
    const { crearIntencion } = getNaveUrls();

    const body: Record<string, any> = {
      external_payment_id: String(grupoPagoId).slice(0, 36),
      seller: { pos_id: credenciales.posId },
      transactions: [
        {
          amount: { currency: 'ARS', value: totalGrupo.toFixed(2) },
          products,
        },
      ],
      buyer: {
        name: (tutorNombre || 'Familia').slice(0, 100),
        user_id: grupoPagoId,
      },
      additional_info: {
        callback_url: `${appUrl}/?nave_status=vuelta&grupo_pago_id=${grupoPagoId}${sufijoReserva}${tokenAccesoValido(llaveRecibida(req), [String(grupoPagoId)]) ? `&t=${tokenAccesoPedido(String(grupoPagoId))}` : ''}`,
      },
    };
    if (tutorEmail && String(tutorEmail).includes('@')) body.buyer.user_email = tutorEmail;
    if (tutorTelefono) body.buyer.phone = tutorTelefono;

    const { resp, data } = await crearIntencionNaveConReintento(crearIntencion, accessToken, body);
    if (!resp || !resp.ok || !data?.checkout_url) {
      console.error('[Nave Crear Intención Multiple Error]:', resp?.status, data);
      return res.status(502).json({
        success: false,
        error: (data && (data.message || data.error)) || 'Nave no respondió. Probá de nuevo en unos segundos o elegí otro medio de pago.',
      });
    }

    const supabase = getServerSupabase();
    if (supabase) {
      // Auditoría 03/10 (alto 10): sólo las filas que esta intención cobra.
      await guardarIntencionNave(supabase, cobro.filas.map((f: any) => String(f.id)), String(data.id));
    }

    return res.json({
      success: true,
      checkoutUrl: data.checkout_url,
      qrData: data.qr_data,
      naveId: data.id,
    });
  } catch (error: any) {
    console.error('[Nave Crear Intención Multiple Error]:', error);
    return res.status(500).json({ success: false, error: error?.message || 'Error al crear la intención de pago combinada en Nave' });
  }
});

// Webhook de Nave (Banco Galicia). Se registran dos rutas separadas (producción/sandbox) porque
// así se le pidió a Nave en el alta (dos "notification_url" distintas) — ambas hacen exactamente
// lo mismo, la única diferencia real es contra qué entorno reconsultan (getNaveEntorno() lee la
// misma variable NAVE_ENVIRONMENT para las dos, así que hoy en la práctica sólo una de las dos
// rutas va a coincidir con el entorno configurado; el día que haya credenciales de producción
// separadas convendría separar también esta lógica por ruta en vez de por variable de entorno).
//
// OJO — a diferencia de Resend y de Mercado Pago (que si se le configura MERCADOPAGO_WEBHOOK_SECRET
// firma con HMAC), la documentación de Nave relevada el 15/9/2026 no menciona ningún esquema de
// firma para verificar que esta notificación realmente vino de Nave. Por eso acá NUNCA se usa el
// estado ni el monto que vengan en el cuerpo del POST para decidir nada — sólo se usa para saber
// QUÉ pago hay que reconsultar, y el estado real siempre se obtiene con un GET propio (con
// nuestro access_token) contra la API de Nave. Tampoco se seguye el "payment_check_url" que
// manda la notificación tal cual: se arma la URL nosotros mismos con nuestra propia base
// (sandbox o producción, según NAVE_ENVIRONMENT) + el payment_id, para no arriesgarnos a que
// una notificación falsa con una URL propia nos haga mandarle nuestro access_token a otro lado.
// Auditoría 2026-09-21 (refuerzo): sin límite, una notificación falsa repetida a alta frecuencia
// obligaba a reconsultar la API de Nave una y otra vez (gasto/carga innecesaria). El límite es
// generoso a propósito para no bloquear notificaciones legítimas de Nave en picos de tráfico.
rutas.post(['/api/nave/webhook', '/api/nave/webhook-sandbox'], limitarFrecuencia('nave-webhook', 5000, 5 * 60 * 1000), async (req, res) => {
  try {
    const credenciales = getNaveCredenciales();
    if (!credenciales || !naveHabilitado()) {
      // Ver naveHabilitado (C1): un aviso de sandbox (o sin credenciales) nunca toca pedidos reales.
      console.warn('[Nave Webhook] Notificación ignorada: Nave no está habilitado en producción.');
      return res.status(200).send('OK');
    }

    const paymentId = req.body?.payment_id;
    if (!paymentId || !/^[\w-]{1,100}$/.test(String(paymentId))) {
      return res.status(200).send('OK');
    }
    // Auditoría 03/10: el aviso de Nave no está firmado; un mismo aviso (payment_id + estado que dice
    // traer) se reconsulta contra la API de Nave como mucho una vez cada 5 s (entre instancias). El
    // estado va en la clave para no frenar NUNCA el aviso APPROVED que llega segundos después del
    // PENDING. Si el aviso no trae estado, no se frena (sólo queda el límite general por IP): no hay
    // forma de saber si es un aviso nuevo. Un repetido recibe 503 (Nave lo reintenta).
    const estadoAviso = estadoPagoNave(req.body).replace(/[^\w-]/g, '').slice(0, 40);
    if (estadoAviso && !(await tocaTurnoDistribuido(`nave-webhook:${paymentId}:${estadoAviso}`, 5))) {
      return res.status(503).send('Retry later');
    }

    const accessToken = await obtenerNaveAccessToken();
    if (!accessToken) {
      console.error('[Nave Webhook] No se pudo autenticar contra Nave para reconfirmar el pago.');
      // 500 (antes 200): así Nave reintenta el aviso; además el control automático cada 10 min
      // (/api/cron/conciliar-pagos) lo recupera igual si el aviso no vuelve.
      return res.status(500).send('Error');
    }

    const { pagos } = getNaveUrls();
    const resp = await fetchNave(`${pagos}/${encodeURIComponent(String(paymentId))}`, {
      headers: { Authorization: `Bearer ${accessToken}` },
    });
    const pago: any = await resp.json().catch(() => null);
    if (!resp.ok || !pago) {
      console.error('[Nave Webhook] No se pudo reconsultar el pago', paymentId, resp.status);
      return res.status(500).send('Error');
    }

    const estadoNave: string = estadoPagoNave(pago);
    // Auditoría 2026-09-26 (A1, ALTO): antes, si la respuesta de Nave no traía external_payment_id,
    // se usaba el que viniera en el cuerpo del POST — que NO está firmado (cualquiera puede
    // mandarlo). Con un payment_id real aprobado (por ejemplo, de un pedido barato propio), un aviso
    // falso podía marcar pagado OTRO pedido. Ahora la referencia sale SÓLO de datos de Nave: su
    // external_payment_id, o el id de la intención de pago cruzado contra la que guardamos nosotros
    // al crearla (nave_payment_request_id).
    let pedidoId: string | undefined = pago?.external_payment_id ? String(pago.external_payment_id) : undefined;
    const supabase = getServerSupabase();
    if (!pedidoId && supabase) {
      const idIntencion = pago?.payment_request_id || pago?.payment_request?.id;
      if (idIntencion && /^[\w-]{1,100}$/.test(String(idIntencion))) {
        const { data: filaIntencion, error: errorIntencion } = await supabase
          .from('pedidos')
          .select('id, grupo_pago_id')
          .eq('nave_payment_request_id', String(idIntencion))
          .limit(1)
          .maybeSingle();
        if (errorIntencion) throw errorIntencion; // Auditoría 11/10: 500 → Nave reintenta (no es un pago huérfano)
        if (filaIntencion) pedidoId = filaIntencion.grupo_pago_id || filaIntencion.id;
        // Auditoría 03/10 noche (M3): también una intención anterior del mismo pedido.
        if (!pedidoId) {
          const { data: filaPrevia, error: errorPrevia } = await supabase
            .from('pedidos')
            .select('id, grupo_pago_id')
            .contains('nave_intenciones_previas', [String(idIntencion)])
            .limit(1)
            .maybeSingle();
          if (errorPrevia) throw errorPrevia;
          if (filaPrevia) pedidoId = filaPrevia.grupo_pago_id || filaPrevia.id;
        }
      }
    }
    if (!pedidoId) {
      console.warn(`[Nave Webhook] El pago ${paymentId} no trae una referencia verificable: no se toca ningún pedido.`);
      // Auditoría 03/10 (alto 9): si está aprobado, nadie lo iba a ver (la conciliación sólo revisa
      // intenciones que guardamos nosotros): queda alerta para revisarlo / devolverlo.
      if (estadoNave === 'APPROVED' && supabase) {
        await registrarAlertaPago(supabase, `pago-huerfano:${paymentId}`, `PAGO SIN PEDIDO: Nave aprobó el pago ${paymentId} sin una referencia que coincida con un pedido. Revisalo y devolvé el dinero si corresponde.`, { paymentId, monto: leerMontoNave(pago) });
      }
      return res.status(200).send('OK');
    }
    console.log(`[Nave Webhook] Pago ${paymentId} — estado: ${estadoNave}, pedido: ${pedidoId}`);

    if (estadoNave === 'APPROVED') {
      if (supabase) {
        const montoPagado = leerMontoNave(pago);
        const orderRows = await marcarReferenciaComoPagada(supabase, String(pedidoId), montoPagado, {
          nave_payment_id: String(paymentId),
        });
        await procesarPedidosRecienPagados(supabase, orderRows);
      }
    } else if (estadoNave === 'CHARGEBACK_REVIEW') {
      // Auditoría 03/10 (alto 11): un contracargo EN REVISIÓN todavía no es un contracargo: sólo aviso
      // (antes cancelaba el pedido y cortaba la descarga antes de tiempo).
      if (supabase) {
        await registrarAlertaPago(supabase, `contracargo-revision-nave:${paymentId}`, `Nave informa un CONTRACARGO EN REVISIÓN para el pago ${paymentId} (pedido ${pedidoId}). El pedido no se canceló: si el contracargo se confirma, se cancela solo.`, { paymentId, referencia: pedidoId });
      }
    } else if (['REJECTED', 'CANCELLED', 'PURCHASE_REVERSED', 'CHARGED_BACK', 'REFUNDED'].includes(estadoNave || '')) {
      if (supabase) {
        // REJECTED/CANCELLED (intento fallido antes de pagar) nunca revierte un pedido pagado ni uno
        // que ya no es de Nave. Contracargo / reversión / reembolso (DESPUÉS de cobrar) sí cancela,
        // pero sólo las filas pagadas con ESTE pago, y deja alerta.
        const esReversion = ['PURCHASE_REVERSED', 'CHARGED_BACK', 'REFUNDED'].includes(estadoNave || '');
        if (esReversion) {
          // Auditoría 03/10 (alto 11): cancelado_definitivo, así la conciliación de Nave (que ve la
          // intención como SUCCESS_PROCESSED) no lo vuelve a marcar "pagado".
          const { data: revertidos, error: errorRevertir } = await supabase
            .from('pedidos')
            .update({ estado: 'cancelado', cancelado_definitivo: true, updated_at: new Date().toISOString() })
            .eq('nave_payment_id', String(paymentId))
            .select('id, pedido_friendly_id');
          // Auditoría 11/10: un error de la base ya no se informa como "ningún pedido tiene ese pago": 500 y Nave reintenta.
          if (errorRevertir) throw errorRevertir;
          if (revertidos && revertidos.length > 0) {
            await registrarAlertaPago(supabase, `reversion-nave:${paymentId}`, `Nave informó "${estadoNave}" para el pago ${paymentId}: se cancelaron ${revertidos.map((r: any) => r.pedido_friendly_id || r.id).join(', ')}. Si ya estaba en laboratorio, frenalo.`, { paymentId, pedidos: revertidos });
          } else {
            // Auditoría 03/10 noche (M4): ninguna fila tiene ese id de pago (p. ej. se marcó pagado sin
            // él): no se cancela a ciegas, pero queda aviso para revisarlo a mano.
            await registrarAlertaPago(supabase, `reversion-nave-sin-fila:${paymentId}`, `Nave informó "${estadoNave}" para el pago ${paymentId} (referencia ${pedidoId}), pero ningún pedido tiene ese pago registrado. Revisá el pedido ${pedidoId} y cancelalo a mano si corresponde.`, { paymentId, referencia: pedidoId });
          }
        } else {
          console.log(`[Nave Webhook] Marcando pedido ${pedidoId} como cancelado (estado Nave: ${estadoNave}).`);
          const { data: dataCancelado } = await supabase
            .from('pedidos')
            .update({ estado: 'cancelado', updated_at: new Date().toISOString() })
            .eq('id', pedidoId)
            .eq('metodo_pago', 'nave')
            .eq('estado', 'pendiente_pago') // Auditoría 08/10 (M6): antes .neq('pagado') también cancelaba 'entregado'
            .eq('cancelado_definitivo', false)
            .select('id');
          if (!dataCancelado || dataCancelado.length === 0) {
            await supabase
              .from('pedidos')
              .update({ estado: 'cancelado', updated_at: new Date().toISOString() })
              .eq('grupo_pago_id', pedidoId)
              .eq('metodo_pago', 'nave')
              .eq('estado', 'pendiente_pago') // Auditoría 08/10 (M6): antes .neq('pagado') también cancelaba 'entregado'
              .eq('cancelado_definitivo', false);
          }
        }
      }
    }
    // PENDING no tiene resultado final todavía: no se toca nada.

    return res.status(200).send('OK');
  } catch (error: any) {
    console.error('[Nave Webhook Error]:', error);
    return res.status(500).send('Error');
  }
});

export { rutas as rutasNave };
