// Precios del sitio (GET /api/precios, POST /api/admin/precios) y el cálculo del total de un pedido
// (`calcularTotalPedido`, carpetas extra, fotos sueltas) (división de server.ts, etapa 6, 10/10/2026).
// El código es el mismo que estaba en la sección 7 de server.ts: sólo se movió de lugar.
import express from 'express';
import { requireAdminAuth } from '../nucleo/auth.js';
import { getServerSupabase } from '../nucleo/clientes.js';
import { aplicarPrecios, exigirPreciosCargados, marcarPreciosGuardados, PRECIO_CARPETA_EXTRA, PRECIO_FOTO_EVENTO, PRECIOS_KITS, preciosActuales, validarPrecios } from '../nucleo/precios.js';

const rutas = express.Router();

// ==============================================================================
// 7. INTEGRACIÓN MERCADO PAGO CHECKOUT PRO Y WEBHOOKS
// ==============================================================================


const MAX_CARPETAS_EXTRA = 20; // tope defensivo, no hay caso de uso real por encima de esto

rutas.get('/api/precios', exigirPreciosCargados, (_req, res) => {
  res.set('Cache-Control', 'public, max-age=60');
  res.json({ success: true, precios: preciosActuales() });
});

rutas.post('/api/admin/precios', requireAdminAuth, async (req, res) => {
  const nuevos = validarPrecios(req.body?.precios);
  if (!nuevos) return res.status(400).json({ success: false, error: 'Revisá los precios: tienen que ser números enteros entre $1.000 y $1.000.000.' });
  const supabase = getServerSupabase();
  if (!supabase) return res.status(500).json({ success: false, error: 'Supabase no configurado en el servidor' });
  const { error } = await supabase
    .from('configuracion')
    .upsert({ clave: 'precios_kits', valor: String(nuevos.kitClasico), datos_extra: nuevos, updated_at: new Date().toISOString() }, { onConflict: 'clave' });
  if (error) return res.status(500).json({ success: false, error: error.message });
  aplicarPrecios(nuevos);
  marcarPreciosGuardados();
  return res.json({ success: true, precios: nuevos });
});
export const MAX_FOTOS_SUELTAS = 50; // tope defensivo, no hay caso de uso real por encima de esto

// Única función que calcula lo que se cobra por un pedido — la usan tanto la creación de la
// preferencia de Mercado Pago como el registro del pedido en la base (ver auditoría
// 2026-09-09, punto de gestión "un solo lugar de verdad para los precios"). Devuelve null si
// el kit no se reconoce.
// La carpeta extra es una COPIA de la carpeta del "Kit Impreso + Digital": en un kit sin carpeta
// física no tiene sentido (y el laboratorio no tendría qué duplicar). El portal ya la resetea al
// cambiar de kit; esto lo garantiza del lado del servidor también.
export function carpetasExtrasValidas(kitId: string, carpetasExtras: unknown): number {
  if (kitId !== 'kit-clasico') return 0;
  return Math.min(MAX_CARPETAS_EXTRA, Math.max(0, Math.floor(Number(carpetasExtras) || 0)));
}

export function calcularTotalPedido(kitId: string, carpetasExtras: unknown, cantidadFotosSueltas: unknown = 0): number | null {
  const precioBaseKit = PRECIOS_KITS[kitId];
  if (precioBaseKit === undefined) return null;
  const extrasValidados = carpetasExtrasValidas(kitId, carpetasExtras);
  const fotosSueltasValidadas = Math.min(
    MAX_FOTOS_SUELTAS,
    Math.max(0, Math.floor(Number(cantidadFotosSueltas) || 0))
  );
  return precioBaseKit + extrasValidados * PRECIO_CARPETA_EXTRA + fotosSueltasValidadas * PRECIO_FOTO_EVENTO;
}

export { rutas as rutasPrecios };

// 14/10/2026 (Pablo): en secundaria no se vende el Kit Solo Digital (la foto es la grupal, igual para todo el
// curso: con un solo digital se la pasaban entre todos). Sólo el Kit Impreso (que trae la descarga HD).
// Debe coincidir con src/utils/kitsSecundaria.ts.
export const ERROR_DIGITAL_SECUNDARIA = 'En secundaria sólo está disponible el Kit Impreso + Digital. Elegí ese kit para continuar.';
export function esGradoDeSecundaria(grado: unknown): boolean {
  const g = String(grado ?? '').toLowerCase();
  return !g.includes('sala') && /\d+\s*°?\s*a[ñn]o(?!s)/.test(g);
}
// 29/10/2026 (Pablo): se vuelve a habilitar el Solo Digital en secundaria. Debe coincidir con la web.
export const SOLO_DIGITAL_EN_SECUNDARIA = true;
export function kitPermitidoParaGrado(kitId: unknown, grado: unknown): boolean {
  if (SOLO_DIGITAL_EN_SECUNDARIA) return true;
  return !(String(kitId) === 'kit-digital' && esGradoDeSecundaria(grado));
}
