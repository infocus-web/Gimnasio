// Pedido existente de la familia, buscador de pedidos y reenvío del link HD (división de server.ts,
// etapa 6, 10/10/2026). El código es el mismo que estaba al final de server.ts: sólo se movió.
import express from 'express';
import type { Request, Response } from 'express';
import { enviarCorreoFotosHD } from '../entrega/correos.js';
import { refirmarLinkDescargaHDSiExiste } from '../entrega/descargas.js';
import { generarYSubirZipHDParaPedido } from '../entrega/zipHD.js';
import { hijosDeFamiliaConAcceso } from '../familias/inscripciones.js';
import { pedidoHabilitaDescarga, tokenAccesoPedido, tokenAccesoValido } from '../nucleo/accesoPedidos.js';
import { getServerSupabase } from '../nucleo/clientes.js';
import { buscarSeccionPorCodigoSecreto, determinarCodigoCursoServidor } from '../nucleo/codigosCurso.js';
import { limitarFrecuencia, limitarFrecuenciaPersistente } from '../nucleo/limites.js';
import { esPedidoAdicional, kitPuedeSumarFotosExtra } from '../nucleo/fotosExtra.js';
import { precioMejoraAImpreso, preciosFotosExtraActuales } from '../nucleo/precios.js';
import { plazoKitImpresoAbierto } from './plazoKitImpreso.js';
import { asegurarPlazosActualizados } from '../nucleo/plazosTemporada.js';
import { normalizarNombrePorPalabras } from '../nucleo/utilidades.js';
import { hijosQueSonElAlumno } from './crearPedido.js';
import { pedidoPuedeMejorarAImpreso } from './mejoraImpreso.js';

const rutas = express.Router();

rutas.get('/api/pedidos/existente', limitarFrecuencia('pedidos-existente', 500, 10 * 60 * 1000), async (req: Request, res: Response) => {
  try {
    await asegurarPlazosActualizados(); // 30/10: «puedeComprarFotosExtra» usa la fecha del panel → Configuración
    // Auditoría 2026-09-23 (bug: el aviso de "ya tenés un pedido" NUNCA aparecía): el portal
    // mandaba acá el código SECRETO de la sección (ej. "88BU-M8TF") como `cursoCodigo`, pero
    // `pedidos.curso_codigo` guarda el código DETERMINÍSTICO de curso (ej. "GRADO1-ATM") que
    // calcula el servidor al crear el pedido — dos valores que nunca coinciden, así que la
    // respuesta era siempre `existe: false`. Ahora se reciben colegio/grado/turno/división y el
    // código de curso se recalcula acá con la misma fórmula que usa /api/pedidos/crear. Además se
    // filtra por colegio (el código de curso se repite entre colegios distintos).
    // Auditoría 2026-09-26 (C2, CRÍTICO): antes bastaba con colegio + grado/turno/división + nombre
    // del chico (datos que cualquier compañero conoce) y se devolvía el UUID del pedido, con el que
    // /api/pedidos/:id/status entregaba el link de las fotos HD. Ahora exige el código secreto de la
    // sección (el mismo que abre la galería) y el curso sale de ese código, no de lo que mande el
    // navegador. Además /status ya no entrega el link sin la llave de acceso del pedido.
    const alumnoNombre = String(req.query.alumnoNombre || '').trim().slice(0, 200);
    const codigo = String(req.query.codigo || '').trim().slice(0, 40);
    if (!codigo || !alumnoNombre) {
      return res.status(400).json({ success: false, error: 'Faltan datos del alumno.' });
    }

    const supabase = getServerSupabase();
    if (!supabase) return res.status(503).json({ success: false, error: 'Servicio de base de datos no disponible' });
    const seccion = await buscarSeccionPorCodigoSecreto(supabase, codigo);
    if (!seccion) return res.status(403).json({ success: false, error: 'Código de acceso incorrecto.' });
    const colegioId = seccion.colegioId;
    const cursoCodigo = determinarCodigoCursoServidor(seccion.grado, seccion.turno, seccion.division);

    const nombreBuscado = normalizarNombrePorPalabras(alumnoNombre);
    // Auditoría 05/10 (medio): el UUID del pedido (con el que se sube un comprobante o se crea la
    // mejora a impreso) sólo se devuelve a la familia del chico (llave de galería) o a quien tenga la
    // llave del pedido. Con sólo el código del curso y el nombre se informa que existe, nada más.
    const hijosConLlave = await hijosDeFamiliaConAcceso(supabase, req.query.familia, req.query.acceso);
    // Auditoría 08/10 (M5): sólo el hijo que ES el chico buscado (no uno de nombre parecido).
    const esDeLaFamilia = (await hijosQueSonElAlumno(supabase, req.query.familia, hijosConLlave, alumnoNombre, colegioId, cursoCodigo)).length > 0;
    const { data, error } = await supabase
      .from('pedidos')
      .select('id, pedido_friendly_id, alumno_nombre, kit_nombre, total, estado, created_at, seleccion_pendiente, metodo_pago, tipo_kit, mejora_de_pedido_id, extras_de_pedido_id, grupo_pago_id, comprobante_subido_at')
      .eq('curso_codigo', cursoCodigo)
      .eq('colegio_id', colegioId)
      .neq('estado', 'cancelado')
      // Auditoría 03/10 (2ª vuelta): sin los archivados por el cierre de temporada (otro año).
      .eq('archivado', false)
      .order('created_at', { ascending: false })
      .limit(50);
    if (error) throw error;

    // Si hay un kit pagado por adelantado esperando fotos, ése es el que importa mostrar.
    // Una reserva de pago anticipado que quedó SIN pagar (la familia volvió de la pasarela sin
    // pagar) no es un pedido: no se muestra "ya tenés un pedido registrado" por ella (caso real
    // 25/9: "Elegir otro medio de pago" llevaba a ese aviso). La reserva se vuelve a ofrecer en la
    // galería y, al crear una nueva, la vieja se cancela sola.
    const todosDelAlumno = (data || []).filter((p: any) => normalizarNombrePorPalabras(p.alumno_nombre) === nombreBuscado);
    // Las mejoras a Kit Impreso (27/9) no son un pedido propio: se muestran dentro del original.
    const propios = todosDelAlumno.filter((p: any) =>
      !esPedidoAdicional(p) && !(p.seleccion_pendiente && p.estado === 'pendiente_pago') // 29/10: tampoco las fotos extra
    );
    const encontrado = propios.find((p: any) => p.seleccion_pendiente && p.estado === 'pagado') || propios[0];
    if (!encontrado) {
      return res.json({ success: true, existe: false });
    }
    const mejoraPagada = todosDelAlumno.some((p: any) =>
      p.mejora_de_pedido_id === encontrado.id && (p.estado === 'pagado' || p.estado === 'entregado')
    );
    const puedeMejorarAImpreso = pedidoPuedeMejorarAImpreso(encontrado) && !mejoraPagada;
    const conLlave = esDeLaFamilia || tokenAccesoValido(req.query.t, [encontrado.id, (encontrado as any).grupo_pago_id]);
    // 14/10/2026: la llave del pedido sólo vivía en el navegador que lo creó; desde otro dispositivo la
    // familia veía el pedido pendiente pero no lo podía pagar ni cambiarle el medio. Ahora, si la familia
    // se identificó (llave de galería + el hijo ES el chico, el mismo control de arriba), se le da la llave
    // de un pedido pendiente (de su grupo de pago si es un carrito). Con sólo el código del curso, nunca.
    const grupoPago = (encontrado as any).grupo_pago_id || null;
    const accesoToken = esDeLaFamilia && encontrado.estado === 'pendiente_pago' ? tokenAccesoPedido(grupoPago || encontrado.id) : null;

    return res.json({
      success: true,
      existe: true,
      pedido: {
        id: encontrado.pedido_friendly_id || encontrado.id,
        kit: encontrado.kit_nombre,
        // Siempre número: el portal hace total.toLocaleString() y un null rompía la pantalla.
        total: Number(encontrado.total) || 0,
        estado: encontrado.estado,
        fecha: encontrado.created_at,
        reservaPendiente: Boolean((encontrado as any).seleccion_pendiente) && encontrado.estado === 'pagado',
        // Para pedir el comprobante si es una transferencia sin confirmar (ver SubirComprobante).
        // Auditoría 05/10: sólo con la llave de la familia o del pedido.
        pedidoUuid: conLlave ? encontrado.id : null,
        requiereLlave: !conLlave,
        metodoPago: (encontrado as any).metodo_pago || null,
        puedeMejorarAImpreso,
        mejoraAImpresoPagada: mejoraPagada,
        precioMejoraAImpreso: precioMejoraAImpreso(),
        grupoPagoId: conLlave ? grupoPago : null,
        accesoToken,
        // 14/10/2026: transferencia con comprobante en revisión (el portal no invita a pagar de nuevo).
        comprobanteSubido: Boolean((encontrado as any).comprobante_subido_at),
        // 29/10/2026: fotos extra (copias impresas aparte) para un kit ya pagado, hasta la fecha límite del Kit Impreso.
        puedeComprarFotosExtra: kitPuedeSumarFotosExtra(encontrado) && plazoKitImpresoAbierto(),
        fotosExtraPagadas: todosDelAlumno.filter((p: any) => p.extras_de_pedido_id === encontrado.id && (p.estado === 'pagado' || p.estado === 'entregado')).length,
        preciosFotosExtra: preciosFotosExtraActuales(),
      },
    });
  } catch (err: any) {
    console.error('Error al verificar pedido existente:', err);
    return res.status(500).json({ success: false, error: err?.message || 'Error al verificar si ya existe un pedido.' });
  }
});

// Auditoría 2026-09-09 (revisión a fondo): el buscador de "seguimiento de pedido" del Portal de
// Familias buscaba únicamente en el localStorage del navegador — una familia que entrara desde
// otro dispositivo o hubiera borrado los datos del navegador no encontraba su pedido, aunque
// estuviera pagado y guardado en Supabase. Este endpoint público (sin login, como corresponde a
// una búsqueda que hace la propia familia con su número de pedido o teléfono) permite buscar
// contra los datos reales.
//
// Auditoría 2026-09-19 (bug real encontrado en auditoría de seguridad): el diseño original de
// este endpoint decía ser "deliberadamente angosto para no poder usarse para barrer la base de
// pedidos de otras familias", pero no lo era: buscaba con `ilike('%query%')` (coincide con
// CUALQUIER parte del texto) contra un número de pedido con sólo ~9.000 combinaciones posibles
// (se genera en el navegador como IFS-2026-<4 dígitos al azar>) y devolvía nombre, teléfono y un
// link de descarga de fotos HD válido por 90 días — bastaba probar "0000".."9999" como número de
// 4 dígitos para ir sacando, pedido por pedido, los datos de cualquier familia. Se corrige así:
//   1) Coincidencia EXACTA del número de pedido completo (ya no alcanza con un fragmento) y con
//      el formato validado (IFS-2026-XXXX) — ya no sirve probar únicamente 4 dígitos sueltos.
//   2) Para la búsqueda por teléfono, se exige el número casi completo (8+ dígitos en vez de 6)
//      — sigue permitiendo que una familia lo tipee sin el 0 o el 15 iniciales, pero ya no
//      alcanza con adivinar sólo 6 dígitos al azar.
//   3) (28/9: 15 intentos cada 30 minutos por IP, contados en Supabase para todas las instancias,
//      y el nombre del alumno y del tutor se devuelven abreviados — "Olivia S.".)
//      Antes: el límite de intentos por IP baja de 15 cada 10 minutos a 5 cada 30 minutos, específico
//      para este endpoint, para que ni siquiera intentando desde una sola IP real (que además
//      Vercel no deja falsificar, ver x-forwarded-for) sea práctico recorrer las combinaciones
//      posibles.
const FORMATO_PEDIDO_FRIENDLY_ID = /^[A-Z]{2,4}-\d{4}-\d{3,5}$/;

// "olivia ayelen sanchez" → "Olivia S."
function nombreAbreviado(nombre: unknown): string {
  const partes = String(nombre || '').trim().split(/\s+/).filter(Boolean);
  if (partes.length === 0) return '';
  const cap = (t: string) => t.charAt(0).toUpperCase() + t.slice(1).toLowerCase();
  return partes.length === 1 ? cap(partes[0]) : `${cap(partes[0])} ${partes[partes.length - 1].charAt(0).toUpperCase()}.`;
}

rutas.get('/api/pedidos/buscar', limitarFrecuenciaPersistente('pedidos-buscar', 15, 30 * 60 * 1000), async (req, res) => {
  try {
    const qRaw = String(req.query.query || '').trim();
    if (!qRaw) {
      return res.status(400).json({ success: false, error: 'Ingresá tu número de pedido o teléfono.' });
    }
    const query = qRaw.toUpperCase().slice(0, 60);
    const soloDigitos = query.replace(/\D/g, '');

    const supabase = getServerSupabase();
    if (!supabase) {
      return res.status(503).json({ success: false, error: 'Servicio de base de datos no disponible' });
    }

    const columnas = 'id, pedido_friendly_id, colegio_nombre, alumno_nombre, grado, division, kit_nombre, total, estado, created_at, link_descarga_hd, seleccion_pendiente, familias(nombre, whatsapp)';
    let fila: any = null;

    if (FORMATO_PEDIDO_FRIENDLY_ID.test(query)) {
      const { data } = await supabase
        .from('pedidos')
        .select(columnas)
        .ilike('pedido_friendly_id', query)
        .order('created_at', { ascending: false })
        .limit(1);
      if (data && data.length > 0) fila = data[0];
    }

    // Auditoría 2026-09-23 (privacidad): el teléfono de una familia NO es un secreto (lo tiene
    // todo el grupo de WhatsApp del curso — mismo criterio que ya se aplica en
    // /api/inscripciones/buscar). Antes, buscando por teléfono se devolvía el link de descarga de
    // las fotos HD pagadas y el teléfono completo. Ahora, por teléfono sólo se informa el estado
    // del pedido; el link HD se devuelve únicamente buscando por el número de pedido exacto (que
    // sólo tiene la familia, en su correo/comprobante), y el link igual le llega por email.
    let encontradoPorTelefono = false;
    if (!fila && soloDigitos.length >= 8) {
      const { data, error } = await supabase
        .from('pedidos')
        .select('id, pedido_friendly_id, colegio_nombre, alumno_nombre, grado, division, kit_nombre, total, estado, created_at, link_descarga_hd, seleccion_pendiente, familias!inner(nombre, whatsapp)')
        // Auditoría 11/10: el teléfono se guarda como lo tipeó la familia ("11 5555-1234", "+54 9 …"): se
        // aceptan separadores (no dígitos) entre dígitos y se usan los últimos 10, al final del número (revisión: con «%»
        // cualquier número que tuviera esos dígitos salteados coincidía). `soloDigitos` sólo tiene 0-9.
        .filter('familias.whatsapp', 'imatch', `${soloDigitos.slice(-10).split('').join('[^0-9]*')}[^0-9]*$`)
        .order('created_at', { ascending: false })
        .limit(1);
      if (error) console.warn('[pedidos/buscar] búsqueda por teléfono falló:', error.message);
      if (data && data.length > 0) {
        fila = data[0];
        encontradoPorTelefono = true;
      }
    }

    if (!fila) {
      return res.status(404).json({ success: false, error: 'No se encontró ningún pedido registrado con ese número o teléfono.' });
    }

    // Auditoría 2026-09-26 (A2, ALTO): este buscador ya NO devuelve el link de descarga HD. El
    // número de pedido (IFS-2026-XXXX, ~9.000 combinaciones) se puede adivinar probando, y con eso
    // se obtenían las fotos HD de cualquier chico. Ahora, si el pedido está cobrado y tiene su .zip,
    // se ofrece "Reenviarme el link por email": el link se manda SÓLO al email de la familia que
    // hizo el pedido (POST /api/pedidos/reenviar-link).
    void encontradoPorTelefono;
    const puedeReenviarLink = pedidoHabilitaDescarga(fila.estado) && Boolean(fila.link_descarga_hd) && !fila.seleccion_pendiente;
    const telefonoCompleto = String(fila.familias?.whatsapp || '');
    // El teléfono se muestra siempre enmascarado: la familia ya lo conoce, y el número de pedido
    // (4 dígitos) no es un secreto lo bastante fuerte como para devolver un dato de contacto.
    const telefonoMostrado = telefonoCompleto ? `***${telefonoCompleto.replace(/\D/g, '').slice(-4)}` : null;

    return res.json({
      success: true,
      pedido: {
        id: fila.pedido_friendly_id || fila.id,
        colegio: fila.colegio_nombre,
        // Abreviados (28/9): la familia se reconoce igual y un número adivinado no revela nombres completos.
        alumno: nombreAbreviado(fila.alumno_nombre),
        grado: fila.grado,
        division: fila.division,
        tutor: nombreAbreviado(fila.familias?.nombre) || null,
        telefono: telefonoMostrado,
        kit: fila.kit_nombre,
        total: Number(fila.total) || 0,
        fecha: fila.created_at,
        estado: fila.estado,
        linkDescargaHD: null,
        puedeReenviarLink,
        reservaPendiente: Boolean(fila.seleccion_pendiente),
      },
    });
  } catch (err: any) {
    console.error('Error al buscar pedido:', err);
    return res.status(500).json({ success: false, error: err?.message || 'Error al buscar el pedido' });
  }
});

// Auditoría 2026-09-26 (A2): reenvía el link de descarga HD de un pedido cobrado, SIEMPRE al email
// de la familia que lo hizo (nunca a uno que se escriba acá) — así el número de pedido deja de
// alcanzar para obtener las fotos. Límite bajo: cada pedido admite un reenvío cada 10 minutos.
const ultimoReenvioLink = new Map<string, number>();
// Auditoría 30/9 (M5): límite guardado en la base (compartido por todas las instancias).
rutas.post('/api/pedidos/reenviar-link', limitarFrecuenciaPersistente('pedidos-reenviar-link', 10, 30 * 60 * 1000), async (req: Request, res: Response) => {
  try {
    const numero = String(req.body?.numero || '').trim().toUpperCase().slice(0, 60);
    if (!FORMATO_PEDIDO_FRIENDLY_ID.test(numero)) {
      return res.status(400).json({ success: false, error: 'Ingresá el número de pedido completo (ej. IFS-2026-1234).' });
    }
    const supabase = getServerSupabase();
    if (!supabase) return res.status(503).json({ success: false, error: 'Servicio de base de datos no disponible' });
    const { data: fila } = await supabase
      .from('pedidos')
      .select('*, familias(nombre, email)')
      .eq('pedido_friendly_id', numero)
      .maybeSingle();
    // Misma respuesta genérica si no existe o no corresponde, para no confirmar números válidos.
    const respuestaGenerica = { success: true, mensaje: 'Si el pedido está pagado, te mandamos el link de descarga al email con el que lo hiciste.' };
    const email = String(fila?.familias?.email || '');
    // Auditoría 05/10: una mejora a Kit Impreso (mejora_de_pedido_id) no tiene .zip propio; el HD lo
    // tiene el pedido original. Misma respuesta genérica, sin armar zip ni mandar mail.
    if (!fila || !pedidoHabilitaDescarga(fila.estado) || fila.seleccion_pendiente || esPedidoAdicional(fila) || !email.includes('@')) {
      return res.json(respuestaGenerica);
    }
    const ultimo = ultimoReenvioLink.get(fila.id);
    if (ultimo && Date.now() - ultimo < 10 * 60 * 1000) return res.json(respuestaGenerica);
    ultimoReenvioLink.set(fila.id, Date.now());
    // Máximo 1 reenvío cada 10 minutos por pedido, contado en la base (la marca en memoria de arriba
    // es por instancia de Vercel y no alcanzaba para evitar que le llenen la casilla a una familia).
    try {
      const { data: espera } = await supabase.rpc('registrar_intento', { p_clave: `reenvio-link:${fila.id}`, p_max: 1, p_ventana_seg: 10 * 60 });
      if (Number(espera) > 0) return res.json(respuestaGenerica);
    } catch {
      /* si falla el contador, sigue con el límite en memoria */
    }
    const link = (await refirmarLinkDescargaHDSiExiste(supabase, fila)) || (await generarYSubirZipHDParaPedido(supabase, fila));
    if (!link) return res.json(respuestaGenerica);
    const resultado = await enviarCorreoFotosHD({
      to: email,
      tutorNombre: fila.familias?.nombre || 'Familia',
      alumnoNombre: fila.alumno_nombre || 'tu hijo/a',
      colegioNombre: fila.colegio_nombre || 'tu colegio',
      cursoCodigo: fila.curso_codigo || undefined,
      kitNombre: fila.kit_nombre || undefined,
      pedidoId: fila.pedido_friendly_id || fila.id,
      total: Number(fila.total) || 0,
      linkDescargaHD: link,
      pedidoUuid: fila.id,
    });
    if (!resultado?.success) console.warn('[reenviar-link] No se pudo reenviar el correo HD:', resultado?.error);
    // Siempre la misma respuesta (sin el email enmascarado): así no sirve para saber qué números de
    // pedido existen y están pagados.
    return res.json(respuestaGenerica);
  } catch (err: any) {
    console.error('[reenviar-link] Error:', err);
    return res.status(500).json({ success: false, error: 'No pudimos reenviar el link. Probá de nuevo en unos minutos.' });
  }
});

export { rutas as rutasBuscadorPedidos };
