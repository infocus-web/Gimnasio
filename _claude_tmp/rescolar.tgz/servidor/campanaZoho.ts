// Campaña de prospección a colegios por Zoho Mail: cliente OAuth2 de Zoho (tokens guardados en la
// base), plantillas y envío uno por uno, y sus rutas del panel (/api/admin/zoho/*, /api/zoho/callback)
// (división de server.ts, etapa 2, 10/10/2026). El código es el mismo que estaba en server.ts (la
// sección "ZOHO MAIL" de la configuración y la de sus rutas): sólo se movió de lugar. Las rutas se
// declaran con el path completo en `rutas` y server.ts las monta con app.use(rutasCampanaZoho) en el
// mismo lugar donde estaban.
import crypto from 'crypto';
import express, { Request, Response } from 'express';
import { getAdminSessionSecret, requireAdminAuth } from './nucleo/auth.js';
import { getServerSupabase } from './nucleo/clientes.js';
import { limitarFrecuencia } from './nucleo/limites.js';
import { escapeHtml } from './nucleo/utilidades.js';

const rutas = express.Router();

// ==============================================================================
// ZOHO MAIL — CAMPAÑA DE PROSPECCIÓN A COLEGIOS (agregado 22/9/2026 a pedido de Pablo)
// La función nativa "Mail Merge" de la interfaz web de Zoho falló con un error genérico
// ("Disculpas: Algo salió mal") tanto con la cuenta principal (ventas@contacto...) como con
// el alias (colegios@contacto...) y sin dejar ningún registro en el historial — todo indica
// un bloqueo de envío masivo a nivel de cuenta nueva, no un problema de datos ni de alias.
// Esta integración evita esa función puntual: manda los correos uno por uno con la API REST
// de Zoho Mail (POST /api/accounts/{accountId}/messages), autenticada por OAuth2. Datacenter
// zoho.com (US), confirmado en la consola de API de Zoho al crear la aplicación.
const ZOHO_ACCOUNTS_BASE = 'https://accounts.zoho.com';
const ZOHO_SCOPES = 'ZohoMail.messages.CREATE,ZohoMail.accounts.READ';
// Lista blanca de remitentes — sin esto, cualquiera que pudiera llamar al endpoint de envío
// (aun detrás de requireAdminAuth) podría hacer que el "De" fuera una dirección arbitraria.
const ZOHO_REMITENTES_PERMITIDOS = [
  'colegios@contacto.retratoescolar.com.ar',
  'ventas@contacto.retratoescolar.com.ar',
];

function getZohoCredenciales(): { clientId: string; clientSecret: string; redirectUri: string } | null {
  const clientId = process.env.ZOHO_CLIENT_ID?.trim();
  const clientSecret = process.env.ZOHO_CLIENT_SECRET?.trim();
  const redirectUri = process.env.ZOHO_REDIRECT_URI?.trim();
  if (!clientId || !clientSecret || !redirectUri) return null;
  return { clientId, clientSecret, redirectUri };
}

interface ZohoTokensGuardados {
  accessToken: string;
  refreshToken: string;
  accountId: string;
  apiDomain: string;
  cuentaEmail: string | null;
  expiresAt: number; // epoch ms
}

async function obtenerZohoTokensGuardados(): Promise<ZohoTokensGuardados | null> {
  const supabase = getServerSupabase();
  if (!supabase) return null;
  const { data, error } = await supabase.from('zoho_oauth_tokens').select('*').eq('id', true).maybeSingle();
  if (error || !data) return null;
  return {
    accessToken: data.access_token,
    refreshToken: data.refresh_token,
    accountId: data.account_id,
    apiDomain: data.api_domain,
    cuentaEmail: data.cuenta_email,
    expiresAt: new Date(data.expires_at).getTime(),
  };
}

// Guarda la conexión completa — SOLO se usa en el callback de OAuth, la primera vez que se
// conecta una cuenta (o al reconectar). Todos los campos son obligatorios a propósito.
async function guardarZohoTokens(tokens: {
  accessToken: string;
  refreshToken: string;
  accountId: string;
  apiDomain: string;
  cuentaEmail: string | null;
  expiresAt: number;
}) {
  const supabase = getServerSupabase();
  if (!supabase) throw new Error('Supabase no configurado.');
  const { error } = await supabase.from('zoho_oauth_tokens').upsert({
    id: true,
    access_token: tokens.accessToken,
    refresh_token: tokens.refreshToken,
    account_id: tokens.accountId,
    api_domain: tokens.apiDomain,
    cuenta_email: tokens.cuentaEmail,
    expires_at: new Date(tokens.expiresAt).toISOString(),
    updated_at: new Date().toISOString(),
  }, { onConflict: 'id' });
  if (error) throw error;
}

// Bug real detectado el 22/9/2026: la renovación automática del access_token (ver más abajo)
// llamaba a guardarZohoTokens() con solo accessToken/expiresAt, confiando en que el upsert
// dejara el resto de las columnas (refresh_token, account_id, api_domain) como estaban. En
// realidad, el upsert de Supabase arma un INSERT ... ON CONFLICT DO UPDATE que también
// actualiza esas columnas con NULL cuando no vienen en el payload — y como refresh_token es
// NOT NULL, la renovación fallaba siempre con "null value in column refresh_token violates
// not-null constraint", dejando la conexión rota hasta desconectar y reconectar a mano. Esta
// función SÍ usa un UPDATE común (no upsert), que solo toca las columnas que le pasamos.
async function actualizarZohoAccessToken(accessToken: string, expiresAt: number): Promise<void> {
  const supabase = getServerSupabase();
  if (!supabase) throw new Error('Supabase no configurado.');
  const { error } = await supabase
    .from('zoho_oauth_tokens')
    .update({ access_token: accessToken, expires_at: new Date(expiresAt).toISOString(), updated_at: new Date().toISOString() })
    .eq('id', true);
  if (error) throw error;
}

// Devuelve un access_token vigente, renovándolo con el refresh_token si ya venció (con 2
// minutos de margen). Nunca pide el consentimiento de nuevo: eso solo pasa una vez, al
// conectar la cuenta desde el panel.
async function obtenerZohoAccessTokenValido(): Promise<ZohoTokensGuardados | null> {
  const creds = getZohoCredenciales();
  if (!creds) return null;
  const tokens = await obtenerZohoTokensGuardados();
  if (!tokens) return null;
  if (tokens.expiresAt - Date.now() > 2 * 60 * 1000) return tokens;
  try {
    const resp = await fetch(`${ZOHO_ACCOUNTS_BASE}/oauth/v2/token`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        refresh_token: tokens.refreshToken,
        client_id: creds.clientId,
        client_secret: creds.clientSecret,
        grant_type: 'refresh_token',
      }),
    });
    const data: any = await resp.json().catch(() => ({}));
    if (!resp.ok || !data?.access_token) {
      console.error('[Zoho] Error al renovar access_token:', resp.status, data);
      return null;
    }
    const nuevoExpiresAt = Date.now() + (Number(data.expires_in) || 3600) * 1000;
    await actualizarZohoAccessToken(data.access_token, nuevoExpiresAt);
    return { ...tokens, accessToken: data.access_token, expiresAt: nuevoExpiresAt };
  } catch (err) {
    console.error('[Zoho] Error de red al renovar access_token:', err);
    return null;
  }
}

interface DestinatarioCampanaZoho {
  email: string;
  institucion?: string;
  localidad_partido?: string;
  nivel?: string;
}

// Reemplaza las variables {{institucion}}, {{localidad_partido}} y {{nivel}} del asunto/cuerpo
// de la plantilla con los datos reales de cada colegio.
function personalizarPlantillaZoho(texto: string, destinatario: DestinatarioCampanaZoho): string {
  return String(texto || '')
    .replace(/\{\{\s*institucion\s*\}\}/gi, destinatario.institucion || '')
    .replace(/\{\{\s*localidad_partido\s*\}\}/gi, destinatario.localidad_partido || '')
    .replace(/\{\{\s*nivel\s*\}\}/gi, destinatario.nivel || '');
}

// Bug real detectado el 22/9/2026 en el primer correo de prueba: la API de Zoho Mail interpreta
// el campo "content" como HTML. Pablo escribe la plantilla como texto plano normal (con saltos
// de línea y viñetas "• "), y al mandarlo tal cual, sin ninguna etiqueta HTML, el cliente de
// correo colapsa todos los saltos de línea — el mail llegó como un solo párrafo corrido, sin
// forma de carta. Esta función convierte ese texto plano a un HTML simple y prolijo (párrafos,
// viñetas como lista real, y links autodetectados) antes de mandarlo.
// Pablo pidió (22/9/2026) que se vea "lindo, con color" como el mail de "fotos en HD listas"
// (franja oscura + naranja arriba, cajas con color para destacar puntos) en vez de texto plano
// en blanco y negro. Se reutiliza la misma paleta de esos templates: navy #0f172a + naranja
// #f59e0b/#d97706 en el header, caja celeste con tildes verdes para las viñetas, y una placa
// ámbar/roja para el título de sección en mayúsculas — todo generado a partir del texto plano
// que Pablo escribe en el panel, sin que tenga que tocar HTML él.
function formatearCuerpoCartaHtml(textoPlano: string): string {
  // Comillas incluidas: los links se insertan dentro de href="..." (una URL con " rompía el HTML).
  const escapeHtml = (s: string) => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  const linkificar = (s: string) => s.replace(/(https?:\/\/[^\s<"]+)/g, '<a href="$1" style="color:#1d4ed8;">$1</a>');
  const esTituloCorto = (l: string) => l.length > 0 && l.length <= 45 && l === l.toUpperCase() && /[A-ZÁÉÍÓÚÑ]/.test(l);

  const bloques = String(textoPlano || '').trim().split(/\n\s*\n/);
  const cuerpoHtml = bloques.map((bloque) => {
    const lineas = bloque.split('\n').map((l) => l.trim()).filter((l) => l.length > 0);
    if (lineas.length === 0) return '';

    // Un renglón corto y en MAYÚSCULAS ("COBERTURA ESCOLAR 2026") se destaca como placa de color
    // en vez de quedar como una línea de texto más.
    if (lineas.length === 1 && esTituloCorto(lineas[0])) {
      return `<div style="margin:22px 0 14px 0;"><span style="display:inline-block;background-color:#fef3c7;color:#b91c1c;font-size:12px;font-weight:800;letter-spacing:1px;padding:6px 14px;border-radius:999px;">${escapeHtml(lineas[0])}</span></div>`;
    }

    // Viñetas ("• ") → caja con marco celeste y tilde verde por ítem, no una lista pelada.
    const esLista = lineas.every((l) => l.startsWith('• '));
    if (esLista) {
      const items = lineas
        .map((l) => `<p style="margin:0 0 8px 0;font-size:14px;line-height:1.5;color:#1e3a5f;"><span style="color:#059669;font-weight:800;">✓</span>&nbsp;${linkificar(escapeHtml(l.slice(2)))}</p>`)
        .join('');
      return `<div style="margin:0 0 20px 0;padding:16px 18px;background-color:#eff6ff;border:1px solid #bfdbfe;border-radius:12px;">${items}</div>`;
    }

    // Un párrafo compuesto solo por un link (el de "conocé la propuesta completa") → botón de
    // acción naranja, igual que el resto de los correos del sitio, en vez de un texto azul.
    if (lineas.length === 1 && /^https?:\/\//i.test(lineas[0])) {
      const url = escapeHtml(lineas[0]);
      return `<div style="margin:24px 0;text-align:center;"><a href="${url}" target="_blank" rel="noopener noreferrer" style="display:inline-block;background-color:#d97706;color:#ffffff;font-size:14px;font-weight:700;text-decoration:none;padding:13px 28px;border-radius:12px;box-shadow:0 4px 12px rgba(217,119,6,0.35);">Ver la propuesta completa →</a></div>`;
    }

    return `<p style="margin:0 0 16px 0;font-size:14px;line-height:1.6;color:#334155;">${lineas.map((l) => linkificar(escapeHtml(l))).join('<br>')}</p>`;
  }).filter(Boolean).join('\n');

  // OJO — bug real detectado el 22/9/2026: acá había un documento HTML completo propio
  // (<!DOCTYPE>, <html>, <head>, <body>). Zoho mete el "content" que le mandamos DENTRO de su
  // propio documento de correo, así que terminaba habiendo un <html>/<body> anidado dentro de
  // otro — Gmail interpreta esa estructura como si fuera contenido citado/recortado y lo pliega
  // detrás de un "..." por default (el correo llegaba con el cuerpo escondido). La solución es
  // mandar solo el fragmento de contenido, sin documento propio — como el resto de los templates
  // de este archivo que sí usan Resend directamente.
  return `<div style="font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Helvetica,Arial,sans-serif;color:#1e293b;max-width:600px;margin:0 auto;">
  <div style="background-color:#ffffff;border-radius:16px;border:1px solid #e2e8f0;overflow:hidden;box-shadow:0 4px 6px -1px rgba(0,0,0,0.05);">
    <div style="background-color:#0f172a;padding:32px 24px;text-align:center;border-bottom:3px solid #f59e0b;">
      <div style="font-size:11px;font-weight:800;letter-spacing:2px;color:#f59e0b;text-transform:uppercase;margin-bottom:6px;">RETRATO ESCOLAR • PRODUCTORA INFOCUS</div>
      <h1 style="color:#ffffff;margin:0;font-size:21px;font-weight:800;letter-spacing:-0.5px;">Propuesta de Cobertura Fotográfica 2026</h1>
    </div>
    <div style="padding:28px 24px;">
      ${cuerpoHtml}
    </div>
    <div style="background-color:#f1f5f9;padding:18px 24px;text-align:center;font-size:11px;color:#64748b;border-top:1px solid #e2e8f0;">
      © 2026 Retrato Escolar • Fotografía Escolar Profesional<br>
      <a href="https://retratoescolar.com.ar" style="color:#d97706;text-decoration:none;font-weight:600;">retratoescolar.com.ar</a>
    </div>
  </div>
</div>`;
}

async function enviarZohoMail(params: {
  fromAddress: string;
  toAddress: string;
  subject: string;
  content: string;
}): Promise<{ ok: boolean; messageId?: string; error?: string }> {
  const tokens = await obtenerZohoAccessTokenValido();
  if (!tokens) return { ok: false, error: 'Zoho no está conectado, o no se pudo renovar el token de acceso.' };
  try {
    const resp = await fetch(`${tokens.apiDomain}/api/accounts/${tokens.accountId}/messages`, {
      method: 'POST',
      headers: {
        Authorization: `Zoho-oauthtoken ${tokens.accessToken}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        fromAddress: params.fromAddress,
        toAddress: params.toAddress,
        subject: params.subject,
        content: formatearCuerpoCartaHtml(params.content),
        askReceipt: 'no',
      }),
    });
    const data: any = await resp.json().catch(() => ({}));
    if (!resp.ok || data?.status?.code !== 200) {
      return { ok: false, error: data?.data?.moreInfo || data?.status?.description || `Zoho respondió con error HTTP ${resp.status}.` };
    }
    return { ok: true, messageId: data?.data?.messageId };
  } catch (err: any) {
    return { ok: false, error: err?.message || 'Error de red al llamar a la API de Zoho Mail.' };
  }
}

// ==============================================================================
// RUTAS: ZOHO MAIL — CAMPAÑA DE PROSPECCIÓN A COLEGIOS
// ==============================================================================

// 1) Inicia el flujo OAuth: devuelve la URL de consentimiento de Zoho para que el panel
// redirija al navegador. Requiere sesión de admin — solo Pablo puede iniciar esto.
rutas.get('/api/admin/zoho/connect', requireAdminAuth, (req: Request, res: Response) => {
  const creds = getZohoCredenciales();
  if (!creds) {
    return res.status(500).json({
      success: false,
      error: 'ZOHO_CLIENT_ID / ZOHO_CLIENT_SECRET / ZOHO_REDIRECT_URI no están configuradas en las variables de entorno del servidor.',
    });
  }
  const sessionSecret = getAdminSessionSecret();
  if (!sessionSecret) {
    return res.status(500).json({ success: false, error: 'ADMIN_SESSION_SECRET no configurada en las variables de entorno del servidor.' });
  }
  // El callback de abajo llega como una navegación normal del navegador (Zoho redirige ahí
  // directamente), sin nuestro header de admin — este "state" firmado es lo que prueba que
  // el flujo lo inició una sesión de admin válida, y evita que alguien lo dispare por CSRF.
  const timestamp = Date.now();
  const random = crypto.randomBytes(12).toString('hex');
  const payload = `${timestamp}.${random}`;
  // Auditoría 30/9 (A5): se firma con un prefijo propio. Antes el "state" tenía exactamente el mismo
  // formato y firma que un token de admin: quien lo viera en una URL (logs, historial) tenía sesión
  // de admin por 24 hs.
  const signature = crypto.createHmac('sha256', sessionSecret).update(`zoho-state:${payload}`).digest('hex');
  const state = `${payload}.${signature}`;

  const url = new URL(`${ZOHO_ACCOUNTS_BASE}/oauth/v2/auth`);
  url.searchParams.set('response_type', 'code');
  url.searchParams.set('client_id', creds.clientId);
  url.searchParams.set('scope', ZOHO_SCOPES);
  url.searchParams.set('redirect_uri', creds.redirectUri);
  url.searchParams.set('access_type', 'offline'); // imprescindible para recibir refresh_token
  url.searchParams.set('prompt', 'consent');
  url.searchParams.set('state', state);
  res.json({ success: true, url: url.toString() });
});

// 2) Callback: Zoho redirige el navegador acá después de que Pablo acepta el consentimiento.
// Ruta pública (no puede llevar el header de admin), protegida por la firma del "state".
rutas.get('/api/zoho/callback', async (req: Request, res: Response) => {
  const redirigirConError = (mensaje: string) => res.redirect(`/?zoho=error&mensaje=${encodeURIComponent(mensaje)}`);
  try {
    const { code, state, error: zohoError } = req.query as { code?: string; state?: string; error?: string };
    if (zohoError) return redirigirConError(`Zoho rechazó la conexión: ${zohoError}`);
    if (!code || !state) return redirigirConError('Falta el código o el estado de la conexión.');

    const sessionSecret = getAdminSessionSecret();
    if (!sessionSecret) return redirigirConError('ADMIN_SESSION_SECRET no configurada en el servidor.');
    const partes = state.split('.');
    if (partes.length !== 3) return redirigirConError('Estado de conexión inválido.');
    const [timestampStr, random, signature] = partes;
    const timestamp = parseInt(timestampStr, 10);
    if (isNaN(timestamp) || Date.now() - timestamp > 10 * 60 * 1000) {
      return redirigirConError('El enlace de conexión expiró — iniciá el proceso de nuevo desde el panel.');
    }
    const esperada = crypto.createHmac('sha256', sessionSecret).update(`zoho-state:${timestampStr}.${random}`).digest('hex');
    const sigBuf = Buffer.from(signature);
    const expBuf = Buffer.from(esperada);
    if (sigBuf.length !== expBuf.length || !crypto.timingSafeEqual(sigBuf, expBuf)) {
      return redirigirConError('Estado de conexión inválido.');
    }

    const creds = getZohoCredenciales();
    if (!creds) return redirigirConError('Credenciales de Zoho no configuradas en el servidor.');

    const tokenResp = await fetch(`${ZOHO_ACCOUNTS_BASE}/oauth/v2/token`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        code,
        client_id: creds.clientId,
        client_secret: creds.clientSecret,
        redirect_uri: creds.redirectUri,
        grant_type: 'authorization_code',
      }),
    });
    const tokenData: any = await tokenResp.json().catch(() => ({}));
    if (!tokenResp.ok || !tokenData.access_token || !tokenData.refresh_token) {
      // Sin imprimir tokenData: puede traer el access_token (auditoría 30/9).
      console.error('[Zoho] Error al intercambiar código por tokens:', tokenResp.status, tokenData?.error || '(sin detalle)');
      return redirigirConError('Zoho no devolvió un token válido.');
    }
    // OJO — bug real encontrado el 22/9/2026: el "api_domain" que devuelve el token de OAuth es
    // el dominio genérico de la API de Zoho (el que usan CRM, Books, etc., algo como
    // www.zohoapis.com), NO el de Zoho Mail. Zoho Mail vive en un dominio propio y separado
    // por datacenter (mail.zoho.com para EE.UU., mail.zoho.eu, mail.zoho.in, etc.) — nunca hay
    // que derivarlo del "api_domain" del token. Como la cuenta de Pablo es del datacenter de
    // EE.UU. (confirmado al crear la app en la consola de Zoho), queda fijo en mail.zoho.com.
    const apiDomain = 'https://mail.zoho.com';

    // Con el access_token recién obtenido pedimos el accountId (lo exige el endpoint de envío)
    // y el email de la cuenta, para poder mostrarlo en el panel.
    const cuentasResp = await fetch(`${apiDomain}/api/accounts`, {
      headers: { Authorization: `Zoho-oauthtoken ${tokenData.access_token}` },
    });
    const cuentasData: any = await cuentasResp.json().catch(() => ({}));
    const primeraCuenta = cuentasData?.data?.[0];
    if (!cuentasResp.ok || !primeraCuenta?.accountId) {
      console.error('[Zoho] Error al obtener accountId:', cuentasResp.status, cuentasData);
      const detalle = cuentasData?.data?.errorCode || cuentasData?.data?.moreInfo || cuentasData?.message;
      return redirigirConError(`No se pudo obtener la cuenta de Zoho conectada.${detalle ? ` (${detalle})` : ''}`);
    }

    await guardarZohoTokens({
      accessToken: tokenData.access_token,
      refreshToken: tokenData.refresh_token,
      accountId: String(primeraCuenta.accountId),
      apiDomain,
      cuentaEmail: primeraCuenta.primaryEmailAddress || null,
      expiresAt: Date.now() + (Number(tokenData.expires_in) || 3600) * 1000,
    });

    return res.redirect('/?zoho=conectado');
  } catch (err) {
    console.error('[Zoho] Error en callback OAuth:', err);
    return redirigirConError('Error inesperado al conectar con Zoho.');
  }
});

// 3) Estado de la conexión — usado por el panel para mostrar "conectado como X" o el botón de
// conectar.
rutas.get('/api/admin/zoho/estado', requireAdminAuth, async (req: Request, res: Response) => {
  const tokens = await obtenerZohoTokensGuardados();
  res.json({
    success: true,
    conectado: Boolean(tokens),
    cuentaEmail: tokens?.cuentaEmail || null,
    remitentesPermitidos: ZOHO_REMITENTES_PERMITIDOS,
    zohoConfigurado: Boolean(getZohoCredenciales()),
  });
});

// 4) Desconectar (borra los tokens guardados; no revoca el permiso del lado de Zoho, pero deja
// a esta app sin forma de mandar correos hasta reconectar).
rutas.post('/api/admin/zoho/desconectar', requireAdminAuth, async (req: Request, res: Response) => {
  const supabase = getServerSupabase();
  if (!supabase) return res.status(500).json({ success: false, error: 'Supabase no configurado.' });
  const { error } = await supabase.from('zoho_oauth_tokens').delete().eq('id', true);
  if (error) return res.status(500).json({ success: false, error: error.message });
  res.json({ success: true });
});

// 5) Correo de prueba — SIEMPRE manda a un único destinatario que se pasa explícitamente
// (nunca a un colegio real), usando los datos del primer colegio de ejemplo para previsualizar
// cómo quedan las variables personalizadas. Es un paso obligatorio antes de habilitar el envío
// real (ver el chequeo en /api/admin/zoho/enviar más abajo).
rutas.post('/api/admin/zoho/prueba', requireAdminAuth, limitarFrecuencia('zoho-prueba', 15, 10 * 60 * 1000), async (req: Request, res: Response) => {
  try {
    const { destinatarioEjemplo, asunto, cuerpoHtml, remitente, emailPrueba } = req.body || {};
    if (typeof remitente !== 'string' || !ZOHO_REMITENTES_PERMITIDOS.includes(remitente)) {
      return res.status(400).json({ success: false, error: 'Remitente no permitido.' });
    }
    if (typeof asunto !== 'string' || !asunto.trim() || typeof cuerpoHtml !== 'string' || !cuerpoHtml.trim()) {
      return res.status(400).json({ success: false, error: 'Falta el asunto o el cuerpo del correo.' });
    }
    if (typeof emailPrueba !== 'string' || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(emailPrueba.trim())) {
      return res.status(400).json({ success: false, error: 'Falta un email de destino válido para la prueba.' });
    }
    const destinatario: DestinatarioCampanaZoho = destinatarioEjemplo || {};
    const asuntoPersonalizado = personalizarPlantillaZoho(asunto, destinatario);
    const cuerpoPersonalizado = personalizarPlantillaZoho(cuerpoHtml, destinatario);
    const resultado = await enviarZohoMail({
      fromAddress: remitente,
      toAddress: emailPrueba.trim(),
      subject: `[PRUEBA] ${asuntoPersonalizado}`,
      content: cuerpoPersonalizado,
    });
    const supabase = getServerSupabase();
    if (supabase) {
      await supabase.from('zoho_campana_envios').insert({
        destinatario_email: emailPrueba.trim().toLowerCase(),
        institucion: destinatario.institucion || null,
        asunto: asuntoPersonalizado,
        tipo: 'prueba',
        estado: resultado.ok ? 'enviado' : 'error',
        zoho_message_id: resultado.messageId || null,
        error: resultado.error || null,
      });
    }
    if (!resultado.ok) return res.status(502).json({ success: false, error: resultado.error });
    res.json({ success: true });
  } catch (err: any) {
    console.error('[Zoho] Error al mandar correo de prueba:', err);
    res.status(500).json({ success: false, error: err?.message || 'Error inesperado al mandar el correo de prueba.' });
  }
});

// 6) Envío real — en lotes chicos (máx. 15 por llamada, el panel los va encadenando) para no
// pisar el límite de 60s de la función serverless. Salvaguardas: exige un remitente de la
// lista blanca, exige que haya al menos una prueba exitosa en las últimas 24hs, salta
// destinatarios a los que ya se les mandó un correo real antes (dedup), y espera un poco entre
// cada envío para no disparar límites de tasa / filtros antispam de Zoho.
// Ritmo seguro para la campaña por Zoho: 1 correo cada 15 s, 3 por llamada (entra holgado en
// los 60 s de la función), máx. 20 por hora y 80 por día. Lo que no entra se retoma después:
// el dedup de más abajo saltea a quien ya recibió la campaña.
const ZOHO_CAMPANA_MAX_POR_LLAMADA = 3;
const ZOHO_CAMPANA_PAUSA_MS = 15_000;
const ZOHO_CAMPANA_MAX_POR_HORA = 20;
const ZOHO_CAMPANA_MAX_POR_DIA = 80;

async function cupoCampanaZoho(supabase: any): Promise<{ ok: boolean; mensaje?: string }> {
  const contar = async (ms: number) => {
    const { count } = await supabase
      .from('zoho_campana_envios')
      .select('id', { count: 'exact', head: true })
      .eq('tipo', 'real')
      .eq('estado', 'enviado')
      .gte('created_at', new Date(Date.now() - ms).toISOString());
    return count || 0;
  };
  if ((await contar(24 * 60 * 60 * 1000)) >= ZOHO_CAMPANA_MAX_POR_DIA) {
    return { ok: false, mensaje: `Llegaste al máximo seguro de ${ZOHO_CAMPANA_MAX_POR_DIA} correos por día con Zoho. Retomá mañana: a quienes ya les llegó no se les vuelve a mandar.` };
  }
  if ((await contar(60 * 60 * 1000)) >= ZOHO_CAMPANA_MAX_POR_HORA) {
    return { ok: false, mensaje: `Llegaste al máximo seguro de ${ZOHO_CAMPANA_MAX_POR_HORA} correos por hora con Zoho. Retomá en un rato: a quienes ya les llegó no se les vuelve a mandar.` };
  }
  return { ok: true };
}

rutas.post('/api/admin/zoho/enviar', requireAdminAuth, limitarFrecuencia('zoho-enviar', 40, 10 * 60 * 1000), async (req: Request, res: Response) => {
  try {
    const { destinatarios, asunto, cuerpoHtml, remitente } = req.body || {};
    if (typeof remitente !== 'string' || !ZOHO_REMITENTES_PERMITIDOS.includes(remitente)) {
      return res.status(400).json({ success: false, error: 'Remitente no permitido.' });
    }
    if (typeof asunto !== 'string' || !asunto.trim() || typeof cuerpoHtml !== 'string' || !cuerpoHtml.trim()) {
      return res.status(400).json({ success: false, error: 'Falta el asunto o el cuerpo del correo.' });
    }
    if (!Array.isArray(destinatarios) || destinatarios.length === 0) {
      return res.status(400).json({ success: false, error: 'No hay destinatarios para enviar.' });
    }
    if (destinatarios.length > ZOHO_CAMPANA_MAX_POR_LLAMADA) {
      return res.status(400).json({ success: false, error: `Máximo ${ZOHO_CAMPANA_MAX_POR_LLAMADA} destinatarios por llamada — el panel los manda en lotes automáticamente.` });
    }

    const supabase = getServerSupabase();
    if (!supabase) return res.status(500).json({ success: false, error: 'Supabase no configurado.' });

    const { data: pruebaReciente } = await supabase
      .from('zoho_campana_envios')
      .select('id')
      .eq('tipo', 'prueba')
      .eq('estado', 'enviado')
      .gte('created_at', new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString())
      .limit(1);
    if (!pruebaReciente || pruebaReciente.length === 0) {
      return res.status(412).json({
        success: false,
        error: 'Mandá primero un correo de prueba exitoso (en las últimas 24hs) antes de habilitar el envío real.',
      });
    }

    const resultados: { email: string; estado: 'enviado' | 'error' | 'omitido'; error?: string }[] = [];
    let primero = true;
    for (const destinatario of destinatarios as DestinatarioCampanaZoho[]) {
      // Tope de ritmo (Zoho bloqueó colegios@ el 22/9 por mandar ~100 por minuto): se cuenta lo
      // enviado de verdad en la última hora y en las últimas 24 h, así el tope vale aunque se
      // recargue el panel o se abran dos pestañas.
      const cupo = await cupoCampanaZoho(supabase);
      if (!cupo.ok) {
        return res.status(429).json({ success: false, resultados, limite: true, error: cupo.mensaje });
      }
      if (!primero) await new Promise((resolve) => setTimeout(resolve, ZOHO_CAMPANA_PAUSA_MS));
      primero = false;
      const email = String(destinatario?.email || '').trim().toLowerCase();
      if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
        resultados.push({ email: destinatario?.email || '(vacío)', estado: 'error', error: 'Email inválido.' });
        continue;
      }
      // Dedup: si ya le mandamos una campaña real exitosa a este email, lo salteamos — evita
      // reescribirle a la misma institución si Pablo repite el envío tras un corte a mitad de
      // camino.
      const { data: yaEnviado } = await supabase
        .from('zoho_campana_envios')
        .select('id')
        .eq('destinatario_email', email)
        .eq('tipo', 'real')
        .eq('estado', 'enviado')
        .limit(1);
      if (yaEnviado && yaEnviado.length > 0) {
        resultados.push({ email, estado: 'omitido' });
        continue;
      }
      const asuntoPersonalizado = personalizarPlantillaZoho(asunto, destinatario);
      const cuerpoPersonalizado = personalizarPlantillaZoho(cuerpoHtml, destinatario);
      const resultado = await enviarZohoMail({
        fromAddress: remitente,
        toAddress: email,
        subject: asuntoPersonalizado,
        content: cuerpoPersonalizado,
      });
      await supabase.from('zoho_campana_envios').insert({
        destinatario_email: email,
        institucion: destinatario.institucion || null,
        asunto: asuntoPersonalizado,
        tipo: 'real',
        estado: resultado.ok ? 'enviado' : 'error',
        zoho_message_id: resultado.messageId || null,
        error: resultado.error || null,
      });
      resultados.push({ email, estado: resultado.ok ? 'enviado' : 'error', error: resultado.error });
      // Si Zoho empieza a rechazar por volumen/bloqueo, se corta enseguida: insistir agrava el bloqueo.
      // Texto real del 22/9: "550 5.4.6 Unusual sending activity detected. Please try after sometime."
      if (!resultado.ok && /block|bloque|limit|exceed|spam|suspend|too many|rate|unusual|5\.4\.6|usage.policy/i.test(String(resultado.error || ''))) {
        return res.status(429).json({
          success: false,
          resultados,
          limite: true,
          error: 'Zoho rechazó el envío por límite o bloqueo de la cuenta. Se frenó la campaña para no empeorarlo; revisá tu casilla de Zoho.',
        });
      }
    }
    res.json({ success: true, resultados });
  } catch (err: any) {
    console.error('[Zoho] Error al mandar campaña real:', err);
    res.status(500).json({ success: false, error: err?.message || 'Error inesperado al mandar la campaña.' });
  }
});

// 7) Historial — bitácora de lo mandado (de prueba y real) para el panel.
rutas.get('/api/admin/zoho/historial', requireAdminAuth, async (req: Request, res: Response) => {
  const supabase = getServerSupabase();
  if (!supabase) return res.status(500).json({ success: false, error: 'Supabase no configurado.' });
  const { data, error } = await supabase
    .from('zoho_campana_envios')
    .select('*')
    .order('created_at', { ascending: false })
    .limit(200);
  if (error) return res.status(500).json({ success: false, error: error.message });
  res.json({ success: true, envios: data });
});

export { rutas as rutasCampanaZoho };
