// Emails de la entrega (división de server.ts, etapa 3, 10/10/2026): «ya están tus fotos» al publicar
// un curso, actualizaciones del pedido, el email con el link HD, mejora a impreso y reserva
// confirmadas. El código es el mismo que estaba en la sección "5. HELPER PARA ENVÍO DE EMAIL CON
// RESEND" de server.ts: sólo se movió de lugar.
import type { SupabaseClient } from '@supabase/supabase-js';
import crypto from 'crypto';
import { tokenAccesoPedido } from '../nucleo/accesoPedidos.js';
import { getResendClient, resendReplyTo } from '../nucleo/clientes.js';
import { colegioTieneBuscadorRostro } from '../nucleo/rostros.js';
import { plazosVigentes, textoFechaCorta } from '../nucleo/plazosTemporada.js';
import { escapeHtml, traerTodasLasFilas } from '../nucleo/utilidades.js';

export type SeccionFotosDisponible = { colegioId: string; codigoCurso: string; grado: string; turno: string; division: string };

export function mismoDatoSeccion(a: unknown, b: unknown): boolean {
  const normalizar = (valor: unknown) => String(valor ?? '').trim().toLocaleLowerCase('es-AR')
    .normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/\s+/g, ' ');
  return normalizar(a) === normalizar(b);
}

// 14/10/2026: devuelve cuántos avisos confirmó Resend y a cuántas familias había que avisar, así el panel
// sabe si quedó alguno sin salir y puede reenviarlo. `sufijoClave` sólo lo usa el reenvío manual (sin él,
// Resend devolvería la respuesta del primer intento sin mandar nada).
// 24/10/2026 (Pablo): en el mail «ya están tus fotos», el buscador por rostro y qué pasa si faltó una foto (sin
// mencionar repetir una foto que no gustó). Privacidad: mismo texto que BuscadorRostro.tsx (TEXTO_PRIVACIDAD_ROSTRO).
// 25/10/2026 (Pablo): el mail dice hasta cuándo se puede pedir la foto faltante («15/11»). 30/10: la fecha sale del
// panel → Configuración (servidor/nucleo/plazosTemporada.ts), por eso el bloque se arma al mandar el mail.
export const bloqueBuscadorRostro = (): string =>
  '<div style="margin-top:20px;background:#eef2ff;border:1px solid #c7d2fe;border-radius:10px;padding:14px 16px;line-height:1.6">' +
  '<p style="margin:0 0 8px"><strong>¿No encontrás la foto de tu hijo/a?</strong> Nuestra galería tiene un <strong>buscador con reconocimiento facial de última generación</strong>: en la pestaña «Individual» tocá «Buscar por rostro», subí una foto del rostro de tu hijo/a y el sistema encuentra sus fotos en todo el colegio en segundos.</p>' +
  '<p style="margin:0 0 8px">Si a tu hijo/a le faltó alguna foto porque no estuvo el día de la toma, avisanos desde la galería con el botón <strong>«Mi hijo/a no tiene esta foto»</strong> <strong>hasta el ' + textoFechaCorta(plazosVigentes().faltantes) + ' inclusive</strong> y la tomamos en los próximos días.</p>' +
  '<p style="margin:0;font-size:12px;color:#475569"><strong>Tu privacidad, primero.</strong> La foto que subís se usa únicamente para encontrar las fotos de tu hijo/a en la galería de Retrato Escolar y no se guarda. Las imágenes no se usan para entrenar inteligencia artificial ni para ningún otro fin: el reconocimiento lo hace nuestro proveedor de infraestructura (Amazon Web Services) sólo para esta búsqueda, y toda la información se borra al finalizar el año escolar.</p>' +
  '</div>';

export async function avisarFotosDisponiblesASeccion(
  supabase: SupabaseClient,
  seccion: SeccionFotosDisponible,
  opciones: { sufijoClave?: string } = {}
): Promise<{ enviados: number; total: number; yaAvisados: number }> {
  const resend = getResendClient();
  if (!resend) throw new Error('RESEND_API_KEY no está configurada; no se enviaron los avisos de galería.');
  // 24/10: el buscador por rostro se nombra sólo si este colegio lo tiene (caras cargadas + AWS configurado).
  const conBuscadorRostro = await colegioTieneBuscadorRostro(supabase, seccion.colegioId);

  // Paginado: en un colegio con más de 1000 familias aprobadas, las que quedaban fuera del tope
  // nunca recibían el aviso de "tus fotos ya están online".
  const inscripciones = await traerTodasLasFilas<any>((desde, hasta) =>
    supabase
      .from('inscripciones')
      .select('id,email,padre_nombre,alumno_nombre,colegio_nombre,grado,turno,division,hermanos')
      .eq('colegio_id', seccion.colegioId)
      .eq('estado', 'aceptado')
      .order('id')
      .range(desde, hasta)
  );

  const destinatarios = new Map<string, { id: string; email: string; tutor: string; alumno: string; colegio: string; reservaPagada?: boolean }>();
  for (const inscripcion of inscripciones || []) {
    const alumnos = [
      { nombre: inscripcion.alumno_nombre, grado: inscripcion.grado, turno: inscripcion.turno, division: inscripcion.division },
      ...(Array.isArray(inscripcion.hermanos) ? inscripcion.hermanos.map((h: any) => ({
        nombre: h.alumnoNombre || h.alumno_nombre,
        grado: h.grado,
        turno: h.turno,
        division: h.division,
      })) : []),
    ];
    const alumnoDelCurso = alumnos.find((alumno) =>
      mismoDatoSeccion(alumno.grado, seccion.grado)
      && mismoDatoSeccion(alumno.turno, seccion.turno)
      && mismoDatoSeccion(alumno.division, seccion.division)
    );
    const email = String(inscripcion.email || '').trim().toLowerCase();
    if (!alumnoDelCurso || !email.includes('@') || destinatarios.has(email)) continue;
    destinatarios.set(email, {
      id: String(inscripcion.id),
      email,
      tutor: inscripcion.padre_nombre || 'Familia',
      alumno: alumnoDelCurso.nombre || 'el alumno/a',
      colegio: inscripcion.colegio_nombre || 'la institución',
    });
  }

  // Pago anticipado: las familias que ya pagaron el kit de este curso reciben el aviso aunque el
  // email de la reserva no coincida con el de la inscripción, y con el texto "ya está pago, sólo
  // falta elegir" (si no, parece que tienen que volver a comprar).
  const { data: reservasPagadas, error: errorReservas } = await supabase
    .from('pedidos')
    .select('id, alumno_nombre, colegio_nombre, familias(nombre, email)')
    .eq('colegio_id', seccion.colegioId)
    .eq('curso_codigo', seccion.codigoCurso)
    .eq('estado', 'pagado')
    .eq('seleccion_pendiente', true);
  if (errorReservas) console.error('[fotos] No se pudieron leer las reservas pagadas del curso:', errorReservas);
  for (const reserva of reservasPagadas || []) {
    const familia: any = Array.isArray((reserva as any).familias) ? (reserva as any).familias[0] : (reserva as any).familias;
    const email = String(familia?.email || '').trim().toLowerCase();
    if (!email.includes('@')) continue;
    const previo = destinatarios.get(email);
    destinatarios.set(email, {
      id: previo?.id || `reserva-${reserva.id}`,
      email,
      tutor: previo?.tutor || familia?.nombre || 'Familia',
      alumno: reserva.alumno_nombre || previo?.alumno || 'el alumno/a',
      colegio: previo?.colegio || reserva.colegio_nombre || 'la institución',
      reservaPagada: true,
    });
  }

  // Auditoría 2026-09-23 (bug real): antes se mandaban TODOS los avisos a la vez con
  // Promise.allSettled + emails.send — Resend limita a ~2 pedidos por segundo, así que en un curso
  // con más de un par de familias casi todos los avisos volvían con error 429 (rate limit) y esas
  // familias nunca se enteraban de que sus fotos estaban online. Ahora se usa la API de lotes de
  // Resend (hasta 100 correos por pedido), de a un lote por vez.
  // 25/10 (auditoría): a quién ya le salió el aviso de este curso (avisos_fotos_destinatarios, hash del email). Antes,
  // si Resend rechazaba algunas direcciones, «Reenviar aviso» les volvía a escribir a todas (duplicado). Ahora se manda
  // sólo a las que faltan, y cada lote se anota apenas Resend lo confirma (si la función se corta, no se repite).
  const huellaEmail = (email: string) => crypto.createHash('sha256').update(email.trim().toLowerCase()).digest('hex');
  const { data: avisadas, error: errorAvisadas } = await supabase
    .from('avisos_fotos_destinatarios')
    .select('email_hash')
    .eq('colegio_id', seccion.colegioId)
    .eq('codigo_curso', seccion.codigoCurso);
  // Sin la tabla (migración 20261025090000 sin aplicar) se manda como antes, a todo el curso. Otro error (pasajero):
  // se corta, así no se le repite el aviso a quien ya lo tenía (el panel muestra «Reenviar aviso» para reintentar).
  const sinTablaAvisados = ['42P01', 'PGRST205'].includes(String((errorAvisadas as any)?.code || ''));
  if (errorAvisadas && !sinTablaAvisados) throw new Error(`No se pudo leer a quién ya se avisó: ${errorAvisadas.message}`);
  if (errorAvisadas) console.warn('[fotos] Falta la tabla avisos_fotos_destinatarios (migración sin aplicar): se avisa a todo el curso.');
  const yaAvisadas = new Set((avisadas || []).map((f: any) => String(f.email_hash)));
  const todas = Array.from(destinatarios.values());
  const lista = todas.filter((d) => !yaAvisadas.has(huellaEmail(d.email)));
  const armarCorreo = (destinatario: { email: string; tutor: string; alumno: string; colegio: string; reservaPagada?: boolean }) => ({
    from: process.env.RESEND_FROM_EMAIL || 'Retrato Escolar <fotos@retratoescolar.com.ar>',
    replyTo: resendReplyTo,
    to: [destinatario.email],
    subject: `Las fotos de ${destinatario.alumno} ya están online`,
    html: `<!doctype html><html lang="es"><body style="margin:0;background:#f8fafc;font-family:Arial,sans-serif;color:#1e293b"><div style="max-width:600px;margin:24px auto;background:#fff;border:1px solid #e2e8f0;border-radius:16px;overflow:hidden"><div style="background:#0f172a;padding:28px 24px;text-align:center;border-bottom:3px solid #f59e0b"><div style="color:#f59e0b;font-size:11px;font-weight:800;letter-spacing:2px">RETRATO ESCOLAR</div><h1 style="color:#fff;font-size:22px;margin:8px 0 0">¡Las fotos ya están online!</h1></div><div style="padding:28px 24px"><p>Hola <strong>${escapeHtml(destinatario.tutor)}</strong>,</p><p style="line-height:1.6">Las fotografías de <strong>${escapeHtml(destinatario.alumno)}</strong>, de ${escapeHtml(seccion.grado)} "${escapeHtml(seccion.division)}" · Turno ${escapeHtml(seccion.turno)}, ya están disponibles para ver y elegir.</p>${destinatario.reservaPagada ? '<p style="line-height:1.6;background:#ecfdf5;border:1px solid #a7f3d0;border-radius:10px;padding:12px 14px;color:#065f46"><strong>Tu kit ya está pago</strong>: entrá, elegí tus 3 fotos favoritas y tocá <strong>"Confirmar mis fotos"</strong>. No tenés que volver a pagar; apenas las confirmes te llega la descarga en alta resolución.</p>' : ''}<div style="margin:24px 0;text-align:center"><a href="https://retratoescolar.com.ar" style="display:inline-block;background:#fbbf24;color:#0f172a;text-decoration:none;font-weight:800;padding:13px 22px;border-radius:10px">${destinatario.reservaPagada ? 'Elegir mis fotos' : 'Ver mis fotos'}</a></div><p style="font-size:12px;color:#64748b">Ingresá con el mismo código de acceso que recibiste al aprobarse tu inscripción en ${escapeHtml(destinatario.colegio)}.</p>${conBuscadorRostro ? bloqueBuscadorRostro() : ''}<div style="margin-top:20px;text-align:center;border-top:1px solid #e2e8f0;padding-top:18px"><p style="margin:0 0 10px;font-size:14px;color:#475569">¿Tenés algún problema o una duda?</p><a href="https://retratoescolar.com.ar/?consulta=1&amp;colegio=${encodeURIComponent(destinatario.colegio || '')}#contacto" style="display:inline-block;background:#ffffff;color:#0f172a;text-decoration:none;font-weight:700;padding:11px 20px;border-radius:10px;border:2px solid #0f172a">Escribinos una consulta</a></div></div></div></body></html>`,
  });

  let enviados = 0;
  const TAMANO_LOTE = 100;
  for (let i = 0; i < lista.length; i += TAMANO_LOTE) {
    const lote = lista.slice(i, i + TAMANO_LOTE);
    try {
      const resultado = await resend.batch.send(lote.map(armarCorreo), {
        idempotencyKey: `fotos-online-${crypto.createHash('sha256').update(`${seccion.colegioId}|${seccion.codigoCurso}|${lote.map((d) => d.id).join(',')}`).digest('hex')}${opciones.sufijoClave ? `-${opciones.sufijoClave}` : ''}`,
        batchValidation: 'permissive',
      });
      if (resultado.error) {
        console.error(`[fotos] Falló un lote de ${lote.length} avisos automáticos:`, resultado.error);
        continue;
      }
      const rechazados: Array<{ index?: number }> = (resultado.data as any)?.errors || [];
      const erroresLote = rechazados.length;
      if (erroresLote > 0) console.error(`[fotos] ${erroresLote} aviso(s) del lote rechazados por Resend:`, rechazados);
      enviados += lote.length - erroresLote;
      const indicesRechazados = new Set(rechazados.map((e) => Number(e?.index)));
      // Sin el índice del rechazo no se sabe a quién no le llegó: no se anota nadie de ese lote (mejor repetir que omitir).
      const salieron = rechazados.some((e) => !Number.isInteger(e?.index)) ? [] : lote.filter((_, j) => !indicesRechazados.has(j));
      if (!errorAvisadas && salieron.length > 0) {
        const { error: errorAnotar } = await supabase.from('avisos_fotos_destinatarios').upsert(
          salieron.map((d) => ({ colegio_id: seccion.colegioId, codigo_curso: seccion.codigoCurso, email_hash: huellaEmail(d.email), enviado_at: new Date().toISOString() })),
          { onConflict: 'colegio_id,codigo_curso,email_hash', ignoreDuplicates: true }
        );
        if (errorAnotar) console.error('[fotos] No se pudo anotar a quién se avisó:', errorAnotar.message);
      }
    } catch (errLote) {
      console.error(`[fotos] Error de red enviando un lote de ${lote.length} avisos:`, errLote);
    }
    if (i + TAMANO_LOTE < lista.length) await new Promise((resolve) => setTimeout(resolve, 600));
  }
  if (enviados < lista.length) console.error(`[fotos] Fallaron ${lista.length - enviados} de ${lista.length} avisos automáticos.`);
  return { enviados, total: lista.length, yaAvisados: todas.length - lista.length };
}

interface DatosCorreoFotosHD {
  to: string;
  tutorNombre?: string;
  alumnoNombre?: string;
  colegioNombre?: string;
  cursoCodigo?: string;
  pedidoId?: string;
  kitNombre?: string;
  total?: number;
  linkDescargaHD?: string;
  esImpreso?: boolean;
  /** UUID del pedido: si viene, el botón del correo pasa por /api/descargas/:id (registra la descarga). */
  pedidoUuid?: string;
  /**
   * Auditoría 03/10 (alto 17): sólo para los envíos AUTOMÁTICOS (webhook y cron). Resend descarta un
   * segundo envío con la misma clave dentro de 24 h, así dos crons (o webhook + cron) no le mandan
   * el mismo correo dos veces a la familia. El reenvío manual del panel no la usa (tiene que salir).
   */
  idempotencyKey?: string;
}

export type TipoActualizacionPedido = 'en_produccion' | 'listo_retiro';

// Auditoría 05/10: `reenvio` = el admin volvió a avisar la misma etapa a propósito. Resend guarda la
// clave de idempotencia 24 h, así que con la clave diaria un reenvío el mismo día devolvía la
// respuesta vieja sin mandar nada; para un reenvío explícito la clave lleva la hora exacta.
export async function enviarCorreoActualizacionPedido(datos: { tipo: TipoActualizacionPedido; to: string; tutorNombre: string; alumnoNombre: string; colegioNombre: string; pedidoId: string; pedidoFriendlyId?: string; reenvio?: boolean }) {
  const resend = getResendClient();
  if (!resend) throw new Error('RESEND_API_KEY no está configurada.');
  const esProduccion = datos.tipo === 'en_produccion';
  const titulo = esProduccion ? 'Tu pedido está en producción' : 'Tu pedido está listo para retirar';
  const mensaje = esProduccion ? `El pedido de fotografías de <strong>${escapeHtml(datos.alumnoNombre)}</strong> ya ingresó al laboratorio y se encuentra en producción.` : `El pedido de fotografías de <strong>${escapeHtml(datos.alumnoNombre)}</strong> ya está listo. Podés retirarlo en <strong>${escapeHtml(datos.colegioNombre)}</strong>.`;
  const detalle = esProduccion ? 'Te enviaremos un nuevo aviso cuando esté disponible para retirar en el colegio.' : 'Consultá en la institución los días y horarios habilitados para la entrega.';
  // Auditoría 2026-09-18 (reporte de Pablo): este correo mostraba "datos.pedidoId" tal cual, que
  // es el UUID interno de Supabase (necesario para que el servidor encuentre la fila), no el
  // número de pedido legible (IFS-2026-XXXX) que ve el cliente en el resto de los correos y en
  // el Portal. Se muestra "pedidoFriendlyId" cuando viene informado, y sólo si falta se cae al
  // UUID (mejor eso que no mostrar nada).
  const pedidoMostrado = datos.pedidoFriendlyId || datos.pedidoId;
  const resultado = await resend.emails.send({
    from: process.env.RESEND_FROM_EMAIL || 'Retrato Escolar <fotos@retratoescolar.com.ar>', replyTo: resendReplyTo, to: [datos.to], subject: `${titulo} — ${datos.alumnoNombre}`,
    html: `<!doctype html><html lang="es"><body style="margin:0;background:#f8fafc;font-family:Arial,sans-serif;color:#1e293b"><div style="max-width:600px;margin:24px auto;background:#fff;border:1px solid #e2e8f0;border-radius:16px;overflow:hidden"><div style="background:#0f172a;padding:28px 24px;text-align:center;border-bottom:3px solid #f59e0b"><div style="color:#f59e0b;font-size:11px;font-weight:800;letter-spacing:2px">RETRATO ESCOLAR</div><h1 style="color:#fff;font-size:22px;margin:8px 0 0">${titulo}</h1></div><div style="padding:28px 24px"><p>Hola <strong>${escapeHtml(datos.tutorNombre || 'Familia')}</strong>,</p><p style="line-height:1.6">${mensaje}</p><div style="margin:22px 0;padding:16px;background:${esProduccion ? '#eef2ff' : '#ecfdf5'};border-radius:12px;line-height:1.5">${detalle}</div><p style="font-size:12px;color:#64748b">Pedido: <strong>${escapeHtml(pedidoMostrado)}</strong></p></div></div></body></html>`,
  }, { idempotencyKey: claveIdempotenciaActualizacionPedido(datos.tipo, datos.pedidoId, datos.reenvio === true) }); // 25/10: opción documentada del SDK (antes headers)
  if (resultado.error) throw new Error(resultado.error.message);
  return resultado;
}

// Auditoría 05/10: clave diaria (webhook/cron/lote no repiten el mismo aviso en 24 h); con `reenvio`
// lleva un sufijo para que el reenvío manual salga de verdad. 14/10/2026: el sufijo es el tramo de 2 minutos
// (antes la hora exacta): un doble clic en «Reenviar aviso» no le duplica el email a la familia.
export function claveIdempotenciaActualizacionPedido(tipo: string, pedidoId: string, reenvio: boolean, ahora = Date.now()): string {
  const base = `estado-${tipo}-${pedidoId}-${new Date(ahora).toISOString().slice(0, 10)}`;
  return reenvio ? `${base}-r${Math.floor(ahora / 120_000)}` : base;
}

export async function enviarCorreoFotosHD(datos: DatosCorreoFotosHD) {
  const {
    to,
    tutorNombre,
    alumnoNombre,
    colegioNombre,
    cursoCodigo,
    pedidoId,
    kitNombre,
    total,
    linkDescargaHD,
    esImpreso,
    pedidoUuid,
    idempotencyKey,
  } = datos;

  if (!to || !to.includes('@')) {
    return { success: false, error: 'Email de destino inválido' };
  }

  const resend = getResendClient();
  if (!resend) {
    return {
      success: false,
      warning: 'RESEND_API_KEY no está configurada.',
      simulated: true,
      previewLink: linkDescargaHD,
    };
  }

  const fromEmail = process.env.RESEND_FROM_EMAIL || 'Retrato Escolar <fotos@retratoescolar.com.ar>';
  // Escapados porque van directo dentro del HTML del correo (ver escapeHtml arriba) — el
  // asunto del correo (más abajo) usa las variables sin escapar, que ahí no hace falta.
  const nombreDestinatario = escapeHtml(tutorNombre?.trim() || 'Familia');
  const nombreAlumnoStr = escapeHtml(alumnoNombre?.trim() || 'el alumno/a');
  const colegioStr = escapeHtml(colegioNombre?.trim() || 'la institución');
  const kitNombreStr = escapeHtml(kitNombre?.trim() || 'Kit Escolar');
  const pedidoIdStr = escapeHtml(pedidoId?.trim() || 'IFS-2026');
  const cursoCodigoStr = escapeHtml(cursoCodigo?.trim() || '2026');
  // IMPORTANTE: ya no se inventa un link cuando no se pasa uno explícito. Antes se armaba acá
  // mismo una URL con el patrón "/object/public/fotos-hd/..." que apuntaba a un archivo que
  // nunca existe (el bucket es privado y, además, hoy no hay ningún proceso que genere un .zip
  // por pedido) — el botón de descarga se mostraba siempre, aunque no hubiera nada real para
  // descargar. Ahora, sin un link real, el correo se manda igual (con el comprobante) pero sin
  // ese botón, en vez de mandar uno que siempre da error.
  // Pedido de Pablo (28/9): el botón pasa por nuestro servidor para anotar cuándo la familia lo
  // tocó ("⬇ Descargado dd/mm" en el panel); de ahí redirige al .zip. Sin UUID, link directo.
  const enlaceDirecto = linkDescargaHD && linkDescargaHD.trim() ? linkDescargaHD.trim() : null;
  const enlaceHD = enlaceDirecto ? urlDescargaSeguida(pedidoUuid) || enlaceDirecto : null;

  const htmlContent = `
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Tus fotos en Alta Resolución - ${nombreAlumnoStr}</title>
</head>
<body style="margin: 0; padding: 0; background-color: #f8fafc; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; color: #1e293b;">
  <div style="max-width: 600px; margin: 24px auto; background-color: #ffffff; border-radius: 16px; border: 1px solid #e2e8f0; overflow: hidden; box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.05);">
    
    <div style="background-color: #0f172a; padding: 32px 24px; text-align: center; border-bottom: 3px solid #f59e0b;">
      <div style="font-size: 11px; font-weight: 800; letter-spacing: 2px; color: #f59e0b; text-transform: uppercase; margin-bottom: 6px;">
        RETRATO ESCOLAR • EDICIÓN 2026
      </div>
      <h1 style="color: #ffffff; margin: 0; font-size: 22px; font-weight: 800; letter-spacing: -0.5px;">
        ¡Tus Fotografías en Alta Resolución ya están listas!
      </h1>
      <p style="color: #94a3b8; font-size: 13px; margin: 6px 0 0 0;">
        ${colegioStr} • Curso: ${cursoCodigoStr}
      </p>
    </div>

    <div style="padding: 28px 24px;">
      <p style="font-size: 15px; line-height: 1.6; margin-top: 0;">
        Hola <strong>${nombreDestinatario}</strong>,
      </p>
      <p style="font-size: 14px; line-height: 1.6; color: #334155;">
        Confirmamos con éxito el pedido de las fotografías escolares de <strong>${nombreAlumnoStr}</strong>. 
        A continuación tenés acceso directo a tus archivos digitales en calidad original de imprenta (300 DPI, Ultra HD y sin marcas de agua).
      </p>

      ${enlaceHD ? `
      <div style="margin: 28px 0; text-align: center;">
        <a href="${escapeHtml(enlaceHD)}" target="_blank" rel="noopener noreferrer" style="display: inline-block; background-color: #d97706; color: #ffffff; font-size: 15px; font-weight: 700; text-decoration: none; padding: 14px 32px; border-radius: 12px; box-shadow: 0 4px 12px rgba(217, 119, 6, 0.35);">
          ⬇️ Descargar Fotos en Alta Resolución (HD)
        </a>
        <div style="font-size: 11px; color: #64748b; margin-top: 8px;">
          Formato original (.ZIP / JPEG 300 DPI) listo para imprimir o guardar
        </div>
      </div>
      ` : `
      <div style="margin: 24px 0; padding: 14px 16px; background-color: #f8fafc; border: 1px solid #e2e8f0; border-radius: 12px; text-align: center; font-size: 13px; color: #475569;">
        En breve te enviaremos por este mismo medio el enlace para descargar tus fotos en alta resolución.
      </div>
      `}

      <div style="background-color: #f8fafc; border: 1px solid #e2e8f0; border-radius: 12px; padding: 18px; margin: 24px 0;">
        <div style="font-size: 11px; font-weight: 800; text-transform: uppercase; letter-spacing: 1px; color: #64748b; margin-bottom: 12px;">
          Resumen de tu Pedido
        </div>
        <table style="width: 100%; border-collapse: collapse; font-size: 13px;">
          <tr>
            <td style="padding: 6px 0; color: #64748b;">N° de Pedido:</td>
            <td style="padding: 6px 0; font-weight: 700; text-align: right; font-family: monospace; color: #0f172a;">${pedidoIdStr}</td>
          </tr>
          <tr>
            <td style="padding: 6px 0; color: #64748b;">Alumno/a:</td>
            <td style="padding: 6px 0; font-weight: 700; text-align: right; color: #0f172a;">${nombreAlumnoStr}</td>
          </tr>
          <tr>
            <td style="padding: 6px 0; color: #64748b;">Kit Seleccionado:</td>
            <td style="padding: 6px 0; font-weight: 700; text-align: right; color: #0f172a;">${kitNombreStr}</td>
          </tr>
          ${total ? `
          <tr style="border-top: 1px dashed #cbd5e1;">
            <td style="padding: 8px 0 0 0; font-weight: 700; color: #0f172a;">Total Abonado:</td>
            <td style="padding: 8px 0 0 0; font-weight: 800; text-align: right; color: #059669; font-size: 15px;">$${Number(total).toLocaleString('es-AR')} ARS</td>
          </tr>
          ` : ''}
        </table>
      </div>

      ${esImpreso ? `
      <div style="background-color: #fffbeb; border: 1px solid #fde68a; border-radius: 12px; padding: 14px 16px; margin-bottom: 24px;">
        <div style="font-size: 12px; font-weight: 700; color: #92400e; margin-bottom: 4px;">
          📦 Entrega de Material Impreso:
        </div>
        <div style="font-size: 12px; color: #78350f; line-height: 1.5;">
          Tu kit incluye las fotos reveladas en papel fotográfico profesional y carpeta institucional. Serán enviadas directamente al colegio para ser entregadas en mano en el plazo informado.
        </div>
      </div>
      ` : ''}

      <div style="font-size: 12px; color: #64748b; line-height: 1.6; border-top: 1px solid #e2e8f0; padding-top: 16px;">
        <p style="margin: 0 0 8px 0;">
          💡 <strong>Recomendación:</strong> Guardá una copia de las fotos en tu Google Drive o en tu computadora para conservarlas siempre con su máxima calidad.
        </p>
        <p style="margin: 0 0 8px 0;">
          🔗 <strong>¿Se venció el link o lo perdiste?</strong> Entrá a <a href="https://retratoescolar.com.ar" style="color: #d97706;">retratoescolar.com.ar</a> → "Acceder a las Fotos" → "Consultar Mi Pedido" con el número <strong>${pedidoIdStr}</strong> y pedí uno nuevo.
        </p>
        <p style="margin: 0;">
          ¿Dudas con tu pedido? Respondé este email y te ayudamos. Las condiciones de compra y el link para cancelar una compra están al pie de la web.
        </p>
      </div>
    </div>

    <div style="background-color: #f1f5f9; padding: 18px 24px; text-align: center; font-size: 11px; color: #64748b; border-top: 1px solid #e2e8f0;">
      © 2026 Retrato Escolar • Fotografía Escolar Profesional<br>
      <a href="https://retratoescolar.com.ar" style="color: #d97706; text-decoration: none; font-weight: 600;">retratoescolar.com.ar</a>
    </div>
  </div>
</body>
</html>
  `;

  // Auditoría 2026-09-23 (bug real): el SDK de Resend NO tira excepción cuando el envío falla
  // (dominio sin verificar, rate limit, email rechazado): devuelve { data: null, error }. Antes se
  // devolvía success:true igual, así que el pedido quedaba marcado email_enviado=true y el cron de
  // reintento lo salteaba aunque el correo nunca hubiera salido. Además el asunto usaba los textos
  // ya escapados para HTML (un "&" llegaba como "&amp;" en el asunto).
  // La clave de idempotencia sólo se usa si el contenido es estable (link propio /api/descargas/:id
  // o sin link): con un link firmado de Storage (cambia en cada firma) Resend rechazaría el reenvío.
  // 14/10/2026: la clave lleva un resumen del link (antes, con un link firmado no se usaba clave): el mismo
  // correo con el mismo link no sale dos veces (doble clic en «Reintentar»), y uno con link nuevo sí sale.
  const claveIdempotencia = idempotencyKey
    ? `${idempotencyKey}-${enlaceHD ? (enlaceHD !== enlaceDirecto ? 'con-link' : `link-${crypto.createHash('sha256').update(enlaceHD).digest('hex').slice(0, 16)}`) : 'sin-link'}`
    : undefined;
  const data = await resend.emails.send({
    from: fromEmail,
    replyTo: resendReplyTo,
    to: [to],
    subject: `📸 Tus fotos en Alta Resolución - ${alumnoNombre?.trim() || 'el alumno/a'} (${colegioNombre?.trim() || 'la institución'})`,
    html: htmlContent,
  }, claveIdempotencia ? { idempotencyKey: claveIdempotencia } : undefined);
  if (data.error) {
    console.error('[Resend] No se pudo enviar el correo de fotos HD:', data.error);
    return { success: false, error: data.error.message || 'Resend rechazó el envío del correo.' };
  }

  return {
    success: true,
    messageId: data.data?.id,
    from: fromEmail,
    to,
  };
}

/**
 * Auditoría 2026-09-20 (bug real reportado por Pablo: "no le llega el enlace de descarga de
 * fotos HD al cliente"). Causa raíz encontrada: aunque `generarYSubirZipHDParaPedido` y
 * `enviarCorreoFotosHD` se ejecutaban bien en el webhook de pago, el resultado (el link firmado,
 * si el correo salió, y cuándo) NUNCA se guardaba de vuelta en `pedidos` — ni acá, ni en el envío
 * manual desde el botón "Reenviar Email HD" del panel. Eso significa que:
 *   1) el panel de Laboratorio no podía distinguir un pedido al que ya se le mandó el link real
 *      de uno al que sólo se le mandó el texto de "en breve" — ambos se veían iguales;
 *   2) cada vez que alguien recargaba la página, `email_enviado`/`link_descarga_hd` volvían a
 *      leerse vacíos de la base, aunque el correo ya se hubiera mandado bien.
 * Esta función es el único lugar que graba ese resultado, para que la tabla `pedidos` sea la
 * fuente de verdad real (no la memoria del navegador). Sólo marca `email_enviado = true` cuando
 * el envío fue realmente exitoso (nunca en un envío simulado o fallido); el link se guarda igual
 * aunque el correo fallara, para no perder un .zip que sí se llegó a generar. Nunca lanza un
 * error — si falla el guardado, el pago/envío ya ocurrieron y no tiene sentido cortar el flujo
 * por esto (mismo criterio que el resto de las actualizaciones "best effort" en este archivo).
 */
export async function registrarEnvioCorreoHD(
  supabase: SupabaseClient | null,
  pedidoId: string | null | undefined,
  linkDescargaHD: string | null,
  envioExitoso: boolean
): Promise<void> {
  if (!supabase || !pedidoId) return;
  try {
    const cambios: Record<string, any> = {};
    if (linkDescargaHD) cambios.link_descarga_hd = linkDescargaHD;
    if (envioExitoso) {
      cambios.email_enviado = true;
      cambios.fecha_envio_email = new Date().toISOString();
    }
    if (Object.keys(cambios).length === 0) return;
    const { error } = await supabase.from('pedidos').update(cambios).eq('id', pedidoId);
    if (error) console.warn(`[registrarEnvioCorreoHD] No se pudo guardar el resultado del envío HD para ${pedidoId}:`, error.message);
  } catch (err: any) {
    console.warn(`[registrarEnvioCorreoHD] Error inesperado guardando el envío HD para ${pedidoId}:`, err?.message || err);
  }
}

/**
 * Auditoría 2026-09-23: todo lo que hay que hacer cuando uno o más pedidos RECIÉN pasan a
 * "pagado" (armar el .zip HD, mandar el correo, grabar el resultado). Antes esto estaba copiado
 * dentro de cada webhook (Mercado Pago y Nave), y el respaldo de reconciliación de
 * /api/pedidos/:id/status marcaba el pedido como pagado SIN hacer nada de esto — y como el
 * webhook que llegaba después ya encontraba el pedido "pagado" (guard .neq), nunca se mandaba el
 * correo ni se armaba el .zip hasta el cron diario. Ahora los tres caminos usan esta misma
 * función, y como los tres marcan "pagado" con .neq('estado','pagado'), sólo el que gana la
 * carrera recibe las filas y las procesa (sin correos duplicados).
 */
export async function enviarCorreoMejoraImpresoConfirmada(datos: { to: string; tutorNombre: string; alumnoNombre: string; pedidoId: string; total: number; idempotencyKey?: string }): Promise<boolean> {
  const resend = getResendClient();
  if (!resend) return false;
  const { error } = await resend.emails.send({
    from: process.env.RESEND_FROM_EMAIL || 'Retrato Escolar <fotos@retratoescolar.com.ar>',
    replyTo: resendReplyTo,
    to: [datos.to],
    subject: `Retrato Escolar: tu Kit Impreso quedó confirmado (${datos.pedidoId})`,
    html: `<div style="font-family:Arial,sans-serif;max-width:560px;margin:auto;color:#1e293b">
<p>Hola <strong>${escapeHtml(datos.tutorNombre)}</strong>,</p>
<p>Recibimos el pago de <strong>$${datos.total.toLocaleString('es-AR')}</strong> para pasar el kit de <strong>${escapeHtml(datos.alumnoNombre)}</strong> a <strong>Kit Impreso + Digital</strong>.</p>
<p>La carpeta se imprime con las mismas 3 fotos que ya elegiste. Te avisamos por email cuando entre a producción y cuando esté lista para retirar. Las fotos digitales ya las tenés en el email anterior.</p>
<p style="font-size:12px;color:#64748b">Pedido ${escapeHtml(datos.pedidoId)} · Retrato Escolar · retratoescolar.com.ar</p></div>`,
  }, datos.idempotencyKey ? { idempotencyKey: datos.idempotencyKey } : undefined);
  if (error) console.warn('[Resend] No se pudo enviar la confirmación de la mejora a impreso:', error);
  return !error;
}

// 29/10/2026: pago confirmado de un pedido de fotos extra (copias impresas sueltas, sin descarga HD).
export async function enviarCorreoFotosExtraConfirmadas(datos: { to: string; tutorNombre: string; alumnoNombre: string; pedidoId: string; total: number; detalle: string; idempotencyKey?: string }): Promise<boolean> {
  const resend = getResendClient();
  if (!resend) return false;
  const { error } = await resend.emails.send({
    from: process.env.RESEND_FROM_EMAIL || 'Retrato Escolar <fotos@retratoescolar.com.ar>',
    replyTo: resendReplyTo,
    to: [datos.to],
    subject: `Retrato Escolar: tus fotos extra quedaron confirmadas (${datos.pedidoId})`,
    html: `<div style="font-family:Arial,sans-serif;max-width:560px;margin:auto;color:#1e293b">
<p>Hola <strong>${escapeHtml(datos.tutorNombre)}</strong>,</p>
<p>Recibimos el pago de <strong>$${datos.total.toLocaleString('es-AR')}</strong> por las fotos extra de <strong>${escapeHtml(datos.alumnoNombre)}</strong>: ${escapeHtml(datos.detalle)}.</p>
<p>Son copias impresas: se imprimen aparte del kit y se entregan en el colegio. Te avisamos por email cuando entren a producción y cuando estén listas.</p>
<p style="font-size:12px;color:#64748b">Pedido ${escapeHtml(datos.pedidoId)} · Retrato Escolar · retratoescolar.com.ar</p></div>`,
  }, datos.idempotencyKey ? { idempotencyKey: datos.idempotencyKey } : undefined);
  if (error) console.warn('[Resend] No se pudo enviar la confirmación de las fotos extra:', error);
  return !error;
}

// Registro de descargas HD (pedido de Pablo 28/9: "⬇ Descargado dd/mm" en el panel). El botón del
// correo de fotos HD (y el de "Descarga inmediata" del portal) ya no apunta directo al .zip de
// Storage sino a /api/descargas/:id?t=<llave del pedido>. Esa ruta:
//   1) muestra una página chica ("Preparando tu descarga…") que con JavaScript salta a &ir=1. Los
//      antivirus de correo (Outlook, Gmail) abren los links para revisarlos pero no ejecutan
//      JavaScript, así que no cuentan como una descarga de la familia;
//   2) con &ir=1 anota la descarga (primera fecha + contador) y redirige a un link firmado nuevo
//      del .zip (1 hora), así el link del correo no vence nunca.
// Es "tocó el botón de descarga", no garantía de que el archivo se haya bajado entero.
export function urlDescargaSeguida(pedidoUuid: string | null | undefined): string | null {
  if (!pedidoUuid) return null;
  const llave = tokenAccesoPedido(String(pedidoUuid));
  if (!llave) return null;
  const appUrl = (process.env.APP_URL || 'https://www.retratoescolar.com.ar').replace(/\/+$/, '');
  return `${appUrl}/api/descargas/${encodeURIComponent(String(pedidoUuid))}?t=${encodeURIComponent(llave)}`;
}

export async function enviarCorreoReservaConfirmada(datos: {
  to: string;
  tutorNombre: string;
  alumnoNombre: string;
  colegioNombre: string;
  kitNombre: string;
  pedidoId: string;
  total: number;
  idempotencyKey?: string;
}): Promise<{ success: boolean; error?: string }> {
  if (!datos.to || !datos.to.includes('@')) return { success: false, error: 'Email de destino inválido' };
  const resend = getResendClient();
  if (!resend) return { success: false, error: 'RESEND_API_KEY no está configurada.' };
  const resultado = await resend.emails.send({
    from: process.env.RESEND_FROM_EMAIL || 'Retrato Escolar <fotos@retratoescolar.com.ar>',
    replyTo: resendReplyTo,
    to: [datos.to],
    subject: `Retrato Escolar: ¡Reserva confirmada! ${datos.kitNombre} de ${datos.alumnoNombre} (${datos.pedidoId})`,
    html: `<div style="font-family:Arial,sans-serif;max-width:640px;margin:auto;color:#0f172a;line-height:1.6">
<h2 style="margin-bottom:4px">¡Reserva confirmada! 🎉</h2>
<p>Hola ${escapeHtml(datos.tutorNombre)},</p>
<p>Recibimos tu pago del <strong>${escapeHtml(datos.kitNombre)}</strong> para <strong>${escapeHtml(datos.alumnoNombre)}</strong> (${escapeHtml(datos.colegioNombre)}). Tu kit ya está reservado y pagado.</p>
<div style="padding:14px 16px;background:#f8fafc;border:1px solid #e2e8f0;border-radius:12px;margin:16px 0">
<p style="margin:0"><strong>Pedido:</strong> ${escapeHtml(datos.pedidoId)}<br><strong>Total abonado:</strong> $${Number(datos.total || 0).toLocaleString('es-AR')}</p>
</div>
<p><strong>¿Qué sigue?</strong> Cuando estén las fotos de su curso en la web, entrá a <a href="https://www.retratoescolar.com.ar">retratoescolar.com.ar</a> → "Acceder a las Fotos" con tu código de acceso, elegí las 3 fotos del kit y confirmalas. <strong>No vas a tener que volver a pagar.</strong> Apenas las confirmes te llega la descarga en alta resolución.</p>
<p style="font-size:13px;color:#475569">Guardá tu número de pedido <strong>${escapeHtml(datos.pedidoId)}</strong>: te sirve para consultar el estado desde "Acceder a las Fotos" → "Consultar Mi Pedido". ¿Dudas? Respondé este email. Las condiciones de compra y el link para cancelar una compra están al pie de la web.</p>
<p style="margin-top:24px">Saludos,<br><strong>Retrato Escolar</strong></p>
</div>`,
  }, datos.idempotencyKey ? { idempotencyKey: datos.idempotencyKey } : undefined);
  if (resultado.error) {
    console.error('[Reservas] No se pudo enviar el email de reserva confirmada:', resultado.error);
    return { success: false, error: resultado.error.message };
  }
  return { success: true };
}
