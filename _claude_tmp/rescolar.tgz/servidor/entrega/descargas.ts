// Descarga del .zip HD (/api/descargas/:id) y refirmado del link cuando venció (división de server.ts,
// etapa 6, 10/10/2026). El código es el mismo que estaba en la sección 5 de server.ts: sólo se movió.
import type { SupabaseClient } from '@supabase/supabase-js';
import express from 'express';
import type { Request, Response } from 'express';
import { pedidoHabilitaDescarga, tokenAccesoValido } from '../nucleo/accesoPedidos.js';
import { getServerSupabase } from '../nucleo/clientes.js';
import { esPedidoAdicional } from '../nucleo/fotosExtra.js';
import { limitarFrecuencia } from '../nucleo/limites.js';
import { escapeHtml } from '../nucleo/utilidades.js';
import { armarZipHDConTurno, nombreZipHDPedido } from './zipHD.js';

const rutas = express.Router();

const USER_AGENT_ROBOT = /bot|crawl|spider|preview|scanner|safelinks|proofpoint|mimecast|barracuda|headless|curl|wget|python|java\/|go-http|okhttp|facebookexternalhit|whatsapp|slack|telegram|discord/i;

function paginaDescarga(titulo: string, cuerpo: string, extraHead = ''): string {
  return `<!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><meta name="robots" content="noindex"><title>${escapeHtml(titulo)} · Retrato Escolar</title>${extraHead}</head><body style="margin:0;background:#f8fafc;font-family:Arial,sans-serif;color:#1e293b"><div style="max-width:440px;margin:60px auto;background:#fff;border:1px solid #e2e8f0;border-radius:16px;padding:28px 24px;text-align:center"><div style="color:#d97706;font-size:11px;font-weight:800;letter-spacing:2px">RETRATO ESCOLAR</div><h1 style="font-size:20px;margin:10px 0 12px">${escapeHtml(titulo)}</h1>${cuerpo}</div></body></html>`;
}

rutas.get('/api/descargas/:id', limitarFrecuencia('descargas-hd', 300, 10 * 60 * 1000), async (req: Request, res: Response) => {
  res.setHeader('Cache-Control', 'no-store');
  res.setHeader('X-Robots-Tag', 'noindex');
  const id = String(req.params.id || '');
  const llave = String(req.query.t || '');
  const noDisponible = (texto: string, status = 404) =>
    res.status(status).type('html').send(paginaDescarga('Descarga no disponible', `<p style="font-size:14px;line-height:1.6">${escapeHtml(texto)}</p><p style="font-size:13px"><a href="https://www.retratoescolar.com.ar" style="color:#d97706">Ir a retratoescolar.com.ar</a></p>`));
  if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(id) || !tokenAccesoValido(llave, [id])) {
    return noDisponible('El link de descarga no es válido. Usá el botón del email que te mandamos o pedí el link de nuevo desde "Seguimiento de pedido" en la web.', 403);
  }
  const supabase = getServerSupabase();
  if (!supabase) return noDisponible('El servicio no está disponible en este momento. Probá de nuevo en unos minutos.', 503);
  try {
    const { data: pedido } = await supabase
      .from('pedidos')
      .select('id, estado, seleccion_pendiente, pedido_friendly_id, link_descarga_hd, descargas_hd, mejora_de_pedido_id, extras_de_pedido_id, tipo_kit')
      .eq('id', id)
      .maybeSingle();
    if (!pedido || !pedidoHabilitaDescarga(pedido.estado) || pedido.seleccion_pendiente || esPedidoAdicional(pedido)) {
      return noDisponible('Este pedido todavía no tiene fotos para descargar. Si ya pagaste y elegiste tus fotos, escribinos respondiendo el email.');
    }
    if (req.query.ir !== '1') {
      const destino = `/api/descargas/${encodeURIComponent(id)}?t=${encodeURIComponent(llave)}&ir=1`;
      return res.type('html').send(
        paginaDescarga(
          'Preparando tu descarga…',
          `<p style="font-size:14px;line-height:1.6">Tus fotos en alta resolución (${escapeHtml(pedido.pedido_friendly_id || '')}) empiezan a bajarse en un momento.</p><p style="margin:22px 0"><a id="descargar" href="${escapeHtml(destino)}" style="display:inline-block;background:#d97706;color:#fff;font-weight:700;text-decoration:none;padding:12px 24px;border-radius:12px">⬇️ Descargar fotos HD</a></p><p style="font-size:12px;color:#64748b">Si no arranca sola, tocá el botón. Es un archivo .ZIP: en el celular se guarda en Descargas.</p><script>setTimeout(function(){location.replace(document.getElementById('descargar').getAttribute('href'))},400)</script>`
        )
      );
    }
    const agente = String(req.get('user-agent') || '');
    if (!USER_AGENT_ROBOT.test(agente)) {
      const ahora = new Date().toISOString();
      // La primera fecha no se pisa; el contador suma cada vez que la tocan.
      await supabase.from('pedidos').update({ descarga_hd_at: ahora }).eq('id', id).is('descarga_hd_at', null);
      await supabase.from('pedidos').update({ descargas_hd: (Number(pedido.descargas_hd) || 0) + 1, descarga_hd_ultima_at: ahora }).eq('id', id);
    }
    const nombreDescarga = `RetratoEscolar_${String(pedido.pedido_friendly_id || id.slice(0, 8)).replace(/[^\w-]/g, '_')}.zip`;
    const { data: firmado } = await supabase.storage.from('fotos-hd').createSignedUrl(nombreZipHDPedido({ id }), 60 * 60, { download: nombreDescarga });
    let destino = firmado?.signedUrl || null;
    if (!destino) {
      // .zip con nombre viejo (antes del 23/9) o que no existe: se arma de nuevo.
      // 25/10 (auditoría): antes se usaba el link guardado «como último recurso»; si el .zip lo había borrado la
      // limpieza (pedido cancelado y después reactivado) la familia caía en un error de Storage para siempre.
      const { data: completo } = await supabase.from('pedidos').select('*').eq('id', id).maybeSingle();
      const nombreViejo = completo?.pedido_friendly_id ? `zips-pedidos/${completo.pedido_friendly_id}.zip` : null;
      const { data: viejo } = nombreViejo ? await supabase.storage.from('fotos-hd').createSignedUrl(nombreViejo, 60 * 60, { download: nombreDescarga }) : { data: null };
      // Con turno: varios clics (o un escáner de mails) no arman el mismo .zip a la vez; el que no tiene turno ve «probá en unos minutos».
      destino = viejo?.signedUrl || (completo ? await armarZipHDConTurno(supabase, completo) : null) || null;
    }
    if (!destino) return noDisponible('Estamos terminando de preparar tus fotos. Probá de nuevo en unos minutos; si sigue sin funcionar, respondé el email y te ayudamos.', 503);
    return res.redirect(302, destino);
  } catch (err: any) {
    console.error('[descargas-hd] Error:', err?.message || err);
    return noDisponible('No pudimos abrir la descarga. Probá de nuevo en unos minutos.', 500);
  }
});

// Auditoría 2026-09-19 (bug real encontrado en auditoría de código, MEDIO): el link de descarga
// HD se firma por 90 días al generar el .zip (ver arriba) y ese mismo valor quedaba guardado en
// "pedidos.link_descarga_hd" para siempre — pasados los 90 días, el link roto seguía
// devolviéndose tal cual en /api/pedidos/:id/status y /api/pedidos/buscar, y la única forma de
// arreglarlo era que el admin usara a mano "Reenviar Email HD" desde el panel. El nombre del
// archivo .zip en Storage es determinístico (no cambia), así que acá se puede volver a firmar
// una URL fresca de 90 días sobre el MISMO .zip ya generado, sin tener que rearmarlo — barato
// (una sola llamada a Storage) y transparente para la familia. Si el objeto ya no existiera en
// Storage por algún motivo, se devuelve tal cual el link guardado como último recurso.
export async function refirmarLinkDescargaHDSiExiste(supabase: SupabaseClient, pedido: { id: string; pedido_friendly_id?: string | null; link_descarga_hd?: string | null }): Promise<string | undefined> {
  if (!pedido?.link_descarga_hd) return undefined;
  // Auditoría 2026-09-26 (B1): antes se firmaba un link nuevo (y se escribía la fila) en CADA
  // consulta de estado. Ahora sólo si al link guardado le quedan menos de 30 días.
  try {
    const token = new URL(pedido.link_descarga_hd).searchParams.get('token') || '';
    const payload = JSON.parse(Buffer.from(token.split('.')[1] || '', 'base64url').toString('utf8'));
    if (Number(payload?.exp) * 1000 - Date.now() > 30 * 24 * 60 * 60 * 1000) return pedido.link_descarga_hd;
  } catch {
    /* link con formato inesperado: se refirma */
  }
  try {
    // Primero el nombre nuevo (por UUID, ver nombreZipHDPedido). Los .zip generados antes del
    // 23/9/2026 quedaron con el nombre viejo (número amigable) — se usa sólo como respaldo, y
    // sólo si el link guardado apunta justamente a ese archivo viejo.
    let { data: firmado, error } = await supabase.storage
      .from('fotos-hd')
      .createSignedUrl(nombreZipHDPedido(pedido), 60 * 60 * 24 * 90);
    const nombreViejo = pedido.pedido_friendly_id ? `zips-pedidos/${pedido.pedido_friendly_id}.zip` : null;
    if ((error || !firmado?.signedUrl) && nombreViejo && pedido.link_descarga_hd.includes(encodeURI(nombreViejo))) {
      ({ data: firmado, error } = await supabase.storage
        .from('fotos-hd')
        .createSignedUrl(nombreViejo, 60 * 60 * 24 * 90));
    }
    if (error || !firmado?.signedUrl) {
      return pedido.link_descarga_hd;
    }
    if (firmado.signedUrl !== pedido.link_descarga_hd) {
      await supabase.from('pedidos').update({ link_descarga_hd: firmado.signedUrl }).eq('id', pedido.id);
    }
    return firmado.signedUrl;
  } catch (err: any) {
    console.warn(`[ZIP HD] No se pudo refirmar el link de descarga para el pedido ${pedido?.id}:`, err?.message || err);
    return pedido.link_descarga_hd;
  }
}

export { rutas as rutasDescargas };
