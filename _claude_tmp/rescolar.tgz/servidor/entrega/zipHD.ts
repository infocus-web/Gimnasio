// Armado y subida del .zip HD de un pedido pagado (con el aviso a Pablo cuando no se puede armar
// solo) (división de server.ts, etapa 3, 10/10/2026). El código es el mismo que estaba en la
// sección 5 de server.ts: sólo se movió de lugar.
import type { SupabaseClient } from '@supabase/supabase-js';
import JSZip from 'jszip';
import { casillaAvisosAdmin, getResendClient } from '../nucleo/clientes.js';
import { hayCupoGlobal, tocaTurnoDistribuido } from '../nucleo/limites.js';
import { categoriaValeEnLugar, lugaresSinFoto, nombreArchivoLugar } from '../nucleo/fotosFaltantes.js';
import { enLotes, escapeHtml, mapConLimite } from '../nucleo/utilidades.js';

export function nombreZipHDPedido(pedido: { id: string }): string {
  return `zips-pedidos/${pedido.id}.zip`;
}

/** Arma el .zip HD tomando antes el turno del pedido (un solo proceso a la vez arma el mismo .zip). */
export async function armarZipHDConTurno(supabase: SupabaseClient, pedido: any, opciones: { maxFotos?: number } = {}): Promise<string | null> {
  if (!pedido?.id) return null;
  if (!(await tocaTurnoDistribuido(`zip-hd:${pedido.id}`, 120))) {
    console.log(`[ZIP HD] Otro proceso ya está armando el .zip del pedido ${pedido.id}; se saltea.`);
    return null;
  }
  return generarYSubirZipHDParaPedido(supabase, pedido, opciones);
}

// Límite del bucket fotos-hd (file_size_limit = 100 MB). Un .zip más grande nunca sube y el pedido
// quedaba reintentándose para siempre sin que nadie se enterara.
const TAMANO_MAX_ZIP_HD = 100 * 1024 * 1024;

// Auditoría 05/10 (alto): aviso a Pablo cuando un .zip HD no se va a poder armar solo (foto elegida
// que ya no existe, .zip más grande que el límite del bucket). Antes el pedido quedaba en el reintento
// horario silencioso o —peor— salía un .zip incompleto. Un aviso por pedido y motivo cada 24 h.
async function avisarAdminEntregaHD(pedido: any, motivo: string, detalle: string) {
  try {
    const resend = getResendClient();
    if (!resend) return;
    if (!(await tocaTurnoDistribuido(`alerta-hd:${pedido?.id}:${motivo}`, 24 * 3600))) return;
    if (!(await hayCupoGlobal('alerta-hd', 30, 3600))) return;
    const fromEmail = process.env.RESEND_FROM_EMAIL || 'Retrato Escolar <fotos@retratoescolar.com.ar>';
    const { error } = await resend.emails.send({
      from: fromEmail,
      to: [casillaAvisosAdmin()],
      subject: `Entrega HD trabada: pedido ${pedido?.pedido_friendly_id || pedido?.id || ''}`,
      html: `<div style="font-family:Arial,sans-serif">
<p>El .zip HD del pedido <strong>${escapeHtml(String(pedido?.pedido_friendly_id || pedido?.id || ''))}</strong> (${escapeHtml(String(pedido?.alumno_nombre || 'alumno'))}, ${escapeHtml(String(pedido?.colegio_nombre || ''))} ${escapeHtml(String(pedido?.curso_codigo || ''))}) no se pudo armar solo.</p>
<p><strong>Motivo:</strong> ${escapeHtml(detalle)}</p>
<p>La familia no recibe el link hasta que lo resuelvas desde el panel → Laboratorio (Reintentar / Reenviar Email HD).</p></div>`,
    });
    if (error) console.warn('[Resend] Aviso de entrega HD trabada rechazado:', error);
  } catch (err: any) {
    console.warn('[ZIP HD] No se pudo avisar al admin:', err?.message || err);
  }
}

export async function generarYSubirZipHDParaPedido(supabase: SupabaseClient, pedido: any, opciones: { maxFotos?: number } = {}): Promise<string | null> {
  try {
    if (!pedido?.colegio_id || !pedido?.curso_codigo) return null;
    // Pago anticipado: todavía no hay fotos elegidas, el .zip se arma cuando la familia las elija.
    if (pedido?.seleccion_pendiente) return null;

    const seleccion = (pedido.fotos_seleccionadas && typeof pedido.fotos_seleccionadas === 'object')
      ? pedido.fotos_seleccionadas
      : {};
    const otrasIds: string[] = Array.isArray(seleccion.otrasIds) ? seleccion.otrasIds : [];
    const idsEsperados = [seleccion.individualId, seleccion.grupalId, seleccion.docenteId, ...otrasIds]
      .filter((id: unknown): id is string => typeof id === 'string' && id.length > 0);
    if (idsEsperados.length === 0) return null;

    // Auditoría 11/10: sólo las fotos del pedido (antes todo el curso de una vez: pasado el tope de 1000
    // filas de PostgREST una foto elegida «no existía»). Un curso sin ninguna foto cae en el aviso de abajo.
    const fotosCurso: any[] = [];
    for (const lote of enLotes([...new Set(idsEsperados)], 100)) {
      const { data, error: errorFotos } = await supabase
        .from('fotos')
        .select('id, categoria, storage_path, bytes_original')
        .eq('colegio_id', pedido.colegio_id)
        .eq('codigo_curso', pedido.curso_codigo)
        .in('id', lote);
      if (errorFotos) throw errorFotos;
      fotosCurso.push(...(data || []));
    }

    const buscarFoto = (id: string | undefined, categoria: string) =>
      id ? fotosCurso.find((f: any) => f.id === id && f.categoria === categoria) : undefined;

    const elegidas: { nombre: string; foto: any }[] = [];
    // 06/10: la 3ª foto puede ser con la seño o con familia/amigos. 22/10: un lugar marcado «no tiene esta
    // foto» (sinFoto) puede venir vacío o con otra foto del curso, que va con nombre «En_lugar_de_…».
    const sinFoto = lugaresSinFoto(seleccion);
    for (const lugar of ['individual', 'grupal', 'docente'] as const) {
      const id = seleccion[`${lugar}Id`];
      const foto = id ? fotosCurso.find((f: any) => f.id === id && categoriaValeEnLugar(f.categoria, lugar, sinFoto)) : undefined;
      if (foto) elegidas.push({ nombre: nombreArchivoLugar(lugar, foto.categoria, !categoriaValeEnLugar(foto.categoria, lugar, [])), foto });
    }
    otrasIds.forEach((id: string, indice: number) => {
      const foto = buscarFoto(id, 'patio');
      if (foto) elegidas.push({ nombre: `Otra_${indice + 1}.jpg`, foto });
    });

    // Auditoría 05/10 (alto): si una foto elegida ya no está en el curso (la borraron o la movieron
    // después de la selección) antes se armaba igual el .zip SIN esa foto y la familia recibía una
    // entrega incompleta como si estuviera bien. Ahora no se entrega nada y se avisa a Pablo.
    const idsEncontrados = new Set(elegidas.map((e) => String(e.foto.id)));
    const sinArchivo = elegidas.filter((e) => !e.foto.storage_path).length;
    const idsPerdidos = idsEsperados.filter((id) => !idsEncontrados.has(id));
    if (idsEsperados.length > 0 && (idsPerdidos.length > 0 || sinArchivo > 0)) {
      console.error(`[ZIP HD] Pedido ${pedido.id}: ${idsPerdidos.length} foto(s) elegidas ya no existen en el curso y ${sinArchivo} sin original; no se arma un .zip incompleto.`);
      await avisarAdminEntregaHD(pedido, 'fotos-faltantes', `${idsPerdidos.length} foto(s) elegidas por la familia ya no existen en el curso (¿se borraron o se movieron?) y ${sinArchivo} no tienen el original en Storage. Hay que recargar las fotos o pedirle a la familia que vuelva a elegir.`);
      return null;
    }

    if (elegidas.length === 0) return null;
    if (opciones.maxFotos && elegidas.length > opciones.maxFotos) {
      console.log(`[ZIP HD] El pedido ${pedido.id} tiene ${elegidas.length} fotos: el .zip lo arma el cron de reintento.`);
      return null;
    }

    // 25/10 (auditoría): si por el peso de los originales ya se sabe que el .zip pasa el límite, se avisa ANTES de
    // bajar nada (antes se bajaba todo a memoria en cada reintento horario y recién ahí se comparaba).
    const pesoConocido = elegidas.reduce((total, e) => total + (Number(e.foto.bytes_original) || 0), 0);
    if (pesoConocido > TAMANO_MAX_ZIP_HD) {
      console.error(`[ZIP HD] Pedido ${pedido.id}: los originales suman ${(pesoConocido / 1048576).toFixed(0)} MB, más que el límite del bucket.`);
      await avisarAdminEntregaHD(pedido, 'zip-grande', `Las ${elegidas.length} fotos suman ${(pesoConocido / 1048576).toFixed(0)} MB y el bucket fotos-hd admite hasta 100 MB por archivo. Hay que subir el límite del bucket o entregar las fotos de otra forma.`);
      return null;
    }

    // Preparación temporada (25/9): las fotos se descargan en paralelo (antes de a una) y el .zip
    // se arma sin comprimir — los JPG ya vienen comprimidos, recomprimirlos no achica nada y
    // gastaba CPU y segundos de la función en cada pago.
    // Auditoría 03/10 (crítico 4): de a 4 descargas a la vez como mucho (antes todas juntas).
    const zip = new JSZip();
    const descargas = await mapConLimite(
      elegidas.filter((item) => item.foto.storage_path), 4, async (item) => {
        const { data: archivo, error: errorDescarga } = await supabase.storage
          .from('fotos-hd')
          .download(item.foto.storage_path);
        if (errorDescarga || !archivo) {
          console.warn(`[ZIP HD] No se pudo descargar ${item.nombre} (pedido ${pedido.id}):`, errorDescarga?.message);
          return null;
        }
        return { nombre: item.nombre, contenido: Buffer.from(await archivo.arrayBuffer()) };
      }
    );
    const faltantes = elegidas.filter((item) => item.foto.storage_path).length - descargas.filter(Boolean).length;
    // Si falta alguna foto (error pasajero de Storage) no se entrega un .zip incompleto: se devuelve
    // null y el reintento horario lo vuelve a armar completo.
    if (faltantes > 0 || descargas.length === 0) return null;
    for (const d of descargas) if (d) zip.file(d.nombre, d.contenido);

    const zipBuffer = await zip.generateAsync({ type: 'nodebuffer', compression: 'STORE' });
    // Auditoría 05/10 (medio): el bucket rechaza archivos de más de 100 MB; antes la subida fallaba
    // en silencio en cada reintento horario, para siempre. Ahora se avisa a Pablo.
    if (zipBuffer.length > TAMANO_MAX_ZIP_HD) {
      console.error(`[ZIP HD] Pedido ${pedido.id}: el .zip pesa ${(zipBuffer.length / 1048576).toFixed(0)} MB, más que el límite del bucket.`);
      await avisarAdminEntregaHD(pedido, 'zip-grande', `El .zip pesa ${(zipBuffer.length / 1048576).toFixed(0)} MB y el bucket fotos-hd admite hasta 100 MB (${elegidas.length} fotos). Hay que subir el límite del bucket o entregar las fotos de otra forma.`);
      return null;
    }
    // Auditoría 2026-09-23 (bug CRÍTICO de privacidad): antes el .zip se nombraba con el número
    // amigable del pedido (IFS-2026-XXXX, 4 dígitos al azar generados en el navegador) y se subía
    // con upsert:true. Con ~9.000 combinaciones posibles, dos pedidos distintos terminan tarde o
    // temprano con el mismo número (con ~110 pedidos ya hay 50% de chance) — y el .zip del
    // segundo PISABA el del primero: la familia A pasaba a descargar las fotos del hijo de la
    // familia B con su propio link. Ahora el archivo se nombra siempre con el UUID del pedido,
    // que es único por definición.
    const nombreZip = nombreZipHDPedido(pedido);
    const { error: errorSubida } = await supabase.storage
      .from('fotos-hd')
      .upload(nombreZip, zipBuffer, { contentType: 'application/zip', upsert: true });
    if (errorSubida) throw errorSubida;

    // 90 días: de sobra para que la familia lo baje; si llega a vencer, "Reenviar Email HD"
    // desde el panel vuelve a generar el .zip y firma un link nuevo.
    const { data: firmado, error: errorFirma } = await supabase.storage
      .from('fotos-hd')
      .createSignedUrl(nombreZip, 60 * 60 * 24 * 90);
    if (errorFirma || !firmado?.signedUrl) throw errorFirma || new Error('No se pudo firmar el link de descarga');

    await supabase.from('pedidos').update({ link_descarga_hd: firmado.signedUrl }).eq('id', pedido.id);
    return firmado.signedUrl;
  } catch (err: any) {
    console.error(`[ZIP HD] Falló la generación automática para el pedido ${pedido?.id}:`, err?.message || err);
    return null;
  }
}
