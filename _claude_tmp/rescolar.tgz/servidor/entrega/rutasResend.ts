// Rutas de Resend del panel: estado del servicio, envío directo del link HD, armar el .zip HD de un
// pedido a mano y email de prueba (división de server.ts, etapa 5, 10/10/2026). El código es el mismo
// que estaba en la sección "6. RUTAS RESEND" de server.ts: sólo se movió de lugar.
import crypto from 'crypto';
import express from 'express';
import type { Request, Response } from 'express';
import { pedidoHabilitaDescarga } from '../nucleo/accesoPedidos.js';
import { requireAdminAuth } from '../nucleo/auth.js';
import { getResendClient, getServerSupabase, resendReplyTo } from '../nucleo/clientes.js';
import { esPedidoAdicional, esPedidoFotosExtra } from '../nucleo/fotosExtra.js';
import { escapeHtml } from '../nucleo/utilidades.js';
import { enviarCorreoFotosHD, registrarEnvioCorreoHD } from './correos.js';
import { generarYSubirZipHDParaPedido } from './zipHD.js';

const rutas = express.Router();

// ==============================================================================
// 6. RUTAS RESEND (ESTADO, ENVÍO DIRECTO Y TEST)
// ==============================================================================

// Auditoría 2026-09-09 (revisión a fondo): esta ruta no pedía sesión y devolvía un fragmento
// real de la RESEND_API_KEY (primeros 6 + últimos 4 caracteres) a cualquier visitante. Enmascarado
// o no, no hay ningún motivo para exponer parte de una clave de servidor a todo internet — pasa
// a exigir sesión de administrador, igual que el resto de los diagnósticos del panel.
rutas.get(['/api/resend/status', '/resend/status'], requireAdminAuth, (req, res) => {
  const apiKey = process.env.RESEND_API_KEY;
  const isConfigured = Boolean(apiKey && apiKey.trim().length > 0);
  const fromEmail = process.env.RESEND_FROM_EMAIL || 'Retrato Escolar <fotos@retratoescolar.com.ar>';

  res.json({
    configured: isConfigured,
    fromEmail,
    maskedKey: isConfigured ? `${apiKey!.substring(0, 6)}...${apiKey!.slice(-4)}` : null,
    domain: 'retratoescolar.com.ar',
  });
});

// SEGURIDAD: antes esta ruta no pedía ningún tipo de sesión — cualquiera podía hacer que el
// dominio verificado de Resend mandara un correo con el texto y el link que quisiera a
// cualquier casilla. Ahora exige la misma sesión de administrador que el resto del panel.
rutas.post(['/api/enviar-fotos-hd', '/enviar-fotos-hd'], requireAdminAuth, async (req, res) => {
  try {
    // Auditoría 2026-09-20: "pedidoId" en el body es el ID legible (IFS-2026-XXXX), sólo para
    // mostrar en el correo — no sirve para encontrar la fila en Supabase. Se agrega
    // "pedidoSupabaseId" (el UUID real) aparte, igual que ya se hace en /notificar-estado, para
    // poder grabar el resultado del envío (ver registrarEnvioCorreoHD) cuando el fotógrafo
    // reenvía el correo a mano desde el botón del panel de Laboratorio.
    // 14/10/2026 (auditoría, «Reintentar los N» HD): `forzar` = reenvío manual a propósito (sale aunque ya se
    // haya mandado el link); `soloConLink` = reintento masivo: sin link HD no se manda el aviso «en breve».
    const { pedidoSupabaseId, forzar, soloConLink, ...datosCorreo } = req.body || {};
    const supabase = getServerSupabase();
    // Caso real 27/9: al aprobar a mano una reserva (kit pagado por adelantado, fotos todavía sin
    // elegir) el panel mandaba además este correo de "Tus fotos HD ya están listas". Una reserva
    // recibe su propio correo de confirmación, y una mejora a Kit Impreso no lleva fotos nuevas.
    if (supabase && typeof pedidoSupabaseId === 'string' && pedidoSupabaseId) {
      const { data: fila } = await supabase
        .from('pedidos')
        .select('seleccion_pendiente, mejora_de_pedido_id, extras_de_pedido_id, tipo_kit, email_enviado, link_descarga_hd')
        .eq('id', pedidoSupabaseId)
        .maybeSingle();
      if (fila?.email_enviado && fila?.link_descarga_hd && forzar !== true) {
        return res.json({ success: true, omitido: true, yaEnviado: true, motivo: 'A esta familia ya le llegó el link HD (no se repitió el correo).' });
      }
      if (fila?.seleccion_pendiente || esPedidoAdicional(fila)) {
        return res.json({
          success: true,
          omitido: true,
          motivo: fila.seleccion_pendiente
            ? 'Es un kit pagado por adelantado: las fotos HD salen cuando la familia las elija.'
            : esPedidoFotosExtra(fila)
              ? 'Es un pedido de fotos extra (copias impresas): no lleva descarga HD.'
              : 'Es una mejora a Kit Impreso: las fotos digitales ya se enviaron con el pedido original.',
        });
      }
    }
    if (soloConLink === true && !String(datosCorreo?.linkDescargaHD || '').trim()) {
      return res.status(409).json({ success: false, sinLink: true, error: 'Todavía no hay .zip HD para este pedido: no se mandó el aviso «en breve».' });
    }
    const uuid = typeof pedidoSupabaseId === 'string' && pedidoSupabaseId ? pedidoSupabaseId : undefined;
    const resultado = await enviarCorreoFotosHD({
      ...datosCorreo,
      pedidoUuid: uuid,
      // Doble clic = misma clave (Resend no lo manda dos veces); el reenvío forzado lleva tramo de 2 minutos.
      // 14/10/2026: prefijo propio del panel + resumen del link: la clave del webhook/cron (`fotos-hd-<uuid>-con-link`)
      // podía coincidir con otro contenido (otro link) y Resend rechazaba el envío del panel.
      idempotencyKey: uuid ? `fotos-hd-panel-${uuid}-${crypto.createHash('sha256').update(String(datosCorreo?.linkDescargaHD || '')).digest('hex').slice(0, 16)}${forzar === true ? `-r${Math.floor(Date.now() / 120_000)}` : ''}` : undefined,
    });
    await registrarEnvioCorreoHD(supabase, pedidoSupabaseId, datosCorreo?.linkDescargaHD || null, resultado?.success === true);
    if (!resultado.success && resultado.error) {
      return res.status(400).json(resultado);
    }
    return res.json(resultado);
  } catch (error: any) {
    console.error('[Resend] Error al enviar email:', error);
    return res.status(500).json({
      success: false,
      error: error?.message || 'Error inesperado al enviar el correo mediante Resend',
    });
  }
});

// Auditoría 2026-09-18 (pedido de Pablo: automatizar el .zip de descarga HD): reintento manual
// desde el panel de Laboratorio para cuando la generación automática (en los webhooks de pago)
// falló — por ejemplo, si en ese momento todavía no se habían cargado las fotos del curso. El
// botón "Reenviar Email HD" llama primero a esta ruta y, si consigue un link, lo usa; si no,
// sigue mandando el correo con lo que ya hubiera guardado (o el texto de "en breve").
rutas.post('/api/admin/pedidos/:id/generar-zip-hd', requireAdminAuth, async (req: Request, res: Response) => {
  try {
    const supabase = getServerSupabase();
    if (!supabase) return res.status(500).json({ success: false, error: 'Supabase no configurado en el servidor' });

    const { data: pedido, error } = await supabase
      .from('pedidos')
      .select('*')
      .eq('id', req.params.id)
      .maybeSingle();
    if (error) throw error;
    if (!pedido) return res.status(404).json({ success: false, error: 'Pedido no encontrado' });
    // Auditoría 2026-09-26 (A4): el .zip HD (y su link) sólo se arma para pedidos cobrados.
    if (!pedidoHabilitaDescarga(pedido.estado)) {
      return res.status(409).json({ success: false, error: 'Este pedido no está pagado: aprobá el pago antes de generar la descarga HD.' });
    }
    // Auditoría 05/10: una mejora a Kit Impreso no lleva .zip propio (el HD es el del pedido original).
    if (esPedidoFotosExtra(pedido)) {
      return res.status(409).json({ success: false, error: 'Es un pedido de fotos extra (copias impresas): no lleva descarga HD.' });
    }
    if (pedido.mejora_de_pedido_id) {
      return res.status(409).json({ success: false, error: 'Este pedido es una mejora a Kit Impreso: la descarga HD es la del pedido original (Solo Digital), no hace falta generar otro .zip.' });
    }

    const link = await generarYSubirZipHDParaPedido(supabase, pedido);
    if (!link) {
      // Auditoría 2026-09-21 (refuerzo): antes este error era el mismo mensaje genérico para
      // TODAS las causas posibles de falla — incluída la vez que curso_codigo no matcheaba
      // ninguna fila de fotos (el bug real que rompió la entrega de HD, ver auditoría en
      // PortalFamiliasModal.tsx). Este diagnóstico rápido distingue "no hay fotos cargadas para
      // ese curso" (lo más común y lo que hay que arreglar cargando fotos) de "hay fotos pero
      // falló armar/subir el .zip" (más probable un problema pasajero de Storage), para que el
      // mensaje del panel apunte a la causa real en vez de mandar a revisar algo que ya está bien.
      const { count: fotosDelCurso } = await supabase
        .from('fotos')
        .select('id', { count: 'exact', head: true })
        .eq('colegio_id', pedido.colegio_id)
        .eq('codigo_curso', pedido.curso_codigo);
      if (!fotosDelCurso) {
        return res.status(422).json({
          success: false,
          error: `No hay fotos cargadas para el curso "${pedido.curso_codigo || '(sin código)'}" de este pedido. Cargá las fotos de ese curso desde el panel de Fotos y volvé a intentar.`,
        });
      }
      return res.status(422).json({
        success: false,
        error: 'Hay fotos cargadas para ese curso, pero no se pudo armar o subir el .zip (probable problema pasajero de Storage — mirá los logs del servidor). Volvé a intentar en unos minutos.',
      });
    }
    return res.json({ success: true, linkDescargaHD: link });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err?.message || 'Error al generar el .zip HD' });
  }
});

// SEGURIDAD: es una herramienta de diagnóstico para el fotógrafo (probar que el dominio de
// Resend funciona), no algo que deba poder disparar cualquier visitante sin sesión.
rutas.post(['/api/resend/test', '/resend/test'], requireAdminAuth, async (req, res) => {
  try {
    const to = typeof req.body?.to === 'string' ? req.body.to.trim() : '';
    if (!to || !to.includes('@')) {
      return res.status(400).json({ success: false, error: 'Email de destino inválido' });
    }

    const resend = getResendClient();
    if (!resend) {
      return res.status(400).json({
        success: false,
        error: 'No se detectó RESEND_API_KEY en las variables de entorno. Configúrala en Settings o en .env.',
      });
    }

    const fromEmail = process.env.RESEND_FROM_EMAIL || 'Retrato Escolar <fotos@retratoescolar.com.ar>';

    const data = await resend.emails.send({
      from: fromEmail,
      replyTo: resendReplyTo,
      to: [to],
      subject: '✅ Prueba de conexión con Resend - Retrato Escolar',
      html: `
        <div style="font-family: sans-serif; max-width: 500px; margin: 20px auto; padding: 24px; border: 1px solid #e2e8f0; border-radius: 12px;">
          <h2 style="color: #0f172a; margin-top: 0;">¡Conexión con Resend exitosa!</h2>
          <p style="color: #334155; font-size: 14px;">
            Este es un correo de prueba enviado desde tu dominio <strong>retratoescolar.com.ar</strong> utilizando la API de Resend.
          </p>
          <div style="background-color: #ecfdf5; border: 1px solid #a7f3d0; padding: 12px; border-radius: 8px; color: #065f46; font-size: 13px; margin: 16px 0;">
            ✓ Remitente: <strong>${escapeHtml(fromEmail)}</strong><br>
            ✓ Destino: <strong>${escapeHtml(to)}</strong><br>
            ✓ Sistema: Retrato Escolar 2026
          </div>
          <p style="font-size: 12px; color: #64748b;">
            Tus clientes recibirán sus enlaces HD y comprobantes automáticamente a través de este canal.
          </p>
        </div>
      `,
    });
    if (data.error) {
      return res.status(502).json({ success: false, error: data.error.message || 'Resend rechazó el envío de prueba.' });
    }

    return res.json({
      success: true,
      messageId: data.data?.id,
      from: fromEmail,
    });
  } catch (error: any) {
    console.error('[Resend Test] Error:', error);
    return res.status(500).json({
      success: false,
      error: error?.message || 'Error al enviar email de prueba',
    });
  }
});

export { rutas as rutasResend };
