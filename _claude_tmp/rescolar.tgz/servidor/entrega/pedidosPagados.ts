// Lo que pasa cuando un pedido queda pagado (webhook, conciliación o aprobación a mano): .zip HD +
// email, avisos de reserva y de mejora, y las comisiones reales del cobro (división de server.ts,
// etapa 3, 10/10/2026). El código es el mismo que estaba en la sección 5 de server.ts: sólo se movió.
import type { SupabaseClient } from '@supabase/supabase-js';
import { registrarComisionDePago } from '../comisionesCobro.js';
import { esPedidoFotosExtra, itemsFotosExtra, nombrePedidoFotosExtra } from '../nucleo/fotosExtra.js';
import { enviarCorreoFotosExtraConfirmadas, enviarCorreoFotosHD, enviarCorreoMejoraImpresoConfirmada, enviarCorreoReservaConfirmada, registrarEnvioCorreoHD } from './correos.js';
import { armarZipHDConTurno } from './zipHD.js';

// Auditoría 03/10 (crítico 4): tope de fotos para armar el .zip DENTRO del webhook de pago. Un pedido
// con muchas fotos sueltas se deja para el cron de reintento (que tiene su propio presupuesto de
// tiempo) en vez de arriesgar los 60 s y la memoria de la función que confirma el pago.
const MAX_FOTOS_ZIP_EN_WEBHOOK = 20;

// Tiempo máximo (desde que empezó a procesar el pago) para seguir armando .zip en el webhook; los
// hermanos que no entren reciben el correo de pago confirmado y el .zip se lo manda el cron.
const PRESUPUESTO_ZIP_WEBHOOK_MS = 30000;

export async function procesarPedidosRecienPagados(supabase: SupabaseClient, filas: any[], emailRespaldo?: string | null, nombreRespaldo?: string | null) {
  // Auditoría 03/10 (crítico 4): en serie y con presupuesto de tiempo. Antes los .zip de todos los
  // hijos de un carrito se armaban a la vez en memoria (con varios pagos juntos, falta de memoria o
  // más de 60 s). Cada hijo va en su try: un error en uno no deja sin correo a los demás.
  const inicioProceso = Date.now();
  for (const orderData of filas || []) {
    try {
      await procesarUnPedidoRecienPagado(supabase, orderData, emailRespaldo, nombreRespaldo, Date.now() - inicioProceso < PRESUPUESTO_ZIP_WEBHOOK_MS);
    } catch (err) {
      console.error(`[Pagos] Error procesando el pedido recién pagado ${orderData?.id}:`, err);
    }
  }
  await registrarComisionesDeFilas(supabase, filas);
}

export async function procesarUnPedidoRecienPagado(supabase: SupabaseClient, orderData: any, emailRespaldo: string | null | undefined, nombreRespaldo: string | null | undefined, armarZip: boolean) {
  const emailDestino = orderData?.familias?.email || emailRespaldo;
  if (!emailDestino || !String(emailDestino).includes('@')) return;
  if (esPedidoFotosExtra(orderData)) {
    // 29/10/2026: fotos extra = copias impresas sueltas; no hay .zip HD (las fotos digitales son las del kit).
    const envio = await enviarCorreoFotosExtraConfirmadas({
      to: emailDestino,
      tutorNombre: orderData?.familias?.nombre || nombreRespaldo || 'Familia',
      alumnoNombre: orderData?.alumno_nombre || 'tu hijo/a',
      pedidoId: orderData?.pedido_friendly_id || orderData?.id,
      total: Number(orderData?.total) || 0,
      detalle: nombrePedidoFotosExtra(itemsFotosExtra(orderData)).replace(/^Fotos extra \((.*)\)$/, '$1'),
      idempotencyKey: orderData?.id ? `fotos-extra-${orderData.id}` : undefined,
    });
    if (envio && orderData?.id) {
      await supabase.from('pedidos').update({ email_enviado: true, fecha_envio_email: new Date().toISOString() }).eq('id', orderData.id);
    }
    return;
  }
  if (orderData?.mejora_de_pedido_id) {
    // Mejora a Kit Impreso (27/9): las fotos digitales ya se entregaron con el pedido original;
    // acá sólo se confirma que la carpeta impresa quedó paga.
    const envio = await enviarCorreoMejoraImpresoConfirmada({
      to: emailDestino,
      tutorNombre: orderData?.familias?.nombre || nombreRespaldo || 'Familia',
      alumnoNombre: orderData?.alumno_nombre || 'tu hijo/a',
      pedidoId: orderData?.pedido_friendly_id || orderData?.id,
      total: Number(orderData?.total) || 0,
      idempotencyKey: orderData?.id ? `mejora-impreso-${orderData.id}` : undefined,
    });
    if (envio && orderData?.id) {
      await supabase.from('pedidos').update({ email_enviado: true, fecha_envio_email: new Date().toISOString() }).eq('id', orderData.id);
    }
    return;
  }
  if (orderData?.seleccion_pendiente) {
    // Pago anticipado: se confirma la reserva; el HD sale cuando la familia elija sus fotos.
    const envio = await enviarCorreoReservaConfirmada({
      to: emailDestino,
      tutorNombre: orderData?.familias?.nombre || nombreRespaldo || 'Familia',
      alumnoNombre: orderData?.alumno_nombre || 'tu hijo/a',
      colegioNombre: orderData?.colegio_nombre || 'tu colegio',
      kitNombre: orderData?.kit_nombre || 'Kit',
      pedidoId: orderData?.pedido_friendly_id || orderData?.id,
      total: Number(orderData?.total) || 0,
      idempotencyKey: orderData?.id ? `reserva-confirmada-${orderData.id}` : undefined,
    });
    if (envio.success && orderData?.id) {
      await supabase.from('pedidos').update({ email_enviado: true, fecha_envio_email: new Date().toISOString() }).eq('id', orderData.id);
    }
    return;
  }
  // Sin .zip (falló, se pasó del tope de fotos o del tiempo del webhook): sale igual el correo de
  // pago confirmado con el texto "en breve", y el cron de reintento manda después el link.
  const linkDescargaHD = armarZip ? await armarZipHDConTurno(supabase, orderData, { maxFotos: MAX_FOTOS_ZIP_EN_WEBHOOK }) : null;
  const resultadoEnvio = await enviarCorreoFotosHD({
    to: emailDestino,
    tutorNombre: orderData?.familias?.nombre || nombreRespaldo || 'Familia',
    alumnoNombre: orderData?.alumno_nombre || 'tu hijo/a',
    colegioNombre: orderData?.colegio_nombre || 'tu colegio',
    cursoCodigo: orderData?.curso_codigo || undefined,
    kitNombre: orderData?.kit_nombre || undefined,
    pedidoId: orderData?.pedido_friendly_id || orderData?.id,
    total: Number(orderData?.total) || 0,
    linkDescargaHD: linkDescargaHD || undefined,
    pedidoUuid: orderData?.id,
    idempotencyKey: orderData?.id ? `fotos-hd-${orderData.id}` : undefined,
  });
  await registrarEnvioCorreoHD(supabase, orderData?.id, linkDescargaHD, resultadoEnvio?.success === true);
}

async function registrarComisionesDeFilas(supabase: SupabaseClient, filas: any[]) {
  // Comisión real del medio de cobro (liquidación al colegio). Va DESPUÉS de los emails y con
  // tope de 4 s, para no demorar el webhook; si no llega, la trae el botón del panel.
  const pagos = new Map<string, 'mp_payment_id' | 'nave_payment_id'>();
  for (const f of filas || []) {
    if (f?.mp_payment_id) pagos.set(String(f.mp_payment_id), 'mp_payment_id');
    else if (f?.nave_payment_id) pagos.set(String(f.nave_payment_id), 'nave_payment_id');
  }
  for (const [idPago, columna] of pagos) {
    await Promise.race([registrarComisionDePago(supabase, columna, idPago), new Promise((r) => setTimeout(r, 4000))]);
  }
}
