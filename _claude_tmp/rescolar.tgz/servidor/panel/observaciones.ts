// Observaciones de la toma de fotos (13/10/2026, pedido de Pablo: «un alumno no quiso foto individual, debo
// registrar esos eventos»). Pablo anota desde el panel (pestaña «Observaciones») lo que pasó con un alumno de la
// nómina: no quiso la individual, no quiso la grupal, estuvo ausente u otra cosa, con un detalle libre.
// Tabla `observaciones_alumnos` (migración 20261013150000): guarda una copia del nombre y del curso del alumno al
// anotarla, así se sigue entendiendo aunque después se lo borre o se lo cambie de curso. Sólo admin.
import express from 'express';
import type { Request, Response } from 'express';
import { requireAdminAuth } from '../nucleo/auth.js';
import { getServerSupabase } from '../nucleo/clientes.js';
import { traerTodasLasFilas } from '../nucleo/utilidades.js';

const rutas = express.Router();

export const TIPOS_OBSERVACION = ['sin_foto_individual', 'sin_foto_grupal', 'ausente', 'otra'] as const;
export type TipoObservacion = (typeof TIPOS_OBSERVACION)[number];
const MAX_DETALLE = 1000;
const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const CLAVE_RE = /^[A-Za-z0-9-]{8,64}$/;
const COLUMNAS = 'id, colegio_id, alumno_id, alumno_nombre, grado, division, turno, tipo, detalle, created_at';

rutas.get('/api/admin/observaciones', requireAdminAuth, async (req: Request, res: Response) => {
  try {
    const colegioId = typeof req.query.colegioId === 'string' ? req.query.colegioId : '';
    if (!UUID_RE.test(colegioId)) return res.status(400).json({ success: false, error: 'Falta indicar el colegio.' });
    const supabase = getServerSupabase();
    if (!supabase) return res.status(500).json({ success: false, error: 'Supabase no configurado en el servidor' });
    const observaciones = await traerTodasLasFilas((desde, hasta) =>
      supabase
        .from('observaciones_alumnos')
        .select(COLUMNAS)
        .eq('colegio_id', colegioId)
        .order('created_at', { ascending: false })
        .order('id')
        .range(desde, hasta)
    );
    return res.json({ success: true, observaciones });
  } catch (err: any) {
    console.error('[observaciones] Error al listar:', err);
    return res.status(500).json({ success: false, error: err?.message || 'No se pudieron cargar las observaciones.' });
  }
});

rutas.post('/api/admin/observaciones', requireAdminAuth, async (req: Request, res: Response) => {
  try {
    const alumnoId = String(req.body?.alumnoId ?? '');
    const tipo = String(req.body?.tipo ?? '') as TipoObservacion;
    const detalle = String(req.body?.detalle ?? '').trim();
    if (!UUID_RE.test(alumnoId)) return res.status(400).json({ success: false, error: 'Elegí un alumno de la nómina.' });
    if (!TIPOS_OBSERVACION.includes(tipo)) return res.status(400).json({ success: false, error: 'Tipo de observación no válido.' });
    if (detalle.length > MAX_DETALLE) {
      return res.status(400).json({ success: false, error: `El detalle no puede pasar los ${MAX_DETALLE} caracteres.` });
    }
    if (tipo === 'otra' && !detalle) return res.status(400).json({ success: false, error: 'Contá qué pasó en el detalle.' });
    const supabase = getServerSupabase();
    if (!supabase) return res.status(500).json({ success: false, error: 'Supabase no configurado en el servidor' });

    // El nombre y el curso salen de la nómina, nunca del navegador.
    const { data: alumno, error: errAlumno } = await supabase
      .from('alumnos')
      .select('id, colegio_id, nombre, grado, division, turno')
      .eq('id', alumnoId)
      .maybeSingle();
    if (errAlumno) throw errAlumno;
    if (!alumno) return res.status(404).json({ success: false, error: 'El alumno ya no está en la nómina.' });
    if (!UUID_RE.test(String(alumno.colegio_id || ''))) {
      return res.status(400).json({ success: false, error: 'El alumno no tiene un colegio válido en la nómina.' });
    }

    // 14/10/2026 (auditoría): con la `clave` del panel, un reintento (corte de red, recarga) devuelve la que ya
    // estaba en vez de anotarla dos veces (columna `clave`, única; migración 20261014020400).
    const clave = typeof req.body?.clave === 'string' && CLAVE_RE.test(req.body.clave) ? req.body.clave : null;
    const yaGuardada = async () => {
      const { data: previa, error: errPrevia } = await supabase.from('observaciones_alumnos').select(COLUMNAS).eq('clave', clave).limit(1).maybeSingle();
      return errPrevia ? null : previa;
    };
    if (clave) {
      const previa = await yaGuardada();
      if (previa) return res.json({ success: true, observacion: previa, repetida: true });
    }
    const fila: Record<string, unknown> = {
      colegio_id: alumno.colegio_id,
      alumno_id: alumno.id,
      alumno_nombre: alumno.nombre,
      grado: alumno.grado ?? null,
      division: alumno.division ?? null,
      turno: alumno.turno ?? null,
      tipo,
      detalle: detalle || null,
      ...(clave ? { clave } : {}),
    };
    let { data, error } = await supabase.from('observaciones_alumnos').insert(fila).select(COLUMNAS).maybeSingle();
    if (error && clave && String((error as any).code) === '23505') {
      const previa = await yaGuardada(); // otro intento con la misma clave ganó la carrera
      if (previa) return res.json({ success: true, observacion: previa, repetida: true });
    }
    if (error && clave && /clave/.test(String(error.message || '')) && ['42703', 'PGRST204'].includes(String((error as any).code))) {
      delete fila.clave; // migración sin aplicar: se guarda como antes
      ({ data, error } = await supabase.from('observaciones_alumnos').insert(fila).select(COLUMNAS).maybeSingle());
    }
    if (error) throw error;
    return res.json({ success: true, observacion: data });
  } catch (err: any) {
    console.error('[observaciones] Error al guardar:', err);
    return res.status(500).json({ success: false, error: err?.message || 'No se pudo guardar la observación.' });
  }
});

rutas.delete('/api/admin/observaciones/:id', requireAdminAuth, async (req: Request, res: Response) => {
  try {
    if (!UUID_RE.test(req.params.id)) return res.status(400).json({ success: false, error: 'Observación no válida.' });
    const supabase = getServerSupabase();
    if (!supabase) return res.status(500).json({ success: false, error: 'Supabase no configurado en el servidor' });
    const { error } = await supabase.from('observaciones_alumnos').delete().eq('id', req.params.id);
    if (error) throw error;
    return res.json({ success: true });
  } catch (err: any) {
    console.error('[observaciones] Error al borrar:', err);
    return res.status(500).json({ success: false, error: err?.message || 'No se pudo borrar la observación.' });
  }
});

export { rutas as rutasObservaciones };
