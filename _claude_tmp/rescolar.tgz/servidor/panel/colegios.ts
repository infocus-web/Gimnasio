// Colegios: lista pública (/api/colegios) y ABM desde el panel (grados, divisiones, turnos, muestras
// con lupa), links del padrón y del convenio (división de server.ts, etapa 4, 10/10/2026). El código
// es el mismo que estaba en la sección "4A. COLEGIOS" de server.ts: sólo se movió de lugar.
import crypto from 'crypto';
import express from 'express';
import type { Request, Response } from 'express';
import { requireAdminAuth, verifyAdminToken } from '../nucleo/auth.js';
import { getServerSupabase } from '../nucleo/clientes.js';

const rutas = express.Router();

// ==============================================================================
// 4A. COLEGIOS: PERFIL DE CADA COLEGIO (GRADOS, DIVISIONES, TURNOS, CÓDIGO DE ACCESO)
// ==============================================================================

const GRADOS_POR_DEFECTO_COLEGIO = [
  'Sala 3 años', 'Sala 4 años', 'Sala 5 años',
  '1° grado', '2° grado', '3° grado', '4° grado', '5° grado', '6° grado', '7° grado',
  '1° año', '2° año', '3° año', '4° año', '5° año', '6° año',
];
const DIVISIONES_POR_DEFECTO_COLEGIO = ['A', 'B', 'C', 'Jornada Extendida'];
const TURNOS_POR_DEFECTO_COLEGIO = ['Mañana', 'Tarde', 'Jornada Extendida / Completa'];

function generarSlugColegio(nombre: string): string {
  return String(nombre || '')
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9]/g, '-')
    .replace(/-+/g, '-')
    .replace(/^-|-$/g, '');
}

function mapearColegioSupabase(row: any) {
  return {
    id: row.id,
    slug: row.slug,
    nombre: row.nombre,
    localidad: row.localidad || 'Buenos Aires',
    zona: row.zona || 'CABA',
    eventoActual: row.evento_actual || 'Temporada Oficial Retratos y Fotos Escolares 2026',
    grados: Array.isArray(row.grados) && row.grados.length > 0 ? row.grados : GRADOS_POR_DEFECTO_COLEGIO,
    divisiones: Array.isArray(row.divisiones) && row.divisiones.length > 0 ? row.divisiones : DIVISIONES_POR_DEFECTO_COLEGIO,
    turnos: Array.isArray(row.turnos) && row.turnos.length > 0 ? row.turnos : TURNOS_POR_DEFECTO_COLEGIO,
    codigoAcceso: row.codigo_acceso || '',
    whatsappContacto: row.whatsapp_contacto || undefined,
    // Colegio oculto (2/10): no aparece para las familias; sirve, por ejemplo, para pruebas internas.
    oculto: row.activo_publico === false,
    // 04/10: interruptor «Muestras con lupa» (lupa/muestra.ts). Apagado por defecto.
    muestrasLupa: row.muestras_lupa === true,
  };
}

// Lista pública de colegios: la usan el registro de familias, el portal y la búsqueda del sitio.
// No requiere autenticación porque hace falta ANTES de que una familia se identifique.
rutas.get('/api/colegios', async (req: Request, res: Response) => {
  try {
    const supabase = getServerSupabase();
    if (!supabase) {
      return res.status(500).json({ success: false, error: 'Supabase no configurado en el servidor' });
    }
    // Solo colegios marcados como públicos: excluye el colegio interno "Colegio Demo — Infocus"
    // que usa el módulo de eventos/kits y que no debe aparecer como opción para las familias.
    // El panel del fotógrafo (con su sesión, ?todos=1) ve también los ocultos, como el colegio de
    // prueba del laboratorio (2/10): así se le pueden cargar fotos y pedidos sin avisar a ninguna familia.
    const token = req.headers.authorization?.startsWith('Bearer ') ? req.headers.authorization.substring(7) : undefined;
    const incluirOcultos = req.query.todos === '1' && verifyAdminToken(token);
    let consulta = supabase.from('colegios').select('*');
    if (!incluirOcultos) consulta = consulta.eq('activo_publico', true);
    const { data, error } = await consulta.order('nombre', { ascending: true });
    if (error) throw error;
    // Auditoría 03/10 (medio): la home pedía esta lista varias veces por visita y cada una llegaba a
    // la base. La lista pública es igual para todos: se deja cachear en el CDN de Vercel 60 s. La
    // del panel (?todos=1) nunca se cachea (incluye colegios ocultos).
    if (req.query.todos === '1') res.setHeader('Cache-Control', 'private, no-store');
    else res.setHeader('Cache-Control', 'public, s-maxage=60, stale-while-revalidate=300');
    return res.json({ success: true, colegios: (data || []).map(mapearColegioSupabase) });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err?.message || 'Error al obtener los colegios' });
  }
});

rutas.post('/api/admin/colegios', requireAdminAuth, async (req: Request, res: Response) => {
  try {
    const { nombre, localidad, zona, codigoAcceso, whatsappContacto, grados, divisiones, turnos, eventoActual, muestrasLupa } = req.body || {};
    if (!nombre || !String(nombre).trim()) {
      return res.status(400).json({ success: false, error: 'Falta el nombre de la institución' });
    }
    if (!codigoAcceso || !String(codigoAcceso).trim()) {
      return res.status(400).json({ success: false, error: 'Falta el código de acceso para las familias' });
    }
    const supabase = getServerSupabase();
    if (!supabase) {
      return res.status(500).json({ success: false, error: 'Supabase no configurado en el servidor' });
    }

    const row = {
      slug: generarSlugColegio(nombre),
      nombre: String(nombre).trim(),
      localidad: (localidad || 'Buenos Aires').toString().trim(),
      zona: zona || 'CABA',
      evento_actual: (eventoActual || 'Temporada Oficial Retratos y Fotos Escolares 2026').toString().trim(),
      codigo_acceso: String(codigoAcceso).trim().toUpperCase(),
      whatsapp_contacto: whatsappContacto ? String(whatsappContacto).replace(/\D/g, '') : null,
      grados: Array.isArray(grados) && grados.length > 0 ? grados : GRADOS_POR_DEFECTO_COLEGIO,
      divisiones: Array.isArray(divisiones) && divisiones.length > 0 ? divisiones : DIVISIONES_POR_DEFECTO_COLEGIO,
      turnos: Array.isArray(turnos) && turnos.length > 0 ? turnos : TURNOS_POR_DEFECTO_COLEGIO,
      muestras_lupa: muestrasLupa === true,
    };

    const { data, error } = await supabase.from('colegios').insert(row).select().single();
    if (error) throw error;
    return res.json({ success: true, colegio: mapearColegioSupabase(data) });
  } catch (err: any) {
    console.error('Error al crear colegio:', err);
    return res.status(500).json({ success: false, error: err?.message || 'Error al crear el colegio' });
  }
});

rutas.put('/api/admin/colegios/:id', requireAdminAuth, async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const { nombre, localidad, zona, codigoAcceso, whatsappContacto, grados, divisiones, turnos, eventoActual, muestrasLupa } = req.body || {};
    const supabase = getServerSupabase();
    if (!supabase) {
      return res.status(500).json({ success: false, error: 'Supabase no configurado en el servidor' });
    }

    const cambios: Record<string, any> = { updated_at: new Date().toISOString() };
    if (nombre !== undefined) {
      cambios.nombre = String(nombre).trim();
      cambios.slug = generarSlugColegio(nombre);
    }
    if (localidad !== undefined) cambios.localidad = String(localidad).trim();
    if (zona !== undefined) cambios.zona = zona;
    if (codigoAcceso !== undefined) cambios.codigo_acceso = String(codigoAcceso).trim().toUpperCase();
    if (whatsappContacto !== undefined) {
      cambios.whatsapp_contacto = whatsappContacto ? String(whatsappContacto).replace(/\D/g, '') : null;
    }
    if (eventoActual !== undefined) cambios.evento_actual = String(eventoActual).trim();
    if (Array.isArray(grados)) cambios.grados = grados;
    if (Array.isArray(divisiones)) cambios.divisiones = divisiones;
    if (Array.isArray(turnos)) cambios.turnos = turnos;
    if (typeof muestrasLupa === 'boolean') cambios.muestras_lupa = muestrasLupa;
    // Auditoría 11/10: ocultar (en vez de borrar) un colegio con convenio o pedidos.
    if (typeof req.body?.oculto === 'boolean') cambios.activo_publico = !req.body.oculto;

    const { data, error } = await supabase.from('colegios').update(cambios).eq('id', id).select().single();
    if (error) throw error;
    return res.json({ success: true, colegio: mapearColegioSupabase(data) });
  } catch (err: any) {
    console.error('Error al actualizar colegio:', err);
    return res.status(500).json({ success: false, error: err?.message || 'Error al actualizar el colegio' });
  }
});

rutas.delete('/api/admin/colegios/:id', requireAdminAuth, async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const supabase = getServerSupabase();
    if (!supabase) {
      return res.status(500).json({ success: false, error: 'Supabase no configurado en el servidor' });
    }
    // Auditoría 11/10: borrar un colegio arrastra (cascade) sus convenios firmados. Con convenio o pedidos no se
    // borra: se oculta. Si no se puede verificar, tampoco se borra.
    const [convenios, pedidos] = await Promise.all([
      supabase.from('convenios_colegios').select('id', { count: 'exact', head: true }).eq('colegio_id', id),
      supabase.from('pedidos').select('id', { count: 'exact', head: true }).eq('colegio_id', id),
    ]);
    if (convenios.error || pedidos.error) throw convenios.error || pedidos.error;
    if ((convenios.count || 0) > 0 || (pedidos.count || 0) > 0) {
      return res.status(409).json({
        success: false,
        codigo: 'COLEGIO_CON_HISTORIAL',
        error: 'Este colegio tiene convenio firmado o pedidos: ocultalo en vez de borrarlo (se pierden el convenio y la base de la liquidación).',
      });
    }
    const { error } = await supabase.from('colegios').delete().eq('id', id);
    if (error) {
      if (String((error as any).code) === '23503') {
        return res.status(409).json({
          success: false,
          error: 'No se puede eliminar: este colegio ya tiene familias, eventos o pedidos asociados.',
        });
      }
      throw error;
    }
    return res.json({ success: true });
  } catch (err: any) {
    console.error('Error al eliminar colegio:', err);
    return res.status(500).json({ success: false, error: err?.message || 'Error al eliminar el colegio' });
  }
});

// Panel admin: devuelve el token secreto de carga de padrón de cada colegio (nunca se expone en /api/colegios,
// que es público). Se usa para armar el link que el fotógrafo comparte con la secretaría del colegio.
rutas.get('/api/admin/colegios/padron-links', requireAdminAuth, async (req: Request, res: Response) => {
  try {
    const supabase = getServerSupabase();
    if (!supabase) {
      return res.status(500).json({ success: false, error: 'Supabase no configurado en el servidor' });
    }
    const { data, error } = await supabase.from('colegios').select('id, codigo_padron');
    if (error) throw error;

    const tokens: Record<string, string> = {};
    for (const row of data || []) {
      if (row.codigo_padron) tokens[row.id] = row.codigo_padron;
    }
    return res.json({ success: true, tokens });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err?.message || 'Error al obtener los links de padrón' });
  }
});

// Convenio con el colegio (27/9): link propio de cada colegio para completar y firmar online el
// convenio (/convenio.html?c=CODIGO). Es DISTINTO del link de padrón, que se reenvía a las familias:
// con ese no se puede firmar. Si un colegio todavía no tiene código, se genera acá.
rutas.get('/api/admin/colegios/convenio-links', requireAdminAuth, async (_req: Request, res: Response) => {
  try {
    const supabase = getServerSupabase();
    if (!supabase) return res.status(500).json({ success: false, error: 'Supabase no configurado en el servidor' });
    const { data: colegios, error } = await supabase.from('colegios').select('id, codigo_convenio');
    if (error) throw error;
    const links: Record<string, { codigo: string; firmadoAt: string | null; firmante: string | null }> = {};
    for (const c of colegios || []) {
      let codigo = c.codigo_convenio as string | null;
      if (!codigo) {
        codigo = `CV${crypto.randomBytes(6).toString('hex').toUpperCase()}`;
        const { error: errorUpdate } = await supabase.from('colegios').update({ codigo_convenio: codigo }).eq('id', c.id);
        if (errorUpdate) throw errorUpdate;
      }
      links[c.id] = { codigo, firmadoAt: null, firmante: null };
    }
    const { data: firmados, error: errorFirmados } = await supabase
      .from('convenios_colegios')
      .select('colegio_id, created_at, firmante_nombre, firmante_cargo')
      .order('created_at', { ascending: false });
    // Auditoría 11/10: sin esto, un error mostraba todos los convenios como "sin firmar".
    if (errorFirmados) throw errorFirmados;
    for (const f of firmados || []) {
      const link = links[f.colegio_id];
      if (link && !link.firmadoAt) {
        link.firmadoAt = f.created_at;
        link.firmante = `${f.firmante_nombre} (${f.firmante_cargo})`;
      }
    }
    return res.json({ success: true, links });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err?.message || 'Error al obtener los links del convenio' });
  }
});

// Panel admin: regenera el token secreto de un colegio (por si el link se filtró o hay que invalidarlo)
rutas.post('/api/admin/colegios/:id/regenerar-padron', requireAdminAuth, async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const supabase = getServerSupabase();
    if (!supabase) {
      return res.status(500).json({ success: false, error: 'Supabase no configurado en el servidor' });
    }
    const nuevoToken = crypto.randomBytes(5).toString('hex').toUpperCase();
    const { data, error } = await supabase
      .from('colegios')
      .update({ codigo_padron: nuevoToken, updated_at: new Date().toISOString() })
      .eq('id', id)
      .select('id, codigo_padron')
      .single();
    if (error) throw error;
    return res.json({ success: true, codigoPadron: data.codigo_padron });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err?.message || 'Error al regenerar el token' });
  }
});

export { rutas as rutasColegios };
