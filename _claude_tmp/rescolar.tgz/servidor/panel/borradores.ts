// Borradores del panel (14/10/2026, auditoría: AdminModal desmonta cada pestaña al cambiar, así que una
// respuesta a medio escribir, las notas de una cancelación o la plantilla de la campaña se perdían al cambiar
// de pestaña o recargar). El panel los guarda solo, mientras se escribe (useBorradorAdmin), en la tabla
// `borradores_admin` (migración 20261014020300) y los borra al enviar o guardar. Sólo admin; tope de 200 KB.
import express from 'express';
import type { Request, Response } from 'express';
import { requireAdminAuth } from '../nucleo/auth.js';
import { getServerSupabase } from '../nucleo/clientes.js';

const rutas = express.Router();
const CLAVE_RE = /^[A-Za-z0-9:_.@-]{1,160}$/;
export const MAX_BYTES_BORRADOR = 200 * 1024;

function claveValida(req: Request, res: Response): string | null {
  const clave = String(req.params.clave || '');
  if (CLAVE_RE.test(clave)) return clave;
  res.status(400).json({ success: false, error: 'Clave de borrador no válida.' });
  return null;
}

rutas.get('/api/admin/borradores/:clave', requireAdminAuth, async (req: Request, res: Response) => {
  try {
    const clave = claveValida(req, res);
    if (!clave) return;
    const supabase = getServerSupabase();
    if (!supabase) return res.status(500).json({ success: false, error: 'Supabase no configurado en el servidor' });
    const { data, error } = await supabase.from('borradores_admin').select('contenido, updated_at').eq('clave', clave).maybeSingle();
    if (error) throw error;
    return res.json({ success: true, contenido: data?.contenido ?? null, updatedAt: data?.updated_at ?? null });
  } catch (err: any) {
    console.error('[borradores] Error al leer:', err);
    return res.status(500).json({ success: false, error: 'No se pudo leer el borrador.' });
  }
});

rutas.put('/api/admin/borradores/:clave', requireAdminAuth, async (req: Request, res: Response) => {
  try {
    const clave = claveValida(req, res);
    if (!clave) return;
    const contenido = req.body?.contenido;
    if (contenido === undefined || contenido === null) return res.status(400).json({ success: false, error: 'Falta el contenido del borrador.' });
    if (Buffer.byteLength(JSON.stringify(contenido), 'utf8') > MAX_BYTES_BORRADOR) {
      return res.status(413).json({ success: false, error: 'El borrador es demasiado grande para guardarlo (máximo 200 KB).' });
    }
    const supabase = getServerSupabase();
    if (!supabase) return res.status(500).json({ success: false, error: 'Supabase no configurado en el servidor' });
    const { error } = await supabase.from('borradores_admin').upsert({ clave, contenido, updated_at: new Date().toISOString() }, { onConflict: 'clave' });
    if (error) throw error;
    return res.json({ success: true });
  } catch (err: any) {
    console.error('[borradores] Error al guardar:', err);
    return res.status(500).json({ success: false, error: 'No se pudo guardar el borrador.' });
  }
});

rutas.delete('/api/admin/borradores/:clave', requireAdminAuth, async (req: Request, res: Response) => {
  try {
    const clave = claveValida(req, res);
    if (!clave) return;
    const supabase = getServerSupabase();
    if (!supabase) return res.status(500).json({ success: false, error: 'Supabase no configurado en el servidor' });
    const { error } = await supabase.from('borradores_admin').delete().eq('clave', clave);
    if (error) throw error;
    return res.json({ success: true });
  } catch (err: any) {
    console.error('[borradores] Error al borrar:', err);
    return res.status(500).json({ success: false, error: 'No se pudo borrar el borrador.' });
  }
});

export { rutas as rutasBorradores };
