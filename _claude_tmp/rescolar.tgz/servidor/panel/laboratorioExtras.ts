// Lotes de FOTOS EXTRA en el panel del laboratorio (29/10/2026, pedido de Pablo: «que esos pedidos se impriman en
// otro lote para que no se mezcle con los kit»). Los pedidos de fotos extra (tipo_kit 'fotos_extra', ver
// servidor/nucleo/fotosExtra.ts) nunca entran en los lotes de kits (pedidosParaLaboratorio de laboratorio.ts filtra
// tipo_kit = 'impreso_digital'): acá se arman en lotes propios (lotes_laboratorio.tipo = 'extras'). El ZIP se arma en
// el navegador con links firmados (como los lotes de eventos): carpeta por tamaño, un archivo por copia, y una planilla
// para ensobrar. «Marcar en producción» usa la misma ruta que los kits (/api/lab/lotes/:id/en-produccion).
import type { SupabaseClient } from '@supabase/supabase-js';
import express from 'express';
import type { Request, Response } from 'express';
import { requireLabAuth } from '../nucleo/auth.js';
import { getServerSupabase } from '../nucleo/clientes.js';
import { copiasPorTamano, itemsFotosExtra, TIPO_KIT_FOTOS_EXTRA } from '../nucleo/fotosExtra.js';
import { limitarFrecuencia } from '../nucleo/limites.js';
import { enLotes, traerTodasLasFilas } from '../nucleo/utilidades.js';

const rutas = express.Router();
const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

// Sin datos de contacto ni importes (igual que COLUMNAS_PEDIDO_LAB).
const COLUMNAS_EXTRAS_LAB =
  'id, pedido_friendly_id, created_at, colegio_id, colegio_nombre, curso_codigo, grado, division, turno, alumno_nombre, codigo_alumno, tipo_kit, kit_nombre, fotos_seleccionadas, estado, estado_lab, lote_lab_id, extras_de_pedido_id';

/** Pedidos de fotos extra cobrados y activos (con o sin lote). */
export async function pedidosExtrasParaLaboratorio(supabase: SupabaseClient, loteId?: string) {
  return traerTodasLasFilas<any>((desde, hasta) => {
    let q = supabase
      .from('pedidos')
      .select(COLUMNAS_EXTRAS_LAB)
      .in('estado', ['pagado', 'entregado'])
      .eq('tipo_kit', TIPO_KIT_FOTOS_EXTRA)
      .eq('en_espera', false)
      .eq('archivado', false);
    if (loteId) q = q.eq('lote_lab_id', loteId);
    return q.order('created_at', { ascending: true }).order('id').range(desde, hasta);
  });
}

function totalesDe(pedidos: any[]) {
  const t = pedidos.reduce(
    (a, p) => {
      const c = copiasPorTamano(itemsFotosExtra(p));
      return { fotos15x21: a.fotos15x21 + c.fotos15x21, fotos20x30: a.fotos20x30 + c.fotos20x30 };
    },
    { fotos15x21: 0, fotos20x30: 0 }
  );
  return { cantidad: pedidos.length, carpetas: 0, fotos_15x21: t.fotos15x21, fotos_20x30: t.fotos20x30, fotos_sueltas: 0 };
}

const limpiar = (texto: unknown) =>
  String(texto || '')
    .normalize('NFD')
    .replace(/[̀-ͯ]/g, '')
    .toUpperCase()
    .replace(/[^A-Z0-9]+/g, '_')
    .replace(/^_|_$/g, '');

export interface ArchivoExtraLab {
  carpeta: '15x21' | '20x30';
  nombre: string;
  fotoId: string;
  pedido: string;
  alumno: string;
  curso: string;
  numeroLista: number | null;
  copia: number;
  copias: number;
}

/**
 * Un archivo por copia, en la carpeta de su tamaño. Nombre: CURSO_NN_ALUMNO_PEDIDO_F<n>_<copia>de<copias>.jpg
 * (NN = número de lista del kit original, para ensobrar junto al kit).
 */
export function archivosDeExtras(pedidos: any[], numeroPorKit: Map<string, number | null>): ArchivoExtraLab[] {
  const salida: ArchivoExtraLab[] = [];
  const ordenados = [...pedidos].sort(
    (a, b) =>
      String(a.curso_codigo || '').localeCompare(String(b.curso_codigo || '')) ||
      (numeroPorKit.get(String(a.extras_de_pedido_id)) ?? 999) - (numeroPorKit.get(String(b.extras_de_pedido_id)) ?? 999) ||
      String(a.alumno_nombre || '').localeCompare(String(b.alumno_nombre || ''), 'es')
  );
  for (const p of ordenados) {
    const numero = numeroPorKit.get(String(p.extras_de_pedido_id)) ?? null;
    const base = [limpiar(p.curso_codigo), numero ? String(numero).padStart(2, '0') : 'SN', limpiar(p.alumno_nombre), limpiar(p.pedido_friendly_id || p.id)].filter(Boolean).join('_');
    itemsFotosExtra(p).forEach((it, i) => {
      for (let copia = 1; copia <= it.cantidad; copia++) {
        salida.push({
          carpeta: it.tamano,
          nombre: `${base}_F${i + 1}_${copia}de${it.cantidad}.jpg`,
          fotoId: it.fotoId,
          pedido: String(p.pedido_friendly_id || p.id),
          alumno: String(p.alumno_nombre || ''),
          curso: String(p.curso_codigo || ''),
          numeroLista: numero,
          copia,
          copias: it.cantidad,
        });
      }
    });
  }
  return salida;
}

async function numerosDeLista(supabase: SupabaseClient, pedidos: any[]): Promise<Map<string, number | null>> {
  const ids = [...new Set(pedidos.map((p) => String(p.extras_de_pedido_id || '')).filter(Boolean))];
  const mapa = new Map<string, number | null>();
  for (const grupo of enLotes(ids, 100)) {
    const { data, error } = await supabase.from('pedidos').select('id, alumno_numero_lista').in('id', grupo);
    if (error) throw error;
    for (const f of data || []) mapa.set(String(f.id), Number(f.alumno_numero_lista) || null);
  }
  return mapa;
}

// Pedidos nuevos (sin lote) y lotes de fotos extra.
rutas.get('/api/lab/extras', requireLabAuth, async (_req: Request, res: Response) => {
  try {
    const supabase = getServerSupabase();
    if (!supabase) return res.status(503).json({ success: false, error: 'Servicio no disponible' });
    const pedidos = await pedidosExtrasParaLaboratorio(supabase);
    const nuevos = pedidos.filter((p: any) => !p.lote_lab_id && !p.estado_lab);
    const { data: lotes, error } = await supabase
      .from('lotes_laboratorio')
      .select('id, numero, created_at, cantidad, en_produccion_at, fotos_20x30, fotos_15x21')
      .eq('tipo', 'extras')
      .order('numero', { ascending: false })
      .limit(50);
    if (error) throw error;
    const nuevosTot = totalesDe(nuevos);
    res.setHeader('Cache-Control', 'private, no-store');
    return res.json({
      success: true,
      nuevos: { pedidos: nuevos.length, fotos15x21: nuevosTot.fotos_15x21, fotos20x30: nuevosTot.fotos_20x30 },
      lotes: lotes || [],
    });
  } catch (err: any) {
    console.error('[Laboratorio extras] Error al listar:', err);
    return res.status(500).json({ success: false, error: 'No se pudieron cargar las fotos extra.' });
  }
});

// Arma un lote de fotos extra con todos los pedidos nuevos (un pedido nunca sale en dos lotes).
rutas.post('/api/lab/extras/lotes', requireLabAuth, limitarFrecuencia('lab-lotes-extras', 30, 10 * 60 * 1000), async (_req: Request, res: Response) => {
  try {
    const supabase = getServerSupabase();
    if (!supabase) return res.status(503).json({ success: false, error: 'Servicio no disponible' });
    const nuevos = (await pedidosExtrasParaLaboratorio(supabase)).filter((p: any) => !p.lote_lab_id && !p.estado_lab);
    if (nuevos.length === 0) return res.status(409).json({ success: false, error: 'No hay fotos extra nuevas para imprimir.' });
    const { data: lote, error } = await supabase.from('lotes_laboratorio').insert({ cantidad: 0, tipo: 'extras' }).select('id, numero, created_at').single();
    if (error || !lote) throw error || new Error('No se pudo crear el lote');
    const asignados: string[] = [];
    const guardarTotales = async () => {
      const ids = new Set(asignados);
      await supabase.from('lotes_laboratorio').update(totalesDe(nuevos.filter((p: any) => ids.has(p.id)))).eq('id', lote.id);
    };
    try {
      for (const grupo of enLotes(nuevos.map((p: any) => p.id))) {
        const { data, error: errUpd } = await supabase
          .from('pedidos')
          .update({ lote_lab_id: lote.id })
          .in('id', grupo)
          .is('lote_lab_id', null)
          .select('id');
        if (errUpd) throw errUpd;
        asignados.push(...(data || []).map((f: any) => f.id));
      }
    } catch (errAsignar) {
      if (asignados.length > 0) await guardarTotales();
      else await supabase.from('lotes_laboratorio').delete().eq('id', lote.id);
      throw errAsignar;
    }
    if (asignados.length === 0) {
      await supabase.from('lotes_laboratorio').delete().eq('id', lote.id);
      return res.status(409).json({ success: false, error: 'Esos pedidos ya se armaron en otro lote.' });
    }
    await guardarTotales();
    return res.json({ success: true, lote: { ...lote, ...totalesDe(nuevos.filter((p: any) => asignados.includes(p.id))) } });
  } catch (err: any) {
    console.error('[Laboratorio extras] Error al armar el lote:', err);
    return res.status(500).json({ success: false, error: 'No se pudo armar el lote de fotos extra.' });
  }
});

// Lista de archivos del lote con links firmados (2 h) + planilla para ensobrar. El ZIP se arma en el navegador.
rutas.get('/api/lab/extras/lotes/:id/manifiesto', requireLabAuth, async (req: Request, res: Response) => {
  try {
    const loteId = String(req.params.id || '');
    if (!UUID_RE.test(loteId)) return res.status(400).json({ success: false, error: 'Lote inválido' });
    const supabase = getServerSupabase();
    if (!supabase) return res.status(503).json({ success: false, error: 'Servicio no disponible' });
    const { data: lote, error } = await supabase.from('lotes_laboratorio').select('id, numero, tipo, cantidad').eq('id', loteId).maybeSingle();
    if (error) throw error;
    if (!lote || lote.tipo !== 'extras') return res.status(404).json({ success: false, error: 'No se encontró el lote de fotos extra.' });
    // Sólo los pedidos que siguen cobrados (uno cancelado después de armar el lote no se imprime).
    const pedidos = await pedidosExtrasParaLaboratorio(supabase, loteId);
    const archivos = archivosDeExtras(pedidos, await numerosDeLista(supabase, pedidos));
    const fotoIds = [...new Set(archivos.map((a) => a.fotoId))];
    const rutaPorFoto = new Map<string, string>();
    for (const grupo of enLotes(fotoIds, 100)) {
      const { data, error: errFotos } = await supabase.from('fotos').select('id, storage_path').in('id', grupo);
      if (errFotos) throw errFotos;
      for (const f of data || []) if (f.storage_path) rutaPorFoto.set(String(f.id).toLowerCase(), f.storage_path);
    }
    const rutasHd = [...new Set(rutaPorFoto.values())];
    const urlPorRuta = new Map<string, string>();
    for (let i = 0; i < rutasHd.length; i += 100) {
      const { data, error: errFirma } = await supabase.storage.from('fotos-hd').createSignedUrls(rutasHd.slice(i, i + 100), 2 * 3600);
      if (errFirma) throw errFirma;
      for (const f of data || []) if (f.path && f.signedUrl) urlPorRuta.set(f.path, f.signedUrl);
    }
    res.setHeader('Cache-Control', 'private, no-store');
    return res.json({
      success: true,
      lote: { id: lote.id, numero: lote.numero, cantidad: lote.cantidad },
      pedidosVigentes: pedidos.length,
      archivos: archivos.map((a) => {
        const ruta = rutaPorFoto.get(a.fotoId.toLowerCase());
        return { carpeta: a.carpeta, nombre: a.nombre, url: (ruta && urlPorRuta.get(ruta)) || null, pedido: a.pedido, alumno: a.alumno, curso: a.curso, numeroLista: a.numeroLista, copia: a.copia, copias: a.copias };
      }),
    });
  } catch (err: any) {
    console.error('[Laboratorio extras] Error al preparar el lote:', err);
    return res.status(500).json({ success: false, error: 'No se pudieron preparar los archivos del lote.' });
  }
});

export { rutas as rutasLaboratorioExtras };
