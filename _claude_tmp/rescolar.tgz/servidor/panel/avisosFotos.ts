// Aviso «ya están tus fotos» por curso (14/10/2026, auditoría: si el aviso fallaba no había forma de
// reenviarlo). Antes «Publicar» avisaba sólo si el curso no tenía fotos publicadas: si Resend fallaba, el
// curso ya quedaba con fotos y nunca más se avisaba. Ahora la tabla `avisos_fotos_curso` (migración
// 20261014020100) anota el curso SÓLO cuando Resend confirmó envíos; «Publicar» avisa a los cursos sin fila
// y el panel tiene «Reenviar aviso a las familias» (POST /api/admin/fotos/reenviar-aviso). Sólo admin.
import type { SupabaseClient } from '@supabase/supabase-js';
import express from 'express';
import type { Request, Response } from 'express';
import { avisarFotosDisponiblesASeccion } from '../entrega/correos.js';
import type { SeccionFotosDisponible } from '../entrega/correos.js';
import { requireAdminAuth } from '../nucleo/auth.js';
import { getServerSupabase } from '../nucleo/clientes.js';

const rutas = express.Router();
const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
export const AVISO_INCOMPLETO = 'Las fotos se publicaron, pero algunos avisos por email no salieron. Usá «Reenviar aviso a las familias» en ese curso.';

// 14/10/2026: sin la tabla (migración 20261014020100 sin aplicar) no se puede anotar nada; no es un aviso
// incompleto (los emails salieron), así que se devuelve true y se loguea una sola vez.
const CODIGOS_SIN_TABLA = new Set(['42P01', 'PGRST205', 'PGRST204', '42703']);
let avisoSinTablaLogueado = false;
export function faltaTablaAvisos(error: any): boolean {
  return !!error && CODIGOS_SIN_TABLA.has(String(error.code || ''));
}

async function anotarAviso(supabase: SupabaseClient, seccion: SeccionFotosDisponible, enviados: number): Promise<boolean> {
  const { error } = await supabase
    .from('avisos_fotos_curso')
    .upsert({ colegio_id: seccion.colegioId, codigo_curso: seccion.codigoCurso, enviado_at: new Date().toISOString(), enviados }, { onConflict: 'colegio_id,codigo_curso' });
  if (faltaTablaAvisos(error)) {
    if (!avisoSinTablaLogueado) console.warn('[avisosFotos] Falta la tabla avisos_fotos_curso (migración sin aplicar); no se anota el aviso.');
    avisoSinTablaLogueado = true;
    return true;
  }
  if (error) console.error('[avisosFotos] No se pudo anotar el aviso del curso:', error);
  return !error;
}

/** ¿El curso ya tiene el aviso confirmado? Sin la tabla (migración sin aplicar) usa el criterio viejo. */
async function cursoYaAvisado(supabase: SupabaseClient, seccion: SeccionFotosDisponible, marca: string): Promise<boolean> {
  const { data, error } = await supabase
    .from('avisos_fotos_curso')
    .select('codigo_curso')
    .eq('colegio_id', seccion.colegioId)
    .eq('codigo_curso', seccion.codigoCurso)
    .maybeSingle();
  if (!error) return !!data;
  console.error('[avisosFotos] No se pudo leer avisos_fotos_curso; uso «tenía fotos publicadas»:', error);
  const { count, error: errorConteo } = await supabase
    .from('fotos')
    .select('id', { count: 'exact', head: true })
    .eq('colegio_id', seccion.colegioId)
    .eq('codigo_curso', seccion.codigoCurso)
    .lt('publicada_at', marca);
  if (errorConteo) throw errorConteo;
  return (count || 0) > 0;
}

/** Al publicar: avisa a los cursos que todavía no tienen el aviso confirmado. */
export async function avisarCursosPublicados(
  supabase: SupabaseClient,
  secciones: SeccionFotosDisponible[],
  marca: string
): Promise<{ emailsEnviados: number; warning?: string }> {
  let emailsEnviados = 0;
  let incompleto = false;
  for (const seccion of secciones) {
    try {
      if (await cursoYaAvisado(supabase, seccion, marca)) continue;
      const { enviados, total } = await avisarFotosDisponiblesASeccion(supabase, seccion);
      emailsEnviados += enviados;
      if (enviados < total) incompleto = true;
      if (enviados > 0 && !(await anotarAviso(supabase, seccion, enviados))) incompleto = true;
    } catch (errorAviso) {
      console.error('[fotos] No se pudo enviar el aviso al publicar:', errorAviso);
      incompleto = true;
    }
  }
  return { emailsEnviados, warning: incompleto ? AVISO_INCOMPLETO : undefined };
}

rutas.get('/api/admin/fotos/avisos', requireAdminAuth, async (req: Request, res: Response) => {
  try {
    const colegioId = typeof req.query.colegioId === 'string' ? req.query.colegioId : '';
    if (!UUID_RE.test(colegioId)) return res.status(400).json({ success: false, error: 'Falta indicar el colegio.' });
    const supabase = getServerSupabase();
    if (!supabase) return res.status(500).json({ success: false, error: 'Supabase no configurado en el servidor' });
    const { data, error } = await supabase.from('avisos_fotos_curso').select('codigo_curso, enviado_at, enviados').eq('colegio_id', colegioId);
    // 14/10/2026: sin la tabla todavía, el panel recibe la lista vacía en vez de un 500.
    if (faltaTablaAvisos(error)) return res.json({ success: true, avisos: [] });
    if (error) throw error;
    return res.json({ success: true, avisos: data || [] });
  } catch (err: any) {
    console.error('[avisosFotos] Error al listar:', err);
    return res.status(500).json({ success: false, error: 'No se pudieron leer los avisos enviados.' });
  }
});

rutas.post('/api/admin/fotos/reenviar-aviso', requireAdminAuth, async (req: Request, res: Response) => {
  try {
    const colegioId = typeof req.body?.colegioId === 'string' ? req.body.colegioId.trim() : '';
    const codigoCurso = typeof req.body?.codigoCurso === 'string' ? req.body.codigoCurso.trim() : '';
    if (!UUID_RE.test(colegioId) || !codigoCurso) return res.status(400).json({ success: false, error: 'Falta el curso.' });
    const supabase = getServerSupabase();
    if (!supabase) return res.status(500).json({ success: false, error: 'Supabase no configurado en el servidor' });
    const { data: foto, error } = await supabase
      .from('fotos')
      .select('grado, turno, division')
      .eq('colegio_id', colegioId)
      .eq('codigo_curso', codigoCurso)
      .not('publicada_at', 'is', null)
      .limit(1)
      .maybeSingle();
    if (error) throw error;
    if (!foto) return res.status(400).json({ success: false, error: 'Ese curso todavía no tiene fotos publicadas.' });
    const seccion: SeccionFotosDisponible = { colegioId, codigoCurso, grado: foto.grado || '', turno: foto.turno || '', division: foto.division || '' };
    // Clave por tramo de 10 minutos: un doble clic no duplica, pero un reenvío más tarde sale de verdad.
    const { enviados, total, yaAvisados } = await avisarFotosDisponiblesASeccion(supabase, seccion, { sufijoClave: `reenvio-${Math.floor(Date.now() / 600_000)}` });
    if (enviados > 0) await anotarAviso(supabase, seccion, enviados + yaAvisados);
    return res.json({
      success: true,
      emailsEnviados: enviados,
      destinatarios: total,
      yaAvisados,
      warning: total === 0 && yaAvisados > 0 ? `Las ${yaAvisados} familias del curso ya habían recibido el aviso: no se mandó de nuevo.`
        : total === 0 ? 'No hay familias aprobadas en ese curso: no se mandó ningún aviso.'
        : enviados < total ? `Salieron ${enviados} de ${total} avisos. Probá de nuevo en unos minutos.` : undefined,
    });
  } catch (err: any) {
    console.error('[avisosFotos] Error al reenviar el aviso:', err);
    return res.status(500).json({ success: false, error: err?.message?.includes('RESEND') ? 'El envío de emails no está configurado.' : 'No se pudo reenviar el aviso. Probá de nuevo.' });
  }
});

export { rutas as rutasAvisosFotos };
