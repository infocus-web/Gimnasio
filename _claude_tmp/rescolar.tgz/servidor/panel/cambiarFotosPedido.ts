// «Cambiar fotos» de un pedido ya confirmado (25/10/2026, regla de Pablo: «cambio hasta laboratorio»). Una familia que
// ya eligió y pagó pide cambiar una foto: desde el panel (Laboratorio → pedido) Pablo elige las fotos nuevas. Se puede
// sólo mientras el pedido NO entró al laboratorio (sin lote ni estado de laboratorio). Mismas reglas que al elegir la
// familia (validarSeleccionFotos: fotos publicadas del curso, individual con nombre sólo del chico, 3ª foto del curso,
// lugares «no tiene esta foto»). Las fotos sueltas que ya pagó se mantienen. Se rearma el .zip HD (mismo archivo,
// se pisa) y le llega a la familia el mail con la descarga nueva.
import crypto from 'crypto';
import express from 'express';
import type { Request, Response } from 'express';
import { pedidoHabilitaDescarga } from '../nucleo/accesoPedidos.js';
import { requireAdminAuth } from '../nucleo/auth.js';
import { getServerSupabase } from '../nucleo/clientes.js';
import { esPedidoFotosExtra } from '../nucleo/fotosExtra.js';
import { enviarCorreoFotosHD, registrarEnvioCorreoHD } from '../entrega/correos.js';
import { armarZipHDConTurno } from '../entrega/zipHD.js';
import { validarSeleccionFotos } from '../pagos/crearPedido.js';

const rutas = express.Router();
const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

/** Motivo por el que no se pueden cambiar las fotos de este pedido (null = se puede). */
export function motivoNoCambiable(p: any): string | null {
  if (!p) return 'Pedido no encontrado.';
  if (!pedidoHabilitaDescarga(p.estado) || p.cancelado_definitivo) return 'El pedido no está pagado.';
  if (esPedidoFotosExtra(p)) return 'Es un pedido de fotos extra: las fotos las eligió la familia al comprarlas.';
  if (p.mejora_de_pedido_id) return 'Es una mejora a Kit Impreso: cambiá las fotos en el pedido original.';
  if (p.seleccion_pendiente) return 'La familia todavía no eligió sus fotos: las elige ella desde la galería.';
  if (p.lote_lab_id || p.estado_lab) return 'Este pedido ya entró al laboratorio: ya no se pueden cambiar las fotos.';
  return null;
}

rutas.post('/api/admin/pedidos/:id/cambiar-fotos', requireAdminAuth, async (req: Request, res: Response) => {
  try {
    if (!UUID_RE.test(req.params.id)) return res.status(400).json({ success: false, error: 'Pedido no válido.' });
    const supabase = getServerSupabase();
    if (!supabase) return res.status(500).json({ success: false, error: 'Supabase no configurado en el servidor' });
    const { data: pedido, error } = await supabase.from('pedidos').select('*').eq('id', req.params.id).maybeSingle();
    if (error) throw error;
    const motivo = motivoNoCambiable(pedido);
    if (motivo) return res.status(pedido ? 409 : 404).json({ success: false, error: motivo });
    // 25/10 (Pablo: «si alguno se hace el vivo, pide el cambio para quedarse con las dos fotos»): si la familia ya
    // descargó el HD, ya tiene la foto anterior. No se cambia salvo que Pablo lo confirme a propósito.
    const descargas = Number(pedido.descargas_hd) || 0;
    // 25/10 noche (Pablo): «Cambiar sólo la impresa»: se imprime la foto nueva y la descarga digital queda como está
    // (sin rearmar el .zip ni mandar mail). No le da una foto de más, así que se permite aunque ya haya descargado.
    const soloImpresa = req.body?.soloImpresa === true;
    if (soloImpresa && pedido.tipo_kit === 'solo_digital') return res.status(400).json({ success: false, error: 'Este kit es sólo digital: no tiene copia impresa.' });
    if (descargas > 0 && req.body?.aunqueDescargo !== true && !soloImpresa) {
      return res.status(409).json({ success: false, codigo: 'YA_DESCARGO', descargas, error: `La familia ya descargó las fotos en HD (${descargas} ${descargas === 1 ? 'vez' : 'veces'}): si cambiás, se queda con la anterior y la nueva.` });
    }

    const anterior = pedido.fotos_seleccionadas && typeof pedido.fotos_seleccionadas === 'object' ? pedido.fotos_seleccionadas : {};
    const otrasIds: string[] = Array.isArray(anterior.otrasIds) ? anterior.otrasIds : [];
    const pedidas = req.body?.fotos && typeof req.body.fotos === 'object' ? req.body.fotos : {};
    const validacion = await validarSeleccionFotos(supabase, pedido.colegio_id, pedido.curso_codigo, { ...pedidas, otrasIds }, '', [pedido.alumno_nombre]);
    if (!validacion.ok) return res.status(400).json({ success: false, error: (validacion as { error: string }).error });
    const nueva: Record<string, unknown> = { ...validacion.seleccion };
    if (!Array.isArray(anterior.otrasIds)) delete nueva.otrasIds; // misma forma que tenía (las reservas no llevan sueltas)
    const igual = ['individualId', 'grupalId', 'docenteId'].every((k) => String(anterior[k] || '') === String(nueva[k] || ''))
      && JSON.stringify([...(anterior.sinFoto || [])].sort()) === JSON.stringify([...((nueva.sinFoto as string[]) || [])].sort());
    if (igual) return res.status(400).json({ success: false, error: 'Elegiste las mismas fotos que ya tenía el pedido.' });

    const { data: filas, error: errUpdate } = await supabase
      .from('pedidos')
      .update(soloImpresa ? { fotos_seleccionadas: nueva, updated_at: new Date().toISOString() } : { fotos_seleccionadas: nueva, email_enviado: false, fecha_envio_email: null, updated_at: new Date().toISOString() })
      .eq('id', pedido.id)
      .is('lote_lab_id', null)
      .is('estado_lab', null)
      .eq('seleccion_pendiente', false)
      .select('*, familias(nombre, email)');
    if (errUpdate) throw errUpdate;
    const actualizado = (filas || [])[0];
    if (!actualizado) return res.status(409).json({ success: false, error: 'El pedido cambió mientras tanto (¿entró al laboratorio?). Recargá y revisá.' });
    console.log(`[Cambiar fotos${soloImpresa ? ' (sólo impresa)' : ''}] Pedido ${pedido.pedido_friendly_id}: ${JSON.stringify(anterior)} → ${JSON.stringify(nueva)}`);
    if (soloImpresa) return res.json({ success: true, soloImpresa: true, zipListo: false, mailEnviado: false });

    // .zip nuevo (mismo archivo del pedido, se pisa) y mail con la descarga. Clave propia por selección: la del pago
    // (`fotos-hd-<id>`) haría que Resend descarte este mail si se manda dentro de las 24 h.
    const emailDestino = actualizado.familias?.email;
    const link = await armarZipHDConTurno(supabase, actualizado);
    let mailEnviado = false;
    if (emailDestino && String(emailDestino).includes('@')) {
      const envio = await enviarCorreoFotosHD({
        to: emailDestino,
        tutorNombre: actualizado.familias?.nombre || 'Familia',
        alumnoNombre: actualizado.alumno_nombre || 'tu hijo/a',
        colegioNombre: actualizado.colegio_nombre || 'tu colegio',
        cursoCodigo: actualizado.curso_codigo || undefined,
        kitNombre: actualizado.kit_nombre || undefined,
        pedidoId: actualizado.pedido_friendly_id || actualizado.id,
        total: Number(actualizado.total) || 0,
        linkDescargaHD: link || undefined,
        pedidoUuid: actualizado.id,
        idempotencyKey: `fotos-hd-cambio-${actualizado.id}-${crypto.createHash('sha256').update(JSON.stringify(nueva)).digest('hex').slice(0, 16)}`,
      });
      mailEnviado = envio?.success === true;
      await registrarEnvioCorreoHD(supabase, actualizado.id, link, mailEnviado);
    }
    return res.json({ success: true, zipListo: Boolean(link), mailEnviado });
  } catch (err: any) {
    console.error('[Cambiar fotos] Error:', err);
    return res.status(500).json({ success: false, error: 'No se pudieron cambiar las fotos. Intentá de nuevo.' });
  }
});

export { rutas as rutasCambiarFotosPedido };
