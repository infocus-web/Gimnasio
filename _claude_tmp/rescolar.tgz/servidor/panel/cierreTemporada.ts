// "Cerrar año": resumen y ejecución del cierre de temporada de un colegio (división de server.ts,
// etapa 4, 10/10/2026). El código es el mismo que estaba en la sección "4C. CIERRE DE TEMPORADA" de
// server.ts: sólo se movió de lugar.
import express from 'express';
import type { Request, Response } from 'express';
import { requireAdminAuth } from '../nucleo/auth.js';
import { getServerSupabase } from '../nucleo/clientes.js';
import { invalidarCacheCodigosSeccion } from '../nucleo/codigosCurso.js';
import { enLotes, traerTodasLasFilas } from '../nucleo/utilidades.js';
import { borrarRostrosDelColegio } from '../familias/buscadorRostro.js';
import { faltaTablaAvisos } from './avisosFotos.js';

import { rutaCopiaLupa } from '../../lupa/recorte.js';
const rutas = express.Router();

// ==============================================================================
// 4C. CIERRE DE TEMPORADA ("Cerrar año") — 2026-09-09
// ==============================================================================
// Antes de esto, el único botón de limpieza ("Limpiar Supabase", en la pestaña de carga de
// fotos) sólo vaciaba los buckets de storage y la tabla `fotos`. Nunca tocaba `alumnos`,
// `familias`, `pedidos`, `pedido_fotos`, `inscripciones`, `padres_autorizados`,
// `codigos_seccion` ni `solicitudes_codigo` — así que no había forma real de arrancar una
// temporada nueva sin dejar pegados los alumnos/pedidos/inscripciones del año anterior.
//
// Este cierre de año SIEMPRE conserva la tabla `colegios` (el colegio en sí no se borra,
// sólo los datos de LA TEMPORADA de ese colegio: alumnos, familias, pedidos, fotos,
// inscripciones, códigos). Se puede aplicar a un colegio puntual, o mandar colegioId="todos"
// para vaciar la temporada completa de todos los colegios de una sola vez (útil hoy, que
// sólo hay uno cargado; pensado para cuando haya varios). Es DESTRUCTIVO e IRREVERSIBLE:
//   1. GET /resumen nunca borra nada — sólo cuenta cuántas filas se verían afectadas, para
//      que el panel se lo muestre al fotógrafo antes de que decida.
//   2. POST /ejecutar exige una frase de confirmación exacta (el nombre real del colegio,
//      verificado del lado del servidor, nunca lo que mande el navegador) — así un clic
//      accidental o un bug del cliente nunca puede disparar el borrado solo.

async function idsDeColegioParaCierre(
  supabase: NonNullable<ReturnType<typeof getServerSupabase>>,
  colegioId: string
) {
  const todos = colegioId === 'todos';

  // Auditoría 2026-09-22 (bug real encontrado en auditoría de código, ALTO): antes esto filtraba
  // `familias.eq('colegio_id', colegioId)`, pero familias.colegio_id es la columna uuid del
  // modelo VIEJO (referencia a la tabla "colegios") que /api/pedidos/crear deliberadamente NUNCA
  // completa al crear una familia real (ver el comentario ahí: ese valor es texto/slug en el
  // resto de la app, no un uuid, y escribirlo rompería el INSERT). Como resultado, esa condición
  // no matcheaba NINGUNA fila real — "resumen" mostraba siempre "familias: 0" y "ejecutar" jamás
  // borraba nombre/whatsapp/email de esas familias, que quedaban huérfanas para siempre pese a
  // que el cierre de año promete limpiar los datos de la temporada. Ahora las familias del
  // colegio se derivan de sus alumnos (alumnos.familia_id) y de sus pedidos (pedidos.familia_id),
  // que son las dos relaciones reales que sí se completan siempre.
  //
  // Auditoría 2026-09-23 (bug real, ALTO): todas estas consultas iban sin paginar (PostgREST
  // corta en 1000 filas: un colegio con 1314 alumnos dejaba 314 sin borrar y el "resumen" mostraba
  // números falsos) y armaban filtros `alumno_id.in.(<todos los ids>)` dentro de la URL — con
  // cientos de UUIDs la URL supera el límite del servidor y la consulta falla entera. Ahora se
  // pagina y los filtros por lista de ids se parten en lotes chicos.
  const alumnos = await traerTodasLasFilas<{ id: string; familia_id: string | null }>((desde, hasta) => {
    const q = supabase.from('alumnos').select('id, familia_id').order('id');
    return (todos ? q : q.eq('colegio_id', colegioId)).range(desde, hasta);
  });
  const alumnoIds: string[] = alumnos.map((a) => a.id);

  // Filas de `tabla` del colegio (por colegio_id) + las ligadas a sus alumnos (por alumno_id),
  // sin repetir.
  const traerPorColegioOAlumnos = async <T extends { id: string }>(tabla: string, columnas: string): Promise<T[]> => {
    const porId = new Map<string, T>();
    const agregar = (filas: T[]) => filas.forEach((f) => porId.set(f.id, f));
    agregar(await traerTodasLasFilas<T>((desde, hasta) => {
      const q = supabase.from(tabla).select(columnas).order('id');
      return (todos ? q : q.eq('colegio_id', colegioId)).range(desde, hasta);
    }));
    if (!todos) {
      for (const lote of enLotes(alumnoIds)) {
        agregar(await traerTodasLasFilas<T>((desde, hasta) =>
          supabase.from(tabla).select(columnas).in('alumno_id', lote).order('id').range(desde, hasta)
        ));
      }
    }
    return Array.from(porId.values());
  };

  const fotos = await traerPorColegioOAlumnos<{ id: string; storage_path: string | null; thumb_path: string | null; preview_path: string | null }>(
    'fotos',
    'id, storage_path, thumb_path, preview_path'
  );

  // Auditoría 2026-09-19 (bug real encontrado en auditoría de código, MEDIO): esto filtraba
  // sólo por familia_id/alumno_id, pero esas dos columnas del pedido casi nunca se completan;
  // en cambio "pedidos.colegio_id" SÍ se guarda siempre desde que se creó el pedido (ver
  // /api/pedidos/crear) — por eso se filtra también por colegio_id.
  const pedidosDelColegio = await traerPorColegioOAlumnos<PedidoParaCierre>('pedidos', COLUMNAS_PEDIDO_CIERRE);

  const familiaIdsSet = new Set<string>();
  for (const a of alumnos) {
    if (a.familia_id) familiaIdsSet.add(a.familia_id);
  }
  for (const p of pedidosDelColegio) {
    if (p.familia_id) familiaIdsSet.add(p.familia_id);
  }

  // Auditoría 03/10 (alto 21): una familia puede tener hijos/pedidos en OTRO colegio (hermanos en
  // dos escuelas). Antes se borraba igual y el otro colegio perdía nombre, email y WhatsApp de esa
  // familia. Se excluye toda familia que tenga un alumno o un pedido fuera de este cierre.
  if (!todos && familiaIdsSet.size > 0) {
    const alumnosPropios = new Set(alumnoIds);
    const pedidosPropios = new Set(pedidosDelColegio.map((p) => p.id));
    for (const lote of enLotes(Array.from(familiaIdsSet))) {
      const alumnosDeEsas = await traerTodasLasFilas<{ id: string; familia_id: string }>((desde, hasta) =>
        supabase.from('alumnos').select('id, familia_id').in('familia_id', lote).order('id').range(desde, hasta)
      );
      for (const a of alumnosDeEsas) if (!alumnosPropios.has(a.id)) familiaIdsSet.delete(a.familia_id);
      const pedidosDeEsas = await traerTodasLasFilas<{ id: string; familia_id: string }>((desde, hasta) =>
        supabase.from('pedidos').select('id, familia_id').in('familia_id', lote).order('id').range(desde, hasta)
      );
      for (const p of pedidosDeEsas) if (!pedidosPropios.has(p.id)) familiaIdsSet.delete(p.familia_id);
    }
  }
  const familiaIds: string[] = Array.from(familiaIdsSet);

  return { familiaIds, alumnoIds, fotos, pedidos: pedidosDelColegio, pedidoIds: pedidosDelColegio.map((p) => p.id) };
}

// Auditoría 03/10 (alto 21): datos de cada pedido que necesita el cierre para decidir.
const COLUMNAS_PEDIDO_CIERRE =
  'id, familia_id, alumno_id, pedido_friendly_id, alumno_nombre, estado, tipo_kit, estado_lab, link_descarga_hd, seleccion_pendiente, archivado, cancelado_definitivo, mejora_de_pedido_id, extras_de_pedido_id, created_at, updated_at, transferencia_desde, transferencia_vencida_at, comprobante_path';
interface PedidoParaCierre {
  id: string;
  familia_id: string | null;
  alumno_id: string | null;
  pedido_friendly_id: string | null;
  alumno_nombre: string | null;
  estado: string | null;
  tipo_kit: string | null;
  estado_lab: string | null;
  link_descarga_hd: string | null;
  seleccion_pendiente: boolean | null;
  archivado: boolean | null;
  cancelado_definitivo: boolean | null;
  mejora_de_pedido_id?: string | null;
  extras_de_pedido_id?: string | null;
  created_at: string | null;
  updated_at: string | null;
  transferencia_desde: string | null;
  transferencia_vencida_at?: string | null;
  comprobante_path?: string | null;
}

/**
 * Auditoría 03/10 (alto 21): el cierre de temporada borraba sin mirar nada: pedidos pagados que
 * todavía no se imprimieron/entregaron, pedidos pendientes con un link de pago vivo (la familia
 * podía pagar algo que ya no existía) y los datos de LIQUIDACIÓN al colegio (los pedidos cobrados,
 * con su comisión real; la complementaria se liquida al 30/6 del año siguiente).
 * - `pagadosSinEntregar` y `pendientesRecientes` frenan el cierre salvo `forzar: true`.
 * - `preservar`: los pedidos COBRADOS no se borran nunca (son la base de la liquidación); quedan
 *   archivados y desvinculados de la familia y del alumno (que sí se borran).
 */
function analizarPedidosParaCierre(pedidos: PedidoParaCierre[], ahora = Date.now()) {
  const cobrado = (p: PedidoParaCierre) => p.estado === 'pagado' || p.estado === 'entregado';
  const preservar = pedidos.filter(cobrado);
  const aBorrar = pedidos.filter((p) => !cobrado(p));
  const pagadosSinEntregar = preservar.filter((p) => {
    if (p.archivado || p.cancelado_definitivo || p.estado === 'entregado') return false;
    if (p.seleccion_pendiente) return true; // pagó por adelantado y todavía no eligió fotos
    // Auditoría 05/10: una mejora a Kit Impreso no lleva .zip propio (el HD es del pedido original).
    if (p.mejora_de_pedido_id || p.extras_de_pedido_id || p.tipo_kit === 'fotos_extra') return p.estado_lab !== 'entregado'; // 29/10: fotos extra, igual
    // Kit Impreso + Digital: retirado Y con su descarga HD; sin el .zip la familia pierde el HD al cerrar.
    if (p.tipo_kit === 'impreso_digital') return p.estado_lab !== 'entregado' || !p.link_descarga_hd;
    return !p.link_descarga_hd; // kit digital sin el link HD
  });
  const hace48h = ahora - 48 * 60 * 60 * 1000;
  const pendientesRecientes = aBorrar.filter((p) => {
    if (p.cancelado_definitivo) return false;
    // Auditoría 11/10: una transferencia vencida en la última semana es recuperable («Reabrir plazo»): la
    // familia puede haber transferido sin subir el comprobante.
    if (p.estado === 'cancelado' && p.transferencia_vencida_at) return (Date.parse(p.transferencia_vencida_at) || 0) > ahora - 7 * 24 * 60 * 60 * 1000;
    if (p.estado !== 'pendiente_pago') return false;
    const ultima = Math.max(...[p.created_at, p.updated_at, p.transferencia_desde].map((v) => (v ? Date.parse(v) || 0 : 0)));
    return ultima > hace48h;
  });
  return { preservar, aBorrar, pagadosSinEntregar, pendientesRecientes };
}

function describirPedidosCierre(lista: PedidoParaCierre[]): string {
  return lista.slice(0, 5).map((p) => `${p.pedido_friendly_id || p.id.slice(0, 8)} ${p.alumno_nombre || ''}`.trim()).join(', ') + (lista.length > 5 ? '…' : '');
}

// Ids de pedido_fotos ligados a esos pedidos o fotos (sin repetir), consultando en lotes.
async function idsPedidoFotosDe(
  supabase: NonNullable<ReturnType<typeof getServerSupabase>>,
  pedidoIds: string[],
  fotoIds: string[]
): Promise<string[]> {
  const ids = new Set<string>();
  for (const [columna, lista] of [['pedido_id', pedidoIds], ['foto_id', fotoIds]] as const) {
    for (const lote of enLotes(lista)) {
      const filas = await traerTodasLasFilas<{ id: string }>((desde, hasta) =>
        supabase.from('pedido_fotos').select('id').in(columna, lote).order('id').range(desde, hasta)
      );
      filas.forEach((f) => ids.add(f.id));
    }
  }
  return Array.from(ids);
}

// Auditoría 11/10: borra del bucket privado 'comprobantes' los comprobantes de transferencia que ya no
// usa NINGÚN pedido (un carrito comparte el mismo archivo entre hermanos). Llamar DESPUÉS de borrar los
// pedidos. Si no se puede verificar, no borra nada. Devuelve un aviso o null.
export async function borrarComprobantesSinUso(supabase: NonNullable<ReturnType<typeof getServerSupabase>>, rutas: (string | null | undefined)[]): Promise<string | null> {
  const candidatas = Array.from(new Set(rutas.filter((r): r is string => typeof r === 'string' && r.trim() !== '')));
  for (const lote of enLotes(candidatas)) {
    const { data, error } = await supabase.from('pedidos').select('comprobante_path').in('comprobante_path', lote);
    if (error) return `comprobantes: no se pudo verificar su uso (${error.message})`;
    const enUso = new Set((data || []).map((f: any) => f.comprobante_path));
    const libres = lote.filter((r) => !enUso.has(r));
    if (libres.length === 0) continue;
    const { error: errRemove } = await supabase.storage.from('comprobantes').remove(libres);
    if (errRemove) return `comprobantes: ${errRemove.message}`;
  }
  return null;
}

// Las miniaturas/vistas ampliadas (thumb_path/preview_path) se guardan como URL pública
// completa (bucket 'fotos-web'); storage_path (HD) se guarda como ruta relativa dentro de
// 'fotos-hd'. Esto extrae la ruta relativa real dentro del bucket para poder borrar el
// archivo físico, sea cual sea el formato en el que haya quedado guardado.
function extraerPathStorageParaCierre(valor: string | null, bucket: string): string | null {
  if (!valor) return null;
  const marcador = `/object/public/${bucket}/`;
  const idx = valor.indexOf(marcador);
  // Las URLs guardadas llevan "?v=<timestamp>" al final (anti-caché, ver subida de fotos): hay que
  // sacarlo, si no Storage busca un archivo con ese nombre literal y el borrado no hace nada.
  const sinQuery = (ruta: string) => ruta.split('?')[0];
  if (idx >= 0) return sinQuery(valor.substring(idx + marcador.length));
  return valor.startsWith('http') ? null : sinQuery(valor);
}

rutas.get('/api/admin/cerrar-anio/resumen', requireAdminAuth, async (req: Request, res: Response) => {
  try {
    const supabase = getServerSupabase();
    if (!supabase) {
      return res.status(500).json({ success: false, error: 'Supabase no configurado en el servidor' });
    }
    const colegioId = (req.query.colegioId as string) || '';
    if (!colegioId) {
      return res.status(400).json({ success: false, error: 'Falta colegioId (o "todos")' });
    }

    let nombreColegio = 'Todos los colegios';
    if (colegioId !== 'todos') {
      const { data: colegio, error: errC } = await supabase
        .from('colegios')
        .select('nombre')
        .eq('id', colegioId)
        .single();
      if (errC || !colegio) {
        return res.status(404).json({ success: false, error: 'Colegio no encontrado' });
      }
      nombreColegio = colegio.nombre;
    }

    const { familiaIds, alumnoIds, fotos, pedidos, pedidoIds } = await idsDeColegioParaCierre(supabase, colegioId);
    const analisis = analizarPedidosParaCierre(pedidos);

    const contarPorColegio = async (tabla: string) => {
      let q = supabase.from(tabla).select('id', { count: 'exact', head: true });
      if (colegioId !== 'todos') q = q.eq('colegio_id', colegioId);
      const { count, error } = await q;
      if (error) throw error;
      return count || 0;
    };

    const [inscripciones, padresAutorizados, codigosSeccion, solicitudesCodigo] = await Promise.all([
      contarPorColegio('inscripciones'),
      contarPorColegio('padres_autorizados'),
      contarPorColegio('codigos_seccion'),
      contarPorColegio('solicitudes_codigo'),
    ]);

    const pedidoFotos = (await idsPedidoFotosDe(supabase, pedidoIds, fotos.map((f) => f.id))).length;

    return res.json({
      success: true,
      colegioNombre: nombreColegio,
      resumen: {
        familias: familiaIds.length,
        alumnos: alumnoIds.length,
        fotos: fotos.length,
        // Auditoría 03/10: `pedidos` = los que se borran; los cobrados se conservan (liquidación).
        pedidos: analisis.aBorrar.length,
        pedidosPreservados: analisis.preservar.length,
        pedidoFotos,
        inscripciones,
        padresAutorizados,
        codigosSeccion,
        solicitudesCodigo,
      },
      bloqueos: {
        pagadosSinEntregar: analisis.pagadosSinEntregar.length,
        pendientesRecientes: analisis.pendientesRecientes.length,
      },
    });
  } catch (err: any) {
    console.error('Error al armar el resumen de cierre de año:', err);
    return res.status(500).json({ success: false, error: err?.message || 'Error al armar el resumen' });
  }
});

rutas.post('/api/admin/cerrar-anio/ejecutar', requireAdminAuth, async (req: Request, res: Response) => {
  // Declarado fuera del try/catch para que el catch de abajo pueda seguir leyéndolo (una
  // variable `let`/`const` declarada DENTRO de un bloque try no es visible en su catch).
  let pasoActual = 'validación';
  try {
    const supabase = getServerSupabase();
    if (!supabase) {
      return res.status(500).json({ success: false, error: 'Supabase no configurado en el servidor' });
    }
    const { colegioId, confirmacion } = req.body || {};
    const forzar = req.body?.forzar === true;
    if (!colegioId || typeof colegioId !== 'string') {
      return res.status(400).json({ success: false, error: 'Falta colegioId (o "todos")' });
    }
    if (typeof confirmacion !== 'string' || !confirmacion.trim()) {
      return res.status(400).json({ success: false, error: 'Falta la frase de confirmación' });
    }

    const normalizar = (s: string) => s.trim().toLowerCase().replace(/\s+/g, ' ');

    let fraseEsperada: string;
    if (colegioId === 'todos') {
      fraseEsperada = 'cerrar todos los colegios';
    } else {
      const { data: colegio, error: errC } = await supabase
        .from('colegios')
        .select('nombre')
        .eq('id', colegioId)
        .single();
      if (errC || !colegio) {
        return res.status(404).json({ success: false, error: 'Colegio no encontrado' });
      }
      fraseEsperada = `cerrar ${colegio.nombre}`;
    }

    if (normalizar(confirmacion) !== normalizar(fraseEsperada)) {
      return res.status(400).json({
        success: false,
        error: `La frase de confirmación no coincide. Tenés que escribir exactamente: "${fraseEsperada.toUpperCase()}"`,
      });
    }

    const { familiaIds: familiasCandidatas, alumnoIds: alumnosCandidatos, fotos, pedidos } = await idsDeColegioParaCierre(supabase, colegioId);
    const fotoIds = fotos.map((f) => f.id);

    // Auditoría 03/10 (alto 21): controles previos (ver analizarPedidosParaCierre).
    const analisis = analizarPedidosParaCierre(pedidos);
    if (!forzar && (analisis.pagadosSinEntregar.length > 0 || analisis.pendientesRecientes.length > 0)) {
      const partes: string[] = [];
      if (analisis.pagadosSinEntregar.length > 0) partes.push(`${analisis.pagadosSinEntregar.length} pedido(s) PAGADO(S) todavía sin imprimir/entregar (${describirPedidosCierre(analisis.pagadosSinEntregar)})`);
      if (analisis.pendientesRecientes.length > 0) partes.push(`${analisis.pendientesRecientes.length} pedido(s) pendiente(s) de pago con movimiento en las últimas 48 h o transferencia(s) vencida(s) esta semana (la familia todavía puede estar pagando: ${describirPedidosCierre(analisis.pendientesRecientes)})`);
      return res.status(409).json({
        success: false,
        requiereForzar: true,
        bloqueos: { pagadosSinEntregar: analisis.pagadosSinEntregar.length, pendientesRecientes: analisis.pendientesRecientes.length },
        error: `No se cerró la temporada: hay ${partes.join(' y ')}. Resolvelos primero o confirmá el cierre forzado.`,
      });
    }
    const pedidoIds = analisis.aBorrar.map((p) => p.id);

    // Los pedidos cobrados se conservan (liquidación al colegio): quedan archivados y se los
    // desvincula de la familia y del alumno ANTES de borrar esas filas (si la base tuviera borrado en
    // cascada, se llevaría estos pedidos). Si no se puede desvincular, esa familia/alumno no se borra.
    const familiaIdsSet = new Set(familiasCandidatas);
    const alumnoIdsSet = new Set(alumnosCandidatos);
    pasoActual = 'preservar pedidos cobrados';
    for (const lote of enLotes(analisis.preservar.map((p) => p.id))) {
      const { error: errArch } = await supabase.from('pedidos').update({ archivado: true }).in('id', lote);
      if (errArch) throw errArch;
      const { error: errDesv } = await supabase.from('pedidos').update({ familia_id: null, alumno_id: null }).in('id', lote);
      if (errDesv) {
        console.warn('[Cerrar año] No se pudieron desvincular pedidos cobrados; se conservan su familia y alumno:', errDesv.message);
        for (const p of analisis.preservar.filter((x) => lote.includes(x.id))) {
          if (p.familia_id) familiaIdsSet.delete(p.familia_id);
          if (p.alumno_id) alumnoIdsSet.delete(p.alumno_id);
        }
      }
    }
    const familiaIds = Array.from(familiaIdsSet);
    const alumnoIds = Array.from(alumnoIdsSet);

    // Auditoría 2026-09-22 (posible bug de integridad, BAJO): esta operación borra en varios
    // pasos secuenciales SIN transacción (Supabase/PostgREST no expone transacciones multi-tabla
    // desde acá sin escribir una función RPC en la base, que es un cambio de esquema que no se
    // aplica solo desde este archivo). Si un paso intermedio falla (timeout, error puntual), el
    // cierre de año queda a medio hacer sin forma de saber en cuál. Mitigación barata: se guarda
    // en qué paso se está y se lo suma al mensaje de error, para que quede claro qué se alcanzó a
    // borrar y qué no si algo se corta a mitad de camino.
    pasoActual = 'pedido_fotos';

    // Borra por lista de ids en lotes (ver enLotes: la lista viaja en la URL).
    const borrarPorIds = async (tabla: string, columna: string, ids: string[]) => {
      for (const lote of enLotes(ids)) {
        const { error } = await supabase.from(tabla).delete().in(columna, lote);
        if (error) throw error;
      }
    };

    // 1) pedido_fotos (depende de pedidos y fotos)
    await borrarPorIds('pedido_fotos', 'pedido_id', pedidoIds);
    await borrarPorIds('pedido_fotos', 'foto_id', fotoIds);

    // 2) pedidos
    pasoActual = 'pedidos';
    await borrarPorIds('pedidos', 'id', pedidoIds);
    // Auditoría 11/10: los comprobantes de transferencia de los pedidos borrados (datos bancarios).
    const avisoComprobantes = await borrarComprobantesSinUso(supabase, analisis.aBorrar.map((p) => p.comprobante_path));

    // 3) fotos (Auditoría 03/10: ANTES de borrar los archivos; si el cierre se cortaba entre un paso
    // y otro quedaban fotos en el catálogo apuntando a archivos ya borrados).
    pasoActual = 'fotos';
    await borrarPorIds('fotos', 'id', fotoIds);

    // 4) archivos físicos en storage de las fotos ya borradas. Best-effort: si el
    // borrado físico falla no frenamos el cierre de año (los registros igual se limpian);
    // los errores quedan listados en la respuesta para que se puedan revisar a mano
    // (o los levanta "Limpiar huérfanos").
    pasoActual = 'archivos de fotos';
    const erroresStorage: string[] = avisoComprobantes ? [avisoComprobantes] : [];
    // 09/10: con cada original va también la copia de la lupa guardada al lado.
    const rutasHD = fotos.flatMap((f) => (f.storage_path ? [f.storage_path, rutaCopiaLupa(f.storage_path)] : []));
    const rutasWeb = fotos
      .flatMap((f) => [
        extraerPathStorageParaCierre(f.thumb_path, 'fotos-web'),
        extraerPathStorageParaCierre(f.preview_path, 'fotos-web'),
      ])
      .filter((p): p is string => !!p);
    for (const [bucket, rutas] of [
      ['fotos-hd', rutasHD],
      ['fotos-web', rutasWeb],
    ] as const) {
      for (let i = 0; i < rutas.length; i += 200) {
        const lote = rutas.slice(i, i + 200);
        if (lote.length === 0) continue;
        const { error } = await supabase.storage.from(bucket).remove(lote);
        if (error) erroresStorage.push(`${bucket}: ${error.message}`);
      }
    }

    // 4b) 24/10: buscador por reconocimiento facial: caras en AWS + tablas rostros_* (las copias ya se borraron con las fotos).
    pasoActual = 'reconocimiento facial';
    const avisoRostros = await borrarRostrosDelColegio(supabase, colegioId);
    if (avisoRostros) erroresStorage.push(avisoRostros);

    // 5) alumnos
    pasoActual = 'alumnos';
    await borrarPorIds('alumnos', 'id', alumnoIds);

    // 6) familias
    pasoActual = 'familias';
    await borrarPorIds('familias', 'id', familiaIds);

    // 7-11) el resto de las tablas de temporada, scopeadas por colegio (o todas si es "todos").
    // Igual que en /api/admin/fotos (DELETE), .not('id','is',null) es el filtro "matchea todo"
    // que exige el cliente de Supabase para no permitir un delete() totalmente sin condición.
    const borrarPorColegio = async (tabla: string) => {
      pasoActual = tabla;
      const q = supabase.from(tabla).delete();
      const { error } = colegioId === 'todos' ? await q.not('id', 'is', null) : await q.eq('colegio_id', colegioId);
      if (error) throw error;
    };
    await borrarPorColegio('eventos');
    await borrarPorColegio('inscripciones');
    await borrarPorColegio('padres_autorizados');
    await borrarPorColegio('codigos_seccion');
    invalidarCacheCodigosSeccion();
    await borrarPorColegio('solicitudes_codigo');
    // 25/10: avisos «ya están tus fotos» (por curso y por familia). Si quedaban, el año siguiente los cursos con el
    // mismo código (GRADO1-ATM…) figuraban como ya avisados y «Publicar» no les mandaba el aviso. No tienen columna id.
    for (const tabla of ['avisos_fotos_destinatarios', 'avisos_fotos_curso']) {
      pasoActual = tabla;
      const q = supabase.from(tabla).delete();
      const { error } = colegioId === 'todos' ? await q.not('colegio_id', 'is', null) : await q.eq('colegio_id', colegioId);
      if (error && !faltaTablaAvisos(error)) throw error;
    }

    return res.json({
      success: true,
      borrados: {
        familias: familiaIds.length,
        alumnos: alumnoIds.length,
        fotos: fotoIds.length,
        pedidos: pedidoIds.length,
      },
      pedidosPreservados: analisis.preservar.length,
      erroresStorage: erroresStorage.length > 0 ? erroresStorage : undefined,
    });
  } catch (err: any) {
    console.error(`Error al ejecutar el cierre de año (paso: ${pasoActual}):`, err);
    return res.status(500).json({
      success: false,
      error: `${err?.message || 'Error al cerrar el año'} (se cortó en el paso "${pasoActual}" — revisá qué se alcanzó a borrar antes de reintentar)`,
    });
  }
});

export { rutas as rutasCierreTemporada };
