// Fotos de los colegios desde el panel: registro de las subidas (SIN PUBLICAR), «Publicar», muestras
// y miniaturas, listados, originales, borrado, y el storage (URLs firmadas de subida, borrado,
// limpieza de buckets y de huérfanos) (división de server.ts, etapa 4, 10/10/2026). El código es el
// mismo que estaba en las secciones de fotos y "4B. STORAGE DE FOTOS" de server.ts: sólo se movió.
import type { SupabaseClient } from '@supabase/supabase-js';
import express from 'express';
import type { Request, Response } from 'express';
import sharp from 'sharp';
import type { SeccionFotosDisponible } from '../entrega/correos.js';
import { nombreZipHDPedido } from '../entrega/zipHD.js';
import { requireAdminAuth } from '../nucleo/auth.js';
import { registrarAlertaPago } from '../nucleo/alertas.js';
import { getServerSupabase } from '../nucleo/clientes.js';
import { determinarCodigoCursoServidor } from '../nucleo/codigosCurso.js';
import { buscarColegioReal } from '../nucleo/colegios.js';
import { enLotes, traerTodasLasFilas } from '../nucleo/utilidades.js';
import { avisarCursosPublicados } from './avisosFotos.js';

import { generarMuestraConMarca, LADO_MUESTRA } from '../../lupa/muestra.js';
import { rutaCopiaLupa } from '../../lupa/recorte.js';
const rutas = express.Router();

// Registrar en Supabase las fotos que el admin ya subió a Storage (queda visible al instante para las familias)
rutas.post('/api/admin/fotos', requireAdminAuth, async (req: Request, res: Response) => {
  try {
    // `subidaDesde`: marca de comienzo de ESTA subida (la devuelve la primera tanda); con ella un curso cuenta
    // como «galería nueva» si no tenía fotos antes. 06/10: las fotos se registran SIN PUBLICAR y el aviso a las
    // familias sale al publicarlas (POST /api/admin/fotos/publicar); `avisar` se acepta por compatibilidad pero
    // ya no manda nada. 14/10: el panel registra cada foto apenas sube (antes, de a 40).
    const { fotos, subidaDesde } = req.body || {};
    const marcaRecibida = typeof subidaDesde === 'string' ? Date.parse(subidaDesde) : NaN;
    const desdeSubida = Number.isFinite(marcaRecibida) && marcaRecibida <= Date.now() + 5 * 60 * 1000 && Date.now() - marcaRecibida < 7 * 24 * 60 * 60 * 1000
      ? new Date(marcaRecibida).toISOString()
      : null;
    if (!Array.isArray(fotos) || fotos.length === 0) {
      return res.status(400).json({ success: false, error: 'No se recibieron fotos para registrar' });
    }
    if (fotos.length > 500) {
      return res.status(400).json({ success: false, error: 'Demasiadas fotos en un solo lote (máximo 500)' });
    }

    const supabase = getServerSupabase();
    if (!supabase) {
      return res.status(500).json({ success: false, error: 'Supabase no configurado en el servidor' });
    }

    const filas = fotos
      .map((f: any) => {
        const grado = String(f.grado || '').trim();
        const turno = String(f.turno || '').trim();
        const division = String(f.division || '').trim();
        return {
          colegio_id: f.colegioId ? String(f.colegioId) : null,
          categoria: f.categoria,
          grado: grado || null,
          turno: turno || null,
          division: division || null,
          codigo_curso: grado && turno ? determinarCodigoCursoServidor(grado, turno, division) : null,
          storage_path: f.storagePathHD || '',
          // thumb_path: miniatura chica y sin marca de agua (grilla de la galería).
          // preview_path: copia con la marca de agua quemada en los píxeles (vista ampliada).
          thumb_path: f.storagePathThumb || f.storagePathWeb || null,
          preview_path: f.storagePathWeb || null,
          alumno_nombre: f.alumnoNombre || null,
          publicada_at: null, // 06/10: sin publicar hasta que Pablo toque «Publicar» en el panel.
          // 14/10: archivo original (nombre + tamaño), así el panel no vuelve a subir los que ya están.
          nombre_original: typeof f.nombreOriginal === 'string' && f.nombreOriginal.trim() ? f.nombreOriginal.trim().slice(0, 255) : null,
          bytes_original: Number.isSafeInteger(f.bytesOriginal) && f.bytesOriginal > 0 ? f.bytesOriginal : null,
        };
      })
      // Auditoría 30/9: las rutas tienen que ser de fotos (carpeta por año); si no, borrar la foto
      // desde el panel podía borrar otro archivo del bucket (por ejemplo, el .zip de un pedido pago).
      // 2/10 (bug real: ninguna foto se podía registrar): la muestra y la miniatura llegan como URL
      // pública completa (".../object/public/fotos-web/2026/...?v=..."), no como ruta; se valida la
      // ruta dentro del bucket y se guarda la URL como siempre.
      .filter((f: any) => {
        const rutaWeb = (v: string | null) => !v || rutaPermitidaParaPanel(rutaEnBucketDesdeUrl(v, 'fotos-web') || '');
        return f.storage_path && f.categoria && f.codigo_curso && rutaPermitidaParaPanel(f.storage_path) && rutaWeb(f.thumb_path) && rutaWeb(f.preview_path);
      });

    if (filas.length === 0) {
      return res.status(400).json({ success: false, error: 'Ninguna foto tiene los datos mínimos (ruta, categoría, grado y turno)' });
    }

    // Ver buscarColegioReal: una foto guardada con el id del colegio "de relleno" (lista de
    // colegios sin cargar) nunca aparece en la galería de las familias del colegio real.
    for (const colegioIdFoto of new Set(filas.map((f: any) => f.colegio_id))) {
      if (!(await buscarColegioReal(supabase, colegioIdFoto))) {
        return res.status(400).json({ success: false, error: 'El colegio elegido no es válido (la lista de colegios no terminó de cargar). Recargá el panel, elegí el colegio y volvé a intentar — las fotos ya subidas se pueden volver a registrar.' });
      }
    }

    // Auditoría 05/10: si un `storage_path` ya está registrado (reintento del panel, doble click,
    // "volver a registrar"), no se inserta otra fila: dos filas con el mismo archivo hacían que
    // borrar la "duplicada" borrara el HD de la otra. Se descartan acá, sin error, y se informa
    // `yaRegistradas`. 08/10: además la base tiene el índice único fotos_storage_path_unico y el
    // insert ignora los repetidos (dos tandas simultáneas del mismo archivo ya no duplican la fila).
    const yaRegistradasEnBase = new Set<string>();
    for (const grupo of enLotes(Array.from(new Set(filas.map((f: any) => f.storage_path))), 100)) {
      const { data: existentes, error: errorExistentes } = await supabase.from('fotos').select('storage_path').in('storage_path', grupo);
      if (errorExistentes) throw errorExistentes;
      for (const e of existentes || []) if (e.storage_path) yaRegistradasEnBase.add(e.storage_path);
    }
    const { nuevas: filasAInsertar, yaRegistradas } = descartarFotosYaRegistradas(filas, yaRegistradasEnBase);

    const { data, error } = filasAInsertar.length > 0
      ? await supabase.from('fotos').upsert(filasAInsertar, { onConflict: 'storage_path', ignoreDuplicates: true }).select()
      : { data: [] as any[], error: null };
    if (error) throw error;
    // Las que otra tanda registró justo en el medio no vuelven en `data`: también cuentan como ya registradas.
    const ignoradasEnCarrera = Math.max(0, filasAInsertar.length - (data?.length || 0));
    // Marca de comienzo de la subida para las tandas siguientes: la recibida o, en la primera tanda,
    // la hora (de la base) de la foto más vieja recién insertada.
    const creadasAhora = (data || []).map((f: any) => Date.parse(f.created_at || '')).filter(Number.isFinite);
    const marcaSubida = desdeSubida || (creadasAhora.length > 0 ? new Date(Math.min(...creadasAhora)).toISOString() : null);

    return res.json({
      success: true,
      registradas: data?.length || 0,
      yaRegistradas: yaRegistradas + ignoradasEnCarrera,
      marcaSubida,
      emailsEnviados: 0,
      sinPublicar: true,
    });
  } catch (err: any) {
    console.error('Error al registrar fotos:', err);
    return res.status(500).json({ success: false, error: err?.message || 'Error al registrar las fotos' });
  }
});

// 06/10/2026 (pedido de Pablo: «si cargo por error unas fotos, que no se publiquen hasta que lo
// apruebe»): botón «Publicar» del panel. Publica las fotos SIN PUBLICAR de un curso (`colegioId` +
// `codigoCurso`) o las elegidas (`ids`). Manda el aviso «ya están tus fotos» a los cursos que todavía no
// lo tienen confirmado (una sola vez por curso; ver avisosFotos.ts).
rutas.post('/api/admin/fotos/publicar', requireAdminAuth, async (req: Request, res: Response) => {
  try {
    const supabase = getServerSupabase();
    if (!supabase) return res.status(500).json({ success: false, error: 'Supabase no configurado en el servidor' });
    const columnas = 'id, colegio_id, codigo_curso, grado, turno, division, categoria, alumno_nombre';
    const crudos = Array.isArray(req.body?.ids) ? req.body.ids : null;
    let pendientes: any[] = [];
    if (crudos) {
      if (crudos.length > 2000) return res.status(400).json({ success: false, error: 'Máximo 2000 fotos por publicación.' });
      const ids = [...new Set(crudos.filter((v: unknown): v is string => typeof v === 'string' && UUID_FOTO_RE.test(v)))] as string[];
      if (ids.length === 0) return res.status(400).json({ success: false, error: 'No se eligió ninguna foto para publicar.' });
      for (const grupo of enLotes(ids, 150)) {
        const { data, error } = await supabase.from('fotos').select(columnas).in('id', grupo).is('publicada_at', null);
        if (error) throw error;
        pendientes.push(...(data || []));
      }
    } else {
      const colegioId = typeof req.body?.colegioId === 'string' ? req.body.colegioId.trim() : '';
      const codigoCurso = typeof req.body?.codigoCurso === 'string' ? req.body.codigoCurso.trim() : '';
      if (!colegioId || !codigoCurso) return res.status(400).json({ success: false, error: 'Falta el curso a publicar.' });
      pendientes = await traerTodasLasFilas<any>((desde, hasta) =>
        supabase.from('fotos').select(columnas).eq('colegio_id', colegioId).eq('codigo_curso', codigoCurso).is('publicada_at', null).order('id').range(desde, hasta)
      );
    }
    // 11/10 (Pablo, «opción 3»): las individuales sin nombre también se publican (las ve todo el curso; las
    // individuales se suben por curso, no por alumno). Antes (08/10, A3) quedaban afuera.
    if (pendientes.length === 0) return res.json({ success: true, publicadas: 0, emailsEnviados: 0 });

    // Sólo se publican las que siguen sin publicar (dos clics seguidos no las pisan).
    const marca = new Date().toISOString();
    const publicadas = new Set<string>();
    for (const grupo of enLotes(pendientes.map((f: any) => String(f.id)), 150)) {
      const { data, error } = await supabase.from('fotos').update({ publicada_at: marca }).in('id', grupo).is('publicada_at', null).select('id');
      if (error) throw error;
      for (const f of data || []) publicadas.add(String(f.id));
    }

    const secciones = new Map<string, SeccionFotosDisponible>();
    for (const f of pendientes) {
      if (!publicadas.has(String(f.id)) || !f.colegio_id || !f.codigo_curso) continue;
      secciones.set(`${f.colegio_id}|${f.codigo_curso}`, { colegioId: f.colegio_id, codigoCurso: f.codigo_curso, grado: f.grado || '', turno: f.turno || '', division: f.division || '' });
    }
    // 14/10/2026: avisa a los cursos sin el aviso confirmado (avisos_fotos_curso), no a los «sin fotos
    // publicadas»: si el aviso falló, la próxima publicación o «Reenviar aviso» lo vuelve a mandar.
    const { emailsEnviados, warning } = await avisarCursosPublicados(supabase, [...secciones.values()], marca);
    return res.json({ success: true, publicadas: publicadas.size, emailsEnviados, warning });
  } catch (err: any) {
    console.error('[Fotos] Error al publicar:', err);
    return res.status(500).json({ success: false, error: 'No se pudieron publicar las fotos. Intentá de nuevo.' });
  }
});

// Migración: genera la miniatura chica y limpia (sin marca de agua) para fotos que se
// subieron ANTES de que existiera esa miniatura propia (su thumb_path todavía apunta a la
// misma copia con marca de agua que preview_path). Se procesa de a un lote chico por
// llamada para no exceder el tiempo máximo de una función serverless; el panel de admin
// la llama en bucle hasta que "restantes" da 0.
rutas.post('/api/admin/fotos/regenerar-miniaturas', requireAdminAuth, async (req: Request, res: Response) => {
  try {
    const supabase = getServerSupabase();
    if (!supabase) {
      return res.status(500).json({ success: false, error: 'Supabase no configurado en el servidor' });
    }

    const limite = Math.min(Math.max(parseInt(String(req.body?.limite || '12'), 10) || 12, 1), 30);

    // .eq()/.or() de PostgREST no permite comparar dos columnas entre sí, así que se trae
    // el universo de fotos y se filtran en el servidor las que todavía no tienen miniatura propia.
    // Paginado: sin esto sólo se revisaban las primeras 1000 fotos y "restantes" daba 0 aunque
    // quedaran fotos sin miniatura propia más allá de ese tope.
    const todas = await traerTodasLasFilas<any>((desde, hasta) =>
      supabase
        .from('fotos')
        .select('id, storage_path, thumb_path, preview_path')
        .order('created_at', { ascending: true })
        .order('id')
        .range(desde, hasta)
    );

    const candidatas = todas.filter((f: any) => !f.thumb_path || f.thumb_path === f.preview_path);
    const lote = candidatas.slice(0, limite);

    let procesadas = 0;
    let fallidas = 0;

    for (const fila of lote) {
      try {
        const { data: archivo, error: errorDescarga } = await supabase.storage
          .from('fotos-hd')
          .download(fila.storage_path);
        if (errorDescarga || !archivo) throw errorDescarga || new Error('No se pudo descargar el original');

        const buffer = Buffer.from(await archivo.arrayBuffer());
        const miniaturaBuffer = await sharp(buffer)
          .resize(320, 320, { fit: 'inside', withoutEnlargement: true }) // M7 (26/9): 320 px, antes 500
          .jpeg({ quality: 80 })
          .toBuffer();

        const nombreArchivo = fila.storage_path.split('/').pop() || `${fila.id}.jpg`;
        const nombreBase = nombreArchivo.replace(/\.[^./]+$/, '');
        const carpeta = fila.storage_path.replace(/\/originales\/[^/]+$/, '/miniaturas');
        const pathThumb = `${carpeta}/${nombreBase}.jpg`;

        const { error: errorSubida } = await supabase.storage
          .from('fotos-web')
          .upload(pathThumb, miniaturaBuffer, { contentType: 'image/jpeg', upsert: true });
        if (errorSubida) throw errorSubida;

        const { data: urlData } = supabase.storage.from('fotos-web').getPublicUrl(pathThumb);
        // "?v=..." para evitar que el navegador siga mostrando la miniatura vieja cacheada
        // de esta misma URL (el archivo se sube con upsert:true, pisando el anterior).
        const urlConVersion = `${urlData.publicUrl}?v=${Date.now()}`;

        const { error: errorUpdate } = await supabase
          .from('fotos')
          .update({ thumb_path: urlConVersion })
          .eq('id', fila.id);
        if (errorUpdate) throw errorUpdate;

        procesadas++;
      } catch (errFila) {
        console.error(`Error al regenerar miniatura de la foto ${fila.id}:`, errFila);
        fallidas++;
      }
    }

    const restantes = Math.max(candidatas.length - lote.length, 0);
    return res.json({ success: true, procesadas, fallidas, restantes });
  } catch (err: any) {
    console.error('Error al regenerar miniaturas:', err);
    return res.status(500).json({ success: false, error: err?.message || 'Error al regenerar las miniaturas' });
  }
});

// Migración: re-genera la copia "ampliada" (con marca de agua quemada en los píxeles) de
// fotos que ya estaban subidas — a partir del original guardado, sin que el fotógrafo tenga que
// volver a subir nada. Se procesa de a un lote chico por llamada, igual que la migración de
// miniaturas. 04/10: cada foto se rehace con el estilo que tiene elegido su colegio (interruptor
// «Muestras con lupa»): prendido = 800 px, desenfoque "muy suave" y "PASÁ LA LUPA POR LA IMAGEN";
// apagado = la clásica de siempre (1600 px, "MUESTRA · RETRATO ESCOLAR"). El texto va como contornos
// (lupa/muestra.ts), sin depender de tipografías del servidor.
rutas.post('/api/admin/fotos/regenerar-marca-agua', requireAdminAuth, async (req: Request, res: Response) => {
  try {
    const supabase = getServerSupabase();
    if (!supabase) {
      return res.status(500).json({ success: false, error: 'Supabase no configurado en el servidor' });
    }

    const limite = Math.min(Math.max(parseInt(String(req.body?.limite || '8'), 10) || 8, 1), 20);
    const offset = Math.max(parseInt(String(req.body?.offset || '0'), 10) || 0, 0);

    // Paginado (mismo motivo que regenerar-miniaturas): el offset nunca pasaba de la foto 1000.
    const universo = await traerTodasLasFilas<any>((desde, hasta) =>
      supabase
        .from('fotos')
        .select('id, storage_path, colegio_id')
        .order('created_at', { ascending: true })
        .order('id')
        .range(desde, hasta)
    );
    const lote = universo.slice(offset, offset + limite);
    const { data: colegiosLupa, error: errColegios } = await supabase.from('colegios').select('id, muestras_lupa');
    if (errColegios) throw errColegios;
    const conLupa = new Set((colegiosLupa || []).filter((c: any) => c.muestras_lupa === true).map((c: any) => c.id));

    let procesadas = 0;
    let fallidas = 0;

    for (const fila of lote) {
      try {
        const { data: archivo, error: errorDescarga } = await supabase.storage
          .from('fotos-hd')
          .download(fila.storage_path);
        if (errorDescarga || !archivo) throw errorDescarga || new Error('No se pudo descargar el original');

        const ampliadaBuffer = conLupa.has(fila.colegio_id)
          ? await generarMuestraConMarca(Buffer.from(await archivo.arrayBuffer()), LADO_MUESTRA, 80, 'lupa')
          : await generarMuestraConMarca(Buffer.from(await archivo.arrayBuffer()), 1600, 85, 'clasica');

        const nombreArchivo = fila.storage_path.split('/').pop() || `${fila.id}.jpg`;
        const nombreBase = nombreArchivo.replace(/\.[^./]+$/, '');
        const carpeta = fila.storage_path.replace(/\/originales\/[^/]+$/, '/muestras-v2');
        const pathAmpliada = `${carpeta}/${nombreBase}.jpg`;

        const { error: errorSubida } = await supabase.storage
          .from('fotos-web')
          .upload(pathAmpliada, ampliadaBuffer, { contentType: 'image/jpeg', upsert: true });
        if (errorSubida) throw errorSubida;

        const { data: urlData } = supabase.storage.from('fotos-web').getPublicUrl(pathAmpliada);
        // "?v=..." para evitar que el navegador siga mostrando la versión vieja cacheada de
        // esta misma URL (el archivo se sube con upsert:true, pisando el anterior) — esto fue
        // justamente lo que hizo pensar que el arreglo de la marca de agua no se aplicaba.
        const urlConVersion = `${urlData.publicUrl}?v=${Date.now()}`;

        const { error: errorUpdate } = await supabase
          .from('fotos')
          .update({ preview_path: urlConVersion })
          .eq('id', fila.id);
        if (errorUpdate) throw errorUpdate;

        procesadas++;
      } catch (errFila) {
        console.error(`Error al regenerar marca de agua de la foto ${fila.id}:`, errFila);
        fallidas++;
      }
    }

    const restantes = Math.max(universo.length - (offset + lote.length), 0);
    return res.json({ success: true, procesadas, fallidas, restantes, siguienteOffset: offset + lote.length });
  } catch (err: any) {
    console.error('Error al regenerar marca de agua:', err);
    return res.status(500).json({ success: false, error: err?.message || 'Error al regenerar la marca de agua' });
  }
});

// Panel admin: lista las fotos activas de un curso puntual (grado+turno+división), para revisar o borrar
const COLUMNAS_FOTO_PANEL = 'id, colegio_id, codigo_curso, grado, division, turno, categoria, alumno_nombre, preview_path, thumb_path, storage_path, created_at, publicada_at, nombre_original, bytes_original';
export const UUID_FOTO_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

rutas.get('/api/admin/fotos', requireAdminAuth, async (req: Request, res: Response) => {
  try {
    const supabase = getServerSupabase();
    if (!supabase) {
      return res.status(500).json({ success: false, error: 'Supabase no configurado en el servidor' });
    }
    const { grado, turno, division, colegioId } = req.query as Record<string, string | undefined>;

    // Auditoría 2026-09-23 (bug real): el panel de Laboratorio llama a esta ruta SIN filtros para
    // cruzar cada pedido con sus fotos. Sin paginar, PostgREST cortaba en las 1000 fotos más
    // nuevas: los pedidos de cursos cargados antes quedaban "sin fotos" en el panel (y sin
    // archivos para el laboratorio) aunque las fotos existieran.
    const data = await traerTodasLasFilas((desde, hasta) => {
      // Auditoría 03/10 (alto 16): sólo las columnas que usa el panel (mapearFilaFoto y pedidosLabService).
      let builder = supabase.from('fotos').select(COLUMNAS_FOTO_PANEL).order('created_at', { ascending: false }).order('id');
      if (grado && turno) {
        builder = builder.eq('codigo_curso', determinarCodigoCursoServidor(grado, turno, division || ''));
      }
      if (colegioId) {
        builder = builder.eq('colegio_id', colegioId);
      }
      return builder.range(desde, hasta);
    });
    return res.json({ success: true, fotos: data });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err?.message || 'Error al obtener las fotos' });
  }
});

// Auditoría 03/10 (alto 16): el panel ya no necesita bajar TODO el catálogo para cruzar los pedidos
// con sus fotos: pide sólo las fotos de los pedidos que muestra (de a 1000 ids como máximo).
rutas.post('/api/admin/fotos/por-ids', requireAdminAuth, async (req: Request, res: Response) => {
  try {
    const supabase = getServerSupabase();
    if (!supabase) return res.status(500).json({ success: false, error: 'Supabase no configurado en el servidor' });
    const crudos = Array.isArray(req.body?.ids) ? req.body.ids : null;
    if (!crudos) return res.status(400).json({ success: false, error: 'Falta la lista de fotos (ids).' });
    if (crudos.length > 1000) return res.status(400).json({ success: false, error: 'Máximo 1000 fotos por consulta.' });
    const ids = [...new Set(crudos.filter((v: unknown): v is string => typeof v === 'string' && UUID_FOTO_RE.test(v)))] as string[];
    const fotos: any[] = [];
    for (const grupo of enLotes(ids, 150)) {
      const { data, error } = await supabase.from('fotos').select(COLUMNAS_FOTO_PANEL).in('id', grupo);
      if (error) throw error;
      fotos.push(...(data || []));
    }
    return res.json({ success: true, fotos });
  } catch (err: any) {
    console.error('[Fotos] Error en por-ids:', err);
    return res.status(500).json({ success: false, error: 'No se pudieron obtener las fotos.' });
  }
});

// Auditoría 03/10 (crítico 3): `?modo=url` devuelve una URL firmada de Storage (válida 5 minutos)
// en vez de pasar el archivo por la función: Vercel corta las respuestas en 4,5 MB, así que los
// originales HD más pesados fallaban siempre. Sin `modo` se mantiene la descarga directa.
export async function responderUrlFirmadaOriginal(supabase: SupabaseClient, res: Response, storagePath: string, fotoId: string) {
  const nombre = (storagePath.split('/').pop() || `${fotoId}.jpg`).replace(/["\\\r\n]/g, '_');
  const { data, error } = await supabase.storage.from('fotos-hd').createSignedUrl(storagePath, 300, { download: nombre });
  if (error || !data?.signedUrl) throw error || new Error('No se pudo firmar la URL del original');
  res.setHeader('Cache-Control', 'private, no-store');
  return res.json({ success: true, url: data.signedUrl, nombre });
}

// Descarga protegida del original HD. El bucket permanece privado y el navegador sólo puede
// acceder mientras conserva una sesión válida del panel de administración.
rutas.get('/api/admin/fotos/:id/original', requireAdminAuth, async (req: Request, res: Response) => {
  try {
    const supabase = getServerSupabase();
    if (!supabase) {
      return res.status(500).json({ success: false, error: 'Supabase no configurado' });
    }

    const { data: foto, error: errorFoto } = await supabase
      .from('fotos')
      .select('storage_path')
      .eq('id', req.params.id)
      .maybeSingle();
    if (errorFoto) throw errorFoto;
    if (!foto?.storage_path) {
      return res.status(404).json({ success: false, error: 'Foto original no encontrada' });
    }
    if (req.query.modo === 'url') return responderUrlFirmadaOriginal(supabase, res, foto.storage_path, String(req.params.id));

    const { data: archivo, error: errorDescarga } = await supabase.storage
      .from('fotos-hd')
      .download(foto.storage_path);
    if (errorDescarga || !archivo) throw errorDescarga || new Error('No se pudo descargar el original');

    const nombre = foto.storage_path.split('/').pop() || `${req.params.id}.jpg`;
    res.setHeader('Content-Type', archivo.type || 'application/octet-stream');
    res.setHeader('Content-Disposition', `inline; filename="${nombre.replace(/["\\\r\n]/g, '_')}"`);
    res.setHeader('Cache-Control', 'private, no-store');
    return res.send(Buffer.from(await archivo.arrayBuffer()));
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err?.message || 'Error al descargar la foto original' });
  }
});

// Eliminar foto protegida
// Ruta dentro del bucket a partir de la URL pública guardada (".../object/public/fotos-web/<ruta>?v=...").
function rutaEnBucketDesdeUrl(valor: unknown, bucket: string): string | null {
  const texto = String(valor || '').trim();
  if (!texto) return null;
  const marca = `/object/public/${bucket}/`;
  const indice = texto.indexOf(marca);
  const ruta = indice >= 0 ? texto.slice(indice + marca.length) : texto.startsWith('http') ? '' : texto;
  const sinQuery = ruta.split('?')[0];
  try {
    return decodeURIComponent(sinQuery) || null;
  } catch {
    return sinQuery || null;
  }
}

// Auditoría 2026-09-26 (M8 + M9): borrar una foto ahora borra, del lado del servidor, sus TRES
// archivos (original HD, muestra con marca de agua y miniatura). Antes el panel borraba sólo la
// miniatura y el HD: la muestra ampliada quedaba publicada para siempre (en la base había 669
// archivos públicos para 18 fotos del catálogo). Además, no se deja borrar una foto que está en un
// pedido ya cobrado (le rompía la descarga HD a esa familia), salvo que se confirme con forzar=1.
rutas.delete('/api/admin/fotos/:id', requireAdminAuth, async (req, res) => {
  try {
    const { id } = req.params;
    const supabase = getServerSupabase();
    if (!supabase) {
      return res.status(500).json({ success: false, error: 'Supabase no configurado' });
    }

    const { data: foto, error: errorFoto } = await supabase
      .from('fotos')
      .select('id, colegio_id, codigo_curso, storage_path, preview_path, thumb_path')
      .eq('id', id)
      .maybeSingle();
    if (errorFoto) throw errorFoto;
    if (!foto) return res.json({ success: true });

    const forzar = req.query.forzar === '1' || (req.body && (req.body as any).forzar === true);
    if (!forzar && foto.colegio_id && foto.codigo_curso) {
      // Auditoría 05/10 (medio): también los pedidos sin pagar todavía (cobrables): si se borra una foto
      // elegida y la familia paga después, el .zip HD no se puede armar (quedaba incompleto en silencio).
      const { data: pedidosCurso, error: errPed } = await supabase
        .from('pedidos')
        .select('pedido_friendly_id, alumno_nombre, fotos_seleccionadas, estado')
        .eq('colegio_id', foto.colegio_id)
        .eq('curso_codigo', foto.codigo_curso)
        .in('estado', ['pagado', 'entregado', 'pendiente_pago'])
        .eq('cancelado_definitivo', false);
      // Auditoría 11/10: si no se pudo verificar, no se borra (antes se borraba igual).
      if (errPed) return res.status(503).json({ success: false, error: 'No se pudo verificar si la foto está en un pedido. Probá de nuevo.' });
      const usanLaFoto = pedidosQueUsanFoto(pedidosCurso || [], id);
      if (usanLaFoto.length > 0) {
        const pagados = usanLaFoto.filter((p: any) => p.estado !== 'pendiente_pago').length;
        return res.status(409).json({
          success: false,
          enUso: true,
          error: `Esta foto está en ${usanLaFoto.length} pedido(s) (${pagados} pagado(s), ${usanLaFoto.length - pagados} sin pagar: ${usanLaFoto.map((p: any) => `${p.pedido_friendly_id || ''} ${p.alumno_nombre || ''}`.trim()).slice(0, 5).join(', ')}). Si la borrás, esas familias pierden la descarga HD. Reemplazala primero o confirmá el borrado forzado.`,
        });
      }
    }

    // Auditoría 05/10: si otra fila de `fotos` usa el mismo archivo, se quita sólo la fila.
    const compartidas = await buscarFotosQueCompartenRutas(supabase, [foto]);
    const rutasWeb = Array.from(new Set([foto.preview_path, foto.thumb_path].filter((v) => v && !compartidas.has(String(v))).map((v) => rutaEnBucketDesdeUrl(v, 'fotos-web')).filter(Boolean))) as string[];
    const avisos: string[] = [];
    if (rutasWeb.length > 0) {
      const { error: errWeb } = await supabase.storage.from('fotos-web').remove(rutasWeb);
      if (errWeb) avisos.push(`muestras: ${errWeb.message}`);
    }
    if (foto.storage_path && !compartidas.has(String(foto.storage_path))) {
      // 09/10: también la copia de la lupa guardada al lado (si no existe, no pasa nada).
      const { error: errHd } = await supabase.storage.from('fotos-hd').remove([foto.storage_path, rutaCopiaLupa(String(foto.storage_path))]);
      if (errHd) avisos.push(`original HD: ${errHd.message}`);
    }

    const { error } = await supabase.from('fotos').delete().eq('id', id);
    if (error) throw error;

    return res.json({ success: true, advertencia: avisos.length > 0 ? `Foto quitada del catálogo, pero no se pudieron borrar algunos archivos (${avisos.join('; ')}).` : undefined });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err?.message || 'Error al eliminar foto' });
  }
});

function pedidosQueUsanFoto(pedidos: any[], fotoId: string): any[] {
  return pedidos.filter((p: any) => {
    const sel = p.fotos_seleccionadas || {};
    // 29/10/2026: también las copias de un pedido de fotos extra.
    return [sel.individualId, sel.grupalId, sel.docenteId].includes(fotoId) || (Array.isArray(sel.otrasIds) && sel.otrasIds.includes(fotoId)) || (Array.isArray(sel.extras) && sel.extras.some((e: any) => e?.fotoId === fotoId));
  });
}

// Auditoría 05/10: de las filas a registrar, separa las que ya tienen su `storage_path` en la base
// (se descartan sin error) y, dentro de la misma tanda, deja una sola fila por `storage_path`.
function descartarFotosYaRegistradas<T extends { storage_path: string }>(filas: T[], yaEnBase: Set<string>): { nuevas: T[]; yaRegistradas: number } {
  const vistas = new Set<string>();
  const nuevas: T[] = [];
  let yaRegistradas = 0;
  for (const fila of filas) {
    if (yaEnBase.has(fila.storage_path) || vistas.has(fila.storage_path)) { yaRegistradas += 1; continue; }
    vistas.add(fila.storage_path);
    nuevas.push(fila);
  }
  return { nuevas, yaRegistradas };
}

// Auditoría 05/10: rutas (HD, muestra y miniatura) de las fotos a borrar que OTRA fila de `fotos`
// (id distinto, y que no se está borrando en la misma tanda) sigue usando. Esos archivos no se
// tocan: sólo se quita la fila de la base. Pasó con fotos registradas dos veces con el mismo
// `storage_path`: borrar la "duplicada" borraba el HD de la otra. Desde el 08/10 la base no admite
// duplicados (fotos_storage_path_unico); esto sigue cuidando las filas viejas.
function rutasCompartidasConOtrasFotos(fotosABorrar: any[], otrasFilas: any[]): Set<string> {
  const idsABorrar = new Set(fotosABorrar.map((f: any) => String(f.id)));
  const compartidas = new Set<string>();
  for (const otra of otrasFilas) {
    if (!otra || idsABorrar.has(String(otra.id))) continue;
    for (const ruta of [otra.storage_path, otra.preview_path, otra.thumb_path]) if (ruta) compartidas.add(String(ruta));
  }
  return compartidas;
}

async function buscarFotosQueCompartenRutas(supabase: any, fotosABorrar: any[]): Promise<Set<string>> {
  const otras: any[] = [];
  for (const columna of ['storage_path', 'preview_path', 'thumb_path'] as const) {
    const valores = Array.from(new Set(fotosABorrar.map((f: any) => f[columna]).filter(Boolean))) as string[];
    for (const grupo of enLotes(valores, 100)) {
      const { data, error } = await supabase.from('fotos').select('id, storage_path, preview_path, thumb_path').in(columna, grupo);
      if (error) throw error;
      otras.push(...(data || []));
    }
  }
  return rutasCompartidasConOtrasFotos(fotosABorrar, otras);
}

// Auditoría 03/10 (bajo "borrados de a una" + alto 16): borrado en bloque, hasta 200 fotos por
// llamada, con las MISMAS protecciones que el borrado individual: no se borra una foto que está en
// un pedido ya pagado salvo `forzar`, y se borran sus tres archivos (HD, muestra y miniatura). Primero
// se quitan las filas (la galería deja de mostrarlas) y después los archivos; si un archivo no se
// pudo borrar queda informado en `errores` y lo levanta luego "Limpiar huérfanos".
rutas.post('/api/admin/fotos/borrar', requireAdminAuth, async (req: Request, res: Response) => {
  try {
    const supabase = getServerSupabase();
    if (!supabase) return res.status(500).json({ success: false, error: 'Supabase no configurado' });
    const crudos = Array.isArray(req.body?.ids) ? req.body.ids : null;
    if (!crudos || crudos.length === 0) return res.status(400).json({ success: false, error: 'Falta la lista de fotos (ids).' });
    if (crudos.length > 200) return res.status(400).json({ success: false, error: 'Máximo 200 fotos por llamada.' });
    const forzar = req.body?.forzar === true;
    // Auditoría 03/10: `enUso: true` marca los errores por foto usada en pedidos pagados (el panel
    // ofrece el borrado forzado sólo para esas, sin depender del texto del mensaje).
    const errores: { id: string; error: string; enUso?: boolean }[] = [];
    const ids: string[] = [];
    for (const v of crudos) {
      if (typeof v === 'string' && UUID_FOTO_RE.test(v)) { if (!ids.includes(v)) ids.push(v); }
      else errores.push({ id: String(v), error: 'Id inválido.' });
    }
    const fotos: any[] = [];
    for (const grupo of enLotes(ids, 100)) {
      const { data, error } = await supabase.from('fotos').select('id, colegio_id, codigo_curso, storage_path, preview_path, thumb_path').in('id', grupo);
      if (error) throw error;
      fotos.push(...(data || []));
    }
    // Las que ya no existen cuentan como borradas (igual que el DELETE individual).
    let borradas = ids.length - fotos.length;

    const aBorrar: any[] = [];
    const pedidosPorCurso = new Map<string, any[]>();
    for (const foto of fotos) {
      if (!forzar && foto.colegio_id && foto.codigo_curso) {
        const clave = `${foto.colegio_id}|${foto.codigo_curso}`;
        if (!pedidosPorCurso.has(clave)) {
          // Auditoría 05/10 (medio): también los pedidos sin pagar (ver DELETE /api/admin/fotos/:id).
          const { data: pedidosCurso, error: errPed } = await supabase
            .from('pedidos')
            .select('pedido_friendly_id, alumno_nombre, fotos_seleccionadas')
            .eq('colegio_id', foto.colegio_id)
            .eq('curso_codigo', foto.codigo_curso)
            .in('estado', ['pagado', 'entregado', 'pendiente_pago'])
            .eq('cancelado_definitivo', false);
          if (errPed) {
            errores.push({ id: foto.id, error: 'No se pudo verificar si la foto está en un pedido pagado.' });
            continue;
          }
          pedidosPorCurso.set(clave, pedidosCurso || []);
        }
        const usan = pedidosQueUsanFoto(pedidosPorCurso.get(clave) || [], foto.id);
        if (usan.length > 0) {
          errores.push({ id: foto.id, error: `Está en ${usan.length} pedido(s) pagado(s) o pendiente(s) de pago (${usan.map((p: any) => `${p.pedido_friendly_id || ''} ${p.alumno_nombre || ''}`.trim()).slice(0, 3).join(', ')}). Confirmá el borrado forzado.`, enUso: true });
          continue;
        }
      }
      aBorrar.push(foto);
    }

    // Auditoría 05/10: archivos que otra fila (que no se borra ahora) sigue usando: no se tocan.
    const compartidas = await buscarFotosQueCompartenRutas(supabase, aBorrar);

    const borradasOk: any[] = [];
    for (const grupo of enLotes(aBorrar, 100)) {
      const { error } = await supabase.from('fotos').delete().in('id', grupo.map((f: any) => f.id));
      if (error) {
        for (const f of grupo) errores.push({ id: f.id, error: 'No se pudo quitar del catálogo.' });
        continue;
      }
      borradasOk.push(...grupo);
      borradas += grupo.length;
    }

    // Archivos: en tandas por bucket.
    const rutasWeb: { ruta: string; id: string }[] = [];
    const rutasHd: { ruta: string; id: string }[] = [];
    for (const foto of borradasOk) {
      for (const r of new Set([foto.preview_path, foto.thumb_path].filter((v: unknown) => v && !compartidas.has(String(v))).map((v: unknown) => rutaEnBucketDesdeUrl(v, 'fotos-web')).filter(Boolean) as string[])) rutasWeb.push({ ruta: r, id: foto.id });
      if (foto.storage_path && !compartidas.has(String(foto.storage_path))) {
        rutasHd.push({ ruta: foto.storage_path, id: foto.id });
        rutasHd.push({ ruta: rutaCopiaLupa(String(foto.storage_path)), id: foto.id }); // 09/10: copia de la lupa
      }
    }
    for (const [bucket, lista, etiqueta] of [['fotos-web', rutasWeb, 'muestras'], ['fotos-hd', rutasHd, 'original HD']] as const) {
      for (const grupo of enLotes(lista, 100)) {
        const { error } = await supabase.storage.from(bucket).remove(grupo.map((x) => x.ruta));
        if (error) {
          for (const idFoto of new Set(grupo.map((x) => x.id))) errores.push({ id: idFoto, error: `Quitada del catálogo, pero no se pudieron borrar los archivos (${etiqueta}).` });
        }
      }
    }
    return res.json({ success: true, borradas, errores });
  } catch (err: any) {
    console.error('[Fotos] Error en borrado en bloque:', err);
    return res.status(500).json({ success: false, error: 'No se pudieron borrar las fotos.' });
  }
});

// Vacía por completo el catálogo de fotos (junto con "Limpiar Supabase"). 19/09 (MEDIO): borra TODO el catálogo de
// todos los colegios, así que exige la misma frase de seguridad que "Cerrar año" (antes, un solo clic).
rutas.delete('/api/admin/fotos', requireAdminAuth, async (req: Request, res: Response) => {
  try {
    const confirmacion = (req.body && (req.body as any).confirmacion) || (req.query.confirmacion as string) || '';
    const normalizar = (s: string) => s.trim().toLowerCase().replace(/\s+/g, ' ');
    if (normalizar(confirmacion) !== normalizar('borrar todas las fotos')) {
      return res.status(400).json({
        success: false,
        error: 'Falta confirmar. Tenés que mandar la frase exacta: "BORRAR TODAS LAS FOTOS".',
      });
    }
    const supabase = getServerSupabase();
    if (!supabase) {
      return res.status(500).json({ success: false, error: 'Supabase no configurado' });
    }
    const { error } = await supabase.from('fotos').delete().not('id', 'is', null);
    if (error) throw error;
    return res.json({ success: true });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err?.message || 'Error al limpiar el catálogo de fotos' });
  }
});

// ==============================================================================
// 4B. STORAGE DE FOTOS — SUBIDA/BORRADO PROTEGIDOS (auditoría 2026-09-09)
// ==============================================================================
// Antes (auditoría 2026-09-09) el navegador subía/borraba en 'fotos-web' y 'fotos-hd' con la clave
// anónima y RLS abierto (cualquiera podía bajar o borrar todo). Ahora todo pasa por acá con sesión de
// admin y la Service Role Key; para subir, el servidor firma una URL de un solo uso y el navegador sube
// directo a Storage. Las políticas públicas de los buckets se cerraron en Supabase.

const BUCKETS_FOTOS_PERMITIDOS = new Set(['fotos-web', 'fotos-hd']);

// Ver B6 (auditoría 2026-09-26): el panel sólo maneja archivos de fotos ("2026/colegio/curso/...")
// y el archivo de prueba del diagnóstico. Nada de "..", ni de los .zip de pedidos.
function rutaPermitidaParaPanel(ruta: string): boolean {
  const limpia = String(ruta || '').trim();
  if (!limpia || limpia.includes('..') || limpia.startsWith('/')) return false;
  return /^\d{4}\//.test(limpia) || limpia.startsWith('_diagnostico/');
}

// Auditoría 2026-09-23 (bug real): storage.list() sólo devuelve el primer nivel de una carpeta —
// las subcarpetas vienen como entradas sin `id`. Las fotos se guardan en "2026/<curso>/originales/
// ...", así que listar la raíz devolvía sólo la carpeta "2026" y el vaciado de bucket terminaba
// sin borrar ni un archivo (y el borrado de buckets huérfanos fallaba por "bucket no vacío").
// Esto recorre las subcarpetas y devuelve la ruta completa de cada archivo.
async function listarArchivosDeBucket(
  supabase: SupabaseClient,
  bucket: string,
  prefijo = '',
  maxArchivos = 20000,
  fechas?: Map<string, number>
): Promise<string[]> {
  const archivos: string[] = [];
  const pendientes: string[] = [prefijo.replace(/^\/+|\/+$/g, '')];
  while (pendientes.length > 0 && archivos.length < maxArchivos) {
    const carpeta = pendientes.shift() as string;
    for (let offset = 0; ; offset += 1000) {
      const { data, error } = await supabase.storage.from(bucket).list(carpeta, { limit: 1000, offset });
      if (error) throw error;
      const entradas = data || [];
      for (const entrada of entradas) {
        const ruta = carpeta ? `${carpeta}/${entrada.name}` : entrada.name;
        if (entrada.id) {
          archivos.push(ruta);
          if (fechas) fechas.set(ruta, Date.parse((entrada as any).created_at || (entrada as any).updated_at || '') || 0);
        } else pendientes.push(ruta);
      }
      if (entradas.length < 1000) break;
    }
  }
  return archivos.slice(0, maxArchivos);
}

// Genera una URL de subida firmada y de un solo uso para un archivo puntual. El navegador la
// usa para subir el archivo directo a Storage (client.storage.from(bucket).uploadToSignedUrl),
// sin necesitar ningún permiso público de escritura en el bucket.
rutas.post('/api/admin/storage/signed-upload-url', requireAdminAuth, async (req: Request, res: Response) => {
  try {
    const { bucket, path: rutaArchivo } = req.body || {};
    if (!BUCKETS_FOTOS_PERMITIDOS.has(bucket)) {
      return res.status(400).json({ success: false, error: 'Bucket no permitido' });
    }
    if (!rutaArchivo || typeof rutaArchivo !== 'string') {
      return res.status(400).json({ success: false, error: 'Falta la ruta del archivo' });
    }
    // Auditoría 2026-09-26 (B6): sólo se sube a carpetas de fotos (AAAA/...) o de diagnóstico. Antes
    // se podía pisar cualquier archivo del bucket privado, incluidos los .zip de descarga de los
    // pedidos (zips-pedidos/), que arma sólo el servidor.
    if (!rutaPermitidaParaPanel(rutaArchivo)) {
      return res.status(400).json({ success: false, error: 'Ruta de archivo no permitida' });
    }
    const supabase = getServerSupabase();
    if (!supabase) {
      return res.status(500).json({ success: false, error: 'Supabase no configurado en el servidor' });
    }
    const { data, error } = await supabase.storage.from(bucket).createSignedUploadUrl(rutaArchivo, { upsert: true } as any);
    if (error) throw error;
    return res.json({ success: true, signedUrl: data.signedUrl, token: data.token, path: data.path });
  } catch (err: any) {
    console.error('Error al generar URL de subida firmada:', err);
    return res.status(500).json({ success: false, error: err?.message || 'Error al generar URL de subida' });
  }
});

// Borra archivos puntuales de un bucket (usado al eliminar una foto individual del panel).
rutas.post('/api/admin/storage/eliminar-archivos', requireAdminAuth, async (req: Request, res: Response) => {
  try {
    const { bucket, paths } = req.body || {};
    if (!BUCKETS_FOTOS_PERMITIDOS.has(bucket)) {
      return res.status(400).json({ success: false, error: 'Bucket no permitido' });
    }
    if (!Array.isArray(paths) || paths.length === 0) {
      return res.json({ success: true, eliminados: 0 });
    }
    const rutasValidas = paths.filter((p: any) => typeof p === 'string' && p.trim() && rutaPermitidaParaPanel(p)).slice(0, 200);
    if (rutasValidas.length === 0) {
      return res.json({ success: true, eliminados: 0 });
    }
    const supabase = getServerSupabase();
    if (!supabase) {
      return res.status(500).json({ success: false, error: 'Supabase no configurado en el servidor' });
    }
    const { error } = await supabase.storage.from(bucket).remove(rutasValidas);
    if (error) throw error;
    return res.json({ success: true, eliminados: rutasValidas.length });
  } catch (err: any) {
    console.error('Error al eliminar archivos de storage:', err);
    return res.status(500).json({ success: false, error: err?.message || 'Error al eliminar archivos' });
  }
});

// 26/09 (M8): limpieza de archivos huérfanos (fotos fuera del catálogo y .zip de pedidos no cobrados). Por
// defecto SOLO cuenta (simulación); con {"aplicar": true} borra. 28/9: también corre sola una vez por semana
// (/api/cron/limpiar-huerfanos), sólo con archivos de más de 3 días (nunca toca una subida en curso).
export async function limpiarArchivosHuerfanos(supabase: SupabaseClient, aplicar: boolean, antiguedadMinimaMs = 0, conFreno = true) {
    const leidoDesde = new Date(Date.now() - 10 * 60 * 1000).toISOString(); // 14/10: margen para la relectura
    const fotos = await traerTodasLasFilas<any>((desde, hasta) =>
      supabase.from('fotos').select('storage_path, preview_path, thumb_path').order('id').range(desde, hasta)
    );
    const referenciadasWeb = new Set<string>();
    const referenciadasHd = new Set<string>();
    for (const f of fotos) {
      for (const v of [f.preview_path, f.thumb_path]) {
        const ruta = rutaEnBucketDesdeUrl(v, 'fotos-web');
        if (ruta) referenciadasWeb.add(ruta);
      }
      if (f.storage_path) {
        referenciadasHd.add(String(f.storage_path));
        referenciadasHd.add(rutaCopiaLupa(String(f.storage_path))); // 09/10: copia de la lupa
      }
    }
    const pedidosCobrados = await traerTodasLasFilas<any>((desde, hasta) =>
      supabase.from('pedidos').select('id, pedido_friendly_id').in('estado', ['pagado', 'entregado']).order('id').range(desde, hasta)
    );
    const zipsValidos = new Set<string>();
    for (const p of pedidosCobrados) {
      zipsValidos.add(nombreZipHDPedido(p));
      if (p.pedido_friendly_id) zipsValidos.add(`zips-pedidos/${p.pedido_friendly_id}.zip`);
    }

    const fechas = new Map<string, number>();
    const archivosWeb = await listarArchivosDeBucket(supabase, 'fotos-web', '', 20000, fechas);
    const fechasHd = new Map<string, number>();
    const archivosHd = await listarArchivosDeBucket(supabase, 'fotos-hd', '', 20000, fechasHd);
    const viejo = (f: Map<string, number>) => (r: string) => antiguedadMinimaMs <= 0 || (f.get(r) || Date.now()) < Date.now() - antiguedadMinimaMs;
    const huerfanosWeb = archivosWeb.filter((r) => /^\d{4}\//.test(r) && !referenciadasWeb.has(r)).filter(viejo(fechas));
    const huerfanosHd = archivosHd.filter((r) => /^\d{4}\//.test(r) && !referenciadasHd.has(r)).filter(viejo(fechasHd));
    const zipsHuerfanos = archivosHd.filter((r) => r.startsWith('zips-pedidos/') && !zipsValidos.has(r)).filter(viejo(fechasHd));
    // Auditoría 11/10: freno (sólo el cron; Pablo desde el panel ve la simulación antes) si "huérfanos" es > 20 % del bucket HD.
    const sospechoso = conFreno && huerfanosHd.length > 0.2 * archivosHd.length;
    if (sospechoso && aplicar) await registrarAlertaPago(supabase, 'limpieza-huerfanos-frenada', `Limpieza de archivos frenada: ${huerfanosHd.length} de ${archivosHd.length} originales HD figuraban huérfanos (¿catálogo leído a medias?). No se borró nada.`);
    let borrados = 0;
    if (aplicar && !sospechoso) {
      for (const [bucket, rutas] of [['fotos-web', huerfanosWeb], ['fotos-hd', [...huerfanosHd, ...zipsHuerfanos]]] as const) {
        for (const loteLeido of enLotes([...rutas], 100)) {
          const lote = await quitarRegistradasRecien(supabase, bucket, loteLeido, leidoDesde);
          if (lote.length === 0) continue;
          const { error } = await supabase.storage.from(bucket).remove(lote);
          if (error) throw error;
          borrados += lote.length;
        }
      }
    }
    return {
      aplicado: aplicar,
      muestrasPublicasHuerfanas: huerfanosWeb.length,
      originalesHdHuerfanos: huerfanosHd.length,
      zipsSinPedidoCobrado: zipsHuerfanos.length,
      borrados,
      frenado: sospechoso,
    };
}

// 14/10/2026 (auditoría): entre la lectura del catálogo y el borrado pudo registrarse una foto nueva (una subida
// que terminó en el medio). Justo antes de cada tanda se vuelve a mirar el catálogo (las fotos registradas desde
// poco antes de la lectura y, en el bucket HD, esas rutas puntuales) y se sacan de la tanda las que ya figuran.
async function quitarRegistradasRecien(supabase: SupabaseClient, bucket: string, lote: string[], desde: string): Promise<string[]> {
  const registradas = new Set<string>();
  const anotar = (f: any) => {
    for (const v of [f.preview_path, f.thumb_path]) {
      const ruta = rutaEnBucketDesdeUrl(v, 'fotos-web');
      if (ruta) registradas.add(ruta);
    }
    if (f.storage_path) registradas.add(String(f.storage_path)).add(rutaCopiaLupa(String(f.storage_path)));
  };
  const recientes = await traerTodasLasFilas<any>((d, h) => supabase.from('fotos').select('id, storage_path, preview_path, thumb_path').gte('created_at', desde).order('id').range(d, h));
  recientes.forEach(anotar);
  if (bucket === 'fotos-hd') {
    const candidatas = [...new Set([...lote, ...lote.map((r) => r.replace(/\.lupa\.jpg$/, ''))])];
    const { data, error } = await supabase.from('fotos').select('storage_path, preview_path, thumb_path').in('storage_path', candidatas);
    if (error) throw error;
    (data || []).forEach(anotar);
  }
  return lote.filter((r) => !registradas.has(r));
}

rutas.post('/api/admin/storage/limpiar-huerfanos', requireAdminAuth, async (req: Request, res: Response) => {
  try {
    const supabase = getServerSupabase();
    if (!supabase) return res.status(500).json({ success: false, error: 'Supabase no configurado' });
    // Auditoría 03/10 (crítico 5): sin antigüedad mínima, "Limpiar huérfanos" borraba las fotos de
    // una subida EN CURSO (los archivos suben antes de registrarse en el catálogo). Sólo se cuentan y
    // borran archivos con más de 24 h.
    const resultado = await limpiarArchivosHuerfanos(supabase, req.body?.aplicar === true, 24 * 60 * 60 * 1000, false);
    return res.json({ success: true, ...resultado });
  } catch (err: any) {
    console.error('Error al limpiar archivos huérfanos:', err);
    return res.status(500).json({ success: false, error: err?.message || 'Error al limpiar archivos huérfanos' });
  }
});

// Vacía por completo un bucket (botón "Limpiar Supabase"). 19/09 (MEDIO): exige la frase de seguridad de
// "Cerrar año", específica del bucket (antes alcanzaba con la sesión de admin).
rutas.post('/api/admin/storage/limpiar-bucket', requireAdminAuth, async (req: Request, res: Response) => {
  try {
    const { bucket, prefix, confirmacion } = req.body || {};
    if (!BUCKETS_FOTOS_PERMITIDOS.has(bucket)) {
      return res.status(400).json({ success: false, error: 'Bucket no permitido' });
    }
    const normalizar = (s: string) => String(s || '').trim().toLowerCase().replace(/\s+/g, ' ');
    if (normalizar(confirmacion) !== normalizar(`borrar bucket ${bucket}`)) {
      return res.status(400).json({
        success: false,
        error: `Falta confirmar. Tenés que mandar la frase exacta: "BORRAR BUCKET ${String(bucket).toUpperCase()}".`,
      });
    }
    const supabase = getServerSupabase();
    if (!supabase) {
      return res.status(500).json({ success: false, error: 'Supabase no configurado en el servidor' });
    }
    const prefijo = typeof prefix === 'string' ? prefix : '';

    // Recorre también las subcarpetas (ver listarArchivosDeBucket); tope defensivo de 20.000
    // archivos por llamada.
    // Auditoría 30/9: sólo fotos (carpetas por año). Nunca los .zip de pedidos ya pagados
    // (zips-pedidos/) ni otras carpetas: antes el vaciado también borraba las descargas de las familias.
    if (prefijo && !/^\d{4}(\/|$)/.test(prefijo)) {
      return res.status(400).json({ success: false, error: 'Carpeta no permitida: sólo se pueden vaciar carpetas de fotos por año (ej. 2026/).' });
    }
    const rutas = (await listarArchivosDeBucket(supabase, bucket, prefijo)).filter(rutaPermitidaParaPanel);
    let eliminados = 0;
    for (const lote of enLotes(rutas, 500)) {
      const { error: errorRemove } = await supabase.storage.from(bucket).remove(lote);
      if (errorRemove) throw errorRemove;
      eliminados += lote.length;
    }

    return res.json({ success: true, eliminados });
  } catch (err: any) {
    console.error('Error al limpiar bucket de storage:', err);
    return res.status(500).json({ success: false, error: err?.message || 'Error al limpiar el bucket' });
  }
});

// Auditoría 2026-09-09 (revisión a fondo): endpoint puntual de una sola vez para borrar dos
// buckets de Storage detectados como huérfanos (ningún código de la app los usa) — 'fotos'
// (público, vacío) y 'photos' (privado, con 4 archivos viejos de prueba). Se usa una lista
// separada de BUCKETS_FOTOS_PERMITIDOS (que son los buckets operativos reales) a propósito, para
// que este endpoint nunca pueda llegar a borrar 'fotos-web' o 'fotos-hd' por error. Se puede
// borrar este endpoint del código una vez usado.
const BUCKETS_HUERFANOS_BORRABLES = new Set(['fotos', 'photos']);
rutas.post('/api/admin/storage/borrar-bucket-huerfano', requireAdminAuth, async (req: Request, res: Response) => {
  try {
    const { bucket } = req.body || {};
    if (!BUCKETS_HUERFANOS_BORRABLES.has(bucket)) {
      return res.status(400).json({ success: false, error: 'Ese bucket no está en la lista de buckets huérfanos permitidos para borrar.' });
    }
    const supabase = getServerSupabase();
    if (!supabase) {
      return res.status(500).json({ success: false, error: 'Supabase no configurado en el servidor' });
    }

    const rutas = await listarArchivosDeBucket(supabase, bucket);
    let eliminados = 0;
    for (const lote of enLotes(rutas, 500)) {
      const { error: errorRemove } = await supabase.storage.from(bucket).remove(lote);
      if (errorRemove) throw errorRemove;
      eliminados += lote.length;
    }

    const { error: errorDeleteBucket } = await supabase.storage.deleteBucket(bucket);
    if (errorDeleteBucket) throw errorDeleteBucket;

    return res.json({ success: true, bucket, archivosEliminados: eliminados });
  } catch (err: any) {
    console.error('Error al borrar bucket huérfano:', err);
    return res.status(500).json({ success: false, error: err?.message || 'Error al borrar el bucket' });
  }
});

export { rutas as rutasFotosPanel };
