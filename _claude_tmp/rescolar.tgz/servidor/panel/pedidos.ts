// Panel del fotógrafo — alumnos, familias y pedidos (división de server.ts, etapa 4, 10/10/2026):
// configuración pública, nómina de alumnos (buscar, importar, borrar), estado de pagos por colegio,
// familias, pedidos del panel (listado, notificar estado, marcar retirado, resumen, QR, aprobar pago a
// mano), organizar un pedido (archivar, en espera, nota) y borrar un pedido. El código es el mismo que
// estaba en la sección "4. RUTAS ADMINISTRATIVAS" de server.ts: sólo se movió de lugar. En server.ts
// esas rutas estaban en tres tramos separados: por eso hay tres routers, montados donde estaba cada uno.
import express from 'express';
import type { Request, Response } from 'express';
import QRCode from 'qrcode';
import { enviarCorreoActualizacionPedido } from '../entrega/correos.js';
import type { TipoActualizacionPedido } from '../entrega/correos.js';
import { procesarPedidosRecienPagados } from '../entrega/pedidosPagados.js';
import { generarYSubirZipHDParaPedido } from '../entrega/zipHD.js';
import { requireAdminAuth } from '../nucleo/auth.js';
import { getServerSupabase } from '../nucleo/clientes.js';
import { separarYaImportadas } from '../nucleo/importacionSinDuplicados.js';
import { normalizarCodigoSeccion } from '../nucleo/codigosCurso.js';
import { esPedidoAdicional, ESTADOS_COBRABLES, puedeAvanzarEtapaLab, tipoChoqueUnicoPedido } from '../nucleo/pedidos.js';
import type { EtapaLab } from '../nucleo/pedidos.js';
import { borrarComprobantesSinUso } from './cierreTemporada.js';
import { enLotes, normalizarNombreComparable, normalizarNombrePorPalabras, traerTodasLasFilas } from '../nucleo/utilidades.js';

// Un router por cada tramo de server.ts donde estaban estas rutas (así el orden de Express no cambia).
const rutas = express.Router();
const rutasOrganizar = express.Router();
const rutasBorrar = express.Router();

// ==============================================================================
// 4. RUTAS ADMINISTRATIVAS PROTEGIDAS (SUPABASE SERVICE ROLE)
// ==============================================================================

// Guarda valores de configuración pública del sitio (hoy: números de WhatsApp de contacto). Antes el
// navegador escribía directo con la clave anónima y RLS abierto; ahora pasa por acá con sesión de admin
// y la escritura pública se cerró en Supabase (la lectura pública sigue). Ver auditoría 2026-09-09.
rutas.post('/api/admin/configuracion', requireAdminAuth, async (req, res) => {
  try {
    const { registros } = req.body || {};
    if (!Array.isArray(registros) || registros.length === 0) {
      return res.status(400).json({ success: false, error: 'Se requiere un array "registros" con al menos un elemento.' });
    }

    const supabase = getServerSupabase();
    if (!supabase) {
      return res.status(500).json({ success: false, error: 'Supabase no configurado en el servidor' });
    }

    const filas = registros
      .filter((r: any) => r && typeof r.clave === 'string' && r.clave.trim())
      .map((r: any) => ({
        clave: String(r.clave).trim(),
        valor: r.valor === undefined || r.valor === null ? '' : String(r.valor),
        datos_extra: r.datos_extra && typeof r.datos_extra === 'object' ? r.datos_extra : {},
        updated_at: new Date().toISOString(),
      }));

    if (filas.length === 0) {
      return res.status(400).json({ success: false, error: 'Ningún registro válido para guardar.' });
    }

    const { error } = await supabase.from('configuracion').upsert(filas, { onConflict: 'clave' });
    if (error) throw error;

    return res.json({ success: true });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err?.message || 'Error al guardar configuración' });
  }
});

// Nómina real de alumnos (tabla 'alumnos', cargada por el importador de padrón). Antes la
// pestaña "Nómina 2026" del panel mostraba una lista vieja, escrita a mano en el código
// (src/data/alumnosData.ts, 211 alumnos de una sola sala de nivel inicial) que no tenía nada
// que ver con los padrones reales que se van cargando por colegio. Se agrega este endpoint
// para que el panel muestre la nómina real de Supabase en vez de esa lista fija.
rutas.get('/api/admin/alumnos', requireAdminAuth, async (req: Request, res: Response) => {
  try {
    const supabase = getServerSupabase();
    if (!supabase) {
      return res.status(500).json({ success: false, error: 'Supabase no configurado en el servidor' });
    }
    const { colegioId } = req.query;

    const alumnos = await traerTodasLasFilas((desde, hasta) => {
      let builder = supabase
        .from('alumnos')
        .select('id, nombre, grado, division, turno, colegio_id, numero_lista, dni, origen, fotografiado_at, foto_seno_at, foto_grupal_at')
        .order('grado', { ascending: true })
        .order('division', { ascending: true })
        .order('numero_lista', { ascending: true, nullsFirst: false })
        .order('id') // auditoría 11/10: desempate único (si no, el paginado repite/saltea alumnos)
        .range(desde, hasta);
      if (typeof colegioId === 'string' && colegioId) {
        builder = builder.eq('colegio_id', colegioId);
      }
      return builder;
    });

    return res.json({ success: true, alumnos });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err?.message || 'Error al obtener la nómina de alumnos' });
  }
});

// Estado de pagos de un colegio/curso puntual: cruza la nómina real de alumnos (tabla
// 'alumnos') contra los pedidos ya registrados para ese mismo colegio_id (tabla 'pedidos'),
// para poder ver de un vistazo quién ya pagó y quién todavía falta — pensado para cursos
// puntuales (ej. actos de egresados) donde el organizador se compromete a una tarifa total
// fija por todo el curso, y hay que ver cuánto falta para llegar a esa meta.
// No hay una columna "alumno_id" confiable en pedidos (no se completa al crear el pedido),
// así que el cruce se hace por nombre normalizado — puede fallar si el nombre cargado en el
// pedido no coincide textualmente con el de la nómina (ej. errores de tipeo de la familia).
rutas.get('/api/admin/colegios/:colegioId/estado-pagos', requireAdminAuth, async (req: Request, res: Response) => {
  try {
    const supabase = getServerSupabase();
    if (!supabase) {
      return res.status(500).json({ success: false, error: 'Supabase no configurado en el servidor' });
    }
    const { colegioId } = req.params;
    if (!colegioId) {
      return res.status(400).json({ success: false, error: 'Falta el colegioId' });
    }

    // Mismo bug que en "Nómina 2026": sin paginar, Supabase/PostgREST corta cada consulta en
    // 1000 filas aunque el colegio tenga más alumnos o pedidos cargados (ver `traerTodasLasFilas`).
    const [alumnos, pedidos] = await Promise.all([
      traerTodasLasFilas<any>((desde, hasta) =>
        supabase
          .from('alumnos')
          .select('id, nombre, grado, division, turno, numero_lista')
          .eq('colegio_id', colegioId)
          .order('grado', { ascending: true })
          .order('division', { ascending: true })
          .order('numero_lista', { ascending: true, nullsFirst: false })
          .order('id')
          .range(desde, hasta)
      ),
      traerTodasLasFilas<any>((desde, hasta) =>
        supabase
          .from('pedidos')
          .select('id, alumno_nombre, alumno_numero_lista, estado, total, kit_nombre, metodo_pago, created_at')
          .eq('colegio_id', colegioId)
          // Orden cronológico: más abajo "el más reciente" se toma como el último del array — sin
          // orden explícito Postgres devuelve las filas en cualquier orden.
          .order('created_at', { ascending: true })
          .order('id')
          .range(desde, hasta)
      ),
    ]);

    // Un pedido cuenta como "pagado" a los fines de este listado si Mercado Pago (o el admin
    // a mano) ya lo confirmó, o si ya se entregó (lo cual implica que se cobró antes).
    const ESTADOS_PAGADOS = new Set(['pagado', 'entregado']);

    // Agrupa los pedidos de este colegio por nombre de alumno normalizado. Si un mismo
    // alumno tiene más de un pedido, se prioriza el pagado (o el más reciente, si hay varios
    // pagados o ninguno lo está) para no perder de vista los otros pedidos.
    // Dos mapas: uno por la clave exacta ("garcia maria jose") y otro por las mismas palabras
    // pero ordenadas alfabéticamente ("garcia jose maria"), para poder emparejar igual aunque
    // la nómina diga "Apellido, Nombre" y la familia haya tipeado "Nombre Apellido".
    const pedidosPorNombreExacto = new Map<string, typeof pedidos>();
    const pedidosPorPalabras = new Map<string, typeof pedidos>();
    for (const p of pedidos) {
      const claveExacta = normalizarNombreComparable(p.alumno_nombre);
      if (!claveExacta) continue;
      if (!pedidosPorNombreExacto.has(claveExacta)) pedidosPorNombreExacto.set(claveExacta, []);
      pedidosPorNombreExacto.get(claveExacta)!.push(p);

      const clavePalabras = normalizarNombrePorPalabras(p.alumno_nombre);
      if (!pedidosPorPalabras.has(clavePalabras)) pedidosPorPalabras.set(clavePalabras, []);
      pedidosPorPalabras.get(clavePalabras)!.push(p);
    }

    const nombresDeLaNomina = new Set(alumnos.map((a) => normalizarNombreComparable(a.nombre)));
    const nombresDeLaNominaPorPalabras = new Set(alumnos.map((a) => normalizarNombrePorPalabras(a.nombre)));

    const alumnosConEstado = alumnos.map((a) => {
      const claveExacta = normalizarNombreComparable(a.nombre);
      const clavePalabras = normalizarNombrePorPalabras(a.nombre);
      const pedidosDelAlumno =
        pedidosPorNombreExacto.get(claveExacta) || pedidosPorPalabras.get(clavePalabras) || [];
      const pedidoPagado = pedidosDelAlumno.find((p) => ESTADOS_PAGADOS.has(p.estado));
      const pedidoElegido = pedidoPagado || pedidosDelAlumno[pedidosDelAlumno.length - 1] || null;
      return {
        id: a.id,
        nombre: a.nombre,
        grado: a.grado,
        division: a.division,
        turno: a.turno,
        numeroLista: a.numero_lista,
        pagado: !!pedidoPagado,
        pedido: pedidoElegido
          ? {
              id: pedidoElegido.id,
              estado: pedidoElegido.estado,
              total: Number(pedidoElegido.total) || 0,
              kitNombre: pedidoElegido.kit_nombre,
              metodoPago: pedidoElegido.metodo_pago,
              fecha: pedidoElegido.created_at,
            }
          : null,
        otrosPedidos: pedidosDelAlumno.length > 1 ? pedidosDelAlumno.length - 1 : 0,
      };
    });

    // Pedidos de este colegio cuyo nombre de alumno no matchea con nadie de la nómina cargada
    // (typo, alumno que ya no está en la nómina, etc.) — se muestran aparte para que el admin
    // los pueda revisar a mano en vez de perderlos silenciosamente.
    const pedidosSinAlumnoEnNomina = pedidos
      .filter((p) => {
        const claveExacta = normalizarNombreComparable(p.alumno_nombre);
        const clavePalabras = normalizarNombrePorPalabras(p.alumno_nombre);
        return claveExacta && !nombresDeLaNomina.has(claveExacta) && !nombresDeLaNominaPorPalabras.has(clavePalabras);
      })
      .map((p) => ({
        id: p.id,
        alumnoNombre: p.alumno_nombre,
        estado: p.estado,
        total: Number(p.total) || 0,
        kitNombre: p.kit_nombre,
        fecha: p.created_at,
      }));

    const totalAlumnos = alumnos.length;
    const alumnosPagados = alumnosConEstado.filter((a) => a.pagado).length;
    // Auditoría 11/10: suma TODOS los pedidos cobrados del colegio (antes, uno solo por alumno: no sumaba mejoras ni repetidos).
    const totalRecaudado = pedidos.reduce((acc, p) => acc + (ESTADOS_PAGADOS.has(p.estado) ? Number(p.total) || 0 : 0), 0);

    return res.json({
      success: true,
      alumnos: alumnosConEstado,
      pedidosSinAlumnoEnNomina,
      resumen: {
        totalAlumnos,
        alumnosPagados,
        alumnosFaltantes: totalAlumnos - alumnosPagados,
        totalRecaudado,
      },
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err?.message || 'Error al obtener el estado de pagos del colegio' });
  }
});

// Auditoría 2026-09-16 (pedido de Pablo: "necesito un buscador de alumnos, por nombre y
// apellido, dni, codigo, telefono, para saber si pagó"): hasta ahora, para saber si una familia
// puntual ya pagó había que entrar a "Estado de pagos" y elegir el colegio a mano (pensado para
// cursos con tarifa total acordada, no para una búsqueda rápida de un alumno cualquiera), o
// revisar "Pedidos" a ojo. Este endpoint busca en paralelo por nombre/apellido y DNI (tabla
// `alumnos`), por Código de Acceso real de la sección (`codigos_seccion`, mismo mecanismo que
// "Códigos y difusión") y por teléfono de la familia (`pedidos` + `familias.whatsapp`, igual que
// ya hace el buscador público `/api/pedidos/buscar`) — y para cada alumno que encuentra, cruza
// sus pedidos por nombre (mismo criterio que `/estado-pagos` de arriba) para decir si ya pagó.
rutas.get('/api/admin/alumnos/buscar', requireAdminAuth, async (req: Request, res: Response) => {
  try {
    const qRaw = String(req.query.q || '').trim();
    if (qRaw.length < 2) {
      return res.status(400).json({ success: false, error: 'Escribí al menos 2 caracteres para buscar.' });
    }
    const supabase = getServerSupabase();
    if (!supabase) return res.status(500).json({ success: false, error: 'Supabase no configurado en el servidor' });

    const soloDigitos = qRaw.replace(/\D/g, '');
    const codigoNormalizado = normalizarCodigoSeccion(qRaw);
    const qLike = `%${qRaw.replace(/[%_]/g, '\\$&')}%`;
    // Búsqueda por nombre por palabras (caso real 25/9: "Olivia Ayelen Sanchez" no encontraba
    // "SANCHEZ, OLIVIA AYELÉN"): la nómina viene como "Apellido, Nombre" y con tildes, y el ilike
    // sobre el texto entero exigía el mismo orden y los mismos acentos. Ahora se trae a Supabase
    // la palabra más larga con las vocales como comodín (tolera tildes) y acá se exige que estén
    // todas las palabras, en cualquier orden y sin importar acentos.
    const palabrasBusqueda = normalizarNombreComparable(qRaw).split(' ').filter((w) => w.length >= 2);
    const palabraAncla = [...palabrasBusqueda].sort((a, b) => b.length - a.length)[0] || '';
    const patronAncla = `%${palabraAncla.replace(/[%_\\]/g, '').replace(/[aeiou]/g, '_').replace(/n/g, '_')}%`;
    const coincidePorPalabras = (nombre: unknown) => {
      const n = normalizarNombreComparable(nombre);
      return palabrasBusqueda.length > 0 && palabrasBusqueda.every((w) => n.includes(w));
    };

    const [colegiosRes, porNombreRes, porDniRes, seccionesRes, pedidosPorTelefonoRes, pedidosPorNombreRes] = await Promise.all([
      supabase.from('colegios').select('id, nombre'),
      palabraAncla
        ? supabase.from('alumnos').select('id, nombre, grado, division, turno, colegio_id, numero_lista, dni').ilike('nombre', patronAncla).limit(1000)
        : Promise.resolve({ data: [], error: null } as any),
      supabase.from('alumnos').select('id, nombre, grado, division, turno, colegio_id, numero_lista, dni').ilike('dni', qLike).limit(50),
      codigoNormalizado.length >= 4
        ? supabase.from('codigos_seccion').select('colegio_id, grado, turno, division, codigo_secreto')
        : Promise.resolve({ data: [], error: null } as any),
      soloDigitos.length >= 6
        ? supabase
            .from('pedidos')
            .select(
              'id, pedido_friendly_id, colegio_id, colegio_nombre, alumno_nombre, grado, division, kit_nombre, total, estado, created_at, familias!inner(nombre, whatsapp, email)'
            )
            .ilike('familias.whatsapp', `%${soloDigitos}%`)
            .order('created_at', { ascending: false })
            .limit(20)
        : Promise.resolve({ data: [], error: null } as any),
      // Pedidos por nombre del alumno: cubre chicos que no están en la nómina cargada (o con el
      // nombre escrito distinto) — se muestran aparte si no quedaron asociados a un alumno.
      palabraAncla.length >= 3
        ? supabase
            .from('pedidos')
            .select(
              'id, pedido_friendly_id, colegio_id, colegio_nombre, alumno_nombre, grado, division, kit_nombre, total, estado, created_at, familias(nombre, whatsapp, email)'
            )
            .ilike('alumno_nombre', patronAncla)
            .order('created_at', { ascending: false })
            .limit(500)
        : Promise.resolve({ data: [], error: null } as any),
    ]);
    if (porNombreRes.error) throw porNombreRes.error;
    if (porDniRes.error) throw porDniRes.error;

    const mapaColegios = new Map((colegiosRes.data || []).map((c: any) => [c.id, c.nombre]));

    // El código de sección no distingue mayúsculas ni guiones ("AB12-CD34" == "ab12cd34"), y
    // Supabase no lo puede filtrar así en la consulta — se compara ya normalizado acá.
    const seccionesQueMatchean = ((seccionesRes as any).data || []).filter(
      (s: any) => codigoNormalizado.length >= 4 && normalizarCodigoSeccion(s.codigo_secreto).includes(codigoNormalizado)
    );
    let alumnosDeSecciones: any[] = [];
    if (seccionesQueMatchean.length > 0) {
      const resultados = await Promise.all(
        seccionesQueMatchean.map((s: any) =>
          supabase
            .from('alumnos')
            .select('id, nombre, grado, division, turno, colegio_id, numero_lista, dni')
            .eq('colegio_id', s.colegio_id)
            .eq('grado', s.grado)
            .eq('turno', s.turno)
            .eq('division', s.division)
        )
      );
      alumnosDeSecciones = resultados.flatMap((r) => r.data || []);
    }

    // Combina y dedupea por id los tres caminos de búsqueda (nombre, DNI, código de sección).
    const mapaAlumnos = new Map<string, any>();
    [...(porNombreRes.data || []).filter((a: any) => coincidePorPalabras(a.nombre)), ...(porDniRes.data || []), ...alumnosDeSecciones].forEach((a) => mapaAlumnos.set(a.id, a));
    const alumnosEncontrados = Array.from(mapaAlumnos.values()).slice(0, 60);

    // Para cruzar pago, trae de una sola vez todos los pedidos de cada colegio involucrado
    // (en vez de un pedido por alumno) — mismo criterio de "pagado" y de emparejado por nombre
    // normalizado que ya usa `/estado-pagos` arriba.
    const colegioIds = Array.from(new Set(alumnosEncontrados.map((a) => a.colegio_id).filter(Boolean)));
    const ESTADOS_PAGADOS = new Set(['pagado', 'entregado']);
    const pedidosPorColegio = new Map<string, any[]>();
    if (colegioIds.length > 0) {
      const resultados = await Promise.all(
        colegioIds.map((cid) =>
          traerTodasLasFilas<any>((desde, hasta) =>
            supabase
              .from('pedidos')
              .select('id, pedido_friendly_id, alumno_nombre, estado, total, kit_nombre, metodo_pago, created_at, familias(nombre, whatsapp, email)')
              .eq('colegio_id', cid)
              .order('created_at', { ascending: true })
              .order('id')
              .range(desde, hasta)
          )
        )
      );
      colegioIds.forEach((cid, idx) => pedidosPorColegio.set(cid, resultados[idx]));
    }

    // El Código de Acceso real de cada sección (no hay uno por alumno individual, es uno por
    // grado+turno+división) — se cachea por sección para no repetir la misma consulta si varios
    // alumnos encontrados comparten curso.
    const codigosPorSeccionCache = new Map<string, string | null>();
    const obtenerCodigoDeSeccion = async (a: any): Promise<string | null> => {
      const clave = `${a.colegio_id}__${a.grado}__${a.turno}__${a.division}`;
      if (codigosPorSeccionCache.has(clave)) return codigosPorSeccionCache.get(clave)!;
      const { data: fila } = await supabase
        .from('codigos_seccion')
        .select('codigo_secreto')
        .eq('colegio_id', a.colegio_id)
        .eq('grado', a.grado || '')
        .eq('turno', a.turno || '')
        .eq('division', a.division || '')
        .maybeSingle();
      const codigo = fila?.codigo_secreto || null;
      codigosPorSeccionCache.set(clave, codigo);
      return codigo;
    };

    const alumnosConDatos = await Promise.all(
      alumnosEncontrados.map(async (a) => {
        const pedidosDelColegio = pedidosPorColegio.get(a.colegio_id || '') || [];
        const claveExacta = normalizarNombreComparable(a.nombre);
        const clavePalabras = normalizarNombrePorPalabras(a.nombre);
        const pedidosDelAlumno = pedidosDelColegio.filter((p: any) => {
          const pClaveExacta = normalizarNombreComparable(p.alumno_nombre);
          const pClavePalabras = normalizarNombrePorPalabras(p.alumno_nombre);
          return pClaveExacta === claveExacta || pClavePalabras === clavePalabras;
        });
        const pedidoPagado = pedidosDelAlumno.find((p: any) => ESTADOS_PAGADOS.has(p.estado));
        const pedidoElegido = pedidoPagado || pedidosDelAlumno[pedidosDelAlumno.length - 1] || null;
        const codigoSeccion = await obtenerCodigoDeSeccion(a);

        return {
          id: a.id,
          nombre: a.nombre,
          dni: a.dni || null,
          grado: a.grado,
          division: a.division,
          turno: a.turno,
          numeroLista: a.numero_lista,
          colegioId: a.colegio_id,
          colegioNombre: mapaColegios.get(a.colegio_id) || null,
          codigoSeccion,
          pagado: !!pedidoPagado,
          otrosPedidos: pedidosDelAlumno.length > 1 ? pedidosDelAlumno.length - 1 : 0,
          pedido: pedidoElegido
            ? {
                id: pedidoElegido.id,
                numero: pedidoElegido.pedido_friendly_id || null,
                estado: pedidoElegido.estado,
                total: Number(pedidoElegido.total) || 0,
                kitNombre: pedidoElegido.kit_nombre,
                metodoPago: pedidoElegido.metodo_pago,
                fecha: pedidoElegido.created_at,
                tutorNombre: pedidoElegido.familias?.nombre || null,
                tutorTelefono: pedidoElegido.familias?.whatsapp || null,
                tutorEmail: pedidoElegido.familias?.email || null,
              }
            : null,
        };
      })
    );

    // Pedidos hallados directo por teléfono de la familia — se muestran aparte porque puede que
    // el nombre del alumno en ese pedido no matchee ningún alumno de la nómina cargada (typo,
    // alumno que ya no está en la lista, colegio sin nómina real cargada todavía, etc.), igual
    // que ya pasa en "Estado de pagos" con "Pedidos sin alumno en la nómina".
    const idsYaMostrados = new Set(alumnosConDatos.map((a) => a.pedido?.id).filter(Boolean));
    const pedidosSueltos = new Map<string, any>();
    for (const p of (pedidosPorTelefonoRes as any).data || []) pedidosSueltos.set(p.id, p);
    for (const p of ((pedidosPorNombreRes as any).data || []).filter((p: any) => coincidePorPalabras(p.alumno_nombre)).slice(0, 20)) {
      const deAlumnoMostrado = alumnosEncontrados.some((a) => a.colegio_id === p.colegio_id
        && (normalizarNombreComparable(a.nombre) === normalizarNombreComparable(p.alumno_nombre)
          || normalizarNombrePorPalabras(a.nombre) === normalizarNombrePorPalabras(p.alumno_nombre)));
      if (!idsYaMostrados.has(p.id) && !deAlumnoMostrado) pedidosSueltos.set(p.id, p);
    }
    const pedidosPorTelefono = Array.from(pedidosSueltos.values()).map((p: any) => ({
      id: p.id,
      numero: p.pedido_friendly_id || null,
      alumnoNombre: p.alumno_nombre,
      colegioNombre: p.colegio_nombre || mapaColegios.get(p.colegio_id) || null,
      grado: p.grado,
      division: p.division,
      estado: p.estado,
      total: Number(p.total) || 0,
      kitNombre: p.kit_nombre,
      fecha: p.created_at,
      tutorNombre: p.familias?.nombre || null,
      tutorTelefono: p.familias?.whatsapp || null,
    }));

    return res.json({ success: true, alumnos: alumnosConDatos, pedidosPorTelefono });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err?.message || 'Error al buscar alumnos' });
  }
});

// Importa alumnos a la nómina real (tabla 'alumnos') para un colegio puntual. No existía
// ninguna forma de cargar esta tabla desde el panel — se cargaba a mano, directo en Supabase.
// Pensado para pegar la lista tal cual sale de copiar un rango de Excel (número de lista +
// nombre separados por tab), una tanda por cada sección (grado/turno/división) del colegio.
rutas.post('/api/admin/alumnos/importar', requireAdminAuth, async (req: Request, res: Response) => {
  try {
    const { colegioId, filas } = req.body || {};
    if (!colegioId || typeof colegioId !== 'string') {
      return res.status(400).json({ success: false, error: 'Falta indicar el colegio' });
    }
    if (!Array.isArray(filas) || filas.length === 0) {
      return res.status(400).json({ success: false, error: 'No se recibieron filas para importar' });
    }
    if (filas.length > 500) {
      return res.status(400).json({ success: false, error: 'Demasiadas filas en un solo lote (máximo 500)' });
    }

    const supabase = getServerSupabase();
    if (!supabase) {
      return res.status(500).json({ success: false, error: 'Supabase no configurado en el servidor' });
    }

    const acotar = (valor: unknown, maxLen: number): string => String(valor ?? '').trim().slice(0, maxLen);

    const filasNormalizadas = filas
      .map((f: any) => ({
        colegio_id: colegioId,
        nombre: acotar(f.nombre, 200),
        grado: acotar(f.grado, 60),
        division: acotar(f.division, 60),
        turno: f.turno ? acotar(f.turno, 60) : null,
        numero_lista: Number.isFinite(Number(f.numeroLista)) ? Math.floor(Number(f.numeroLista)) : null,
        dni: f.dni ? acotar(f.dni, 30) : null,
        origen: 'importado_panel_admin',
      }))
      .filter((f: any) => f.nombre && f.grado && f.division);

    if (filasNormalizadas.length === 0) {
      return res.status(400).json({ success: false, error: 'Ninguna fila tiene los datos mínimos (nombre, grado y división)' });
    }

    // 14/10/2026: un reintento (respuesta perdida) no duplica la nómina: se saltean las que ya están.
    const { nuevas, repetidas } = await separarYaImportadas(supabase, 'alumnos', ['grado', 'division', 'turno', 'nombre'], filasNormalizadas);
    const { data, error } = nuevas.length ? await supabase.from('alumnos').insert(nuevas).select('id') : { data: [], error: null };
    if (error) throw error;
    return res.json({ success: true, importados: data?.length || 0, descartados: filas.length - filasNormalizadas.length, repetidos: repetidas });
  } catch (err: any) {
    console.error('Error al importar alumnos:', err);
    return res.status(500).json({ success: false, error: err?.message || 'Error al importar alumnos' });
  }
});

// Elimina un alumno puntual de la nómina (ej. para corregir un import duplicado o mal cargado).
rutas.delete('/api/admin/alumnos/:id', requireAdminAuth, async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const supabase = getServerSupabase();
    if (!supabase) {
      return res.status(500).json({ success: false, error: 'Supabase no configurado en el servidor' });
    }
    const { error } = await supabase.from('alumnos').delete().eq('id', id);
    if (error) throw error;
    return res.json({ success: true });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err?.message || 'Error al eliminar el alumno' });
  }
});

// Obtener todas las familias con datos de contacto (restringido al admin)
rutas.get('/api/admin/familias', requireAdminAuth, async (req, res) => {
  try {
    const supabase = getServerSupabase();
    if (!supabase) {
      return res.status(500).json({ success: false, error: 'Supabase no configurado en el servidor' });
    }
    // Paginado (ver traerTodasLasFilas): sin esto el listado se cortaba en 1000 familias.
    const data = await traerTodasLasFilas((desde, hasta) =>
      supabase.from('familias').select('*').order('created_at', { ascending: false }).order('id').range(desde, hasta)
    );
    return res.json({ success: true, familias: data });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err?.message || 'Error al obtener familias' });
  }
});

const COLUMNAS_PEDIDO_PANEL =
  'id, pedido_friendly_id, grupo_pago_id, created_at, updated_at, familia_id, colegio_id, colegio_nombre, curso_codigo, grado, division, turno, alumno_numero_lista, alumno_nombre, codigo_alumno, tipo_kit, kit_nombre, carpetas_impresas, total, metodo_pago, estado, estado_lab, seleccion_pendiente, archivado, en_espera, nota_espera, comprobante_subido_at, recordatorio_pago_at, descarga_hd_at, descargas_hd, fotos_seleccionadas, copias_extras, link_descarga_hd, email_enviado, fecha_envio_email, fecha_envio_produccion, fecha_envio_listo_retiro, fecha_entregado, lote_lab_id, cancelado_definitivo, mejora_de_pedido_id, pagado_at, transferencia_desde, transferencia_vencida_at, aviso_vencimiento_at';

// Obtener todos los pedidos
rutas.get('/api/admin/pedidos', requireAdminAuth, async (req, res) => {
  try {
    const supabase = getServerSupabase();
    if (!supabase) {
      return res.status(500).json({ success: false, error: 'Supabase no configurado en el servidor' });
    }
    // Auditoría 2026-09-09 (revisión a fondo): se suma el join con "familias" (nombre, whatsapp,
    // email) para que el panel pueda mostrar los datos del tutor sin depender de que el pedido
    // haya quedado además guardado en el localStorage del navegador de esa familia.
    // Auditoría 2026-09-22: se agrega colegio_id al join con familias para que el panel de
    // "Resumen de Kits" (ver server-side fix en resumenKitsService.ts) pueda agrupar por
    // colegio sin necesitar una consulta aparte.
    // Auditoría 2026-09-23 (bug real): sin paginar, PostgREST devuelve como máximo 1000 filas —
    // a partir del pedido 1001 el panel de Laboratorio dejaba de mostrar los pedidos más viejos
    // sin ningún aviso. Se pagina igual que "Nómina 2026" (ver traerTodasLasFilas).
    // Auditoría 03/10 (alto 16): con miles de pedidos la respuesta con `*` iba a pasar los 4,5 MB
    // de Vercel. Se piden sólo las columnas que usa el panel (construirPedidoCompletoDesdeFila en
    // pedidosLabService.ts y resumenKitsService.ts) + las del laboratorio; quedan afuera notas,
    // datos de la pasarela, términos, comprobante_path y la liquidación.
    const data = await traerTodasLasFilas((desde, hasta) =>
      supabase
        .from('pedidos')
        .select(`${COLUMNAS_PEDIDO_PANEL}, familias(nombre, whatsapp, email, colegio_id)`)
        .order('created_at', { ascending: false })
        .order('id')
        .range(desde, hasta)
    );
    return res.json({ success: true, pedidos: data });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err?.message || 'Error al obtener pedidos' });
  }
});

rutas.post('/api/admin/pedidos/notificar-estado', requireAdminAuth, async (req: Request, res: Response) => {
 try {
  const tipo = req.body?.tipo as TipoActualizacionPedido;
  // Auditoría 03/10 (alto 18): antes se cortaba en silencio en 100 destinatarios (el resto nunca se
  // avisaba ni se marcaba) y con muchos pedidos podía pasar los 60 s de Vercel. Ahora se procesa con
  // un presupuesto de tiempo y lo que no entra vuelve en `restantes` (ids) para que el panel lo reenvíe.
  const destinatarios = Array.isArray(req.body?.destinatarios) ? req.body.destinatarios : [];
  if (!['en_produccion', 'listo_retiro'].includes(tipo) || destinatarios.length === 0) return res.status(400).json({ success: false, error: 'Tipo de aviso o destinatarios inválidos.' });
  if (destinatarios.length > 5000) return res.status(400).json({ success: false, error: 'Demasiados destinatarios en un solo envío (máximo 5000).' });
  const inicioProceso = Date.now();
  const PRESUPUESTO_MS = 40 * 1000;
  const restantes: string[] = [];
  // 15/09: además del email, se guarda la etapa en pedidos.estado_lab (antes sólo salía el email).
  const supabase = getServerSupabase();
  // 20/09 (Pablo): los avisos se pueden reenviar, pero la fecha del panel es SIEMPRE la del primer envío
  // (.is(columna, null)); estado_lab y updated_at se actualizan siempre.
  // 14/10/2026 (auditoría): sólo es reenvío si el panel lo pide a propósito (`reenvio: true`, botón «Reenviar
  // aviso»). Sin eso, un pedido que YA está en esa etapa se saltea (`yaAvisados`): tras un corte de red o con
  // dos pestañas, repetir el envío no le duplica el email a la familia.
  const reenvioPedido = req.body?.reenvio === true;
  const yaAvisados: string[] = [];
  const columnaFecha = tipo === 'en_produccion' ? 'fecha_envio_produccion' : 'fecha_envio_listo_retiro';
  let enviados = 0;
  const errores: string[] = [];
  const resultados: { pedidoId: string; estadoLab: string; fechaEnvioProduccion?: string | null; fechaEnvioListoRetiro?: string | null }[] = [];
  // 20/09 (Pablo): se lee el estado_lab actual ANTES de mandar nada, para no saltear ni retroceder etapas.
  const estadosActuales = new Map<string, string | null>();
  // Auditoría 2026-09-24: estado de PAGO de cada pedido — no se manda a producción ni se avisa
  // "listo para retirar" un pedido que todavía no se cobró (antes nada lo impedía, y el panel
  // pasaba a mostrarlo como "Aprobado").
  const estadosPago = new Map<string, string>();
  // Pedidos que no pueden pasar por el laboratorio ahora (en espera, archivados o reservas sin fotos).
  const bloqueados = new Map<string, string>();
  if (supabase) {
    const idsValidos = [...new Set(destinatarios.map((d: any) => d?.pedidoId).filter((v: unknown) => typeof v === 'string' && /^[0-9a-f-]{36}$/i.test(v)))] as string[];
    if (idsValidos.length > 0) {
      // En tandas: una lista larga de ids en un solo .in() supera el largo máximo de la URL.
      let errorEstados: any = null;
      const filasActuales: any[] = [];
      for (const grupo of enLotes(idsValidos, 150)) {
        const { data, error } = await supabase
          .from('pedidos')
          .select('id, estado, estado_lab, en_espera, archivado, seleccion_pendiente, tipo_kit, lote_lab_id')
          .in('id', grupo);
        if (error) { errorEstados = error; break; }
        filasActuales.push(...(data || []));
      }
      // Auditoría 11/10: sin poder verificar pago/etapa no se avisa nada (antes seguía y avisaba a impagos).
      if (errorEstados) return res.status(503).json({ success: false, error: 'No se pudo verificar el estado de los pedidos. Probá de nuevo.' });
      {
        (filasActuales || []).forEach((fila: any) => {
          estadosActuales.set(fila.id, fila.estado_lab);
          estadosPago.set(fila.id, fila.estado);
          if (fila.en_espera) bloqueados.set(fila.id, 'está "En espera" — sacalo de espera antes de avisar la etapa de laboratorio.');
          else if (fila.archivado) bloqueados.set(fila.id, 'está archivado — desarchivalo antes de avisar la etapa de laboratorio.');
          else if (fila.seleccion_pendiente) bloqueados.set(fila.id, 'es un kit pagado por adelantado y la familia todavía no eligió sus fotos.');
          // Auditoría 03/10 (alto 20): un kit impreso que todavía no está en un lote del laboratorio
          // es justamente lo que el laboratorio tiene en su cola de "nuevos". Si el panel lo pasaba a
          // "En producción", desaparecía de esa cola (el lab sólo toma los que no tienen etapa) y
          // nunca se imprimía. Ese paso lo hace el laboratorio al marcar el lote.
          else if (tipo === 'en_produccion' && fila.tipo_kit !== 'solo_digital' && !fila.lote_lab_id && !fila.estado_lab) { // 29/10: también fotos extra
            bloqueados.set(fila.id, 'todavía no está en un lote del laboratorio: lo pasa a "En producción" el laboratorio cuando arma y marca el lote.');
          }
        });
      }
    }
  }
  let omitidos = 0;
  for (let indice = 0; indice < destinatarios.length; indice++) {
    const destinatario = destinatarios[indice];
    if (Date.now() - inicioProceso > PRESUPUESTO_MS) {
      for (const pendiente of destinatarios.slice(indice)) if (pendiente?.pedidoId) restantes.push(String(pendiente.pedidoId));
      break;
    }
    if (!destinatario?.to?.includes('@') || !destinatario?.pedidoId) { omitidos += 1; errores.push(`${destinatario?.alumnoNombre || 'Cliente'}: email o pedido inválido.`); continue; }
    // 20/09: puedeAvanzarEtapaLab (más abajo) bloquea saltear una etapa y retroceder una ya alcanzada.
    if (supabase && !['pagado', 'entregado'].includes(estadosPago.get(destinatario.pedidoId) as string)) {
      omitidos += 1;
      errores.push(`${destinatario.alumnoNombre || destinatario.to}: el pedido todavía no está pagado — aprobá el pago antes de avisar la etapa de laboratorio.`);
      continue;
    }
    if (bloqueados.has(destinatario.pedidoId)) {
      omitidos += 1;
      errores.push(`${destinatario.alumnoNombre || destinatario.to}: el pedido ${bloqueados.get(destinatario.pedidoId)}`);
      continue;
    }
    if (supabase && !puedeAvanzarEtapaLab(estadosActuales.get(destinatario.pedidoId) as EtapaLab | null, tipo)) {
      const etapaLegible = tipo === 'en_produccion' ? 'En producción' : 'Listo para retirar';
      omitidos += 1;
      errores.push(`${destinatario.alumnoNombre || destinatario.to}: no se puede pasar a "${etapaLegible}" desde el estado actual de ese pedido (evita saltos y retrocesos de etapa).`);
      continue;
    }
    const esReenvio = supabase !== null && estadosActuales.get(destinatario.pedidoId) === tipo;
    if (esReenvio && !reenvioPedido) { yaAvisados.push(String(destinatario.pedidoId)); continue; }
    try {
      await enviarCorreoActualizacionPedido({ tipo, ...destinatario, reenvio: esReenvio });
      enviados += 1;
      if (supabase) {
        const ahora = new Date().toISOString();
        // 1) Graba la fecha de "primera vez" sólo si todavía no existe.
        const { error: errorFecha } = await supabase
          .from('pedidos')
          .update({ [columnaFecha]: ahora })
          .eq('id', destinatario.pedidoId)
          .is(columnaFecha, null);
        if (errorFecha) console.warn(`[notificar-estado] Email enviado pero no se pudo guardar ${columnaFecha} para ${destinatario.pedidoId}:`, errorFecha.message);
        // 2) Actualiza el estado actual y updated_at siempre, sea primer envío o reenvío.
        const { data: filaActualizada, error: updateError } = await supabase
          .from('pedidos')
          .update({ estado_lab: tipo, updated_at: ahora })
          .eq('id', destinatario.pedidoId)
          .select('id, estado_lab, fecha_envio_produccion, fecha_envio_listo_retiro')
          .single();
        if (updateError) {
          console.warn(`[notificar-estado] Email enviado pero no se pudo guardar estado_lab para ${destinatario.pedidoId}:`, updateError.message);
        } else if (filaActualizada) {
          resultados.push({
            pedidoId: destinatario.pedidoId,
            estadoLab: filaActualizada.estado_lab,
            fechaEnvioProduccion: filaActualizada.fecha_envio_produccion,
            fechaEnvioListoRetiro: filaActualizada.fecha_envio_listo_retiro,
          });
        }
      }
    }
    catch (error: any) { errores.push(`${destinatario.alumnoNombre || destinatario.to}: ${error?.message || 'falló el envío'}`); }
  }
  // Si quedaron pendientes por tiempo y no se mandó nada todavía no es una falla: el panel reenvía `restantes`.
  // Auditoría 03/10 (2ª vuelta): si no salió ninguno, la respuesta trae el motivo en `error` (antes era
  // un 502 sin texto y el panel no explicaba nada, p. ej. con el bloqueo "kit impreso sin lote").
  // Todos omitidos por una regla = 409 (no es una falla del envío); si falló el envío = 502.
  if (enviados === 0 && restantes.length === 0 && errores.length > 0) {
    const motivo = errores[0] || 'No se envió ningún aviso.';
    const error = errores.length > 1 ? `${motivo} (y ${errores.length - 1} más)` : motivo;
    return res.status(omitidos > 0 && omitidos === errores.length ? 409 : 502).json({ success: false, error, enviados, omitidos, fallidos: errores.length, errores, resultados, restantes, yaAvisados: yaAvisados.length, idsYaAvisados: yaAvisados });
  }
  return res.status(200).json({ success: errores.length === 0, enviados, omitidos, fallidos: errores.length, errores, resultados, restantes, yaAvisados: yaAvisados.length, idsYaAvisados: yaAvisados });
 } catch (err: any) {
  // Auditoría 2026-09-21 (refuerzo): esta ruta era la única de todo el archivo sin try/catch
  // envolviendo todo el handler — si la consulta de estados actuales (más arriba) fallaba antes
  // de llegar al bucle, la promesa quedaba rechazada sin capturar y la respuesta nunca se
  // mandaba (el botón del panel se queda "colgado" en vez de mostrar un error).
  console.error('Error en /api/admin/pedidos/notificar-estado:', err);
  return res.status(500).json({ success: false, error: err?.message || 'Error al notificar el estado del pedido' });
 }
});

// Auditoría 2026-09-20 (revisión completa de estados, pedido de Pablo): hasta hoy no existía
// NINGÚN botón ni endpoint que registrara "la familia ya vino y retiró su pedido" — el pipeline
// del panel de Laboratorio se quedaba en "Listo para retirar" para siempre, sin forma de cerrar
// el círculo. El único lugar que modelaba un estado "entregado" era el valor 'entregado' de la
// columna de PAGO "estado" (mezclando cobro con entrega física), y nada lo escribía nunca. Este
// endpoint es la pieza que faltaba: usa estado_lab (el mismo campo de todo el pipeline físico,
// ver ETAPAS_LAB) en vez de tocar el estado de pago, y exige haber pasado por "listo_retiro"
// antes — no se puede marcar como retirado un pedido que nunca avisamos que estaba listo.
rutas.post('/api/admin/pedidos/:id/marcar-retirado', requireAdminAuth, async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const supabase = getServerSupabase();
    if (!supabase) return res.status(500).json({ success: false, error: 'Supabase no configurado en el servidor' });

    const { data: pedido, error: errorLectura } = await supabase
      .from('pedidos')
      .select('id, estado, estado_lab')
      .eq('id', id)
      .maybeSingle();
    if (errorLectura) throw errorLectura;
    if (!pedido) return res.status(404).json({ success: false, error: 'Pedido no encontrado' });
    if (!['pagado', 'entregado'].includes(pedido.estado)) {
      return res.status(409).json({ success: false, error: 'Este pedido todavía no está pagado — aprobá el pago antes de marcarlo como retirado.' });
    }

    if (!puedeAvanzarEtapaLab(pedido.estado_lab as EtapaLab | null, 'entregado')) {
      return res.status(409).json({
        success: false,
        error: 'Este pedido todavía no pasó por "Listo para retirar" — avisale a la familia antes de marcarlo como retirado.',
      });
    }

    const ahora = new Date().toISOString();
    // La fecha de retiro se graba una sola vez (igual que fecha_envio_produccion/listo_retiro),
    // por si en algún momento se necesita "reabrir" y volver a marcar sin perder la fecha real.
    const { error: errorFecha } = await supabase.from('pedidos').update({ fecha_entregado: ahora }).eq('id', id).is('fecha_entregado', null);
    if (errorFecha) throw errorFecha;
    const { data: filaActualizada, error: errorUpdate } = await supabase
      .from('pedidos')
      .update({ estado_lab: 'entregado', updated_at: ahora })
      .eq('id', id)
      .select('id, estado_lab, fecha_entregado')
      .single();
    if (errorUpdate) throw errorUpdate;

    return res.json({ success: true, estadoLab: filaActualizada.estado_lab, fechaEntregado: filaActualizada.fecha_entregado });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err?.message || 'Error al marcar el pedido como retirado' });
  }
});

// Auditoría 2026-09-21 (pedido de Pablo: poder escanear con el celular un QR impreso en el sobre
// físico del laboratorio, y que le muestre al toque el pedido para avisar "Listo para retirar" o
// "Marcar retirado" sin tener que buscarlo a mano en el panel completo). Vista liviana de un solo
// pedido — evita bajar el listado entero de pedidos al celular sólo para atender un escaneo.
rutas.get('/api/admin/pedidos/:id/resumen', requireAdminAuth, async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const supabase = getServerSupabase();
    if (!supabase) return res.status(500).json({ success: false, error: 'Supabase no configurado en el servidor' });

    const { data: pedido, error } = await supabase
      .from('pedidos')
      .select('id, pedido_friendly_id, alumno_nombre, colegio_nombre, grado, division, turno, estado, estado_lab, fecha_envio_produccion, fecha_envio_listo_retiro, fecha_entregado, email_enviado, link_descarga_hd, familias(nombre, whatsapp, email)')
      .eq('id', id)
      .maybeSingle();
    if (error) throw error;
    if (!pedido) return res.status(404).json({ success: false, error: 'Pedido no encontrado' });

    const familia: any = Array.isArray((pedido as any).familias) ? (pedido as any).familias[0] : (pedido as any).familias;

    return res.json({
      success: true,
      pedido: {
        id: pedido.id,
        pedidoFriendlyId: pedido.pedido_friendly_id,
        alumnoNombre: pedido.alumno_nombre,
        colegioNombre: pedido.colegio_nombre,
        grado: pedido.grado,
        division: pedido.division,
        turno: pedido.turno,
        estado: pedido.estado,
        estadoLab: pedido.estado_lab,
        fechaEnvioProduccion: pedido.fecha_envio_produccion,
        fechaEnvioListoRetiro: pedido.fecha_envio_listo_retiro,
        fechaEntregado: pedido.fecha_entregado,
        tutorNombre: familia?.nombre || null,
        tutorEmail: familia?.email || null,
        tutorWhatsapp: familia?.whatsapp || null,
        // 14/10: para releer el pedido antes de reintentar el HD o tras un corte al aprobar un pago.
        emailEnviado: Boolean((pedido as any).email_enviado), linkDescargaHD: (pedido as any).link_descarga_hd || null,
      },
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err?.message || 'Error al obtener el pedido' });
  }
});

// Genera el código QR (PNG) que se imprime en el sobre físico para el laboratorio: al escanearlo
// con la cámara del celular abre directamente la vista de arriba para ESE pedido puntual — como
// exige la sesión de admin (requireAdminAuth), quien escanee el sobre sin haber iniciado sesión
// como fotógrafo sólo ve la pantalla de PIN, nunca el nombre del alumno. No se guarda en ningún
// lado: se genera al vuelo cada vez que el panel lo pide, así que sigue sirviendo igual aunque
// cambie el dominio del sitio en el futuro.
rutas.get('/api/admin/pedidos/:id/qr', requireAdminAuth, async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const supabase = getServerSupabase();
    if (!supabase) return res.status(500).json({ success: false, error: 'Supabase no configurado en el servidor' });

    const { data: pedido, error } = await supabase.from('pedidos').select('id').eq('id', id).maybeSingle();
    if (error) throw error;
    if (!pedido) return res.status(404).json({ success: false, error: 'Pedido no encontrado' });

    const hostDetectado = req.get('host') || '';
    const esLocal = /^(localhost|127\.0\.0\.1)(:\d+)?$/i.test(hostDetectado);
    const protocoloFinal = esLocal ? req.protocol : 'https';
    const appUrl = (process.env.APP_URL || `${protocoloFinal}://${hostDetectado}`).replace(/\/+$/, '');
    const urlEscaneo = `${appUrl}/?escaneo=${encodeURIComponent(id)}`;

    const png = await QRCode.toBuffer(urlEscaneo, { type: 'png', width: 500, margin: 2 });
    res.setHeader('Content-Type', 'image/png');
    res.setHeader('Cache-Control', 'no-store');
    return res.send(png);
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err?.message || 'Error al generar el código QR' });
  }
});

// Actualizar estado de pedido (Pago o Entrega)
rutas.post('/api/admin/pedidos/:id/estado', requireAdminAuth, async (req, res) => {
  try {
    const { id } = req.params;
    // Auditoría 03/10: `reactivar: true` (explícito) es la única forma de sacarle el
    // cancelado_definitivo a un pedido; `estadoAnterior` (opcional) hace el cambio condicional.
    const { estadoPago, reactivar, estadoAnterior } = req.body || {};
    const supabase = getServerSupabase();
    if (!supabase) {
      return res.status(500).json({ success: false, error: 'Supabase no configurado en el servidor' });
    }

    // La tabla tiene UNA sola columna de pago ("estado"); el retiro físico va en estado_lab (marcar-retirado).
    // Ver auditorías 2026-09-09 y 2026-09-20.
    let nuevoEstado: string | undefined;
    if (estadoPago === 'aprobado' || estadoPago === 'pagado') {
      nuevoEstado = 'pagado';
    } else if (estadoPago === 'rechazado' || estadoPago === 'cancelado') {
      nuevoEstado = 'cancelado';
    } else if (estadoPago === 'pendiente') {
      nuevoEstado = 'pendiente_pago';
    }

    const updates: Record<string, any> = {
      updated_at: new Date().toISOString(),
    };
    if (nuevoEstado) {
      updates.estado = nuevoEstado;
      // Cancelado por el fotógrafo: ya no lo revive un pago que llegue después (ver ESTADOS_COBRABLES).
      // Auditoría 03/10: aprobar o pasar a pendiente ya no borra el cancelado_definitivo (lo dejaron
      // un arrepentimiento, un reembolso o el fotógrafo); sólo con reactivar: true.
      if (nuevoEstado === 'cancelado') updates.cancelado_definitivo = true;
      else if (reactivar === true) updates.cancelado_definitivo = false;
    }
    // Auditoría 2026-09-26 (B2): queda registrado cuándo se aprobó un pago A MANO desde el panel
    // (transferencia/efectivo), para poder distinguirlo de uno confirmado por la pasarela.
    if (nuevoEstado === 'pagado') {
      updates.aprobado_manual_at = new Date().toISOString();
    }
    // Auditoría 03/10 (2ª vuelta): un pedido que el fotógrafo vuelve a "pendiente de pago" (o
    // reactiva) arranca un plazo de transferencia nuevo de 48 h y deja de figurar como vencido (si
    // no, el portal le mostraba "se canceló por plazo" y no le dejaba subir el comprobante). Uno que
    // pasa a pagado tampoco queda marcado como vencido.
    // 10/10: con el plazo nuevo también vuelve el último aviso antes de vencer (a la familia y a Pablo).
    if (nuevoEstado === 'pendiente_pago') {
      updates.transferencia_vencida_at = null;
      updates.transferencia_desde = new Date().toISOString();
      updates.aviso_vencimiento_at = null;
    } else if (nuevoEstado === 'pagado') {
      updates.transferencia_vencida_at = null;
    }

    if (Object.keys(updates).length === 1) {
      // Llegó un estado intermedio que hoy no tiene columna propia en la base (ej: estados de
      // laboratorio internos como "laboratorio_listo") — no hay nada real para persistir acá,
      // así que no se hace ningún UPDATE. El panel sigue funcionando con su propio localStorage
      // para esa granularidad interna.
      return res.json({
        success: true,
        pedido: null,
        warning: 'Estado intermedio no persistido en Supabase (sin columna propia para esto).',
      });
    }

    // Auditoría 03/10: aprobación a mano CONDICIONAL. Antes pisaba cualquier estado (un pedido que
    // la pasarela acababa de pagar se volvía a "pagar" y re-enviaba el .zip; uno reembolsado volvía a
    // "pagado"). Ahora sólo aprueba si sigue cobrable y, salvo reactivar, si no está cancelado
    // definitivo; si el estado ya cambió, 409 y no se pisa nada.
    let consultaUpdate = supabase.from('pedidos').update(updates).eq('id', id);
    if (nuevoEstado === 'pagado') consultaUpdate = consultaUpdate.in('estado', ESTADOS_COBRABLES);
    // Auditoría 11/10: volver a pendiente o cancelar tampoco pisa un pedido ya cobrado (salvo forzar al cancelar).
    if (nuevoEstado === 'pendiente_pago') consultaUpdate = consultaUpdate.in('estado', ESTADOS_COBRABLES);
    if (nuevoEstado === 'cancelado' && req.body?.forzar !== true) consultaUpdate = consultaUpdate.in('estado', ESTADOS_COBRABLES);
    if (nuevoEstado && nuevoEstado !== 'cancelado' && reactivar !== true) consultaUpdate = consultaUpdate.eq('cancelado_definitivo', false);
    if (nuevoEstado && typeof estadoAnterior === 'string' && estadoAnterior) consultaUpdate = consultaUpdate.eq('estado', estadoAnterior);
    const { data, error } = await consultaUpdate.select();
    if (error) {
      // 08/10: reactivar una mejora a Kit Impreso cuando el kit ya tiene otra viva choca con el índice
      // único pedidos_mejora_viva_unica: se avisa claro en lugar de un error genérico.
      if (tipoChoqueUnicoPedido(error) === 'mejora') {
        return res.status(409).json({ success: false, codigo: 'MEJORA_DUPLICADA', error: 'Este kit ya tiene otra mejora a Kit Impreso activa. Cancelá esa antes de reactivar ésta.' });
      }
      throw error;
    }
    if (nuevoEstado && (!data || data.length === 0)) {
      const { data: actual } = await supabase.from('pedidos').select('id, estado, cancelado_definitivo').eq('id', id).maybeSingle();
      if (!actual) return res.status(404).json({ success: false, error: 'Pedido no encontrado' });
      if (actual.cancelado_definitivo && reactivar !== true && nuevoEstado !== 'cancelado') {
        return res.status(409).json({ success: false, codigo: 'CANCELADO_DEFINITIVO', estadoActual: actual.estado, error: 'Este pedido está cancelado definitivamente (por vos, por un arrepentimiento o por un reembolso). Si de verdad querés reactivarlo, confirmá la reactivación.' });
      }
      return res.status(409).json({ success: false, codigo: 'ESTADO_CAMBIO', estadoActual: actual.estado, error: `El pedido ya cambió de estado (ahora figura "${actual.estado}"). Recargá la lista antes de volver a intentarlo.` });
    }

    // Auditoría 2026-09-18 (reporte de Pablo): la automatización del .zip HD solo estaba
    // conectada a los webhooks de Mercado Pago y Nave. Cuando el admin aprueba un pago a mano
    // desde este botón (pagos en efectivo/transferencia), el pedido pasaba a "pagado" pero nunca
    // se generaba el .zip ni se guardaba el link de descarga — por eso el email salía sin el
    // link y el portal quedaba en "preparando tu descarga" para siempre. Se genera acá también,
    // igual que en los webhooks, cada vez que un pedido pasa a "pagado" por esta vía.
    let linkDescargaHD: string | null = null;
    if (nuevoEstado === 'pagado' && data?.[0]) {
      // Auditoría 05/10 (medio): una mejora a Kit Impreso aprobada a mano armaba un .zip HD inútil
      // (el digital ya salió con el pedido original) y la familia no recibía el correo de la mejora.
      if (data[0].seleccion_pendiente || esPedidoAdicional(data[0])) { // 29/10: + fotos extra (sin .zip)
        // Pago anticipado aprobado a mano (transferencia/efectivo): se le confirma la reserva.
        const { data: conFamilia } = await supabase.from('pedidos').select('*, familias(nombre, whatsapp, email)').eq('id', data[0].id);
        await procesarPedidosRecienPagados(supabase, conFamilia || []);
      } else {
        linkDescargaHD = await generarYSubirZipHDParaPedido(supabase, data[0]);
      }
    }

    return res.json({ success: true, pedido: data?.[0], linkDescargaHD: linkDescargaHD || undefined });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err?.message || 'Error al actualizar pedido' });
  }
});

// Organizar un pedido desde el panel sin borrarlo (pedido de Pablo, 25/9): archivar/desarchivar y
// poner/sacar "en espera" con una nota. Ver la migración 20260925010000_pedidos_archivado_en_espera.
rutasOrganizar.post('/api/admin/pedidos/:id/organizar', requireAdminAuth, async (req, res) => {
  try {
    const { id } = req.params;
    const { archivado, enEspera, notaEspera } = req.body || {};
    const supabase = getServerSupabase();
    if (!supabase) return res.status(500).json({ success: false, error: 'Supabase no configurado' });

    const updates: Record<string, any> = { updated_at: new Date().toISOString() };
    if (typeof archivado === 'boolean') updates.archivado = archivado;
    if (typeof enEspera === 'boolean') {
      updates.en_espera = enEspera;
      updates.nota_espera = enEspera ? String(notaEspera || '').trim().slice(0, 300) || null : null;
    }
    if (Object.keys(updates).length === 1) return res.status(400).json({ success: false, error: 'No se indicó ningún cambio.' });

    const { data, error } = await supabase.from('pedidos').update(updates).eq('id', id).select('id, archivado, en_espera, nota_espera');
    if (error) throw error;
    if (!data?.[0]) return res.status(404).json({ success: false, error: 'No se encontró el pedido.' });
    return res.json({ success: true, archivado: data[0].archivado, enEspera: data[0].en_espera, notaEspera: data[0].nota_espera || '' });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err?.message || 'Error al organizar el pedido' });
  }
});

// Eliminar pedido protegido
rutasBorrar.delete('/api/admin/pedidos/:id', requireAdminAuth, async (req, res) => {
  try {
    const { id } = req.params;
    const supabase = getServerSupabase();
    if (!supabase) {
      return res.status(500).json({ success: false, error: 'Supabase no configurado' });
    }

    // Auditoría 05/10: antes se borraba sin mirar el estado. Un pedido pagado/entregado (o ya en un
    // lote del laboratorio) no se borra salvo `forzar`: la familia perdía la descarga HD y el pedido
    // desaparecía del laboratorio y de la liquidación. El panel pide una confirmación específica.
    const { data: filaPedido, error: errorLectura } = await supabase
      .from('pedidos')
      .select('id, estado, cancelado_definitivo, lote_lab_id, estado_lab, pedido_friendly_id, comprobante_path')
      .eq('id', id)
      .maybeSingle();
    if (errorLectura) throw errorLectura;
    if (!filaPedido) return res.json({ success: true });
    const forzar = req.query.forzar === '1' || (req.body && (req.body as any).forzar === true);
    const motivoProteccion = motivoPedidoProtegidoParaBorrar(filaPedido);
    if (motivoProteccion && !forzar) {
      return res.status(409).json({
        success: false,
        codigo: 'PEDIDO_PAGADO',
        pedidoFriendlyId: filaPedido.pedido_friendly_id || null,
        error: `Este pedido ${motivoProteccion} (${filaPedido.pedido_friendly_id || id}). Si lo borrás, la familia pierde la descarga HD y el pedido desaparece del laboratorio y de la liquidación. Confirmá el borrado forzado.`,
      });
    }

    const { error: errorFotos } = await supabase.from('pedido_fotos').delete().eq('pedido_id', id);
    if (errorFotos) throw errorFotos;
    const { error } = await supabase.from('pedidos').delete().eq('id', id);
    if (error) throw error;
    // Auditoría 11/10: el comprobante de transferencia se borra si ningún otro pedido (hermano del carrito) lo usa.
    const advertencia = await borrarComprobantesSinUso(supabase, [filaPedido.comprobante_path]);
    return res.json({ success: true, ...(advertencia ? { advertencia } : {}) });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err?.message || 'Error al eliminar pedido' });
  }
});

// Auditoría 05/10: motivo por el que un pedido no se debe borrar sin confirmación forzada
// (null = se puede borrar). Pagado/entregado, o ya dentro de un lote del laboratorio.
function motivoPedidoProtegidoParaBorrar(fila: { estado?: string | null; cancelado_definitivo?: boolean | null; lote_lab_id?: string | null }): string | null {
  if (!fila || fila.cancelado_definitivo === true) return null;
  const estado = String(fila.estado || '');
  if (estado === 'pagado') return 'está PAGADO';
  if (estado === 'entregado') return 'está ENTREGADO';
  if (fila.lote_lab_id) return 'ya está en un lote del laboratorio';
  return null;
}

export { rutas as rutasPanelPedidos, rutasOrganizar as rutasOrganizarPedido, rutasBorrar as rutasBorrarPedido };
