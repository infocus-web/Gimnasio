// "Estado del sistema" del panel (/api/admin/salud) y reporte de errores (/api/errores/reportar,
// bandeja /api/admin/errores) (división de server.ts, etapa 4, 10/10/2026). El código es el mismo
// que estaba en server.ts: sólo se movió de lugar. `recortarJson` pasó al núcleo (servidor/nucleo/alertas.ts) en la etapa 5.
import express from 'express';
import type { Request, Response } from 'express';
import { getAdminPin, getLabPin, requireAdminAuth, verifyAdminToken } from '../nucleo/auth.js';
import { casillaAvisosAdmin, getResendClient, getServerSupabase } from '../nucleo/clientes.js';
import { hayCupoGlobal, limitarFrecuencia, limitarFrecuenciaPersistente } from '../nucleo/limites.js';
import { recortarJson } from '../nucleo/alertas.js';
import { escapeHtml } from '../nucleo/utilidades.js';

const rutas = express.Router();

// "Estado del sistema" (preparación temporada 25/9): un vistazo rápido para el panel de lo que
// puede necesitar atención — pagos sin descarga HD o sin correo, transferencias por aprobar,
// consultas nuevas y si los controles automáticos están corriendo.
rutas.get('/api/admin/salud', requireAdminAuth, async (_req, res) => {
  try {
    const supabase = getServerSupabase();
    if (!supabase) return res.status(500).json({ success: false, error: 'Supabase no configurado' });
    const hace15min = new Date(Date.now() - 15 * 60 * 1000).toISOString();
    const contar = async (consulta: any) => {
      const { count, error } = await consulta;
      if (error) throw error;
      return count || 0;
    };
    const base = () => supabase.from('pedidos').select('id', { count: 'exact', head: true });
    const [pagadosSinHD, pagadosSinEmail, transferenciasPendientes, consultasNuevas, tareas, erroresNuevos] = await Promise.all([
      // Auditoría 05/10: las mejoras a Kit Impreso (mejora_de_pedido_id) no tienen .zip propio: el HD ya
      // se entregó con el pedido original. Sin este filtro figuraban como "HD pendiente" para siempre.
      contar(base().eq('estado', 'pagado').eq('seleccion_pendiente', false).is('mejora_de_pedido_id', null).neq('tipo_kit', 'fotos_extra').or('link_descarga_hd.is.null,link_descarga_hd.eq.').lt('updated_at', hace15min)),
      contar(base().eq('estado', 'pagado').eq('email_enviado', false).lt('updated_at', hace15min)),
      contar(base().eq('estado', 'pendiente_pago').eq('metodo_pago', 'transferencia').eq('archivado', false).not('comprobante_subido_at', 'is', null)),
      contar(supabase.from('consultas_familias').select('id', { count: 'exact', head: true }).eq('estado', 'nueva')),
      supabase.from('tareas_programadas_estado').select('nombre, ultima_ejecucion, resultado'),
      contar(supabase.from('reportes_errores').select('id', { count: 'exact', head: true }).eq('estado', 'nuevo')),
    ]);
    // Auditoría 11/10: si no se pudo leer, no mostrar los controles como "sin correr".
    if ((tareas as any).error) throw (tareas as any).error;
    return res.json({
      success: true,
      pagadosSinHD,
      pagadosSinEmail,
      transferenciasPendientes,
      consultasNuevas,
      tareas: (tareas as any).data || [],
      erroresNuevos,
      // Auditoría 03/10 noche (M15): Vercel guarda los PIN como "sensibles" (no se pueden leer desde
      // afuera). Acá sólo se informa si son cortos, nunca su valor.
      pinesCortos: {
        admin: (getAdminPin() || '').length < 12,
        lab: (getLabPin() || '').length > 0 && (getLabPin() || '').length < 12,
      },
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err?.message || 'No se pudo leer el estado.' });
  }
});

// Reportes de error "Avisar al equipo técnico" (pedido de Pablo 25/9): la web junta sola el
// contexto (pantalla, paso, pedido, últimas llamadas que fallaron con su respuesta) y con un
// botón lo guarda acá y avisa por email. Público a propósito (lo usan las familias), con límite
// por IP y todo truncado para que no se pueda usar para llenar la base.
const avisosErrorEnviados: number[] = [];

// Auditoría 03/10 (medio): el tope era sólo en memoria (cada instancia de Vercel con el suyo) y no
// había tope total de filas: con muchas IPs se llenaba reportes_errores. Ahora: límite persistente por
// IP (además del de memoria, que frena primero sin ir a la base) y un cupo GLOBAL de reportes por hora.
rutas.post('/api/errores/reportar', limitarFrecuencia('errores-reportar', 30, 10 * 60 * 1000), limitarFrecuenciaPersistente('errores-reportar-ip', 40, 10 * 60 * 1000), async (req: Request, res: Response) => {
  try {
    const supabase = getServerSupabase();
    if (!supabase) return res.status(500).json({ success: false, error: 'Supabase no configurado' });
    if (!(await hayCupoGlobal('errores-reportar', 600, 3600))) {
      return res.status(429).json({ success: false, error: 'Estamos recibiendo muchos reportes en este momento. Probá de nuevo en un rato.' });
    }
    const body = req.body || {};
    const mensaje = String(body.mensaje || '').trim().slice(0, 1000) || 'Error sin mensaje';
    // Auditoría 03/10 noche (M6): esta ruta es pública. Sólo se guarda como 'admin' (igual que las
    // alertas que genera el servidor) si viene una sesión de admin válida; si no, siempre 'familia'.
    // Antes cualquiera podía fabricar una alerta de pago con apariencia oficial ("devolvé $X").
    const authHeader = String(req.headers.authorization || '');
    const tokenAdmin = authHeader.startsWith('Bearer ') ? authHeader.substring(7) : String(req.headers['x-admin-token'] || '');
    const origen = body.origen === 'admin' && verifyAdminToken(tokenAdmin) ? 'admin' : 'familia';
    const emailCrudo = String(body.email || '').trim().toLowerCase().slice(0, 200);
    const email = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(emailCrudo) ? emailCrudo : null;
    const detalle = recortarJson(body.detalle, 20000);
    // Auditoría 03/10 noche (M6): `clave` y `tipo` son de las alertas del servidor (con `clave` se
    // evita repetir una alerta): un reporte de afuera con la misma clave silenciaba la alerta real
    // (p. ej. la de un contracargo). Se guardan aparte.
    if (detalle && typeof detalle === 'object' && !Array.isArray(detalle)) {
      for (const reservada of ['clave', 'tipo']) {
        if (reservada in (detalle as any)) {
          (detalle as any)[`${reservada}_cliente`] = (detalle as any)[reservada];
          delete (detalle as any)[reservada];
        }
      }
    }
    // Reportes automáticos (2/10): firma del error sin números ni ids, para no mandar un email por
    // cada repetición del mismo problema (queda guardado igual; el email sale una vez cada 6 h).
    const automatico = Boolean(detalle && typeof detalle === 'object' && (detalle as any).automatico);
    const firma = mensaje.replace(/[0-9a-f]{8}-[0-9a-f-]{27,}/gi, '#').replace(/\d+/g, '#').slice(0, 200);
    if (detalle && typeof detalle === 'object') (detalle as any).firma = firma;
    const url = String(body.url || '').slice(0, 500) || null;
    const userAgent = String(req.headers['user-agent'] || '').slice(0, 300) || null;
    const codigo = `ERR-${Math.random().toString(36).slice(2, 7).toUpperCase()}`;

    const { error } = await supabase.from('reportes_errores').insert({
      codigo,
      origen,
      mensaje,
      detalle,
      url,
      user_agent: userAgent,
      email_contacto: email,
    });
    if (error) throw error;

    // Auditoría 2026-09-27: como mucho 20 avisos por email por hora (el reporte queda guardado
    // igual en el panel); evita que alguien llene la casilla mandando reportes en cadena.
    const ahoraAviso = Date.now();
    avisosErrorEnviados.splice(0, avisosErrorEnviados.length, ...avisosErrorEnviados.filter((t) => ahoraAviso - t < 60 * 60 * 1000));
    let repetido = false;
    if (automatico) {
      const { count } = await supabase
        .from('reportes_errores')
        .select('id', { count: 'exact', head: true })
        .eq('detalle->>firma', firma)
        .neq('codigo', codigo)
        .gte('created_at', new Date(ahoraAviso - 6 * 60 * 60 * 1000).toISOString());
      repetido = (count || 0) > 0;
    }
    const resend = avisosErrorEnviados.length < 20 && !repetido && (await hayCupoGlobal('aviso-error-email', 30, 3600)) ? getResendClient() : null;
    if (resend) {
      avisosErrorEnviados.push(ahoraAviso);
      const destino = casillaAvisosAdmin();
      const fallas = Array.isArray(detalle?.eventos)
        ? detalle.eventos
            .slice(-6)
            .map((e: any) => `<li style="margin-bottom:6px"><code>${escapeHtml(String(e?.resumen || '').slice(0, 400))}</code></li>`)
            .join('')
        : '';
      const aviso = await resend.emails.send({
        from: process.env.RESEND_FROM_EMAIL || 'Retrato Escolar <fotos@retratoescolar.com.ar>',
        ...(email ? { replyTo: email } : {}),
        to: [destino],
        subject: `⚠️ ${automatico ? 'Error detectado' : 'Error reportado'} ${codigo}: ${mensaje.replace(/^\[Automático\] /, '').slice(0, 80)}`,
        html: `<div style="font-family:Arial,sans-serif;max-width:640px;margin:auto;color:#0f172a"><h2>${automatico ? `La web detectó un error mientras la usaba ${origen === 'admin' ? 'alguien del panel' : 'una familia'} (aviso automático)` : `Una ${origen === 'admin' ? 'persona del panel' : 'familia'} reportó un error`}</h2><p><strong>Código:</strong> ${escapeHtml(codigo)}</p><p><strong>Mensaje:</strong> ${escapeHtml(mensaje)}</p>${email ? `<p><strong>Email:</strong> ${escapeHtml(email)}</p>` : ''}${url ? `<p><strong>Página:</strong> ${escapeHtml(url)}</p>` : ''}${fallas ? `<p><strong>Últimas fallas registradas:</strong></p><ul>${fallas}</ul>` : ''}<p style="font-size:12px;color:#64748b">El detalle completo está en el panel → Estado del sistema → Errores reportados. Pasale el código ${escapeHtml(codigo)} a Claude para que lo revise.</p></div>`,
      });
      if (aviso.error) console.error('[Errores] No se pudo enviar el aviso por email:', aviso.error);
    }
    console.warn(`[Errores] Reporte ${codigo} (${origen}): ${mensaje}`);
    return res.status(201).json({ success: true, codigo });
  } catch (err: any) {
    console.error('[Errores] No se pudo guardar el reporte:', err);
    return res.status(500).json({ success: false, error: 'No pudimos enviar el reporte.' });
  }
});

rutas.get('/api/admin/errores', requireAdminAuth, async (req: Request, res: Response) => {
  const supabase = getServerSupabase();
  if (!supabase) return res.status(500).json({ success: false, error: 'Supabase no configurado' });
  const verResueltos = req.query.resueltos === '1';
  // Auditoría 03/10 noche (M6): las alertas del servidor y los reportes de familias se traen por
  // separado (100 de cada uno): una ráfaga de reportes de afuera ya no saca de la lista las alertas
  // de pagos.
  const traer = (origen: string) => {
    let consulta = supabase.from('reportes_errores').select('*').eq('origen', origen).order('created_at', { ascending: false }).limit(100);
    if (!verResueltos) consulta = consulta.eq('estado', 'nuevo');
    return consulta;
  };
  const [admin, familias] = await Promise.all([traer('admin'), traer('familia')]);
  const error = admin.error || familias.error;
  if (error) return res.status(500).json({ success: false, error: error.message });
  const reportes = [...(admin.data || []), ...(familias.data || [])].sort((a: any, b: any) => String(b.created_at).localeCompare(String(a.created_at)));
  return res.json({ success: true, reportes });
});

rutas.post('/api/admin/errores/:id/resolver', requireAdminAuth, async (req: Request, res: Response) => {
  const supabase = getServerSupabase();
  if (!supabase) return res.status(500).json({ success: false, error: 'Supabase no configurado' });
  const { error } = await supabase
    .from('reportes_errores')
    .update({ estado: 'resuelto', resuelto_at: new Date().toISOString() })
    .eq('id', req.params.id);
  if (error) return res.status(500).json({ success: false, error: error.message });
  return res.json({ success: true });
});

export { rutas as rutasSaludErrores };
