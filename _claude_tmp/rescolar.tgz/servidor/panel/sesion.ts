// Sesión del panel: login con PIN, verificación del token y modo mantenimiento (división de server.ts,
// etapa 5, 10/10/2026). El código es el mismo que estaba en las secciones "3. RUTAS DE AUTENTICACIÓN
// ADMIN" y "MODO MANTENIMIENTO" de server.ts: sólo se movió de lugar.
import type { SupabaseClient } from '@supabase/supabase-js';
import crypto from 'crypto';
import express from 'express';
import type { Request, Response } from 'express';
import { generateAdminToken, getAdminPin, getAdminSessionSecret, normalizePin, pinAdminCorrecto, requireAdminAuth, verifyAdminToken } from '../nucleo/auth.js';
import { getServerSupabase } from '../nucleo/clientes.js';
import { alertarIntentosLoginMasivos, hayCupoPorClave, limitarFrecuenciaPersistente } from '../nucleo/limites.js';

import { CLAVE_CONFIG_MANTENIMIENTO, COOKIE_MANTENIMIENTO, crearLlaveMantenimiento, DURACION_LLAVE_MANTENIMIENTO_SEG } from '../../mantenimiento/llave.js';
const rutas = express.Router();

// ==============================================================================
// 3. RUTAS DE AUTENTICACIÓN ADMIN
// ==============================================================================

// Login de administrador con PIN
// Auditoría 30/9: además del límite por IP, un tope total por hora (un ataque desde muchas IPs).
// Auditoría 03/10: el total ya no bloquea (dejaba afuera a Pablo); sólo alerta (ver alertarIntentosLoginMasivos).
rutas.post('/api/admin/login', limitarFrecuenciaPersistente('admin-login', 8, 15 * 60 * 1000), alertarIntentosLoginMasivos('admin-login-total', 60), (req, res) => {
  const adminPin = getAdminPin();
  if (!adminPin) {
    return res.status(500).json({
      success: false,
      error: 'ADMIN_PIN no configurado en las variables de entorno del servidor.',
    });
  }

  const sessionSecret = getAdminSessionSecret();
  if (!sessionSecret) {
    return res.status(500).json({
      success: false,
      error: 'ADMIN_SESSION_SECRET no configurada en las variables de entorno del servidor.',
    });
  }

  // String(): si llegaba un número (ej. {"pin": 1234}) normalizePin hacía .trim() sobre un
  // número y el handler explotaba con un 500 en vez de responder "PIN incorrecto".
  const pin = req.body?.pin === undefined || req.body?.pin === null ? '' : String(req.body.pin);
  if (!pin) {
    return res.status(400).json({ success: false, error: 'PIN requerido' });
  }

  const expectedNormalized = normalizePin(adminPin);
  const inputNormalized = normalizePin(pin);

  const expectedBuf = Buffer.from(expectedNormalized);
  const inputBuf = Buffer.from(inputNormalized);

  const isValid =
    expectedBuf.length === inputBuf.length &&
    crypto.timingSafeEqual(expectedBuf, inputBuf);

  if (isValid) {
    const token = generateAdminToken();
    if (!token) {
      return res.status(500).json({ success: false, error: 'Error al generar token de sesión.' });
    }
    return res.json({
      success: true,
      token,
      expiresIn: 86400,
    });
  }

  return res.status(401).json({
    success: false,
    error: 'PIN de fotógrafo administrador incorrecto.',
  });
});

// Verificación de token activo
rutas.get('/api/admin/verify', (req, res) => {
  const authHeader = req.headers.authorization;
  const token = authHeader?.startsWith('Bearer ')
    ? authHeader.substring(7)
    : (req.headers['x-admin-token'] as string);

  const valid = verifyAdminToken(token);
  return res.json({ valid });
});

// ==============================================================================
// MODO MANTENIMIENTO (09/10/2026, pedido de Pablo). La pantalla la muestra middleware.ts (raíz);
// acá están el ingreso de Pablo desde esa pantalla y el interruptor del panel. Ver mantenimiento/llave.ts.
// ==============================================================================


// Formulario sin JavaScript de la pantalla de mantenimiento: PIN correcto → cookie con la llave firmada
// (24 h) y vuelta a la portada. Comparte el tope de intentos con el login del panel ('admin-login').
rutas.post('/api/mantenimiento/acceso', express.urlencoded({ extended: false, limit: '2kb' }), async (req: Request, res: Response) => {
  try {
    const dentroDelTope = await hayCupoPorClave(`admin-login:${req.ip || 'desconocida'}`, 8, 15 * 60);
    if (!dentroDelTope) return res.redirect(303, '/?mantenimiento=muchos');
    const secreto = getAdminSessionSecret();
    if (!secreto || !pinAdminCorrecto(req.body?.pin)) return res.redirect(303, '/?mantenimiento=pin');
    const llave = await crearLlaveMantenimiento(secreto);
    res.setHeader('Set-Cookie', `${COOKIE_MANTENIMIENTO}=${llave}; Path=/; Max-Age=${DURACION_LLAVE_MANTENIMIENTO_SEG}; HttpOnly; Secure; SameSite=Lax`);
    return res.redirect(303, '/');
  } catch (err) {
    console.error('[mantenimiento] Error en el ingreso:', err);
    return res.redirect(303, '/?mantenimiento=pin');
  }
});

async function leerModoMantenimiento(supabase: SupabaseClient) {
  const { data, error } = await supabase.from('configuracion').select('valor, datos_extra').eq('clave', CLAVE_CONFIG_MANTENIMIENTO).maybeSingle();
  if (error) throw error;
  return { activo: data?.valor === 'activo', desde: (data?.datos_extra as any)?.desde || null };
}

rutas.get('/api/admin/mantenimiento', requireAdminAuth, async (_req: Request, res: Response) => {
  try {
    const supabase = getServerSupabase();
    if (!supabase) return res.status(503).json({ success: false, error: 'Servicio no disponible' });
    return res.json({ success: true, ...(await leerModoMantenimiento(supabase)) });
  } catch (err) {
    console.error('[mantenimiento] No se pudo leer el estado:', err);
    return res.status(500).json({ success: false, error: 'No se pudo leer el modo mantenimiento.' });
  }
});

rutas.post('/api/admin/mantenimiento', requireAdminAuth, async (req: Request, res: Response) => {
  try {
    if (typeof req.body?.activo !== 'boolean') return res.status(400).json({ success: false, error: 'Falta indicar si se prende o se apaga.' });
    const supabase = getServerSupabase();
    if (!supabase) return res.status(503).json({ success: false, error: 'Servicio no disponible' });
    const ahora = new Date().toISOString();
    const { error } = await supabase.from('configuracion').upsert(
      [{ clave: CLAVE_CONFIG_MANTENIMIENTO, valor: req.body.activo ? 'activo' : 'inactivo', datos_extra: { desde: ahora }, updated_at: ahora }],
      { onConflict: 'clave' }
    );
    if (error) throw error;
    // Quien lo prende desde el panel queda habilitado en ese navegador (si no, se quedaría afuera).
    const secreto = getAdminSessionSecret();
    if (req.body.activo && secreto) {
      const llave = await crearLlaveMantenimiento(secreto);
      res.setHeader('Set-Cookie', `${COOKIE_MANTENIMIENTO}=${llave}; Path=/; Max-Age=${DURACION_LLAVE_MANTENIMIENTO_SEG}; HttpOnly; Secure; SameSite=Lax`);
    }
    return res.json({ success: true, ...(await leerModoMantenimiento(supabase)) });
  } catch (err) {
    console.error('[mantenimiento] No se pudo cambiar el estado:', err);
    return res.status(500).json({ success: false, error: 'No se pudo cambiar el modo mantenimiento.' });
  }
});

export { rutas as rutasSesionAdmin };
