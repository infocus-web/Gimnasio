// Panel del laboratorio (/laboratorio): login con LAB_PIN, pedidos pagados con impresión, originales,
// lotes, resumen para facturar, reimpresiones, reporte de problemas y el aviso diario por email
// (división de server.ts, etapa 4, 10/10/2026). El código es el mismo que estaba en la sección "4E.
// PANEL DEL LABORATORIO" de server.ts: sólo se movió de lugar.
import type { SupabaseClient } from '@supabase/supabase-js';
import crypto from 'crypto';
import express from 'express';
import type { Request, Response } from 'express';
import { enviarCorreoActualizacionPedido } from '../entrega/correos.js';
import { autorizarTareaProgramada, compararTimingSafe, generarTokenLab, getLabPin, normalizePin, requireLabAuth } from '../nucleo/auth.js';
import { casillaAvisosAdmin, getResendClient, getServerSupabase } from '../nucleo/clientes.js';
import { alertarIntentosLoginMasivos, limitarFrecuencia, limitarFrecuenciaPersistente } from '../nucleo/limites.js';
import { contarImpresionesPedido, puedeAvanzarEtapaLab } from '../nucleo/pedidos.js';
import type { EtapaLab } from '../nucleo/pedidos.js';
import { enLotes, escapeHtml, traerTodasLasFilas } from '../nucleo/utilidades.js';
import { responderUrlFirmadaOriginal } from './fotos.js';
import { pedidosExtrasParaLaboratorio } from './laboratorioExtras.js';

const rutas = express.Router();

// ==============================================================================
// 4E. PANEL DEL LABORATORIO (27/9/2026, pedido de Pablo)
// Acceso propio con LAB_PIN (variable de entorno). El laboratorio sólo ve los pedidos PAGADOS con
// impresión, sin datos de contacto de las familias; descarga el ZIP/Excel por lotes (sin repetir),
// marca un lote "En producción" (eso avisa a cada familia por email) y puede reportar problemas.
// El token del laboratorio tiene otra forma que el del admin ("lab.<ts>.<rand>.<firma>"): no sirve
// para ninguna ruta del panel del fotógrafo. El panel del fotógrafo sí puede usar estas rutas.
// ==============================================================================


// Auditoría 30/9: límite guardado en la base (el de memoria se reinicia en cada instancia de Vercel).
rutas.post('/api/lab/login', limitarFrecuenciaPersistente('lab-login', 8, 15 * 60 * 1000), alertarIntentosLoginMasivos('lab-login-total', 60), (req: Request, res: Response) => {
  const labPin = getLabPin();
  if (!labPin) return res.status(503).json({ success: false, error: 'El panel del laboratorio todavía no está activado.' });
  const pin = normalizePin(String(req.body?.pin ?? ''));
  if (!pin) return res.status(400).json({ success: false, error: 'Ingresá el PIN.' });
  if (!compararTimingSafe(pin, normalizePin(labPin))) {
    return res.status(401).json({ success: false, error: 'PIN incorrecto.' });
  }
  const token = generarTokenLab();
  if (!token) return res.status(500).json({ success: false, error: 'No se pudo iniciar la sesión.' });
  return res.json({ success: true, token, expiresIn: 12 * 60 * 60 });
});

// Columnas que ve el laboratorio: nada de contacto, pagos, comprobantes ni links de descarga.
const COLUMNAS_PEDIDO_LAB =
  'id, pedido_friendly_id, created_at, colegio_id, colegio_nombre, curso_codigo, grado, division, turno, alumno_nombre, alumno_numero_lista, codigo_alumno, tipo_kit, kit_nombre, carpetas_impresas, copias_extras, fotos_seleccionadas, estado, estado_lab, seleccion_pendiente, lote_lab_id, mejora_de_pedido_id, fecha_envio_produccion';

/** Pedidos que corresponden al laboratorio: cobrados, con impresión, con fotos elegidas y activos. */
async function pedidosParaLaboratorio(supabase: SupabaseClient) {
  const filas = await traerTodasLasFilas<any>((desde, hasta) =>
    supabase
      .from('pedidos')
      .select(COLUMNAS_PEDIDO_LAB)
      .in('estado', ['pagado', 'entregado'])
      .eq('tipo_kit', 'impreso_digital')
      .eq('seleccion_pendiente', false)
      .eq('en_espera', false)
      .eq('archivado', false)
      .order('created_at', { ascending: true })
      .order('id')
      .range(desde, hasta)
  );
  return filas;
}

// Auditoría 05/10: pedidos de cada lote que ya NO están pagados/entregados (cancelados después de
// armar el lote): el laboratorio no debe imprimirlos. Sólo número de pedido y alumno, sin contacto.
function agruparAnuladosPorLote(filas: any[]): Map<string, { friendlyId: string; alumno: string }[]> {
  const porLote = new Map<string, { friendlyId: string; alumno: string }[]>();
  for (const f of filas || []) {
    if (!f?.lote_lab_id || ['pagado', 'entregado'].includes(String(f.estado))) continue;
    const lista = porLote.get(f.lote_lab_id) || [];
    lista.push({ friendlyId: f.pedido_friendly_id || String(f.id || '').slice(0, 8), alumno: f.alumno_nombre || '' });
    porLote.set(f.lote_lab_id, lista);
  }
  return porLote;
}

async function anuladosDeLotesLab(supabase: SupabaseClient, loteIds: string[]): Promise<Map<string, { friendlyId: string; alumno: string }[]>> {
  const filas: any[] = [];
  for (const grupo of enLotes(loteIds, 100)) {
    const { data, error } = await supabase
      .from('pedidos')
      .select('id, pedido_friendly_id, alumno_nombre, estado, lote_lab_id')
      .in('lote_lab_id', grupo)
      .not('estado', 'in', '(pagado,entregado)')
      .limit(1000);
    if (error) { console.warn('[Laboratorio] No se pudieron leer los pedidos anulados de los lotes:', error.message); break; }
    filas.push(...(data || []));
  }
  return agruparAnuladosPorLote(filas);
}

function idsDeFotosDelPedido(p: any): string[] {
  const f = p?.fotos_seleccionadas || {};
  return [f.grupalId, f.individualId, f.docenteId, ...(Array.isArray(f.otrasIds) ? f.otrasIds : [])].filter(
    (v: unknown): v is string => typeof v === 'string' && v.length > 0
  );
}

function sumarImpresiones(filas: any[]) {
  return filas.reduce(
    (acc, p) => {
      const c = contarImpresionesPedido(p);
      return { carpetas: acc.carpetas + c.carpetas, fotos20x30: acc.fotos20x30 + c.fotos20x30, fotos15x21: acc.fotos15x21 + c.fotos15x21, sueltas: acc.sueltas + c.sueltas };
    },
    { carpetas: 0, fotos20x30: 0, fotos15x21: 0, sueltas: 0 }
  );
}

// Fotos que el laboratorio puede bajar (las de sus pedidos). Se cachea 1 minuto: un ZIP pide
// cientos de fotos seguidas y no tiene sentido recalcular la lista en cada una.
let cacheFotosLab: { hasta: number; ids: Set<string> } | null = null;
async function fotosPermitidasLab(supabase: SupabaseClient): Promise<Set<string>> {
  if (cacheFotosLab && cacheFotosLab.hasta > Date.now()) return cacheFotosLab.ids;
  const ids = new Set((await pedidosParaLaboratorio(supabase)).flatMap(idsDeFotosDelPedido));
  // Reimpresiones (2/10): también las fotos de pedidos ya archivados que el laboratorio pidió
  // reimprimir en los últimos 14 días.
  const { data: reimpresiones } = await supabase
    .from('reimpresiones_lab')
    .select('pedidos(fotos_seleccionadas)')
    .gte('created_at', new Date(Date.now() - 14 * 24 * 60 * 60 * 1000).toISOString())
    .limit(500);
  for (const r of reimpresiones || []) for (const id of idsDeFotosDelPedido((r as any).pedidos)) ids.add(id);
  cacheFotosLab = { hasta: Date.now() + 60 * 1000, ids };
  return ids;
}

rutas.get('/api/lab/pedidos', requireLabAuth, async (_req: Request, res: Response) => {
  try {
    const supabase = getServerSupabase();
    if (!supabase) return res.status(503).json({ success: false, error: 'Servicio no disponible' });
    const pedidos = await pedidosParaLaboratorio(supabase);
    const idsFotos = [...new Set(pedidos.flatMap(idsDeFotosDelPedido))];
    const fotos: any[] = [];
    for (const lote of enLotes(idsFotos)) {
      const { data, error } = await supabase.from('fotos').select('id, categoria, alumno_nombre, thumb_path, preview_path').in('id', lote);
      if (error) throw error;
      fotos.push(...(data || []));
    }
    const { data: lotes, error: errLotes } = await supabase
      .from('lotes_laboratorio')
      .select('id, numero, created_at, cantidad, en_produccion_at, carpetas, fotos_20x30, fotos_15x21, fotos_sueltas')
      .eq('tipo', 'kits') // 29/10: los lotes de fotos extra van aparte (laboratorioExtras.ts)
      .order('numero', { ascending: false })
      .limit(100);
    if (errLotes) throw errLotes;
    // Auditoría 05/10: un pedido que se cancela (o se deja de considerar cobrado) DESPUÉS de entrar a
    // un lote desaparecía de la lista del laboratorio sin aviso: el lote seguía con su cantidad y el
    // lab podía imprimirlo igual. Se informan por lote los pedidos que ya no están pagados/entregados.
    const anuladosPorLote = await anuladosDeLotesLab(supabase, (lotes || []).map((l: any) => l.id));
    const lotesConAnulados = (lotes || []).map((l: any) => ({ ...l, anulados: anuladosPorLote.get(l.id) || [] }));
    return res.json({ success: true, pedidos, fotos, lotes: lotesConAnulados });
  } catch (err: any) {
    console.error('[Laboratorio] Error al listar pedidos:', err);
    return res.status(500).json({ success: false, error: 'No se pudieron cargar los pedidos.' });
  }
});

// Original HD de una foto, sólo si pertenece a un pedido que le corresponde al laboratorio.
rutas.get('/api/lab/fotos/:id/original', requireLabAuth, async (req: Request, res: Response) => {
  try {
    const supabase = getServerSupabase();
    if (!supabase) return res.status(503).json({ success: false, error: 'Servicio no disponible' });
    const fotoId = String(req.params.id || '');
    if (!/^[0-9a-f-]{36}$/i.test(fotoId)) return res.status(400).json({ success: false, error: 'Foto inválida' });
    let permitidas = await fotosPermitidasLab(supabase);
    if (!permitidas.has(fotoId)) {
      // Puede ser una reimpresión recién registrada en otra instancia del servidor: se recalcula una vez.
      cacheFotosLab = null;
      permitidas = await fotosPermitidasLab(supabase);
    }
    if (!permitidas.has(fotoId)) {
      return res.status(404).json({ success: false, error: 'Foto no disponible para el laboratorio' });
    }
    const { data: foto, error: errorFoto } = await supabase.from('fotos').select('storage_path').eq('id', fotoId).maybeSingle();
    if (errorFoto) throw errorFoto;
    if (!foto?.storage_path) return res.status(404).json({ success: false, error: 'Foto original no encontrada' });
    // Auditoría 03/10 (crítico 3): ver responderUrlFirmadaOriginal (originales > 4,5 MB).
    if (req.query.modo === 'url') return responderUrlFirmadaOriginal(supabase, res, foto.storage_path, fotoId);
    const { data: archivo, error: errorDescarga } = await supabase.storage.from('fotos-hd').download(foto.storage_path);
    if (errorDescarga || !archivo) throw errorDescarga || new Error('No se pudo descargar el original');
    res.setHeader('Content-Type', archivo.type || 'application/octet-stream');
    res.setHeader('Cache-Control', 'private, no-store');
    return res.send(Buffer.from(await archivo.arrayBuffer()));
  } catch (err: any) {
    console.error('[Laboratorio] Error al descargar original:', err);
    return res.status(500).json({ success: false, error: 'No se pudo descargar la foto.' });
  }
});

// Arma un lote con todos los pedidos nuevos (sin lote y sin etapa de laboratorio todavía).
rutas.post('/api/lab/lotes', requireLabAuth, limitarFrecuencia('lab-lotes', 30, 10 * 60 * 1000), async (_req: Request, res: Response) => {
  try {
    const supabase = getServerSupabase();
    if (!supabase) return res.status(503).json({ success: false, error: 'Servicio no disponible' });
    const nuevos = (await pedidosParaLaboratorio(supabase)).filter((p: any) => !p.lote_lab_id && !p.estado_lab);
    if (nuevos.length === 0) return res.status(409).json({ success: false, error: 'No hay pedidos nuevos para descargar.' });
    const { data: lote, error } = await supabase.from('lotes_laboratorio').insert({ cantidad: 0 }).select('id, numero, created_at').single();
    if (error || !lote) throw error || new Error('No se pudo crear el lote');
    const asignados: string[] = [];
    // Foto de las cantidades al momento de armar el lote: es lo que el laboratorio factura.
    const totalesDe = () => {
      const idsAsignados = new Set(asignados);
      const t = sumarImpresiones(nuevos.filter((p: any) => idsAsignados.has(p.id)));
      return { cantidad: asignados.length, carpetas: t.carpetas, fotos_20x30: t.fotos20x30, fotos_15x21: t.fotos15x21, fotos_sueltas: t.sueltas };
    };
    try {
      for (const grupo of enLotes(nuevos.map((p: any) => p.id))) {
        // Sólo los que siguen sin lote (si dos personas descargan a la vez, nadie repite pedidos).
        const { data, error: errUpd } = await supabase
          .from('pedidos')
          .update({ lote_lab_id: lote.id })
          .in('id', grupo)
          .is('lote_lab_id', null)
          .select('id');
        if (errUpd) throw errUpd;
        asignados.push(...(data || []).map((f: any) => f.id));
      }
    } catch (errAsignar) {
      // Auditoría 11/10: si se corta a mitad, el lote queda con los totales de lo que sí se asignó (antes, en 0).
      if (asignados.length > 0) await supabase.from('lotes_laboratorio').update(totalesDe()).eq('id', lote.id);
      else await supabase.from('lotes_laboratorio').delete().eq('id', lote.id);
      throw errAsignar;
    }
    if (asignados.length === 0) {
      await supabase.from('lotes_laboratorio').delete().eq('id', lote.id);
      return res.status(409).json({ success: false, error: 'Esos pedidos ya se descargaron en otro lote.' });
    }
    const totales = totalesDe();
    const { error: errTotales } = await supabase.from('lotes_laboratorio').update(totales).eq('id', lote.id);
    if (errTotales) console.error('[Laboratorio] El lote se armó pero no se pudieron guardar sus totales:', errTotales.message);
    return res.json({ success: true, lote: { ...lote, ...totales, en_produccion_at: null }, pedidoIds: asignados });
  } catch (err: any) {
    console.error('[Laboratorio] Error al crear lote:', err);
    return res.status(500).json({ success: false, error: 'No se pudo armar el lote.' });
  }
});

// Marca los pedidos del lote "En producción" y le avisa por email a cada familia.
rutas.post('/api/lab/lotes/:id/en-produccion', requireLabAuth, limitarFrecuencia('lab-produccion', 30, 10 * 60 * 1000), async (req: Request, res: Response) => {
  try {
    const supabase = getServerSupabase();
    if (!supabase) return res.status(503).json({ success: false, error: 'Servicio no disponible' });
    const loteId = String(req.params.id || '');
    if (!/^[0-9a-f-]{36}$/i.test(loteId)) return res.status(400).json({ success: false, error: 'Lote inválido' });
    // Auditoría 03/10 (alto 18): con lotes grandes (un mail por familia) esto podía pasar los 60 s
    // de Vercel y cortarse a mitad. Ahora es idempotente (sólo toma los pedidos del lote que todavía
    // no tienen etapa, o sea, no avisados) y trabaja con un presupuesto de tiempo: si no llega,
    // responde `restantes` > 0 y el panel del laboratorio lo vuelve a llamar.
    const inicioProceso = Date.now();
    const PRESUPUESTO_MS = 40 * 1000;
    const filas = await traerTodasLasFilas<any>((desde, hasta) =>
      supabase
        .from('pedidos')
        .select('id, pedido_friendly_id, alumno_nombre, colegio_nombre, estado, estado_lab, en_espera, archivado, seleccion_pendiente, familias(nombre, email)')
        .eq('lote_lab_id', loteId)
        .is('estado_lab', null)
        .order('id')
        .range(desde, hasta)
    );
    let avisados = 0;
    let restantes = 0;
    const errores: string[] = [];
    for (const f of filas) {
      if (!['pagado', 'entregado'].includes(f.estado) || f.en_espera || f.archivado || f.seleccion_pendiente) continue;
      if (Date.now() - inicioProceso > PRESUPUESTO_MS) {
        restantes += 1;
        continue;
      }
      if (!puedeAvanzarEtapaLab(f.estado_lab as EtapaLab | null, 'en_produccion') || f.estado_lab === 'en_produccion') continue;
      const ahora = new Date().toISOString();
      const { data: actualizada, error: errUpd } = await supabase
        .from('pedidos')
        .update({ estado_lab: 'en_produccion', fecha_envio_produccion: ahora, updated_at: ahora })
        .eq('id', f.id)
        .is('estado_lab', null)
        .select('id');
      if (errUpd || !actualizada || actualizada.length === 0) continue;
      const familia: any = Array.isArray(f.familias) ? f.familias[0] : f.familias;
      if (familia?.email?.includes('@')) {
        try {
          await enviarCorreoActualizacionPedido({
            tipo: 'en_produccion',
            to: familia.email,
            tutorNombre: familia.nombre || 'Familia',
            alumnoNombre: f.alumno_nombre || '',
            colegioNombre: f.colegio_nombre || '',
            pedidoId: f.id,
            pedidoFriendlyId: f.pedido_friendly_id || undefined,
          });
          avisados += 1;
        } catch (e: any) {
          errores.push(`${f.alumno_nombre}: no se pudo mandar el email`);
        }
      }
    }
    // Auditoría 03/10: el lote se marca en producción recién cuando no quedan pedidos por avisar;
    // si no, un corte a mitad dejaba el lote "en producción" con pedidos sin marcar y sin botón para seguir.
    if (restantes === 0) {
      await supabase.from('lotes_laboratorio').update({ en_produccion_at: new Date().toISOString() }).eq('id', loteId).is('en_produccion_at', null);
    }
    return res.json({ success: true, avisados, errores, restantes });
  } catch (err: any) {
    console.error('[Laboratorio] Error al marcar en producción:', err);
    return res.status(500).json({ success: false, error: 'No se pudo marcar el lote.' });
  }
});

// Resumen para facturar: suma los lotes marcados "En producción" dentro del período (fechas de
// Argentina, "desde" y "hasta" en formato AAAA-MM-DD). Los lotes descargados que todavía no se
// marcaron se informan aparte. También lo usa el panel del fotógrafo (sesión de admin).
rutas.get('/api/lab/resumen', requireLabAuth, async (req: Request, res: Response) => {
  try {
    const supabase = getServerSupabase();
    if (!supabase) return res.status(503).json({ success: false, error: 'Servicio no disponible' });
    const fecha = (v: unknown) => (/^\d{4}-\d{2}-\d{2}$/.test(String(v || '')) ? String(v) : null);
    const desde = fecha(req.query.desde);
    const hasta = fecha(req.query.hasta);
    if (!desde || !hasta) return res.status(400).json({ success: false, error: 'Elegí el período.' });
    const inicio = new Date(`${desde}T00:00:00-03:00`).toISOString();
    const fin = new Date(new Date(`${hasta}T00:00:00-03:00`).getTime() + 24 * 60 * 60 * 1000).toISOString();
    const columnas = 'id, numero, created_at, en_produccion_at, cantidad, carpetas, fotos_20x30, fotos_15x21, fotos_sueltas';
    const { data: enPeriodo, error } = await supabase
      .from('lotes_laboratorio')
      .select(columnas)
      .gte('en_produccion_at', inicio)
      .lt('en_produccion_at', fin)
      .order('numero');
    if (error) throw error;
    const { data: pendientes, error: errPend } = await supabase.from('lotes_laboratorio').select(columnas).is('en_produccion_at', null).order('numero');
    if (errPend) throw errPend;
    // Reimpresiones del período (2/10): con cargo (daño, pérdida u otro) y sin cargo (falla del laboratorio).
    const { data: reimp, error: errReimp } = await supabase
      .from('reimpresiones_lab')
      .select('id, created_at, motivo, detalle, fotos_20x30, fotos_15x21, con_cargo, pedidos(pedido_friendly_id, alumno_nombre, curso_codigo)')
      .gte('created_at', inicio)
      .lt('created_at', fin)
      .order('created_at');
    if (errReimp) console.warn('[Laboratorio] No se pudieron leer las reimpresiones:', errReimp);
    const reimpresiones = (errReimp ? [] : reimp || []).map((r: any) => ({
      id: r.id,
      fecha: r.created_at,
      motivo: r.motivo,
      detalle: r.detalle,
      conCargo: Boolean(r.con_cargo),
      fotos20x30: r.fotos_20x30 || 0,
      fotos15x21: r.fotos_15x21 || 0,
      pedido: r.pedidos?.pedido_friendly_id || '',
      alumno: r.pedidos?.alumno_nombre || '',
      curso: r.pedidos?.curso_codigo || '',
    }));
    const sumarReimp = (conCargo: boolean) =>
      reimpresiones
        .filter((r) => r.conCargo === conCargo)
        .reduce((a, r) => ({ cantidad: a.cantidad + 1, fotos20x30: a.fotos20x30 + r.fotos20x30, fotos15x21: a.fotos15x21 + r.fotos15x21 }), { cantidad: 0, fotos20x30: 0, fotos15x21: 0 });
    const sumar = (lista: any[]) =>
      lista.reduce(
        (a, l) => ({
          lotes: a.lotes + 1,
          pedidos: a.pedidos + (l.cantidad || 0),
          carpetas: a.carpetas + (l.carpetas || 0),
          fotos20x30: a.fotos20x30 + (l.fotos_20x30 || 0),
          fotos15x21: a.fotos15x21 + (l.fotos_15x21 || 0),
          sueltas: a.sueltas + (l.fotos_sueltas || 0),
        }),
        { lotes: 0, pedidos: 0, carpetas: 0, fotos20x30: 0, fotos15x21: 0, sueltas: 0 }
      );
    return res.json({
      success: true,
      desde,
      hasta,
      lotes: enPeriodo || [],
      totales: sumar(enPeriodo || []),
      pendientes: pendientes || [],
      totalesPendientes: sumar(pendientes || []),
      reimpresiones,
      totalesReimpresiones: { conCargo: sumarReimp(true), sinCargo: sumarReimp(false) },
    });
  } catch (err: any) {
    console.error('[Laboratorio] Error al armar el resumen:', err);
    return res.status(500).json({ success: false, error: 'No se pudo armar el resumen.' });
  }
});

// ==============================================================================
// REIMPRESIONES (2/10, pedido de Pablo): el laboratorio busca un pedido que salió mal por número de
// pedido, código o nombre del alumno (también los ya entregados o archivados), elige qué fotos
// reimprimir y baja un ZIP sólo con esas. Queda registrado (motivo, cantidades), le llega un aviso
// a Pablo y aparece en el resumen para facturar: sin cargo si fue una falla del laboratorio.
// ==============================================================================
const MOTIVOS_REIMPRESION = ['falla_laboratorio', 'dano_o_perdida', 'otro'] as const;

rutas.get('/api/lab/buscar', requireLabAuth, limitarFrecuencia('lab-buscar', 120, 10 * 60 * 1000), async (req: Request, res: Response) => {
  try {
    const supabase = getServerSupabase();
    if (!supabase) return res.status(503).json({ success: false, error: 'Servicio no disponible' });
    // Sólo letras, números, espacios, guiones y guiones bajos: así el texto no puede romper el filtro.
    const q = String(req.query.q || '').normalize('NFC').replace(/[^\p{L}\p{N} _-]/gu, '').trim().slice(0, 60);
    if (q.replace(/[\s_-]/g, '').length < 3) return res.status(400).json({ success: false, error: 'Escribí al menos 3 letras o números.' });
    // El "código de cliente" que ve el laboratorio en cada archivo (ej. SALA5_BTT_03_RENATO_DELGADO)
    // puede tener _ o - donde la base tiene otro separador: se busca con comodines entre partes.
    const patron = `%${q.replace(/[\s_-]+/g, '%')}%`;
    // Además por nombre: las palabras después del número de lista (o todas, si no hay número), en
    // cualquier orden y sin importar tildes (cada vocal o ñ se busca como "cualquier letra").
    const partes = q.split(/[\s_-]+/).filter(Boolean);
    const ultimoNumero = partes.map((x) => /\d/.test(x)).lastIndexOf(true);
    const palabras = partes.slice(ultimoNumero + 1).filter((x) => x.length >= 3 && !/\d/.test(x)).slice(0, 4);
    const comodin = (w: string) => `%${w.toLowerCase().replace(/ñ/g, '_').normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[aeiou]/g, '_')}%`;
    const porNombre = palabras.length > 0 ? `,and(${palabras.map((w) => `alumno_nombre.ilike.${comodin(w)}`).join(',')})` : '';
    const { data: pedidos, error } = await supabase
      .from('pedidos')
      .select(COLUMNAS_PEDIDO_LAB)
      .in('estado', ['pagado', 'entregado'])
      .eq('tipo_kit', 'impreso_digital')
      .eq('seleccion_pendiente', false)
      .eq('en_espera', false)
      .or(`pedido_friendly_id.ilike.${patron},codigo_alumno.ilike.${patron},alumno_nombre.ilike.${patron}${porNombre}`)
      .order('created_at', { ascending: false })
      .limit(10);
    if (error) throw error;
    const lista = pedidos || [];
    const idsFotos = [...new Set(lista.flatMap(idsDeFotosDelPedido))];
    const fotos: any[] = [];
    for (const lote of enLotes(idsFotos)) {
      const { data, error: errFotos } = await supabase.from('fotos').select('id, categoria, alumno_nombre, thumb_path, preview_path').in('id', lote);
      if (errFotos) throw errFotos;
      fotos.push(...(data || []));
    }
    const { data: previas } = lista.length
      ? await supabase.from('reimpresiones_lab').select('pedido_id, created_at, motivo').in('pedido_id', lista.map((p: any) => p.id)).order('created_at', { ascending: false })
      : { data: [] as any[] };
    return res.json({ success: true, pedidos: lista, fotos, reimpresiones: previas || [] });
  } catch (err: any) {
    console.error('[Laboratorio] Error al buscar pedido:', err);
    return res.status(500).json({ success: false, error: 'No se pudo buscar el pedido.' });
  }
});

rutas.post('/api/lab/pedidos/:id/reimpresion', requireLabAuth, limitarFrecuencia('lab-reimpresion', 40, 10 * 60 * 1000), async (req: Request, res: Response) => {
  try {
    const supabase = getServerSupabase();
    if (!supabase) return res.status(503).json({ success: false, error: 'Servicio no disponible' });
    const motivo = String(req.body?.motivo || '');
    if (!(MOTIVOS_REIMPRESION as readonly string[]).includes(motivo)) return res.status(400).json({ success: false, error: 'Elegí el motivo de la reimpresión.' });
    const detalle = String(req.body?.detalle || '').trim().slice(0, 600);
    if (motivo !== 'falla_laboratorio' && detalle.length < 3) return res.status(400).json({ success: false, error: 'Contanos brevemente qué pasó.' });
    const archivosRecibidos = (Array.isArray(req.body?.archivos) ? req.body.archivos : [])
      .slice(0, 60)
      .map((a: any) => ({ nombre: String(a?.nombre || '').slice(0, 160), tamano: String(a?.tamano || '') }))
      .filter((a: any) => a.nombre && ['20x30', '15x21'].includes(a.tamano));
    // Auditoría 11/10 (ADM-1): el mismo nombre puede venir en 20x30 y en 15x21: se deduplica por tamaño + nombre.
    const archivos = [...new Map(archivosRecibidos.map((a: any) => [`${a.tamano}/${a.nombre}`, a])).values()] as { nombre: string; tamano: string }[];
    if (archivos.length === 0) return res.status(400).json({ success: false, error: 'Elegí al menos una foto para reimprimir.' });
    const { data: p } = await supabase
      .from('pedidos')
      .select('id, pedido_friendly_id, alumno_nombre, colegio_nombre, curso_codigo, estado, tipo_kit, seleccion_pendiente, en_espera, archivado, lote_lab_id, estado_lab, fotos_seleccionadas, copias_extras')
      .eq('id', String(req.params.id || ''))
      .maybeSingle();
    if (!p || !['pagado', 'entregado'].includes(p.estado) || p.tipo_kit !== 'impreso_digital' || p.seleccion_pendiente || p.en_espera) {
      return res.status(404).json({ success: false, error: 'Ese pedido no se puede reimprimir.' });
    }
    // Sólo lo que ya se imprimió alguna vez (si todavía no salió en un lote, va con los pedidos nuevos).
    if (!p.lote_lab_id && !p.estado_lab && !p.archivado && p.estado !== 'entregado') {
      return res.status(409).json({ success: false, error: 'Ese pedido todavía no se imprimió: sale con los pedidos nuevos.' });
    }
    const fotos20x30 = archivos.filter((a) => a.tamano === '20x30').length;
    const fotos15x21 = archivos.length - fotos20x30;
    const maximo = contarImpresionesPedido(p);
    if (fotos20x30 > maximo.fotos20x30 || fotos15x21 > maximo.fotos15x21) {
      return res.status(400).json({ success: false, error: 'Elegiste más fotos de las que tiene el pedido.' });
    }
    const conCargo = motivo !== 'falla_laboratorio';
    // 14/10/2026 (auditoría): la misma reimpresión (pedido + motivo + fotos) pedida otra vez dentro de 6 h —por
    // ejemplo, tras recargar la página con el ZIP a medias— reusa el registro: no suma otra con cargo ni otro aviso.
    const huella = crypto.createHash('sha256').update(`${p.id}|${motivo}|${archivos.map((a) => `${a.tamano}/${a.nombre}`).sort().join(',')}`).digest('hex').slice(0, 32);
    const buscarPrevia = async () => {
      const { data, error: errPrevia } = await supabase.from('reimpresiones_lab').select('id, created_at').ilike('clave', `${huella}-%`)
        .gte('created_at', new Date(Date.now() - 6 * 60 * 60 * 1000).toISOString()).order('created_at', { ascending: false }).limit(1).maybeSingle();
      return errPrevia ? null : data;
    };
    const previa = await buscarPrevia();
    if (previa) return res.json({ success: true, id: previa.id, fecha: previa.created_at, repetida: true });
    const nueva: Record<string, unknown> = { pedido_id: p.id, motivo, detalle: detalle || null, archivos, fotos_20x30: fotos20x30, fotos_15x21: fotos15x21, con_cargo: conCargo, clave: `${huella}-${Math.floor(Date.now() / (6 * 60 * 60 * 1000))}` };
    let { data: fila, error } = await supabase.from('reimpresiones_lab').insert(nueva).select('id, created_at').single();
    if (error && String((error as any).code) === '23505') {
      const ganadora = await buscarPrevia(); // dos pedidos iguales a la vez: gana uno solo
      if (ganadora) return res.json({ success: true, id: ganadora.id, fecha: ganadora.created_at, repetida: true });
    }
    if (error && /clave/.test(String(error.message || '')) && ['42703', 'PGRST204'].includes(String((error as any).code))) {
      delete nueva.clave; // migración sin aplicar: se registra como antes
      ({ data: fila, error } = await supabase.from('reimpresiones_lab').insert(nueva).select('id, created_at').single());
    }
    if (error || !fila) throw error || new Error('No se pudo registrar la reimpresión');
    cacheFotosLab = null; // que las fotos de este pedido queden habilitadas ya mismo
    const textoMotivo = motivo === 'falla_laboratorio' ? 'Falla de impresión del laboratorio (sin cargo)' : motivo === 'dano_o_perdida' ? 'Se dañó o se perdió después de imprimir (con cargo)' : 'Otro motivo (con cargo)';
    await supabase.from('reportes_errores').insert({
      codigo: `REI-${String(fila.id).slice(0, 5).toUpperCase()}`,
      origen: 'admin',
      mensaje: `Laboratorio: reimpresión de ${p.pedido_friendly_id} (${p.alumno_nombre}): ${textoMotivo}${detalle ? ` — ${detalle}` : ''}`.slice(0, 1000),
      detalle: { tipo: 'reimpresion_laboratorio', pedidoId: p.id, pedido: p.pedido_friendly_id, motivo, detalle, fotos20x30, fotos15x21 },
    });
    const resend = getResendClient();
    if (resend) {
      await resend.emails.send({
        from: process.env.RESEND_FROM_EMAIL || 'Retrato Escolar <fotos@retratoescolar.com.ar>',
        to: [casillaAvisosAdmin()],
        subject: `🖨️ Reimpresión: ${p.pedido_friendly_id} (${p.alumno_nombre || ''})`,
        html: `<div style="font-family:Arial,sans-serif"><h2>El laboratorio va a reimprimir un pedido</h2><p><strong>Pedido:</strong> ${escapeHtml(p.pedido_friendly_id || p.id)}<br><strong>Alumno/a:</strong> ${escapeHtml(p.alumno_nombre || '')} (${escapeHtml(p.curso_codigo || '')})<br><strong>Colegio:</strong> ${escapeHtml(p.colegio_nombre || '')}</p><p><strong>Motivo:</strong> ${escapeHtml(textoMotivo)}${detalle ? `<br><strong>Detalle:</strong> ${escapeHtml(detalle)}` : ''}</p><p><strong>Fotos:</strong> ${fotos20x30} de 20x30 y ${fotos15x21} de 15x21<br>${archivos.map((a: any) => escapeHtml(`${a.nombre} (${a.tamano})`)).join('<br>')}</p><p style="font-size:12px;color:#64748b">Si fue un daño o una pérdida, va con cargo en el resumen del laboratorio. Si no estás de acuerdo con el motivo, hablalo con el laboratorio.</p></div>`,
      }).catch((e: any) => console.warn('[Laboratorio] No se pudo avisar la reimpresión por email:', e));
    }
    return res.json({ success: true, id: fila.id, fecha: fila.created_at });
  } catch (err: any) {
    console.error('[Laboratorio] Error al registrar reimpresión:', err);
    return res.status(500).json({ success: false, error: 'No se pudo registrar la reimpresión.' });
  }
});

// 14/10/2026 (auditoría): progreso del ZIP por partes de un lote (qué partes ya se bajaron), guardado en el lote
// (columna zip_partes, migración 20261014020500). Si el laboratorio recarga la página a mitad de un lote grande,
// al volver a bajarlo ve qué partes ya tenía. Sin la columna (migración sin aplicar), simplemente no se recuerda.
rutas.get('/api/lab/lotes/:id/zip-partes', requireLabAuth, async (req: Request, res: Response) => {
  const supabase = getServerSupabase();
  if (!supabase) return res.status(503).json({ success: false, error: 'Servicio no disponible' });
  const { data, error } = await supabase.from('lotes_laboratorio').select('zip_partes').eq('id', String(req.params.id || '')).maybeSingle();
  return res.json({ success: true, zipPartes: error ? null : data?.zip_partes ?? null });
});

rutas.put('/api/lab/lotes/:id/zip-partes', requireLabAuth, async (req: Request, res: Response) => {
  try {
    const total = Number(req.body?.total);
    const hechas = Array.isArray(req.body?.hechas) ? [...new Set<number>(req.body.hechas.map(Number))].filter((n) => Number.isInteger(n) && n >= 0 && n < total) : null;
    if (!Number.isInteger(total) || total < 1 || total > 500 || !hechas) return res.status(400).json({ success: false, error: 'Datos de las partes no válidos.' });
    const supabase = getServerSupabase();
    if (!supabase) return res.status(503).json({ success: false, error: 'Servicio no disponible' });
    const zipPartes = { total, hechas: hechas.sort((a, b) => a - b), nombre: String(req.body?.nombre || '').slice(0, 160), at: new Date().toISOString() };
    const { data, error } = await supabase.from('lotes_laboratorio').update({ zip_partes: zipPartes }).eq('id', String(req.params.id || '')).select('id');
    if (error) throw error;
    if (!data || data.length === 0) return res.status(404).json({ success: false, error: 'Lote no encontrado' });
    return res.json({ success: true });
  } catch (err: any) {
    console.error('[Laboratorio] Error al guardar las partes del ZIP:', err);
    return res.status(500).json({ success: false, error: 'No se pudo guardar el avance del ZIP.' });
  }
});

// "Hay un problema con este pedido": queda en Estado del sistema y le llega un email a Pablo.
rutas.post('/api/lab/pedidos/:id/problema', requireLabAuth, limitarFrecuencia('lab-problema', 30, 10 * 60 * 1000), async (req: Request, res: Response) => {
  try {
    const supabase = getServerSupabase();
    if (!supabase) return res.status(503).json({ success: false, error: 'Servicio no disponible' });
    const motivo = String(req.body?.motivo || '').trim().slice(0, 600);
    if (motivo.length < 3) return res.status(400).json({ success: false, error: 'Contanos brevemente cuál es el problema.' });
    const { data: p } = await supabase
      .from('pedidos')
      .select('id, pedido_friendly_id, alumno_nombre, colegio_nombre, curso_codigo')
      .eq('id', String(req.params.id || ''))
      .maybeSingle();
    if (!p) return res.status(404).json({ success: false, error: 'Pedido no encontrado' });
    const codigo = `LAB-${Math.random().toString(36).slice(2, 7).toUpperCase()}`;
    const mensaje = `Laboratorio: problema con ${p.pedido_friendly_id} (${p.alumno_nombre}, ${p.curso_codigo}): ${motivo}`;
    // 14/10/2026 (auditoría): si no quedó guardado, el laboratorio tiene que saberlo (antes se respondía «listo» igual).
    const { error: errorReporte } = await supabase.from('reportes_errores').insert({
      codigo,
      origen: 'admin',
      mensaje: mensaje.slice(0, 1000),
      detalle: { tipo: 'problema_laboratorio', pedidoId: p.id, pedido: p.pedido_friendly_id, motivo },
    });
    if (errorReporte) throw errorReporte;
    const resend = getResendClient();
    if (resend) {
      await resend.emails.send({
        from: process.env.RESEND_FROM_EMAIL || 'Retrato Escolar <fotos@retratoescolar.com.ar>',
        to: [casillaAvisosAdmin()],
        subject: `🖨️ Problema reportado por el laboratorio: ${p.pedido_friendly_id}`,
        html: `<div style="font-family:Arial,sans-serif"><h2>El laboratorio reportó un problema</h2><p><strong>Pedido:</strong> ${escapeHtml(p.pedido_friendly_id || p.id)}<br><strong>Alumno/a:</strong> ${escapeHtml(p.alumno_nombre || '')} (${escapeHtml(p.curso_codigo || '')})<br><strong>Colegio:</strong> ${escapeHtml(p.colegio_nombre || '')}</p><p><strong>Problema:</strong> ${escapeHtml(motivo)}</p><p style="font-size:12px;color:#64748b">También figura en el panel → Estado del sistema (código ${escapeHtml(codigo)}).</p></div>`,
      }).catch((e: any) => console.warn('[Laboratorio] No se pudo avisar el problema por email:', e));
    }
    return res.json({ success: true, codigo });
  } catch (err: any) {
    console.error('[Laboratorio] Error al reportar problema:', err);
    return res.status(500).json({ success: false, error: 'No se pudo enviar el reporte.' });
  }
});

// Aviso diario al laboratorio (pg_cron, 9 hs): si hay pedidos nuevos, un email con las cantidades.
rutas.all('/api/cron/aviso-laboratorio', async (req: Request, res: Response) => {
  if (!(await autorizarTareaProgramada(req))) return res.status(401).json({ success: false, error: 'No autorizado.' });
  const destino = process.env.LAB_EMAIL?.trim();
  const supabase = getServerSupabase();
  // Auditoría 11/10 (DB-8): "Estado del sistema" ve la tarea corriendo también cuando no hay nada que avisar.
  const anotarEjecucion = (resultado: Record<string, unknown>) =>
    supabase?.from('tareas_programadas_estado').upsert({ nombre: 'aviso-laboratorio', ultima_ejecucion: new Date().toISOString(), resultado });
  if (!destino || !destino.includes('@') || !supabase) {
    await anotarEjecucion({ omitido: 'Falta LAB_EMAIL' });
    return res.json({ success: true, omitido: 'Falta LAB_EMAIL' });
  }
  try {
    const nuevos = (await pedidosParaLaboratorio(supabase)).filter((p: any) => !p.lote_lab_id && !p.estado_lab);
    // 29/10/2026: también avisa de las fotos extra nuevas (van en su propio lote, pestaña «Fotos extra»).
    const extrasNuevos = (await pedidosExtrasParaLaboratorio(supabase)).filter((p: any) => !p.lote_lab_id && !p.estado_lab).length;
    if (nuevos.length === 0 && extrasNuevos === 0) {
      await anotarEjecucion({ nuevos: 0 });
      return res.json({ success: true, nuevos: 0 });
    }
    const lineaExtras = extrasNuevos ? `<p>Además hay <strong>${extrasNuevos}</strong> pedido${extrasNuevos > 1 ? 's' : ''} de <strong>fotos extra</strong> (copias sueltas, en la pestaña «Fotos extra», lote aparte).</p>` : '';
    const carpetas = nuevos.reduce((acc: number, p: any) => acc + (Number(p.carpetas_impresas) || 1), 0);
    const colegios = [...new Set(nuevos.map((p: any) => p.colegio_nombre || 'Colegio'))];
    const appUrl = (process.env.APP_URL || 'https://www.retratoescolar.com.ar').replace(/\/+$/, '');
    const resend = getResendClient();
    if (!resend) return res.json({ success: false, error: 'Resend no configurado' });
    const { error } = await resend.emails.send({
      from: process.env.RESEND_FROM_EMAIL || 'Retrato Escolar <fotos@retratoescolar.com.ar>',
      replyTo: casillaAvisosAdmin(),
      to: [destino],
      subject: `Retrato Escolar: ${nuevos.length + extrasNuevos} pedido${nuevos.length + extrasNuevos > 1 ? 's' : ''} nuevo${nuevos.length + extrasNuevos > 1 ? 's' : ''} para imprimir`,
      html: `<div style="font-family:Arial,sans-serif;max-width:560px;color:#0f172a"><h2>Hay pedidos nuevos para imprimir</h2>${nuevos.length ? `<p><strong>${nuevos.length}</strong> pedido${nuevos.length > 1 ? 's' : ''} · <strong>${carpetas}</strong> carpeta${carpetas > 1 ? 's' : ''} (cada una: 1 foto 20x30 + 2 fotos 15x21).</p>` : ''}${lineaExtras}<p>Colegios: ${colegios.map(escapeHtml).join(', ')}</p><p><a href="${appUrl}/laboratorio" style="display:inline-block;background:#f59e0b;color:#0f172a;padding:10px 16px;border-radius:10px;font-weight:bold;text-decoration:none">Abrir el panel del laboratorio</a></p></div>`,
    });
    if (error) throw error;
    await anotarEjecucion({ nuevos: nuevos.length, extras: extrasNuevos });
    return res.json({ success: true, nuevos: nuevos.length, extras: extrasNuevos });
  } catch (err: any) {
    console.error('[cron aviso-laboratorio]', err);
    return res.status(500).json({ success: false, error: err?.message || 'Error' });
  }
});

export { rutas as rutasLaboratorio };
