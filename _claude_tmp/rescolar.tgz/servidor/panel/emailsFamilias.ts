// Panel «Emails» (26/10/2026, pedido de Pablo): escribirle a las familias desde un solo lugar.
// - Destinatarios por grupo, calculados con los datos del sistema: todas las familias inscriptas (aprobadas, colegios
//   públicos), las que compraron, las que no, las que pidieron foto de hermanos, las que tienen fotos faltantes
//   pendientes, una familia puntual; y se puede acotar por curso(s). Un mail por casilla.
// - Tipos: mensaje, citación (día, hora, lugar: si va a las de fotos faltantes, queda anotada en cada pedido como el
//   «Convocar» de Faltantes), promoción (con código de descuento opcional) y encuesta de satisfacción (link personal).
// - La IA redacta asunto y texto a partir de una idea; siempre se puede editar. Prueba a una casilla antes de enviar.
// - Cada envío guarda sus destinatarios (envios_email / envios_email_destinatarios, migración 20261026000000) y se
//   manda por tandas de Resend (100 por pedido, con pausa, clave de idempotencia); el panel repite hasta terminar.
//   El webhook de Resend marca los rebotes (registrarRebotesEnvios, desde correoEntrante.ts).
// - Citación repartida (26/10, pedido de Pablo para la foto de hermanos): el sistema reparte a las familias en varios días
//   (parejo) y les da una franja según el turno de sus hijos; el mediodía queda para las que tienen hijos en ambos turnos.
//   Lo asignado a cada familia se guarda en envios_email.contenido.citas (email → día y hora).
import type { SupabaseClient } from '@supabase/supabase-js';
import crypto from 'crypto';
import express from 'express';
import type { Request, Response } from 'express';
import { requireAdminAuth } from '../nucleo/auth.js';
import { getResendClient, getServerSupabase, resendReplyTo } from '../nucleo/clientes.js';
import { determinarCodigoCursoServidor } from '../nucleo/codigosCurso.js';
import { AVISO_IA_SATURADA, ERROR_IA_NO_CONFIGURADA, esIaSaturada, generarTextoIA, iaConfigurada } from '../nucleo/ia.js';
import { limitarFrecuencia } from '../nucleo/limites.js';
import { escapeHtml, traerTodasLasFilas } from '../nucleo/utilidades.js';
import { contextoNegocioConsultas } from '../familias/contextoConsultas.js';
import { textoEventoFotoHermanos } from '../familias/consultas.js';
import { correoEncuesta } from '../familias/encuesta.js';

const rutas = express.Router();
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const DIA_RE = /^\d{4}-\d{2}-\d{2}$/;
const TIEMPO_MAXIMO_MS = 40_000;
const APP_URL = () => (process.env.APP_URL || 'https://www.retratoescolar.com.ar').replace(/\/+$/, '');

export type TipoEnvio = 'mensaje' | 'citacion' | 'promocion' | 'encuesta';
export type Grupo = 'todas' | 'compraron' | 'no_compraron' | 'foto_hermanos' | 'faltantes' | 'pagados_sin_fotos' | 'familia';
export interface Filtro { grupo: Grupo; cursos: string[]; email: string }
export type Franja = 'ambos' | 'manana' | 'tarde' | 'completa';
export type Franjas = Record<Franja, string>;
export interface Cita { dia: string; hora: string; franja: Franja | 'general' }
export interface Contenido {
  texto: string; boton: boolean; dia: string; hora: string; lugar: string; codigo: string; vence: string;
  /** Citación repartida en varios días, con franja por turno. */
  reparto?: boolean; dias?: string[]; franjas?: Franjas; citas?: Record<string, Cita>;
}
export interface Destinatario { email: string; tutor: string; alumnos: string[]; inscripcionId: string | null; faltanteIds: string[]; turnos?: string[] }

export const FRANJAS_POR_DEFECTO: Franjas = { ambos: '12:00 a 13:00 h', manana: '10:30 a 11:30 h', tarde: '13:30 a 14:30 h', completa: '11:30 a 12:00 h' };

const GRUPOS: Grupo[] = ['todas', 'compraron', 'no_compraron', 'foto_hermanos', 'faltantes', 'pagados_sin_fotos', 'familia'];
export const NOMBRE_GRUPO: Record<Grupo, string> = {
  todas: 'Todas las familias inscriptas',
  compraron: 'Las que compraron',
  no_compraron: 'Las que todavía no compraron',
  foto_hermanos: 'Las que pidieron foto de hermanos',
  faltantes: 'Las que tienen fotos faltantes pendientes',
  pagados_sin_fotos: 'Las que pagaron el kit y les faltan fotos',
  familia: 'Una familia',
};

export function leerFiltro(cuerpo: any): Filtro | null {
  const grupo = GRUPOS.includes(cuerpo?.grupo) ? (cuerpo.grupo as Grupo) : null;
  if (!grupo) return null;
  const cursos = Array.isArray(cuerpo?.cursos) ? [...new Set(cuerpo.cursos.map((c: unknown) => String(c || '').trim().toUpperCase()).filter((c: string) => /^[A-Z0-9-]{3,30}$/.test(c)))].slice(0, 80) as string[] : [];
  const email = String(cuerpo?.email || '').trim().toLowerCase();
  if (grupo === 'familia' && !EMAIL_RE.test(email)) return null;
  return { grupo, cursos, email };
}

export function leerContenido(tipo: TipoEnvio, cuerpo: any): { ok: true; asunto: string; contenido: Contenido } | { ok: false; error: string } {
  const t = (v: unknown, max: number) => String(v || '').trim().slice(0, max);
  const asunto = t(cuerpo?.asunto, 150);
  const contenido: Contenido = {
    texto: t(cuerpo?.texto, 5000),
    boton: cuerpo?.boton === true,
    dia: t(cuerpo?.dia, 10),
    hora: t(cuerpo?.hora, 40),
    lugar: t(cuerpo?.lugar, 200),
    codigo: t(cuerpo?.codigo, 40).toUpperCase(),
    vence: t(cuerpo?.vence, 10),
  };
  if (tipo === 'encuesta') return { ok: true, asunto: asunto || 'Encuesta de satisfacción', contenido };
  if (asunto.length < 3) return { ok: false, error: 'Escribí el asunto del mail.' };
  if (contenido.texto.length < 5) return { ok: false, error: 'Escribí el texto del mail.' };
  if (tipo === 'citacion') {
    if (cuerpo?.reparto === true) {
      const dias = [...new Set((Array.isArray(cuerpo?.dias) ? cuerpo.dias : []).map((d: unknown) => t(d, 10)).filter((d: string) => DIA_RE.test(d)))].sort().slice(0, 5) as string[];
      if (dias.length === 0) return { ok: false, error: 'Elegí los días de la citación.' };
      const f = cuerpo?.franjas || {};
      contenido.reparto = true;
      contenido.dias = dias;
      contenido.franjas = {
        ambos: t(f.ambos, 40) || FRANJAS_POR_DEFECTO.ambos,
        manana: t(f.manana, 40) || FRANJAS_POR_DEFECTO.manana,
        tarde: t(f.tarde, 40) || FRANJAS_POR_DEFECTO.tarde,
        completa: t(f.completa, 40) || FRANJAS_POR_DEFECTO.completa,
      };
      contenido.dia = dias[0];
    }
    if (!DIA_RE.test(contenido.dia)) return { ok: false, error: 'Elegí el día de la citación.' };
    if (!contenido.hora) return { ok: false, error: contenido.reparto ? 'Indicá la hora general (para las familias sin turno cargado).' : 'Indicá la hora.' };
    if (contenido.lugar.length < 2) return { ok: false, error: 'Indicá el lugar.' };
  }
  if (contenido.vence && !DIA_RE.test(contenido.vence)) return { ok: false, error: 'La fecha de vencimiento no es válida.' };
  return { ok: true, asunto, contenido };
}

function primerNombre(nombre: string): string {
  return String(nombre || '').trim().split(/\s+/)[0] || '';
}

/** {nombre} → primer nombre del tutor; {alumnos} → nombres de los chicos («Juan y Sofía»). */
export function personalizar(texto: string, d: Pick<Destinatario, 'tutor' | 'alumnos'>): string {
  const nombres = d.alumnos.map((a) => primerNombre(a)).filter(Boolean);
  const alumnos = nombres.length > 1 ? `${nombres.slice(0, -1).join(', ')} y ${nombres[nombres.length - 1]}` : nombres[0] || 'tu hijo/a';
  return texto.replace(/\{nombre\}/gi, primerNombre(d.tutor) || 'familia').replace(/\{alumnos?\}/gi, alumnos);
}

function parrafos(texto: string): string {
  return texto
    .split(/\n{2,}/)
    .map((p) => p.trim())
    .filter(Boolean)
    .map((p) => `<p style="margin:0 0 14px">${escapeHtml(p).replace(/\n/g, '<br>')}</p>`)
    .join('');
}

/** «miércoles 28 de octubre». */
export function diaLargo(dia: string): string {
  return new Date(`${dia}T12:00:00-03:00`).toLocaleDateString('es-AR', { weekday: 'long', day: 'numeric', month: 'long', timeZone: 'America/Argentina/Buenos_Aires' }).replace(',', '');
}

/** «GRADO2-BTT» → «Tarde»; «SALA5-AJE» → «Jornada Extendida»; «ANIO1-ATM» → «Mañana». */
export function turnoDeCodigoCurso(codigo: unknown): string {
  const c = String(codigo || '').toUpperCase();
  return c.endsWith('TT') ? 'Tarde' : c.endsWith('TM') ? 'Mañana' : c.endsWith('JE') ? 'Jornada Extendida' : '';
}

/** Qué franja le toca a una familia según los turnos de sus hijos. */
export function franjaPorTurnos(turnos: string[] | undefined): Franja | 'general' {
  const n = (turnos || []).map((x) => String(x || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, ''));
  const manana = n.some((x) => x.includes('manana'));
  const tarde = n.some((x) => x.includes('tarde'));
  const completa = n.some((x) => x.includes('jornada') || x.includes('completa') || x.includes('extendida'));
  if (manana && tarde) return 'ambos';
  if (manana) return 'manana';
  if (tarde) return 'tarde';
  return completa ? 'completa' : 'general';
}

/**
 * Reparte a las familias entre los días, parejo: cada familia va al día que tiene menos de su misma franja (y si
 * empatan, al que tiene menos familias en total). Así cada día queda con una mezcla parecida y el mediodía no se llena.
 */
export function repartirCitas(lista: Destinatario[], c: Contenido): Record<string, Cita> {
  const dias = c.dias?.length ? c.dias : [c.dia];
  const franjas = c.franjas || FRANJAS_POR_DEFECTO;
  const total = dias.map(() => 0);
  const porFranja = new Map<string, number[]>();
  const citas: Record<string, Cita> = {};
  const orden = [...lista].sort((a, b) => a.email.localeCompare(b.email));
  for (const d of orden) {
    const franja = franjaPorTurnos(d.turnos);
    const cuenta = porFranja.get(franja) || dias.map(() => 0);
    let elegido = 0;
    for (let i = 1; i < dias.length; i += 1) {
      if (cuenta[i] < cuenta[elegido] || (cuenta[i] === cuenta[elegido] && total[i] < total[elegido])) elegido = i;
    }
    cuenta[elegido] += 1;
    total[elegido] += 1;
    porFranja.set(franja, cuenta);
    citas[d.email] = { dia: dias[elegido], hora: franja === 'general' ? c.hora : franjas[franja], franja };
  }
  return citas;
}

/** El contenido con el día y la hora que le tocan a esa familia (si la citación está repartida). */
export function contenidoDeFamilia(c: Contenido, email: string): Contenido {
  const cita = c.citas?.[String(email || '').toLowerCase()];
  return cita ? { ...c, dia: cita.dia, hora: cita.hora } : c;
}

const fechaCorta = (dia: string) => !DIA_RE.test(dia) ? dia : new Date(`${dia}T12:00:00-03:00`).toLocaleDateString('es-AR', { day: '2-digit', month: '2-digit', timeZone: 'America/Argentina/Buenos_Aires' });

export function armarCorreo(tipo: TipoEnvio, asunto: string, c: Contenido, d: Destinatario) {
  if (tipo === 'encuesta') return correoEncuesta({ email: d.email, tutor: d.tutor, inscripcionId: d.inscripcionId });
  const titulos: Record<Exclude<TipoEnvio, 'encuesta'>, string> = { mensaje: 'Novedades de Retrato Escolar', citacion: 'Te esperamos para la foto', promocion: 'Una propuesta para vos' };
  const fila = (etiqueta: string, valor: string) =>
    `<tr><td style="padding:6px 12px 6px 0;color:#64748b;font-size:13px;white-space:nowrap">${etiqueta}</td><td style="padding:6px 0;font-weight:700;font-size:15px">${valor}</td></tr>`;
  const citacion = tipo === 'citacion'
    ? `<div style="background:#fffbeb;border:1px solid #fcd34d;border-radius:12px;padding:14px 18px;margin:4px 0 18px"><table role="presentation" style="border-collapse:collapse">${fila('Día', escapeHtml(DIA_RE.test(c.dia) ? diaLargo(c.dia) : '—'))}${fila('Hora', escapeHtml(c.hora || '—'))}${fila('Lugar', escapeHtml(c.lugar || '—'))}</table></div>`
    : '';
  const promo = tipo === 'promocion' && c.codigo
    ? `<div style="margin:4px 0 18px;text-align:center;background:#fffbeb;border:2px dashed #f59e0b;border-radius:12px;padding:16px"><div style="font-size:11px;font-weight:800;letter-spacing:1px;color:#92400e">TU CÓDIGO DE DESCUENTO</div><div style="font-size:26px;font-weight:800;font-family:monospace;letter-spacing:2px;color:#0f172a;margin-top:4px">${escapeHtml(c.codigo)}</div>${c.vence ? `<div style="font-size:12px;color:#92400e;margin-top:4px">Válido hasta el ${escapeHtml(fechaCorta(c.vence))}</div>` : ''}</div>`
    : tipo === 'promocion' && c.vence ? `<p style="font-size:13px;color:#92400e"><strong>Válido hasta el ${escapeHtml(fechaCorta(c.vence))}.</strong></p>` : '';
  const boton = c.boton || tipo === 'promocion'
    ? `<p style="text-align:center;margin:24px 0"><a href="${escapeHtml(APP_URL())}" style="display:inline-block;background:#f59e0b;color:#0f172a;text-decoration:none;font-weight:800;font-size:16px;padding:14px 28px;border-radius:12px">Ver mis fotos</a></p>`
    : '';
  // Citación repartida (pedido de Pablo, 26/10): saludo alegre «¡Hola Pablo!».
  const nombre = primerNombre(d.tutor) ? ` <strong>${escapeHtml(primerNombre(d.tutor))}</strong>` : '';
  const saludo = tipo === 'citacion' && c.reparto ? `¡Hola${nombre}!` : `Hola${nombre},`;
  return {
    from: process.env.RESEND_FROM_EMAIL || 'Retrato Escolar <fotos@retratoescolar.com.ar>',
    replyTo: resendReplyTo,
    to: [d.email],
    subject: personalizar(asunto, d),
    html: `<!doctype html><html lang="es"><body style="margin:0;background:#f8fafc;font-family:Arial,sans-serif;color:#1e293b"><div style="max-width:600px;margin:24px auto;background:#fff;border:1px solid #e2e8f0;border-radius:16px;overflow:hidden"><div style="background:#0f172a;padding:28px 24px;text-align:center;border-bottom:3px solid #f59e0b"><div style="color:#f59e0b;font-size:11px;font-weight:800;letter-spacing:2px">RETRATO ESCOLAR</div><h1 style="color:#fff;font-size:22px;margin:8px 0 0">${escapeHtml(titulos[tipo])}</h1></div><div style="padding:28px 24px;line-height:1.65;font-size:15px"><p style="margin:0 0 14px">${saludo}</p>${citacion}${parrafos(personalizar(c.texto, d))}${promo}${boton}<p style="margin:18px 0 0">Saludos,<br><strong>Equipo de Retrato Escolar</strong></p><p style="font-size:12px;color:#64748b;border-top:1px solid #e2e8f0;padding-top:14px;margin-top:24px">Si tenés alguna duda, respondé este email: nos llega directo.</p></div></div></body></html>`,
  };
}

// --- Destinatarios -------------------------------------------------------------------------------------------------

interface AlumnoInscripto { nombre: string; curso: string; etiqueta: string; turno: string }

function alumnosDeInscripcion(f: any): AlumnoInscripto[] {
  const uno = (nombre: string, grado: string, division: string, turno: string): AlumnoInscripto | null => {
    if (!grado || !division || !turno) return null;
    return { nombre: String(nombre || '').trim(), curso: determinarCodigoCursoServidor(grado, turno, division), etiqueta: `${grado} "${division}" · ${turno}`, turno: String(turno) };
  };
  const lista = [uno(`${f.alumno_nombre || ''} ${f.alumno_apellido || ''}`, f.grado, f.division, f.turno)];
  for (const h of Array.isArray(f.hermanos) ? f.hermanos : []) lista.push(uno(`${h.alumnoNombre || ''} ${h.alumnoApellido || ''}`, h.grado, h.division, h.turno));
  return lista.filter((a): a is AlumnoInscripto => Boolean(a));
}

async function inscripcionesPublicas(supabase: SupabaseClient) {
  const { data: colegios, error } = await supabase.from('colegios').select('id').eq('activo_publico', true);
  if (error) throw error;
  const ids = (colegios || []).map((c: any) => c.id);
  if (ids.length === 0) return [] as any[];
  return traerTodasLasFilas<any>((desde, hasta) =>
    supabase
      .from('inscripciones')
      .select('id, email, padre_nombre, alumno_nombre, alumno_apellido, grado, division, turno, hermanos, solicita_foto_hermanos, telefono_whatsapp')
      .eq('estado', 'aceptado')
      .in('colegio_id', ids)
      .order('created_at')
      .order('id')
      .range(desde, hasta)
  );
}

async function emailsQueCompraron(supabase: SupabaseClient): Promise<Set<string>> {
  const pedidos = await traerTodasLasFilas<any>((desde, hasta) =>
    supabase.from('pedidos').select('familia_id').in('estado', ['pagado', 'entregado']).is('evento_id', null).order('id').range(desde, hasta)
  );
  const idsFamilia = [...new Set(pedidos.map((p) => p.familia_id).filter(Boolean))] as string[];
  const emails = new Set<string>();
  for (let i = 0; i < idsFamilia.length; i += 200) {
    const { data } = await supabase.from('familias').select('email').in('id', idsFamilia.slice(i, i + 200));
    for (const f of data || []) if (f.email) emails.add(String(f.email).trim().toLowerCase());
  }
  return emails;
}

/**
 * 29/10/2026 (Pablo): pedidos de kit ya pagados a los que les falta la grupal o la individual (sobre todo secundaria,
 * donde no se sacaron individuales). Para citarlos a la toma que completa el kit.
 */
export function faltaFotoDelPack(seleccion: unknown): boolean {
  const s = (seleccion && typeof seleccion === 'object' ? seleccion : {}) as Record<string, unknown>;
  return !String(s.grupalId || '').trim() || !String(s.individualId || '').trim();
}

export async function calcularDestinatarios(supabase: SupabaseClient, filtro: Filtro): Promise<Destinatario[]> {
  const porEmail = new Map<string, Destinatario>();
  const sumar = (email: string, tutor: string, alumnos: string[], inscripcionId: string | null, faltanteId?: string, turnos: string[] = []) => {
    const clave = String(email || '').trim().toLowerCase();
    if (!EMAIL_RE.test(clave)) return;
    const d = porEmail.get(clave) || { email: clave, tutor: tutor || '', alumnos: [], inscripcionId, faltanteIds: [] };
    for (const a of alumnos) if (a && !d.alumnos.includes(a)) d.alumnos.push(a);
    if (!d.inscripcionId && inscripcionId) d.inscripcionId = inscripcionId;
    if (!d.tutor && tutor) d.tutor = tutor;
    if (faltanteId) d.faltanteIds.push(faltanteId);
    for (const t of turnos) if (t && !(d.turnos ||= []).includes(t)) d.turnos.push(t);
    porEmail.set(clave, d);
  };

  if (filtro.grupo === 'faltantes') {
    const filas = await traerTodasLasFilas<any>((desde, hasta) =>
      supabase.from('fotos_faltantes_solicitudes').select('id, alumno_nombre, codigo_curso, tutor_nombre, contacto_email, inscripcion_id, lugar').eq('estado', 'pendiente').neq('lugar', 'grupal').order('id').range(desde, hasta)
    );
    for (const f of filas) {
      if (filtro.cursos.length && !filtro.cursos.includes(String(f.codigo_curso || '').toUpperCase())) continue;
      // El turno sale del código del curso (…TM, …TT, …JE): define la franja de la citación repartida.
      sumar(f.contacto_email, f.tutor_nombre, [String(f.alumno_nombre || '').trim()], f.inscripcion_id || null, f.id, [turnoDeCodigoCurso(f.codigo_curso)]);
    }
    return [...porEmail.values()];
  }

  if (filtro.grupo === 'pagados_sin_fotos') {
    const pedidos = await traerTodasLasFilas<any>((desde, hasta) =>
      supabase.from('pedidos').select('id, familia_id, curso_codigo, alumno_nombre, fotos_seleccionadas, archivado, tipo_kit').eq('estado', 'pagado').is('evento_id', null).order('id').range(desde, hasta)
    );
    // 29/10/2026: un pedido de fotos extra no es un kit (no tiene grupal ni individual): no se lo cita.
    const incompletos = pedidos.filter((p) => !p.archivado && p.tipo_kit !== 'fotos_extra' && p.familia_id && faltaFotoDelPack(p.fotos_seleccionadas) && (!filtro.cursos.length || filtro.cursos.includes(String(p.curso_codigo || '').toUpperCase())));
    const ids = [...new Set(incompletos.map((p) => String(p.familia_id)))];
    const familias = new Map<string, any>();
    for (let i = 0; i < ids.length; i += 200) {
      const { data, error } = await supabase.from('familias').select('id, email, nombre').in('id', ids.slice(i, i + 200));
      if (error) throw error;
      for (const f of data || []) familias.set(String(f.id), f);
    }
    for (const p of incompletos) {
      const f = familias.get(String(p.familia_id));
      if (f) sumar(f.email, f.nombre, [String(p.alumno_nombre || '').trim()], null, undefined, [turnoDeCodigoCurso(p.curso_codigo)]);
    }
    return [...porEmail.values()].sort((a, b) => a.email.localeCompare(b.email));
  }

  const inscripciones = await inscripcionesPublicas(supabase);
  const compraron = filtro.grupo === 'compraron' || filtro.grupo === 'no_compraron' ? await emailsQueCompraron(supabase) : null;
  for (const f of inscripciones) {
    const email = String(f.email || '').trim().toLowerCase();
    if (filtro.grupo === 'familia' && email !== filtro.email) continue;
    if (filtro.grupo === 'foto_hermanos' && !f.solicita_foto_hermanos) continue;
    if (filtro.grupo === 'compraron' && !compraron?.has(email)) continue;
    if (filtro.grupo === 'no_compraron' && compraron?.has(email)) continue;
    const alumnos = alumnosDeInscripcion(f);
    const enCursos = filtro.cursos.length ? alumnos.filter((a) => filtro.cursos.includes(a.curso)) : alumnos;
    if (enCursos.length === 0) continue;
    // Los turnos de TODOS sus hijos (no sólo los de los cursos elegidos): definen la franja de la citación.
    sumar(email, f.padre_nombre, enCursos.map((a) => a.nombre), f.id, undefined, alumnos.map((a) => a.turno));
  }
  return [...porEmail.values()].sort((a, b) => a.email.localeCompare(b.email));
}

export function describirFiltro(filtro: Filtro, etiquetasCursos: Map<string, string>): string {
  const base = filtro.grupo === 'familia' ? `Familia ${filtro.email}` : NOMBRE_GRUPO[filtro.grupo];
  return filtro.cursos.length ? `${base} · ${filtro.cursos.map((c) => etiquetasCursos.get(c) || c).join(', ')}` : base;
}

async function etiquetasDeCursos(supabase: SupabaseClient): Promise<Map<string, { etiqueta: string; familias: number }>> {
  const mapa = new Map<string, { etiqueta: string; familias: Set<string> }>();
  for (const f of await inscripcionesPublicas(supabase)) {
    for (const a of alumnosDeInscripcion(f)) {
      const c = mapa.get(a.curso) || { etiqueta: a.etiqueta, familias: new Set<string>() };
      c.familias.add(String(f.email || '').toLowerCase());
      mapa.set(a.curso, c);
    }
  }
  return new Map([...mapa.entries()].map(([k, v]) => [k, { etiqueta: v.etiqueta, familias: v.familias.size }]));
}

// --- Rutas -------------------------------------------------------------------------------------------------------

function sinSupabase(res: Response) {
  return res.status(500).json({ success: false, error: 'Supabase no configurado en el servidor' });
}

rutas.get('/api/admin/emails/cursos', requireAdminAuth, async (_req: Request, res: Response) => {
  try {
    const supabase = getServerSupabase();
    if (!supabase) return sinSupabase(res);
    const cursos = [...(await etiquetasDeCursos(supabase)).entries()]
      .map(([codigo, v]) => ({ codigo, etiqueta: v.etiqueta, familias: v.familias }))
      .sort((a, b) => a.codigo.localeCompare(b.codigo, 'es', { numeric: true }));
    return res.json({ success: true, cursos });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err?.message || 'No se pudieron leer los cursos.' });
  }
});

rutas.get('/api/admin/emails/buscar-familia', requireAdminAuth, async (req: Request, res: Response) => {
  try {
    const supabase = getServerSupabase();
    if (!supabase) return sinSupabase(res);
    const q = String(req.query.q || '').trim().toLowerCase();
    if (q.length < 2) return res.json({ success: true, familias: [] });
    const familias = (await inscripcionesPublicas(supabase))
      .filter((f) => [f.email, f.padre_nombre, ...alumnosDeInscripcion(f).map((a) => a.nombre)].some((v) => String(v || '').toLowerCase().includes(q)))
      .slice(0, 12)
      .map((f) => ({ email: String(f.email || '').toLowerCase(), tutor: f.padre_nombre || '', alumnos: alumnosDeInscripcion(f).map((a) => `${a.nombre} (${a.etiqueta})`) }));
    return res.json({ success: true, familias });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err?.message || 'No se pudo buscar.' });
  }
});

rutas.post('/api/admin/emails/destinatarios', requireAdminAuth, async (req: Request, res: Response) => {
  try {
    const supabase = getServerSupabase();
    if (!supabase) return sinSupabase(res);
    const filtro = leerFiltro(req.body);
    if (!filtro) return res.status(400).json({ success: false, error: 'Elegí a quién mandarle.' });
    const lista = await calcularDestinatarios(supabase, filtro);
    // Vista previa del reparto de una citación en varios días (lo mismo que se va a guardar al enviar).
    const r = req.body?.reparto;
    const leido = r ? leerContenido('citacion', { asunto: 'x x x', texto: 'x x x x x', lugar: 'x x', hora: r.hora || 'x', dias: r.dias, franjas: r.franjas, reparto: true }) : null;
    const citas = leido?.ok ? repartirCitas(lista, leido.contenido) : null;
    return res.json({ success: true, total: lista.length, destinatarios: lista.map((d) => ({ email: d.email, tutor: d.tutor, alumnos: d.alumnos, ...(citas ? { cita: citas[d.email] } : {}) })) });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err?.message || 'No se pudieron calcular los destinatarios.' });
  }
});

rutas.post('/api/admin/emails/vista-previa', requireAdminAuth, (req: Request, res: Response) => {
  const tipo = (['mensaje', 'citacion', 'promocion', 'encuesta'] as TipoEnvio[]).includes(req.body?.tipo) ? (req.body.tipo as TipoEnvio) : 'mensaje';
  const contenido = leerContenido(tipo, { ...req.body, asunto: req.body?.asunto || 'Asunto', texto: req.body?.texto || '' });
  const c = contenido.ok ? contenido.contenido : { texto: String(req.body?.texto || ''), boton: false, dia: '', hora: '', lugar: '', codigo: '', vence: '' };
  const ejemplo: Destinatario = { email: 'familia@ejemplo.com', tutor: 'María López', alumnos: ['Sofía López', 'Juan López'], inscripcionId: null, faltanteIds: [], turnos: ['Mañana', 'Tarde'] };
  const base = { ...c, dia: DIA_RE.test(c.dia) ? c.dia : '', hora: c.hora || '', lugar: c.lugar || '' } as Contenido;
  const correo = armarCorreo(tipo, String(req.body?.asunto || ''), base.reparto ? contenidoDeFamilia({ ...base, citas: repartirCitas([ejemplo], base) }, ejemplo.email) : base, ejemplo);
  return res.json({ success: true, asunto: correo.subject, html: correo.html });
});

rutas.post('/api/admin/emails/redactar', requireAdminAuth, limitarFrecuencia('emails-redactar', 30, 10 * 60 * 1000), async (req: Request, res: Response) => {
  try {
    if (!iaConfigurada()) return res.status(503).json({ success: false, error: ERROR_IA_NO_CONFIGURADA });
    const tipo = String(req.body?.tipo || 'mensaje');
    const idea = String(req.body?.idea || '').trim().slice(0, 1500);
    if (idea.length < 5) return res.status(400).json({ success: false, error: 'Escribí en pocas palabras qué querés decir.' });
    const grupo = GRUPOS.includes(req.body?.grupo) ? NOMBRE_GRUPO[req.body.grupo as Grupo] : 'familias';
    const repartida = tipo === 'citacion' && req.body?.reparto === true;
    const prompt = `
Retrato Escolar le va a mandar un email a un grupo de familias: ${grupo}.
Tipo de email: ${repartida ? 'citación a una toma de fotos. A cada familia el sistema ya le asignó UN día y UN horario según el turno de sus hijos (las que tienen hijos en ambos turnos, al mediodía), y aparecen destacados en un recuadro junto con el lugar: no los repitas, no menciones otros días ni horarios y no les pidas que elijan ni que vengan más temprano o más tarde; pediles que respeten el horario asignado y que, si no pueden, escriban para reorganizarlo' : tipo === 'citacion' ? 'citación a una toma de fotos (el día, la hora y el lugar ya aparecen destacados en un recuadro: no los repitas)' : tipo === 'promocion' ? 'promoción (el código de descuento y el botón «Ver mis fotos» ya aparecen en el mail: no los repitas)' : 'mensaje informativo'}.
Lo que el fotógrafo quiere comunicar: ${idea}

Escribí el asunto (corto, claro, hasta 70 caracteres) y el cuerpo del email: español rioplatense ("vos"), cálido, breve y claro,
en párrafos cortos separados por una línea en blanco. Sin saludo inicial ni firma (el sistema los agrega). Podés usar {nombre}
(nombre del tutor) y {alumnos} (nombres de los chicos) donde quede natural. No inventes fechas, precios, montos ni promesas que
no estén en lo que quiere comunicar. Nunca incluyas códigos de acceso ni DNIs.
Respondé con JSON: {"asunto": "...", "texto": "..."}
`.trim();
    const crudo = await generarTextoIA({ sistema: contextoNegocioConsultas(await textoEventoFotoHermanos()), prompt, json: true, esfuerzo: 'low', maxTokens: 2000 });
    const json = JSON.parse(crudo.slice(crudo.indexOf('{'), crudo.lastIndexOf('}') + 1));
    return res.json({ success: true, asunto: String(json.asunto || '').slice(0, 150), texto: String(json.texto || '').slice(0, 5000) });
  } catch (err: any) {
    console.error('[emails] Error al redactar con IA:', err);
    return res.status(esIaSaturada(err) ? 503 : 500).json({ success: false, error: esIaSaturada(err) ? AVISO_IA_SATURADA : 'La IA no pudo armar el mail. Escribilo a mano o probá de nuevo.' });
  }
});

rutas.post('/api/admin/emails/prueba', requireAdminAuth, async (req: Request, res: Response) => {
  try {
    const resend = getResendClient();
    if (!resend) return res.status(503).json({ success: false, error: 'El envío de emails no está configurado (RESEND_API_KEY).' });
    const tipo = (['mensaje', 'citacion', 'promocion', 'encuesta'] as TipoEnvio[]).includes(req.body?.tipo) ? (req.body.tipo as TipoEnvio) : null;
    const email = String(req.body?.email || '').trim();
    if (!tipo || !EMAIL_RE.test(email)) return res.status(400).json({ success: false, error: 'Falta el tipo o el email de prueba.' });
    const leido = leerContenido(tipo, req.body);
    if (leido.ok === false) return res.status(400).json({ success: false, error: leido.error });
    const ejemplo: Destinatario = { email, tutor: 'Pablo', alumnos: ['Sofía López', 'Juan López'], inscripcionId: null, faltanteIds: [], turnos: ['Mañana', 'Tarde'] };
    const c = leido.contenido.reparto ? contenidoDeFamilia({ ...leido.contenido, citas: repartirCitas([ejemplo], leido.contenido) }, email) : leido.contenido;
    const correo = armarCorreo(tipo, leido.asunto, c, ejemplo);
    const r = await resend.emails.send({ ...correo, subject: `[PRUEBA] ${correo.subject}` });
    if (r.error) return res.status(502).json({ success: false, error: r.error.message || 'No se pudo mandar la prueba.' });
    return res.json({ success: true });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err?.message || 'No se pudo mandar la prueba.' });
  }
});

// Crea el envío con la lista de destinatarios del momento (no manda nada todavía).
rutas.post('/api/admin/emails/envios', requireAdminAuth, async (req: Request, res: Response) => {
  try {
    const supabase = getServerSupabase();
    if (!supabase) return sinSupabase(res);
    const tipo = (['mensaje', 'citacion', 'promocion', 'encuesta'] as TipoEnvio[]).includes(req.body?.tipo) ? (req.body.tipo as TipoEnvio) : null;
    if (!tipo) return res.status(400).json({ success: false, error: 'Tipo de mail no válido.' });
    const filtro = leerFiltro(req.body?.filtro);
    if (!filtro) return res.status(400).json({ success: false, error: 'Elegí a quién mandarle.' });
    const leido = leerContenido(tipo, req.body);
    if (leido.ok === false) return res.status(400).json({ success: false, error: leido.error });
    const lista = await calcularDestinatarios(supabase, filtro);
    if (lista.length === 0) return res.status(400).json({ success: false, error: 'No hay familias en ese grupo.' });
    const etiquetas = new Map([...(await etiquetasDeCursos(supabase)).entries()].map(([k, v]) => [k, v.etiqueta]));
    const contenido: Contenido = tipo === 'citacion' && leido.contenido.reparto ? { ...leido.contenido, citas: repartirCitas(lista, leido.contenido) } : leido.contenido;
    const { data: envio, error } = await supabase
      .from('envios_email')
      .insert({ tipo, asunto: leido.asunto, contenido, filtro, descripcion_destinatarios: describirFiltro(filtro, etiquetas), total: lista.length })
      .select('id')
      .single();
    if (error) throw error;
    for (let i = 0; i < lista.length; i += 300) {
      const { error: errDest } = await supabase.from('envios_email_destinatarios').insert(
        lista.slice(i, i + 300).map((d) => ({ envio_id: envio.id, email: d.email, tutor: d.tutor, alumnos: d.alumnos.join(', '), inscripcion_id: d.inscripcionId, faltante_ids: d.faltanteIds.length ? d.faltanteIds : null }))
      );
      if (errDest) throw errDest;
    }
    return res.json({ success: true, id: envio.id, total: lista.length });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err?.message || 'No se pudo crear el envío.' });
  }
});

// Manda una tanda de los pendientes de un envío (lo que entra en el tiempo de la función); el panel repite.
rutas.post('/api/admin/emails/envios/:id/enviar', requireAdminAuth, async (req: Request, res: Response) => {
  try {
    if (!UUID_RE.test(req.params.id)) return res.status(400).json({ success: false, error: 'Envío no válido.' });
    const supabase = getServerSupabase();
    if (!supabase) return sinSupabase(res);
    const resend = getResendClient();
    if (!resend) return res.status(503).json({ success: false, error: 'El envío de emails no está configurado (RESEND_API_KEY).' });
    const { data: envio, error } = await supabase.from('envios_email').select('*').eq('id', req.params.id).maybeSingle();
    if (error) throw error;
    if (!envio) return res.status(404).json({ success: false, error: 'No encontramos ese envío.' });
    const inicio = Date.now();
    let enviados = 0;
    let fallidos = 0;
    while (Date.now() - inicio < TIEMPO_MAXIMO_MS) {
      const { data: lote, error: errLote } = await supabase.from('envios_email_destinatarios').select('*').eq('envio_id', envio.id).eq('estado', 'pendiente').order('email').limit(100);
      if (errLote) throw errLote;
      if (!lote || lote.length === 0) break;
      const destinatarios: Destinatario[] = lote.map((f: any) => ({ email: f.email, tutor: f.tutor || '', alumnos: String(f.alumnos || '').split(', ').filter(Boolean), inscripcionId: f.inscripcion_id, faltanteIds: f.faltante_ids || [] }));
      const clave = crypto.createHash('sha256').update(`${envio.id}|${lote.map((f: any) => f.id).sort().join(',')}`).digest('hex');
      let r: any;
      try {
        r = await resend.batch.send(destinatarios.map((d) => armarCorreo(envio.tipo, envio.asunto, contenidoDeFamilia(envio.contenido, d.email), d)), { idempotencyKey: `envio-familias-${clave}`, batchValidation: 'permissive' });
      } catch (errRed: any) {
        console.error('[emails] Error de red enviando una tanda:', errRed);
        break; // queda pendiente: se reintenta en la próxima vuelta
      }
      if (r?.error) {
        console.error('[emails] Resend rechazó una tanda:', r.error);
        break;
      }
      const errores: Array<{ index?: number; message?: string }> = r?.data?.errors || [];
      const conError = new Map(errores.filter((e) => Number.isInteger(e?.index)).map((e) => [Number(e.index), String(e.message || 'Rechazado')]));
      const ids: Array<{ id?: string }> = r?.data?.data || [];
      const ahora = new Date().toISOString();
      let k = 0;
      for (let j = 0; j < lote.length; j += 1) {
        const fila = lote[j];
        if (conError.has(j)) {
          fallidos += 1;
          await supabase.from('envios_email_destinatarios').update({ estado: 'fallido', error: conError.get(j)?.slice(0, 300) }).eq('id', fila.id);
          continue;
        }
        const resendId = ids[k]?.id || null;
        k += 1;
        enviados += 1;
        await supabase.from('envios_email_destinatarios').update({ estado: 'enviado', resend_id: resendId, enviado_at: ahora }).eq('id', fila.id);
      }
      const salieron = lote.filter((_: any, j: number) => !conError.has(j));
      if (envio.tipo === 'encuesta') {
        const idsInsc = salieron.map((f: any) => f.inscripcion_id).filter(Boolean);
        if (idsInsc.length) await supabase.from('inscripciones').update({ encuesta_enviada_at: ahora }).in('id', idsInsc);
      }
      if (envio.tipo === 'citacion') {
        // Citación a las de fotos faltantes: queda anotada en cada pedido, como el «Convocar» de Faltantes
        // (con el día y la hora de cada familia, si la citación está repartida).
        const porCita = new Map<string, { c: Contenido; ids: string[] }>();
        for (const f of salieron) {
          if (!f.faltante_ids?.length) continue;
          const c = contenidoDeFamilia(envio.contenido || {}, f.email);
          const k = `${c.dia}|${c.hora}`;
          const g = porCita.get(k) || { c, ids: [] };
          g.ids.push(...f.faltante_ids);
          porCita.set(k, g);
        }
        for (const { c, ids: idsFaltantes } of porCita.values()) {
          const { error: errFalt } = await supabase
            .from('fotos_faltantes_solicitudes')
            .update({ convocatoria_dia: c.dia, convocatoria_hora: c.hora, convocatoria_lugar: c.lugar, convocatoria_nota: c.texto || null, convocada_at: ahora })
            .in('id', idsFaltantes);
          if (errFalt) console.error('[emails] Citación enviada pero no se pudo anotar en Faltantes:', errFalt.message);
        }
      }
      await new Promise((ok) => setTimeout(ok, 600));
    }
    const { count: pendientes } = await supabase.from('envios_email_destinatarios').select('id', { count: 'exact', head: true }).eq('envio_id', envio.id).eq('estado', 'pendiente');
    if (!pendientes) await supabase.from('envios_email').update({ terminado_at: new Date().toISOString() }).eq('id', envio.id).is('terminado_at', null);
    return res.json({ success: true, enviados, fallidos, pendientes: pendientes || 0 });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err?.message || 'No se pudo mandar.' });
  }
});

async function contarPorEstado(supabase: SupabaseClient, envioIds: string[]) {
  const cuentas = new Map<string, Record<string, number>>();
  for (let i = 0; i < envioIds.length; i += 50) {
    const filas = await traerTodasLasFilas<any>((desde, hasta) =>
      supabase.from('envios_email_destinatarios').select('envio_id, estado').in('envio_id', envioIds.slice(i, i + 50)).order('id').range(desde, hasta)
    );
    for (const f of filas) {
      const c = cuentas.get(f.envio_id) || {};
      c[f.estado] = (c[f.estado] || 0) + 1;
      cuentas.set(f.envio_id, c);
    }
  }
  return cuentas;
}

rutas.get('/api/admin/emails/envios', requireAdminAuth, async (_req: Request, res: Response) => {
  try {
    const supabase = getServerSupabase();
    if (!supabase) return sinSupabase(res);
    const { data, error } = await supabase.from('envios_email').select('id, tipo, asunto, descripcion_destinatarios, total, creado_at, terminado_at').order('creado_at', { ascending: false }).limit(100);
    if (error) throw error;
    const cuentas = await contarPorEstado(supabase, (data || []).map((e: any) => e.id));
    return res.json({ success: true, envios: (data || []).map((e: any) => ({ ...e, estados: cuentas.get(e.id) || {} })) });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err?.message || 'No se pudo leer el historial.' });
  }
});

rutas.get('/api/admin/emails/envios/:id', requireAdminAuth, async (req: Request, res: Response) => {
  try {
    if (!UUID_RE.test(req.params.id)) return res.status(400).json({ success: false, error: 'Envío no válido.' });
    const supabase = getServerSupabase();
    if (!supabase) return sinSupabase(res);
    const { data: envio } = await supabase.from('envios_email').select('contenido').eq('id', req.params.id).maybeSingle();
    const citas: Record<string, Cita> = envio?.contenido?.citas || {};
    const destinatarios = await traerTodasLasFilas<any>((desde, hasta) =>
      supabase.from('envios_email_destinatarios').select('email, tutor, alumnos, estado, error, enviado_at').eq('envio_id', req.params.id).order('email').range(desde, hasta)
    );
    return res.json({ success: true, destinatarios: destinatarios.map((d) => (citas[d.email] ? { ...d, cita: citas[d.email] } : d)) });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err?.message || 'No se pudo leer el envío.' });
  }
});

// Familias cuyo email no llega: los rebotes de los envíos y los avisos de rebote del webhook (Estado del sistema).
rutas.get('/api/admin/emails/rebotes', requireAdminAuth, async (_req: Request, res: Response) => {
  try {
    const supabase = getServerSupabase();
    if (!supabase) return sinSupabase(res);
    const [desdeEnvios, reportes, inscripciones] = await Promise.all([
      traerTodasLasFilas<any>((desde, hasta) => supabase.from('envios_email_destinatarios').select('email, error, enviado_at').eq('estado', 'rebotado').order('id').range(desde, hasta)),
      traerTodasLasFilas<any>((desde, hasta) => supabase.from('reportes_errores').select('detalle, created_at').eq('detalle->>tipo', 'rebote_email').order('created_at', { ascending: false }).range(desde, hasta)),
      inscripcionesPublicas(supabase),
    ]);
    const rebotes = new Map<string, { email: string; motivo: string; asunto: string; fecha: string }>();
    for (const r of reportes) for (const email of r.detalle?.destinatarios || []) {
      const e = String(email).toLowerCase();
      if (!rebotes.has(e)) rebotes.set(e, { email: e, motivo: r.detalle?.motivo || '', asunto: r.detalle?.asunto || '', fecha: r.created_at });
    }
    for (const d of desdeEnvios) {
      const e = String(d.email).toLowerCase();
      if (!rebotes.has(e)) rebotes.set(e, { email: e, motivo: d.error || '', asunto: '', fecha: d.enviado_at || '' });
    }
    const lista = [...rebotes.values()].map((r) => {
      const insc = inscripciones.find((f) => String(f.email || '').toLowerCase() === r.email);
      return {
        ...r,
        tutor: insc?.padre_nombre || '',
        alumnos: insc ? alumnosDeInscripcion(insc).map((a) => `${a.nombre} (${a.etiqueta})`) : [],
        whatsapp: insc?.telefono_whatsapp || '',
        corregido: !insc, // ya no hay una inscripción con ese email (se corrigió o no era de una inscripción)
      };
    });
    lista.sort((a, b) => Number(a.corregido) - Number(b.corregido) || String(b.fecha).localeCompare(String(a.fecha)));
    return res.json({ success: true, rebotes: lista });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err?.message || 'No se pudieron leer los rebotes.' });
  }
});

// Corrige un email mal escrito en la inscripción (y en la familia y sus consultas), para que los próximos mails lleguen.
rutas.post('/api/admin/emails/corregir-email', requireAdminAuth, async (req: Request, res: Response) => {
  try {
    const supabase = getServerSupabase();
    if (!supabase) return sinSupabase(res);
    const viejo = String(req.body?.viejo || '').trim().toLowerCase();
    const nuevo = String(req.body?.nuevo || '').trim().toLowerCase();
    if (!EMAIL_RE.test(viejo) || !EMAIL_RE.test(nuevo)) return res.status(400).json({ success: false, error: 'Email no válido.' });
    if (viejo === nuevo) return res.status(400).json({ success: false, error: 'Es el mismo email.' });
    const { data: inscs, error } = await supabase.from('inscripciones').update({ email: nuevo, updated_at: new Date().toISOString() }).ilike('email', viejo.replace(/[%_\\]/g, (c) => `\\${c}`)).select('id');
    if (error) throw error;
    await supabase.from('familias').update({ email: nuevo }).ilike('email', viejo.replace(/[%_\\]/g, (c) => `\\${c}`));
    await supabase.from('consultas_familias').update({ email: nuevo }).ilike('email', viejo.replace(/[%_\\]/g, (c) => `\\${c}`));
    return res.json({ success: true, inscripciones: (inscs || []).length });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err?.message || 'No se pudo corregir el email.' });
  }
});

/** Lo llama el webhook de Resend (correoEntrante.ts) ante un rebote permanente: marca el destinatario del envío. */
export async function registrarRebotesEnvios(supabase: SupabaseClient, emailId: string, motivo: string): Promise<void> {
  if (!emailId) return;
  try {
    const { error } = await supabase.from('envios_email_destinatarios').update({ estado: 'rebotado', error: motivo.slice(0, 300) || 'La casilla no existe o rechazó el mail.' }).eq('resend_id', emailId);
    if (error) console.error('[emails] No se pudo marcar el rebote:', error.message);
  } catch (err: any) {
    // Nunca frena el aviso de rebote en Estado del sistema.
    console.error('[emails] No se pudo marcar el rebote:', err?.message || err);
  }
}

export { rutas as rutasEmailsFamilias };
