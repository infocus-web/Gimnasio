// Copias de la lupa preparadas de antemano (25/10/2026, Pablo: «me preocupa el tiempo que tarda la lupa en mostrar la
// imagen»). La primera vez que alguien pasa la lupa por una foto, el servidor baja el original (~2 MB) y arma la copia
// nítida de 1600 px (lupa/recorte.ts, armarCopiaLupa): ~1,7 s más el arranque de la función. Con la copia ya guardada
// al lado del original (`<original>.lupa.jpg`, bucket privado fotos-hd) la primera vez baja a ~0,6 s.
// - POST /api/admin/fotos/preparar-lupa: botón de «Cargar fotos»; arma una tanda y dice cuántas faltan (el panel repite).
// - /api/cron/preparar-lupa: lo mismo, solo, cada 15 minutos (vercel.json), para las fotos que se publiquen después.
// Las copias de 800 px de antes del 17/10 (cuando la lupa pasó a 1600 px) se rehacen.
import type { SupabaseClient } from '@supabase/supabase-js';
import express from 'express';
import type { Request, Response } from 'express';
import { armarCopiaLupa, rutaCopiaLupa } from '../../lupa/recorte.js';
import { autorizarTareaProgramada, requireAdminAuth } from '../nucleo/auth.js';
import { getServerSupabase } from '../nucleo/clientes.js';
import { enLotes, traerTodasLasFilas } from '../nucleo/utilidades.js';

const rutas = express.Router();
const BUCKET = 'fotos-hd';
const PARALELO = 3;
/** Copias guardadas antes de esta fecha son de 800 px (lupa vieja): se rehacen. */
export const COPIAS_VALIDAS_DESDE = Date.parse('2026-10-18T00:00:00-03:00');

function carpetaYNombre(ruta: string): { carpeta: string; nombre: string } {
  const i = ruta.lastIndexOf('/');
  return i < 0 ? { carpeta: '', nombre: ruta } : { carpeta: ruta.slice(0, i), nombre: ruta.slice(i + 1) };
}

/** Rutas de los originales publicados que todavía no tienen su copia de lupa (válida). */
export async function originalesSinCopiaLupa(supabase: SupabaseClient): Promise<string[]> {
  const fotos = await traerTodasLasFilas<{ storage_path: string | null }>((desde, hasta) =>
    supabase.from('fotos').select('storage_path').not('publicada_at', 'is', null).not('storage_path', 'is', null).order('id').range(desde, hasta)
  );
  const porCarpeta = new Map<string, Set<string>>();
  for (const f of fotos) {
    const ruta = String(f.storage_path || '');
    if (!ruta || ruta.endsWith('.lupa.jpg')) continue;
    const { carpeta, nombre } = carpetaYNombre(ruta);
    if (!porCarpeta.has(carpeta)) porCarpeta.set(carpeta, new Set());
    porCarpeta.get(carpeta)!.add(nombre);
  }
  const pendientes: string[] = [];
  for (const lote of enLotes([...porCarpeta.keys()], 8)) {
    await Promise.all(lote.map(async (carpeta) => {
      const copias = new Set<string>();
      for (let offset = 0; ; offset += 1000) {
        const { data, error } = await supabase.storage.from(BUCKET).list(carpeta, { limit: 1000, offset });
        if (error) throw error;
        for (const o of data || []) {
          const fecha = Date.parse(String((o as any).updated_at || (o as any).created_at || ''));
          if (o.name.endsWith('.lupa.jpg') && Number.isFinite(fecha) && fecha >= COPIAS_VALIDAS_DESDE) copias.add(o.name);
        }
        if (!data || data.length < 1000) break;
      }
      for (const nombre of porCarpeta.get(carpeta) || []) {
        if (!copias.has(`${nombre}.lupa.jpg`)) pendientes.push(carpeta ? `${carpeta}/${nombre}` : nombre);
      }
    }));
  }
  return pendientes;
}

/** Arma copias hasta agotar el presupuesto de tiempo. */
export async function prepararCopiasLupa(supabase: SupabaseClient, presupuestoMs: number): Promise<{ preparadas: number; errores: number; restantes: number }> {
  const inicio = Date.now();
  const pendientes = await originalesSinCopiaLupa(supabase);
  let preparadas = 0;
  let errores = 0;
  let i = 0;
  while (i < pendientes.length && Date.now() - inicio < presupuestoMs) {
    const lote = pendientes.slice(i, i + PARALELO);
    i += lote.length;
    const resultados = await Promise.all(lote.map(async (ruta) => {
      try {
        const { data: archivo, error } = await supabase.storage.from(BUCKET).download(ruta);
        if (error || !archivo) throw error || new Error('sin archivo');
        const { data } = await armarCopiaLupa(Buffer.from(await archivo.arrayBuffer()));
        const { error: errSubir } = await supabase.storage.from(BUCKET).upload(rutaCopiaLupa(ruta), data, { contentType: 'image/jpeg', upsert: true });
        if (errSubir) throw errSubir;
        return true;
      } catch (err: any) {
        console.warn('[preparar-lupa] No se pudo preparar', ruta, err?.message || err);
        return false;
      }
    }));
    for (const ok of resultados) if (ok) preparadas++; else errores++;
  }
  return { preparadas, errores, restantes: pendientes.length - preparadas };
}

rutas.post('/api/admin/fotos/preparar-lupa', requireAdminAuth, async (req: Request, res: Response) => {
  try {
    const supabase = getServerSupabase();
    if (!supabase) return res.status(500).json({ success: false, error: 'Supabase no configurado en el servidor' });
    // Sólo contar (para mostrar el botón con cuántas faltan) o preparar una tanda de ~35 s.
    if (req.body?.soloContar === true) return res.json({ success: true, preparadas: 0, errores: 0, restantes: (await originalesSinCopiaLupa(supabase)).length });
    return res.json({ success: true, ...(await prepararCopiasLupa(supabase, 35000)) });
  } catch (err: any) {
    console.error('[preparar-lupa] Error:', err);
    return res.status(500).json({ success: false, error: 'No se pudieron preparar las copias de la lupa.' });
  }
});

rutas.all('/api/cron/preparar-lupa', async (req: Request, res: Response) => {
  if (!(await autorizarTareaProgramada(req))) return res.status(401).json({ success: false, error: 'No autorizado.' });
  const supabase = getServerSupabase();
  if (!supabase) return res.status(500).json({ success: false, error: 'Supabase no configurado en el servidor' });
  try {
    const resultado = await prepararCopiasLupa(supabase, 40000);
    console.log('[cron preparar-lupa]', resultado);
    return res.json({ success: true, ...resultado });
  } catch (err: any) {
    console.error('[cron preparar-lupa] Error:', err);
    return res.status(500).json({ success: false, error: 'No se pudieron preparar las copias de la lupa.' });
  }
});

export { rutas as rutasPrepararLupa };
