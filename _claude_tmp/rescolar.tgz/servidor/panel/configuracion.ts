// Panel → Configuración (30/10/2026, pedido de Pablo): fechas límite de la temporada editables sin tocar código.
// GET /api/plazos es público (la web de las familias muestra y aplica las fechas); POST /api/admin/plazos exige
// sesión de admin. Las fechas viven en servidor/nucleo/plazosTemporada.ts.
import express from 'express';
import type { Request, Response } from 'express';
import { requireAdminAuth } from '../nucleo/auth.js';
import { getServerSupabase } from '../nucleo/clientes.js';
import { aplicarPlazos, asegurarPlazosActualizados, CLAVE_CONFIG_PLAZOS, PLAZOS_POR_DEFECTO, plazosVigentes, validarPlazos } from '../nucleo/plazosTemporada.js';

const rutas = express.Router();

rutas.get('/api/plazos', async (_req: Request, res: Response) => {
  await asegurarPlazosActualizados();
  res.set('Cache-Control', 'public, max-age=60');
  res.json({ success: true, plazos: plazosVigentes(), porDefecto: PLAZOS_POR_DEFECTO });
});

rutas.post('/api/admin/plazos', requireAdminAuth, async (req: Request, res: Response) => {
  const nuevos = validarPlazos(req.body?.plazos);
  if (!nuevos) return res.status(400).json({ success: false, error: 'Revisá las fechas: tienen que ser días válidos (por ejemplo 15/11/2026).' });
  const supabase = getServerSupabase();
  if (!supabase) return res.status(500).json({ success: false, error: 'Supabase no configurado en el servidor' });
  const { error } = await supabase
    .from('configuracion')
    .upsert({ clave: CLAVE_CONFIG_PLAZOS, valor: nuevos.kitImpreso, datos_extra: nuevos, updated_at: new Date().toISOString() }, { onConflict: 'clave' });
  if (error) return res.status(500).json({ success: false, error: error.message });
  aplicarPlazos(nuevos);
  return res.json({ success: true, plazos: nuevos });
});

export { rutas as rutasConfiguracion };
