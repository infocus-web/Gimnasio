// Panel propio del colegio (10/10/2026, pedido de Pablo; plan en el proyecto: claude/panel-colegio-plan.md).
//
// La secretaría / dirección entra a retratoescolar.com.ar/colegio?c=<codigo> con un PIN de 6 números que
// genera Pablo desde su panel (Colegios → Panel del colegio). Ve:
//   - su comisión de la temporada, con la MISMA cuenta que la Liquidación de Pablo, y el detalle por número
//     de pedido y curso, SIN datos de las familias (como pide la cláusula OCTAVA BIS del convenio);
//   - el avance por curso, sólo en números (nómina, familias inscriptas, kits comprados e impresos);
//   - las fechas de la campaña (las carga Pablo) para los mensajes de difusión;
//   - las entregas de los kits impresos de cada curso, que puede marcar como entregados.
// No ve montos por familia, emails, teléfonos, fotos ni pedidos sin pagar.
//
// Acceso: el PIN se guarda sólo cifrado (scrypt) en colegios_panel (tabla aparte, sin acceso desde el
// navegador). La sesión es un token firmado que dura 7 días; deja de valer al dar un PIN nuevo o al apagar
// el acceso (colegios_panel.sesiones_desde). Topes: por IP (como los demás logins) y 20 intentos de PIN por
// hora por colegio.
import crypto from 'crypto';
import express from 'express';
import type { NextFunction, Request, Response } from 'express';
import type { SupabaseClient } from '@supabase/supabase-js';
import { calcularLiquidacionColegio, periodoLiquidacion } from '../convenioLiquidacion.js';
import { compararTimingSafe, getAdminSessionSecret, requireAdminAuth } from '../nucleo/auth.js';
import { getServerSupabase } from '../nucleo/clientes.js';
import { determinarCodigoCursoServidor } from '../nucleo/codigosCurso.js';
import { hayCupoPorClave, limitarFrecuenciaPersistente } from '../nucleo/limites.js';
import { normalizarNombreComparable, traerTodasLasFilas } from '../nucleo/utilidades.js';

const rutas = express.Router();

export const DURACION_SESION_COLEGIO_MS = 7 * 24 * 60 * 60 * 1000;
const MAX_FALLAS_PIN_POR_HORA = 20;
const CODIGO_PANEL = /^PC[0-9A-F]{20}$/;
const FECHA = /^\d{4}-\d{2}-\d{2}$/;

const urlSitio = () => (process.env.APP_URL || 'https://www.retratoescolar.com.ar').replace(/\/+$/, '');
export const linkPanelColegio = (codigo: string) => `${urlSitio()}/colegio?c=${encodeURIComponent(codigo)}`;

// ---------------------------------------------------------------------------------------------
// PIN y código del link
// ---------------------------------------------------------------------------------------------
export function generarPinColegio(): string {
  return String(crypto.randomInt(0, 1_000_000)).padStart(6, '0');
}

export function generarCodigoPanel(): string {
  return `PC${crypto.randomBytes(10).toString('hex').toUpperCase()}`;
}

/** "scrypt$<sal>$<hash>": nunca se guarda el PIN legible. */
export function hashPinColegio(pin: string): string {
  const sal = crypto.randomBytes(16);
  const hash = crypto.scryptSync(pin, sal, 32);
  return `scrypt$${sal.toString('hex')}$${hash.toString('hex')}`;
}

export function pinColegioValido(pin: string, guardado: string | null | undefined): boolean {
  if (!guardado || !/^\d{6}$/.test(pin)) return false;
  const [tipo, salHex, hashHex] = guardado.split('$');
  if (tipo !== 'scrypt' || !salHex || !hashHex) return false;
  try {
    const esperado = Buffer.from(hashHex, 'hex');
    const calculado = crypto.scryptSync(pin, Buffer.from(salHex, 'hex'), esperado.length);
    return esperado.length > 0 && crypto.timingSafeEqual(esperado, calculado);
  } catch {
    return false;
  }
}

// ---------------------------------------------------------------------------------------------
// Sesión del colegio: "colegio.<colegioId>.<emitido>.<azar>.<firma>"
// ---------------------------------------------------------------------------------------------
export function generarTokenColegio(colegioId: string, ahora: number = Date.now()): string | null {
  const secreto = getAdminSessionSecret();
  if (!secreto) return null;
  const payload = `${colegioId}.${ahora}.${crypto.randomBytes(12).toString('hex')}`;
  const firma = crypto.createHmac('sha256', secreto).update(`colegio:${payload}`).digest('hex');
  return `colegio.${payload}.${firma}`;
}

// Vista previa de Pablo (10/10: «a mí no me deja entrar hasta firmar el convenio, pero quiero ver cómo es
// el panel»): token aparte, firmado con otro prefijo (no se puede convertir en una sesión del colegio ni al
// revés), que dura 2 horas, no exige PIN, acceso prendido ni convenio, y NO puede marcar entregas.
// "colegiovista.<colegioId>.<emitido>.<azar>.<firma>"
export const DURACION_VISTA_PREVIA_MS = 2 * 60 * 60 * 1000;

export function generarTokenVistaPrevia(colegioId: string, ahora: number = Date.now()): string | null {
  const secreto = getAdminSessionSecret();
  if (!secreto) return null;
  const payload = `${colegioId}.${ahora}.${crypto.randomBytes(12).toString('hex')}`;
  const firma = crypto.createHmac('sha256', secreto).update(`colegio-vista:${payload}`).digest('hex');
  return `colegiovista.${payload}.${firma}`;
}

export function leerTokenVistaPrevia(token?: string): { colegioId: string; emitido: number } | null {
  const secreto = getAdminSessionSecret();
  if (!token || !secreto) return null;
  const partes = token.split('.');
  if (partes.length !== 5 || partes[0] !== 'colegiovista') return null;
  const [, colegioId, ts, azar, firma] = partes;
  const emitido = Number(ts);
  if (!Number.isFinite(emitido) || emitido > Date.now() + 60_000 || Date.now() - emitido > DURACION_VISTA_PREVIA_MS) return null;
  const esperada = crypto.createHmac('sha256', secreto).update(`colegio-vista:${colegioId}.${ts}.${azar}`).digest('hex');
  return compararTimingSafe(firma, esperada) ? { colegioId, emitido } : null;
}

export function leerTokenColegio(token?: string): { colegioId: string; emitido: number } | null {
  const secreto = getAdminSessionSecret();
  if (!token || !secreto) return null;
  const partes = token.split('.');
  if (partes.length !== 5 || partes[0] !== 'colegio') return null;
  const [, colegioId, ts, azar, firma] = partes;
  const emitido = Number(ts);
  if (!Number.isFinite(emitido) || emitido > Date.now() + 60_000 || Date.now() - emitido > DURACION_SESION_COLEGIO_MS) return null;
  const esperada = crypto.createHmac('sha256', secreto).update(`colegio:${colegioId}.${ts}.${azar}`).digest('hex');
  return compararTimingSafe(firma, esperada) ? { colegioId, emitido } : null;
}

// ---------------------------------------------------------------------------------------------
// Convenio: el panel se habilita recién cuando el colegio lo firma (Pablo, 10/10: «debo hacer que firmen
// el convenio antes de mostrarles esto»). Firmado = hay una fila en convenios_colegios.
// ---------------------------------------------------------------------------------------------
export const linkConvenioColegio = (codigoConvenio: string) => `${urlSitio()}/convenio.html?c=${encodeURIComponent(codigoConvenio)}`;

export async function estadoConvenio(supabase: SupabaseClient, colegioId: string): Promise<{ firmado: boolean; fecha: string | null; link: string | null }> {
  const [{ data: convenio, error }, { data: colegio }] = await Promise.all([
    supabase.from('convenios_colegios').select('created_at').eq('colegio_id', colegioId).order('created_at', { ascending: false }).limit(1).maybeSingle(),
    supabase.from('colegios').select('codigo_convenio').eq('id', colegioId).maybeSingle(),
  ]);
  if (error) throw error;
  return {
    firmado: Boolean(convenio),
    fecha: convenio?.created_at || null,
    link: colegio?.codigo_convenio ? linkConvenioColegio(String(colegio.codigo_convenio)) : null,
  };
}

export const ERROR_CONVENIO_SIN_FIRMAR = 'Para entrar al panel, el colegio primero tiene que firmar el convenio con Retrato Escolar.';

export async function requireColegioAuth(req: Request, res: Response, next: NextFunction) { // 26/10: también lo usa fotoHermanos.ts
  const autorizacion = req.headers.authorization;
  const token = autorizacion?.startsWith('Bearer ') ? autorizacion.substring(7) : undefined;
  const supabase = getServerSupabase();
  const vencida = () => res.status(401).json({ success: false, codigo: 'SESION_VENCIDA', error: 'La sesión venció. Volvé a entrar con el PIN.' });
  // Vista previa de Pablo: ve lo mismo que el colegio, sin PIN ni convenio (sólo lectura).
  const vista = leerTokenVistaPrevia(token);
  if (vista) {
    if (!supabase) return vencida();
    res.locals.colegioId = vista.colegioId;
    res.locals.vistaPrevia = true;
    return next();
  }
  const sesion = leerTokenColegio(token);
  if (!sesion || !supabase) return vencida();
  try {
    const [{ data: panel }, convenio] = await Promise.all([
      supabase.from('colegios_panel').select('colegio_id, activo, sesiones_desde').eq('colegio_id', sesion.colegioId).maybeSingle(),
      estadoConvenio(supabase, sesion.colegioId),
    ]);
    if (!panel || !panel.activo || sesion.emitido < Date.parse(String(panel.sesiones_desde))) return vencida();
    if (!convenio.firmado) return res.status(403).json({ success: false, codigo: 'CONVENIO_SIN_FIRMAR', error: ERROR_CONVENIO_SIN_FIRMAR, linkConvenio: convenio.link });
    res.locals.colegioId = sesion.colegioId;
    return next();
  } catch {
    return res.status(500).json({ success: false, error: 'No pudimos validar la sesión. Probá de nuevo en unos segundos.' });
  }
}

// ---------------------------------------------------------------------------------------------
// Cursos: orden y nombre
// ---------------------------------------------------------------------------------------------
const ORDEN_GRADOS = [
  'sala 3', 'sala 4', 'sala 5',
  '1° grado', '2° grado', '3° grado', '4° grado', '5° grado', '6° grado', '7° grado',
  '1° año', '2° año', '3° año', '4° año', '5° año', '6° año',
];
function posicionGrado(grado: string): number {
  const g = String(grado || '').toLowerCase();
  const i = ORDEN_GRADOS.findIndex((o) => g.startsWith(o));
  return i === -1 ? ORDEN_GRADOS.length : i;
}

export type CursoColegio = { clave: string; grado: string; division: string; turno: string; etiqueta: string };

export function etiquetaCurso(grado: string, division: string, turno: string): string {
  const partes = [String(grado || '').trim()];
  if (division) partes.push(`"${String(division).trim()}"`);
  if (turno) partes.push(`· ${String(turno).trim()}`);
  return partes.filter(Boolean).join(' ');
}

export function ordenarCursos<T extends { grado: string; division: string; turno: string }>(cursos: T[]): T[] {
  return [...cursos].sort(
    (a, b) =>
      posicionGrado(a.grado) - posicionGrado(b.grado) ||
      String(a.grado).localeCompare(String(b.grado)) ||
      String(a.turno).localeCompare(String(b.turno)) ||
      String(a.division).localeCompare(String(b.division))
  );
}

// ---------------------------------------------------------------------------------------------
// Comisión: la liquidación de Pablo, sin datos de las familias
// ---------------------------------------------------------------------------------------------
type Liquidacion = NonNullable<Awaited<ReturnType<typeof calcularLiquidacionColegio>>>;

/**
 * Lo que ve el colegio al entrar (pedido de Pablo, 10/10 17:20): SÓLO la comisión que se lleva. Nada de
 * lo cobrado, costos, ganancia ni detalle por pedido: tampoco viaja en la respuesta del resumen.
 */
export function liquidacionParaColegio(liquidacion: Liquidacion) {
  return {
    periodo: liquidacion.periodo,
    participacion: liquidacion.participacion,
  };
}

/**
 * El detalle del cálculo, sólo si el colegio lo pide (Pablo, 10/10 17:31: «que lo muestre solo si lo
 * solicita, con 3 puntitos en una esquina»). Totales y cada pedido por número y curso, sin nombres ni
 * datos de las familias: lo mismo que pide la cláusula OCTAVA BIS para la liquidación de cierre.
 */
export function detalleLiquidacionParaColegio(liquidacion: Liquidacion) {
  return {
    periodo: liquidacion.periodo,
    porcentaje: liquidacion.porcentaje,
    pedidos: liquidacion.totales.pedidos,
    venta: liquidacion.totales.venta,
    costoLaboratorio: liquidacion.totales.costoLaboratorio,
    comisionesCobro: liquidacion.totales.comision,
    impuestos: liquidacion.totales.impuestos,
    // Convenio 2026-10-30, OCTAVA BIS (iv): 0 si su convenio no lo prevé.
    gastosPlataforma: liquidacion.totales.gastosPlataforma ?? 0,
    gananciaNeta: liquidacion.totales.ganancia,
    participacion: liquidacion.participacion,
    pedidosConFotosPendientes: liquidacion.pedidosConFotosPendientes,
    detalle: (liquidacion.filas as any[]).map((f) => ({
      pedido: f.pedido,
      curso: f.curso,
      pagado: f.pagado,
      venta: f.venta,
      gananciaNeta: f.ganancia,
    })),
  };
}

// ---------------------------------------------------------------------------------------------
// Avance por curso (sólo números)
// ---------------------------------------------------------------------------------------------
export type AvanceCurso = CursoColegio & { nomina: number; inscriptos: number; compraron: number; impresos: number };

export async function avancePorCurso(supabase: SupabaseClient, colegioId: string): Promise<AvanceCurso[]> {
  const cursos = new Map<string, AvanceCurso>();
  const curso = (grado: string, turno: string, division: string, clave?: string) => {
    const k = clave || determinarCodigoCursoServidor(grado, turno, division);
    let c = cursos.get(k);
    if (!c) {
      c = { clave: k, grado: grado || '', division: division || '', turno: turno || '', etiqueta: etiquetaCurso(grado, division, turno), nomina: 0, inscriptos: 0, compraron: 0, impresos: 0 };
      cursos.set(k, c);
    }
    return c;
  };

  const [secciones, nomina, inscripciones, pedidos] = await Promise.all([
    traerTodasLasFilas<any>((d, h) => supabase.from('codigos_seccion').select('grado, turno, division').eq('colegio_id', colegioId).order('id').range(d, h)),
    traerTodasLasFilas<any>((d, h) => supabase.from('alumnos').select('grado, turno, division').eq('colegio_id', colegioId).order('id').range(d, h)),
    traerTodasLasFilas<any>((d, h) =>
      supabase.from('inscripciones').select('alumno_nombre, alumno_apellido, grado, turno, division, hermanos').eq('colegio_id', colegioId).eq('estado', 'aceptado').order('id').range(d, h)
    ),
    traerTodasLasFilas<any>((d, h) =>
      supabase.from('pedidos').select('curso_codigo, grado, turno, division, alumno_nombre, tipo_kit').eq('colegio_id', colegioId).in('estado', ['pagado', 'entregado']).order('id').range(d, h)
    ),
  ]);

  for (const s of secciones) curso(s.grado, s.turno, s.division);
  for (const a of nomina) curso(a.grado, a.turno, a.division).nomina++;

  // Inscriptos: cada chico una vez (el de la inscripción y sus hermanos del mismo colegio).
  const inscriptos = new Set<string>();
  const anotarInscripto = (grado: string, turno: string, division: string, nombre: string) => {
    const c = curso(grado, turno, division);
    const clave = `${c.clave}|${normalizarNombreComparable(nombre)}`;
    if (inscriptos.has(clave)) return;
    inscriptos.add(clave);
    c.inscriptos++;
  };
  for (const i of inscripciones) {
    anotarInscripto(i.grado, i.turno, i.division, `${i.alumno_nombre || ''} ${i.alumno_apellido || ''}`);
    for (const h of Array.isArray(i.hermanos) ? i.hermanos : []) {
      if (h && String(h.colegioId || '') === String(colegioId)) anotarInscripto(h.grado, h.turno, h.division, `${h.alumnoNombre || ''} ${h.alumnoApellido || ''}`);
    }
  }

  // Compras: cada chico una vez por curso (un kit pagado alcanza; "impresos" si alguno es impreso).
  const compraron = new Set<string>();
  const impresos = new Set<string>();
  for (const p of pedidos) {
    const c = curso(p.grado, p.turno, p.division, p.curso_codigo || undefined);
    const clave = `${c.clave}|${normalizarNombreComparable(p.alumno_nombre)}`;
    if (!compraron.has(clave)) {
      compraron.add(clave);
      c.compraron++;
    }
    if (p.tipo_kit === 'impreso_digital' && !impresos.has(clave)) {
      impresos.add(clave);
      c.impresos++;
    }
  }
  return ordenarCursos([...cursos.values()]);
}

// ---------------------------------------------------------------------------------------------
// Entregas de los kits impresos
// ---------------------------------------------------------------------------------------------
export type EstadoEntregaColegio = 'falta_elegir_fotos' | 'en_espera' | 'pagado' | 'en_laboratorio' | 'listo' | 'entregado';

export function estadoEntregaParaColegio(p: { seleccion_pendiente?: boolean | null; en_espera?: boolean | null; estado_lab?: string | null }): EstadoEntregaColegio {
  if (p.estado_lab === 'entregado') return 'entregado';
  if (p.estado_lab === 'listo_retiro') return 'listo';
  if (p.seleccion_pendiente) return 'falta_elegir_fotos';
  if (p.en_espera) return 'en_espera';
  if (p.estado_lab === 'en_produccion') return 'en_laboratorio';
  return 'pagado';
}

// Sólo lo necesario para repartir los sobres: nada de contacto, montos ni links.
// 29/10/2026: las fotos extra (copias impresas aparte del kit) también se entregan en el colegio.
const TIPOS_CON_ENTREGA = ['impreso_digital', 'fotos_extra'];
const COLUMNAS_ENTREGA =
  'pedido_friendly_id, alumno_nombre, alumno_numero_lista, codigo_alumno, grado, division, turno, curso_codigo, kit_nombre, carpetas_impresas, seleccion_pendiente, en_espera, estado_lab, fecha_entregado, entregado_por';

export function filaEntregaParaColegio(f: any) {
  return {
    pedido: String(f.pedido_friendly_id || ''),
    alumno: String(f.alumno_nombre || ''),
    numeroLista: Number(f.alumno_numero_lista) || null,
    codigoSobre: String(f.codigo_alumno || ''),
    curso: f.curso_codigo || determinarCodigoCursoServidor(f.grado, f.turno, f.division),
    cursoEtiqueta: etiquetaCurso(f.grado, f.division, f.turno),
    grado: String(f.grado || ''),
    division: String(f.division || ''),
    turno: String(f.turno || ''),
    kit: String(f.kit_nombre || 'Kit impreso'),
    carpetas: Number(f.carpetas_impresas) || 0,
    estado: estadoEntregaParaColegio(f),
    entregadoAt: f.fecha_entregado || null,
    entregadoPor: f.entregado_por === 'colegio' ? 'colegio' : f.estado_lab === 'entregado' ? 'fotografo' : null,
  };
}

// ---------------------------------------------------------------------------------------------
// Rutas del colegio
// ---------------------------------------------------------------------------------------------
rutas.post('/api/colegio/login', limitarFrecuenciaPersistente('colegio-login', 10, 15 * 60 * 1000), async (req: Request, res: Response) => {
  try {
    const codigo = String(req.body?.codigo || '').trim().toUpperCase();
    const pin = String(req.body?.pin ?? '').replace(/\D/g, '');
    if (!CODIGO_PANEL.test(codigo)) return res.status(404).json({ success: false, error: 'El link no es válido. Pedile el link del panel al fotógrafo.' });
    if (!/^\d{6}$/.test(pin)) return res.status(400).json({ success: false, error: 'Ingresá el PIN de 6 números.' });
    const supabase = getServerSupabase();
    if (!supabase) return res.status(503).json({ success: false, error: 'Servicio no disponible. Probá de nuevo en unos minutos.' });
    const claveFallas = `colegio-login-fallas:${codigo}`;
    // Auditoría 11/10 (NUC-2): se cuenta el intento ANTES de verificar (atómico); antes se leía el tope y se
    // sumaba después del PIN equivocado, y muchos pedidos simultáneos pasaban todos el chequeo.
    if (!(await hayCupoPorClave(claveFallas, MAX_FALLAS_PIN_POR_HORA, 60 * 60))) {
      return res.status(429).json({ success: false, error: 'Demasiados intentos con un PIN equivocado. Probá de nuevo en una hora o pedile un PIN nuevo al fotógrafo.' });
    }
    const { data: panel, error } = await supabase.from('colegios_panel').select('colegio_id, pin_hash, activo').eq('codigo', codigo).maybeSingle();
    if (error) throw error;
    if (!panel) return res.status(404).json({ success: false, error: 'El link no es válido. Pedile el link del panel al fotógrafo.' });
    if (!panel.activo || !panel.pin_hash) return res.status(403).json({ success: false, error: 'El acceso de este colegio está desactivado. Consultá con el fotógrafo.' });
    if (!pinColegioValido(pin, panel.pin_hash)) {
      return res.status(401).json({ success: false, error: 'PIN incorrecto.' });
    }
    // Con el PIN correcto pero sin convenio firmado no entra: se le muestra el link para firmarlo.
    const convenio = await estadoConvenio(supabase, String(panel.colegio_id));
    if (!convenio.firmado) return res.status(403).json({ success: false, codigo: 'CONVENIO_SIN_FIRMAR', error: ERROR_CONVENIO_SIN_FIRMAR, linkConvenio: convenio.link });
    const { data: colegio } = await supabase.from('colegios').select('id, nombre').eq('id', panel.colegio_id).maybeSingle();
    const token = generarTokenColegio(String(panel.colegio_id));
    if (!colegio || !token) return res.status(500).json({ success: false, error: 'No se pudo iniciar la sesión.' });
    return res.json({ success: true, token, colegio: { nombre: colegio.nombre }, expiraEn: DURACION_SESION_COLEGIO_MS / 1000 });
  } catch (err: any) {
    console.error('[Panel colegio] Error en el ingreso:', err);
    return res.status(500).json({ success: false, error: 'No se pudo iniciar la sesión. Probá de nuevo en unos segundos.' });
  }
});

rutas.get('/api/colegio/resumen', requireColegioAuth, async (_req: Request, res: Response) => {
  try {
    const supabase = getServerSupabase();
    if (!supabase) return res.status(503).json({ success: false, error: 'Servicio no disponible.' });
    const colegioId = String(res.locals.colegioId);
    const [{ data: colegio }, { data: panel }, { data: convenio }] = await Promise.all([
      supabase.from('colegios').select('id, nombre, evento_actual, porcentaje_participacion').eq('id', colegioId).maybeSingle(),
      supabase.from('colegios_panel').select('fecha_toma_fotos, fecha_cierre_pedidos, fecha_entrega_kits').eq('colegio_id', colegioId).maybeSingle(),
      supabase.from('convenios_colegios').select('created_at, porcentaje_participacion').eq('colegio_id', colegioId).order('created_at', { ascending: false }).limit(1).maybeSingle(),
    ]);
    if (!colegio) return res.status(404).json({ success: false, error: 'Colegio no encontrado.' });
    const periodo = periodoLiquidacion(undefined, undefined); // temporada en curso: 1/1 a 31/12
    const liquidacion = periodo ? await calcularLiquidacionColegio(supabase, colegioId, periodo) : null;
    const cursos = await avancePorCurso(supabase, colegioId);
    res.setHeader('Cache-Control', 'private, no-store');
    return res.json({
      success: true,
      colegio: { nombre: colegio.nombre, eventoActual: colegio.evento_actual || '' },
      fechas: {
        tomaFotos: panel?.fecha_toma_fotos || null,
        cierrePedidos: panel?.fecha_cierre_pedidos || null,
        entregaKits: panel?.fecha_entrega_kits || null,
      },
      convenio: {
        firmado: Boolean(convenio),
        fecha: convenio?.created_at || null,
        porcentaje: Number(convenio?.porcentaje_participacion ?? colegio.porcentaje_participacion ?? 30),
      },
      comision: liquidacion ? liquidacionParaColegio(liquidacion) : null,
      cursos,
      difusion: { urlSitio: urlSitio(), urlInscripcion: `${urlSitio()}/?inscribirme=1` },
    });
  } catch (err: any) {
    console.error('[Panel colegio] Error en el resumen:', err);
    return res.status(500).json({ success: false, error: 'No pudimos cargar los datos. Probá de nuevo en unos segundos.' });
  }
});

// Detalle del cálculo de la comisión: sólo cuando el colegio lo pide (menú «⋯» de la tarjeta).
rutas.get('/api/colegio/comision/detalle', requireColegioAuth, async (_req: Request, res: Response) => {
  try {
    const supabase = getServerSupabase();
    if (!supabase) return res.status(503).json({ success: false, error: 'Servicio no disponible.' });
    const periodo = periodoLiquidacion(undefined, undefined); // temporada en curso: 1/1 a 31/12
    const liquidacion = periodo ? await calcularLiquidacionColegio(supabase, String(res.locals.colegioId), periodo) : null;
    res.setHeader('Cache-Control', 'private, no-store');
    return res.json({ success: true, comision: liquidacion ? detalleLiquidacionParaColegio(liquidacion) : null });
  } catch (err: any) {
    console.error('[Panel colegio] Error en el detalle de la comisión:', err);
    return res.status(500).json({ success: false, error: 'No pudimos cargar el detalle. Probá de nuevo en unos segundos.' });
  }
});

rutas.get('/api/colegio/entregas', requireColegioAuth, async (_req: Request, res: Response) => {
  try {
    const supabase = getServerSupabase();
    if (!supabase) return res.status(503).json({ success: false, error: 'Servicio no disponible.' });
    const colegioId = String(res.locals.colegioId);
    const filas = await traerTodasLasFilas<any>((d, h) =>
      supabase
        .from('pedidos')
        .select(COLUMNAS_ENTREGA)
        .eq('colegio_id', colegioId)
        .in('estado', ['pagado', 'entregado'])
        .in('tipo_kit', TIPOS_CON_ENTREGA)
        .eq('archivado', false)
        .order('curso_codigo')
        .order('alumno_numero_lista')
        .order('id')
        .range(d, h)
    );
    res.setHeader('Cache-Control', 'private, no-store');
    return res.json({ success: true, entregas: filas.map(filaEntregaParaColegio) });
  } catch (err: any) {
    console.error('[Panel colegio] Error en las entregas:', err);
    return res.status(500).json({ success: false, error: 'No pudimos cargar las entregas. Probá de nuevo en unos segundos.' });
  }
});

// Marcar un kit como entregado: sólo de este colegio, pagado y «listo para entregar» (las mismas reglas
// que «Marcar retirado» en el panel de Pablo: no se saltean etapas). Se identifica por el número de pedido
// (IFS-…), así el colegio nunca ve los ids internos.
rutas.post('/api/colegio/entregas/:pedido/entregado', requireColegioAuth, async (req: Request, res: Response) => {
  if (res.locals.vistaPrevia) {
    return res.status(403).json({ success: false, codigo: 'VISTA_PREVIA', error: 'Es la vista previa: desde acá no se marcan entregas (sólo el colegio, desde su panel).' });
  }
  try {
    const supabase = getServerSupabase();
    if (!supabase) return res.status(503).json({ success: false, error: 'Servicio no disponible.' });
    const colegioId = String(res.locals.colegioId);
    const numero = String(req.params.pedido || '').trim().slice(0, 40);
    const ahora = new Date().toISOString();
    const { data: marcados, error } = await supabase
      .from('pedidos')
      .update({ estado_lab: 'entregado', entregado_por: 'colegio', updated_at: ahora })
      .eq('pedido_friendly_id', numero)
      .eq('colegio_id', colegioId)
      .in('estado', ['pagado', 'entregado'])
      .in('tipo_kit', TIPOS_CON_ENTREGA)
      .eq('archivado', false) // auditoría 11/10 (NUC-5): igual que la lista de entregas
      .eq('estado_lab', 'listo_retiro')
      .select('pedido_friendly_id');
    if (error) throw error;
    if (!marcados || marcados.length === 0) {
      const { data: actual } = await supabase.from('pedidos').select('estado_lab').eq('pedido_friendly_id', numero).eq('colegio_id', colegioId).eq('archivado', false).maybeSingle();
      if (!actual) return res.status(404).json({ success: false, error: 'No encontramos ese pedido en este colegio.' });
      if (actual.estado_lab === 'entregado') return res.json({ success: true, yaEstaba: true });
      return res.status(409).json({ success: false, error: 'Ese kit todavía no está listo para entregar. Recargá la lista.' });
    }
    // La fecha de entrega se graba una sola vez (igual que en el panel de Pablo).
    await supabase.from('pedidos').update({ fecha_entregado: ahora }).eq('pedido_friendly_id', numero).eq('colegio_id', colegioId).is('fecha_entregado', null);
    return res.json({ success: true, entregadoAt: ahora });
  } catch (err: any) {
    console.error('[Panel colegio] Error al marcar entregado:', err);
    return res.status(500).json({ success: false, error: 'No se pudo marcar como entregado. Probá de nuevo.' });
  }
});

// ---------------------------------------------------------------------------------------------
// Rutas de Pablo (panel → Colegios → Panel del colegio)
// ---------------------------------------------------------------------------------------------
async function filaPanel(supabase: SupabaseClient, colegioId: string) {
  const { data } = await supabase.from('colegios_panel').select('*').eq('colegio_id', colegioId).maybeSingle();
  return data as any;
}

function vistaPanelAdmin(panel: any, convenio: { firmado: boolean; fecha: string | null; link: string | null }) {
  return {
    convenio,
    activo: Boolean(panel?.activo),
    link: panel?.codigo ? linkPanelColegio(panel.codigo) : null,
    tienePin: Boolean(panel?.pin_hash),
    pinActualizadoAt: panel?.pin_actualizado_at || null,
    fechas: {
      tomaFotos: panel?.fecha_toma_fotos || null,
      cierrePedidos: panel?.fecha_cierre_pedidos || null,
      entregaKits: panel?.fecha_entrega_kits || null,
    },
  };
}

async function colegioExiste(supabase: SupabaseClient, colegioId: string): Promise<boolean> {
  if (!/^[0-9a-f-]{36}$/i.test(colegioId)) return false;
  const { data } = await supabase.from('colegios').select('id').eq('id', colegioId).maybeSingle();
  return Boolean(data);
}

rutas.get('/api/admin/colegios/:id/panel', requireAdminAuth, async (req: Request, res: Response) => {
  try {
    const supabase = getServerSupabase();
    if (!supabase) return res.status(500).json({ success: false, error: 'Supabase no configurado' });
    const colegioId = String(req.params.id);
    if (!(await colegioExiste(supabase, colegioId))) return res.status(404).json({ success: false, error: 'Colegio no encontrado.' });
    const [panel, convenio] = await Promise.all([filaPanel(supabase, colegioId), estadoConvenio(supabase, colegioId)]);
    return res.json({ success: true, panel: vistaPanelAdmin(panel, convenio) });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err?.message || 'Error al leer el panel del colegio' });
  }
});

// PIN nuevo (también el primero): activa el acceso y cierra las sesiones abiertas. El PIN se devuelve UNA
// sola vez (sólo se guarda cifrado).
rutas.post('/api/admin/colegios/:id/panel/pin', requireAdminAuth, async (req: Request, res: Response) => {
  try {
    const supabase = getServerSupabase();
    if (!supabase) return res.status(500).json({ success: false, error: 'Supabase no configurado' });
    const colegioId = String(req.params.id);
    if (!(await colegioExiste(supabase, colegioId))) return res.status(404).json({ success: false, error: 'Colegio no encontrado.' });
    const actual = await filaPanel(supabase, colegioId);
    const pin = generarPinColegio();
    const ahora = new Date().toISOString();
    const cambios = { pin_hash: hashPinColegio(pin), pin_actualizado_at: ahora, activo: true, sesiones_desde: ahora, updated_at: ahora };
    const { data, error } = actual
      ? await supabase.from('colegios_panel').update(cambios).eq('colegio_id', colegioId).select('*').single()
      : await supabase.from('colegios_panel').insert({ colegio_id: colegioId, codigo: generarCodigoPanel(), ...cambios }).select('*').single();
    if (error) throw error;
    return res.json({ success: true, pin, panel: vistaPanelAdmin(data, await estadoConvenio(supabase, colegioId)) });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err?.message || 'Error al generar el PIN' });
  }
});

// Vista previa: Pablo ve el panel tal como lo ve el colegio (aunque no haya firmado el convenio ni tenga
// PIN). Devuelve un token de sólo lectura que dura 2 horas.
rutas.post('/api/admin/colegios/:id/panel/vista-previa', requireAdminAuth, async (req: Request, res: Response) => {
  try {
    const supabase = getServerSupabase();
    if (!supabase) return res.status(500).json({ success: false, error: 'Supabase no configurado' });
    const colegioId = String(req.params.id);
    if (!(await colegioExiste(supabase, colegioId))) return res.status(404).json({ success: false, error: 'Colegio no encontrado.' });
    const { data: colegio } = await supabase.from('colegios').select('nombre').eq('id', colegioId).maybeSingle();
    const token = generarTokenVistaPrevia(colegioId);
    if (!token) return res.status(500).json({ success: false, error: 'No se pudo abrir la vista previa.' });
    return res.json({ success: true, token, colegio: { nombre: colegio?.nombre || '' }, expiraEn: DURACION_VISTA_PREVIA_MS / 1000 });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err?.message || 'Error al abrir la vista previa' });
  }
});

// Prender/apagar el acceso y cargar las fechas de la campaña. Apagarlo cierra las sesiones abiertas.
rutas.post('/api/admin/colegios/:id/panel', requireAdminAuth, async (req: Request, res: Response) => {
  try {
    const supabase = getServerSupabase();
    if (!supabase) return res.status(500).json({ success: false, error: 'Supabase no configurado' });
    const colegioId = String(req.params.id);
    if (!(await colegioExiste(supabase, colegioId))) return res.status(404).json({ success: false, error: 'Colegio no encontrado.' });
    const { activo, fechas } = req.body || {};
    const ahora = new Date().toISOString();
    const cambios: Record<string, any> = { updated_at: ahora };
    if (typeof activo === 'boolean') {
      cambios.activo = activo;
      if (!activo) cambios.sesiones_desde = ahora;
    }
    if (fechas && typeof fechas === 'object') {
      const fecha = (v: unknown) => (v === null || v === '' ? null : FECHA.test(String(v)) ? String(v) : undefined);
      const campos: Record<string, string> = { tomaFotos: 'fecha_toma_fotos', cierrePedidos: 'fecha_cierre_pedidos', entregaKits: 'fecha_entrega_kits' };
      for (const [clave, columna] of Object.entries(campos)) {
        if (!(clave in fechas)) continue;
        const valor = fecha((fechas as any)[clave]);
        if (valor === undefined) return res.status(400).json({ success: false, error: 'Fecha inválida (formato AAAA-MM-DD).' });
        cambios[columna] = valor;
      }
    }
    const actual = await filaPanel(supabase, colegioId);
    if (!actual && cambios.activo === true) {
      return res.status(409).json({ success: false, error: 'Primero generá el PIN del colegio.' });
    }
    const { data, error } = actual
      ? await supabase.from('colegios_panel').update(cambios).eq('colegio_id', colegioId).select('*').single()
      : await supabase.from('colegios_panel').insert({ colegio_id: colegioId, codigo: generarCodigoPanel(), activo: false, ...cambios }).select('*').single();
    if (error) throw error;
    return res.json({ success: true, panel: vistaPanelAdmin(data, await estadoConvenio(supabase, colegioId)) });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err?.message || 'Error al guardar el panel del colegio' });
  }
});

export { rutas as rutasPanelColegio };
