// Comisiones reales de cobro de Mercado Pago y Nave, guardadas en cada pedido para la liquidación al
// colegio (división de server.ts, etapa 2, 10/10/2026). El código es el mismo que estaba en la
// sección "COMISIONES REALES DE COBRO" de server.ts: sólo se movió de lugar. server.ts usa
// registrarComisionDePago (al confirmarse un pago) y leerMontoNave (conciliación de Nave).
import type { SupabaseClient } from '@supabase/supabase-js';
import { Payment } from 'mercadopago';
import { getMercadoPagoConfig, getNaveUrls, naveHabilitado, obtenerNaveAccessToken } from './nucleo/clientes.js';

// ==============================================================================
// COMISIONES REALES DE COBRO (2/10, convenio OCTAVA BIS a.ii)
// Al confirmarse un pago de Mercado Pago o Nave se guarda en cada pedido lo que la pasarela
// retuvo DE VERDAD (comisión y retenciones), prorrateado por el total de cada pedido cuando el
// pago cubrió un carrito de varios hijos. La liquidación usa ese dato; si no está (pasarela que
// no lo informa o pago anterior), estima con el % configurado y lo marca como estimado.
// Mercado Pago: fee_details (sólo lo que paga el vendedor, fee_payer = collector) y
// transaction_details.net_received_amount; lo que falta para llegar al neto son retenciones
// (p. ej. Ingresos Brutos). Nave: su documentación pública no detalla estos campos, así que se
// prueban los nombres habituales y, si no aparece ninguno, se registra 'sin_dato'.
// ==============================================================================
type DetalleCobro = { comision: number; retenciones: number; neto: number | null; fecha: string | null; monto?: number | null };

function primerNumero(valores: unknown[]): number | null {
  for (const v of valores) {
    const n = typeof v === 'string' || typeof v === 'number' ? Number(v) : NaN;
    if (Number.isFinite(n) && n >= 0) return n;
  }
  return null;
}

async function detalleCobroMercadoPago(paymentId: string): Promise<DetalleCobro | null> {
  const mpConfig = getMercadoPagoConfig();
  if (!mpConfig) throw new Error('Mercado Pago no configurado');
  const info: any = await new Payment(mpConfig).get({ id: paymentId, requestOptions: { timeout: 8000, maxRetries: 0 } });
  const monto = Number(info?.transaction_amount);
  if (!Number.isFinite(monto) || monto <= 0) return null;
  const cargos = Array.isArray(info?.fee_details) ? info.fee_details : [];
  const comisionCargos = cargos
    .filter((c: any) => String(c?.fee_payer || 'collector') === 'collector')
    .reduce((a: number, c: any) => a + (Number(c?.amount) || 0), 0);
  const neto = Number(info?.transaction_details?.net_received_amount);
  const hayNeto = Number.isFinite(neto) && neto > 0;
  if (cargos.length === 0 && !hayNeto) return null;
  const comision = cargos.length > 0 ? comisionCargos : Math.max(0, monto - neto);
  const retenciones = hayNeto ? Math.max(0, monto - neto - comision) : 0;
  return { comision, retenciones, neto: hayNeto ? neto : null, fecha: info?.date_approved ? String(info.date_approved) : null, monto };
}

async function detalleCobroNave(paymentId: string): Promise<DetalleCobro | null> {
  if (!naveHabilitado()) throw new Error('Nave no habilitado');
  const token = await obtenerNaveAccessToken();
  if (!token) throw new Error('Sin token de Nave');
  const { pagos } = getNaveUrls();
  const resp = await fetch(`${pagos}/${encodeURIComponent(paymentId)}`, { headers: { Authorization: `Bearer ${token}` }, signal: AbortSignal.timeout(8000) });
  const pago: any = await resp.json().catch(() => null);
  if (!resp.ok || !pago) throw new Error(`Nave respondió ${resp.status}`);
  const monto = leerMontoNave(pago);
  const t = pago?.transactions?.[0] || pago?.transaction || {};
  const comisionInformada = primerNumero([
    pago?.fee?.value, pago?.fee?.amount, pago?.fee, pago?.fee_amount?.value, pago?.fee_amount,
    pago?.commission?.value, pago?.commission?.amount, pago?.commission, pago?.commission_amount?.value, pago?.commission_amount,
    t?.fee?.value, t?.fee_amount?.value, t?.commission?.value, t?.commission_amount?.value,
    pago?.settlement?.fee?.value, pago?.settlement?.fee_amount?.value, pago?.settlement?.commission?.value,
  ]);
  const neto = primerNumero([
    pago?.net_amount?.value, pago?.net_amount, pago?.net_received_amount, t?.net_amount?.value,
    pago?.settlement?.net_amount?.value, pago?.settlement?.net_amount, pago?.settlement?.amount?.value,
  ]);
  if (comisionInformada === null && (neto === null || !Number.isFinite(monto))) {
    // Sólo los NOMBRES de los campos (sin valores ni datos de la tarjeta), para ajustar la lectura.
    console.warn('[Nave] El pago no informa comisión ni neto. Campos recibidos:', Object.keys(pago || {}).join(', '));
    return null;
  }
  const comision = comisionInformada ?? Math.max(0, monto - (neto as number));
  const retenciones = neto !== null && Number.isFinite(monto) ? Math.max(0, monto - neto - comision) : 0;
  const fecha = pago?.approved_at || pago?.approval_date || pago?.status?.date || null;
  return { comision, retenciones, neto, fecha: fecha ? String(fecha) : null, monto: Number.isFinite(monto) ? monto : null };
}

/** Guarda la comisión real de un pago en sus pedidos (prorrateada). Nunca tira error. */
export async function registrarComisionDePago(supabase: SupabaseClient, columna: 'mp_payment_id' | 'nave_payment_id', idPago: string): Promise<'real' | 'sin_dato' | 'error'> {
  try {
    const { data: pedidos } = await supabase.from('pedidos').select('id, total').eq(columna, idPago).order('created_at');
    if (!pedidos || pedidos.length === 0) return 'error';
    const ahora = new Date().toISOString();
    let detalle: DetalleCobro | null = null;
    try {
      detalle = columna === 'mp_payment_id' ? await detalleCobroMercadoPago(idPago) : await detalleCobroNave(idPago);
    } catch (err) {
      console.error(`[Comisiones] No se pudo consultar el pago ${idPago}:`, err);
      await supabase.from('pedidos').update({ comision_origen: 'error', comision_actualizada_at: ahora }).eq(columna, idPago);
      return 'error';
    }
    if (!detalle) {
      const { error } = await supabase.from('pedidos').update({ comision_origen: 'sin_dato', comision_actualizada_at: ahora }).eq(columna, idPago);
      if (error) {
        console.error(`[Comisiones] No se pudo guardar el pago ${idPago}:`, error);
        return 'error';
      }
      return 'sin_dato';
    }
    const totalPago = pedidos.reduce((a: number, p: any) => a + (Number(p.total) || 0), 0);
    const centavos = (n: number) => Math.round(n * 100);
    const repartir = (monto: number) => {
      // Reparto en centavos: el último pedido se lleva el redondeo, así la suma da exacto.
      const totalC = centavos(monto);
      let asignado = 0;
      return pedidos.map((p: any, i: number) => {
        if (i === pedidos.length - 1) return (totalC - asignado) / 100;
        const parte = totalPago > 0 ? Math.round((totalC * (Number(p.total) || 0)) / totalPago) : Math.round(totalC / pedidos.length);
        asignado += parte;
        return parte / 100;
      });
    };
    // Auditoría 03/10 noche (P8): si se cobró MÁS de lo que valen los pedidos (link de un carrito
    // pagado después de cancelar a un hermano; la diferencia se devuelve), a estos pedidos les toca
    // sólo la parte proporcional de la comisión, no la del pago entero.
    const factor = detalle.monto && totalPago > 0 && detalle.monto > totalPago + 1 ? totalPago / detalle.monto : 1;
    const comisiones = repartir(detalle.comision * factor);
    const retenciones = repartir(detalle.retenciones * factor);
    const netos = detalle.neto !== null ? repartir(detalle.neto * factor) : null;
    const fechaValida = detalle.fecha && !Number.isNaN(Date.parse(detalle.fecha)) ? new Date(detalle.fecha).toISOString() : null;
    for (let i = 0; i < pedidos.length; i++) {
      const { error } = await supabase
        .from('pedidos')
        .update({
          comision_cobro: comisiones[i],
          retenciones_cobro: retenciones[i],
          neto_cobro: netos ? netos[i] : null,
          comision_origen: 'real',
          comision_actualizada_at: ahora,
          ...(fechaValida ? { pagado_at: fechaValida } : {}),
        })
        .eq('id', pedidos[i].id);
      if (error) {
        console.error(`[Comisiones] No se pudo guardar la comisión del pedido ${pedidos[i].id}:`, error);
        return 'error';
      }
    }
    return 'real';
  } catch (err) {
    console.error(`[Comisiones] Error al registrar la comisión del pago ${idPago}:`, err);
    return 'error';
  }
}

// Lee el monto de un objeto de Nave (pago o intención). La forma exacta de la respuesta no está
// garantizada en la documentación relevada, así que se prueban las variantes conocidas; si
// ninguna da un número, devuelve NaN (y montoCubrePedidos NO da el pago por bueno).
export function leerMontoNave(obj: any): number {
  const candidatos = [
    obj?.transactions?.[0]?.amount?.value,
    obj?.transaction?.amount?.value,
    obj?.amount?.value,
    obj?.amount,
    obj?.total_amount?.value,
    obj?.payment_request?.transactions?.[0]?.amount?.value,
  ];
  for (const c of candidatos) {
    const n = typeof c === 'string' || typeof c === 'number' ? Number(c) : NaN;
    if (Number.isFinite(n) && n > 0) return n;
  }
  return NaN;
}
