// Tareas programadas (crons de pg_cron y Vercel): diagnóstico de Nave, conciliar pagos, recordar pagos
// pendientes y cancelar transferencias vencidas, limpiar huérfanos y reintentar los .zip HD (división
// de server.ts, etapa 6, 10/10/2026). El código es el mismo que estaba en la sección 5 de server.ts:
// sólo se movió. En server.ts estas rutas estaban en dos tramos (con /api/descargas en el medio): por
// eso hay dos routers, montados donde estaba cada uno.
import type { SupabaseClient } from '@supabase/supabase-js';
import crypto from 'crypto';
import express from 'express';
import type { Request, Response } from 'express';
import { Resend } from 'resend';
import { enviarCorreoFotosHD, registrarEnvioCorreoHD } from './entrega/correos.js';
import { refirmarLinkDescargaHDSiExiste } from './entrega/descargas.js';
import { procesarUnPedidoRecienPagado } from './entrega/pedidosPagados.js';
import { generarYSubirZipHDParaPedido } from './entrega/zipHD.js';
import { autorizarTareaProgramada } from './nucleo/auth.js';
import { esPedidoAdicional } from './nucleo/fotosExtra.js';
import { casillaAvisosAdmin, fetchNave, getNaveCredenciales, getNaveEntorno, getResendClient, getServerSupabase, NAVE_AUTH_AUDIENCE, resendReplyTo } from './nucleo/clientes.js';
import { tocaTurnoDistribuido } from './nucleo/limites.js';
import { escapeHtml } from './nucleo/utilidades.js';
import { fechaHoraArgentina, PLAZO_TRANSFERENCIA_HORAS, venceTransferenciaDe } from './pagos/comprobantes.js';
import { htmlRecordatorioPago, urlPedidoPendiente } from './pagos/avisoPedidoPendiente.js';
import { alumnosConKitPagado } from './pagos/cobros.js';
import { conciliarPagoPendiente } from './pagos/conciliacion.js';
import { limpiarArchivosHuerfanos } from './panel/fotos.js';

// Un router por cada tramo de server.ts donde estaban estas rutas (así el orden de Express no cambia).
const rutas = express.Router();
const rutasHD = express.Router();

/**
 * Auditoría 2026-09-20 (revisión completa de estados, pedido de Pablo: "avancemos con el cron").
 * Hasta ahora, si el .zip HD fallaba al momento del pago, la ÚNICA forma de que la familia
 * recibiera su link real era que Pablo abriera el panel de Laboratorio, notara la alerta y
 * apretara "Reintentar" a mano. Esta función es el reintento automático: busca pedidos pagados
 * sin link real hace más de `graciaMinutos` (para no pisarle los talones al intento que ya hace
 * el webhook de pago en el momento) y repite el mismo proceso que ese webhook — generar el .zip,
 * mandar el correo, grabar el resultado. La llama tanto el endpoint de cron de más abajo como
 * cualquier otro lugar que en el futuro quiera un reintento en lote sin pasar por HTTP.
 */
async function reintentarPedidosConHDPendiente(
  supabase: SupabaseClient,
  opciones: { limite?: number; graciaMinutos?: number } = {}
): Promise<{ revisados: number; resueltos: number; fallidos: number; reenviados?: number; omitidos?: number }> {
  // Auditoría 03/10 (crítico 4 + alto 17): antes 20 por corrida (con ~1.300 familias, un corte de
  // Resend dejaba HD perdidos durante horas) y se volvía a armar el .zip aunque el link ya existiera.
  // Ahora: hasta 100 por corrida dentro de un presupuesto de 45 s; si el pedido ya tiene .zip sólo se
  // reenvía el correo; cada pedido toma su turno (dos crons a la vez no arman el mismo .zip ni
  // mandan el mismo correo) y el correo lleva clave de idempotencia de Resend.
  const limite = opciones.limite ?? 100;
  const graciaMinutos = opciones.graciaMinutos ?? 10;
  const cortaMs = Date.now() - graciaMinutos * 60 * 1000;
  const hace14Dias = new Date(Date.now() - 14 * 24 * 60 * 60 * 1000).toISOString();

  // Auditoría 2026-09-23 (bug real): antes se pedían sólo `limite` filas, sin orden. Los pedidos
  // que nunca se pueden resolver (sin email de la familia, o de un curso sin fotos cargadas)
  // seguían saliendo primero todos los días y ocupaban los 20 lugares: los demás pedidos pendientes
  // no se reintentaban nunca. Ahora se trae un margen más amplio, se descartan los que no tienen
  // email y se priorizan los más nuevos.
  // Auditoría 03/10: el orden y la gracia van por pagado_at (cuándo se cobró), no por created_at: un
  // pedido creado hace días y pagado recién no se le cruza al webhook que lo está procesando.
  const { data: candidatos, error } = await supabase
    .from('pedidos')
    .select('*, familias(nombre, whatsapp, email)')
    .eq('estado', 'pagado')
    .eq('seleccion_pendiente', false)
    // Las mejoras a Kit Impreso no llevan .zip propio (el digital salió con el pedido original).
    .is('mejora_de_pedido_id', null)
    .neq('tipo_kit', 'fotos_extra') // 29/10: las fotos extra tampoco (son copias impresas)
    // También los pagos con link pero cuyo correo no salió (p. ej. Resend caído en ese momento),
    // limitado a los últimos 14 días para no escribirle a familias de pedidos viejos.
    .or(`link_descarga_hd.is.null,link_descarga_hd.eq.,and(email_enviado.is.false,or(pagado_at.gte.${hace14Dias},created_at.gte.${hace14Dias}))`)
    .order('pagado_at', { ascending: false, nullsFirst: false })
    .order('created_at', { ascending: false })
    .limit(500);
  if (error) {
    console.error('[cron reintentar-hd] Error buscando pedidos pendientes:', error.message);
    return { revisados: 0, resueltos: 0, fallidos: 0 };
  }
  const pendientes = (candidatos || [])
    .filter((p: any) => String(p?.familias?.email || '').includes('@'))
    .filter((p: any) => {
      const pagadoMs = Date.parse(p?.pagado_at || p?.created_at || '');
      return Number.isFinite(pagadoMs) && pagadoMs < cortaMs;
    })
    .slice(0, limite);
  if (pendientes.length === 0) return { revisados: 0, resueltos: 0, fallidos: 0 };

  let resueltos = 0;
  let fallidos = 0;
  let reenviados = 0;
  let omitidos = 0;
  let revisados = 0;
  const inicio = Date.now();
  // En serie, no en paralelo: a diferencia del webhook (que procesa como mucho los pedidos de UN
  // pago), acá puede haber varios pedidos de distintos pagos juntos, y no tiene sentido armar
  // todos los .zip al mismo tiempo dentro de una función serverless con tiempo límite.
  for (const pedido of pendientes) {
    if (Date.now() - inicio > 45000) break;
    const yaTieneZip = Boolean(String(pedido.link_descarga_hd || '').trim());
    // Armar un .zip nuevo necesita margen (descargas + subida); reenviar un correo, no.
    if (!yaTieneZip && Date.now() - inicio > 30000) continue;
    if (!(await tocaTurnoDistribuido(`zip-hd:${pedido.id}`, 120))) {
      omitidos += 1;
      continue;
    }
    revisados += 1;
    const emailDestino = pedido.familias.email;
    try {
      const linkDescargaHD = yaTieneZip
        ? (await refirmarLinkDescargaHDSiExiste(supabase, pedido)) || null
        : await generarYSubirZipHDParaPedido(supabase, pedido);
      if (!linkDescargaHD) { fallidos += 1; continue; }
      const resultadoEnvio = await enviarCorreoFotosHD({
        to: emailDestino,
        tutorNombre: pedido?.familias?.nombre || 'Familia',
        alumnoNombre: pedido?.alumno_nombre || 'tu hijo/a',
        colegioNombre: pedido?.colegio_nombre || 'tu colegio',
        cursoCodigo: pedido?.curso_codigo || undefined,
        kitNombre: pedido?.kit_nombre || undefined,
        pedidoId: pedido?.pedido_friendly_id || pedido?.id,
        total: Number(pedido?.total) || 0,
        linkDescargaHD,
        pedidoUuid: pedido?.id,
        idempotencyKey: `fotos-hd-${pedido.id}`,
      });
      await registrarEnvioCorreoHD(supabase, pedido?.id, linkDescargaHD, resultadoEnvio?.success === true);
      if (resultadoEnvio?.success === true) {
        resueltos += 1;
        if (yaTieneZip) reenviados += 1;
      } else fallidos += 1;
    } catch (err: any) {
      fallidos += 1;
      console.warn(`[cron reintentar-hd] Falló el reintento para el pedido ${pedido?.id}:`, err?.message || err);
    }
  }
  return { revisados, resueltos, fallidos, reenviados, omitidos };
}

/**
 * 25/10 (auditoría): confirmaciones de reserva (pago anticipado) y de mejora a Kit Impreso cuyo correo falló
 * (email_enviado = false). El reintento del HD las excluye (no llevan .zip) y antes quedaban sin correo ni alerta.
 * Últimos 14 días, después de la gracia de 10 minutos del webhook, como mucho 30 por corrida.
 */
export async function reintentarConfirmacionesPendientes(supabase: SupabaseClient): Promise<{ revisadas: number; enviadas: number }> {
  const hace14Dias = new Date(Date.now() - 14 * 24 * 60 * 60 * 1000).toISOString();
  const cortaMs = Date.now() - 10 * 60 * 1000;
  const { data, error } = await supabase
    .from('pedidos')
    .select('*, familias(nombre, whatsapp, email)')
    .eq('estado', 'pagado')
    .eq('email_enviado', false)
    .gte('pagado_at', hace14Dias)
    .order('pagado_at', { ascending: false })
    .limit(200);
  if (error) {
    console.error('[cron reintentar-hd] Error buscando confirmaciones pendientes:', error.message);
    return { revisadas: 0, enviadas: 0 };
  }
  const pendientes = (data || [])
    .filter((p: any) => p.seleccion_pendiente === true || esPedidoAdicional(p)) // 29/10: + fotos extra
    .filter((p: any) => String(p?.familias?.email || '').includes('@') && Date.parse(p.pagado_at || '') < cortaMs)
    .slice(0, 30);
  let enviadas = 0;
  const inicio = Date.now();
  for (const pedido of pendientes) {
    if (Date.now() - inicio > 10000) break;
    if (!(await tocaTurnoDistribuido(`confirmacion:${pedido.id}`, 120))) continue;
    try {
      await procesarUnPedidoRecienPagado(supabase, pedido, null, null, false);
      const { data: despues } = await supabase.from('pedidos').select('email_enviado').eq('id', pedido.id).maybeSingle();
      if (despues?.email_enviado) enviadas += 1;
    } catch (err: any) {
      console.warn(`[cron reintentar-hd] No se pudo reenviar la confirmación del pedido ${pedido.id}:`, err?.message || err);
    }
  }
  return { revisadas: pendientes.length, enviadas };
}

// Diagnóstico de Nave (25/9, para pasar de sandbox a producción): prueba las credenciales cargadas
// contra el login de sandbox y el de producción y dice cuál acepta. No devuelve ningún secreto ni
// token, solo los códigos de respuesta. Protegido con el mismo secreto que las tareas programadas.
rutas.all('/api/cron/nave-diagnostico', async (req: Request, res: Response) => {
  if (!(await autorizarTareaProgramada(req))) return res.status(401).json({ success: false, error: 'No autorizado.' });
  const credenciales = getNaveCredenciales();
  if (!credenciales) return res.json({ success: false, error: 'Faltan NAVE_CLIENT_ID / NAVE_CLIENT_SECRET / NAVE_POS_ID.' });
  const probar = async (url: string) => {
    try {
      const resp = await fetchNave(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ client_id: credenciales.clientId, client_secret: credenciales.clientSecret, audience: NAVE_AUTH_AUDIENCE }),
      });
      const texto = await resp.text().catch(() => '');
      let tieneToken = false;
      try {
        tieneToken = Boolean(JSON.parse(texto)?.access_token);
      } catch {
        /* no era JSON */
      }
      return { status: resp.status, acepta: resp.ok && tieneToken, detalle: tieneToken ? 'token OK' : texto.slice(0, 200) };
    } catch (err: any) {
      return { status: 0, acepta: false, detalle: err?.message || 'error de red' };
    }
  };
  const [sandbox, produccion] = await Promise.all([
    probar('https://homoservices.apinaranja.com/security-ms/api/security/auth0/b2b/m2msPrivate'),
    probar('https://services.apinaranja.com/security-ms/api/security/auth0/b2b/m2msPrivate'),
  ]);
  return res.json({ success: true, entornoActual: getNaveEntorno(), sandbox, produccion });
});

// Control automático de pagos (cada 10 minutos, vía pg_cron): reconsulta a Mercado Pago / Nave
// los pedidos con link de pago generado que siguen sin pagar (o cancelados) en los últimos 3 días.
// Así un pago acreditado cuyo aviso se perdió se registra solo, con su correo y su .zip, aunque la
// familia haya cerrado la web.
rutas.all('/api/cron/conciliar-pagos', async (req: Request, res: Response) => {
  if (!(await autorizarTareaProgramada(req))) return res.status(401).json({ success: false, error: 'No autorizado.' });
  const supabase = getServerSupabase();
  if (!supabase) return res.status(500).json({ success: false, error: 'Supabase no configurado.' });
  const inicio = Date.now();
  // Auditoría 03/10 noche (M2): se revisa por la fecha del último link de pago generado
  // (link_pago_at), 10 días para atrás (los links de MP vencen a los 3 días, pero un pago en efectivo
  // puede acreditarse después), y nunca los cancelados definitivos (no se pueden pagar: sólo
  // ocupaban lugar en los 400). Antes se filtraba por updated_at, que crear un link no actualiza.
  const desde = new Date(Date.now() - 10 * 24 * 60 * 60 * 1000).toISOString();
  const columnas = 'id, estado, total, updated_at, mp_payment_id, metodo_pago, nave_payment_request_id, nave_intenciones_previas, mp_preference_id, grupo_pago_id, pedido_friendly_id, link_descarga_hd, seleccion_pendiente';
  // Auditoría 05/10 (medio): siempre se recorrían los 400 más nuevos y, con el presupuesto de 45 s,
  // los más viejos de la ventana no se consultaban nunca. Ahora una corrida va de los más nuevos a los
  // más viejos y la siguiente al revés, así en 20 minutos se cubren las dos puntas.
  const masViejosPrimero = Math.floor(Date.now() / (10 * 60 * 1000)) % 2 === 1;
  const { data: candidatos, error } = await supabase
    .from('pedidos')
    .select(columnas)
    .in('estado', ['pendiente_pago', 'cancelado'])
    .eq('cancelado_definitivo', false)
    .gte('link_pago_at', desde)
    .or('mp_preference_id.not.is.null,nave_payment_request_id.not.is.null')
    .order('link_pago_at', { ascending: masViejosPrimero })
    .limit(400);
  if (error) return res.status(500).json({ success: false, error: error.message });
  const vistos = new Set<string>();
  let revisados = 0;
  let pagados = 0;
  for (const fila of candidatos || []) {
    const clave = fila.grupo_pago_id || fila.id;
    if (vistos.has(clave)) continue;
    vistos.add(clave);
    if (Date.now() - inicio > 45000) break; // margen dentro del límite de 60 s de la función
    try {
      const estado = await conciliarPagoPendiente(supabase, fila, { forzar: true, hastaMs: inicio + 50000 });
      revisados += 1;
      if (estado === 'pagado' && fila.estado !== 'pagado') pagados += 1;
    } catch (err) {
      console.error('[cron conciliar-pagos] Error con', clave, err);
    }
  }
  if (pagados > 0) console.log(`[cron conciliar-pagos] ${pagados} pago(s) recuperados.`);
  await supabase.from('tareas_programadas_estado').upsert({ nombre: 'conciliar-pagos', ultima_ejecucion: new Date().toISOString(), resultado: { revisados, pagados } });
  return res.json({ success: true, revisados, pagados });
});

// Recordatorio de pago pendiente (pedido de Pablo 28/9): si a las 12 hs de registrado un pedido
// sigue "pendiente de pago" y la familia no subió el comprobante, le llega UN email automático
// recordándoselo, con un botón que abre su pedido en la web (pantalla de ReservaRetorno) para
// subir el comprobante o terminar de pagar. Corre cada hora vía pg_cron. Se manda una sola vez
// por pago (columna pedidos.recordatorio_pago_at); no se manda si el pedido está archivado, en
// espera, cancelado, ya pagado, con comprobante subido, o tiene más de 10 días (pedidos viejos
// que seguramente quedaron abandonados). Máximo 20 correos por corrida para cuidar el cupo diario
// de Resend.
const RECORDATORIO_PAGO_HORAS = 12;
const RECORDATORIO_PAGO_MAX_DIAS = 10;
const RECORDATORIO_PAGO_MAX_POR_CORRIDA = 20;

// 14/10/2026: el email (y su link con la llave) pasó a pagos/avisoPedidoPendiente.ts: también sale al crear
// un pedido por transferencia (ver enviarAvisoTransferenciaRegistrada).

rutas.all('/api/cron/recordar-pagos-pendientes', async (req: Request, res: Response) => {
  if (!(await autorizarTareaProgramada(req))) return res.status(401).json({ success: false, error: 'No autorizado.' });
  const supabase = getServerSupabase();
  if (!supabase) return res.status(500).json({ success: false, error: 'Supabase no configurado.' });
  const resend = getResendClient();
  if (!resend) return res.status(500).json({ success: false, error: 'Resend no configurado.' });
  const inicio = Date.now();
  const hasta = new Date(Date.now() - RECORDATORIO_PAGO_HORAS * 60 * 60 * 1000).toISOString();
  const desde = new Date(Date.now() - RECORDATORIO_PAGO_MAX_DIAS * 24 * 60 * 60 * 1000).toISOString();
  const columnas = 'id, estado, total, updated_at, created_at, mp_payment_id, metodo_pago, nave_payment_request_id, nave_intenciones_previas, mp_preference_id, grupo_pago_id, pedido_friendly_id, link_descarga_hd, seleccion_pendiente, alumno_nombre, colegio_id, curso_codigo, archivado, en_espera, comprobante_subido_at, recordatorio_pago_at, transferencia_desde, mejora_de_pedido_id, extras_de_pedido_id, tipo_kit, familias(nombre, email)';
  const { data: candidatos, error } = await supabase
    .from('pedidos')
    .select(columnas)
    .eq('estado', 'pendiente_pago')
    .eq('archivado', false)
    .eq('en_espera', false)
    .neq('metodo_pago', 'efectivo')
    .is('comprobante_subido_at', null)
    .is('recordatorio_pago_at', null)
    .lte('created_at', hasta)
    .gte('created_at', desde)
    .order('created_at', { ascending: true })
    .limit(300);
  if (error) return res.status(500).json({ success: false, error: error.message });
  const vistos = new Set<string>();
  let enviados = 0;
  let omitidos = 0;
  for (const fila of (candidatos || []) as any[]) {
    const clave = fila.grupo_pago_id || fila.id;
    if (vistos.has(clave)) continue;
    vistos.add(clave);
    if (enviados >= RECORDATORIO_PAGO_MAX_POR_CORRIDA || Date.now() - inicio > 45000) break;
    try {
      // Todas las filas del pago (hermanos del mismo carrito): si alguna ya está paga, tiene
      // comprobante, ya recibió el recordatorio o está archivada / en espera, no se manda.
      let filas: any[] = [fila];
      if (fila.grupo_pago_id) {
        const { data: grupo } = await supabase.from('pedidos').select(columnas).eq('grupo_pago_id', fila.grupo_pago_id);
        filas = (grupo || []).filter((f: any) => f.estado !== 'cancelado');
      }
      const bloqueado = filas.length === 0 || filas.some((f: any) => f.estado !== 'pendiente_pago' || f.comprobante_subido_at || f.recordatorio_pago_at || f.archivado || f.en_espera);
      const email = String(filas.map((f: any) => f.familias?.email).find((e: any) => e && String(e).includes('@')) || '');
      if (bloqueado || !email) {
        omitidos += 1;
        continue;
      }
      // 14/10/2026: un pedido pendiente de un chico que YA tiene otro kit pagado (pedido duplicado, p. ej.
      // un reintento o el otro tutor) no recibe «pendiente de pago»: lo invitaba a pagar dos veces. No se
      // cancela solo (lo decide Pablo) ni se marca; se vuelve a mirar en la próxima corrida (una consulta).
      // 14/10/2026: las mejoras «Pasar a Kit Impreso» copian alumno/colegio/curso del kit original
      // pagado: no son duplicados y su recordatorio tiene que salir. Sólo se miran las filas que no son
      // mejora; si no queda ninguna, no se omite. Limitación aceptada: un segundo kit que la familia
      // confirmó a propósito (confirmarOtroKit en crearPedido) no queda marcado en ninguna columna, así
      // que acá no se distingue de un duplicado y tampoco recibe el recordatorio.
      const filasKit = filas.filter((f: any) => !esPedidoAdicional(f)); // 29/10: + fotos extra
      const yaPagados = filasKit.length === 0 ? [] : await alumnosConKitPagado(supabase, filasKit.map((f: any) => ({ colegioId: f.colegio_id, cursoCodigo: f.curso_codigo, alumnoNombre: f.alumno_nombre })), filas.map((f: any) => String(f.id)));
      if (yaPagados.length > 0) {
        omitidos += 1;
        continue;
      }
      // Por las dudas, se reconsulta a la pasarela: si el pago se acreditó y el aviso se perdió,
      // se registra acá (con su correo) y no se manda el recordatorio.
      if (fila.mp_preference_id || fila.nave_payment_request_id) {
        const estado = await conciliarPagoPendiente(supabase, fila, { forzar: true, hastaMs: Date.now() + 15000 });
        if (estado !== 'pendiente_pago') {
          omitidos += 1;
          continue;
        }
      }
      const numeros = [...new Set(filas.map((f: any) => f.pedido_friendly_id || String(f.id).slice(0, 8)))].join(', ');
      const alumnos = [...new Set(filas.map((f: any) => f.alumno_nombre).filter(Boolean))].join(', ') || 'tu pedido';
      const total = filas.reduce((acc: number, f: any) => acc + (Number(f.total) || 0), 0);
      const { subject, html } = htmlRecordatorioPago({
        tutorNombre: filas.map((f: any) => f.familias?.nombre).find(Boolean) || 'Familia',
        numeros,
        alumnos,
        total,
        metodo: String(fila.metodo_pago || ''),
        url: urlPedidoPendiente(fila),
        vence: fila.metodo_pago === 'transferencia' ? venceTransferenciaDe(filas) : null,
      });
      const envio = await resend.emails.send(
        {
          from: process.env.RESEND_FROM_EMAIL || 'Retrato Escolar <fotos@retratoescolar.com.ar>',
          replyTo: resendReplyTo,
          to: [email],
          subject,
          html,
        },
        { idempotencyKey: `recordatorio-pago-${clave}` }
      );
      if (envio.error) {
        console.warn('[cron recordar-pagos-pendientes] No se pudo enviar a', clave, envio.error);
        continue;
      }
      await supabase.from('pedidos').update({ recordatorio_pago_at: new Date().toISOString() }).in('id', filas.map((f: any) => f.id));
      enviados += 1;
    } catch (err) {
      console.error('[cron recordar-pagos-pendientes] Error con', clave, err);
    }
  }
  // 10/10 (pedido de Pablo): transferencias sin comprobante a las que les quedan pocas horas. Último
  // aviso a la familia y un resumen para Pablo, para que revise el banco antes de que se cancelen.
  let avisosPorVencer = 0;
  try {
    avisosPorVencer = await avisarTransferenciasPorVencer(supabase, resend, inicio);
  } catch (err) {
    console.error('[cron recordar-pagos-pendientes] Error al avisar transferencias por vencer:', err);
  }
  // Segunda parte (pedido de Pablo 29/9): transferencias sin comprobante que ya pasaron el plazo.
  let cancelados = 0;
  try {
    cancelados = await cancelarTransferenciasVencidas(supabase, resend, inicio);
  } catch (err) {
    console.error('[cron recordar-pagos-pendientes] Error al cancelar transferencias vencidas:', err);
  }
  await supabase.from('tareas_programadas_estado').upsert({ nombre: 'recordar-pagos-pendientes', ultima_ejecucion: new Date().toISOString(), resultado: { enviados, omitidos, avisosPorVencer, cancelados } });
  return res.json({ success: true, enviados, omitidos, avisosPorVencer, cancelados });
});

// ---------------------------------------------------------------------------------------------
// Transferencias por vencer (10/10/2026, pedido de Pablo): "el cliente hizo el pago pero no envió el
// comprobante" y a las 48 h el pedido se caía. Ahora, cuando a un pago por transferencia sin comprobante
// le quedan AVISO_PREVIO_VENCIMIENTO_HORAS o menos:
//   1. a la familia le llega un último aviso con el botón para subir el comprobante (salvo que el
//      recordatorio de las 12 h le haya llegado hace muy poco: ese ya dice la fecha de vencimiento);
//   2. a Pablo (casillaAvisosAdmin) le llega UN resumen con todos los pagos por vencer, para que mire el
//      banco y, si la plata entró, lo apruebe desde el panel antes de que se cancele.
// Se avisa una sola vez por plazo (columna pedidos.aviso_vencimiento_at, migración
// 20261010150000_transferencia_aviso_vencimiento.sql). Si el plazo vuelve a empezar (la familia vuelve a
// elegir transferencia, o Pablo reabre un pedido vencido), esa columna vuelve a null y hay aviso nuevo.
// Al vencer, el pedido se cancela igual que antes pero NO se pierde: queda con transferencia_vencida_at
// y sin cancelado_definitivo, en el panel → Pedidos → «Vencidos sin comprobante», para aprobarlo o
// reabrirle el plazo.
export const AVISO_PREVIO_VENCIMIENTO_HORAS = 12;
// El recordatorio de las 12 h ya dice la fecha de vencimiento: si salió hace menos que esto, a la familia
// no se le manda otro email en la misma tanda (a Pablo sí se le avisa).
const RECORDATORIO_RECIENTE_HORAS = 6;

/**
 * Vencimiento del pago si le toca el último aviso: todas las filas siguen pendientes por transferencia,
 * sin comprobante, sin archivar ni en espera, sin aviso previo, y vence dentro de las próximas
 * AVISO_PREVIO_VENCIMIENTO_HORAS (todavía no venció). Si no corresponde avisar, null.
 */
export function transferenciaPorVencer(filas: any[], ahora: number = Date.now()): Date | null {
  if (filas.length === 0) return null;
  if (filas.some((f: any) => f.estado !== 'pendiente_pago' || f.metodo_pago !== 'transferencia' || f.comprobante_subido_at || f.archivado || f.en_espera || f.aviso_vencimiento_at)) {
    return null;
  }
  const vence = venceTransferenciaDe(filas);
  if (!vence) return null;
  const falta = vence.getTime() - ahora;
  if (falta <= 0 || falta > AVISO_PREVIO_VENCIMIENTO_HORAS * 60 * 60 * 1000) return null;
  return vence;
}

/** Un pago por transferencia para el resumen que le llega a Pablo. */
export type PagoTransferenciaResumen = {
  numeros: string;
  alumnos: string;
  colegio: string;
  tutor: string;
  email: string;
  total: number;
  vence: Date;
  /** Sólo en «por vencer»: qué pasó con el último aviso a la familia. */
  avisoFamilia?: 'enviado' | 'recordatorio-reciente' | 'sin-email' | 'fallo';
};

function datosDelPago(filas: any[]): Omit<PagoTransferenciaResumen, 'vence' | 'avisoFamilia'> {
  return {
    numeros: [...new Set(filas.map((f: any) => f.pedido_friendly_id || String(f.id).slice(0, 8)))].join(', '),
    alumnos: [...new Set(filas.map((f: any) => f.alumno_nombre).filter(Boolean))].join(', ') || '—',
    colegio: [...new Set(filas.map((f: any) => f.colegio_nombre).filter(Boolean))].join(', ') || '—',
    tutor: filas.map((f: any) => f.familias?.nombre).find(Boolean) || '',
    email: String(filas.map((f: any) => f.familias?.email).find((e: any) => e && String(e).includes('@')) || ''),
    total: filas.reduce((acc: number, f: any) => acc + (Number(f.total) || 0), 0),
  };
}

/** Resumen para Pablo: pagos por transferencia por vencer o ya vencidos (cancelados, recuperables). */
export function htmlAvisoAdminTransferencias(tipo: 'por-vencer' | 'vencidos', pagos: PagoTransferenciaResumen[]): { subject: string; html: string } {
  const n = pagos.length;
  const plural = n === 1 ? '' : 's';
  const textoAvisoFamilia: Record<string, string> = {
    enviado: 'Último aviso enviado',
    'recordatorio-reciente': 'Recibió el recordatorio hace poco',
    'sin-email': '⚠ Sin email: avisale vos',
    fallo: '⚠ No se pudo mandar el aviso',
  };
  const filasTabla = pagos
    .map((p) => {
      const columnaAviso = tipo === 'por-vencer' ? `<td style="padding:6px 8px;border-top:1px solid #e2e8f0">${escapeHtml(textoAvisoFamilia[p.avisoFamilia || ''] || '')}</td>` : '';
      return `<tr><td style="padding:6px 8px;border-top:1px solid #e2e8f0;font-family:monospace">${escapeHtml(p.numeros)}</td><td style="padding:6px 8px;border-top:1px solid #e2e8f0">${escapeHtml(p.alumnos)}<br><span style="color:#64748b">${escapeHtml(p.colegio)}</span></td><td style="padding:6px 8px;border-top:1px solid #e2e8f0">${escapeHtml(p.tutor)}${p.email ? `<br><span style="color:#64748b">${escapeHtml(p.email)}</span>` : ''}</td><td style="padding:6px 8px;border-top:1px solid #e2e8f0;white-space:nowrap"><strong>$${p.total.toLocaleString('es-AR')}</strong></td><td style="padding:6px 8px;border-top:1px solid #e2e8f0">${escapeHtml(fechaHoraArgentina(p.vence))}</td>${columnaAviso}</tr>`;
    })
    .join('');
  const encabezadoAviso = tipo === 'por-vencer' ? '<th style="padding:6px 8px;text-align:left">Familia avisada</th>' : '';
  const tabla = `<table style="border-collapse:collapse;width:100%;font-size:13px;margin:12px 0"><thead style="background:#f1f5f9"><tr><th style="padding:6px 8px;text-align:left">Pedido</th><th style="padding:6px 8px;text-align:left">Alumno/s</th><th style="padding:6px 8px;text-align:left">Familia</th><th style="padding:6px 8px;text-align:left">Monto</th><th style="padding:6px 8px;text-align:left">${tipo === 'por-vencer' ? 'Vence' : 'Venció'}</th>${encabezadoAviso}</tr></thead><tbody>${filasTabla}</tbody></table>`;
  if (tipo === 'por-vencer') {
    return {
      subject: `⏰ ${n} pago${plural} por transferencia vence${n === 1 ? '' : 'n'} en menos de ${AVISO_PREVIO_VENCIMIENTO_HORAS} h sin comprobante`,
      html: `<div style="font-family:Arial,sans-serif;max-width:720px;margin:auto;color:#0f172a"><h2 style="margin-bottom:4px">Transferencias por vencer sin comprobante</h2><p>Estos pagos por transferencia todavía no tienen comprobante y se cancelan solos al vencer el plazo de ${PLAZO_TRANSFERENCIA_HORAS} h.</p>${tabla}<p><strong>Si la plata entró al banco</strong>, aprobalo desde el panel → Pedidos → <strong>Aprobar Pago</strong>.</p><p>Si no hacés nada y vence, el pedido no se pierde: queda en el panel → Pedidos → <strong>Vencidos sin comprobante</strong>, desde donde lo podés aprobar o reabrirle el plazo.</p></div>`,
    };
  }
  return {
    subject: `⌛ Se cancelaron ${n} pago${plural} por transferencia sin comprobante (se pueden recuperar)`,
    html: `<div style="font-family:Arial,sans-serif;max-width:720px;margin:auto;color:#0f172a"><h2 style="margin-bottom:4px">Transferencias vencidas sin comprobante</h2><p>Pasaron ${PLAZO_TRANSFERENCIA_HORAS} h sin comprobante y estos pedidos se cancelaron solos. A la familia le llegó el aviso de cancelación.</p>${tabla}<p><strong>No se borraron:</strong> están en el panel → Pedidos → <strong>Vencidos sin comprobante</strong>. Si aparece el pago, tocá <strong>Aprobar Pago</strong>; si la familia necesita más tiempo, <strong>Reabrir plazo</strong> (vuelve a pendiente con ${PLAZO_TRANSFERENCIA_HORAS} h nuevas).</p></div>`,
  };
}

async function enviarAvisoAdminTransferencias(resend: Resend, tipo: 'por-vencer' | 'vencidos', pagos: PagoTransferenciaResumen[], claves: string[]): Promise<void> {
  if (pagos.length === 0) return;
  const { subject, html } = htmlAvisoAdminTransferencias(tipo, pagos);
  const huella = crypto.createHash('sha256').update([...claves].sort().join('|')).digest('hex').slice(0, 24);
  const envio = await resend.emails.send(
    {
      from: process.env.RESEND_FROM_EMAIL || 'Retrato Escolar <fotos@retratoescolar.com.ar>',
      to: [casillaAvisosAdmin()],
      subject,
      html,
    },
    { idempotencyKey: `admin-transferencias-${tipo}-${huella}` }
  );
  if (envio.error) console.warn(`[transferencias ${tipo}] No se pudo mandar el resumen a Pablo:`, envio.error);
}

async function avisarTransferenciasPorVencer(supabase: SupabaseClient, resend: Resend, inicio: number): Promise<number> {
  const ahora = Date.now();
  // Elegidas hace entre (plazo - aviso previo) y plazo horas: les quedan AVISO_PREVIO_VENCIMIENTO_HORAS
  // o menos, y todavía no vencieron (las vencidas las cancela cancelarTransferenciasVencidas).
  const desde = new Date(ahora - PLAZO_TRANSFERENCIA_HORAS * 60 * 60 * 1000).toISOString();
  const hasta = new Date(ahora - (PLAZO_TRANSFERENCIA_HORAS - AVISO_PREVIO_VENCIMIENTO_HORAS) * 60 * 60 * 1000).toISOString();
  const columnas = 'id, estado, total, updated_at, created_at, mp_payment_id, metodo_pago, nave_payment_request_id, nave_intenciones_previas, mp_preference_id, grupo_pago_id, pedido_friendly_id, link_descarga_hd, seleccion_pendiente, alumno_nombre, colegio_nombre, archivado, en_espera, comprobante_subido_at, recordatorio_pago_at, transferencia_desde, aviso_vencimiento_at, familias(nombre, email)';
  const { data: candidatos, error } = await supabase
    .from('pedidos')
    .select(columnas)
    .eq('estado', 'pendiente_pago')
    .eq('metodo_pago', 'transferencia')
    .eq('archivado', false)
    .eq('en_espera', false)
    .is('comprobante_subido_at', null)
    .is('aviso_vencimiento_at', null)
    .not('transferencia_desde', 'is', null)
    .gt('transferencia_desde', desde)
    .lte('transferencia_desde', hasta)
    .order('transferencia_desde', { ascending: true })
    .limit(200);
  if (error) throw error;
  const vistos = new Set<string>();
  const avisados: PagoTransferenciaResumen[] = [];
  const claves: string[] = [];
  for (const fila of (candidatos || []) as any[]) {
    const clave = fila.grupo_pago_id || fila.id;
    if (vistos.has(clave)) continue;
    vistos.add(clave);
    if (avisados.length >= 20 || Date.now() - inicio > 48000) break;
    try {
      let filas: any[] = [fila];
      if (fila.grupo_pago_id) {
        const { data: grupo } = await supabase.from('pedidos').select(columnas).eq('grupo_pago_id', fila.grupo_pago_id);
        filas = (grupo || []).filter((f: any) => f.estado !== 'cancelado');
      }
      const vence = transferenciaPorVencer(filas);
      if (!vence) continue;
      // Por las dudas, si el pago tuvo un intento con Mercado Pago o Nave, se reconsulta a la pasarela.
      if (filas.some((f: any) => f.mp_preference_id || f.nave_payment_request_id)) {
        const estado = await conciliarPagoPendiente(supabase, fila, { forzar: true, hastaMs: Date.now() + 15000 });
        if (estado !== 'pendiente_pago') continue;
      }
      // Se marca ANTES de avisar y sólo si sigue igual: así dos corridas que se pisan no avisan dos veces.
      const marca = new Date().toISOString();
      const { data: marcadas, error: errorMarca } = await supabase
        .from('pedidos')
        .update({ aviso_vencimiento_at: marca })
        .in('id', filas.map((f: any) => f.id))
        .eq('estado', 'pendiente_pago')
        .eq('metodo_pago', 'transferencia')
        .eq('archivado', false)
        .eq('en_espera', false)
        .is('comprobante_subido_at', null)
        .is('aviso_vencimiento_at', null)
        .select('id');
      if (errorMarca) {
        console.error('[transferencias por vencer] No se pudo marcar', clave, errorMarca.message);
        continue;
      }
      if (!marcadas || marcadas.length === 0) continue;
      const datos = datosDelPago(filas);
      const ultimoRecordatorio = Math.max(0, ...filas.map((f: any) => Date.parse(f.recordatorio_pago_at || '') || 0));
      let avisoFamilia: PagoTransferenciaResumen['avisoFamilia'] = 'sin-email';
      if (ultimoRecordatorio && Date.now() - ultimoRecordatorio < RECORDATORIO_RECIENTE_HORAS * 60 * 60 * 1000) {
        avisoFamilia = 'recordatorio-reciente';
      } else if (datos.email) {
        const { subject, html } = htmlRecordatorioPago({
          tutorNombre: datos.tutor || 'Familia',
          numeros: datos.numeros,
          alumnos: datos.alumnos === '—' ? 'tu pedido' : datos.alumnos,
          total: datos.total,
          metodo: 'transferencia',
          url: urlPedidoPendiente(fila),
          vence,
          ultimoAviso: true,
        });
        const envio = await resend.emails.send(
          {
            from: process.env.RESEND_FROM_EMAIL || 'Retrato Escolar <fotos@retratoescolar.com.ar>',
            replyTo: resendReplyTo,
            to: [datos.email],
            subject,
            html,
          },
          { idempotencyKey: `aviso-vencimiento-${clave}-${vence.getTime()}` }
        );
        avisoFamilia = envio.error ? 'fallo' : 'enviado';
        if (envio.error) console.warn('[transferencias por vencer] No se pudo avisar a', clave, envio.error);
      }
      avisados.push({ ...datos, vence, avisoFamilia });
      claves.push(`${clave}:${vence.getTime()}`);
    } catch (err) {
      console.error('[transferencias por vencer] Error con', clave, err);
    }
  }
  await enviarAvisoAdminTransferencias(resend, 'por-vencer', avisados, claves);
  if (avisados.length > 0) console.log(`[transferencias por vencer] ${avisados.length} pago(s) avisado(s).`);
  return avisados.length;
}

// Cancela los pedidos por transferencia que siguen sin comprobante pasadas PLAZO_TRANSFERENCIA_HORAS
// desde que se eligió transferencia. Se hace por pago completo (todos los hermanos de un carrito
// juntos) y se le avisa a la familia por email. No toca pedidos archivados, en espera, pagados, con
// comprobante, ni los anteriores a esta regla (sin transferencia_desde). Si el pago tuvo un intento
// con Mercado Pago o Nave, antes se reconsulta a la pasarela por si se acreditó por ahí.
async function cancelarTransferenciasVencidas(supabase: SupabaseClient, resend: Resend, inicio: number): Promise<number> {
  const limite = new Date(Date.now() - PLAZO_TRANSFERENCIA_HORAS * 60 * 60 * 1000).toISOString();
  const columnas = 'id, estado, total, updated_at, created_at, mp_payment_id, metodo_pago, nave_payment_request_id, nave_intenciones_previas, mp_preference_id, grupo_pago_id, pedido_friendly_id, link_descarga_hd, seleccion_pendiente, alumno_nombre, colegio_nombre, archivado, en_espera, comprobante_subido_at, transferencia_desde, familias(nombre, email)';
  const { data: candidatos, error } = await supabase
    .from('pedidos')
    .select(columnas)
    .eq('estado', 'pendiente_pago')
    .eq('metodo_pago', 'transferencia')
    .eq('archivado', false)
    .eq('en_espera', false)
    .is('comprobante_subido_at', null)
    .not('transferencia_desde', 'is', null)
    .lte('transferencia_desde', limite)
    .order('transferencia_desde', { ascending: true })
    .limit(200);
  if (error) throw error;
  const vistos = new Set<string>();
  let cancelados = 0;
  // 10/10: resumen para Pablo con lo que se canceló en esta corrida (queda recuperable en el panel).
  const resumen: PagoTransferenciaResumen[] = [];
  const claves: string[] = [];
  for (const fila of (candidatos || []) as any[]) {
    const clave = fila.grupo_pago_id || fila.id;
    if (vistos.has(clave)) continue;
    vistos.add(clave);
    if (cancelados >= 20 || Date.now() - inicio > 50000) break;
    try {
      let filas: any[] = [fila];
      if (fila.grupo_pago_id) {
        const { data: grupo } = await supabase.from('pedidos').select(columnas).eq('grupo_pago_id', fila.grupo_pago_id);
        filas = (grupo || []).filter((f: any) => f.estado !== 'cancelado');
      }
      const vence = venceTransferenciaDe(filas);
      const bloqueado =
        filas.length === 0 ||
        !vence ||
        vence.getTime() > Date.now() ||
        filas.some((f: any) => f.estado !== 'pendiente_pago' || f.metodo_pago !== 'transferencia' || f.comprobante_subido_at || f.archivado || f.en_espera);
      if (bloqueado) continue;
      if (filas.some((f: any) => f.mp_preference_id || f.nave_payment_request_id)) {
        const estado = await conciliarPagoPendiente(supabase, fila, { forzar: true, hastaMs: Date.now() + 15000 });
        if (estado !== 'pendiente_pago') continue;
      }
      const ahora = new Date().toISOString();
      const ids = filas.map((f: any) => f.id);
      // Sólo si sigue igual (comprobante recién subido; auditoría 11/10: o pasó a otro medio, archivado o en espera).
      const { data: actualizados, error: errorUpdate } = await supabase
        .from('pedidos')
        .update({ estado: 'cancelado', transferencia_vencida_at: ahora, updated_at: ahora })
        .in('id', ids)
        .eq('estado', 'pendiente_pago')
        .eq('metodo_pago', 'transferencia')
        .eq('archivado', false)
        .eq('en_espera', false)
        .is('comprobante_subido_at', null)
        .select('id');
      if (errorUpdate) {
        console.error('[transferencias vencidas] No se pudo cancelar', clave, errorUpdate.message);
        continue;
      }
      if (!actualizados || actualizados.length === 0) continue;
      cancelados += 1;
      // `vence` no es null acá (si lo fuera, `bloqueado` habría cortado arriba).
      resumen.push({ ...datosDelPago(filas), vence: vence as Date });
      claves.push(`${clave}:${(vence as Date).getTime()}`);
      console.log(`[transferencias vencidas] Pedido ${clave} cancelado (${actualizados.length} fila/s).`);
      const email = String(filas.map((f: any) => f.familias?.email).find((e: any) => e && String(e).includes('@')) || '');
      if (!email) continue;
      const numeros = [...new Set(filas.map((f: any) => f.pedido_friendly_id || String(f.id).slice(0, 8)))].join(', ');
      const alumnos = [...new Set(filas.map((f: any) => f.alumno_nombre).filter(Boolean))].join(', ') || 'tu pedido';
      const tutor = filas.map((f: any) => f.familias?.nombre).find(Boolean) || 'Familia';
      const appUrl = (process.env.APP_URL || 'https://www.retratoescolar.com.ar').replace(/\/+$/, '');
      const envio = await resend.emails.send(
        {
          from: process.env.RESEND_FROM_EMAIL || 'Retrato Escolar <fotos@retratoescolar.com.ar>',
          replyTo: resendReplyTo,
          to: [email],
          subject: `Retrato Escolar: se canceló tu pedido ${numeros} (no recibimos el comprobante)`,
          html: `<div style="font-family:Arial,sans-serif;max-width:560px;margin:auto;color:#1e293b">
<p>Hola <strong>${escapeHtml(tutor)}</strong>,</p>
<p>Tu pedido <strong>${escapeHtml(numeros)}</strong> (${escapeHtml(alumnos)}) era por <strong>transferencia</strong> y pasaron ${PLAZO_TRANSFERENCIA_HORAS} horas sin que recibiéramos el comprobante, así que <strong>se canceló automáticamente</strong>, como te avisamos al hacer el pedido.</p>
<p><strong>¿Ya habías transferido?</strong> Respondé este email con el comprobante: tu pedido queda guardado y, si la transferencia está acreditada, lo reactivamos tal cual, con las mismas fotos.</p>
<p><strong>¿Todavía lo querés?</strong> Podés hacer el pedido de nuevo cuando quieras desde la web:</p>
<p style="text-align:center;margin:24px 0"><a href="${escapeHtml(appUrl)}" style="background:#f59e0b;color:#0f172a;text-decoration:none;font-weight:bold;padding:12px 22px;border-radius:10px;display:inline-block">Ir a Retrato Escolar</a></p>
<p style="font-size:12px;color:#64748b">Pedido ${escapeHtml(numeros)} · Retrato Escolar · retratoescolar.com.ar</p></div>`,
        },
        { idempotencyKey: `transferencia-vencida-${clave}` }
      );
      if (envio.error) console.warn('[transferencias vencidas] No se pudo avisar a', clave, envio.error);
    } catch (err) {
      console.error('[transferencias vencidas] Error con', clave, err);
    }
  }
  if (cancelados > 0) console.log(`[transferencias vencidas] ${cancelados} pedido(s) cancelado(s).`);
  try {
    await enviarAvisoAdminTransferencias(resend, 'vencidos', resumen, claves);
  } catch (err) {
    console.error('[transferencias vencidas] No se pudo mandar el resumen a Pablo:', err);
  }
  return cancelados;
}

rutasHD.all('/api/cron/limpiar-huerfanos', async (req: Request, res: Response) => {
  if (!(await autorizarTareaProgramada(req))) {
    return res.status(401).json({ success: false, error: 'No autorizado.' });
  }
  const supabase = getServerSupabase();
  if (!supabase) return res.status(500).json({ success: false, error: 'Supabase no configurado en el servidor' });
  try {
    const resultado = await limpiarArchivosHuerfanos(supabase, true, 3 * 24 * 60 * 60 * 1000);
    await supabase.from('tareas_programadas_estado').upsert({ nombre: 'limpiar-huerfanos', ultima_ejecucion: new Date().toISOString(), resultado });
    return res.json({ success: true, ...resultado });
  } catch (err: any) {
    console.error('[cron limpiar-huerfanos]', err);
    return res.status(500).json({ success: false, error: err?.message || 'Error al limpiar' });
  }
});

rutasHD.all('/api/cron/reintentar-hd', async (req: Request, res: Response) => {
  // Además del cron diario de Vercel, pg_cron lo llama cada hora (ver autorizarTareaProgramada).
  if (!(await autorizarTareaProgramada(req))) {
    return res.status(401).json({ success: false, error: 'No autorizado.' });
  }
  const supabase = getServerSupabase();
  if (!supabase) return res.status(500).json({ success: false, error: 'Supabase no configurado en el servidor' });
  // 25/10: las confirmaciones (rápidas, sin .zip) van primero: si el armado de los .zip agota los 60 s, igual salen.
  const confirmaciones = await reintentarConfirmacionesPendientes(supabase);
  const resultado: Record<string, unknown> = { ...(await reintentarPedidosConHDPendiente(supabase)), confirmaciones };
  console.log('[cron reintentar-hd]', resultado);
  await supabase.from('tareas_programadas_estado').upsert({ nombre: 'reintentar-hd', ultima_ejecucion: new Date().toISOString(), resultado });
  return res.json({ success: true, ...resultado });
});

export { rutas as rutasTareasProgramadas, rutasHD as rutasTareasProgramadasHD };
