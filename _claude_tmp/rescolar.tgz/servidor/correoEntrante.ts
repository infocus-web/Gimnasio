// Correo entrante: webhook de Resend (/api/webhooks/resend-inbound) para los mails que llegan al
// dominio. Lo que es consulta de una familia entra al panel (Consultas, con borrador de la IA); lo demás
// (comprobantes, fotos@, avisos) se reenvía a la casilla de Zoho (división de server.ts, etapa 5,
// 10/10/2026). El código es el mismo que estaba al principio de server.ts: sólo se movió. La ruta va
// ANTES de express.json (lee el cuerpo como texto para verificar la firma de Resend): server.ts monta
// este router en ese mismo lugar.
import type { SupabaseClient } from '@supabase/supabase-js';
import express from 'express';
import type { Request, Response } from 'express';
import { Resend } from 'resend';
import { conLimiteDeTiempo, procesarConsultaConIA } from './familias/consultas.js';
import { CASILLA_REENVIO_ENTRANTE, casillaAvisosAdmin, getResendClient, getResendInboundClient, getServerSupabase } from './nucleo/clientes.js';
import { hayCupoGlobal } from './nucleo/limites.js';
import { escapeHtml } from './nucleo/utilidades.js';
import { registrarRebotesEnvios } from './panel/emailsFamilias.js';

const rutas = express.Router();

// Las respuestas por email traen debajo el mensaje original citado ("El mar, 22 sept 2026, ...
// escribió:" + líneas con ">"), que en el panel ya se ve arriba en la conversación. Se recorta
// para mostrar sólo lo que escribió la familia; si el recorte dejara el texto vacío, se deja entero.
function quitarMensajeCitado(texto: string): string {
  const lineas = texto.split(/\r?\n/);
  let corte = lineas.findIndex((linea) => /^\s*>/.test(linea));
  if (corte === -1) return texto;
  // Encabezado de la cita ("El ..., X escribió:" / "On ..., X wrote:"), que Gmail puede partir en 2-3 líneas.
  for (let i = corte - 1; i >= Math.max(0, corte - 4); i--) {
    if (/(escribi[oó]|wrote)\s*:\s*$/i.test(lineas[i])) {
      let inicio = i;
      while (inicio > 0 && inicio > i - 3 && lineas[inicio - 1].trim() !== '' && !/^\s*(El|On)\s/i.test(lineas[inicio])) inicio--;
      corte = inicio;
      break;
    }
  }
  const recortado = lineas.slice(0, corte).join('\n').trim();
  return recortado || texto;
}

// Reenvía a la casilla de Zoho un correo recibido en el dominio principal, con sus adjuntos
// (los links de descarga de Resend) y con "Responder" apuntando a quien lo mandó. La clave de
// idempotencia evita duplicados si Resend reintenta o se hace "Replay" del mismo evento.
async function reenviarCorreoEntrante(resend: Resend, lector: Resend, email: any): Promise<void> {
  const remitente = String(email.from || '');
  if (remitente.toLowerCase().includes(CASILLA_REENVIO_ENTRANTE.toLowerCase())) return;
  // 1/10: Zoho reenvía a familias@ una copia de todo lo que llega a colegios@. Nunca se vuelve a
  // mandar a Zoho algo que salió de nuestros propios dominios (evita un bucle infinito de reenvíos).
  if (DOMINIOS_PROPIOS.test(direccionDeCorreo(remitente))) return;
  // Auditoría 03/10 (alto 26): cualquiera puede mandar correos a cualquier dirección @retratoescolar
  // y cada uno se reenviaba a Zoho sin tope (gastaba el cupo diario de Resend que necesitan los links
  // HD y los códigos). Tope GLOBAL de 200 reenvíos por hora; pasado eso el correo sigue en Resend
  // (Emails → Receiving) y sólo se saltea el reenvío.
  if (!(await hayCupoGlobal('reenvio-correo-entrante', 200, 3600))) {
    console.warn('[Reenvío entrante] Tope por hora alcanzado: no se reenvía', email?.id);
    return;
  }
  let adjuntos: { filename?: string; path: string }[] = [];
  if (Array.isArray(email.attachments) && email.attachments.length > 0) {
    const { data, error } = await lector.emails.receiving.attachments.list({ emailId: email.id });
    if (error) throw error;
    adjuntos = (data?.data || []).map((a: any) => ({ filename: a.filename || undefined, path: a.download_url }));
  }
  const destinos = (Array.isArray(email.to) ? email.to : []).join(', ');
  const encabezado = `<div style="font-family:Arial,sans-serif;font-size:12px;color:#475569;border:1px solid #e2e8f0;background:#f8fafc;border-radius:8px;padding:10px 12px;margin-bottom:16px">Reenviado automáticamente por la web.<br><strong>De:</strong> ${escapeHtml(remitente)}<br><strong>Para:</strong> ${escapeHtml(destinos)}<br>Tocá "Responder" para contestarle directo a quien lo mandó.</div>`;
  // Auditoría 03/10 (alto 26): antes se reenviaba el HTML crudo del remitente (links disfrazados,
  // formularios, imágenes de rastreo: servía para phishing a Pablo con el aspecto de un aviso de la
  // web). Ahora sólo va el TEXTO, escapado; si el correo no trae versión texto se le sacan las etiquetas.
  const textoPlano = String(email.text || '').trim() ||
    String(email.html || '')
      .replace(/<(script|style)[^>]*>[\s\S]*?<\/\1>/gi, ' ')
      .replace(/<br\s*\/?>|<\/(p|div|li|tr|h[1-6])>/gi, '\n')
      .replace(/<[^>]*>/g, ' ')
      .replace(/&nbsp;/gi, ' ')
      .replace(/[ \t]+/g, ' ')
      .trim();
  const cuerpo = `<pre style="font-family:Arial,sans-serif;white-space:pre-wrap">${escapeHtml(textoPlano.slice(0, 50000) || '(sin texto)')}</pre>`;
  const { error } = await resend.emails.send(
    {
      from: process.env.RESEND_FROM_EMAIL || 'Retrato Escolar <fotos@retratoescolar.com.ar>',
      to: [CASILLA_REENVIO_ENTRANTE],
      replyTo: remitente || undefined,
      subject: `Fwd: ${email.subject || '(sin asunto)'}`.slice(0, 250),
      html: encabezado + cuerpo,
      attachments: adjuntos.length > 0 ? adjuntos : undefined,
    },
    { idempotencyKey: `reenvio-${email.id}` }
  );
  if (error) throw error;
}


// ==============================================================================
// Auditoría/pedido 2026-09-26: CONSULTAS DE FAMILIAS POR EMAIL
// Los correos que las familias mandan a la dirección pública de contacto (contacto@ / familias@
// retratoescolar.com.ar — la que muestra la web y la que figura como "responder a" en los emails
// que les manda el sistema) ya no se reenvían a Zoho: entran como una consulta más al panel
// (Consultas de familias), con la misma revisión de datos + borrador de la IA que el formulario.
// Si la familia ya tiene una conversación abierta, el correo se suma a esa conversación.
// Por defecto la IA sólo deja BORRADOR para estos correos; para que responda sola (con las mismas
// reglas que el formulario) cargar RESPUESTAS_AUTOMATICAS_EMAIL=on en Vercel.
// Nunca se procesan: respuestas automáticas ("fuera de la oficina"), rebotes, no-reply ni correos
// que vengan de nuestros propios dominios (evita bucles) — esos siguen reenviándose a Zoho.
// Excepción útil: si Pablo REENVÍA a mano a familias@ un correo que le llegó a Zoho, se toma el
// remitente original que figura en el texto reenviado ("De: ..." / "From: ...").
// ==============================================================================
function direccionesFamilias(): string[] {
  const configuradas = String(process.env.DIRECCIONES_FAMILIAS || '')
    .split(',')
    .map((d) => d.trim().toLowerCase())
    .filter(Boolean);
  return configuradas.length > 0 ? configuradas : ['contacto@retratoescolar.com.ar', 'familias@retratoescolar.com.ar'];
}

function direccionDeCorreo(valor: unknown): string {
  const texto = String(valor || '').trim();
  const entre = texto.match(/<([^<>\s]+@[^<>\s]+)>/);
  return (entre ? entre[1] : texto).trim().toLowerCase();
}

function nombreDeCorreo(valor: unknown): string {
  const texto = String(valor || '').trim();
  const nombre = texto.includes('<') ? texto.slice(0, texto.indexOf('<')).replace(/["']/g, '').trim() : '';
  return nombre || direccionDeCorreo(texto).split('@')[0] || 'Familia';
}

const DOMINIOS_PROPIOS = /@(?:[a-z0-9-]+\.)*retratoescolar\.com\.ar$/i;

function esCorreoAutomatico(email: any, remitente: string): boolean {
  const encabezados: Record<string, string> = Object.fromEntries(
    Object.entries(email?.headers || {}).map(([k, v]) => [k.toLowerCase(), String(v)])
  );
  return (
    (Boolean(encabezados['auto-submitted']) && encabezados['auto-submitted'].toLowerCase() !== 'no') ||
    Boolean(encabezados['x-autoreply'] || encabezados['x-autorespond']) ||
    /^(bulk|junk|list)$/i.test(encabezados['precedence'] || '') ||
    /(no-?reply|mailer-daemon|postmaster|bounce)/i.test(remitente) ||
    // Auditoría 11/10: sin «ausente» ni «no se pudo entregar» (asuntos normales de una familia).
    /(respuesta autom|automatic reply|auto.?reply|fuera de la oficina|out of office|undeliverable|delivery status)/i.test(String(email?.subject || ''))
  );
}

/**
 * Auditoría 03/10 noche (B3): ¿el servidor de correo que recibió el mensaje dice que el remitente NO
 * pasó SPF/DKIM/DMARC? (cabecera Authentication-Results, si Resend la incluye). Un "From" falsificado
 * con el email de una familia no se suma a su conversación ni recibe respuestas automáticas. Si la
 * cabecera no viene, no se puede saber: se sigue como antes.
 */
function remitenteNoVerificado(email: any): boolean {
  const encabezados: Record<string, string> = Object.fromEntries(
    Object.entries(email?.headers || {}).map(([k, v]) => [k.toLowerCase(), String(v)])
  );
  const resultado = `${encabezados['authentication-results'] || ''} ${encabezados['arc-authentication-results'] || ''}`.toLowerCase();
  if (!resultado.trim()) return false;
  // Auditoría 28/10 (M1): quien manda el correo puede agregar su propia cabecera con «dmarc=pass» (por
  // ejemplo, una ARC-Authentication-Results inventada), pero no puede borrar el «dmarc=fail» que agrega
  // el servidor que lo recibió. Por eso un «dmarc=fail» en cualquier cabecera manda, aunque haya un «pass».
  if (/dmarc=fail/.test(resultado)) return true;
  if (/dmarc=pass/.test(resultado)) return false;
  return /spf=fail|dkim=fail/.test(resultado);
}

// Cuando Pablo reenvía a mano un correo, el remitente original está en el texto reenviado.
function remitenteOriginalReenviado(texto: string): { email: string; nombre: string } | null {
  const lineas = texto.split(/\r?\n/);
  for (const linea of lineas) {
    const m = linea.match(/^\s*\**\s*(?:De|From)\s*:\s*\**\s*(.+)$/i);
    if (!m) continue;
    const dir = direccionDeCorreo(m[1]);
    if (/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(dir) && !DOMINIOS_PROPIOS.test(dir)) {
      return { email: dir, nombre: nombreDeCorreo(m[1]) };
    }
  }
  return null;
}

async function registrarConsultaPorEmail(
  supabase: SupabaseClient,
  resend: Resend,
  lector: Resend,
  email: any
): Promise<{ consultaId: string | null; motivo: string }> {
  const remitenteCrudo = String(email?.from || '');
  let remitente = direccionDeCorreo(remitenteCrudo);
  let nombre = nombreDeCorreo(remitenteCrudo);
  const textoCompleto = String(email?.text || '').trim() || String(email?.html || '').replace(/<br\s*\/?>/gi, '\n').replace(/<[^>]*>/g, ' ').replace(/[ \t]+/g, ' ').trim();

  if (esCorreoAutomatico(email, remitente)) return { consultaId: null, motivo: 'automatico' };
  if (DOMINIOS_PROPIOS.test(remitente)) {
    const original = remitenteOriginalReenviado(textoCompleto);
    if (!original) return { consultaId: null, motivo: 'propio' };
    remitente = original.email;
    nombre = original.nombre;
  }
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(remitente)) return { consultaId: null, motivo: 'sin-remitente' };

  const contenido = (quitarMensajeCitado(textoCompleto) || textoCompleto || '(correo sin texto)').slice(0, 10000);
  const sinVerificar = remitenteNoVerificado(email);
  const asuntoBase = String(email?.subject || 'Consulta por email').replace(/^\s*((re|rv|fw|fwd)\s*:\s*)+/i, '').trim().slice(0, 140) || 'Consulta por email';
  const asunto = sinVerificar ? `[Remitente NO verificado] ${asuntoBase}` : asuntoBase;
  const cantidadAdjuntos = Array.isArray(email?.attachments) ? email.attachments.length : 0;
  const notaAdjuntos = cantidadAdjuntos > 0 ? `\n\n[Este correo trae ${cantidadAdjuntos} adjunto(s): se reenviaron a ${CASILLA_REENVIO_ENTRANTE}.]` : '';

  // ¿Conversación abierta de la misma familia (últimos 14 días)? Se suma ahí.
  const hace14Dias = new Date(Date.now() - 14 * 24 * 60 * 60 * 1000).toISOString();
  const { data: abiertas } = await supabase
    .from('consultas_familias')
    .select('id')
    .ilike('email', remitente.replace(/[%_\\]/g, (c) => `\\${c}`).replace(/\*/g, '')) // «*» = «%» en PostgREST
    .neq('estado', 'archivada')
    .gte('updated_at', hace14Dias)
    .order('updated_at', { ascending: false })
    .limit(1);

  let consultaId: string;
  let esNueva = false;
  if (abiertas && abiertas.length > 0 && !sinVerificar) {
    consultaId = abiertas[0].id;
    const { data: insertados, error } = await supabase.from('consultas_familias_mensajes').upsert({
      consulta_id: consultaId,
      direccion: 'entrante',
      remitente: remitenteCrudo || remitente,
      destinatario: (Array.isArray(email?.to) && email.to.length > 0 ? email.to.join(', ') : direccionesFamilias()[0]).slice(0, 500),
      asunto,
      contenido: contenido + notaAdjuntos,
      resend_email_id: email?.id,
      created_at: email?.created_at || new Date().toISOString(),
    }, { onConflict: 'resend_email_id', ignoreDuplicates: true }).select('id');
    if (error) throw error;
    if (!insertados || insertados.length === 0) return { consultaId, motivo: 'duplicado' };
    await supabase.from('consultas_familias').update({ estado: 'nueva', updated_at: new Date().toISOString() }).eq('id', consultaId);
  } else {
    const { data: creada, error } = await supabase.from('consultas_familias').insert({
      nombre: nombre.slice(0, 120) || 'Familia',
      email: remitente,
      asunto,
      mensaje: (contenido + notaAdjuntos).slice(0, 10000),
      estado: 'nueva',
      origen: 'email',
      resend_email_id: email?.id || null,
    }).select('id').single();
    if (error) {
      // 23505 = el mismo correo ya se registró (Resend reintentó el aviso).
      if ((error as any).code === '23505') return { consultaId: null, motivo: 'duplicado' };
      throw error;
    }
    consultaId = creada.id;
    esNueva = true;
  }

  // Los adjuntos (comprobantes, fotos) no se guardan en el panel: se reenvía el correo a Zoho.
  if (cantidadAdjuntos > 0) {
    try {
      await reenviarCorreoEntrante(resend, lector, email);
    } catch (errAdj) {
      console.warn('[Consultas por email] No se pudieron reenviar los adjuntos a Zoho:', errAdj);
    }
  }

  // Aviso al fotógrafo, igual que con el formulario de la web (sólo para conversaciones nuevas).
  if (esNueva && (await hayCupoGlobal('aviso-consulta-email', 120, 3600))) {
    const aviso = await resend.emails.send({
      from: process.env.RESEND_FROM_EMAIL || 'Retrato Escolar <fotos@retratoescolar.com.ar>',
      replyTo: remitente,
      to: [casillaAvisosAdmin()],
      subject: `Nueva consulta por email: ${asunto}`,
      html: `<div style="font-family:Arial,sans-serif;max-width:640px;margin:auto;color:#0f172a"><h2>Nueva consulta de una familia (por email)</h2><p><strong>De:</strong> ${escapeHtml(nombre)} (${escapeHtml(remitente)})</p><div style="padding:16px;background:#f8fafc;border:1px solid #e2e8f0;border-radius:12px;white-space:pre-wrap">${escapeHtml(contenido.slice(0, 3000))}</div><p style="font-size:12px;color:#64748b">Respondela desde el panel → Consultas de familias (ahí está el borrador de la IA).</p></div>`,
    });
    if (aviso.error) console.error('[Consultas por email] No se pudo enviar el aviso:', aviso.error);
  }

  const envioAutomaticoEmail = String(process.env.RESPUESTAS_AUTOMATICAS_EMAIL || 'off').trim().toLowerCase() === 'on';
  if (await hayCupoGlobal('ia-consultas', 200, 3600)) {
    await conLimiteDeTiempo(procesarConsultaConIA(supabase, consultaId, { permitirEnvio: envioAutomaticoEmail && !sinVerificar }), 11000);
  }
  return { consultaId, motivo: esNueva ? 'nueva' : 'agregada' };
}

/** Alerta en reportes_errores por un rebote permanente o una queja por spam (una por email enviado). Nunca tira error. */
export async function registrarProblemaDeEntrega(supabase: SupabaseClient, tipo: string, datos: any): Promise<void> {
  try {
    if (tipo === 'email.bounced' && String(datos?.bounce?.type || '').toLowerCase() === 'transient') return; // temporal: Resend reintenta
    const emailId = String(datos?.email_id || '').slice(0, 100);
    const destinatarios = (Array.isArray(datos?.to) ? datos.to : [datos?.to]).map((d: unknown) => String(d || '').trim().toLowerCase()).filter((d: string) => d.includes('@')).slice(0, 5);
    if (!emailId || destinatarios.length === 0) return;
    // 26/10: si el mail era de un envío del panel «Emails», queda marcado como rebotado en ese envío.
    if (tipo === 'email.bounced') await registrarRebotesEnvios(supabase, emailId, String(datos?.bounce?.message || ''));
    const clave = `entrega-email:${emailId}`;
    const { data: existentes } = await supabase.from('reportes_errores').select('id').eq('detalle->>clave', clave).limit(1);
    if (existentes && existentes.length > 0) return;
    const { data: familias } = await supabase.from('familias').select('id').in('email', destinatarios).limit(20);
    const idsFamilias = (familias || []).map((f: any) => f.id);
    const { data: pedidos } = idsFamilias.length
      ? await supabase.from('pedidos').select('pedido_friendly_id').in('familia_id', idsFamilias).limit(10)
      : { data: [] as any[] };
    const refs = (pedidos || []).map((p: any) => p.pedido_friendly_id).filter(Boolean);
    const asunto = String(datos?.subject || '').slice(0, 150);
    const mensaje = tipo === 'email.complained'
      ? `${destinatarios.join(', ')} marcó como spam el email «${asunto}».`
      : `No se pudo entregar el email «${asunto}» a ${destinatarios.join(', ')} (la casilla no existe o la rechazó).${refs.length ? ` Pedidos de esa familia: ${refs.join(', ')}.` : ''} Revisá la dirección con la familia y reenviale desde el panel.`;
    await supabase.from('reportes_errores').insert({
      codigo: `MAIL-${Math.random().toString(36).slice(2, 7).toUpperCase()}`,
      origen: 'admin',
      mensaje: mensaje.slice(0, 1000),
      detalle: { clave, tipo: tipo === 'email.complained' ? 'queja_spam' : 'rebote_email', emailId, destinatarios, asunto, pedidos: refs, motivo: String(datos?.bounce?.message || '').slice(0, 300) },
    });
  } catch (err: any) {
    console.error('[Resend] No se pudo registrar el rebote/queja:', err?.message || err);
  }
}

// Resend firma el cuerpo exacto del webhook. Esta ruta debe procesarse como texto
// antes del parser JSON global para poder verificar que el evento sea auténtico.
rutas.post('/api/webhooks/resend-inbound', express.text({ type: 'application/json' }), async (req: Request, res: Response) => {
  try {
    const resend = getResendClient();
    const webhookSecret = process.env.RESEND_WEBHOOK_SECRET?.trim();
    if (!resend || !webhookSecret) return res.status(503).json({ success: false });
    const id = req.header('svix-id');
    const timestamp = req.header('svix-timestamp');
    const signature = req.header('svix-signature');
    if (!id || !timestamp || !signature) return res.status(400).json({ success: false });

    const evento = resend.webhooks.verify({
      payload: String(req.body || ''),
      headers: { id, timestamp, signature },
      webhookSecret,
    });
    // 25/10 (auditoría): rebotes y quejas por spam. Antes se ignoraban: un link HD a una casilla mal escrita quedaba
    // «enviado» y nadie se enteraba. Ahora queda una alerta en el panel (Estado del sistema) con los pedidos de esa familia.
    // Requiere suscribir el webhook de Resend a email.bounced y email.complained.
    if (evento.type === 'email.bounced' || evento.type === 'email.complained') {
      const supabase = getServerSupabase();
      if (supabase) await registrarProblemaDeEntrega(supabase, evento.type, (evento as any).data || {});
      return res.json({ success: true });
    }
    if (evento.type !== 'email.received') return res.json({ success: true });

    // Auditoría 2026-09-24 (bug real en producción): si Resend no devolvía el texto del correo
    // (respondió 404 "Inbound email not found" al reenviar un evento), se tiraba un error y la
    // respuesta de la familia se perdía por completo. El evento ya trae remitente, destinatarios
    // y asunto: con eso se registra igual la respuesta en la consulta, con un aviso para leer el
    // texto en el panel de Resend.
    const datosEvento: any = evento.data || {};
    const lectorInbound = getResendInboundClient() || resend;
    const { data: email, error: emailError } = await lectorInbound.emails.receiving.get(datosEvento.email_id);
    if (emailError || !email) {
      console.warn('[Resend Inbound] No se pudo descargar el texto del correo recibido:', emailError);
    }
    const inboundDomain = (process.env.RESEND_INBOUND_DOMAIN || 'respuestas.retratoescolar.com.ar').toLowerCase();
    const destinatarios: string[] = Array.isArray(email?.to) ? email.to : Array.isArray(datosEvento.to) ? datosEvento.to : [];
    const direccionDestino = destinatarios.find((destino) => String(destino).toLowerCase().includes(`@${inboundDomain}`));
    const consultaId = direccionDestino?.match(/consulta-([0-9a-f-]{36})@/i)?.[1];
    // Auditoría 11/10: sin el correo (error de Resend) y sin consulta no hay qué hacer: 503 para que
    // Resend reintente (antes 200 «ignored» y el correo, p. ej. un comprobante, se perdía).
    if (!email && !consultaId) return res.status(503).json({ success: false });
    if (!consultaId) {
      // 1/10: copia de un correo que esta misma web ya reenvió a Zoho (Zoho la devuelve a familias@
      // con su reenvío automático): se ignora, ya se procesó cuando llegó por primera vez.
      if (String(email?.html || email?.text || '').includes('Reenviado automáticamente por la web')) {
        return res.json({ success: true, ignored: true, motivo: 'copia-de-reenvio' });
      }
      // Avisos de Zoho (por ejemplo, el código para verificar el reenvío automático): se pasan a la
      // casilla de Zoho para que Pablo los vea (si no, quedaban descartados como "automáticos").
      if (email && /@([a-z0-9-]+\.)*zoho(mail)?\.(com|eu|in|com\.au)>?\s*$/i.test(String(email.from || '').trim())) {
        await reenviarCorreoEntrante(resend, lectorInbound, email);
        return res.json({ success: true, reenviado: true, motivo: 'aviso-zoho' });
      }
      // Correos a la dirección pública de las familias (contacto@ / familias@): entran al panel
      // como consulta (ver registrarConsultaPorEmail). Si no corresponde procesarlos (respuesta
      // automática, remitente propio), siguen el camino de siempre: reenvío a Zoho.
      const direccionesDeFamilias = direccionesFamilias();
      // 1/10: también los que llegan reenviados por Zoho desde colegios@ (conservan ese "Para").
      const aFamilias = destinatarios.some((destino) => {
        const d = direccionDeCorreo(destino);
        return direccionesDeFamilias.includes(d) || d === CASILLA_REENVIO_ENTRANTE.toLowerCase();
      });
      if (aFamilias && email) {
        const supabaseFamilias = getServerSupabase();
        if (supabaseFamilias) {
          const resultado = await registrarConsultaPorEmail(supabaseFamilias, resend, lectorInbound, email);
          if (resultado.consultaId || resultado.motivo === 'duplicado') {
            return res.json({ success: true, consulta: resultado.consultaId, motivo: resultado.motivo });
          }
          // Auditoría 11/10: lo automático (y lo propio) no se descarta: sigue al reenvío a Zoho de abajo.
        }
      }
      // Correos a direcciones del dominio principal (fotos@, colegios@, contacto@...): el MX de
      // retratoescolar.com.ar apunta a Resend, que no es una casilla que alguien lea. Se reenvían
      // a la casilla real de Zoho para que no se pierdan (p. ej. comprobantes de transferencia).
      const aDominioPrincipal = destinatarios.some((destino) => /@retratoescolar\.com\.ar>?\s*$/i.test(String(destino).trim()));
      if (aDominioPrincipal && email) {
        await reenviarCorreoEntrante(resend, lectorInbound, email);
        return res.json({ success: true, reenviado: true });
      }
      return res.json({ success: true, ignored: true });
    }

    const contenido = email
      ? quitarMensajeCitado(String(email.text || '').trim()) || String(email.html || '').replace(/<[^>]*>/g, ' ').replace(/\s+/g, ' ').trim()
      : '(No se pudo descargar el texto de esta respuesta. Leela en resend.com → Emails → Receiving.)';
    // Pedido de Pablo (28/9): las capturas que una familia manda RESPONDIENDO a un email de la
    // consulta se perdían (acá sólo se guardaba el texto). Ahora se reenvían a Zoho, igual que las
    // de un email nuevo, y la consulta avisa que llegaron.
    const cantidadAdjuntosRespuesta = Array.isArray(email?.attachments) ? email.attachments.length : 0;
    if (!contenido && cantidadAdjuntosRespuesta === 0) return res.json({ success: true, ignored: true });
    const notaAdjuntosRespuesta =
      cantidadAdjuntosRespuesta > 0 ? `\n\n[Este correo trae ${cantidadAdjuntosRespuesta} adjunto(s): se reenviaron a ${CASILLA_REENVIO_ENTRANTE}.]` : '';
    const supabase = getServerSupabase();
    if (!supabase) throw new Error('Supabase no configurado.');
    const { data: insertados, error: insertError } = await supabase.from('consultas_familias_mensajes').upsert({
      consulta_id: consultaId,
      direccion: 'entrante',
      remitente: email?.from || datosEvento.from || 'desconocido',
      destinatario: direccionDestino,
      asunto: email?.subject || datosEvento.subject || null,
      contenido: ((contenido || '(correo sin texto)') + notaAdjuntosRespuesta).slice(0, 10000),
      resend_email_id: email?.id || datosEvento.email_id,
      created_at: email?.created_at || datosEvento.created_at || new Date().toISOString(),
    }, { onConflict: 'resend_email_id', ignoreDuplicates: true }).select('id');
    if (insertError) throw insertError;
    if (insertados && insertados.length > 0 && cantidadAdjuntosRespuesta > 0 && email) {
      try {
        await reenviarCorreoEntrante(resend, lectorInbound, email);
      } catch (errAdj) {
        console.warn('[Resend Inbound] No se pudieron reenviar los adjuntos de la respuesta a Zoho:', errAdj);
      }
    }
    await supabase.from('consultas_familias').update({ estado: 'nueva', updated_at: new Date().toISOString() }).eq('id', consultaId);
    // Sólo si es un mensaje nuevo (no un reintento o "Replay" de uno ya guardado) se revisa y,
    // si corresponde, se contesta solo. Las respuestas automáticas del correo de la familia
    // ("fuera de la oficina") nunca se contestan, para no entrar en un ida y vuelta infinito.
    if (insertados && insertados.length > 0) {
      const encabezados: Record<string, string> = Object.fromEntries(
        Object.entries((email as any)?.headers || {}).map(([k, v]) => [k.toLowerCase(), String(v)])
      );
      const esAutoRespuesta =
        (encabezados['auto-submitted'] && encabezados['auto-submitted'].toLowerCase() !== 'no') ||
        Boolean(encabezados['x-autoreply'] || encabezados['x-autorespond']) ||
        /(respuesta autom|automatic reply|auto.?reply|fuera de la oficina|out of office)/i.test(String(email?.subject || datosEvento.subject || ''));
      if (await hayCupoGlobal('ia-consultas', 200, 3600)) await conLimiteDeTiempo(
        procesarConsultaConIA(supabase, consultaId, { permitirEnvio: !remitenteNoVerificado(email), esRespuestaAutomaticaDeLaFamilia: esAutoRespuesta }),
        12000 // Resend espera ~15 s la respuesta del webhook; si la IA tarda más, queda para el panel.
      );
    }
    return res.json({ success: true });
  } catch (err: any) {
    console.error('[Resend Inbound] Webhook rechazado o no procesado:', err);
    return res.status(400).json({ success: false });
  }
});

export { rutas as rutasCorreoEntrante };
