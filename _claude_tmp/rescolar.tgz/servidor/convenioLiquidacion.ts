// Convenio con el colegio (página /convenio.html?c=CODIGO: datos, firma electrónica, Anexo IV de
// precios) y liquidación al colegio (30% de la ganancia neta, costos del laboratorio, comisiones)
// (división de server.ts, etapa 2, 10/10/2026). El código es el mismo que estaba en las secciones
// "CONVENIO CON EL COLEGIO" y "LIQUIDACIÓN AL COLEGIO" de server.ts: sólo se movió de lugar. Las
// rutas se declaran con el path completo en `rutas` y server.ts las monta con
// app.use(rutasConvenioLiquidacion) en el mismo lugar donde estaban.
import crypto from 'crypto';
import express, { Request, Response } from 'express';
import type { SupabaseClient } from '@supabase/supabase-js';
import { registrarComisionDePago } from './comisionesCobro.js';
import { requireAdminAuth } from './nucleo/auth.js';
import { casillaAvisosAdmin, getResendClient, getServerSupabase } from './nucleo/clientes.js';
import { limitarFrecuencia } from './nucleo/limites.js';
import { esPedidoFotosExtra } from './nucleo/fotosExtra.js';
import { contarImpresionesPedido } from './nucleo/pedidos.js';
import { escapeHtml, ipDelCliente, traerTodasLasFilas } from './nucleo/utilidades.js';

const rutas = express.Router();

// ==============================================================================
// CONVENIO CON EL COLEGIO (27/9): página estática /convenio.html?c=CODIGO
// El colegio completa sus datos, el listado de alumnos que no deben ser fotografiados y lo firma
// (aceptación electrónica, Ley 25.506). Se guarda el texto completo que vio, su hash, fecha e IP,
// y se le manda copia por email al colegio y al fotógrafo.
// ==============================================================================
// DEBE coincidir con VERSION_CONVENIO de public/convenio.html.
const VERSION_CONVENIO_SERVIDOR = '2026-10-30';

// Convenio 2026-10-30 (pedido de Pablo 30/10): punto (iv) de la ganancia neta. Los gastos de operación de la
// plataforma del período se reparten entre colegios según lo cobrado a cada uno, con este tope sobre lo cobrado
// al colegio. Se guarda en el convenio firmado (gastos_plataforma_tope_pct): los convenios anteriores no lo tienen
// y su liquidación no descuenta gastos de plataforma.
const TOPE_GASTOS_PLATAFORMA_PCT = 5;

// Anexo IV del convenio (revisión 2/10): precios máximos de impresión que se pueden descontar en la
// liquidación. Salen de costos_liquidacion al momento de la firma y quedan guardados en el convenio
// firmado (precios_laboratorio); la liquidación nunca descuenta más que esos precios.
const CAMPOS_PRECIOS_LABORATORIO = ['costo_carpeta', 'costo_foto_20x30', 'costo_foto_15x21'] as const;
async function preciosLaboratorioParaConvenio(supabase: SupabaseClient) {
  const { costos } = await leerCostosLiquidacion(supabase);
  if (CAMPOS_PRECIOS_LABORATORIO.some((c) => !(costos[c] > 0))) return null;
  return { costo_carpeta: costos.costo_carpeta, costo_foto_20x30: costos.costo_foto_20x30, costo_foto_15x21: costos.costo_foto_15x21 };
}

// Participación del colegio (pedido de Pablo 1/10): un porcentaje de la GANANCIA NETA, no de la
// venta (cláusula OCTAVA BIS del convenio). El porcentaje es por colegio (colegios.porcentaje_
// participacion, 30 por defecto) y queda fijo en el convenio firmado.
function formatearPorcentaje(n: unknown): string {
  const v = Math.round((Number(n) || 0) * 100) / 100;
  return Number.isInteger(v) ? String(v) : String(v).replace('.', ',');
}

async function resolverColegioPorCodigoConvenio(codigo: string) {
  const supabase = getServerSupabase();
  if (!supabase) return { ok: false as const, status: 500, error: 'Servicio no disponible' };
  const codigoLimpio = String(codigo || '').trim().toUpperCase();
  if (!/^CV[0-9A-F]{12}$/.test(codigoLimpio)) return { ok: false as const, status: 404, error: 'Link no válido' };
  const { data: colegio, error } = await supabase.from('colegios').select('id, nombre, porcentaje_participacion').eq('codigo_convenio', codigoLimpio).maybeSingle();
  if (error || !colegio) return { ok: false as const, status: 404, error: 'Link no válido' };
  return { ok: true as const, supabase, colegio };
}

rutas.get('/api/convenio/:codigo', limitarFrecuencia('convenio-get', 60, 10 * 60 * 1000), async (req: Request, res: Response) => {
  const resultado = await resolverColegioPorCodigoConvenio(String(req.params.codigo));
  if (!resultado.ok) return res.status(resultado.status).json({ success: false, error: resultado.error });
  const { data: ultimo } = await resultado.supabase
    .from('convenios_colegios')
    .select('created_at, firmante_nombre, firmante_cargo')
    .eq('colegio_id', resultado.colegio.id)
    .order('created_at', { ascending: false })
    .limit(1);
  const firmado = ultimo?.[0] ? { fecha: ultimo[0].created_at, firmante: `${ultimo[0].firmante_nombre} (${ultimo[0].firmante_cargo})` } : null;
  return res.json({
    success: true,
    colegioNombre: resultado.colegio.nombre,
    porcentaje: formatearPorcentaje((resultado.colegio as any).porcentaje_participacion ?? 30),
    preciosLaboratorio: await preciosLaboratorioParaConvenio(resultado.supabase),
    version: VERSION_CONVENIO_SERVIDOR,
    firmado,
  });
});

rutas.post('/api/convenio/:codigo', limitarFrecuencia('convenio-post', 10, 30 * 60 * 1000), async (req: Request, res: Response) => {
  try {
    const resultado = await resolverColegioPorCodigoConvenio(String(req.params.codigo));
    if (!resultado.ok) return res.status(resultado.status).json({ success: false, error: resultado.error });
    const { supabase, colegio } = resultado;
    const b = req.body || {};
    const acotar = (v: unknown, max: number) => String(v ?? '').trim().slice(0, max);
    const datos = {
      razonSocial: acotar(b.razonSocial, 200),
      cuit: acotar(b.cuit, 20),
      domicilio: acotar(b.domicilio, 300),
      email: acotar(b.email, 200).toLowerCase(),
      firmanteNombre: acotar(b.firmanteNombre, 200),
      firmanteDni: acotar(b.firmanteDni, 20).replace(/\D/g, ''),
      firmanteCargo: acotar(b.firmanteCargo, 120),
    };
    if (b.version !== VERSION_CONVENIO_SERVIDOR) return res.status(409).json({ success: false, error: 'El convenio se actualizó. Recargá la página y volvé a completarlo.' });
    if (!datos.razonSocial || !datos.domicilio || !datos.firmanteNombre || !datos.firmanteCargo) return res.status(400).json({ success: false, error: 'Completá todos los datos del colegio y de quien firma.' });
    if (datos.cuit.replace(/\D/g, '').length !== 11) return res.status(400).json({ success: false, error: 'El CUIT del colegio debe tener 11 números.' });
    if (datos.firmanteDni.length < 6 || datos.firmanteDni.length > 9) return res.status(400).json({ success: false, error: 'El DNI de quien firma no es válido.' });
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(datos.email)) return res.status(400).json({ success: false, error: 'Ingresá un email válido del colegio.' });
    if (b.aceptaFacultades !== true || b.aceptaConvenio !== true) return res.status(400).json({ success: false, error: 'Tildá las dos casillas de aceptación antes de firmar.' });

    const sinRestricciones = b.sinRestricciones === true;
    const alumnos = (Array.isArray(b.alumnosRestringidos) ? b.alumnosRestringidos : [])
      .slice(0, 300)
      .map((a: any) => ({
        alumno: acotar(a?.alumno, 200),
        curso: acotar(a?.curso, 120),
        noFotografiar: a?.noFotografiar === true,
        excluirGrupales: a?.excluirGrupales === true,
        motivo: acotar(a?.motivo, 300),
      }))
      .filter((a: any) => a.alumno);
    if (!sinRestricciones && alumnos.length === 0) {
      return res.status(400).json({ success: false, error: 'En el Anexo III cargá los alumnos que no deben ser fotografiados, o tildá "No hay alumnos con restricciones".' });
    }
    const textoFirmado = acotar(b.textoFirmado, 100000);
    if (textoFirmado.length < 2000) return res.status(400).json({ success: false, error: 'No pudimos leer el texto del convenio. Recargá la página e intentá de nuevo.' });
    // El texto aceptado tiene que mostrar el porcentaje vigente del colegio (cláusula OCTAVA BIS).
    const porcentajeColegio = Number((colegio as any).porcentaje_participacion ?? 30);
    if (!textoFirmado.includes('OCTAVA BIS') || !textoFirmado.includes(`${formatearPorcentaje(porcentajeColegio)}%`)) {
      return res.status(409).json({ success: false, error: 'El convenio se actualizó. Recargá la página y volvé a completarlo.' });
    }
    const preciosLaboratorio = await preciosLaboratorioParaConvenio(supabase);
    if (!preciosLaboratorio) return res.status(409).json({ success: false, error: 'Este convenio todavía no está listo para firmar: faltan los precios del Anexo IV. Avisale a Retrato Escolar.' });
    if (!textoFirmado.includes('gastos de operación de la plataforma')) return res.status(409).json({ success: false, error: 'El convenio se actualizó. Recargá la página y volvé a completarlo.' });
    if (!textoFirmado.includes('ANEXO IV')) return res.status(409).json({ success: false, error: 'El convenio se actualizó. Recargá la página y volvé a completarlo.' });
    const hash = crypto.createHash('sha256').update(textoFirmado).digest('hex');

    const { data: fila, error } = await supabase
      .from('convenios_colegios')
      .insert({
        colegio_id: colegio.id,
        version: VERSION_CONVENIO_SERVIDOR,
        porcentaje_participacion: porcentajeColegio,
        precios_laboratorio: preciosLaboratorio,
        gastos_plataforma_tope_pct: TOPE_GASTOS_PLATAFORMA_PCT,
        razon_social: datos.razonSocial,
        cuit: datos.cuit,
        domicilio: datos.domicilio,
        email: datos.email,
        firmante_nombre: datos.firmanteNombre,
        firmante_dni: datos.firmanteDni,
        firmante_cargo: datos.firmanteCargo,
        sin_restricciones: sinRestricciones,
        alumnos_restringidos: alumnos,
        texto_firmado: textoFirmado,
        hash_texto: hash,
        ip: ipDelCliente(req),
        user_agent: acotar(req.headers['user-agent'], 300) || null,
      })
      .select('id, created_at')
      .single();
    if (error) throw error;

    const fecha = new Date(fila.created_at).toLocaleString('es-AR', { timeZone: 'America/Argentina/Buenos_Aires' });
    const comprobante = String(fila.id).slice(0, 8).toUpperCase();
    const tablaAlumnos = sinRestricciones
      ? '<p><strong>Anexo III:</strong> sin alumnos con restricciones.</p>'
      : `<p><strong>Anexo III — alumnos que no deben ser fotografiados:</strong></p><ul>${alumnos
          .map((a: any) => `<li>${escapeHtml(a.alumno)} · ${escapeHtml(a.curso)} · ${a.noFotografiar ? 'No fotografiar' : ''}${a.noFotografiar && a.excluirGrupales ? ' / ' : ''}${a.excluirGrupales ? 'Excluir de grupales' : ''}${a.motivo ? ` · ${escapeHtml(a.motivo)}` : ''}</li>`)
          .join('')}</ul>`;
    const html = `<div style="font-family:Arial,sans-serif;max-width:700px;margin:auto;color:#0f172a"><h2>Convenio de fotografía escolar firmado</h2><p><strong>${escapeHtml(datos.razonSocial)}</strong> (${escapeHtml(colegio.nombre)}) aceptó el convenio con Retrato Escolar el ${escapeHtml(fecha)}.</p><p>Firmó: ${escapeHtml(datos.firmanteNombre)}, DNI ${escapeHtml(datos.firmanteDni)}, ${escapeHtml(datos.firmanteCargo)}.<br>Comprobante: ${escapeHtml(comprobante)} · Huella del texto (SHA-256): <span style="font-family:monospace;font-size:11px">${hash}</span></p>${tablaAlumnos}<p>Texto completo aceptado:</p><pre style="white-space:pre-wrap;font-size:11px;background:#f8fafc;padding:12px;border-radius:8px">${escapeHtml(textoFirmado)}</pre></div>`;
    const resend = getResendClient();
    if (resend) {
      const envio = await resend.emails.send({
        from: process.env.RESEND_FROM_EMAIL || 'Retrato Escolar <fotos@retratoescolar.com.ar>',
        to: [datos.email],
        bcc: [casillaAvisosAdmin()],
        replyTo: 'contacto@retratoescolar.com.ar',
        subject: `Convenio de fotografía escolar firmado — ${colegio.nombre}`,
        html,
      });
      if (envio.error) console.error('[Convenio] No se pudo enviar la copia por email:', envio.error);
    }
    return res.status(201).json({ success: true, comprobante, fecha: fila.created_at, hash });
  } catch (err: any) {
    console.error('[Convenio] Error al guardar el convenio firmado:', err);
    return res.status(500).json({ success: false, error: 'No pudimos guardar el convenio. Intentá de nuevo en unos minutos.' });
  }
});

// ==============================================================================
// LIQUIDACIÓN AL COLEGIO (pedido de Pablo 1/10)
// El colegio recibe un % de la GANANCIA NETA de las ventas a sus familias (cláusula OCTAVA BIS del
// convenio). Ganancia neta de cada pedido pagado (no cancelado ni devuelto) = lo cobrado
//   − impresión del laboratorio (precio fijo por carpeta y por copia, tabla costos_liquidacion)
//   − comisión del medio de cobro (% por medio: Mercado Pago, Nave; transferencia/efectivo 0)
//   − impuestos sobre la venta (% configurable, p. ej. IIBB).
// Se liquida una vez, al cerrar la temporada del colegio. El porcentaje es el del convenio
// firmado (si hay) o el del colegio.
// ==============================================================================
const COSTOS_LIQUIDACION_DEFECTO = {
  costo_carpeta: 0,
  costo_foto_20x30: 0,
  costo_foto_15x21: 0,
  comision_mercadopago_pct: 0,
  comision_nave_pct: 0,
  impuestos_pct: 0,
};
const CAMPOS_COSTOS_LIQUIDACION = Object.keys(COSTOS_LIQUIDACION_DEFECTO) as (keyof typeof COSTOS_LIQUIDACION_DEFECTO)[];

async function leerCostosLiquidacion(supabase: SupabaseClient) {
  const { data } = await supabase.from('costos_liquidacion').select('*').eq('id', 1).maybeSingle();
  const costos: Record<string, number> = { ...COSTOS_LIQUIDACION_DEFECTO };
  for (const campo of CAMPOS_COSTOS_LIQUIDACION) if (data && data[campo] !== null && data[campo] !== undefined) costos[campo] = Number(data[campo]) || 0;
  return { costos: costos as typeof COSTOS_LIQUIDACION_DEFECTO, actualizado: data?.updated_at || null };
}

rutas.get('/api/admin/liquidacion/costos', requireAdminAuth, async (_req: Request, res: Response) => {
  const supabase = getServerSupabase();
  if (!supabase) return res.status(500).json({ success: false, error: 'Supabase no configurado' });
  return res.json({ success: true, ...(await leerCostosLiquidacion(supabase)) });
});

rutas.post('/api/admin/liquidacion/costos', requireAdminAuth, async (req: Request, res: Response) => {
  const supabase = getServerSupabase();
  if (!supabase) return res.status(500).json({ success: false, error: 'Supabase no configurado' });
  const fila: Record<string, any> = { id: 1, updated_at: new Date().toISOString() };
  for (const campo of CAMPOS_COSTOS_LIQUIDACION) {
    const valor = Number(String(req.body?.[campo] ?? '').replace(',', '.'));
    const tope = campo.endsWith('_pct') ? 100 : 10_000_000;
    if (!Number.isFinite(valor) || valor < 0 || valor > tope) return res.status(400).json({ success: false, error: `Valor inválido en "${campo}".` });
    fila[campo] = Math.round(valor * 100) / 100;
  }
  const { error } = await supabase.from('costos_liquidacion').upsert(fila);
  if (error) return res.status(500).json({ success: false, error: 'No se pudieron guardar los costos.' });
  return res.json({ success: true, ...(await leerCostosLiquidacion(supabase)) });
});

rutas.post('/api/admin/colegios/:id/porcentaje', requireAdminAuth, async (req: Request, res: Response) => {
  const supabase = getServerSupabase();
  if (!supabase) return res.status(500).json({ success: false, error: 'Supabase no configurado' });
  const porcentaje = Number(String(req.body?.porcentaje ?? '').replace(',', '.'));
  if (!Number.isFinite(porcentaje) || porcentaje < 0 || porcentaje > 100) return res.status(400).json({ success: false, error: 'El porcentaje tiene que estar entre 0 y 100.' });
  const { error } = await supabase.from('colegios').update({ porcentaje_participacion: Math.round(porcentaje * 100) / 100 }).eq('id', req.params.id);
  if (error) return res.status(500).json({ success: false, error: 'No se pudo guardar el porcentaje.' });
  return res.json({ success: true });
});

// Período de una liquidación (convenio OCTAVA BIS b): por fecha de COBRO, en hora argentina.
// desde/hasta = AAAA-MM-DD, ambos inclusive; por defecto, el año en curso (1/1 al 31/12).
export function periodoLiquidacion(desdeTexto: unknown, hastaTexto: unknown) {
  const formato = /^\d{4}-\d{2}-\d{2}$/;
  const anio = Number(new Date().toLocaleString('en-CA', { timeZone: 'America/Argentina/Buenos_Aires', year: 'numeric' }));
  const desde = formato.test(String(desdeTexto || '')) ? String(desdeTexto) : `${anio}-01-01`;
  const hasta = formato.test(String(hastaTexto || '')) ? String(hastaTexto) : `${anio}-12-31`;
  const inicio = new Date(`${desde}T00:00:00-03:00`);
  const fin = new Date(new Date(`${hasta}T00:00:00-03:00`).getTime() + 24 * 60 * 60 * 1000);
  if (Number.isNaN(inicio.getTime()) || Number.isNaN(fin.getTime()) || fin <= inicio) return null;
  return { desde, hasta, inicioISO: inicio.toISOString(), finISO: fin.toISOString() };
}

rutas.post('/api/admin/liquidacion/actualizar-comisiones', requireAdminAuth, async (req: Request, res: Response) => {
  // Busca en Mercado Pago / Nave la comisión real de los pagos del colegio en el período que
  // todavía no la tienen. Procesa de a tandas (límite de tiempo de Vercel): el panel repite la
  // llamada mientras queden pendientes.
  try {
    const supabase = getServerSupabase();
    if (!supabase) return res.status(500).json({ success: false, error: 'Supabase no configurado' });
    const periodo = periodoLiquidacion(req.body?.desde, req.body?.hasta);
    if (!periodo) return res.status(400).json({ success: false, error: 'Período inválido.' });
    const colegioId = String(req.body?.colegioId || '');
    const reintentarDesde = new Date(Date.now() - 12 * 60 * 60 * 1000).toISOString();
    const pendientesQuery = () =>
      supabase
        .from('pedidos')
        .select('id, mp_payment_id, nave_payment_id', { count: 'exact' })
        .eq('colegio_id', colegioId)
        .in('estado', ['pagado', 'entregado'])
        .gte('pagado_at', periodo.inicioISO)
        .lt('pagado_at', periodo.finISO)
        .or('mp_payment_id.not.is.null,nave_payment_id.not.is.null')
        .or(`comision_origen.is.null,and(comision_origen.in.(sin_dato,error),comision_actualizada_at.lt."${reintentarDesde}")`);
    const { data: pendientes, error } = await pendientesQuery().order('comision_actualizada_at', { ascending: true, nullsFirst: true }).order('id').limit(60);
    if (error) throw error;
    const pagos = new Map<string, 'mp_payment_id' | 'nave_payment_id'>();
    for (const p of pendientes || []) {
      if (p.mp_payment_id) pagos.set(String(p.mp_payment_id), 'mp_payment_id');
      else if (p.nave_payment_id) pagos.set(String(p.nave_payment_id), 'nave_payment_id');
    }
    const limite = Date.now() + 20_000;
    const resultado = { real: 0, sinDato: 0, errores: 0 };
    for (const [idPago, columna] of pagos) {
      if (Date.now() > limite) break;
      const r = await registrarComisionDePago(supabase, columna, idPago);
      if (r === 'real') resultado.real++;
      else if (r === 'sin_dato') resultado.sinDato++;
      else resultado.errores++;
    }
    const { count } = await pendientesQuery().limit(1);
    // Los que dieron error quedan marcados y no vuelven hasta dentro de 12 h, así que el conteo baja.
    return res.json({ success: true, ...resultado, pendientes: count || 0 });
  } catch (err: any) {
    console.error('[Liquidación] Error al actualizar comisiones:', err);
    return res.status(500).json({ success: false, error: 'No se pudieron actualizar las comisiones.' });
  }
});

rutas.get('/api/admin/liquidacion', requireAdminAuth, async (req: Request, res: Response) => {
  try {
    const supabase = getServerSupabase();
    if (!supabase) return res.status(500).json({ success: false, error: 'Supabase no configurado' });
    const periodo = periodoLiquidacion(req.query.desde, req.query.hasta);
    if (!periodo) return res.status(400).json({ success: false, error: 'Período inválido.' });
    const liquidacion = await calcularLiquidacionColegio(supabase, String(req.query.colegioId || ''), periodo);
    if (!liquidacion) return res.status(404).json({ success: false, error: 'Colegio no encontrado.' });
    return res.json({ success: true, ...liquidacion });
  } catch (err: any) {
    console.error('[Liquidación] Error:', err);
    return res.status(500).json({ success: false, error: 'No se pudo calcular la liquidación.' });
  }
});

/**
 * Liquidación de un colegio en un período (cláusula OCTAVA BIS del convenio). 10/10: sale de la ruta
 * /api/admin/liquidacion para que el panel del colegio (servidor/colegio/panelColegio.ts) use EXACTAMENTE
 * la misma cuenta. El cálculo no cambió: es el mismo código, ahora en una función. null = el colegio no existe.
 */
export async function calcularLiquidacionColegio(supabase: SupabaseClient, colegioId: string, periodo: NonNullable<ReturnType<typeof periodoLiquidacion>>) {
    const { data: colegio } = await supabase.from('colegios').select('id, nombre, porcentaje_participacion').eq('id', colegioId).maybeSingle();
    if (!colegio) return null;
    const { data: convenio } = await supabase
      .from('convenios_colegios')
      .select('created_at, porcentaje_participacion, razon_social, precios_laboratorio, gastos_plataforma_tope_pct')
      .eq('colegio_id', colegio.id)
      .order('created_at', { ascending: false })
      .limit(1)
      .maybeSingle();
    const porcentaje = Number(convenio?.porcentaje_participacion ?? colegio.porcentaje_participacion ?? 30);
    const { costos: costosVigentes } = await leerCostosLiquidacion(supabase);
    // Tope del Anexo IV: si el convenio firmado fijó precios de impresión, nunca se descuenta más.
    const tope = (convenio as any)?.precios_laboratorio || null;
    const costos = { ...costosVigentes };
    if (tope) {
      for (const c of CAMPOS_PRECIOS_LABORATORIO) {
        const maximo = Number(tope[c]);
        if (Number.isFinite(maximo) && maximo >= 0) costos[c] = Math.min(costos[c], maximo);
      }
    }
    const pedidos = await traerTodasLasFilas<any>((desde, hasta) =>
      supabase
        .from('pedidos')
        .select('id, pedido_friendly_id, created_at, pagado_at, alumno_nombre, grado, division, turno, kit_nombre, tipo_kit, total, metodo_pago, estado, carpetas_impresas, copias_extras, fotos_seleccionadas, seleccion_pendiente, mejora_de_pedido_id, extras_de_pedido_id, mp_payment_id, nave_payment_id, comision_cobro, retenciones_cobro, comision_origen, aprobado_manual_at')
        .eq('colegio_id', colegio.id)
        .in('estado', ['pagado', 'entregado'])
        .gte('pagado_at', periodo.inicioISO)
        .lt('pagado_at', periodo.finISO)
        .order('pagado_at')
        .order('id')
        .range(desde, hasta)
    );
    const redondear = (n: number) => Math.round(n * 100) / 100;
    // 22/10 (Pablo): un pedido sin cargo por código de descuento («bonificado») no suma ni resta al colegio.
    const filas = (pedidos || []).filter((p: any) => p.metodo_pago !== 'bonificado').map((p: any) => {
      const venta = Number(p.total) || 0;
      // 29/10/2026: las fotos extra no tienen carpeta pero sí copias impresas (costo del laboratorio).
      const impreso = (Number(p.carpetas_impresas) || 0) > 0 || esPedidoFotosExtra(p);
      const imp = impreso ? contarImpresionesPedido(p) : { carpetas: 0, fotos20x30: 0, fotos15x21: 0, sueltas: 0 };
      const costoLaboratorio = imp.carpetas * costos.costo_carpeta + imp.fotos20x30 * costos.costo_foto_20x30 + imp.fotos15x21 * costos.costo_foto_15x21;
      const pctComision = p.metodo_pago === 'mercadopago' ? costos.comision_mercadopago_pct : p.metodo_pago === 'nave' ? costos.comision_nave_pct : 0;
      // Comisión real informada por la pasarela si la hay; si no, estimada con el %.
      const comisionReal = p.comision_origen === 'real' && p.comision_cobro !== null && p.comision_cobro !== undefined;
      // Auditoría 11/10: aprobado a mano sin id de pago = no pasó por la pasarela (efectivo/transferencia):
      // sin comisión. Antes una mejora a impreso (siempre 'mercadopago') cobrada en efectivo pagaba comisión.
      const tienePasarela = Boolean(p.mp_payment_id || p.nave_payment_id) || (!p.aprobado_manual_at && (p.metodo_pago === 'mercadopago' || p.metodo_pago === 'nave'));
      const comision = comisionReal ? Number(p.comision_cobro) || 0 : tienePasarela ? (venta * pctComision) / 100 : 0;
      const impuestos = (venta * costos.impuestos_pct) / 100;
      const ganancia = venta - costoLaboratorio - comision - impuestos;
      return {
        pedido: p.pedido_friendly_id || String(p.id).slice(0, 8),
        fecha: p.created_at,
        pagado: p.pagado_at,
        comisionOrigen: comisionReal ? 'real' : tienePasarela ? 'estimada' : 'sin_comision',
        retencionesInformadas: comisionReal ? redondear(Number(p.retenciones_cobro) || 0) : 0,
        porActualizar: tienePasarela && !comisionReal && Boolean(p.mp_payment_id || p.nave_payment_id),
        alumno: p.alumno_nombre || '',
        curso: [p.grado, p.division, p.turno].filter(Boolean).join(' '),
        kit: p.kit_nombre || '',
        medio: p.metodo_pago || '',
        venta: redondear(venta),
        carpetas: imp.carpetas,
        fotos20x30: imp.fotos20x30,
        fotos15x21: imp.fotos15x21,
        costoLaboratorio: redondear(costoLaboratorio),
        comision: redondear(comision),
        impuestos: redondear(impuestos),
        ganancia: redondear(ganancia),
        // Reserva paga sin fotos elegidas: el costo de impresión puede cambiar cuando las elija.
        fotosPendientes: Boolean(p.seleccion_pendiente),
      };
    });
    const sumar = (k: 'venta' | 'costoLaboratorio' | 'comision' | 'impuestos' | 'ganancia') => redondear(filas.reduce((a: number, f: any) => a + f[k], 0));
    const totales = {
      pedidos: filas.length,
      venta: sumar('venta'),
      costoLaboratorio: sumar('costoLaboratorio'),
      comision: sumar('comision'),
      impuestos: sumar('impuestos'),
      ganancia: sumar('ganancia'),
      gastosPlataforma: 0,
    };
    // Punto (iv) del convenio 2026-10-30: gastos de plataforma prorrateados, sólo si el convenio firmado lo prevé.
    const gastosPlataforma = await calcularGastosPlataforma(supabase, periodo, totales.venta, (convenio as any)?.gastos_plataforma_tope_pct);
    if (gastosPlataforma) {
      totales.gastosPlataforma = gastosPlataforma.asignado;
      totales.ganancia = redondear(totales.ganancia - gastosPlataforma.asignado);
    }
    const participacion = redondear((Math.max(0, totales.ganancia) * porcentaje) / 100);
    // Resumen por medio de cobro: lo que el colegio cruza con los reportes de cada pasarela.
    const porMedio = new Map<string, any>();
    for (const f of filas as any[]) {
      const medio = f.medio || 'sin dato';
      const r = porMedio.get(medio) || { medio, pedidos: 0, cobrado: 0, comision: 0, retencionesInformadas: 0, comisionesEstimadas: 0 };
      r.pedidos++;
      r.cobrado += f.venta;
      r.comision += f.comision;
      r.retencionesInformadas += f.retencionesInformadas;
      if (f.comisionOrigen === 'estimada') r.comisionesEstimadas++;
      porMedio.set(medio, r);
    }
    const resumenPorMedio = [...porMedio.values()].map((r) => ({ ...r, cobrado: redondear(r.cobrado), comision: redondear(r.comision), retencionesInformadas: redondear(r.retencionesInformadas) }));
    return {
      colegio: { id: colegio.id, nombre: colegio.nombre },
      porcentaje,
      porcentajeDelConvenio: Boolean(convenio),
      convenioFirmado: convenio ? { fecha: convenio.created_at, razonSocial: convenio.razon_social } : null,
      costos,
      topesAnexoIV: tope,
      gastosPlataforma,
      periodo: { desde: periodo.desde, hasta: periodo.hasta },
      filas,
      totales,
      resumenPorMedio,
      participacion,
      comisionesEstimadas: (filas as any[]).filter((f) => f.comisionOrigen === 'estimada').length,
      comisionesPorActualizar: (filas as any[]).filter((f) => f.porActualizar).length,
      pedidosConFotosPendientes: filas.filter((f: any) => f.fotosPendientes).length,
    };
}

/**
 * Gastos de plataforma que le tocan a un colegio en el período (convenio 2026-10-30, OCTAVA BIS punto iv):
 * total pagado en el período × (lo cobrado al colegio / lo cobrado por toda la plataforma), con tope
 * del % firmado sobre lo cobrado al colegio. null = el convenio firmado no prevé este descuento.
 */
async function calcularGastosPlataforma(
  supabase: SupabaseClient,
  periodo: NonNullable<ReturnType<typeof periodoLiquidacion>>,
  ventaColegio: number,
  topePctFirmado: unknown,
) {
  const topePct = Number(topePctFirmado);
  if (topePctFirmado === null || topePctFirmado === undefined || !Number.isFinite(topePct) || topePct <= 0) return null;
  const redondear = (n: number) => Math.round(n * 100) / 100;
  const { data: gastos } = await supabase
    .from('gastos_plataforma')
    .select('monto')
    .gte('fecha', periodo.desde)
    .lte('fecha', periodo.hasta);
  const gastosPeriodo = redondear((gastos || []).reduce((a: number, g: any) => a + (Number(g.monto) || 0), 0));
  // Lo cobrado por toda la plataforma en el período, con el mismo criterio que la liquidación
  // (pedidos pagados o entregados, sin los bonificados).
  const ventas = await traerTodasLasFilas<any>((desde, hasta) =>
    supabase
      .from('pedidos')
      .select('id, total, metodo_pago')
      .in('estado', ['pagado', 'entregado'])
      .gte('pagado_at', periodo.inicioISO)
      .lt('pagado_at', periodo.finISO)
      .order('id')
      .range(desde, hasta)
  );
  const ventasPlataforma = redondear((ventas || []).filter((p: any) => p.metodo_pago !== 'bonificado').reduce((a: number, p: any) => a + (Number(p.total) || 0), 0));
  const proporcion = ventasPlataforma > 0 ? Math.min(1, Math.max(0, ventaColegio / ventasPlataforma)) : 0;
  const prorrateado = redondear(gastosPeriodo * proporcion);
  const tope = redondear((Math.max(0, ventaColegio) * topePct) / 100);
  return {
    gastosPeriodo,
    ventasPlataforma,
    proporcion: Math.round(proporcion * 10_000) / 10_000,
    prorrateado,
    topePct,
    tope,
    asignado: Math.min(prorrateado, tope),
    topeAplicado: prorrateado > tope,
  };
}

// ==============================================================================
// GASTOS DE PLATAFORMA (convenio 2026-10-30): los carga Pablo en el panel, en pesos.
// ==============================================================================
rutas.get('/api/admin/liquidacion/gastos-plataforma', requireAdminAuth, async (req: Request, res: Response) => {
  const supabase = getServerSupabase();
  if (!supabase) return res.status(500).json({ success: false, error: 'Supabase no configurado' });
  const periodo = periodoLiquidacion(req.query.desde, req.query.hasta);
  if (!periodo) return res.status(400).json({ success: false, error: 'Período inválido.' });
  const { data, error } = await supabase
    .from('gastos_plataforma')
    .select('id, fecha, concepto, monto, moneda_original, monto_original, comprobante')
    .gte('fecha', periodo.desde)
    .lte('fecha', periodo.hasta)
    .order('fecha', { ascending: false });
  if (error) return res.status(500).json({ success: false, error: 'No se pudieron leer los gastos.' });
  return res.json({ success: true, gastos: data || [] });
});

rutas.post('/api/admin/liquidacion/gastos-plataforma', requireAdminAuth, async (req: Request, res: Response) => {
  const supabase = getServerSupabase();
  if (!supabase) return res.status(500).json({ success: false, error: 'Supabase no configurado' });
  const b = req.body || {};
  const fecha = String(b.fecha || '');
  const concepto = String(b.concepto || '').trim().slice(0, 120);
  const monto = Number(String(b.monto ?? '').replace(',', '.'));
  const moneda = b.monedaOriginal === 'USD' ? 'USD' : b.monedaOriginal === 'ARS' ? 'ARS' : null;
  const montoOriginal = b.montoOriginal === '' || b.montoOriginal === undefined || b.montoOriginal === null ? null : Number(String(b.montoOriginal).replace(',', '.'));
  if (!/^\d{4}-\d{2}-\d{2}$/.test(fecha)) return res.status(400).json({ success: false, error: 'Fecha inválida.' });
  if (concepto.length < 2) return res.status(400).json({ success: false, error: 'Escribí el concepto (ej. Vercel, Supabase, IA).' });
  if (!Number.isFinite(monto) || monto <= 0 || monto > 100_000_000) return res.status(400).json({ success: false, error: 'Monto en pesos inválido.' });
  if (montoOriginal !== null && (!Number.isFinite(montoOriginal) || montoOriginal <= 0)) return res.status(400).json({ success: false, error: 'Monto original inválido.' });
  const { error } = await supabase.from('gastos_plataforma').insert({
    fecha,
    concepto,
    monto: Math.round(monto * 100) / 100,
    moneda_original: moneda,
    monto_original: montoOriginal,
    comprobante: String(b.comprobante || '').trim().slice(0, 120) || null,
  });
  if (error) return res.status(500).json({ success: false, error: 'No se pudo guardar el gasto.' });
  return res.json({ success: true });
});

rutas.delete('/api/admin/liquidacion/gastos-plataforma/:id', requireAdminAuth, async (req: Request, res: Response) => {
  const supabase = getServerSupabase();
  if (!supabase) return res.status(500).json({ success: false, error: 'Supabase no configurado' });
  const id = String(req.params.id || '');
  if (!/^[0-9a-f-]{36}$/i.test(id)) return res.status(400).json({ success: false, error: 'Gasto inválido.' });
  const { error } = await supabase.from('gastos_plataforma').delete().eq('id', id);
  if (error) return res.status(500).json({ success: false, error: 'No se pudo borrar el gasto.' });
  return res.json({ success: true });
});

export { rutas as rutasConvenioLiquidacion };
