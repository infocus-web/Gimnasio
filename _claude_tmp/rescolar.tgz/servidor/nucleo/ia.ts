// IA para los borradores (y las respuestas automáticas seguras) de las consultas de familias: Claude
// (Anthropic). 13/10/2026 (Pablo pagó la API de Anthropic: «eliminá gemini y respondé vos todo»): se sacó
// Gemini (plan gratis, 20 pedidos por día, caídas por «high demand»); la única clave es ANTHROPIC_API_KEY.
import './entorno.js';

export function iaConfigurada(): boolean {
  return Boolean(process.env.ANTHROPIC_API_KEY?.trim());
}

export const ERROR_IA_NO_CONFIGURADA = 'La IA no está configurada (falta ANTHROPIC_API_KEY en el servidor).';

// 13/10/2026 (pedido de Pablo: que las consultas las conteste Claude): el modelo por defecto era
// 'claude-sonnet-5', que no es un ID de la API. Sonnet 5.5 piensa antes de responder y ese
// razonamiento cuenta dentro de max_tokens: con el tope viejo (1200) el JSON podía quedar cortado.
// `esfuerzo` (output_config.effort de la API): 'low' para lo automático (el webhook de correo espera
// ~12 s) y 'medium' cuando lo pide Pablo desde el panel.
export const MODELO_CLAUDE_POR_DEFECTO = 'claude-sonnet-5-5';

// 13/10/2026: «saturada» = la IA está sobrecargada o frenando por demanda (Claude 429/529 «Overloaded»).
// Es pasajero: el panel lo muestra como aviso («probá en unos minutos») y no como error.
export const AVISO_IA_SATURADA = 'La IA está saturada en este momento (mucha demanda). Probá de nuevo en unos minutos o escribí la respuesta a mano.';
export function esIaSaturada(err: any): boolean {
  const estado = Number(err?.status || err?.code || 0);
  return [429, 502, 503, 504, 529].includes(estado) || /overloaded|high demand|UNAVAILABLE|RESOURCE_EXHAUSTED/i.test(String(err?.message || ''));
}

export async function generarTextoIA(params: { sistema: string; prompt: string; json?: boolean; maxTokens?: number; esfuerzo?: 'low' | 'medium' }): Promise<string> {
  const claveAnthropic = process.env.ANTHROPIC_API_KEY?.trim();
  if (claveAnthropic) {
    const res = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: { 'content-type': 'application/json', 'x-api-key': claveAnthropic, 'anthropic-version': '2023-06-01' },
      body: JSON.stringify({
        model: process.env.ANTHROPIC_MODEL?.trim() || MODELO_CLAUDE_POR_DEFECTO,
        max_tokens: params.maxTokens || 6000,
        output_config: { effort: params.esfuerzo || 'low' },
        // El contexto del negocio es largo y se repite en cada consulta: se cachea para que las
        // consultas seguidas cuesten ~90% menos.
        system: [{ type: 'text', text: params.sistema, cache_control: { type: 'ephemeral' } }],
        messages: [{ role: 'user', content: params.json ? `${params.prompt}\n\nRespondé únicamente con el JSON, sin texto antes ni después.` : params.prompt }],
      }),
    });
    const data: any = await res.json().catch(() => null);
    if (!res.ok) throw Object.assign(new Error(`Claude respondió ${res.status}: ${data?.error?.message || 'sin detalle'}`), { status: res.status });
    if (data?.stop_reason === 'max_tokens') throw new Error('La respuesta de Claude quedó cortada (se alcanzó el máximo de texto). Probá de nuevo o respondé a mano.');
    return (Array.isArray(data?.content) ? data.content : [])
      .filter((b: any) => b?.type === 'text')
      .map((b: any) => String(b.text))
      .join('')
      .trim();
  }
  throw new Error(ERROR_IA_NO_CONFIGURADA);
}
