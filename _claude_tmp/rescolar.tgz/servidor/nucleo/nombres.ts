// Comparación de nombres de alumnos ("García, María José" contra "maria jose garcia") y etiquetas de
// las fotos individuales que corresponden a cada hijo (división de server.ts, etapa 5, 10/10/2026). Lo
// usan la galería, la inscripción y las compras. El código es el mismo que estaba en server.ts.
import { normalizarNombreComparable, normalizarNombrePorPalabras } from './utilidades.js';

// Auditoría 2026-09-26 (M5 + M6): la selección de fotos se valida al registrar el pedido. Antes se
// guardaba tal cual la mandaba el navegador: ids inexistentes, de otro curso, de otra categoría o
// incompletos se cobraban igual y después el .zip HD fallaba (o salía incompleto) y el control
// automático lo reintentaba para siempre. Además, una foto INDIVIDUAL etiquetada con el nombre de
// un alumno sólo la puede comprar la familia de ese alumno (M6). Debe coincidir con
// src/utils/nombresAlumno.ts.
/**
 * Auditoría 03/10 noche (A3): cuántas palabras de más tiene el nombre más largo respecto del más
 * corto (0 = mismo nombre), o null si no son compatibles. Compatibles = todas las palabras del
 * nombre más corto (2 como mínimo) están en el más largo.
 */
function puntajeNombres(a: unknown, b: unknown): number | null {
  const palabras = (n: unknown) => Array.from(new Set(normalizarNombreComparable(n).split(' ').filter(Boolean)));
  const pa = palabras(a);
  const pb = palabras(b);
  if (pa.length === 0 || pb.length === 0) return null;
  const [corto, largoLista] = pa.length <= pb.length ? [pa, pb] : [pb, pa];
  const largo = new Set(largoLista);
  // Auditoría 30/9: con una sola palabra ("Juan") coincidía con todos los "Juan …" del curso.
  if (corto.length < 2) return null;
  if (!corto.every((p) => largo.has(p))) return null;
  return largoLista.length - corto.length;
}

export function nombresCompatibles(a: unknown, b: unknown): boolean {
  return puntajeNombres(a, b) !== null;
}

/**
 * Auditoría 03/10 noche (A3): de las etiquetas de fotos individuales de un curso, cuáles son del
 * alumno `nombre`. Antes alcanzaba con que fueran "compatibles" (subconjunto de palabras), así que
 * una familia anotada como "Juan Pérez" veía también las fotos de "Juan Ignacio Pérez", y un nombre
 * larguísimo coincidía con muchos chicos. Ahora sólo cuentan las etiquetas que MEJOR coinciden (las
 * de menos palabras de diferencia): si en el curso está "Juan Pérez", "Juan Ignacio Pérez" queda
 * afuera. Devuelve claves normalizadas (normalizarNombrePorPalabras).
 */
// Auditoría 11/10 (FAM-1): la etiqueta tiene que CONTENER todas las palabras del nombre inscripto (al revés sólo
// con UNA palabra de más: un nombre inscripto largo empataba con varios compañeros), y si al mejor puntaje > 0 empatan
// etiquetas distintas ("María García" ante "María Sol García" y "María Laura García") es ambiguo: ninguna.
// Debe coincidir con etiquetasDelAlumno de src/utils/nombresAlumno.ts.
// Revisión 11/10: etiqueta ⊇ nombre (la nómina suele tener segundo nombre) o, como mucho UNA palabra de más
// en lo que escribió la familia (segundo nombre/apellido que la nómina no tiene); sin contar partículas.
function puntajeEtiqueta(delNombre: string[], deLaEtiqueta: string[]): number | null {
  const et = new Set(deLaEtiqueta);
  if (delNombre.every((p) => et.has(p))) return et.size - delNombre.length;
  const nom = new Set(delNombre);
  if (et.size >= 2 && deLaEtiqueta.every((p) => nom.has(p)) && nom.size - et.size === 1) return 1;
  return null;
}

export function etiquetasDelAlumno(nombre: unknown, etiquetas: unknown[]): Set<string> {
  const palabrasSin = (n: unknown) => Array.from(new Set(normalizarNombreComparable(n).split(' ').filter((p) => p && !PARTICULAS_NOMBRE.has(p))));
  const delNombre = palabrasSin(nombre);
  let mejor = Infinity;
  const elegidas = new Set<string>();
  if (delNombre.length < 2) return elegidas;
  const vistas = new Set<string>();
  for (const etiqueta of etiquetas) {
    const clave = normalizarNombrePorPalabras(etiqueta);
    if (!clave || vistas.has(clave)) continue;
    vistas.add(clave);
    const puntaje = puntajeEtiqueta(delNombre, palabrasSin(etiqueta));
    if (puntaje === null) continue;
    if (puntaje < mejor) {
      mejor = puntaje;
      elegidas.clear();
    }
    if (puntaje === mejor) elegidas.add(clave);
  }
  return mejor > 0 && elegidas.size > 1 ? new Set<string>() : elegidas;
}

// 10/10/2026 (pedido de Pablo, probando la inscripción: escribió «PABLITA Alderete»): los nombres que
// escribe la familia se guardan con mayúscula inicial. Sólo se corrigen las palabras escritas TODAS en
// mayúsculas o TODAS en minúsculas; una palabra con mezcla (McDonald, DeLuca) se respeta. Las partículas
// (de, del, la, los, y…) que no van primero quedan en minúscula: «MARÍA DE LOS ÁNGELES» → «María de los
// Ángeles». También después de guion o apóstrofo: «maría-josé d'angelo» → «María-José D'Angelo».
// Debe coincidir con nombrePropio de src/utils/nombresAlumno.ts / servidor/nucleo/nombres.ts.
const PARTICULAS_NOMBRE = new Set(['de', 'del', 'la', 'las', 'los', 'y', 'e', 'da', 'das', 'do', 'dos', 'di', 'van', 'von', 'der']);

export function nombrePropio(texto: string): string {
  return String(texto ?? '')
    .replace(/\s+/g, ' ')
    .trim()
    .split(' ')
    .map((palabra, i) => {
      const letras = palabra.replace(/[^\p{L}]/gu, '');
      if (!letras) return palabra;
      const todoMayusculas = letras === letras.toLocaleUpperCase('es');
      const todoMinusculas = letras === letras.toLocaleLowerCase('es');
      if (!todoMayusculas && !todoMinusculas) return palabra;
      const minusculas = palabra.toLocaleLowerCase('es');
      if (i > 0 && PARTICULAS_NOMBRE.has(minusculas)) return minusculas;
      return minusculas.replace(/(^|[-'’])(\p{L})/gu, (_m: string, separador: string, letra: string) => separador + letra.toLocaleUpperCase('es'));
    })
    .join(' ');
}
