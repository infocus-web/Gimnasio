// Límites de frecuencia, cupos y turnos (en memoria y en la base, sobre la rpc registrar_intento)
// (división de server.ts, etapa 1, 10/10/2026). El código es el mismo que estaba en server.ts: sólo
// se movió de lugar.
import crypto from 'crypto';
import type { NextFunction, Request, Response } from 'express';
import { casillaAvisosAdmin, getResendClient, getServerSupabase } from './clientes.js';
import { escapeHtml } from './utilidades.js';

// Límite de intentos básico, en memoria, para frenar fuerza bruta / spam en endpoints
// públicos sensibles (login de admin, búsqueda de inscripción por teléfono/email, creación
// de preferencias de pago, solicitudes de código). Auditoría 2026-09-09: hasta ahora ningún
// endpoint tenía ningún límite de frecuencia.
//
// OJO — limitación conocida: en Vercel (serverless) cada instancia puede tener su propia
// memoria, así que esto no es un límite global infalible contra un atacante distribuido;
// sí frena intentos manuales y scripts simples desde una misma conexión, que es el 90% del
// riesgo real hoy. Si en el futuro esto pasa a preocupar más, lo correcto es un store
// compartido (Redis/Upstash) en vez de memoria del proceso.
//
// Auditoría 2026-09-23 (riesgo real para el lanzamiento): los límites son POR IP, y en Argentina
// los celulares suelen salir a internet por una IP compartida del operador (CGNAT) — igual que
// todas las familias conectadas al WiFi de un colegio. Varios topes eran tan bajos que un grupo de
// familias en la misma red se bloqueaba entre sí (ej. 10 inscripciones cada 15 min, o 60 consultas
// de estado cada 10 min, que una sola pantalla de "pago pendiente" agotaba sola en 4 minutos), y el
// webhook de Nave (siempre desde las mismas IPs de Nave) podía quedar rechazado en un día de mucha
// venta. Se subieron para uso legítimo en grupo; los secretos (códigos de 8 caracteres, tokens)
// siguen siendo inviables de adivinar con estos topes.
const intentosPorClave = new Map<string, { count: number; desde: number }>();

// Preparación para la temporada (25/9, ~1300 familias en pocos días): en Argentina las compañías
// de celular sacan a cientos de clientes por la MISMA IP pública (CGNAT), igual que el WiFi de un
// colegio o una oficina. Con los topes anteriores (pensados para una IP = una persona) familias
// reales podían quedar bloqueadas en horas pico. Se subieron los topes de las consultas normales
// (galería, estado del pago, datos de la familia) y de las acciones de compra; los endpoints
// sensibles a abuso (login de admin, IA, envío de emails) mantienen topes bajos. El conteo es por
// instancia del servidor, así que en la práctica el margen es todavía mayor.
export function limitarFrecuencia(nombre: string, maxIntentos: number, ventanaMs: number) {
  return (req: Request, res: Response, next: NextFunction) => {
    const ip = req.ip || 'desconocida';
    const clave = `${nombre}:${ip}`;
    const ahora = Date.now();
    const entrada = intentosPorClave.get(clave);
    if (!entrada || ahora - entrada.desde > ventanaMs) {
      intentosPorClave.set(clave, { count: 1, desde: ahora });
      return next();
    }
    entrada.count += 1;
    if (entrada.count > maxIntentos) {
      const segundosRestantes = Math.ceil((ventanaMs - (ahora - entrada.desde)) / 1000);
      return res.status(429).json({
        success: false,
        error: `Demasiados intentos. Probá de nuevo en ${segundosRestantes} segundos.`,
      });
    }
    return next();
  };
}

// Auditoría 28/9: igual que limitarFrecuencia pero el contador vive en Supabase (tabla
// limites_intentos, función registrar_intento), así vale para todas las instancias de Vercel. Se
// usa donde importa de verdad (PIN del panel, buscador público de pedidos). Si Supabase no
// responde, cae al contador en memoria para no dejar el endpoint sin límite.
export function limitarFrecuenciaPersistente(nombre: string, maxIntentos: number, ventanaMs: number, claveFija?: string) {
  const respaldo = limitarFrecuencia(nombre, maxIntentos, ventanaMs);
  return async (req: Request, res: Response, next: NextFunction) => {
    const supabase = getServerSupabase();
    if (!supabase) return respaldo(req, res, next);
    try {
      const { data, error } = await supabase.rpc('registrar_intento', {
        // claveFija: un tope TOTAL (todas las IPs juntas), además del de cada IP.
        p_clave: claveFija ? `${nombre}:${claveFija}` : `${nombre}:${req.ip || 'desconocida'}`,
        p_max: maxIntentos,
        p_ventana_seg: Math.round(ventanaMs / 1000),
      });
      if (error) throw error;
      const segundos = Number(data) || 0;
      if (segundos > 0) {
        const minutos = Math.ceil(segundos / 60);
        return res.status(429).json({ success: false, error: `Demasiados intentos. Probá de nuevo en ${minutos} minuto${minutos === 1 ? '' : 's'}.` });
      }
      return next();
    } catch {
      return respaldo(req, res, next);
    }
  };
}

// 09/10: como limitarFrecuenciaPersistente pero SIN hacer esperar el pedido (la lupa se sentía trabada):
// el intento se anota en la base en paralelo y, si esa IP ya pasó el tope, esta instancia la frena en
// los pedidos siguientes. El conteo sigue siendo global (todas las instancias suman en la base).
export function limitarFrecuenciaPersistenteSinEspera(nombre: string, maxIntentos: number, ventanaMs: number) {
  const bloqueadasHasta = new Map<string, number>();
  return (req: Request, res: Response, next: NextFunction) => {
    const clave = `${nombre}:${req.ip || 'desconocida'}`;
    const hasta = bloqueadasHasta.get(clave);
    if (hasta && hasta > Date.now()) {
      return res.status(429).json({ success: false, error: 'Demasiados pedidos seguidos. Probá de nuevo en un rato.' });
    }
    const supabase = getServerSupabase();
    if (supabase) {
      void Promise.resolve(supabase.rpc('registrar_intento', { p_clave: clave, p_max: maxIntentos, p_ventana_seg: Math.round(ventanaMs / 1000) }))
        .then(({ data }) => {
          const segundos = Number(data) || 0;
          if (segundos > 0) {
            if (bloqueadasHasta.size > 5000) bloqueadasHasta.clear();
            bloqueadasHasta.set(clave, Date.now() + segundos * 1000);
          }
        })
        .catch(() => undefined);
    }
    return next();
  };
}

// Auditoría de seguridad 02/10: tope GLOBAL (todas las IPs juntas, todas las instancias) para lo que
// cuesta plata o reputación aunque el visitante no quede bloqueado: emails de aviso al panel y
// llamadas a la IA disparadas desde formularios públicos. Con muchas IPs (o instancias nuevas de
// Vercel, cada una con su contador en memoria) un ataque podía gastar el cupo de Resend o la cuenta
// de la IA. Si se pasa el tope, lo recibido igual queda guardado en el panel; sólo se saltea el
// email o la IA. Si la base no responde se permite (el tope en memoria de cada ruta sigue valiendo).
export async function hayCupoGlobal(clave: string, maximo: number, ventanaSeg: number): Promise<boolean> {
  const supabase = getServerSupabase();
  if (!supabase) return true;
  try {
    const { data, error } = await supabase.rpc('registrar_intento', { p_clave: `global:${clave}`, p_max: maximo, p_ventana_seg: ventanaSeg });
    if (error) throw error;
    const permitido = !(Number(data) > 0);
    if (!permitido) console.warn(`[Seguridad] Tope global alcanzado: ${clave}`);
    return permitido;
  } catch {
    return true;
  }
}

// Auditoría 03/10 (medio): el tope TOTAL del login (todas las IPs juntas) dejaba que un tercero,
// probando PINes desde muchas IPs, bloqueara el ingreso de Pablo (o del laboratorio) durante una hora.
// Ahora ese conteo total NUNCA bloquea: si se pasa, deja una alerta en "Errores reportados" y manda un
// email, como mucho una vez por hora. El freno real sigue siendo el límite persistente por IP.
export function alertarIntentosLoginMasivos(nombre: string, maxPorHora: number) {
  return async (_req: Request, _res: Response, next: NextFunction) => {
    try {
      const supabase = getServerSupabase();
      if (supabase) {
        const { data, error } = await supabase.rpc('registrar_intento', { p_clave: `${nombre}:todas`, p_max: maxPorHora, p_ventana_seg: 3600 });
        if (!error && Number(data) > 0 && (await hayCupoGlobal(`alerta-${nombre}`, 1, 3600))) {
          const mensaje = `Hubo más de ${maxPorHora} intentos de ingreso (${nombre}) en la última hora, desde distintas conexiones. El acceso NO se bloqueó; si no fuiste vos, conviene cambiar el PIN en Vercel.`;
          console.warn(`[Seguridad] ${mensaje}`);
          void supabase.from('reportes_errores').insert({
            codigo: `LOGIN-${Math.random().toString(36).slice(2, 7).toUpperCase()}`,
            origen: 'admin',
            mensaje,
            detalle: { tipo: 'alerta_login', nombre },
          }).then(() => undefined, () => undefined);
          const resend = getResendClient();
          if (resend) {
            void resend.emails.send({
              from: process.env.RESEND_FROM_EMAIL || 'Retrato Escolar <fotos@retratoescolar.com.ar>',
              to: [casillaAvisosAdmin()],
              subject: '⚠️ Muchos intentos de ingreso al panel',
              html: `<div style="font-family:Arial,sans-serif;max-width:600px;margin:auto;color:#0f172a"><p>${escapeHtml(mensaje)}</p></div>`,
            }).then(() => undefined, () => undefined);
          }
        }
      }
    } catch {
      // La alerta es informativa: nunca frena el login.
    }
    next();
  };
}

// Auditoría 03/10 (alto 24): cupo por una clave puntual (una inscripción, un código), compartido por
// todas las instancias. true = permitido. Si la base no responde se permite.
// Auditoría 11/10 (DB-5): limites_intentos no guarda DNI ni emails en texto plano. Las claves se arman en
// otros archivos (p. ej. `inscripciones-buscar-dni:<código>:<dni>`): acá se reemplaza el DNI (último tramo)
// y cualquier email por su SHA-256. Mismo valor de entrada → misma clave, así el tope sigue contando igual.
const hashDato = (dato: string) => `h-${crypto.createHash('sha256').update(dato).digest('hex')}`;
export function claveSinDatosPersonales(clave: string): string {
  const conDni = /^(inscripciones-buscar-dni:.*:)([^:]+)$/.exec(clave);
  const base = conDni ? `${conDni[1]}${hashDato(conDni[2])}` : clave;
  return base.replace(/[^\s:@]+@[^\s:@]+\.[^\s:@]+/g, hashDato);
}

/**
 * Auditoría 03/10 noche (M13): ¿la clave ya llegó a `maximo` intentos dentro de la ventana? Sólo LEE
 * (no suma un intento). Si la base no responde, no bloquea.
 */
export async function superoTopeIntentos(clave: string, maximo: number, ventanaSeg: number): Promise<boolean> {
  const supabase = getServerSupabase();
  if (!supabase) return false;
  try {
    const { data, error } = await supabase.from('limites_intentos').select('cantidad, desde').eq('clave', claveSinDatosPersonales(clave)).maybeSingle();
    if (error || !data) return false;
    const desde = Date.parse(String(data.desde));
    if (!Number.isFinite(desde) || Date.now() - desde > ventanaSeg * 1000) return false;
    return Number(data.cantidad) >= maximo;
  } catch {
    return false;
  }
}

export async function hayCupoPorClave(clave: string, maximo: number, ventanaSeg: number): Promise<boolean> {
  const supabase = getServerSupabase();
  if (!supabase) return true;
  try {
    const { data, error } = await supabase.rpc('registrar_intento', { p_clave: claveSinDatosPersonales(clave), p_max: maximo, p_ventana_seg: ventanaSeg });
    if (error) throw error;
    return !(Number(data) > 0);
  } catch {
    return true;
  }
}

/**
 * Auditoría 28/10 (M5): el mismo tope para todas las rutas que reenvían el código de acceso. Antes cada
 * ruta contaba con una clave distinta («global:reenvio-codigo:…» y «reenvio-codigo:…») y sin tope por día,
 * así que alternándolas se le podían mandar ~288 correos por día a una familia. Ahora: 1 cada 10 minutos
 * y 4 por día por inscripción, y 300 por hora en total (para que no se gaste el cupo de Resend).
 */
export async function hayCupoReenvioCodigo(inscripcionId: string): Promise<boolean> {
  if (!(await hayCupoPorClave(`reenvio-codigo:${inscripcionId}`, 1, 600))) return false;
  if (!(await hayCupoPorClave(`reenvio-codigo-dia:${inscripcionId}`, 4, 24 * 60 * 60))) return false;
  return hayCupoGlobal('reenvio-codigo-todos', 300, 60 * 60);
}

// Limpieza periódica para no acumular memoria indefinidamente en un proceso de larga vida.
setInterval(() => {
  const ahora = Date.now();
  for (const [clave, entrada] of intentosPorClave.entries()) {
    if (ahora - entrada.desde > 30 * 60 * 1000) intentosPorClave.delete(clave);
  }
}, 5 * 60 * 1000).unref?.();

export async function tocaTurnoDistribuido(clave: string, ventanaSeg: number): Promise<boolean> {
  const supabase = getServerSupabase();
  if (!supabase) return true;
  try {
    const { data, error } = await supabase.rpc('registrar_intento', { p_clave: `turno:${clave}`.slice(0, 300), p_max: 1, p_ventana_seg: ventanaSeg });
    if (error) throw error;
    return !(Number(data) > 0);
  } catch {
    return true;
  }
}
