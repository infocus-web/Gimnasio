// Versión vigente de los términos y condiciones (división de server.ts, etapa 5, 10/10/2026). El resto
// del marco legal (aceptación, arrepentimiento) sigue con los pagos.

// Ver src/legal/textosLegales.ts (textos) y el documento "Marco legal completo". Cada pedido guarda
// qué versión de los términos aceptó la familia, cuándo y desde qué IP (prueba ante un reclamo).
// DEBE coincidir con VERSION_TERMINOS de src/legal/textosLegales.ts (lo controla un test). Se
// repite acá porque la función de Vercel no empaqueta archivos de src/.
export const VERSION_TERMINOS_SERVIDOR = '2026-10-24';
