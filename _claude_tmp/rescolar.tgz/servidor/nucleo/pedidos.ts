// Reglas de pedidos que usan varios temas del servidor (laboratorio y liquidación al colegio)
// (división de server.ts, etapa 2, 10/10/2026). El código es el mismo que estaba en server.ts:
// sólo se movió de lugar.
import { copiasPorTamano, esPedidoFotosExtra, itemsFotosExtra } from './fotosExtra.js';
export { esPedidoAdicional } from './fotosExtra.js'; // 29/10: mejora a impreso o fotos extra

/**
 * Cuántas impresiones lleva un pedido (27/9, para que el laboratorio pueda facturar). Mismo
 * criterio que arma el ZIP (generarArchivosParaLaboratorio en pedidosLabService.ts): por carpeta
 * 1 grupal 20x30 + individual 15x21 (+ docente 15x21 si se eligió); las copias sueltas por tamaño
 * sólo suman lo que excede a las carpetas extra; las "otras fotos" van en 15x21.
 */
export function contarImpresionesPedido(p: any): { carpetas: number; fotos20x30: number; fotos15x21: number; sueltas: number } {
  // 29/10/2026: un pedido de fotos extra no tiene carpeta: sólo las copias que pidió la familia.
  if (esPedidoFotosExtra(p)) return { carpetas: 0, ...copiasPorTamano(itemsFotosExtra(p)), sueltas: 0 };
  const ce = Math.max(0, Number(p?.copias_extras?.carpetasExtras) || 0);
  const excedente = (v: unknown) => Math.max(0, (Number(v) || 0) - ce);
  const f = p?.fotos_seleccionadas || {};
  // 22/10: un lugar marcado «no tiene esta foto» y sin otra foto en su lugar no se imprime (fotosFaltantes.ts).
  const sinFoto: unknown[] = Array.isArray(f.sinFoto) ? f.sinFoto : [];
  const conIndividual = !(sinFoto.includes('individual') && !f.individualId);
  const conGrupal = !(sinFoto.includes('grupal') && !f.grupalId);
  const conDocente = Boolean(f.docenteId);
  const carpetas = 1 + ce;
  const sueltas = Array.isArray(f.otrasIds) ? f.otrasIds.length : 0;
  return {
    carpetas,
    fotos20x30: conGrupal ? carpetas + excedente(p?.copias_extras?.grupal20x30) : 0,
    fotos15x21:
      carpetas * ((conIndividual ? 1 : 0) + (conDocente ? 1 : 0)) +
      (conIndividual ? excedente(p?.copias_extras?.individual15x21) : 0) +
      (conDocente ? excedente(p?.copias_extras?.docente15x21) : 0) +
      sueltas,
    sueltas,
  };
}

// Etapa 3 (10/10): etapas del laboratorio, estados cobrables, choques de índices únicos y la 3ª foto.
// Auditoría 2026-09-20 (revisión completa de estados, pedido de Pablo). El pipeline físico de un
// pedido pagado tiene 3 etapas ordenadas — antes cada botón del panel las trataba por separado y
// nada impedía saltear una (ver bug real: se pudo marcar "listo_retiro" sin pasar por
// "en_produccion"). Esta es la única lista de orden: cualquier validación de "¿puedo avanzar a
// esta etapa?" en todo el archivo se apoya en ella, en vez de tener el orden repetido a mano en
// cada endpoint.
const ETAPAS_LAB = ['en_produccion', 'listo_retiro', 'entregado'] as const;

export type EtapaLab = typeof ETAPAS_LAB[number];

/** true si "siguiente" es una etapa a la que se puede avanzar desde "actual" — es decir, la
 * inmediatamente próxima en ETAPAS_LAB, o la misma etapa (reenvío del mismo aviso). No permite
 * saltear etapas ni retroceder. */
export function puedeAvanzarEtapaLab(actual: EtapaLab | null | undefined, siguiente: EtapaLab): boolean {
  const indiceSiguiente = ETAPAS_LAB.indexOf(siguiente);
  const indiceActual = actual ? ETAPAS_LAB.indexOf(actual) : -1;
  return indiceSiguiente === indiceActual || indiceSiguiente === indiceActual + 1;
}

/**
 * Auditoría 2026-09-23 (defensa en profundidad): antes de dar por pagados los pedidos de una
 * referencia, se compara lo que efectivamente cobró la pasarela contra la suma de los `total`
 * guardados. Si se cobró menos (con $1 de tolerancia por redondeo), NO se marca como pagado.
 * Auditoría 2026-09-26 (C3, CRÍTICO): antes un monto ilegible (NaN) SALTEABA el control — y la
 * conciliación de Nave pasaba siempre NaN, así que se podía pagar un carrito de $15.000, sumarle
 * reservas al mismo grupo y quedar todo pagado. Ahora un monto ilegible nunca da el pago por
 * bueno: queda una alerta para revisarlo a mano.
 */
// Auditoría 30/9 (A1): sólo se pueden dar por pagados los pedidos pendientes o cancelados por la
// pasarela (un rechazo de tarjeta seguido de un pago aprobado). Nunca los "entregado" ni los que
// cancelaron el fotógrafo o un arrepentimiento (cancelado_definitivo): antes, con un reembolso
// PARCIAL de un carrito de hermanos, la conciliación volvía a marcar "pagado" al hermano
// cancelado y le reenviaba el HD.
export const ESTADOS_COBRABLES = ['pendiente_pago', 'cancelado'];

// Auditoría 2026-09-23: el número amigable (IFS-2026-XXXX) lo genera el navegador con 4 dígitos
// al azar, sin chequear si ya existe. Se usa para buscar el pedido, en el correo y (antes) como
// nombre del .zip HD. Acá se garantiza que no se repita: si el propuesto ya existe (o ya se usó
// dentro del mismo carrito) se genera otro en el servidor, y se le devuelve al navegador el final.
// Qué índice único de "pedidos" frenó un insert/update (error 23505), o null si fue otro error (o la
// clave primaria: un reintento con el mismo id, que cada ruta maneja aparte).
export function tipoChoqueUnicoPedido(error: any): 'friendly' | 'numero_lista' | 'mejora' | null {
  if (!error || error.code !== '23505') return null;
  const texto = `${error.message || ''} ${error.details || ''}`;
  if (/friendly/i.test(texto)) return 'friendly';
  if (texto.includes('pedidos_numero_lista_unico')) return 'numero_lista';
  if (texto.includes('pedidos_mejora_viva_unica')) return 'mejora';
  return null;
}

// 06/10/2026 (pedido de Pablo, consulta real de una familia de secundaria): en secundaria no se sacan
// fotos con el docente. La 3ª foto del kit puede ser «con la seño» (categoría 'docente') o «con
// familia y/o amigos» ('familia'). Las dos las ve todo el curso (decisión de Pablo, 06/10) y cualquier
// familia del curso las puede elegir. En el pedido sigue guardándose en `fotos_seleccionadas.docenteId`
// (el lugar de la 3ª foto) para no tocar pedidos viejos, el laboratorio ni las copias extra
// (`docente15x21`). Debe coincidir con src/utils/terceraFoto.ts.
export function esCategoriaTerceraFoto(categoria: unknown): boolean {
  return categoria === 'docente' || categoria === 'familia';
}
