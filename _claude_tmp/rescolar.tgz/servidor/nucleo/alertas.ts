// Alertas de pagos para Pablo (reportes_errores + email con tope) y `recortarJson` (división de
// server.ts, etapa 5, 10/10/2026). El código es el mismo que estaba en server.ts y en
// panel/saludErrores.ts: sólo se movió de lugar.
import type { SupabaseClient } from '@supabase/supabase-js';
import { casillaAvisosAdmin, getResendClient } from './clientes.js';
import { escapeHtml } from './utilidades.js';

// Recorta un objeto a JSON de hasta `maxCaracteres` (para guardar detalles en reportes_errores).
export function recortarJson(valor: unknown, maxCaracteres: number): any {
  try {
    const texto = JSON.stringify(valor ?? {});
    if (texto.length <= maxCaracteres) return JSON.parse(texto);
    return { recortado: true, contenido: texto.slice(0, maxCaracteres) };
  } catch {
    return { invalido: true };
  }
}

/**
 * Auditoría 2026-09-26 (M2): alerta de pagos para el panel. Antes, un pago con monto insuficiente
 * o un posible pago duplicado sólo dejaba un console.error que nadie ve: la familia pagaba y no
 * recibía nada, sin que Pablo se enterara. Ahora queda un reporte en "Estado del sistema →
 * Errores reportados" (tabla reportes_errores) y llega un email. `clave` evita repetir la misma
 * alerta en cada vuelta del control automático (cada 10 minutos).
 */
export async function registrarAlertaPago(supabase: SupabaseClient, clave: string, mensaje: string, detalle: Record<string, any> = {}): Promise<void> {
  try {
    console.error(`[Pagos][ALERTA] ${mensaje}`, detalle);
    const { data: existentes } = await supabase
      .from('reportes_errores')
      .select('id')
      .eq('estado', 'nuevo')
      .eq('detalle->>clave', clave)
      .limit(1);
    if (existentes && existentes.length > 0) return;
    const codigo = `PAGO-${Math.random().toString(36).slice(2, 7).toUpperCase()}`;
    await supabase.from('reportes_errores').insert({
      codigo,
      origen: 'admin',
      mensaje: mensaje.slice(0, 1000),
      detalle: recortarJson({ clave, tipo: 'alerta_pago', ...detalle }, 20000),
    });
    const resend = getResendClient();
    if (resend) {
      const destino = casillaAvisosAdmin();
      await resend.emails.send({
        from: process.env.RESEND_FROM_EMAIL || 'Retrato Escolar <fotos@retratoescolar.com.ar>',
        to: [destino],
        subject: `⚠️ Revisar pago ${codigo}: ${mensaje.slice(0, 90)}`,
        html: `<div style="font-family:Arial,sans-serif;max-width:640px;margin:auto;color:#0f172a"><h2>Hay un pago para revisar a mano</h2><p>${escapeHtml(mensaje)}</p><pre style="white-space:pre-wrap;font-size:12px;background:#f8fafc;padding:10px;border-radius:8px">${escapeHtml(JSON.stringify(detalle, null, 2)).slice(0, 4000)}</pre><p style="font-size:12px;color:#64748b">También figura en el panel → Estado del sistema → Errores reportados (código ${escapeHtml(codigo)}).</p></div>`,
      });
    }
  } catch (err) {
    console.error('[Pagos] No se pudo registrar la alerta de pago:', err);
  }
}
