// Importaciones del panel sin duplicados (14/10/2026, auditoría): «Importar alumnos» y el padrón hacían un
// insert plano; si la respuesta se perdía y Pablo reintentaba, la lista quedaba cargada dos veces. Ahora,
// antes de insertar, se descartan las filas que YA están en la base para ese colegio (mismo curso y mismo
// nombre, sin importar mayúsculas ni espacios) y se informa cuántas se saltearon. No se usa un índice único
// porque puede haber duplicados legítimos ya cargados (y dos chicos con el mismo nombre en una misma tanda
// se respetan: sólo se compara contra lo que ya estaba guardado).
import type { SupabaseClient } from '@supabase/supabase-js';
import { traerTodasLasFilas } from './utilidades.js';

const normalizar = (valor: unknown) => String(valor ?? '').trim().toLocaleLowerCase('es-AR').replace(/\s+/g, ' ');

/** Clave de comparación de una fila: los campos pedidos, normalizados (turno vacío = sin turno). */
export function claveFilaImportada(fila: Record<string, unknown>, campos: string[]): string {
  return campos.map((c) => normalizar(fila[c])).join('|');
}

/** Separa las filas a insertar de las que ya están guardadas para su colegio (`colegio_id`). */
export async function separarYaImportadas<T extends Record<string, any>>(
  supabase: SupabaseClient,
  tabla: string,
  campos: string[],
  filas: T[]
): Promise<{ nuevas: T[]; repetidas: number }> {
  const colegios = [...new Set(filas.map((f) => String(f.colegio_id || '')).filter(Boolean))];
  const guardadas = new Set<string>();
  for (const colegioId of colegios) {
    const existentes = await traerTodasLasFilas<any>((desde, hasta) =>
      supabase.from(tabla).select(['id', 'colegio_id', ...campos].join(', ')).eq('colegio_id', colegioId).order('id').range(desde, hasta)
    );
    for (const e of existentes) guardadas.add(`${colegioId}|${claveFilaImportada(e, campos)}`);
  }
  const nuevas = filas.filter((f) => !guardadas.has(`${String(f.colegio_id || '')}|${claveFilaImportada(f, campos)}`));
  return { nuevas, repetidas: filas.length - nuevas.length };
}
