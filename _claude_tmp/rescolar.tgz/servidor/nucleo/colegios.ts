// Validación del colegio de un pedido o inscripción (`buscarColegioReal`, `ERROR_COLEGIO_NO_VALIDO`)
// (división de server.ts, etapa 3, 10/10/2026). El código es el mismo que estaba en la sección
// "4A. COLEGIOS" de server.ts: sólo se movió de lugar.
import type { SupabaseClient } from '@supabase/supabase-js';

// Auditoría 2026-09-23 (bug de integridad, ALTO): el sitio muestra un colegio "de relleno"
// (id 'col-divino-pastor-2026', ver COLEGIO_POR_DEFECTO en colegiosService.ts) mientras carga la
// lista real o si esa carga falla. Una inscripción o un pedido enviados en ese momento quedaban
// guardados con un colegio_id que no existe: nunca cruzaban con el padrón ni con las fotos del
// colegio real (la familia no veía nunca sus fotos). Se valida contra la tabla antes de guardar.
export async function buscarColegioReal(supabase: SupabaseClient, colegioId: unknown): Promise<{ id: string; nombre: string } | null> {
  const id = String(colegioId || '').trim();
  if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(id)) return null;
  const { data, error } = await supabase.from('colegios').select('id, nombre').eq('id', id).maybeSingle();
  if (error) throw error;
  return data ? { id: data.id, nombre: data.nombre } : null;
}

export const ERROR_COLEGIO_NO_VALIDO = 'No pudimos identificar el colegio. Recargá la página y volvé a intentar.';
