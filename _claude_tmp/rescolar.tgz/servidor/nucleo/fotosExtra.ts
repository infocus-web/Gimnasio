// Fotos extra (29/10/2026, pedido de Pablo: «muchos padres quieren comprar fotos extra de sus hijos, fuera del kit»
// y «que esos pedidos se impriman en otro lote para que no se mezcle con los kit»).
// Una familia con el kit PAGADO compra copias sueltas impresas (15x21 o 20x30) de cualquier foto que ve en la
// galería. Se registra como un pedido APARTE: tipo_kit 'fotos_extra', extras_de_pedido_id = el kit, y los ítems en
// fotos_seleccionadas.extras = [{ fotoId, tamano, cantidad }]. No lleva .zip HD (son sólo copias impresas) y el
// laboratorio lo arma en lotes propios (lotes_laboratorio.tipo = 'extras', servidor/panel/laboratorioExtras.ts).
// Debe coincidir con src/utils/fotosExtra.ts.

export const TIPO_KIT_FOTOS_EXTRA = 'fotos_extra';
export const TAMANOS_FOTO_EXTRA = ['15x21', '20x30'] as const;
export type TamanoFotoExtra = (typeof TAMANOS_FOTO_EXTRA)[number];
export interface ItemFotoExtra {
  fotoId: string;
  tamano: TamanoFotoExtra;
  cantidad: number;
}

/** Topes defensivos: no hay caso real por encima (y así nadie arma un pedido gigante sin querer). */
export const MAX_COPIAS_POR_FOTO = 10;
export const MAX_ITEMS_FOTOS_EXTRA = 40;

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

export function esTamanoFotoExtra(v: unknown): v is TamanoFotoExtra {
  return (TAMANOS_FOTO_EXTRA as readonly string[]).includes(String(v));
}

/** Pedido de fotos extra (ver arriba). */
export function esPedidoFotosExtra(p: any): boolean {
  return p?.tipo_kit === TIPO_KIT_FOTOS_EXTRA || Boolean(p?.extras_de_pedido_id);
}

/**
 * Pedido que cuelga de otro (mejora a Kit Impreso o fotos extra): no es un kit propio, no lleva .zip HD, no
 * cuenta como «ya tiene un kit pagado» y no se muestra como el pedido del chico.
 */
export function esPedidoAdicional(p: any): boolean {
  return Boolean(p?.mejora_de_pedido_id) || esPedidoFotosExtra(p);
}

/** Los ítems guardados de un pedido de fotos extra (los inválidos se descartan). */
export function itemsFotosExtra(p: any): ItemFotoExtra[] {
  const crudos: unknown[] = Array.isArray(p?.fotos_seleccionadas?.extras) ? p.fotos_seleccionadas.extras : [];
  const salida: ItemFotoExtra[] = [];
  for (const c of crudos as any[]) {
    const cantidad = Math.floor(Number(c?.cantidad) || 0);
    if (!c || typeof c.fotoId !== 'string' || !esTamanoFotoExtra(c.tamano) || cantidad < 1) continue;
    salida.push({ fotoId: c.fotoId, tamano: c.tamano, cantidad: Math.min(cantidad, MAX_COPIAS_POR_FOTO) });
  }
  return salida;
}

/**
 * Lo que manda el navegador → ítems limpios. La misma foto y tamaño repetidos se suman (con el tope por foto).
 * Devuelve un error en castellano para la familia si algo no cierra.
 */
export function normalizarItemsFotosExtra(crudo: unknown): { ok: true; items: ItemFotoExtra[] } | { ok: false; error: string } {
  if (!Array.isArray(crudo) || crudo.length === 0) return { ok: false, error: 'Elegí al menos una foto extra.' };
  if (crudo.length > MAX_ITEMS_FOTOS_EXTRA) return { ok: false, error: `Se pueden pedir hasta ${MAX_ITEMS_FOTOS_EXTRA} fotos distintas por pedido.` };
  const porClave = new Map<string, ItemFotoExtra>();
  for (const c of crudo as any[]) {
    const fotoId = String(c?.fotoId || '');
    const cantidad = Number(c?.cantidad);
    if (!UUID_RE.test(fotoId)) return { ok: false, error: 'Alguna de las fotos elegidas no es válida. Volvé a elegirlas.' };
    if (!esTamanoFotoExtra(c?.tamano)) return { ok: false, error: 'Elegí el tamaño de cada foto (15x21 o 20x30).' };
    if (!Number.isInteger(cantidad) || cantidad < 1) return { ok: false, error: 'La cantidad de copias tiene que ser 1 o más.' };
    const clave = `${fotoId.toLowerCase()}|${c.tamano}`;
    const previo = porClave.get(clave);
    const total = (previo?.cantidad || 0) + cantidad;
    if (total > MAX_COPIAS_POR_FOTO) return { ok: false, error: `Se pueden pedir hasta ${MAX_COPIAS_POR_FOTO} copias de la misma foto en el mismo tamaño.` };
    porClave.set(clave, { fotoId: fotoId.toLowerCase(), tamano: c.tamano, cantidad: total });
  }
  return { ok: true, items: [...porClave.values()] };
}

export interface PreciosFotosExtra {
  extra15x21: number;
  extra20x30: number;
}

export function precioCopiaExtra(tamano: TamanoFotoExtra, precios: PreciosFotosExtra): number {
  return tamano === '20x30' ? precios.extra20x30 : precios.extra15x21;
}

/** Total a cobrar (lo calcula SIEMPRE el servidor con los precios de la base). */
export function totalFotosExtra(items: ItemFotoExtra[], precios: PreciosFotosExtra): number {
  return items.reduce((a, it) => a + it.cantidad * precioCopiaExtra(it.tamano, precios), 0);
}

export function copiasPorTamano(items: ItemFotoExtra[]): { fotos15x21: number; fotos20x30: number } {
  return items.reduce(
    (a, it) => (it.tamano === '20x30' ? { ...a, fotos20x30: a.fotos20x30 + it.cantidad } : { ...a, fotos15x21: a.fotos15x21 + it.cantidad }),
    { fotos15x21: 0, fotos20x30: 0 }
  );
}

/** Nombre del pedido que ven la familia, el panel y el colegio. */
export function nombrePedidoFotosExtra(items: ItemFotoExtra[]): string {
  const c = copiasPorTamano(items);
  const partes = [c.fotos15x21 ? `${c.fotos15x21} de 15x21` : '', c.fotos20x30 ? `${c.fotos20x30} de 20x30` : ''].filter(Boolean);
  return `Fotos extra (${partes.join(' + ')})`;
}

/** Kit (impreso o digital) pagado y con las fotos elegidas: se le pueden sumar fotos extra. */
export function kitPuedeSumarFotosExtra(p: any): boolean {
  return (
    Boolean(p) &&
    !esPedidoAdicional(p) &&
    (p.estado === 'pagado' || p.estado === 'entregado') &&
    !p.seleccion_pendiente &&
    !p.cancelado_definitivo &&
    !p.archivado
  );
}

// 29/10/2026 (Pablo: «si la plataforma siempre permitió los 3»): las fotos extra y la mejora a Kit Impreso se pagan
// con los mismos medios que el kit. Nave sólo funciona en producción (lo frena su propia ruta si no está habilitado).
export const METODOS_PAGO_ADICIONAL = ['mercadopago', 'nave', 'transferencia'] as const;
export type MetodoPagoAdicional = (typeof METODOS_PAGO_ADICIONAL)[number];
export function metodoPagoAdicional(v: unknown): MetodoPagoAdicional {
  return (METODOS_PAGO_ADICIONAL as readonly string[]).includes(String(v)) ? (String(v) as MetodoPagoAdicional) : 'mercadopago';
}
