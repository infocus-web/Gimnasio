// Llave de acceso de los pedidos (`tokenAccesoPedido`, `tokenAccesoValido`, `llaveRecibida`): la
// que habilita ver el estado de un pedido y su descarga HD sin otra sesión (división de server.ts,
// etapa 3, 10/10/2026). El código es el mismo que estaba en la sección 5 de server.ts: sólo se movió.
import crypto from 'crypto';
import type { Request } from 'express';
import { compararTimingSafe, getAdminSessionSecret } from './auth.js';

/**
 * Auditoría 2026-09-18 (pedido de Pablo: automatizar el .zip de descarga HD, en vez de que el
 * link de descarga quede vacío hasta que alguien lo suba a mano). Arma un .zip con los originales
 * en alta resolución (sin marca de agua) de las fotos que ESE pedido puntual compró — mismo
 * criterio de selección que generarArchivosParaLaboratorio() en el frontend
 * (src/services/pedidosLabService.ts), pero un solo archivo por foto distinta: una copia extra
 * impresa (copias_extras) es una copia física de más, no un archivo digital repetido.
 *
 * Sube el .zip al mismo bucket privado 'fotos-hd' (bajo "zips-pedidos/") y devuelve un link
 * firmado temporal para que la familia lo descargue directamente, sin exponer el bucket.
 *
 * Se llama automáticamente apenas se confirma un pago (Mercado Pago o Nave, más abajo). Si algo
 * falla acá (todavía no se cargaron las fotos de ese curso, error de red con Storage, etc.) esto
 * resuelve a null y el resto del flujo de pago sigue sin verse afectado: el pedido igual queda
 * "pagado" y el correo se manda con el texto de "en breve" en vez del link, como pasaba antes de
 * esta auditoría. El fotógrafo puede reintentarlo a mano una vez resuelto lo que haya fallado
 * (botón "Reenviar Email HD" en el panel de Laboratorio, que primero reintenta armar el .zip).
 */
// Auditoría 2026-09-26 (C2, CRÍTICO): llave de acceso a un pedido para la familia que lo creó.
// Antes, /api/pedidos/:id/status devolvía el link de descarga HD a cualquiera que tuviera el UUID
// del pedido — y /api/pedidos/existente se lo daba a cualquiera que supiera colegio, curso y nombre
// del chico. Ahora el link sólo sale acompañado de esta llave: un HMAC del id del pedido (o del
// grupo de pago) con un secreto del servidor. Se le entrega únicamente a quien crea el pedido (en
// la respuesta de /api/pedidos/crear, /crear-multiple y /api/reservas/crear, y en la URL de vuelta
// de la pasarela), así que nadie más puede fabricarla. Si la familia la pierde (otro dispositivo),
// el link le llega igual por email y lo puede pedir de nuevo desde "Seguimiento de pedido".
export function tokenAccesoPedido(referencia: string | null | undefined): string | null {
  const secreto = process.env.PEDIDOS_ACCESO_SECRET?.trim() || getAdminSessionSecret();
  if (!secreto || !referencia) return null;
  return crypto.createHmac('sha256', secreto).update(`acceso-pedido:${referencia}`).digest('base64url').slice(0, 32);
}

/** Llave del pedido que manda la familia (cuerpo o query `t`). */
export function llaveRecibida(req: Request): string {
  return String((req.body && (req.body as any).t) || req.query?.t || '').slice(0, 100);
}

export function tokenAccesoValido(token: unknown, referencias: (string | null | undefined)[]): boolean {
  if (typeof token !== 'string' || !token) return false;
  return referencias.some((referencia) => {
    const esperado = tokenAccesoPedido(referencia);
    return Boolean(esperado) && compararTimingSafe(token, esperado as string);
  });
}

// Etapa 5 (10/10): si un pedido ya habilita la descarga HD.
// Auditoría 2026-09-26 (A4): el link de descarga HD sólo se entrega si el pedido está cobrado. Un
// pedido cancelado (rechazo, contracargo, reembolso) o todavía sin pagar nunca lo devuelve.
export function pedidoHabilitaDescarga(estado: unknown): boolean {
  return estado === 'pagado' || estado === 'entregado';
}
