// Códigos de curso: el código interno de cada curso (`determinarCodigoCursoServidor`) y los códigos
// secretos de sección (caché en memoria de 60 s, `buscarSeccionPorCodigoSecreto`) (división de
// server.ts, etapa 3, 10/10/2026). El código es el mismo que estaba en las secciones "4B.
// INSCRIPCIONES" y "CÓDIGOS DE SECCIÓN" de server.ts: sólo se movió de lugar. La caché vive acá
// adentro; desde afuera se limpia con invalidarCacheCodigosSeccion().
import { traerTodasLasFilas } from './utilidades.js';

// Determina el código de curso sugerido según sala/turno/división (mismo criterio usado en el frontend)
// IMPORTANTE: mantener esta función en sincro con `determinarCodigoParaInscripcion` en
// src/services/inscripcionesService.ts (misma lógica, una para el servidor y otra para
// mostrarle al instante un código sugerido a la familia en el navegador).
export function determinarCodigoCursoServidor(grado: string, turno: string, division: string): string {
  const g = (grado || '').toLowerCase();
  const t = (turno || '').toLowerCase();
  const d = (division || '').toLowerCase();
  const esJornadaExtendida = t.includes('jornada') || t.includes('extendida') || d.includes('jornada') || d.includes('extendida');

  const turnoAbrev = esJornadaExtendida ? 'JE' : (t.includes('tarde') ? 'TT' : 'TM');

  // Abreviatura de la división (ej: "División C" -> "C", "Jornada Extendida" -> "JO"),
  // para diferenciar divisiones dentro del mismo grado y turno.
  const divisionAbrev = d
    .replace(/divisi[oó]n/g, '')
    .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9]/g, '')
    .toUpperCase()
    .slice(0, 2) || 'X';

  // Nivel inicial (jardín): "Sala 3/4/5 años". Auditoría 2026-09-24 (bug real, una familia
  // pagó por fotos que no eran de su curso): antes las salas usaban códigos fijos (SALA-5B,
  // SALA-4JE...) que juntaban secciones distintas — Sala 5 tarde "A" y "B" compartían
  // "SALA-5B", y las dos divisiones de Jornada Extendida compartían "SALA-5JE" —, así que una
  // familia veía (y podía comprar) fotos de otra sección. Ahora, igual que en primaria, cada
  // sala + división + turno tiene su propio código.
  const matchSala = g.match(/sala\s*(\d+)/);
  if (matchSala) {
    return `SALA${matchSala[1]}-${divisionAbrev}${turnoAbrev}`;
  }

  // Primaria: "1° grado" a "7° grado" (o variantes equivalentes que digan "grado").
  const matchGrado = g.match(/(\d+)\s*°?\s*grado/);
  if (matchGrado) {
    return `GRADO${matchGrado[1]}-${divisionAbrev}${turnoAbrev}`;
  }

  // Secundaria: "1° año" a "6° año".
  const matchAnio = g.match(/(\d+)\s*°?\s*a[ñn]o/);
  if (matchAnio) {
    return `ANIO${matchAnio[1]}-${divisionAbrev}${turnoAbrev}`;
  }

  // Cualquier otro texto de grado no contemplado arriba (colegio con nomenclatura propia):
  // se arma un código determinístico a partir del texto real, para que nunca choque por
  // accidente con el curso de otra sala/grado/año. Antes, cualquier grado no reconocido
  // devolvía siempre 'SALA-3TM' de memoria, y por eso terminaba mostrando las mismas
  // fotos que "Sala 3 años, Turno Mañana" sin importar qué grado/turno/división se eligiera.
  const gradoSlug = g
    .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .toUpperCase()
    .slice(0, 12) || 'CURSO';
  return `${gradoSlug}-${divisionAbrev}${turnoAbrev}`;
}

export function normalizarCodigoSeccion(codigo: string): string {
  return String(codigo || '').trim().toUpperCase().replace(/[^A-Z0-9]/g, '');
}

// 13/10/2026 (caso real: un tutor no podía entrar porque escribía «O» donde su código tenía «0»): los códigos
// viejos o fijados a mano mezclan 0/O y 1/I/L. Se comparan «plegados» (O→0; I y L→1), sólo como segundo intento
// y sólo si el código plegado identifica UNA sola sección (y el alta ya no deja crear dos que se confundan).
export function plegarCodigoSeccion(codigo: string): string {
  return normalizarCodigoSeccion(codigo).replace(/O/g, '0').replace(/[IL]/g, '1');
}

/** La única fila de codigos_seccion cuyo código, plegado, es igual al ingresado plegado; si no hay una sola, null. */
export function seccionConCodigoParecido(filas: any[], codigoIngresado: string): any | null {
  const plegado = plegarCodigoSeccion(codigoIngresado);
  if (plegado.length < 4) return null;
  const parecidas = filas.filter((f: any) => plegarCodigoSeccion(f.codigo_secreto) === plegado);
  return parecidas.length === 1 ? parecidas[0] : null;
}

// Todas las filas de codigos_seccion (paginado: PostgREST corta en 1000 filas por consulta).
// Auditoría 03/10 (alto 27): cada código de curso inválido que se probaba en el portal bajaba la
// tabla ENTERA: con pocas IPs se saturaba la base. Ahora se cachea 60 s por instancia (se invalida
// cuando el panel crea o cambia códigos en esta instancia). Los chequeos de unicidad
// (codigoSeccionEnUso) piden `fresco` y siempre leen la base.
let cacheCodigosSeccion: { hasta: number; filas: any[] } | null = null;

export function invalidarCacheCodigosSeccion(): void {
  cacheCodigosSeccion = null;
}

export async function traerTodosLosCodigosSeccion(supabase: any, opciones: { fresco?: boolean } = {}): Promise<any[]> {
  if (!opciones.fresco && cacheCodigosSeccion && cacheCodigosSeccion.hasta > Date.now()) return cacheCodigosSeccion.filas;
  const filas = await traerTodasLasFilas<any>((desde, hasta) =>
    supabase
      .from('codigos_seccion')
      .select('id, colegio_id, grado, turno, division, codigo_secreto')
      .order('id')
      .range(desde, hasta)
  );
  cacheCodigosSeccion = { hasta: Date.now() + 60 * 1000, filas };
  return filas;
}

/** Busca a qué sección (colegio+grado+turno+división) pertenece un código secreto ingresado. */
export async function buscarSeccionPorCodigoSecreto(
  supabase: any,
  codigoIngresado: string
): Promise<{ colegioId: string; grado: string; turno: string; division: string } | null> {
  const limpio = normalizarCodigoSeccion(codigoIngresado);
  if (!limpio) return null;

  // Paginado y con error propagado: antes, con más de 1000 secciones, los códigos más nuevos
  // "no existían", y un error puntual de la base se informaba como "código incorrecto".
  const data = await traerTodosLosCodigosSeccion(supabase);

  let match = data.find((row: any) => normalizarCodigoSeccion(row.codigo_secreto) === limpio);
  if (!match) {
    // Auditoría 03/10: si no está en la copia cacheada puede ser un código recién creado en otra
    // instancia: se busca SÓLO ese código (no la tabla entera) en sus formas guardadas posibles
    // ("AB12-CD34" generado, "AB12CD34" fijado a mano o tal cual se tipeó).
    const variantes = new Set([limpio, String(codigoIngresado || '').trim().toUpperCase().replace(/[^A-Z0-9 -]/g, '').slice(0, 40)]);
    if (limpio.length === 8) variantes.add(`${limpio.slice(0, 4)}-${limpio.slice(4)}`);
    const { data: puntual, error } = await supabase
      .from('codigos_seccion')
      .select('id, colegio_id, grado, turno, division, codigo_secreto')
      .in('codigo_secreto', Array.from(variantes).filter(Boolean))
      .limit(5);
    if (error) throw error;
    match = (puntual || []).find((row: any) => normalizarCodigoSeccion(row.codigo_secreto) === limpio);
    if (match) invalidarCacheCodigosSeccion();
  }
  if (!match) match = seccionConCodigoParecido(data, codigoIngresado); // 13/10: «O» por «0», «I»/«L» por «1»
  if (!match) return null;

  return { colegioId: match.colegio_id, grado: match.grado, turno: match.turno, division: match.division };
}

// Auditoría 11/10 (FAM-2, preventivo): dos secciones distintas de un colegio que dan el mismo código de
// curso (p. ej. "Jornada Extendida" y "Jornada Completa" → JE) compartirían las fotos. No se cambia la
// fórmula (rompería el codigo_curso guardado en `fotos`): se frena el alta de la sección que choca.
export class ErrorChoqueCodigoCurso extends Error {
  status = 409;
}

export async function verificarSinChoqueCodigoCurso(supabase: any, colegioId: string, grado: string, turno: string, division: string): Promise<void> {
  const t = (v: unknown) => String(v ?? '').trim();
  // Revisión 11/10: «Mañana» y «Turno Mañana», «A» y «División A» o mayúsculas distintas son la MISMA sección.
  const n = (v: unknown) => t(v).normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/\b(turno|division)\b/g, ' ').replace(/[^a-z0-9°º]+/g, ' ').trim();
  const codigoCurso = determinarCodigoCursoServidor(t(grado), t(turno), t(division));
  const filas = await traerTodosLosCodigosSeccion(supabase, { fresco: true });
  const choque = filas.find(
    (f: any) =>
      t(f.colegio_id) === t(colegioId) &&
      !(n(f.grado) === n(grado) && n(f.turno) === n(turno) && n(f.division) === n(division)) &&
      determinarCodigoCursoServidor(t(f.grado), t(f.turno), t(f.division)) === codigoCurso
  );
  if (choque) {
    throw new ErrorChoqueCodigoCurso(
      `«${t(grado)} ${t(division)} (${t(turno)})» y «${t(choque.grado)} ${t(choque.division)} (${t(choque.turno)})» quedarían con el mismo código interno de curso (${codigoCurso}) y compartirían las fotos. Cambiá el nombre del turno o de la división de uno de los dos (por ejemplo, usá otras dos primeras letras) antes de crear el código.`
    );
  }
}
