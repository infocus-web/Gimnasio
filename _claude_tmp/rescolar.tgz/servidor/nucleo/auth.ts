// Autenticación del panel (PIN de admin y token firmado) y del laboratorio (LAB_PIN y token lab.…)
// (división de server.ts, etapa 1, 10/10/2026). El código es el mismo que estaba en las secciones
// "2. AUTENTICACIÓN ADMINISTRATIVA" y "4E. PANEL DEL LABORATORIO" de server.ts: sólo se movió de lugar.
import './entorno.js';
import crypto from 'crypto';
import type { NextFunction, Request, Response } from 'express';
import { getServerSupabase } from './clientes.js';

export function getAdminPin(): string | null {
  const pin = process.env.ADMIN_PIN;
  if (!pin || pin.trim() === '') return null;
  return pin.trim();
}

export function getAdminSessionSecret(): string | null {
  const secret = process.env.ADMIN_SESSION_SECRET;
  if (!secret || secret.trim() === '') return null;
  return secret.trim();
}

export function normalizePin(p: string): string {
  return (p || '').trim().replace(/^#/, '');
}

export function generateAdminToken(): string | null {
  const secret = getAdminSessionSecret();
  if (!secret) return null;
  const timestamp = Date.now();
  const random = crypto.randomBytes(16).toString('hex');
  const payload = `${timestamp}.${random}`;
  const signature = crypto
    .createHmac('sha256', secret)
    .update(payload)
    .digest('hex');
  return `${payload}.${signature}`;
}

export function verifyAdminToken(token?: string): boolean {
  if (!token) return false;
  const secret = getAdminSessionSecret();
  if (!secret) return false;

  const parts = token.split('.');
  if (parts.length !== 3) return false;
  const [timestampStr, random, signature] = parts;
  // Auditoría 30/9: el token de admin tiene exactamente 32 hex al azar; así ningún otro valor
  // firmado con el mismo secreto (por ejemplo, el "state" viejo de Zoho) sirve como sesión.
  if (!/^[0-9a-f]{32}$/.test(random) || !/^\d{10,16}$/.test(timestampStr)) return false;
  const timestamp = parseInt(timestampStr, 10);
  if (isNaN(timestamp)) return false;

  // Sesión válida durante 24 horas
  if (Date.now() - timestamp > 24 * 60 * 60 * 1000) return false;

  const expectedSignature = crypto
    .createHmac('sha256', secret)
    .update(`${timestampStr}.${random}`)
    .digest('hex');

  try {
    const sigBuf = Buffer.from(signature);
    const expBuf = Buffer.from(expectedSignature);
    return sigBuf.length === expBuf.length && crypto.timingSafeEqual(sigBuf, expBuf);
  } catch {
    return false;
  }
}

// Auditoría 2026-09-22 (posible bug de seguridad, BAJO): comparación genérica en tiempo
// constante para secretos cortos comparados por igualdad de string (además del PIN/token admin,
// que ya usaban este patrón cada uno por su lado — ver verifyAdminToken arriba). Se centraliza
// acá para que cualquier otra comparación de "secreto que viene del cliente vs. secreto guardado"
// (por ejemplo el código de acceso al padrón de un colegio) no vuelva a compararse con `!==`
// plano, que es vulnerable en teoría a timing attacks.
export function compararTimingSafe(a: string, b: string): boolean {
  try {
    const bufA = Buffer.from(a);
    const bufB = Buffer.from(b);
    return bufA.length === bufB.length && crypto.timingSafeEqual(bufA, bufB);
  } catch {
    return false;
  }
}

export function requireAdminAuth(req: Request, res: Response, next: NextFunction) {
  const secret = getAdminSessionSecret();
  if (!secret) {
    return res.status(500).json({
      success: false,
      error: 'ADMIN_SESSION_SECRET no configurada en las variables de entorno del servidor.',
    });
  }

  const authHeader = req.headers.authorization;
  const token = authHeader?.startsWith('Bearer ')
    ? authHeader.substring(7)
    : (req.headers['x-admin-token'] as string);

  if (!verifyAdminToken(token)) {
    return res.status(401).json({
      success: false,
      error: 'No autorizado. Se requiere sesión de administrador válida.',
    });
  }
  next();
}

export function pinAdminCorrecto(pinCrudo: unknown): boolean {
  const adminPin = getAdminPin();
  const pin = pinCrudo === undefined || pinCrudo === null ? '' : String(pinCrudo);
  if (!adminPin || !pin) return false;
  const esperado = Buffer.from(normalizePin(adminPin));
  const recibido = Buffer.from(normalizePin(pin));
  return esperado.length === recibido.length && crypto.timingSafeEqual(esperado, recibido);
}

export function getLabPin(): string | null {
  const pin = process.env.LAB_PIN?.trim();
  return pin ? pin : null;
}

export function generarTokenLab(): string | null {
  const secret = getAdminSessionSecret();
  if (!secret) return null;
  const payload = `${Date.now()}.${crypto.randomBytes(16).toString('hex')}`;
  const firma = crypto.createHmac('sha256', secret).update(`lab:${payload}`).digest('hex');
  return `lab.${payload}.${firma}`;
}

export function verificarTokenLab(token?: string): boolean {
  const secret = getAdminSessionSecret();
  if (!token || !secret) return false;
  const partes = token.split('.');
  if (partes.length !== 4 || partes[0] !== 'lab') return false;
  const [, ts, random, firma] = partes;
  const momento = parseInt(ts, 10);
  if (isNaN(momento) || Date.now() - momento > 12 * 60 * 60 * 1000) return false; // 12 horas
  const esperada = crypto.createHmac('sha256', secret).update(`lab:${ts}.${random}`).digest('hex');
  return compararTimingSafe(firma, esperada);
}

export function requireLabAuth(req: Request, res: Response, next: NextFunction) {
  const authHeader = req.headers.authorization;
  const token = authHeader?.startsWith('Bearer ') ? authHeader.substring(7) : undefined;
  if (verificarTokenLab(token) || verifyAdminToken(token)) return next();
  return res.status(401).json({ success: false, error: 'Sesión vencida. Volvé a ingresar con el PIN del laboratorio.' });
}

// Etapa 3 (10/10): autorización de las tareas programadas (crons de Supabase y Vercel).
// Auditoría 2026-09-20: endpoint que dispara Vercel Cron (ver vercel.json) para que el reintento
// del .zip HD no dependa de que alguien abra el panel de Laboratorio. Protegido con CRON_SECRET:
// Vercel manda automáticamente "Authorization: Bearer <CRON_SECRET>" en las llamadas programadas
// cuando esa variable de entorno existe — hay que crearla en el proyecto de Vercel (cualquier
// texto largo al azar sirve) para que este endpoint acepte las llamadas. Sin esa variable
// configurada, el endpoint sigue existiendo pero rechaza todo (falla cerrado, no abierto).
// Autorización de tareas programadas: acepta el CRON_SECRET de Vercel o el secreto que guarda la
// base (tabla privada tareas_programadas_secreto), que es el que usa pg_cron de Supabase para
// llamar cada 10 minutos sin depender del plan de Vercel ni de tener el secreto en otro lado.
export async function autorizarTareaProgramada(req: Request): Promise<boolean> {
  const autorizacion = req.headers.authorization || '';
  const secretoVercel = process.env.CRON_SECRET;
  if (secretoVercel && compararTimingSafe(autorizacion, `Bearer ${secretoVercel}`)) return true;
  const supabase = getServerSupabase();
  if (!supabase) return false;
  const { data } = await supabase.from('tareas_programadas_secreto').select('secreto').eq('id', 1).maybeSingle();
  return Boolean(data?.secreto) && compararTimingSafe(autorizacion, `Bearer ${data!.secreto}`);
}
