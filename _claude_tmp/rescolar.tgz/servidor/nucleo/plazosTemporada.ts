// Fechas límite de la temporada, editables desde el panel → Configuración (30/10/2026, pedido de Pablo).
// Antes estaban fijas en el código (15/11/2026) y para moverlas había que tocar código y subir.
//  - kitImpreso: hasta cuándo se elige el Kit Impreso (comprar, confirmar fotos de una reserva pagada, pasar de
//    Solo Digital a Impreso) y se piden fotos extra.
//  - faltantes: hasta cuándo la familia puede pedir que le saquen una foto que le falta.
// Se guardan en `configuracion` (clave 'plazos_temporada', columna datos_extra) y se releen como mucho una vez
// por minuto por instancia. Si la base no responde se usa la última fecha leída (o la de abajo, por defecto).
// Las fechas son días (AAAA-MM-DD) y cierran al final de ese día, hora de Argentina.
// Debe coincidir con src/utils/plazosTemporada.ts.
import type { SupabaseClient } from '@supabase/supabase-js';
import { getServerSupabase } from './clientes.js';

export interface PlazosTemporada {
  kitImpreso: string;
  faltantes: string;
}

export const PLAZOS_POR_DEFECTO: Readonly<PlazosTemporada> = Object.freeze({ kitImpreso: '2026-11-15', faltantes: '2026-11-15' });
export const CLAVE_CONFIG_PLAZOS = 'plazos_temporada';
const RELECTURA_MS = 60 * 1000;
const REINTENTO_SI_FALLA_MS = 10 * 1000;

let actuales: PlazosTemporada = { ...PLAZOS_POR_DEFECTO };
let leidosAt = 0;
let leidosDeLaBase = false;
let lecturaEnCurso: Promise<void> | null = null;

const MESES = ['enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre'];

/** Día real con formato AAAA-MM-DD (entre 2024 y 2100). */
export function fechaValida(valor: unknown): valor is string {
  if (typeof valor !== 'string') return false;
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(valor);
  if (!m) return false;
  const [anio, mes, dia] = [Number(m[1]), Number(m[2]), Number(m[3])];
  if (anio < 2024 || anio > 2100) return false;
  const f = new Date(Date.UTC(anio, mes - 1, dia));
  return f.getUTCFullYear() === anio && f.getUTCMonth() === mes - 1 && f.getUTCDate() === dia;
}

/** Las dos fechas válidas, o null. */
export function validarPlazos(entrada: unknown): PlazosTemporada | null {
  if (!entrada || typeof entrada !== 'object') return null;
  const { kitImpreso, faltantes } = entrada as Record<string, unknown>;
  if (!fechaValida(kitImpreso) || !fechaValida(faltantes)) return null;
  return { kitImpreso, faltantes };
}

/** Último instante del día (23:59:59.999 hora de Argentina), en milisegundos. */
export function finDelDia(fecha: string): number {
  return Date.parse(`${fecha}T23:59:59.999-03:00`);
}

/** «15/11» */
export function textoFechaCorta(fecha: string): string {
  return `${fecha.slice(8, 10)}/${fecha.slice(5, 7)}`;
}

/** «15 de noviembre» */
export function textoFechaLarga(fecha: string): string {
  return `${Number(fecha.slice(8, 10))} de ${MESES[Number(fecha.slice(5, 7)) - 1]}`;
}

async function leerDeLaBase(supabase: SupabaseClient): Promise<void> {
  try {
    const { data, error } = await supabase
      .from('configuracion')
      .select('datos_extra')
      .eq('clave', CLAVE_CONFIG_PLAZOS)
      .abortSignal(AbortSignal.timeout(4000))
      .maybeSingle();
    if (error) throw error;
    // Sin fila (nunca se guardó desde el panel) o con una fecha rota: la que falte va por defecto.
    const guardados = (data?.datos_extra && typeof data.datos_extra === 'object' ? data.datos_extra : {}) as Record<string, unknown>;
    actuales = {
      kitImpreso: fechaValida(guardados.kitImpreso) ? guardados.kitImpreso : PLAZOS_POR_DEFECTO.kitImpreso,
      faltantes: fechaValida(guardados.faltantes) ? guardados.faltantes : PLAZOS_POR_DEFECTO.faltantes,
    };
    leidosDeLaBase = true;
    leidosAt = Date.now();
  } catch (err) {
    console.error('[plazos] No se pudieron leer las fechas límite (se usan las últimas conocidas):', err);
    leidosAt = Date.now() - RELECTURA_MS + REINTENTO_SI_FALLA_MS; // se reintenta en unos segundos
  }
}

/**
 * Relee las fechas si pasó más de un minuto. Devuelve una promesa sólo cuando hay que esperar (instancia nueva
 * que todavía no las leyó); si ya se leyeron alguna vez, la relectura va en segundo plano y devuelve undefined.
 * Sin base configurada (pruebas) no hace nada: quedan las por defecto.
 */
export function asegurarPlazosActualizados(): Promise<void> | undefined {
  if (Date.now() - leidosAt < RELECTURA_MS) return undefined;
  if (!process.env.SUPABASE_SERVICE_ROLE_KEY) return undefined;
  const supabase = getServerSupabase();
  if (!supabase) return undefined;
  if (!lecturaEnCurso) {
    lecturaEnCurso = leerDeLaBase(supabase).finally(() => {
      lecturaEnCurso = null;
    });
  }
  return leidosDeLaBase ? undefined : lecturaEnCurso;
}

/** Para middlewares: sigue en el acto si las fechas están al día; si no, espera la lectura. */
export function conPlazosActualizados(seguir: () => void): void {
  const espera = asegurarPlazosActualizados();
  if (espera) void espera.then(seguir, seguir);
  else seguir();
}

/** Las fechas vigentes (y, si están viejas, las relee en segundo plano para la próxima). */
export function plazosVigentes(): PlazosTemporada {
  void asegurarPlazosActualizados()?.catch(() => undefined);
  return actuales;
}

/** Después de guardar desde el panel: esta instancia las usa en el acto (las demás, en menos de un minuto). */
export function aplicarPlazos(nuevos: PlazosTemporada): void {
  actuales = { ...nuevos };
  leidosDeLaBase = true;
  leidosAt = Date.now();
}
