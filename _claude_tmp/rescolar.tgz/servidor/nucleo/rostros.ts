// Buscador por reconocimiento facial (24/10/2026): ¿este colegio lo tiene? Sólo si están las variables de AWS y el
// colegio tiene su colección de caras armada (_ubicador/indexar_buscador.py). Esta temporada: sólo el Divino Pastor.
// Se puede cambiar sin tocar código con REKOGNITION_COLEGIOS (ids separados por coma). Lo usan la ruta del buscador,
// el portal (mostrar o no el botón), el mail «ya están tus fotos» (nombrarlo o no) y «Cerrar año».
import type { SupabaseClient } from '@supabase/supabase-js';

const COLEGIOS_POR_DEFECTO = ['73812be8-33f2-4bfd-a83e-ef7d7643bb0f']; // Instituto Madre del Divino Pastor (2026)

export function buscadorRostroConfigurado(): boolean {
  return Boolean((process.env.AWS_REKOGNITION_ACCESS_KEY_ID || '').trim() && (process.env.AWS_REKOGNITION_SECRET_ACCESS_KEY || '').trim());
}

export function colegiosConBuscadorRostro(): string[] {
  const env = (process.env.REKOGNITION_COLEGIOS || '').split(',').map((s) => s.trim()).filter(Boolean);
  return env.length > 0 ? env : COLEGIOS_POR_DEFECTO;
}

/** Errores de «la tabla no existe» (migración sin aplicar): PostgREST PGRST205 o Postgres 42P01. */
export function tablaRostrosNoExiste(error: any): boolean {
  return error?.code === 'PGRST205' || error?.code === '42P01';
}

// `supabase` queda en la firma por si más adelante la lista pasa a la base.
export async function colegioTieneBuscadorRostro(_supabase: SupabaseClient, colegioId: string): Promise<boolean> {
  return Boolean(colegioId) && buscadorRostroConfigurado() && colegiosConBuscadorRostro().includes(colegioId);
}

/**
 * 25/10 (auditoría): el buscador sólo copia individuales PUBLICADAS y las copias nacen publicadas en el curso de la
 * familia. Con el curso de la familia todavía sin publicar, cada búsqueda gastaba cupo, decía «no encontramos» y
 * publicaba copias en un curso que Pablo no había publicado: el botón aparece recién con fotos publicadas en el curso.
 */
export async function cursoTieneFotosPublicadas(supabase: SupabaseClient, colegioId: string, codigoCurso: string): Promise<boolean> {
  if (!colegioId || !codigoCurso) return false;
  const { data, error } = await supabase
    .from('fotos')
    .select('id')
    .eq('colegio_id', colegioId)
    .eq('codigo_curso', codigoCurso)
    .not('publicada_at', 'is', null)
    .limit(1);
  if (error) throw error;
  return (data || []).length > 0;
}

/** Sin caché desde el 24/10 (la lista sale de una constante / variable); se deja para las pruebas. */
export function limpiarCacheBuscadorRostro() {}
