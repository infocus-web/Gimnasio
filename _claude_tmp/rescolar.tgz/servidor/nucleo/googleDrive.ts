// ORIGINALES EN GOOGLE DRIVE (17/10/2026, pedido de Pablo).
// Pablo sube los originales sólo a una carpeta de Drive (cuenta alderpol@gmail.com, "Retrato Escolar -
// Originales HD"). La web los lee con una cuenta de servicio de Google que tiene acceso de LECTOR a esa
// carpeta: importa (arma muestras, miniaturas y la copia de la lupa) y, cuando un pedido se paga, copia
// el original a Storage para la descarga HD y el laboratorio.
// Credenciales: variable GOOGLE_SERVICE_ACCOUNT_JSON en Vercel (el JSON completo de la clave). Sin
// librerías: el token se pide firmando un JWT (RS256) con la clave privada.
import crypto from 'crypto';

interface Credenciales {
  client_email: string;
  private_key: string;
  token_uri?: string;
}

export interface ArchivoDrive {
  id: string;
  nombre: string;
  tamano: number;
  mimeType: string;
}

let credenciales: Credenciales | null | undefined;
let tokenGuardado: { valor: string; vence: number } | null = null;

function leerCredenciales(): Credenciales | null {
  if (credenciales !== undefined) return credenciales;
  const crudo = process.env.GOOGLE_SERVICE_ACCOUNT_JSON;
  credenciales = null;
  if (!crudo) return null;
  try {
    const c = JSON.parse(crudo);
    if (c && typeof c.client_email === 'string' && typeof c.private_key === 'string') credenciales = c;
  } catch {
    console.error('[drive] GOOGLE_SERVICE_ACCOUNT_JSON no es un JSON válido');
  }
  return credenciales;
}

export function driveConfigurado(): boolean {
  return leerCredenciales() !== null;
}

/** Sólo para las pruebas. */
export function olvidarCredencialesDrive(): void {
  credenciales = undefined;
  tokenGuardado = null;
}

const b64url = (b: Buffer | string) => Buffer.from(b).toString('base64').replace(/=+$/, '').replace(/\+/g, '-').replace(/\//g, '_');

async function token(): Promise<string> {
  if (tokenGuardado && tokenGuardado.vence > Date.now() + 60_000) return tokenGuardado.valor;
  const c = leerCredenciales();
  if (!c) throw new Error('Falta configurar GOOGLE_SERVICE_ACCOUNT_JSON en Vercel');
  const ahora = Math.floor(Date.now() / 1000);
  const aud = c.token_uri || 'https://oauth2.googleapis.com/token';
  const cabecera = b64url(JSON.stringify({ alg: 'RS256', typ: 'JWT' }));
  const cuerpo = b64url(JSON.stringify({ iss: c.client_email, scope: 'https://www.googleapis.com/auth/drive.readonly', aud, iat: ahora, exp: ahora + 3600 }));
  const firma = b64url(crypto.createSign('RSA-SHA256').update(`${cabecera}.${cuerpo}`).sign(c.private_key));
  const r = await fetch(aud, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({ grant_type: 'urn:ietf:params:oauth:grant-type:jwt-bearer', assertion: `${cabecera}.${cuerpo}.${firma}` }),
  });
  if (!r.ok) throw new Error(`Google no dio acceso a Drive (${r.status})`);
  const j = (await r.json()) as { access_token: string; expires_in: number };
  tokenGuardado = { valor: j.access_token, vence: Date.now() + j.expires_in * 1000 };
  return j.access_token;
}

/** Saca el id de la carpeta de un link de Drive (o lo devuelve tal cual si ya es un id). */
export function idCarpetaDrive(texto: unknown): string | null {
  const t = String(texto ?? '').trim();
  const enLink = t.match(/\/folders\/([A-Za-z0-9_-]{10,})/) || t.match(/[?&]id=([A-Za-z0-9_-]{10,})/);
  const id = enLink ? enLink[1] : t;
  return /^[A-Za-z0-9_-]{10,}$/.test(id) ? id : null;
}

const TIPOS_FOTO = new Set(['image/jpeg', 'image/jpg', 'image/pjpeg']);

/** Fotos JPG que están directamente dentro de la carpeta (sin entrar a subcarpetas), ordenadas por nombre. */
export async function listarFotosDeCarpeta(carpetaId: string): Promise<ArchivoDrive[]> {
  const t = await token();
  const fotos: ArchivoDrive[] = [];
  let pageToken = '';
  do {
    const q = new URLSearchParams({
      q: `'${carpetaId}' in parents and trashed = false`,
      fields: 'nextPageToken, files(id, name, size, mimeType)',
      pageSize: '1000',
      supportsAllDrives: 'true',
      includeItemsFromAllDrives: 'true',
    });
    if (pageToken) q.set('pageToken', pageToken);
    const r = await fetch(`https://www.googleapis.com/drive/v3/files?${q}`, { headers: { Authorization: `Bearer ${t}` } });
    if (r.status === 404) throw Object.assign(new Error('No encontramos la carpeta en Drive (¿está compartida con la cuenta de servicio?)'), { publico: true });
    if (!r.ok) throw new Error(`Drive respondió ${r.status} al listar la carpeta`);
    const j = (await r.json()) as { nextPageToken?: string; files?: { id: string; name: string; size?: string; mimeType: string }[] };
    for (const f of j.files || []) {
      if (TIPOS_FOTO.has(f.mimeType) || /\.jpe?g$/i.test(f.name)) fotos.push({ id: f.id, nombre: f.name, tamano: Number(f.size || 0), mimeType: f.mimeType });
    }
    pageToken = j.nextPageToken || '';
  } while (pageToken);
  const nat = new Intl.Collator('es', { numeric: true, sensitivity: 'base' });
  return fotos.sort((a, b) => nat.compare(a.nombre, b.nombre));
}

/** Baja un archivo de Drive entero (con 2 reintentos si Google responde lento o con error temporal). */
export async function descargarDeDrive(archivoId: string): Promise<Buffer> {
  if (!/^[A-Za-z0-9_-]{10,}$/.test(archivoId)) throw new Error('Id de Drive inválido');
  let ultimo: unknown;
  for (let intento = 0; intento < 3; intento++) {
    try {
      const t = await token();
      const r = await fetch(`https://www.googleapis.com/drive/v3/files/${archivoId}?alt=media&supportsAllDrives=true`, {
        headers: { Authorization: `Bearer ${t}` },
      });
      if (r.status === 404) throw Object.assign(new Error('El original ya no está en Drive (¿se borró o se movió?)'), { definitivo: true });
      if (!r.ok) throw new Error(`Drive respondió ${r.status} al bajar el original`);
      return Buffer.from(await r.arrayBuffer());
    } catch (e: any) {
      ultimo = e;
      if (e?.definitivo) break;
      await new Promise((ok) => setTimeout(ok, 700 * (intento + 1)));
    }
  }
  throw ultimo;
}
