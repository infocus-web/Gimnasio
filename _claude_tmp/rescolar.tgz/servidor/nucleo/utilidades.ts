// Utilidades comunes del servidor, sin dependencias (división de server.ts, etapa 1, 10/10/2026;
// `ipDelCliente` se sumó en la etapa 2). El código es el mismo que estaba en server.ts: sólo se movió
// de lugar.
import type { Request } from 'express';

// Auditoría 2026-09 (bug reportado por Pablo): la pestaña "Nómina 2026" mostraba "(1000)"
// aunque el colegio ya tenía 1314 alumnos cargados. Causa: Supabase/PostgREST limita cada
// consulta a un máximo de filas por respuesta (1000 por defecto) aunque no se pida un
// `.limit()` explícito — una sola consulta nunca devuelve más filas que ese tope, sin importar
// cuántas haya en la tabla. Este helper pagina la consulta pidiendo de a 1000 filas hasta
// traerlas todas, para que ningún endpoint dependa de la configuración de "Max Rows" del
// proyecto en Supabase. `construirConsulta` arma la consulta base (columnas, filtros, orden)
// y recibe el rango de filas a pedir en cada vuelta.
export async function traerTodasLasFilas<T>(
  construirConsulta: (desde: number, hasta: number) => any
): Promise<T[]> {
  const TAMANO_PAGINA = 1000;
  const filas: T[] = [];
  let desde = 0;
  while (true) {
    const { data, error } = await construirConsulta(desde, desde + TAMANO_PAGINA - 1);
    if (error) throw error;
    const pagina: T[] = data || [];
    // Auditoría 11/10: si "Max Rows" de PostgREST es menor que la página, cortar en `< 1000` truncaba
    // todo en silencio. Se avanza por lo recibido y se corta recién con una página vacía.
    if (pagina.length === 0) break;
    // Freno: 500 páginas = 500.000 filas. Si una consulta no aplicara el rango, cortar con error en vez de girar para siempre.
    if (filas.length >= TAMANO_PAGINA * 500) throw new Error('traerTodasLasFilas: demasiadas filas (¿falta .range en la consulta?)');
    filas.push(...pagina);
    desde += pagina.length;
  }
  return filas;
}

// Normaliza un nombre para poder comparar "Juan Pérez" con "juan   perez," (sin acentos,
// mayúsculas, comas/puntos ni espacios de más) — mismo criterio de limpieza que ya se usa
// para los códigos de curso más arriba en este archivo.
export function normalizarNombreComparable(nombre: unknown): string {
  return String(nombre || '')
    .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .replace(/[.,]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

// La nómina suele cargarse como "Apellido, Nombre" mientras que la familia tipea su propio
// pedido como "Nombre Apellido" (o en cualquier otro orden) — para no perder esos casos, esta
// clave alternativa ordena alfabéticamente las palabras del nombre, así "García María José" y
// "María José García" quedan con la misma clave sin importar el orden en que se escribieron.
export function normalizarNombrePorPalabras(nombre: unknown): string {
  return normalizarNombreComparable(nombre)
    .split(' ')
    .filter(Boolean)
    .sort()
    .join(' ');
}

// Parte una lista de ids en lotes chicos para filtros `.in(...)`: cada id viaja en la URL de la
// consulta, y con cientos de UUIDs juntos la URL supera el largo máximo que acepta el servidor.
export function enLotes<T>(lista: T[], tamano = 100): T[][] {
  const lotes: T[][] = [];
  for (let i = 0; i < lista.length; i += tamano) lotes.push(lista.slice(i, i + tamano));
  return lotes;
}

// Auditoría 2026-09-09 (revisión a fondo): los dos correos de abajo arman el HTML pegando
// directo strings que vienen de un formulario público (nombre del padre/tutor, nombre del
// alumno, del colegio, del kit, etc.), sin sacarles los caracteres especiales de HTML. Alguien
// podía escribir en su nombre algo como `<a href="...">` y ese link (o cualquier otro HTML)
// terminaba insertado tal cual dentro de un correo real, con la marca de Retrato Escolar, que
// se le manda a una familia — la puerta de entrada clásica para un correo de phishing con
// apariencia legítima. Se escapan todos los valores que vienen de afuera antes de insertarlos.
export function escapeHtml(valor: unknown): string {
  return String(valor ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

export function ipDelCliente(req: Request): string | null {
  const ip = String(req.ip || '').trim();
  return ip ? ip.slice(0, 80) : null;
}

// Etapa 3 (10/10): `mapConLimite` (corre tareas en paralelo con un tope).
// Auditoría 03/10 (crítico 4): corre `fn` sobre `items` con como mucho `limite` a la vez (mismo
// orden en el resultado). Las descargas de originales para el .zip iban todas juntas: con muchas
// fotos se llenaba la memoria de la función y Storage cortaba.
export async function mapConLimite<T, R>(items: T[], limite: number, fn: (item: T, indice: number) => Promise<R>): Promise<R[]> {
  const resultados: R[] = new Array(items.length);
  let siguiente = 0;
  const trabajador = async () => {
    while (siguiente < items.length) {
      const indice = siguiente++;
      resultados[indice] = await fn(items[indice], indice);
    }
  };
  await Promise.all(Array.from({ length: Math.max(1, Math.min(limite, items.length)) }, trabajador));
  return resultados;
}
