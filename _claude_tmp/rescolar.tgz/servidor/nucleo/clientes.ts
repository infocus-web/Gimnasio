// Clientes de los servicios externos: Resend (emails), Supabase (base y archivos), Mercado Pago y
// Nave (división de server.ts, etapa 1, 10/10/2026). El código es el mismo que estaba en la sección
// "1. CONFIGURACIÓN DE SERVICIOS Y CLIENTES" de server.ts: sólo se movió de lugar.
import './entorno.js';
import { Resend } from 'resend';
import { createClient, SupabaseClient } from '@supabase/supabase-js';
import { MercadoPagoConfig } from 'mercadopago';
import { escapeHtml } from './utilidades.js';

export const CASILLA_REENVIO_ENTRANTE = process.env.CASILLA_REENVIO_ENTRANTE?.trim() || 'colegios@contacto.retratoescolar.com.ar';

// Lazy client para Resend
export function getResendClient(): Resend | null {
  const apiKey = process.env.RESEND_API_KEY;
  if (!apiKey || apiKey.trim() === '') {
    return null;
  }
  const cliente = new Resend(apiKey.trim());
  // Preparación temporada (25/9): Resend limita los envíos por segundo. En un pico (muchos pagos a
  // la vez, avisos de fotos) un correo rechazado por ese límite o por un error pasajero de Resend
  // se perdía: nadie lo reenviaba. Ahora cada envío (individual o por lotes) se reintenta hasta 4
  // veces con espera creciente ante límite de frecuencia (429), error del servidor de Resend (5xx)
  // o fallo de red. Errores de datos (email inválido, etc.) no se reintentan.
  const conReintento = <T extends (...args: any[]) => Promise<any>>(fn: T): T =>
    (async (...args: any[]) => {
      let ultimo: any;
      for (let intento = 0; intento < 4; intento++) {
        try {
          ultimo = await fn(...args);
          const e: any = ultimo?.error;
          const reintentable = e && (e.statusCode === 429 || e.name === 'rate_limit_exceeded' || (Number(e.statusCode) >= 500) || e.name === 'application_error' || e.name === 'internal_server_error');
          if (!reintentable) return ultimo;
        } catch (err) {
          ultimo = { data: null, error: { name: 'network_error', message: (err as any)?.message || String(err) } };
        }
        await new Promise((resolve) => setTimeout(resolve, 600 * (intento + 1) + Math.floor(Math.random() * 400)));
      }
      return ultimo;
    }) as T;
  // Auditoría 28/9: cada envío que sale bien se cuenta (ver contarEnviosEmail) para avisar antes
  // de llegar al cupo de Resend.
  const contando = <T extends (...args: any[]) => Promise<any>>(fn: T, cantidadDe: (args: any[]) => number): T =>
    (async (...args: any[]) => {
      const resultado = await fn(...args);
      if (resultado && !resultado.error) void contarEnviosEmail(cantidadDe(args)).catch(() => {});
      return resultado;
    }) as T;
  cliente.emails.send = contando(conReintento(cliente.emails.send.bind(cliente.emails)), (args) => {
    const to = args[0]?.to;
    return Array.isArray(to) ? Math.max(1, to.length) : 1;
  });
  cliente.batch.send = contando(conReintento(cliente.batch.send.bind(cliente.batch)), (args) => (Array.isArray(args[0]) ? args[0].length : 1));
  return cliente;
}

// Cupo de Resend (plan gratuito: 100 emails por día y 3.000 por mes). Se puede ajustar con
// RESEND_LIMITE_DIARIO / RESEND_LIMITE_MENSUAL (0 = sin límite, por ejemplo con el plan Pro).
// Al pasar el 80% queda una alerta en el panel (Estado del sistema) y un email al admin, una vez
// por día.
export async function contarEnviosEmail(cantidad: number): Promise<void> {
  const supabase = getServerSupabase();
  if (!supabase || cantidad <= 0) return;
  const { data } = await supabase.rpc('sumar_envios_email', { p_cantidad: cantidad });
  const fila = Array.isArray(data) ? data[0] : data;
  if (!fila) return;
  const limiteDia = Number(process.env.RESEND_LIMITE_DIARIO ?? 100);
  const limiteMes = Number(process.env.RESEND_LIMITE_MENSUAL ?? 3000);
  const hoy = Number(fila.hoy) || 0;
  const mes = Number(fila.mes) || 0;
  const cercaDia = limiteDia > 0 && hoy >= limiteDia * 0.8;
  const cercaMes = limiteMes > 0 && mes >= limiteMes * 0.8;
  if (!cercaDia && !cercaMes) return;
  const dia = new Date().toLocaleDateString('en-CA', { timeZone: 'America/Argentina/Buenos_Aires' });
  const clave = `cupo-email:${dia}`;
  const { data: existentes, error: errorExistentes } = await supabase.from('reportes_errores').select('id').eq('detalle->>clave', clave).limit(1);
  if (errorExistentes || (existentes && existentes.length > 0)) return;
  const mensaje = cercaDia
    ? `Se enviaron ${hoy} emails hoy (cupo diario de Resend: ${limiteDia}). Si se llega al límite, los códigos de acceso y las descargas dejan de salir hasta mañana.`
    : `Se enviaron ${mes} emails en los últimos 30 días (cupo mensual de Resend: ${limiteMes}).`;
  const { error: errorMarca } = await supabase.from('reportes_errores').insert({
    codigo: `EMAIL-${Math.random().toString(36).slice(2, 7).toUpperCase()}`,
    origen: 'admin',
    mensaje: `${mensaje} Conviene pasar a Resend Pro.`,
    detalle: { clave, tipo: 'cupo_email', hoy, mes, limiteDia, limiteMes },
  });
  // Auditoría 11/10: sin la marca no se avisa, y el aviso sale con un cliente que no cuenta (antes cada
  // aviso volvía a contarse y, si la marca no se guardaba, disparaba otro aviso sin fin).
  if (errorMarca) return;
  const apiKey = process.env.RESEND_API_KEY?.trim();
  if (apiKey) {
    await new Resend(apiKey).emails.send({
      from: process.env.RESEND_FROM_EMAIL || 'Retrato Escolar <fotos@retratoescolar.com.ar>',
      to: [casillaAvisosAdmin()],
      subject: '⚠️ Te estás quedando sin cupo de emails (Resend)',
      html: `<div style="font-family:Arial,sans-serif;max-width:600px;margin:auto;color:#0f172a"><p>${escapeHtml(mensaje)}</p><p>Para no cortar los envíos a las familias, pasá a Resend Pro desde resend.com → Settings → Billing. Si ya tenés el plan Pro, cargá RESEND_LIMITE_DIARIO=0 y RESEND_LIMITE_MENSUAL=0 en Vercel para apagar este aviso.</p></div>`,
    });
  }
}

// Las respuestas de las familias pueden llegar a una cuenta de Resend distinta de la que envía
// (el dominio de envío está verificado en una cuenta y el de recepción en otra). Si está
// configurada RESEND_INBOUND_API_KEY (clave con permiso "Full access" de la cuenta que recibe),
// se usa sólo para leer los correos recibidos; si no, se usa la misma clave de envío.
export function getResendInboundClient(): Resend | null {
  const apiKey = process.env.RESEND_INBOUND_API_KEY?.trim();
  return apiKey ? new Resend(apiKey) : getResendClient();
}

// Auditoría 2026-09-26: "responder a" de los emails que reciben las familias. Antes era el Gmail
// del negocio (las respuestas quedaban fuera del panel); ahora es la dirección pública de
// contacto, que entra al panel como consulta (ver registrarConsultaPorEmail).
export const resendReplyTo = process.env.RESEND_REPLY_TO_EMAIL || 'contacto@retratoescolar.com.ar';

// Casilla donde le llegan a Pablo los avisos internos (consultas nuevas, comprobantes, errores).
export function casillaAvisosAdmin(): string {
  // 28/9 (pedido de Pablo): todos los avisos llegan a Zoho, la misma casilla donde se reenvían los
  // correos y adjuntos de las familias (CASILLA_REENVIO_ENTRANTE). Se puede cambiar con CONSULTAS_EMAIL.
  return process.env.CONSULTAS_EMAIL || CASILLA_REENVIO_ENTRANTE;
}

// Lazy client para Supabase con Service Role Key (Backend seguro)
let serverSupabaseInstance: SupabaseClient | null = null;

export function getServerSupabase(): SupabaseClient | null {
  const url = process.env.SUPABASE_URL || process.env.VITE_SUPABASE_URL || 'https://ntkqypxvrljuihbxdrtx.supabase.co';
  // Auditoría 2026-09-26 (B5): antes, si faltaba la Service Role Key, se caía en silencio a la
  // clave anónima — el servidor seguía "andando" pero cada consulta devolvía vacío o fallaba por
  // RLS, con errores engañosos. Ahora exige la Service Role Key: sin ella, el servidor responde
  // "Supabase no configurado" y el problema se ve de inmediato.
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!url || !key) {
    console.error('[Supabase] Falta SUPABASE_SERVICE_ROLE_KEY en las variables de entorno del servidor.');
    return null;
  }
  if (!serverSupabaseInstance) {
    serverSupabaseInstance = createClient(url, key.trim(), {
      auth: { persistSession: false, autoRefreshToken: false },
    });
  }
  return serverSupabaseInstance;
}

// Lazy client para Mercado Pago
export function getMercadoPagoConfig(): MercadoPagoConfig | null {
  const token = process.env.MERCADOPAGO_ACCESS_TOKEN;
  if (!token || token.trim() === '') {
    return null;
  }
  return new MercadoPagoConfig({ accessToken: token.trim() });
}

// NAVE (Banco Galicia) — segundo medio de pago, sumado el 15/9/2026 a pedido de Pablo.
// Documentación real relevada ese día (portal de desarrolladores de Nave, sección "Checkout"):
// autenticación tipo OAuth2 client_credentials contra un servicio propio (no hay SDK server-side
// oficial, se llama con fetch directo), creación de una "intención de pago" que devuelve un
// checkout_url hosteado + un qr_data, y notificación asíncrona por webhook. A diferencia de
// Resend, Nave NO firma sus webhooks (no hay ningún esquema HMAC documentado) — por eso el
// webhook de acá abajo nunca confía en el estado que venga en el POST: siempre reconsulta el
// pago con un GET propio (con nuestro access_token) antes de tocar la base.
export const NAVE_AUTH_AUDIENCE = 'https://naranja.com/ranty/merchants/api';

export function getNaveEntorno(): 'sandbox' | 'production' {
  return (process.env.NAVE_ENVIRONMENT || 'sandbox').trim().toLowerCase() === 'production'
    ? 'production'
    : 'sandbox';
}

// URLs reales tomadas de la documentación de Nave (15/9/2026) — ver auditoría arriba.
export function getNaveUrls() {
  const esSandbox = getNaveEntorno() === 'sandbox';
  return {
    auth: esSandbox
      ? 'https://homoservices.apinaranja.com/security-ms/api/security/auth0/b2b/m2msPrivate'
      : 'https://services.apinaranja.com/security-ms/api/security/auth0/b2b/m2msPrivate',
    crearIntencion: esSandbox
      ? 'https://api-sandbox.ranty.io/api/payment_request/ecommerce'
      : 'https://api.ranty.io/api/payment_request/ecommerce',
    // Base para "recuperar un pago" (GET .../ranty-payments/payments/{payment_id}) — se arma acá
    // en vez de usar el "payment_check_url" que manda la notificación tal cual, para no confiar
    // en una URL que viene en un POST sin firma (ver comentario del webhook más abajo).
    pagos: esSandbox
      ? 'https://api-sandbox.ranty.io/ranty-payments/payments'
      : 'https://api.ranty.io/ranty-payments/payments',
    intenciones: esSandbox
      ? 'https://api-sandbox.ranty.io/api/payment_requests'
      : 'https://api.ranty.io/api/payment_requests',
  };
}

export function getNaveCredenciales(): { clientId: string; clientSecret: string; posId: string } | null {
  const clientId = process.env.NAVE_CLIENT_ID?.trim();
  const clientSecret = process.env.NAVE_CLIENT_SECRET?.trim();
  const posId = process.env.NAVE_POS_ID?.trim();
  if (!clientId || !clientSecret || !posId) return null;
  return { clientId, clientSecret, posId };
}

// Auditoría 2026-09-26 (C1, CRÍTICO): Nave sólo cobra de verdad en producción. En sandbox acepta
// tarjetas de PRUEBA y devuelve pagos "aprobados" — antes el portal sólo escondía el botón, pero
// los endpoints seguían vivos: alguien podía crear la intención a mano, pagar con una tarjeta de
// prueba y el webhook/conciliación dejaba el pedido "pagado" de verdad (HD gratis + kit impreso al
// laboratorio). Ahora TODO lo de Nave (crear intención, webhook, conciliación) exige producción.
export function naveHabilitado(): boolean {
  return getNaveEntorno() === 'production' && Boolean(getNaveCredenciales());
}

// Cache en memoria del access_token de Nave (dura 24hs según "expires_in") — no hace falta
// persistirlo: si el proceso del servidor se reinicia, se pide uno nuevo sin drama. Se guarda con
// 60s de margen para no arriesgarse a usarlo justo cuando expira.
let naveTokenCache: { token: string; expiraEn: number; entorno: string } | null = null;

// Crear la intención de pago en Nave con UN reintento automático. Caso real (25/9): Nave respondió
// 502 sin cuerpo al primer intento y la familia esperó ~20 s y tuvo que tocar el botón de nuevo; el
// segundo intento funcionó. Se reintenta sólo ante errores del lado de Nave (5xx / red / demora
// mayor a 15 s), nunca ante un 4xx (datos rechazados), para no duplicar nada.
export async function crearIntencionNaveConReintento(url: string, accessToken: string, body: unknown): Promise<{ resp: globalThis.Response | null; data: any }> {
  let ultimo: { resp: globalThis.Response | null; data: any } = { resp: null, data: null };
  for (let intento = 1; intento <= 2; intento++) {
    const controlador = new AbortController();
    const temporizador = setTimeout(() => controlador.abort(), 15000);
    try {
      const resp = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${accessToken}` },
        body: JSON.stringify(body),
        signal: controlador.signal,
      });
      const data: any = await resp.json().catch(() => null);
      ultimo = { resp, data };
      if (resp.ok && data?.checkout_url) return ultimo;
      if (resp.status < 500) return ultimo;
      console.warn(`[Nave] Intento ${intento} de crear la intención falló con ${resp.status}.`);
    } catch (err) {
      console.warn(`[Nave] Intento ${intento} de crear la intención falló (red/demora):`, err);
    } finally {
      clearTimeout(temporizador);
    }
    if (intento === 1) await new Promise((resolve) => setTimeout(resolve, 800));
  }
  return ultimo;
}

export async function obtenerNaveAccessToken(): Promise<string | null> {
  const credenciales = getNaveCredenciales();
  if (!credenciales) return null;
  const entorno = getNaveEntorno();
  if (naveTokenCache && naveTokenCache.entorno === entorno && naveTokenCache.expiraEn > Date.now()) {
    return naveTokenCache.token;
  }
  try {
    const { auth } = getNaveUrls();
    const resp = await fetch(auth, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        client_id: credenciales.clientId,
        client_secret: credenciales.clientSecret,
        audience: NAVE_AUTH_AUDIENCE,
      }),
      signal: AbortSignal.timeout(8000),
    });
    if (!resp.ok) {
      console.error('[Nave] Error al obtener access_token:', resp.status, await resp.text().catch(() => ''));
      return null;
    }
    const data: any = await resp.json();
    if (!data?.access_token) return null;
    const expiresInSeg = Number(data.expires_in) || 3600;
    naveTokenCache = {
      token: data.access_token,
      expiraEn: Date.now() + Math.max(0, expiresInSeg - 60) * 1000,
      entorno,
    };
    return naveTokenCache.token;
  } catch (err) {
    console.error('[Nave] Error de red al pedir access_token:', err);
    return null;
  }
}

// Auditoría 03/10 (alto 14): ninguna llamada a Nave queda colgada más de 8 s (antes sin timeout,
// una Nave lenta dejaba la consulta de estado o el webhook esperando hasta los 60 s de Vercel).
export function fetchNave(url: string, init: RequestInit = {}, ms = 8000) {
  return fetch(url, { ...init, signal: AbortSignal.timeout(ms) });
}
