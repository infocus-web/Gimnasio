// Precios vigentes del sitio: los de la tabla `configuracion` (clave 'precios_kits'), releídos como
// mucho una vez por minuto por instancia, o PRECIOS_POR_DEFECTO si la base no responde (división de
// server.ts, etapa 1, 10/10/2026). El código es el mismo que estaba en server.ts (al principio y en
// la sección 7): sólo se movió de lugar. El estado (hora de la última lectura, si ya se leyó de la
// base) vive acá adentro; desde afuera se cambia sólo con aplicarPrecios() y marcarPreciosGuardados().
// PRECIO_CARPETA_EXTRA y PRECIO_FOTO_EVENTO se exportan como `let`: quien los importa ve siempre el
// valor actual (los imports de ESM son "en vivo"), pero sólo este archivo los puede cambiar.
import type { NextFunction, Request, Response } from 'express';
import { getServerSupabase } from './clientes.js';

export interface PreciosSitio {
  kitClasico: number;
  kitDigital: number;
  carpetaExtra: number;
  fotoEvento: number;
  /** 29/10/2026: fotos extra (pedido aparte después de pagar el kit, servidor/nucleo/fotosExtra.ts). */
  extra15x21: number;
  extra20x30: number;
}

export const PRECIOS_POR_DEFECTO: PreciosSitio = { kitClasico: 30000, kitDigital: 15000, carpetaExtra: 15000, fotoEvento: 5000, extra15x21: 5000, extra20x30: 8000 };
// 29/10/2026: claves nuevas. Los precios guardados antes no las tienen: se toma el valor por defecto (si no,
// validarPrecios rechazaba la fila entera y el sitio volvía a TODOS los precios por defecto).
const CLAVES_CON_DEFECTO: (keyof PreciosSitio)[] = ['extra15x21', 'extra20x30'];

let preciosLeidosAt = 0;

export function validarPrecios(entrada: any): PreciosSitio | null {
  if (!entrada || typeof entrada !== 'object') return null;
  const salida: any = {};
  for (const clave of Object.keys(PRECIOS_POR_DEFECTO) as (keyof PreciosSitio)[]) {
    const sinValor = entrada[clave] === undefined || entrada[clave] === null || entrada[clave] === '';
    const n = sinValor && CLAVES_CON_DEFECTO.includes(clave) ? PRECIOS_POR_DEFECTO[clave] : Number(entrada[clave]);
    if (!Number.isInteger(n) || n < 1000 || n > 1000000) return null;
    salida[clave] = n;
  }
  if (salida.kitClasico <= salida.kitDigital) return null; // la mejora a impreso tiene que costar algo
  return salida as PreciosSitio;
}

// Auditoría 03/10 noche (M7): antes la hora de lectura se marcaba ANTES de leer, así que los requests
// que llegaban mientras tanto a una instancia nueva (o todos, si la lectura fallaba) cobraban los
// precios por defecto durante un minuto. Ahora todos esperan la misma lectura, y hasta que una
// lectura salga bien las rutas que registran pedidos responden 503 (ver exigirPreciosCargados).
let preciosCargadosDeLaBase = false;

let cargaPreciosEnCurso: Promise<void> | null = null;

export async function asegurarPreciosActualizados(): Promise<void> {
  if (Date.now() - preciosLeidosAt < 60 * 1000) return;
  // Revisión 03/10 noche: si la instancia ya tiene precios leídos, la relectura de cada minuto va en
  // segundo plano (no frena webhooks, /status ni la galería mientras tanto).
  if (cargaPreciosEnCurso) return preciosCargadosDeLaBase ? undefined : cargaPreciosEnCurso;
  cargaPreciosEnCurso = (async () => {
    try {
      const supabase = getServerSupabase();
      if (!supabase) return;
      const { data, error } = await supabase.from('configuracion').select('datos_extra').eq('clave', 'precios_kits').abortSignal(AbortSignal.timeout(4000)).maybeSingle();
      if (error) throw error;
      const guardados = validarPrecios(data?.datos_extra);
      if (guardados) aplicarPrecios(guardados);
      preciosLeidosAt = Date.now();
      preciosCargadosDeLaBase = true;
    } catch (e) {
      // Se reintenta a los 10 s (no en cada request) y se siguen usando los últimos precios leídos.
      preciosLeidosAt = Date.now() - 50 * 1000;
      throw e;
    } finally {
      cargaPreciosEnCurso = null;
    }
  })();
  if (preciosCargadosDeLaBase) {
    cargaPreciosEnCurso.catch(() => undefined);
    return;
  }
  return cargaPreciosEnCurso;
}

/** Auditoría 03/10 noche (M7): no se registra nada con precios que no salieron de la base. */
export function exigirPreciosCargados(_req: Request, res: Response, next: NextFunction) {
  if (preciosCargadosDeLaBase) return next();
  return res.status(503).json({ success: false, error: 'Estamos actualizando los precios. Probá de nuevo en unos segundos.' });
}

// Precios oficiales de cada kit (deben coincidir siempre con src/data/colegiosData.ts —
// KITS_DISPONIBLES). Es la fuente de verdad del lado del servidor: antes el monto a cobrar
// (unit_price) se armaba directamente con el "total" que mandaba el navegador, sin volver a
// calcularlo acá. Cualquiera podía interceptar el pedido a este endpoint (sin login, es la
// creación de la preferencia de pago) y cambiar "total" a $1 antes de que Mercado Pago generara
// el link de cobro — el pago hubiera sido válido por ese monto. Ver auditoría 2026-09-09.
export const PRECIOS_KITS: Record<string, number> = {
  'kit-clasico': PRECIOS_POR_DEFECTO.kitClasico,
  'kit-digital': PRECIOS_POR_DEFECTO.kitDigital,
  'kit-evento-suelto': PRECIOS_POR_DEFECTO.fotoEvento,
};

export let PRECIO_CARPETA_EXTRA = PRECIOS_POR_DEFECTO.carpetaExtra;

// Auditoría 2026-09-19 (bug real encontrado en auditoría de código, CRÍTICO): precio por cada
// "Otra Foto" suelta del evento (fuera del kit) — debe coincidir siempre con
// PRECIO_FOTO_EVENTO en PortalFamiliasModal.tsx. Antes esta constante no existía del lado del
// servidor: el frontend mostraba estas fotos como cobradas en el total que la familia veía,
// pero ningún endpoint las sumaba al monto real, así que se cobraba de menos (o directamente
// $0 extra) por fotos que la familia sí recibía.
export let PRECIO_FOTO_EVENTO = PRECIOS_POR_DEFECTO.fotoEvento;
let preciosFotosExtra = { extra15x21: PRECIOS_POR_DEFECTO.extra15x21, extra20x30: PRECIOS_POR_DEFECTO.extra20x30 };
/** 29/10/2026: precio de cada copia de las fotos extra (15x21 y 20x30), leído en vivo. */
export function preciosFotosExtraActuales() {
  return { ...preciosFotosExtra };
}

// Auditoría 28/9 ("un solo lugar para los precios"): los precios se guardan en la tabla
// `configuracion` (clave 'precios_kits', columna datos_extra) y se editan desde el panel
// (Configuración → Precios). El sitio los lee de GET /api/precios; los emails, la IA y el cobro
// usan preciosActuales(). Si la fila no existe o falla la lectura, quedan los de PRECIOS_POR_DEFECTO.
export function aplicarPrecios(p: PreciosSitio) {
  PRECIOS_KITS['kit-clasico'] = p.kitClasico;
  PRECIOS_KITS['kit-digital'] = p.kitDigital;
  PRECIOS_KITS['kit-evento-suelto'] = p.fotoEvento;
  PRECIO_CARPETA_EXTRA = p.carpetaExtra;
  PRECIO_FOTO_EVENTO = p.fotoEvento;
  preciosFotosExtra = { extra15x21: p.extra15x21, extra20x30: p.extra20x30 };
}

export function preciosActuales(): PreciosSitio {
  return {
    kitClasico: PRECIOS_KITS['kit-clasico'],
    kitDigital: PRECIOS_KITS['kit-digital'],
    carpetaExtra: PRECIO_CARPETA_EXTRA,
    fotoEvento: PRECIO_FOTO_EVENTO,
    ...preciosFotosExtra,
  };
}

export function precioMejoraAImpreso(): number {
  return PRECIOS_KITS['kit-clasico'] - PRECIOS_KITS['kit-digital'];
}

// Después de guardar precios nuevos desde el panel (POST /api/admin/precios, en server.ts): ya quedaron
// aplicados en esta instancia, así que no hace falta releerlos de la base por un minuto. (Antes eran
// dos asignaciones sueltas en esa ruta: `preciosLeidosAt = Date.now(); preciosCargadosDeLaBase = true;`.)
export function marcarPreciosGuardados() {
  preciosLeidosAt = Date.now();
  preciosCargadosDeLaBase = true;
}
