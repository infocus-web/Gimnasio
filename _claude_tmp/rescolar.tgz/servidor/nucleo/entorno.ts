// Carga el .env de la compu ANTES que cualquier otro módulo del servidor (división de server.ts,
// etapa 1, 10/10/2026). Los módulos de servidor/nucleo leen variables de entorno al cargarse (por
// ejemplo CASILLA_REENVIO_ENTRANTE), y en los módulos ES los imports se evalúan antes que el cuerpo
// del archivo que los importa: por eso `dotenv.config()` ya no puede quedar en el cuerpo de
// server.ts. Es el primer import de server.ts y de cada módulo del núcleo que lee el entorno al
// cargarse. En Vercel no hay .env (las variables vienen del panel) y esto no cambia nada.
import dotenv from 'dotenv';

dotenv.config();
