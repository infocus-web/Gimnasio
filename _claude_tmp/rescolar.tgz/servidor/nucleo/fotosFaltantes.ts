// 22/10/2026 (Pablo): «si un alumno le falta una foto (no quiso o no estaba el día de la toma), no podrá
// terminar el pedido». La familia puede avisar en la galería que a su hijo/a le falta una de las fotos del
// pack («Mi hijo/a no tiene esta foto») y, en ese lugar, elegir OTRA foto del curso o seguir sin ella. El
// precio no cambia. En el pedido queda en `fotos_seleccionadas.sinFoto` (lista de lugares: 'individual',
// 'grupal', 'docente' = 3ª foto); el id de ese lugar queda vacío (sin foto) o con la foto que la reemplaza,
// de cualquier categoría del curso. Debe coincidir con src/utils/fotosFaltantes.ts.
import { esCategoriaTerceraFoto } from './pedidos.js';
import { finDelDia, plazosVigentes } from './plazosTemporada.js';

export type LugarPack = 'individual' | 'grupal' | 'docente';
export const LUGARES_PACK: readonly LugarPack[] = ['individual', 'grupal', 'docente'];

/** Los lugares del pack que la familia marcó «no tiene esta foto» (sin repetidos, sólo valores válidos). */
export function lugaresSinFoto(seleccion: unknown): LugarPack[] {
  const lista = (seleccion as any)?.sinFoto;
  if (!Array.isArray(lista)) return [];
  return LUGARES_PACK.filter((lugar) => lista.includes(lugar));
}

/** Si una foto de esta categoría puede ir en ese lugar del pack (en un lugar «sin foto», cualquiera del curso). */
export function categoriaValeEnLugar(categoria: unknown, lugar: LugarPack, sinFoto: readonly LugarPack[]): boolean {
  if (typeof categoria !== 'string' || !categoria) return false;
  if (sinFoto.includes(lugar)) return categoria !== 'patio'; // las sueltas se venden aparte
  if (lugar === 'docente') return esCategoriaTerceraFoto(categoria);
  return categoria === lugar;
}

/** Cómo se llama el archivo de un lugar del pack en el .zip HD (la 3ª foto según su categoría). */
export function nombreArchivoLugar(lugar: LugarPack, categoria: unknown, reemplazo: boolean): string {
  if (reemplazo) return { individual: 'En_lugar_de_la_individual.jpg', grupal: 'En_lugar_de_la_grupal.jpg', docente: 'En_lugar_de_la_tercera.jpg' }[lugar];
  if (lugar === 'docente') return categoria === 'familia' ? 'Con_familia_y_amigos.jpg' : 'Con_la_seño.jpg';
  return lugar === 'individual' ? 'Individual.jpg' : 'Grupal.jpg';
}

// 22/10/2026 (Pablo): «Faltantes solicitadas». La familia puede pedir que le saquen (o busquen) la foto que falta
// hasta el 15/11/2026 inclusive (hora de Argentina). Debe coincidir con src/utils/fotosFaltantes.ts.
// 30/10/2026: la fecha se edita desde el panel → Configuración (servidor/nucleo/plazosTemporada.ts).
export const MOTIVOS_FALTANTE = ['ausente', 'no_quiso', 'no_encontrada'] as const;
export type MotivoFaltante = (typeof MOTIVOS_FALTANTE)[number];
export function solicitudFaltanteAbierta(ahora: Date = new Date()): boolean {
  return ahora.getTime() <= finDelDia(plazosVigentes().faltantes);
}
