// 17/10/2026: originales en Google Drive (servidor/nucleo/googleDrive.ts).
import crypto from 'crypto';
import { afterEach, describe, expect, it, vi } from 'vitest';
import { descargarDeDrive, driveConfigurado, idCarpetaDrive, listarFotosDeCarpeta, olvidarCredencialesDrive } from '../googleDrive';

const { privateKey, publicKey } = crypto.generateKeyPairSync('rsa', { modulusLength: 2048 });
const CLAVE = privateKey.export({ type: 'pkcs8', format: 'pem' }).toString();

function conCredenciales() {
  process.env.GOOGLE_SERVICE_ACCOUNT_JSON = JSON.stringify({ client_email: 'cuenta@proyecto.iam.gserviceaccount.com', private_key: CLAVE, token_uri: 'https://oauth2.googleapis.com/token' });
  olvidarCredencialesDrive();
}

afterEach(() => {
  delete process.env.GOOGLE_SERVICE_ACCOUNT_JSON;
  olvidarCredencialesDrive();
  vi.unstubAllGlobals();
});

describe('Google Drive', () => {
  it('saca el id de la carpeta de un link (o lo acepta tal cual)', () => {
    expect(idCarpetaDrive('https://drive.google.com/drive/folders/1jYVWZ5sTOQJGUcVfnuhbFzYdiF4NNcVW?usp=sharing')).toBe('1jYVWZ5sTOQJGUcVfnuhbFzYdiF4NNcVW');
    expect(idCarpetaDrive('https://drive.google.com/open?id=1jYVWZ5sTOQJGUcVfnuhbFzYdiF4NNcVW')).toBe('1jYVWZ5sTOQJGUcVfnuhbFzYdiF4NNcVW');
    expect(idCarpetaDrive('1jYVWZ5sTOQJGUcVfnuhbFzYdiF4NNcVW')).toBe('1jYVWZ5sTOQJGUcVfnuhbFzYdiF4NNcVW');
    expect(idCarpetaDrive("x' or name contains 'a")).toBeNull();
    expect(idCarpetaDrive('')).toBeNull();
  });

  it('sin la variable de Vercel no está configurado', () => {
    olvidarCredencialesDrive();
    expect(driveConfigurado()).toBe(false);
    conCredenciales();
    expect(driveConfigurado()).toBe(true);
  });

  it('pide el token con un JWT firmado y lista sólo los JPG, ordenados por número', async () => {
    conCredenciales();
    const llamadas: string[] = [];
    vi.stubGlobal('fetch', vi.fn(async (url: string, op?: any) => {
      llamadas.push(url);
      if (url.startsWith('https://oauth2.googleapis.com/token')) {
        const jwt = String(new URLSearchParams(op.body).get('assertion'));
        const [c, b, f] = jwt.split('.');
        const ok = crypto.createVerify('RSA-SHA256').update(`${c}.${b}`).verify(publicKey, Buffer.from(f.replace(/-/g, '+').replace(/_/g, '/'), 'base64'));
        expect(ok).toBe(true);
        expect(JSON.parse(Buffer.from(b, 'base64').toString()).scope).toContain('drive.readonly');
        return new Response(JSON.stringify({ access_token: 'tok', expires_in: 3600 }), { status: 200 });
      }
      return new Response(JSON.stringify({ files: [
        { id: 'a1234567890', name: 'FOTO-10.jpg', size: '100', mimeType: 'image/jpeg' },
        { id: 'b1234567890', name: 'FOTO-9.JPG', size: '100', mimeType: 'image/jpeg' },
        { id: 'c1234567890', name: 'notas.txt', size: '1', mimeType: 'text/plain' },
      ] }), { status: 200 });
    }));
    const fotos = await listarFotosDeCarpeta('1jYVWZ5sTOQJGUcVfnuhbFzYdiF4NNcVW');
    expect(fotos.map((f) => f.nombre)).toEqual(['FOTO-9.JPG', 'FOTO-10.jpg']);
    // el token se reusa: una sola vez al servidor de Google
    await listarFotosDeCarpeta('1jYVWZ5sTOQJGUcVfnuhbFzYdiF4NNcVW');
    expect(llamadas.filter((u) => u.includes('oauth2')).length).toBe(1);
  });

  it('si el original ya no está en Drive, falla sin reintentar y lo marca como definitivo', async () => {
    conCredenciales();
    let bajadas = 0;
    vi.stubGlobal('fetch', vi.fn(async (url: string) => {
      if (url.includes('oauth2')) return new Response(JSON.stringify({ access_token: 'tok', expires_in: 3600 }), { status: 200 });
      bajadas++;
      return new Response('no', { status: 404 });
    }));
    await expect(descargarDeDrive('a1234567890')).rejects.toMatchObject({ definitivo: true });
    expect(bajadas).toBe(1);
  });
});
