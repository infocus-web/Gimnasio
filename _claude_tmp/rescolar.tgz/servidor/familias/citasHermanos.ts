// 26/10/2026: día y horario de la foto de hermanos asignados a cada familia en la última citación repartida
// (Emails → Citación con «Repartir en varios días»; quedan en envios_email.contenido.citas, por email).
// Lo usan el Excel y el panel del colegio (fotoHermanos.ts) y la ficha de la IA de consultas (fichaFamiliaExtra.ts).
import type { SupabaseClient } from '@supabase/supabase-js';

export type CitaHermanos = { dia: string; hora: string };

export async function citasUltimaCitacion(supabase: SupabaseClient): Promise<Record<string, CitaHermanos>> {
  // Se filtra acá (no con `.not('contenido->citas', …)`) para que ande igual en cualquier base.
  const { data } = await supabase.from('envios_email').select('contenido, creado_at').eq('tipo', 'citacion').order('creado_at', { ascending: false }).limit(10);
  const envio = (data || []).find((e: any) => e?.contenido?.citas && typeof e.contenido.citas === 'object' && Object.keys(e.contenido.citas).length > 0);
  const citas = envio?.contenido?.citas || {};
  return Object.fromEntries(Object.entries(citas).map(([email, c]: [string, any]) => [email.trim().toLowerCase(), { dia: String(c?.dia || ''), hora: String(c?.hora || '') }]));
}

/** «2026-10-29» → «jueves 29 de octubre». */
export function diaLargoCita(dia: string): string {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(dia)) return dia;
  return new Date(`${dia}T12:00:00-03:00`).toLocaleDateString('es-AR', { weekday: 'long', day: 'numeric', month: 'long', timeZone: 'America/Argentina/Buenos_Aires' }).replace(',', '');
}
