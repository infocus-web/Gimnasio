// «Faltantes solicitadas» (22/10/2026, pedido de Pablo). Cuando a un chico le falta una foto del pack, la familia
// (en la galería, después de marcar «Mi hijo/a no tiene esta foto») puede pedir que se la saquen, o que la busquen si
// se la sacaron y no aparece. Antes de enviar contesta qué pasó (no estuvo / no quiso / se la sacaron y no aparece):
// Pablo: a la familia no se le menciona nada sobre repetir una foto que no le gustó. Hasta el 15/11/2026 (FECHA_LIMITE_FALTANTES).
// Mientras el pedido de foto está pendiente, el kit de ese chico no se cierra sin esa foto (validarSeleccionFotos en
// servidor/pagos/crearPedido.ts usa `faltantePendienteQueFrena`). Pablo los ve en la pestaña «Faltantes» del panel;
// con «Ya está la foto» se marca resuelto y le llega un mail a la familia para que entre a elegirla.
// Tabla `fotos_faltantes_solicitudes` (migración 20261022150000). Detalle: claude/foto-faltante-2026-10-22.md.
import type { SupabaseClient } from '@supabase/supabase-js';
import crypto from 'crypto';
import express from 'express';
import type { Request, Response } from 'express';
import { requireAdminAuth } from '../nucleo/auth.js';
import { getResendClient, getServerSupabase, resendReplyTo } from '../nucleo/clientes.js';
import { buscarSeccionPorCodigoSecreto, determinarCodigoCursoServidor } from '../nucleo/codigosCurso.js';
import { categoriaValeEnLugar, LUGARES_PACK, MOTIVOS_FALTANTE, solicitudFaltanteAbierta, type LugarPack, type MotivoFaltante } from '../nucleo/fotosFaltantes.js';
import { limitarFrecuencia } from '../nucleo/limites.js';
import { asegurarPlazosActualizados, plazosVigentes, textoFechaLarga } from '../nucleo/plazosTemporada.js';
import { nombresCompatibles } from '../nucleo/nombres.js';
import { escapeHtml, traerTodasLasFilas } from '../nucleo/utilidades.js';
import { hijosQueSonElAlumno } from '../pagos/crearPedido.js';
import { mismoAlumno, NOMBRE_LUGAR_FALTANTE, TABLA_FALTANTES, tablaFaltantesNoExiste } from './faltantesPendientes.js';
import { hijosDeFamiliaConAcceso } from './inscripciones.js';

const rutas = express.Router();
const TABLA = TABLA_FALTANTES;
const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const CLAVE_RE = /^[A-Za-z0-9-]{8,64}$/;
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const COLUMNAS_FAMILIA = 'id, alumno_nombre, lugar, motivo, estado, created_at, convocatoria_dia, convocatoria_hora, convocatoria_lugar';
const COLUMNAS_ADMIN =
  'id, created_at, colegio_id, codigo_curso, grado, division, turno, alumno_nombre, lugar, motivo, tutor_nombre, contacto_email, contacto_whatsapp, nomina_tiene_foto, estado, resuelta_at, cancelada_at, cancelada_por, aviso_enviado_at, convocatoria_dia, convocatoria_hora, convocatoria_lugar, convocatoria_nota, convocada_at';
const COLUMNA_NOMINA: Record<LugarPack, string> = { individual: 'fotografiado_at', grupal: 'foto_grupal_at', docente: 'foto_seno_at' };
const ERROR_ACCESO = 'Para pedir la foto tenés que ingresar a la galería con los datos de tu familia (DNI del tutor). Volvé a ingresar e intentá de nuevo.';

/**
 * Sección + el chico de la familia (revisión 22/10): la llave de galería tiene que ser de una inscripción de ESE colegio,
 * el chico tiene que ser uno de sus hijos que esté en ESE curso, y se usa su nombre de la inscripción (nunca el texto
 * del navegador). Mismo criterio que la reserva: `hijosQueSonElAlumno` (exacto, o parecido sólo si nadie más del curso
 * coincide mejor). null = sin acceso.
 */
export async function familiaYCurso(supabase: SupabaseClient, cuerpo: any, alumno: unknown): Promise<{ colegioId: string; codigoCurso: string; seccion: { grado: string; turno: string; division: string }; hijo: string } | null> {
  const seccion = await buscarSeccionPorCodigoSecreto(supabase, String(cuerpo?.codigo || ''));
  if (!seccion) return null;
  const hijos = await hijosDeFamiliaConAcceso(supabase, cuerpo?.familia, cuerpo?.acceso);
  if (!hijos || hijos.length === 0) return null;
  const codigoCurso = determinarCodigoCursoServidor(seccion.grado, seccion.turno, seccion.division);
  const candidatos = await hijosQueSonElAlumno(supabase, cuerpo?.familia, hijos, alumno, seccion.colegioId, codigoCurso);
  if (candidatos.length === 0) return null;
  const { data: insc, error } = await supabase
    .from('inscripciones')
    .select('colegio_id, alumno_nombre, alumno_apellido, grado, turno, division, hermanos')
    .eq('id', String(cuerpo?.familia || ''))
    .maybeSingle();
  if (error || !insc || String(insc.colegio_id || '') !== String(seccion.colegioId)) return null;
  const chicos = [
    { nombre: `${insc.alumno_nombre || ''} ${insc.alumno_apellido || ''}`, grado: insc.grado, turno: insc.turno, division: insc.division },
    ...(Array.isArray(insc.hermanos) ? insc.hermanos : []).map((h: any) => ({ nombre: `${h?.alumnoNombre || ''} ${h?.alumnoApellido || ''}`, grado: h?.grado, turno: h?.turno, division: h?.division })),
  ];
  const hijo = chicos.find(
    (c) => candidatos.some((n) => mismoAlumno(n, c.nombre)) && (!c.grado || determinarCodigoCursoServidor(String(c.grado), String(c.turno || ''), String(c.division || '')) === codigoCurso)
  );
  if (!hijo) return null;
  return { colegioId: seccion.colegioId, codigoCurso, seccion, hijo: hijo.nombre.trim().replace(/\s+/g, ' ') };
}

/** Si la nómina tiene tildada esa foto para ese chico (una sola coincidencia por nombre en el colegio). */
async function nominaDelAlumno(supabase: SupabaseClient, colegioId: string, alumno: string, lugar: LugarPack): Promise<{ id: string | null; tieneFoto: boolean | null }> {
  try {
    const filas = await traerTodasLasFilas<any>((desde, hasta) =>
      supabase.from('alumnos').select('id, nombre, fotografiado_at, foto_grupal_at, foto_seno_at').eq('colegio_id', colegioId).order('id').range(desde, hasta)
    );
    const coinciden = filas.filter((a) => a.nombre && nombresCompatibles(a.nombre, alumno));
    if (coinciden.length !== 1) return { id: null, tieneFoto: null };
    return { id: coinciden[0].id, tieneFoto: Boolean(coinciden[0][COLUMNA_NOMINA[lugar]]) };
  } catch (err: any) {
    console.warn('[faltantes] No se pudo cruzar con la nómina:', err?.message || err);
    return { id: null, tieneFoto: null };
  }
}

// ---------------------------------------------------------------------------------------------
// Familias
// ---------------------------------------------------------------------------------------------
rutas.post('/api/fotos-faltantes/estado', limitarFrecuencia('fotos-faltantes-estado', 120, 10 * 60 * 1000), async (req: Request, res: Response) => {
  try {
    const supabase = getServerSupabase();
    if (!supabase) return res.status(503).json({ success: false, error: 'Servicio no disponible' });
    const acceso = await familiaYCurso(supabase, req.body, String(req.body?.alumnoNombre || '').slice(0, 200));
    if (!acceso) return res.status(403).json({ success: false, error: ERROR_ACCESO });
    const { data, error } = await supabase
      .from(TABLA)
      .select(COLUMNAS_FAMILIA)
      .eq('colegio_id', acceso.colegioId)
      .eq('codigo_curso', acceso.codigoCurso)
      .eq('estado', 'pendiente')
      .limit(500);
    if (error && !tablaFaltantesNoExiste(error)) throw error;
    const solicitudes = (data || []).filter((s: any) => mismoAlumno(s.alumno_nombre, acceso.hijo));
    await asegurarPlazosActualizados(); // 30/10: la fecha límite sale del panel → Configuración
    return res.json({ success: true, abierto: solicitudFaltanteAbierta(), solicitudes });
  } catch (err: any) {
    console.error('[faltantes] Error al consultar:', err);
    return res.status(500).json({ success: false, error: 'No pudimos consultar los pedidos de foto.' });
  }
});

rutas.post('/api/fotos-faltantes/solicitar', limitarFrecuencia('fotos-faltantes-solicitar', 20, 10 * 60 * 1000), async (req: Request, res: Response) => {
  try {
    await asegurarPlazosActualizados(); // 30/10: la fecha límite sale del panel → Configuración
    if (!solicitudFaltanteAbierta()) {
      return res.status(410).json({ success: false, codigo: 'FUERA_DE_PLAZO', error: `El plazo para pedir fotos faltantes terminó el ${textoFechaLarga(plazosVigentes().faltantes)}.` });
    }
    const lugar = String(req.body?.lugar || '') as LugarPack;
    const motivo = String(req.body?.motivo || '') as MotivoFaltante;
    const email = String(req.body?.email || '').trim().toLowerCase().slice(0, 200);
    const whatsapp = String(req.body?.whatsapp || '').trim().slice(0, 40);
    const tutor = String(req.body?.tutorNombre || '').trim().slice(0, 200);
    if (!LUGARES_PACK.includes(lugar)) return res.status(400).json({ success: false, error: 'Foto no válida.' });
    // 25/10/2026 (Pablo): la grupal no se puede volver a sacar: sólo se sigue sin ella o se elige otra foto del curso.
    if (lugar === 'grupal') return res.status(400).json({ success: false, codigo: 'GRUPAL', error: 'Si tu hijo/a no está en la foto grupal, avisanos desde la galería con «No está en la grupal: avisar» y lo revisamos.' });
    if (!MOTIVOS_FALTANTE.includes(motivo)) return res.status(400).json({ success: false, error: 'Contanos qué pasó con la foto.' });
    if (!EMAIL_RE.test(email)) return res.status(400).json({ success: false, error: 'Dejanos un email válido para avisarte cuando esté la foto.' });
    if (whatsapp && !/^[0-9+()\s-]{6,40}$/.test(whatsapp)) return res.status(400).json({ success: false, error: 'El WhatsApp no parece válido.' });
    const supabase = getServerSupabase();
    if (!supabase) return res.status(503).json({ success: false, error: 'Servicio no disponible' });
    const acceso = await familiaYCurso(supabase, req.body, String(req.body?.alumnoNombre || '').slice(0, 200));
    if (!acceso) return res.status(403).json({ success: false, error: ERROR_ACCESO });
    const alumno = acceso.hijo; // el nombre de la inscripción, nunca el texto del navegador

    const pendienteIgual = async () => {
      const { data } = await supabase.from(TABLA).select(COLUMNAS_FAMILIA).eq('colegio_id', acceso.colegioId).eq('codigo_curso', acceso.codigoCurso).eq('estado', 'pendiente').eq('lugar', lugar).limit(500);
      return (data || []).find((s: any) => mismoAlumno(s.alumno_nombre, alumno)) || null;
    };
    // Reintento (misma clave) o pedido repetido del mismo chico y foto: se devuelve el que ya estaba.
    const previo = await pendienteIgual();
    if (previo) return res.json({ success: true, solicitud: previo, repetida: true });
    // 25/10 (auditoría): si Pablo ya descartó el pedido de este chico y esta foto, no se puede volver a pedir desde la web
    // (si hace falta, la vuelve a abrir Pablo; si no, el descarte no servía: la familia lo pedía de nuevo y el kit volvía a quedar en espera).
    const { data: descartados } = await supabase.from(TABLA).select('alumno_nombre').eq('colegio_id', acceso.colegioId).eq('codigo_curso', acceso.codigoCurso).eq('lugar', lugar).eq('estado', 'cancelada').eq('cancelada_por', 'admin').limit(500);
    if ((descartados || []).some((s: any) => mismoAlumno(s.alumno_nombre, alumno))) {
      return res.status(409).json({ success: false, codigo: 'YA_REVISADO', error: 'Ya revisamos el pedido de esta foto. Si tenés alguna duda, escribinos desde «Consultas».' });
    }

    const nomina = await nominaDelAlumno(supabase, acceso.colegioId, alumno, lugar);
    const clave = typeof req.body?.clave === 'string' && CLAVE_RE.test(req.body.clave) ? req.body.clave : null;
    const { data, error } = await supabase
      .from(TABLA)
      .insert({
        id: crypto.randomUUID(),
        estado: 'pendiente',
        colegio_id: acceso.colegioId,
        codigo_curso: acceso.codigoCurso,
        grado: acceso.seccion.grado,
        division: acceso.seccion.division,
        turno: acceso.seccion.turno,
        alumno_nombre: alumno,
        lugar,
        motivo,
        tutor_nombre: tutor || null,
        contacto_email: email,
        contacto_whatsapp: whatsapp || null,
        inscripcion_id: String(req.body?.familia || '') || null,
        nomina_alumno_id: nomina.id,
        nomina_tiene_foto: nomina.tieneFoto,
        ...(clave ? { clave } : {}),
      })
      .select(COLUMNAS_FAMILIA)
      .maybeSingle();
    if (error && String((error as any).code) === '23505') {
      const ganador = await pendienteIgual();
      if (ganador) return res.json({ success: true, solicitud: ganador, repetida: true });
    }
    if (error) throw error;
    return res.json({ success: true, solicitud: data });
  } catch (err: any) {
    console.error('[faltantes] Error al guardar el pedido de foto:', err);
    return res.status(500).json({ success: false, error: 'No pudimos guardar el pedido de foto. Probá de nuevo.' });
  }
});

rutas.post('/api/fotos-faltantes/:id/cancelar', limitarFrecuencia('fotos-faltantes-cancelar', 30, 10 * 60 * 1000), async (req: Request, res: Response) => {
  try {
    if (!UUID_RE.test(req.params.id)) return res.status(400).json({ success: false, error: 'Pedido no válido.' });
    const supabase = getServerSupabase();
    if (!supabase) return res.status(503).json({ success: false, error: 'Servicio no disponible' });
    const { data: fila, error } = await supabase.from(TABLA).select('id, colegio_id, codigo_curso, alumno_nombre, estado').eq('id', req.params.id).maybeSingle();
    if (error) throw error;
    const acceso = fila ? await familiaYCurso(supabase, req.body, fila.alumno_nombre) : null;
    if (!fila || !acceso || fila.colegio_id !== acceso.colegioId || fila.codigo_curso !== acceso.codigoCurso || !mismoAlumno(fila.alumno_nombre, acceso.hijo)) {
      return res.status(404).json({ success: false, error: 'No encontramos ese pedido de foto.' });
    }
    if (fila.estado !== 'pendiente') return res.json({ success: true, yaEstaba: true });
    const { error: errUpd } = await supabase
      .from(TABLA)
      .update({ estado: 'cancelada', cancelada_at: new Date().toISOString(), cancelada_por: 'familia' })
      .eq('id', fila.id)
      .eq('estado', 'pendiente');
    if (errUpd) throw errUpd;
    return res.json({ success: true });
  } catch (err: any) {
    console.error('[faltantes] Error al cancelar:', err);
    return res.status(500).json({ success: false, error: 'No pudimos cancelar el pedido de foto.' });
  }
});

// ---------------------------------------------------------------------------------------------
// Panel (pestaña «Faltantes»)
// ---------------------------------------------------------------------------------------------
rutas.get('/api/admin/fotos-faltantes', requireAdminAuth, async (req: Request, res: Response) => {
  try {
    const colegioId = typeof req.query.colegioId === 'string' ? req.query.colegioId : '';
    if (!colegioId || colegioId.length > 100) return res.status(400).json({ success: false, error: 'Falta indicar el colegio.' });
    const supabase = getServerSupabase();
    if (!supabase) return res.status(500).json({ success: false, error: 'Supabase no configurado en el servidor' });
    const solicitudes = await traerTodasLasFilas((desde, hasta) =>
      supabase.from(TABLA).select(COLUMNAS_ADMIN).eq('colegio_id', colegioId).order('created_at', { ascending: false }).order('id').range(desde, hasta)
    );
    return res.json({ success: true, solicitudes, fechaLimite: plazosVigentes().faltantes });
  } catch (err: any) {
    console.error('[faltantes] Error al listar:', err);
    return res.status(500).json({ success: false, error: err?.message || 'No se pudieron cargar las fotos faltantes.' });
  }
});

async function enviarAvisoFotoLista(fila: any): Promise<boolean> {
  const resend = getResendClient();
  if (!resend || !EMAIL_RE.test(String(fila.contacto_email || ''))) return false;
  const lugar = NOMBRE_LUGAR_FALTANTE[fila.lugar as LugarPack] || 'la foto';
  const curso = `${fila.grado || ''} "${fila.division || ''}"${fila.turno ? ` · Turno ${fila.turno}` : ''}`;
  const { error } = await resend.emails.send(
    {
      from: process.env.RESEND_FROM_EMAIL || 'Retrato Escolar <fotos@retratoescolar.com.ar>',
      replyTo: resendReplyTo,
      to: [fila.contacto_email],
      subject: `Ya está ${lugar} de ${fila.alumno_nombre}`,
      html: `<!doctype html><html lang="es"><body style="margin:0;background:#f8fafc;font-family:Arial,sans-serif;color:#1e293b"><div style="max-width:600px;margin:24px auto;background:#fff;border:1px solid #e2e8f0;border-radius:16px;overflow:hidden"><div style="background:#0f172a;padding:28px 24px;text-align:center;border-bottom:3px solid #f59e0b"><div style="color:#f59e0b;font-size:11px;font-weight:800;letter-spacing:2px">RETRATO ESCOLAR</div><h1 style="color:#fff;font-size:22px;margin:8px 0 0">¡Ya está la foto que pediste!</h1></div><div style="padding:28px 24px"><p>Hola <strong>${escapeHtml(fila.tutor_nombre || 'familia')}</strong>,</p><p style="line-height:1.6">Ya publicamos ${escapeHtml(lugar)} de <strong>${escapeHtml(fila.alumno_nombre)}</strong> (${escapeHtml(curso)}). Entrá a la galería, elegila y cerrá tu kit.</p><div style="margin:24px 0;text-align:center"><a href="https://retratoescolar.com.ar" style="display:inline-block;background:#fbbf24;color:#0f172a;text-decoration:none;font-weight:800;padding:13px 22px;border-radius:10px">Elegir mi foto</a></div><p style="font-size:12px;color:#64748b">Ingresá con el mismo código de acceso de siempre.</p></div></div></body></html>`,
    },
    { idempotencyKey: `foto-faltante-lista-${fila.id}` }
  );
  if (error) {
    console.warn('[faltantes] Resend rechazó el aviso:', error);
    return false;
  }
  return true;
}

async function enviarAvisoDescarte(fila: any): Promise<boolean> {
  const resend = getResendClient();
  if (!resend || !EMAIL_RE.test(String(fila.contacto_email || ''))) return false;
  const lugar = NOMBRE_LUGAR_FALTANTE[fila.lugar as LugarPack] || 'la foto';
  try {
    const { error } = await resend.emails.send(
      {
        from: process.env.RESEND_FROM_EMAIL || 'Retrato Escolar <fotos@retratoescolar.com.ar>',
        replyTo: resendReplyTo,
        to: [fila.contacto_email],
        subject: `Ya podés cerrar el kit de ${fila.alumno_nombre}`,
        html: `<div style="font-family:Arial,sans-serif;max-width:600px;margin:auto;color:#0f172a;line-height:1.6"><p>Hola <strong>${escapeHtml(fila.tutor_nombre || 'familia')}</strong>,</p><p>Revisamos tu pedido sobre ${escapeHtml(lugar)} de <strong>${escapeHtml(fila.alumno_nombre)}</strong>. El kit ya no está en espera: podés entrar a la galería y cerrarlo, eligiendo otra foto del curso para ese lugar (el precio del kit no cambia).</p><p>Si tenés alguna duda, respondé este email.</p><p>Saludos,<br>Equipo de Retrato Escolar</p></div>`,
      },
      { idempotencyKey: `foto-faltante-descartada-${fila.id}` }
    );
    if (error) console.warn('[faltantes] Resend rechazó el aviso de descarte:', error);
    return !error;
  } catch (err: any) {
    console.warn('[faltantes] No se pudo mandar el aviso de descarte:', err?.message || err);
    return false;
  }
}

rutas.post('/api/admin/fotos-faltantes/:id/resolver', requireAdminAuth, async (req: Request, res: Response) => {
  try {
    if (!UUID_RE.test(req.params.id)) return res.status(400).json({ success: false, error: 'Pedido no válido.' });
    const supabase = getServerSupabase();
    if (!supabase) return res.status(500).json({ success: false, error: 'Supabase no configurado en el servidor' });
    // 25/10 (auditoría): el mail dice «Ya publicamos…»: antes de marcarlo se controla que el curso tenga una foto de ese
    // lugar PUBLICADA después del pedido (subida sin publicar = la familia no la encuentra). Con `forzar` se avisa igual.
    if (req.body?.forzar !== true) {
      const { data: pedido } = await supabase.from(TABLA).select('colegio_id, codigo_curso, lugar, estado, created_at').eq('id', req.params.id).maybeSingle();
      if (pedido?.estado === 'pendiente') {
        const { data: fotos, error: errFotos } = await supabase
          .from('fotos')
          .select('categoria')
          .eq('colegio_id', pedido.colegio_id)
          .eq('codigo_curso', pedido.codigo_curso)
          .gte('publicada_at', pedido.created_at)
          .limit(1000);
        if (errFotos) throw errFotos;
        if (!(fotos || []).some((f: any) => categoriaValeEnLugar(f.categoria, pedido.lugar as LugarPack, []))) {
          return res.status(409).json({ success: false, codigo: 'SIN_FOTO_PUBLICADA', error: 'En ese curso no hay una foto de ese tipo publicada después del pedido. Subila y tocá «Publicar» antes de avisar.' });
        }
      }
    }
    const { data: filas, error } = await supabase
      .from(TABLA)
      .update({ estado: 'resuelta', resuelta_at: new Date().toISOString() })
      .eq('id', req.params.id)
      .eq('estado', 'pendiente')
      .select(COLUMNAS_ADMIN);
    if (error) throw error;
    let fila: any = (filas || [])[0];
    if (!fila) {
      const { data: actual } = await supabase.from(TABLA).select(COLUMNAS_ADMIN).eq('id', req.params.id).maybeSingle();
      if (!actual) return res.status(404).json({ success: false, error: 'No encontramos ese pedido de foto.' });
      if (actual.estado !== 'resuelta') return res.status(409).json({ success: false, error: 'Ese pedido de foto fue cancelado.' });
      fila = actual; // ya estaba resuelto (doble clic o reintento): sólo se reintenta el mail si no salió
    }
    let avisoEnviado = Boolean(fila.aviso_enviado_at);
    if (!avisoEnviado && (await enviarAvisoFotoLista(fila))) {
      const ahora = new Date().toISOString();
      const { error: errMarca } = await supabase.from(TABLA).update({ aviso_enviado_at: ahora }).eq('id', fila.id);
      if (errMarca) console.warn('[faltantes] Mail enviado pero no se pudo anotar aviso_enviado_at:', errMarca.message);
      fila = { ...fila, aviso_enviado_at: ahora };
      avisoEnviado = true;
    }
    return res.json({ success: true, solicitud: fila, avisoEnviado });
  } catch (err: any) {
    console.error('[faltantes] Error al resolver:', err);
    return res.status(500).json({ success: false, error: err?.message || 'No se pudo marcar la foto como lista.' });
  }
});

rutas.post('/api/admin/fotos-faltantes/:id/descartar', requireAdminAuth, async (req: Request, res: Response) => {
  try {
    if (!UUID_RE.test(req.params.id)) return res.status(400).json({ success: false, error: 'Pedido no válido.' });
    const supabase = getServerSupabase();
    if (!supabase) return res.status(500).json({ success: false, error: 'Supabase no configurado en el servidor' });
    const { data, error } = await supabase
      .from(TABLA)
      .update({ estado: 'cancelada', cancelada_at: new Date().toISOString(), cancelada_por: 'admin' })
      .eq('id', req.params.id)
      .eq('estado', 'pendiente')
      .select(COLUMNAS_ADMIN);
    if (error) throw error;
    if (!data || data.length === 0) return res.status(409).json({ success: false, error: 'Ese pedido de foto ya no está pendiente.' });
    // 25/10 (auditoría): antes el cartel «te avisamos por mail» desaparecía sin aviso. Mail neutro (sin hablar de
    // repetir fotos): el kit ya no está en espera y puede cerrarlo.
    const avisoEnviado = await enviarAvisoDescarte(data[0]);
    return res.json({ success: true, solicitud: data[0], avisoEnviado });
  } catch (err: any) {
    console.error('[faltantes] Error al descartar:', err);
    return res.status(500).json({ success: false, error: err?.message || 'No se pudo descartar el pedido de foto.' });
  }
});

export { rutas as rutasSolicitudesFaltantes };
