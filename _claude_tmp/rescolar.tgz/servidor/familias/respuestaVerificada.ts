// 26/10/2026 (Pablo: «busca una solución definitiva, no me sirve una IA que responda tan mal y genéricamente»).
// La respuesta a una consulta se arma en dos pasos y sólo con lo que está comprobado:
//  1) REDACCIÓN: la IA dice qué entendió, lista cada cosa que va a afirmar con su respaldo (un dato numerado de
//     la ficha de la familia, una regla del negocio o la idea del fotógrafo), marca lo ambiguo y lo que tiene que
//     decidir el equipo, y recién ahí escribe el mensaje.
//  2) CONTROL: otra pasada revisa el borrador frase por frase contra la ficha y saca lo que no tiene respaldo.
// Además, acá mismo se controla (sin IA) que cada afirmación cite un dato que exista. Una respuesta sólo puede salir
// sola si pasó el control sin problemas, sin dudas ni decisiones pendientes (ver procesarConsultaConIA).
import { generarTextoIA } from '../nucleo/ia.js';

export type ChequeoFicha = { ok: boolean; texto: string };
export interface FichaParaIA { chequeos: ChequeoFicha[]; datos: string[] }
export interface Afirmacion { texto: string; fuente: string }
export interface DecisionPendiente { pregunta: string; opciones: string[] }
export interface Alerta { frase: string; motivo: string }

export interface DecisionIA {
  tema: string;
  respondible: boolean;
  respuesta: string;
  motivo: string;
  /** Qué entendió la IA que pide la familia (una línea). */
  entendido: string;
  ambiguedades: string[];
  decisiones: DecisionPendiente[];
  afirmaciones: Afirmacion[];
  /** Lo que el control encontró sin respaldo (y sacó de la respuesta). */
  alertas: Alerta[];
  /** true si el control (paso 2) corrió y devolvió el formato esperado. */
  verificado: boolean;
  /** 26/10: cómo se armó («Investigada por Claude Opus 5.5 con 4 consultas a la base»), para el panel. */
  nota?: string;
}

/** La ficha con un código por línea: [C1] para los chequeos, [D1] para los datos. */
export function fichaNumerada(ficha: FichaParaIA): { texto: string; codigos: Set<string> } {
  const codigos = new Set<string>();
  const lineas = [
    ...ficha.chequeos.map((c, i) => (codigos.add(`C${i + 1}`), `[C${i + 1}] ${c.ok ? '[OK]' : '[PROBLEMA]'} ${c.texto}`)),
    ...ficha.datos.map((d, i) => (codigos.add(`D${i + 1}`), `[D${i + 1}] ${d}`)),
  ];
  return { texto: lineas.join('\n') || '(no hay datos de esta familia)', codigos };
}

export function encabezadoConsulta(consulta: any): string {
  const historial = [...(consulta.consultas_familias_mensajes || [])]
    .sort((a: any, b: any) => String(a.created_at).localeCompare(String(b.created_at)))
    .map((m: any) => `${m.direccion === 'entrante' ? 'Familia' : 'Retrato Escolar'}: ${m.contenido}`)
    .join('\n');
  return `
Consulta de una familia:
- Nombre: ${consulta.nombre}
- Email: ${consulta.email}
- Colegio mencionado: ${consulta.colegio || 'no especificado'}
- Número de pedido mencionado: ${consulta.numero_pedido || 'ninguno'}
- Asunto: ${consulta.asunto}
- Mensaje: ${consulta.origen === 'panel' ? '(Esta conversación la inició Retrato Escolar escribiéndole a la familia; ver la conversación de abajo.)' : consulta.mensaje}
${historial ? `\nConversación hasta ahora (lo último es lo más reciente y es lo que hay que contestar):\n${historial}` : ''}`.trim();
}

export function bloqueIdea(idea?: string): string {
  return idea ? `
IDEA DEL FOTÓGRAFO PARA ESTA RESPUESTA (manda sobre todo lo demás en cuanto a QUÉ decir):
<<<
${idea}
>>>
- Redactá la respuesta a partir de esta idea: es lo que decidió el fotógrafo. Desarrollala en un mensaje claro y cálido, sin cambiar lo que dice ni agregar promesas, fechas o datos que no estén en la idea, en la ficha o en la información del negocio. Lo que sale de la idea lleva fuente "IDEA".
- Con una idea, "respuesta" nunca va vacía (aunque sea un agradecimiento) y lo que la idea resuelve ya no es una decisión pendiente.
- Igual nunca des códigos de acceso, DNIs ni datos de otras familias.` : '';
}

export function promptRedaccion(consulta: any, ficha: FichaParaIA, idea?: string): string {
  return `
${encabezadoConsulta(consulta)}

FICHA DE ESTA FAMILIA (datos reales, revisados recién; son la ÚNICA fuente sobre esta familia). Cada línea tiene un código:
${fichaNumerada(ficha).texto}

Trabajá en este orden:
1. "entendido": en UNA línea, qué pide o pregunta la familia en su ÚLTIMO mensaje (no en los anteriores). Si algo se puede leer de dos maneras (por ejemplo «la foto con Valentina» puede ser la foto de hermanos o la foto con la seño), anotalo en "ambiguedades" y quedate con la lectura que respaldan los datos (si Valentina es su hija y la familia tiene foto de hermanos, habla de la foto de hermanos).
2. "afirmaciones": cada cosa concreta que le vas a decir a la familia, con su "fuente": el código del dato que la respalda ("D3", "C1"), "REGLA: <la regla del negocio, en pocas palabras>" o "IDEA". Lo que no tiene fuente NO se dice. Nunca digas que algo "no figura", "no existe" o "no está registrado" si la ficha no lo dice con esas palabras.
3. "decisiones": lo que la familia pide y NO se resuelve con la ficha ni con las reglas (cambiar un día u horario, una excepción, un descuento o reintegro, una foto que no existe en su curso, cualquier promesa). Para cada una, la "pregunta" para el fotógrafo y 2 o 3 "opciones" concretas. En la respuesta no lo resuelvas: decí que lo revisa el equipo y le responde por email.
4. "respuesta": el mensaje para la familia. Contestá SOLO lo que pregunta su último mensaje, con SUS datos (nombres, cursos, días, horarios) y sin explicaciones generales que no pidió. Breve (2 a 6 oraciones), cálido, en español rioplatense («vos»), sin saludo inicial ni firma (el sistema los agrega). No repitas lo que ya le dijimos en la conversación salvo que lo vuelva a preguntar.

Respondé SOLO con un JSON con esta forma exacta:
{"tema": "funcionamiento" | "pedido_pago" | "reclamo" | "agradecimiento" | "otro",
 "entendido": "qué pide, en una línea",
 "ambiguedades": ["..."],
 "afirmaciones": [{"texto": "...", "fuente": "D3"}],
 "decisiones": [{"pregunta": "...", "opciones": ["...", "..."]}],
 "respondible": true | false,
 "respuesta": "cuerpo del mensaje para la familia",
 "motivo": "una línea para el fotógrafo explicando la decisión"}

Reglas:
- "funcionamiento": dudas sobre cómo usar la web (inscripción, hermanos, código de acceso, cómo ver o elegir fotos, kits, precios, cómo y cuándo se paga) que se contestan con la información del negocio y la ficha.
- "respondible" es true SÓLO si no hay decisiones ni ambigüedades y toda la respuesta sale de la ficha y de las reglas, sin inventar nada y sin prometer fechas, reintegros ni excepciones.
- Si la familia pregunta si su inscripción está bien, usá la ficha: confirmale el curso de cada hijo si está [OK], o explicale con tacto lo que haya que corregir.
- Si hay un [PROBLEMA] con el curso de un chico, aplicá "LA NÓMINA MANDA": no le confirmes el curso que eligió ni le pidas que se vuelva a inscribir, y "respondible" es false.
- Si la familia dice (en el mensaje o en la conversación) que su hijo va a un curso, división o turno distinto del que figura en la ficha, o pide que lo cambien, "respondible" es false aunque la ficha diga [OK]: el cambio lo revisa el equipo a mano. No prometas la corrección ni un código nuevo.
- Nunca des códigos de acceso, DNIs ni datos de otras familias en la respuesta.
- "agradecimiento": la familia solo agradece o cierra la conversación; respuesta "" y respondible false.${bloqueIdea(idea)}
`.trim();
}

export function promptControl(consulta: any, ficha: FichaParaIA, borrador: DecisionIA, idea?: string): string {
  return `
Sos el control de calidad de las respuestas a las familias. NO escribís desde cero: revisás un borrador.

${encabezadoConsulta(consulta)}

FICHA DE ESTA FAMILIA (la única fuente sobre esta familia):
${fichaNumerada(ficha).texto}
${idea ? `\nIDEA DEL FOTÓGRAFO (también vale como fuente):\n<<<\n${idea}\n>>>\n` : ''}
BORRADOR A REVISAR:
<<<
${borrador.respuesta}
>>>

Revisalo frase por frase:
- ¿Contesta lo que pregunta el ÚLTIMO mensaje de la familia? Si contesta otra cosa (por ejemplo habla de la foto con la seño cuando pregunta por la foto de hermanos), es un problema.
- Cada dato concreto (días, horarios, montos, nombres, cursos, estados, si algo existe o no, plazos, qué botón tocar) tiene que estar en la ficha, en la información del negocio o en la idea del fotógrafo. Si no está, es un problema.
- Decir que algo "no figura", "no existe" o "no está registrado" sin que la ficha lo diga es un problema.
- Prometer algo que el equipo no decidió (un día nuevo, una excepción, un descuento, una foto) es un problema.
- Explicaciones generales que la familia no pidió son un problema menor: sacalas.

Respondé SOLO con un JSON:
{"verificado": true,
 "problemas": [{"frase": "la frase del borrador", "motivo": "por qué está mal"}],
 "respuesta": "el borrador corregido: igual que el original pero sin las frases con problemas; si sacarlas lo deja sin sentido, reescribilo SÓLO con lo que sí está respaldado. Sin saludo ni firma."}
Si no encontraste problemas, "problemas" va vacío y "respuesta" es el borrador tal cual.
`.trim();
}

const limpiarJson = (texto: string) => String(texto || '').replace(/^```(?:json)?\s*/i, '').replace(/```\s*$/, '').trim();
const listaDeTextos = (v: unknown): string[] => (Array.isArray(v) ? v.map((x) => String(x || '').trim()).filter(Boolean) : []);

export function leerRedaccion(textoIA: string): DecisionIA {
  const base: DecisionIA = { tema: 'otro', respondible: false, respuesta: '', motivo: '', entendido: '', ambiguedades: [], decisiones: [], afirmaciones: [], alertas: [], verificado: false };
  let json: any;
  try {
    json = JSON.parse(limpiarJson(textoIA));
  } catch {
    // Si la IA no devolvió JSON válido, se usa su texto como borrador y nunca se envía solo.
    return { ...base, respuesta: limpiarJson(textoIA), motivo: 'La IA no devolvió el formato esperado.' };
  }
  return {
    ...base,
    tema: String(json.tema || 'otro'),
    respondible: json.respondible === true,
    respuesta: String(json.respuesta || '').trim(),
    motivo: String(json.motivo || '').trim(),
    entendido: String(json.entendido || '').trim(),
    ambiguedades: listaDeTextos(json.ambiguedades),
    decisiones: (Array.isArray(json.decisiones) ? json.decisiones : [])
      .map((d: any) => ({ pregunta: String(d?.pregunta || '').trim(), opciones: listaDeTextos(d?.opciones).slice(0, 4) }))
      .filter((d: DecisionPendiente) => d.pregunta),
    afirmaciones: (Array.isArray(json.afirmaciones) ? json.afirmaciones : [])
      .map((a: any) => ({ texto: String(a?.texto || '').trim(), fuente: String(a?.fuente || '').trim() }))
      .filter((a: Afirmacion) => a.texto),
  };
}

/** Afirmaciones cuya fuente no es un dato que exista en la ficha, una regla o la idea del fotógrafo (control sin IA). */
export function afirmacionesSinRespaldo(afirmaciones: Afirmacion[], codigos: Set<string>, hayIdea: boolean): Alerta[] {
  return afirmaciones
    .filter((a) => {
      const fuente = a.fuente.toUpperCase();
      if (/^REGLA\b/.test(fuente)) return false;
      if (hayIdea && /^IDEA\b/.test(fuente)) return false;
      const citados = fuente.match(/\b[CD]\d+\b/g) || [];
      return citados.length === 0 || citados.some((c) => !codigos.has(c));
    })
    .map((a) => ({ frase: a.texto, motivo: a.fuente ? `Su respaldo («${a.fuente}») no es un dato de la ficha.` : 'No tiene ningún dato que la respalde.' }));
}

export function leerControl(textoIA: string): { verificado: boolean; problemas: Alerta[]; respuesta: string } | null {
  try {
    const json = JSON.parse(limpiarJson(textoIA));
    if (json?.verificado !== true || typeof json.respuesta !== 'string') return null;
    const problemas = (Array.isArray(json.problemas) ? json.problemas : [])
      .map((p: any) => ({ frase: String(p?.frase || '').trim(), motivo: String(p?.motivo || '').trim() }))
      .filter((p: Alerta) => p.frase || p.motivo);
    return { verificado: true, problemas, respuesta: json.respuesta.trim() };
  } catch {
    return null;
  }
}

/**
 * Los dos pasos. `alTenerBorrador` se llama con el borrador del paso 1 antes del control, para guardarlo: si el
 * control no llega a correr (por ejemplo el tope de tiempo del webhook de correo), el borrador no se pierde, queda
 * «sin verificar» y no sale solo.
 */
export async function redactarYControlar(params: {
  consulta: any;
  ficha: FichaParaIA;
  sistema: string;
  esfuerzo?: 'low' | 'medium';
  idea?: string;
  alTenerBorrador?: (borrador: DecisionIA) => Promise<void>;
}): Promise<DecisionIA> {
  const { consulta, ficha, sistema, esfuerzo, idea } = params;
  const borrador = leerRedaccion(await generarTextoIA({ sistema, prompt: promptRedaccion(consulta, ficha, idea), json: true, esfuerzo }));
  const sinRespaldo = afirmacionesSinRespaldo(borrador.afirmaciones, fichaNumerada(ficha).codigos, Boolean(idea));
  const conAlertas: DecisionIA = { ...borrador, alertas: sinRespaldo };
  if (!borrador.respuesta) return conAlertas; // nada que controlar (por ejemplo, un agradecimiento)
  if (params.alTenerBorrador) await params.alTenerBorrador(conAlertas).catch(() => undefined);
  const control = leerControl(await generarTextoIA({ sistema, prompt: promptControl(consulta, ficha, borrador, idea), json: true, esfuerzo }));
  if (!control) return { ...conAlertas, alertas: [...sinRespaldo, { frase: '', motivo: 'El control automático no devolvió el formato esperado: revisá el borrador a mano.' }] };
  return {
    ...conAlertas,
    respuesta: control.respuesta || borrador.respuesta,
    alertas: [...sinRespaldo, ...control.problemas],
    verificado: true,
  };
}

/** Si la respuesta puede salir sola según el análisis (además de los otros controles de procesarConsultaConIA). */
export function analisisPermiteEnvio(d: DecisionIA): boolean {
  return d.verificado && d.alertas.length === 0 && d.ambiguedades.length === 0 && d.decisiones.length === 0;
}

/** Lo que se guarda en verificacion_ia y ve el panel. */
export function analisisParaPanel(d: DecisionIA) {
  return { entendido: d.entendido, ambiguedades: d.ambiguedades, decisiones: d.decisiones, alertas: d.alertas, verificado: d.verificado, ...(d.nota ? { nota: d.nota } : {}) };
}
