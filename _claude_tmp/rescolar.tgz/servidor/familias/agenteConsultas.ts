// 26/10/2026 (Pablo: «cuando apriete "Pedir otra a la IA", te llegue la consulta a vos y prepares una respuesta»; eligió
// Claude Opus 5.5). Desde el panel, la respuesta la arma un AGENTE: Claude con herramientas de SÓLO LECTURA que investiga
// la consulta como lo hace Claude en el chat de Pablo (busca a la familia, la nómina, nombres parecidos, las fotos de cada
// curso, pedidos, la citación de hermanos, las consultas anteriores), y recién después entrega el borrador con lo que
// entendió, dudas y decisiones. No escribe en la base ni manda nada: Pablo revisa y envía.
// Tiempo: la función de Vercel corta a los 120 s (vercel.json); el agente tiene un presupuesto menor y, si se le acaba,
// se le pide que entregue con lo que tiene.
import type { SupabaseClient } from '@supabase/supabase-js';
import { citasUltimaCitacion } from './citasHermanos.js';
import { cargarNominaColegio, clasesDeFotosDelCurso, nombreParecidoEnNomina, textoFotoHermanos } from './fichaFamiliaExtra.js';
import { bloqueIdea, encabezadoConsulta, fichaNumerada, type DecisionIA, type FichaParaIA } from './respuestaVerificada.js';

export const MODELO_AGENTE_POR_DEFECTO = 'claude-opus-5-5';
const PRESUPUESTO_MS = 95_000;
const MAX_VUELTAS = 10;

const escaparIlike = (t: string) => t.replace(/[\\%_]/g, (c) => `\\${c}`);
const fecha = (v: unknown) => (v ? new Date(String(v)).toLocaleDateString('es-AR', { day: '2-digit', month: '2-digit', timeZone: 'America/Argentina/Buenos_Aires' }) : '—');

const HERRAMIENTAS = [
  {
    name: 'buscar_inscripciones',
    description: 'Busca inscripciones por nombre o apellido del tutor o de un alumno, o por email (sirve si la familia escribió desde otro email o nombró a otro chico). Devuelve tutor, email, colegio, chicos con su curso, estado y foto de hermanos.',
    input_schema: { type: 'object', properties: { texto: { type: 'string', description: 'Nombre, apellido o email (al menos 3 letras).' } }, required: ['texto'] },
  },
  {
    name: 'buscar_en_nomina',
    description: 'Busca un alumno en la nómina del colegio (la lista oficial que pasó el colegio), también con el nombre mal escrito. Devuelve nombre, grado, división, turno y las marcas del día de fotos (individual, grupal, 3ª foto).',
    input_schema: { type: 'object', properties: { nombre: { type: 'string' }, grado: { type: 'string', description: 'Opcional, por ejemplo «6° grado» o «1° año».' } }, required: ['nombre'] },
  },
  {
    name: 'fotos_del_curso',
    description: 'Qué clases de fotos hay publicadas en un curso (grupales, individuales, con la seño, con familia y/o amigos) y si falta alguna.',
    input_schema: { type: 'object', properties: { grado: { type: 'string' }, division: { type: 'string' }, turno: { type: 'string' } }, required: ['grado', 'division', 'turno'] },
  },
  {
    name: 'ver_pedido',
    description: 'Detalle de un pedido por su número (IFS-2026-…): alumno, kit, estado del pago, laboratorio, si faltan elegir fotos y el email de quien lo hizo.',
    input_schema: { type: 'object', properties: { numero: { type: 'string' } }, required: ['numero'] },
  },
  {
    name: 'conversaciones_anteriores',
    description: 'Las consultas anteriores de esta familia con sus mensajes (lo que preguntó y lo que le respondimos).',
    input_schema: { type: 'object', properties: {} },
  },
  {
    name: 'entregar_respuesta',
    description: 'Entrega el resultado final. Llamala UNA vez, cuando terminaste de investigar.',
    input_schema: {
      type: 'object',
      properties: {
        tema: { type: 'string', enum: ['funcionamiento', 'pedido_pago', 'reclamo', 'agradecimiento', 'otro'] },
        entendido: { type: 'string', description: 'Qué pide la familia en su último mensaje, en una línea.' },
        ambiguedades: { type: 'array', items: { type: 'string' } },
        decisiones: {
          type: 'array',
          items: { type: 'object', properties: { pregunta: { type: 'string' }, opciones: { type: 'array', items: { type: 'string' } } }, required: ['pregunta', 'opciones'] },
        },
        respuesta: { type: 'string', description: 'El mensaje para la familia, sin saludo inicial ni firma. Vacío sólo si no hace falta responder.' },
        motivo: { type: 'string', description: 'Una línea para el fotógrafo: qué investigaste y qué encontraste.' },
      },
      required: ['tema', 'entendido', 'ambiguedades', 'decisiones', 'respuesta', 'motivo'],
    },
  },
];

const INSTRUCCIONES = `
Sos parte del equipo de Retrato Escolar y preparás el BORRADOR de respuesta a una consulta de una familia. El fotógrafo lo revisa antes de enviarlo.
Trabajá como un empleado que conoce el sistema: primero entendé qué pide la familia en su ÚLTIMO mensaje, después investigá con las herramientas todo lo que haga falta para contestarle con SUS datos, y recién ahí redactá.
- Ya tenés la ficha de la familia: usala, y con las herramientas confirmá o completá lo que falte (otro email, un chico que no aparece, un nombre mal escrito en la nómina, las fotos de su curso, un pedido, lo que ya le dijimos antes).
- No afirmes nada que no hayas visto en la ficha, en las herramientas o en la información del negocio. Nunca digas que algo «no figura» o «no existe» sin haberlo buscado.
- Si algo se puede leer de dos formas (por ejemplo «la foto con Valentina» puede ser la de hermanos o la de la seño), investigá cuál es y anotalo en "ambiguedades".
- Lo que la familia pide y no se resuelve con los datos ni las reglas (cambiar un día u horario, una excepción, un descuento, una foto que no existe) va a "decisiones" con 2 o 3 opciones concretas; en la respuesta decí que lo revisa el equipo y le responde por email.
- La respuesta: breve (2 a 6 oraciones), cálida, en español rioplatense («vos»), sin saludo inicial ni firma; contestá SÓLO lo que pregunta, con sus nombres, cursos, días y horarios. Nunca des códigos de acceso, DNIs ni datos de otras familias.
- Usá pocas herramientas y en paralelo cuando puedas: tenés poco tiempo. Cuando termines, llamá a "entregar_respuesta".
`.trim();

async function herramienta(nombre: string, entrada: any, ctx: { supabase: SupabaseClient; email: string; colegios: string[] }): Promise<string> {
  const { supabase } = ctx;
  if (nombre === 'buscar_inscripciones') {
    const texto = String(entrada?.texto || '').trim();
    if (texto.length < 3) return 'Escribí al menos 3 letras.';
    const patron = `%${escaparIlike(texto)}%`;
    const columnas = 'email, padre_nombre, alumno_nombre, alumno_apellido, grado, division, turno, hermanos, estado, colegio_nombre, solicita_foto_hermanos, foto_hermanos_confirmada_at, foto_hermanos_email';
    const filas = new Map<string, any>();
    for (const col of ['padre_nombre', 'alumno_apellido', 'alumno_nombre', 'email']) {
      const { data } = await supabase.from('inscripciones').select(`id, ${columnas}`).ilike(col, patron).limit(8);
      for (const f of data || []) filas.set(f.id, f);
    }
    if (filas.size === 0) return `No hay inscripciones que coincidan con «${texto}».`;
    const citas = await citasUltimaCitacion(supabase).catch(() => ({}));
    return [...filas.values()].slice(0, 10).map((f) => {
      const chicos = [`${f.alumno_nombre} ${f.alumno_apellido || ''} (${f.grado} "${f.division}" ${f.turno || ''})`, ...(f.hermanos || []).map((h: any) => `${h?.alumnoNombre} ${h?.alumnoApellido || ''} (${h?.grado} "${h?.division}" ${h?.turno || ''})`)];
      return `- ${f.padre_nombre} <${f.email}> · ${f.colegio_nombre} · ${f.estado} · chicos: ${chicos.join('; ')}${textoFotoHermanos(f, citas) ? ` · ${textoFotoHermanos(f, citas)}` : ''}`;
    }).join('\n');
  }
  if (nombre === 'buscar_en_nomina') {
    const buscado = String(entrada?.nombre || '').trim();
    const grado = entrada?.grado ? String(entrada.grado) : '';
    const resultados: string[] = [];
    for (const colegioId of ctx.colegios) {
      const nomina = await cargarNominaColegio(supabase, colegioId);
      const palabras = buscado.toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').split(/\s+/).filter((p) => p.length >= 3);
      const coinciden = nomina.filter((a) => {
        const n = a.nombre.toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '');
        return palabras.length > 0 && palabras.every((p) => n.includes(p)) && (!grado || a.grado === grado);
      });
      const parecido = coinciden.length === 0 && grado ? nombreParecidoEnNomina(nomina, buscado, grado) : null;
      for (const a of [...coinciden, ...(parecido ? [parecido] : [])].slice(0, 10)) {
        const { data: marcas } = await supabase.from('alumnos').select('fotografiado_at, foto_grupal_at, foto_seno_at').eq('colegio_id', colegioId).eq('nombre', a.nombre).limit(1);
        const m: any = marcas?.[0] || {};
        resultados.push(`- ${a.nombre} · ${a.grado} "${a.division}"${a.turno ? ` ${a.turno}` : ''}${a === parecido ? ' (NOMBRE PARECIDO, no igual)' : ''} · marcas del día de fotos: individual ${fecha(m.fotografiado_at)}, grupal ${fecha(m.foto_grupal_at)}, 3ª foto ${fecha(m.foto_seno_at)}`);
      }
    }
    return resultados.length ? `${resultados.join('\n')}\n(Las marcas son las que carga el fotógrafo; lo que se puede elegir es lo publicado: usá fotos_del_curso.)` : `No hay nadie en la nómina que coincida con «${buscado}»${grado ? ` en ${grado}` : ''}.`;
  }
  if (nombre === 'fotos_del_curso') {
    const chico = { nombre: 'ese curso', grado: String(entrada?.grado || ''), division: String(entrada?.division || ''), turno: String(entrada?.turno || '') };
    const textos = [];
    for (const colegioId of ctx.colegios) textos.push(await clasesDeFotosDelCurso(supabase, colegioId, chico));
    return textos.join('\n') || 'No hay colegio para buscar.';
  }
  if (nombre === 'ver_pedido') {
    const numero = String(entrada?.numero || '').trim();
    if (!numero) return 'Falta el número.';
    const { data } = await supabase.from('pedidos').select('pedido_friendly_id, alumno_nombre, curso_codigo, kit_nombre, estado, estado_lab, total, metodo_pago, created_at, seleccion_pendiente, familia_id').ilike('pedido_friendly_id', escaparIlike(numero)).limit(1);
    const p = data?.[0];
    if (!p) return `No existe el pedido ${numero}.`;
    const { data: familia } = p.familia_id ? await supabase.from('familias').select('email').eq('id', p.familia_id).maybeSingle() : { data: null };
    const deEstaFamilia = String(familia?.email || '').trim().toLowerCase() === ctx.email;
    return `Pedido ${p.pedido_friendly_id}: ${p.alumno_nombre} (${p.curso_codigo}) · ${p.kit_nombre} · $${p.total} · pago «${p.estado}» (${p.metodo_pago}) · laboratorio «${p.estado_lab || 'sin estado'}» · ${p.seleccion_pendiente ? 'fotos todavía sin elegir' : 'fotos elegidas'} · hecho el ${fecha(p.created_at)}${deEstaFamilia ? '' : ' · OJO: NO es de este email (no le des datos de este pedido a la familia).'}`;
  }
  if (nombre === 'conversaciones_anteriores') {
    const { data } = await supabase.from('consultas_familias').select('id, asunto, mensaje, estado, created_at').ilike('email', escaparIlike(ctx.email)).order('created_at', { ascending: false }).limit(4);
    if (!data?.length) return 'No tiene consultas anteriores.';
    const partes: string[] = [];
    for (const c of data) {
      const { data: mensajes } = await supabase.from('consultas_familias_mensajes').select('direccion, contenido, created_at').eq('consulta_id', c.id).order('created_at').limit(8);
      partes.push(`Consulta del ${fecha(c.created_at)} «${c.asunto}» (${c.estado}): ${String(c.mensaje || '').slice(0, 400)}\n${(mensajes || []).map((m: any) => `  ${m.direccion === 'entrante' ? 'Familia' : 'Nosotros'}: ${String(m.contenido || '').slice(0, 500)}`).join('\n')}`);
    }
    return partes.join('\n\n');
  }
  return `Herramienta desconocida: ${nombre}`;
}

async function llamarClaude(cuerpo: any, msRestantes: number): Promise<any> {
  const clave = process.env.ANTHROPIC_API_KEY?.trim();
  const control = new AbortController();
  const corte = setTimeout(() => control.abort(), Math.max(5_000, msRestantes));
  try {
    const res = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: { 'content-type': 'application/json', 'x-api-key': String(clave), 'anthropic-version': '2023-06-01' },
      body: JSON.stringify(cuerpo),
      signal: control.signal,
    });
    const data: any = await res.json().catch(() => null);
    if (!res.ok) throw Object.assign(new Error(`Claude respondió ${res.status}: ${data?.error?.message || 'sin detalle'}`), { status: res.status });
    return data;
  } finally {
    clearTimeout(corte);
  }
}

/** El agente completo. Devuelve el borrador con su análisis, o tira error si no llegó a entregar. */
export async function investigarYResponder(params: {
  supabase: SupabaseClient;
  consulta: any;
  ficha: FichaParaIA;
  colegios: string[];
  sistema: string;
  idea?: string;
}): Promise<DecisionIA> {
  if (!process.env.ANTHROPIC_API_KEY?.trim()) throw new Error('Falta ANTHROPIC_API_KEY: no se puede investigar.');
  const inicio = Date.now();
  const modelo = process.env.ANTHROPIC_MODEL_AGENTE?.trim() || MODELO_AGENTE_POR_DEFECTO;
  const ctx = { supabase: params.supabase, email: String(params.consulta.email || '').trim().toLowerCase(), colegios: params.colegios };
  const mensajes: any[] = [{
    role: 'user',
    content: `${encabezadoConsulta(params.consulta)}\n\nFICHA DE LA FAMILIA (armada recién):\n${fichaNumerada(params.ficha).texto}\n${bloqueIdea(params.idea)}\n\nInvestigá lo que haga falta y entregá con "entregar_respuesta".`,
  }];
  let consultasALaBase = 0;
  for (let vuelta = 0; vuelta < MAX_VUELTAS; vuelta++) {
    const restante = PRESUPUESTO_MS - (Date.now() - inicio);
    if (restante < 20_000 && vuelta > 0) {
      mensajes.push({ role: 'user', content: 'Se terminó el tiempo: llamá YA a "entregar_respuesta" con lo que averiguaste (si no estás seguro de algo, ponelo en "decisiones" o "ambiguedades").' });
    }
    const data = await llamarClaude({
      model: modelo,
      max_tokens: 8000,
      output_config: { effort: 'medium' },
      system: [{ type: 'text', text: `${params.sistema}\n\n=== CÓMO TRABAJAR ESTA CONSULTA ===\n${INSTRUCCIONES}`, cache_control: { type: 'ephemeral' } }],
      tools: HERRAMIENTAS,
      messages: mensajes,
    }, Math.max(restante - 2_000, 8_000));
    const bloques: any[] = Array.isArray(data?.content) ? data.content : [];
    mensajes.push({ role: 'assistant', content: bloques });
    const usos = bloques.filter((b) => b?.type === 'tool_use');
    const final = usos.find((b) => b.name === 'entregar_respuesta');
    if (final) {
      const r = final.input || {};
      const lista = (v: unknown) => (Array.isArray(v) ? v.map((x) => String(x || '').trim()).filter(Boolean) : []);
      return {
        tema: String(r.tema || 'otro'),
        respondible: false, // lo armado por el agente siempre lo revisa Pablo (sale desde el panel)
        respuesta: String(r.respuesta || '').trim(),
        motivo: String(r.motivo || '').trim(),
        entendido: String(r.entendido || '').trim(),
        ambiguedades: lista(r.ambiguedades),
        decisiones: (Array.isArray(r.decisiones) ? r.decisiones : []).map((d: any) => ({ pregunta: String(d?.pregunta || '').trim(), opciones: lista(d?.opciones).slice(0, 4) })).filter((d: any) => d.pregunta),
        afirmaciones: [],
        alertas: [],
        verificado: true,
        nota: `Investigada por ${modelo.startsWith('claude-opus') ? 'Claude Opus' : 'Claude'} con ${consultasALaBase} consulta${consultasALaBase === 1 ? '' : 's'} a la base (${Math.round((Date.now() - inicio) / 1000)} s).`,
      };
    }
    if (usos.length === 0) {
      // Respondió con texto sin entregar: se le pide que use la herramienta.
      mensajes.push({ role: 'user', content: 'Entregá el resultado llamando a "entregar_respuesta".' });
      continue;
    }
    const resultados = [];
    for (const uso of usos) {
      consultasALaBase++;
      let contenido: string;
      try {
        contenido = await herramienta(uso.name, uso.input, ctx);
      } catch (err: any) {
        contenido = `Error al consultar: ${String(err?.message || err).slice(0, 200)}`;
      }
      resultados.push({ type: 'tool_result', tool_use_id: uso.id, content: contenido.slice(0, 12_000) });
    }
    mensajes.push({ role: 'user', content: resultados });
  }
  throw new Error('La IA no llegó a entregar la respuesta a tiempo.');
}

