// 27/10/2026 (Pablo, casos Claudia Yagusieczko y Carolina Barbero): familias que se inscribieron con un hijo y
// se olvidaron de sumar a otro. Hasta hoy se arreglaba a mano con SQL sobre `inscripciones.hermanos`. Ahora el
// panel (Inscriptos → «Sumar hijo») busca al chico en la nómina del mismo colegio y lo agrega como hermano, con
// el mismo formato que deja la inscripción. El código de acceso no cambia: con nombre y DNI del tutor la familia
// ve a todos sus hijos. Reenviar el email con el código queda en manos del panel (ruta enviar-email).
import express from 'express';
import type { Request, Response } from 'express';
import crypto from 'crypto';
import { requireAdminAuth } from '../nucleo/auth.js';
import { getServerSupabase } from '../nucleo/clientes.js';
import { normalizarNombreComparable } from '../nucleo/utilidades.js';

const rutas = express.Router();

const palabras = (texto: unknown) => normalizarNombreComparable(texto).split(' ').filter((w) => w.length >= 2);
const mismoCurso = (a: { grado?: unknown; division?: unknown }, b: { grado?: unknown; division?: unknown }) =>
  normalizarNombreComparable(a.grado) === normalizarNombreComparable(b.grado) &&
  normalizarNombreComparable(a.division) === normalizarNombreComparable(b.division);

/** «PEREA, Belen» → { nombre: 'Belen', apellido: 'Perea' } (la nómina viene «Apellido, Nombre», a veces en mayúsculas). */
export function partirNombreNomina(nombreNomina: unknown): { nombre: string; apellido: string } {
  const titulo = (t: string) =>
    t.trim().toLowerCase().split(/\s+/).filter(Boolean).map((w) => w.charAt(0).toUpperCase() + w.slice(1)).join(' ');
  const texto = String(nombreNomina || '').trim();
  const coma = texto.indexOf(',');
  if (coma < 0) return { nombre: titulo(texto), apellido: '' };
  return { nombre: titulo(texto.slice(coma + 1)), apellido: titulo(texto.slice(0, coma)) };
}

/** Los chicos que ya tiene la inscripción (principal + hermanos), para no sumar dos veces al mismo. */
function chicosDeInscripcion(fila: any) {
  const lista = [{ nombre: `${fila?.alumno_nombre || ''} ${fila?.alumno_apellido || ''}`, grado: fila?.grado, division: fila?.division }];
  for (const h of Array.isArray(fila?.hermanos) ? fila.hermanos : []) {
    if (h && typeof h === 'object') lista.push({ nombre: `${h.alumnoNombre || ''} ${h.alumnoApellido || ''}`, grado: h.grado, division: h.division });
  }
  return lista;
}

/** ¿El alumno de la nómina ya está en la inscripción? Mismo curso y todas las palabras de un nombre en el otro. */
export function yaEstaEnInscripcion(fila: any, alumno: { nombre: unknown; grado: unknown; division: unknown }): boolean {
  const delAlumno = palabras(alumno.nombre);
  return chicosDeInscripcion(fila).some((c) => {
    if (!mismoCurso(c, alumno)) return false;
    const delChico = palabras(c.nombre);
    if (!delChico.length || !delAlumno.length) return false;
    return delChico.every((w) => delAlumno.includes(w)) || delAlumno.every((w) => delChico.includes(w));
  });
}

async function leerInscripcion(supabase: any, id: string) {
  const { data, error } = await supabase
    .from('inscripciones')
    .select('id, colegio_id, alumno_nombre, alumno_apellido, grado, division, turno, hermanos, updated_at')
    .eq('id', id)
    .maybeSingle();
  if (error) throw error;
  return data;
}

// Busca en la nómina del colegio de la inscripción (mín. 2 letras). Marca los que ya están en la inscripción.
rutas.get('/api/admin/inscripciones/:id/nomina-hijos', requireAdminAuth, async (req: Request, res: Response) => {
  try {
    const supabase = getServerSupabase();
    if (!supabase) return res.status(500).json({ success: false, error: 'Supabase no configurado en el servidor' });
    const buscadas = palabras(req.query.q);
    if (!buscadas.length) return res.status(400).json({ success: false, error: 'Escribí al menos 2 letras del nombre.' });
    const fila = await leerInscripcion(supabase, req.params.id);
    if (!fila) return res.status(404).json({ success: false, error: 'Inscripción no encontrada' });
    // La palabra más larga, con vocales y ñ como comodín (la nómina trae tildes), y acá se exigen todas.
    const ancla = [...buscadas].sort((a, b) => b.length - a.length)[0].replace(/[aeioun]/g, '_');
    const { data, error } = await supabase
      .from('alumnos')
      .select('id, nombre, grado, division, turno')
      .eq('colegio_id', fila.colegio_id)
      .ilike('nombre', `%${ancla}%`)
      .limit(300);
    if (error) throw error;
    const alumnos = (data || [])
      .filter((a: any) => {
        const n = palabras(a.nombre);
        return buscadas.every((w) => n.some((x) => x.includes(w)));
      })
      .slice(0, 20)
      .map((a: any) => ({ id: a.id, nombre: a.nombre, grado: a.grado, division: a.division, turno: a.turno || null, yaIncluido: yaEstaEnInscripcion(fila, a) }));
    return res.json({ success: true, alumnos });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err?.message || 'No se pudo buscar en la nómina' });
  }
});

// Suma un alumno de la nómina como hermano. Body: { alumnoId }.
rutas.post('/api/admin/inscripciones/:id/hermanos', requireAdminAuth, async (req: Request, res: Response) => {
  try {
    const supabase = getServerSupabase();
    if (!supabase) return res.status(500).json({ success: false, error: 'Supabase no configurado en el servidor' });
    const alumnoId = String(req.body?.alumnoId || '').trim();
    if (!alumnoId) return res.status(400).json({ success: false, error: 'Falta elegir el alumno de la nómina.' });

    const fila = await leerInscripcion(supabase, req.params.id);
    if (!fila) return res.status(404).json({ success: false, error: 'Inscripción no encontrada' });
    const { data: alumno, error: errAlumno } = await supabase
      .from('alumnos')
      .select('id, colegio_id, nombre, grado, division, turno, dni')
      .eq('id', alumnoId)
      .maybeSingle();
    if (errAlumno) throw errAlumno;
    if (!alumno) return res.status(404).json({ success: false, error: 'Ese alumno ya no está en la nómina.' });
    if (String(alumno.colegio_id) !== String(fila.colegio_id)) {
      return res.status(400).json({ success: false, error: 'Ese alumno es de otro colegio.' });
    }
    if (yaEstaEnInscripcion(fila, alumno)) {
      return res.status(409).json({ success: false, error: `${alumno.nombre} ya está en esta inscripción.` });
    }

    // El turno: el de la nómina; si no lo tiene (secundaria), el del código del curso cuando hay uno solo.
    let turno = String(alumno.turno || '').trim();
    if (!turno) {
      const { data: codigos, error: errCod } = await supabase
        .from('codigos_seccion')
        .select('turno')
        .eq('colegio_id', fila.colegio_id)
        .eq('grado', alumno.grado)
        .eq('division', alumno.division);
      if (errCod) throw errCod;
      const turnos = Array.from(new Set((codigos || []).map((c: any) => String(c.turno || '').trim()).filter(Boolean)));
      if (turnos.length !== 1) {
        return res.status(409).json({
          success: false,
          error: turnos.length
            ? `${alumno.grado} "${alumno.division}" tiene más de un turno y la nómina no dice cuál: cargale el turno en la Nómina y probá de nuevo.`
            : `${alumno.grado} "${alumno.division}" no tiene código de curso: crealo en «Códigos y difusión» y probá de nuevo.`,
        });
      }
      turno = turnos[0];
    }

    const { nombre, apellido } = partirNombreNomina(alumno.nombre);
    const hermano = {
      id: `hermano-admin-${Date.now()}-${crypto.randomBytes(2).toString('hex')}`,
      grado: alumno.grado,
      turno,
      division: alumno.division,
      alumnoDni: String(alumno.dni || '').replace(/\D/g, ''),
      colegioId: fila.colegio_id,
      alumnoNombre: nombre,
      alumnoApellido: apellido,
      verificadoEnNomina: true,
      verificadoEnPadron: false,
    };
    const hermanos = [...(Array.isArray(fila.hermanos) ? fila.hermanos : []), hermano];

    // Si otra pestaña cambió la inscripción mientras tanto, no se pisa: se pide recargar.
    let consulta = supabase.from('inscripciones').update({ hermanos, updated_at: new Date().toISOString() }).eq('id', fila.id);
    if (fila.updated_at) consulta = consulta.eq('updated_at', fila.updated_at);
    const { data: guardada, error: errGuardar } = await consulta.select('id, hermanos').maybeSingle();
    if (errGuardar) throw errGuardar;
    if (!guardada) return res.status(409).json({ success: false, error: 'La inscripción cambió mientras tanto. Recargá la lista y probá de nuevo.' });
    return res.json({ success: true, hermano, hermanos: guardada.hermanos });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err?.message || 'No se pudo sumar al alumno' });
  }
});

export { rutas as rutasSumarHijo };
