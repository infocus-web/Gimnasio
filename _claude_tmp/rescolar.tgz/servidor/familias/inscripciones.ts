// Inscripciones de las familias (validación contra el padrón y la nómina, ingreso con código + nombre +
// DNI, confirmación de acceso, hijos de la familia), administración de inscripciones y del padrón, y
// los códigos secretos de sección del panel (división de server.ts, etapa 5, 10/10/2026). El código es
// el mismo que estaba en las secciones "4B. INSCRIPCIONES" y "4D. ADMINISTRACIÓN DE CÓDIGOS REALES DE
// SECCIÓN" de server.ts: sólo se movió. También están acá el número de lista y el código de alumno de
// los pedidos (los usan las rutas de pedidos).
import type { SupabaseClient } from '@supabase/supabase-js';
import crypto from 'crypto';
import express from 'express';
import type { Request, Response } from 'express';
import { registrarAlertaPago } from '../nucleo/alertas.js';
import { compararTimingSafe, getAdminSessionSecret, requireAdminAuth } from '../nucleo/auth.js';
import { casillaAvisosAdmin, getResendClient, getServerSupabase } from '../nucleo/clientes.js';
import { ErrorChoqueCodigoCurso, invalidarCacheCodigosSeccion, normalizarCodigoSeccion, plegarCodigoSeccion, seccionConCodigoParecido, traerTodosLosCodigosSeccion, verificarSinChoqueCodigoCurso } from '../nucleo/codigosCurso.js';
import { buscarColegioReal, ERROR_COLEGIO_NO_VALIDO } from '../nucleo/colegios.js';
import { VERSION_TERMINOS_SERVIDOR } from '../nucleo/legal.js';
import { separarYaImportadas } from '../nucleo/importacionSinDuplicados.js';
import { hayCupoGlobal, hayCupoPorClave, hayCupoReenvioCodigo, limitarFrecuencia, limitarFrecuenciaPersistente, superoTopeIntentos } from '../nucleo/limites.js';
import { nombrePropio, nombresCompatibles } from '../nucleo/nombres.js';
import { escapeHtml, ipDelCliente, normalizarNombreComparable, normalizarNombrePorPalabras, traerTodasLasFilas } from '../nucleo/utilidades.js';
import { dniParcialServidor, enviarCorreoCodigoAcceso, inscripcionSinConfirmar, linkConfirmacionAcceso, tokenConfirmacionAcceso } from './accesoFamilias.js';
import type { DatosCorreoCodigoAcceso } from './accesoFamilias.js';
import { crearBuscadorEnNomina, cursoFueraDeNomina } from './cursosNomina.js';
import { alumnosDeInscripcion, alumnosParaCorreo } from './inscripcionesAdmin.js';

const rutas = express.Router();

// ==============================================================================
// 4B. INSCRIPCIONES: VALIDACIÓN AUTOMÁTICA CONTRA PADRÓN Y GESTIÓN ADMIN
// ==============================================================================


export function normalizarTelefonoServidor(tel: string): string {
  return (tel || '').replace(/\D/g, '');
}

// Auditoría 2026-09-22 (pedido de Pablo: "que cada vez que vayan a ingresar, lo hagan con
// nombre y apellido del padre, tutor o encargado, el DNI del padre, tutor o encargado, y el
// código generado"): igual que el teléfono, el DNI se compara sólo por dígitos (sin puntos ni
// espacios que la familia pueda haber tipeado).
function normalizarDniServidor(dni: unknown): string {
  return String(dni || '').replace(/\D/g, '');
}

// Auditoría 2026-09-22 (bug real encontrado en auditoría de código, BAJO): los timestamps
// legibles que se guardan en `fecha_inscripcion`/`fecha_aprobacion` se armaban con
// `now.getDate()/getMonth()/getHours()`, que usan la hora LOCAL DEL PROCESO NODE, no la de
// Argentina. En un despliegue serverless (Vercel) el runtime suele correr en UTC, así que esas
// fechas quedaban grabadas y mostradas en el panel con ~3hs de diferencia respecto a la hora
// real en la que la familia se inscribió o se la aprobó — confuso para el fotógrafo al revisar
// "cuándo pasó esto". Se centraliza acá con Intl.DateTimeFormat fijando explícitamente el huso
// horario de Argentina, sin importar en qué huso corra el servidor.
function formatearFechaHoraArgentina(fecha: Date): string {
  const partes = new Intl.DateTimeFormat('es-AR', {
    timeZone: 'America/Argentina/Buenos_Aires',
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    hour12: false,
  }).formatToParts(fecha);
  const obtener = (tipo: string) => partes.find((p) => p.type === tipo)?.value || '';
  return `${obtener('day')}/${obtener('month')}/${obtener('year')} ${obtener('hour')}:${obtener('minute')}`;
}

// Auditoría 2026-09-22 (Pablo: "¿por qué el código minilab no figura en esos pedidos de
// prueba?"): mismo criterio de refuerzo que ya se aplicó a curso_codigo — nunca confiar en un
// valor derivado que mande el navegador cuando el servidor puede calcularlo solo con datos que
// ya validó. Réplica exacta de `sanitizarParaMinilab` (src/services/pedidosLabService.ts) —
// función pura de texto, sin ninguna dependencia de navegador, así que es segura de duplicar acá.
function sanitizarParaMinilabServidor(texto: string): string {
  return texto
    .normalize('NFD')
    .replace(/[̀-ͯ]/g, '')
    .toUpperCase()
    .replace(/[^A-Z0-9_]/g, '_')
    .replace(/_+/g, '_')
    .replace(/^_|_$/g, '');
}

/**
 * Auditoría 2026-09-22: hasta ahora el "número de lista" de cada pedido (usado sólo para armar
 * el código de minilab y ordenar los archivos del laboratorio, nunca vino de ningún padrón real
 * de la escuela) se generaba en el navegador con `Math.floor(1 + Math.random() * 25)` — un
 * número al azar en cada pedido, incluso para el MISMO alumno pagando de nuevo. Dos
 * consecuencias reales, visibles en el panel: (1) el código de minilab de un mismo alumno
 * cambiaba de pedido a pedido sin ningún motivo; (2) dos alumnos distintos del mismo curso
 * podían coincidir en el mismo número al azar, generando el mismo código de minilab para dos
 * fotos distintas (colisión real de nombre de archivo). Se reemplaza por un correlativo estable:
 * cuántos pedidos ya existen para ese mismo curso_codigo, +1 — determinístico dentro de ese
 * curso y sin depender de ningún dato que el navegador pueda inventar. No es el número de lista
 * oficial del colegio (el sistema no guarda ninguno), pero al menos dos pedidos del mismo curso
 * nunca van a coincidir en el mismo número.
 */
// Auditoría 03/10 (medio): el código de curso (p. ej. "GRADO1-ATM") se repite entre colegios: sin
// filtrar por colegio_id, los números de un colegio se mezclaban con los de otro. Ahora se cuenta y
// se verifica dentro del mismo colegio.
// 08/10/2026: la base garantiza que el número no se repite (índice único pedidos_numero_lista_unico:
// colegio + curso + número, sin contar las mejoras a Kit Impreso, que repiten a propósito el número
// del pedido original). El siguiente número es el más alto usado + 1 (antes era la cantidad de
// pedidos + 1, que con números salteados podía chocar con uno existente). Si dos compras simultáneas
// toman el mismo, `insertarPedidosConReintento` renumera y reintenta.
export async function ultimoNumeroLista(supabase: SupabaseClient, cursoCodigo: string, colegioId?: string | null): Promise<number> {
  let consulta = supabase
    .from('pedidos')
    .select('alumno_numero_lista')
    .eq('curso_codigo', cursoCodigo)
    .is('mejora_de_pedido_id', null)
    .not('alumno_numero_lista', 'is', null);
  if (colegioId) consulta = consulta.eq('colegio_id', colegioId);
  const { data, error } = await consulta.order('alumno_numero_lista', { ascending: false }).limit(1);
  if (error) throw error;
  return Number(data?.[0]?.alumno_numero_lista) || 0;
}

export async function obtenerNumeroListaSecuencial(supabase: ReturnType<typeof getServerSupabase>, cursoCodigo: string, colegioId?: string | null): Promise<number> {
  try {
    return (await ultimoNumeroLista(supabase!, cursoCodigo, colegioId)) + 1;
  } catch {
    // Si la lectura falla no se traba el pedido: si el 1 ya está usado, el índice único lo frena y
    // `insertarPedidosConReintento` vuelve a numerar.
    return 1;
  }
}

// Clave de la numeración: el mismo código de curso existe en varios colegios.
export function claveCursoNumeroLista(colegioId: unknown, cursoCodigo: unknown): string {
  return `${String(colegioId || '')}|${String(cursoCodigo || '')}`;
}

// Da números de lista nuevos (el último usado + 1, + 2…) a las filas de pedidos normales y rehace su
// código de minilab. Las mejoras a Kit Impreso conservan el número del pedido original.
export function renumerarFilasPorCurso(filas: Record<string, any>[], ultimoPorCurso: Map<string, number>): void {
  for (const fila of filas) {
    if (fila.mejora_de_pedido_id || fila.extras_de_pedido_id || !fila.curso_codigo) continue; // 29/10: las fotos extra no llevan número
    const clave = claveCursoNumeroLista(fila.colegio_id, fila.curso_codigo);
    const siguiente = (ultimoPorCurso.get(clave) || 0) + 1;
    ultimoPorCurso.set(clave, siguiente);
    fila.alumno_numero_lista = siguiente;
    fila.codigo_alumno = calcularCodigoAlumnoServidor(String(fila.curso_codigo), siguiente, String(fila.alumno_nombre || ''));
  }
}

export function calcularCodigoAlumnoServidor(cursoCodigo: string, numeroLista: number, alumnoNombre: string): string {
  return `${sanitizarParaMinilabServidor(cursoCodigo)}_${String(numeroLista).padStart(2, '0')}_${sanitizarParaMinilabServidor(alumnoNombre || 'ALUMNO')}`;
}

/** Enmascara un email para mostrarlo en una respuesta pública sin revelarlo completo (ej: "ju***@gmail.com") */
function enmascararEmailServidor(email: string): string {
  const [usuario, dominio] = String(email || '').split('@');
  if (!usuario || !dominio) return '';
  const visible = usuario.slice(0, Math.min(2, usuario.length));
  return `${visible}${'*'.repeat(Math.max(3, usuario.length - visible.length))}@${dominio}`;
}

// ==============================================================================
// CÓDIGOS DE SECCIÓN: el código real y secreto que necesita una familia para ver
// las fotos de un curso puntual (colegio + grado + turno + división).
//
// IMPORTANTE — por qué existe esto: `determinarCodigoCursoServidor` de arriba es
// una FÓRMULA pública y determinística (mismo texto de grado/turno/división →
// siempre el mismo código). Sirve para ETIQUETAR internamente las fotos en la
// tabla `fotos`, pero nunca debe tratarse como un secreto: cualquiera que mire
// el código fuente del sitio (es un repo público) o simplemente elija las
// opciones del combo de grado/turno/división puede reconstruirlo exacto sin
// haber recibido nunca un código real. Por eso `/api/fotos` YA NO usa esa
// fórmula como control de acceso: exige y valida el código guardado acá, en
// `codigos_seccion`, que es un valor aleatorio generado por el servidor (o
// elegido a mano por el fotógrafo) y jamás derivable a partir del grado, turno
// o división. Esta tabla no tiene ninguna policy de lectura pública en Supabase:
// sólo el servidor (Service Role Key) puede consultarla.
function generarCodigoSecretoSeccion(): string {
  // Alfabeto sin 0/O/1/I para que no se confundan al leerlo o dictarlo por WhatsApp.
  const alfabeto = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let codigo = '';
  for (let i = 0; i < 8; i++) {
    codigo += alfabeto[crypto.randomInt(alfabeto.length)];
  }
  return `${codigo.slice(0, 4)}-${codigo.slice(4, 8)}`;
}

// Auditoría 2026-09-23 (bug real): la validación del portal compara los códigos NORMALIZADOS (sin
// guiones ni espacios: "AB12-CD34" == "AB12CD34"), pero los chequeos de "¿este código ya lo usa
// otra sección?" comparaban el texto exacto. Los códigos generados se guardan con guion
// ("AB12-CD34") y los fijados a mano desde el panel sin él ("AB12CD34"), así que dos secciones
// distintas podían quedar con el "mismo" código — y el portal le mostraba a una familia la
// galería de OTRO curso (la primera que apareciera). Este chequeo compara igual que el portal.
async function codigoSeccionEnUso(supabase: any, codigo: string, excluirId?: string | null): Promise<boolean> {
  const buscado = plegarCodigoSeccion(codigo); // 13/10: plegado (O/0, I/L/1), igual que el ingreso de las familias
  if (!buscado) return false;
  const filas = await traerTodosLosCodigosSeccion(supabase, { fresco: true });
  return filas.some((fila) => fila.id !== excluirId && plegarCodigoSeccion(fila.codigo_secreto) === buscado);
}

/**
 * Devuelve el código secreto ya asignado a esta sección (colegio+grado+turno+división)
 * si ya existe, o crea uno nuevo si es la primera vez. Todas las familias de la misma
 * sección terminan compartiendo el mismo código (así funciona hoy: un código por curso,
 * para todo el grupo de WhatsApp de esa sección), pero ese código nunca se puede adivinar
 * desde afuera. Si se pasa `candidatoPreferido` (por ejemplo, un código que el fotógrafo
 * escribió a mano, o uno pre-cargado en el padrón), se usa como valor inicial siempre que
 * no esté ya en uso por otra sección distinta.
 */
async function obtenerOCrearCodigoSeccion(
  supabase: any,
  colegioId: string,
  grado: string,
  turno: string,
  division: string,
  candidatoPreferido?: string | null
): Promise<string> {
  const cid = String(colegioId || '').trim();
  const g = String(grado || '').trim();
  const t = String(turno || '').trim();
  const d = String(division || '').trim();

  const { data: existente } = await supabase
    .from('codigos_seccion')
    .select('codigo_secreto')
    .eq('colegio_id', cid)
    .eq('grado', g)
    .eq('turno', t)
    .eq('division', d)
    .maybeSingle();
  if (existente?.codigo_secreto) {
    return existente.codigo_secreto;
  }
  await verificarSinChoqueCodigoCurso(supabase, cid, g, t, d); // auditoría 11/10 (FAM-2): 409 si choca con otra sección

  let candidato = String(candidatoPreferido || '').trim().toUpperCase();
  // Auditoría 03/10 noche (B2): una sugerencia corta (escrita a mano o del padrón) se descarta y se
  // genera un código al azar: un código corto se adivina y abre la galería del curso.
  if (candidato && normalizarCodigoSeccion(candidato).length < 8) candidato = '';
  if (candidato) {
    if (await codigoSeccionEnUso(supabase, candidato)) {
      // Ese código ya pertenece a otra sección distinta: se descarta y se genera uno nuevo,
      // en vez de dejar que dos secciones distintas terminen compartiendo el mismo código.
      candidato = '';
    }
  }
  if (!candidato) {
    // Auditoría 2026-09-16: antes se usaba el código recién generado al azar sin chequear si ya
    // pertenecía a otra sección (ese chequeo sólo se hacía para un candidato sugerido a mano,
    // arriba) — con pocos intentos de reintento acá alcanza para blindarlo también en este caso.
    for (let intento = 0; intento < 5; intento++) {
      const propuesto = generarCodigoSecretoSeccion();
      if (!(await codigoSeccionEnUso(supabase, propuesto))) {
        candidato = propuesto;
        break;
      }
    }
    if (!candidato) candidato = generarCodigoSecretoSeccion();
  }

  const { data: creado, error } = await supabase
    .from('codigos_seccion')
    .insert({ colegio_id: cid, grado: g, turno: t, division: d, codigo_secreto: candidato })
    .select('codigo_secreto')
    .single();
  invalidarCacheCodigosSeccion();

  if (error) {
    // Posible carrera (dos aprobaciones casi simultáneas para la misma sección): releer
    // en vez de fallar, ya que probablemente alguien más ya la creó un instante antes.
    const { data: relectura } = await supabase
      .from('codigos_seccion')
      .select('codigo_secreto')
      .eq('colegio_id', cid)
      .eq('grado', g)
      .eq('turno', t)
      .eq('division', d)
      .maybeSingle();
    if (relectura?.codigo_secreto) return relectura.codigo_secreto;
    throw error;
  }

  return creado.codigo_secreto;
}

// ==============================================================================
// 4D. ADMINISTRACIÓN DE CÓDIGOS REALES DE SECCIÓN — 2026-09-09
// ==============================================================================
// La pestaña "Códigos & Difusión WhatsApp" del panel usaba códigos INVENTADOS, guardados
// solo en el navegador (localStorage) y editables a mano — nunca tenían nada que ver con el
// código secreto real de `codigos_seccion` (el que de verdad valida `/api/fotos` para dejar
// entrar a una familia). Es decir que un colegio o una familia podían recibir por WhatsApp un
// código que no funcionaba en el sitio. Estas rutas permiten al panel leer y gestionar los
// códigos REALES para poder armar la difusión con el código que de verdad funciona.

// Lista los códigos reales ya asignados a las secciones de un colegio (para mostrarlos en el panel).
rutas.get('/api/admin/codigos-seccion', requireAdminAuth, async (req: Request, res: Response) => {
  try {
    const supabase = getServerSupabase();
    if (!supabase) {
      return res.status(500).json({ success: false, error: 'Supabase no configurado en el servidor' });
    }
    const { colegioId } = req.query as Record<string, string | undefined>;
    if (!colegioId) {
      return res.status(400).json({ success: false, error: 'Falta colegioId' });
    }
    const { data, error } = await supabase
      .from('codigos_seccion')
      .select('grado, turno, division, codigo_secreto')
      .eq('colegio_id', colegioId);
    if (error) throw error;
    return res.json({ success: true, codigos: data || [] });
  } catch (err: any) {
    console.error('Error al listar códigos de sección:', err);
    return res.status(500).json({ success: false, error: err?.message || 'Error al listar los códigos' });
  }
});

// Se asegura de que una sección tenga un código real asignado — si ya tiene uno, lo devuelve
// tal cual (no lo pisa); si no tiene, crea uno nuevo aleatorio. Así el panel puede mostrar
// (o generar por primera vez) el código real de cada curso sin esperar a que una familia lo
// dispare sola al inscribirse.
rutas.post('/api/admin/codigos-seccion/asegurar', requireAdminAuth, async (req: Request, res: Response) => {
  try {
    const supabase = getServerSupabase();
    if (!supabase) {
      return res.status(500).json({ success: false, error: 'Supabase no configurado en el servidor' });
    }
    const { colegioId, grado, turno, division } = req.body || {};
    if (!colegioId || !grado || !turno) {
      return res.status(400).json({ success: false, error: 'Faltan colegioId, grado o turno' });
    }
    const codigo = await obtenerOCrearCodigoSeccion(supabase, colegioId, grado, turno, division || '');
    return res.json({ success: true, codigo });
  } catch (err: any) {
    console.error('Error al asegurar código de sección:', err);
    return res.status(err instanceof ErrorChoqueCodigoCurso ? 409 : 500).json({ success: false, error: err?.message || 'Error al asegurar el código' });
  }
});

// Genera un código nuevo (aleatorio) para una sección, reemplazando el anterior si existía —
// el código viejo deja de funcionar. Igual que `obtenerOCrearCodigoSeccion` pero forzando
// siempre un valor nuevo, con reintentos por si el azar generara uno ya usado (prácticamente
// imposible con el alfabeto de 8 caracteres, pero más vale prevenir).
rutas.post('/api/admin/codigos-seccion/regenerar', requireAdminAuth, async (req: Request, res: Response) => {
  try {
    const supabase = getServerSupabase();
    if (!supabase) {
      return res.status(500).json({ success: false, error: 'Supabase no configurado en el servidor' });
    }
    const { colegioId, grado, turno, division } = req.body || {};
    if (!colegioId || !grado || !turno) {
      return res.status(400).json({ success: false, error: 'Faltan colegioId, grado o turno' });
    }
    const cid = String(colegioId).trim();
    const g = String(grado).trim();
    const t = String(turno).trim();
    const d = String(division || '').trim();
    await verificarSinChoqueCodigoCurso(supabase, cid, g, t, d);

    let nuevoCodigo = '';
    for (let intento = 0; intento < 5; intento++) {
      const candidato = generarCodigoSecretoSeccion();
      if (!(await codigoSeccionEnUso(supabase, candidato))) {
        nuevoCodigo = candidato;
        break;
      }
    }
    if (!nuevoCodigo) {
      return res.status(500).json({ success: false, error: 'No se pudo generar un código único, probá de nuevo.' });
    }

    const { data: existente } = await supabase
      .from('codigos_seccion')
      .select('id')
      .eq('colegio_id', cid)
      .eq('grado', g)
      .eq('turno', t)
      .eq('division', d)
      .maybeSingle();

    if (existente?.id) {
      const { error } = await supabase.from('codigos_seccion').update({ codigo_secreto: nuevoCodigo }).eq('id', existente.id);
      if (error) throw error;
    } else {
      const { error } = await supabase
        .from('codigos_seccion')
        .insert({ colegio_id: cid, grado: g, turno: t, division: d, codigo_secreto: nuevoCodigo });
      if (error) throw error;
    }
    invalidarCacheCodigosSeccion();

    return res.json({ success: true, codigo: nuevoCodigo });
  } catch (err: any) {
    console.error('Error al regenerar código de sección:', err);
    return res.status(err instanceof ErrorChoqueCodigoCurso ? 409 : 500).json({ success: false, error: err?.message || 'Error al regenerar el código' });
  }
});

// Fija a mano el código real de una sección (por ejemplo, uno más fácil de leer para una
// escuela puntual). Rechaza el pedido si ese código ya pertenece a otra sección distinta,
// para nunca dejar dos secciones compartiendo sin querer el mismo código de acceso.
rutas.post('/api/admin/codigos-seccion/actualizar', requireAdminAuth, async (req: Request, res: Response) => {
  try {
    const supabase = getServerSupabase();
    if (!supabase) {
      return res.status(500).json({ success: false, error: 'Supabase no configurado en el servidor' });
    }
    const { colegioId, grado, turno, division, nuevoCodigo } = req.body || {};
    if (!colegioId || !grado || !turno || !nuevoCodigo) {
      return res.status(400).json({ success: false, error: 'Faltan colegioId, grado, turno o el nuevo código' });
    }
    const cid = String(colegioId).trim();
    const g = String(grado).trim();
    const t = String(turno).trim();
    const d = String(division || '').trim();
    const codigoNormalizado = normalizarCodigoSeccion(nuevoCodigo);
    // Auditoría 03/10 noche (B2): un código corto ("3A2026") se adivina y abre la galería del curso.
    if (codigoNormalizado.length < 8) {
      return res.status(400).json({ success: false, error: 'El código tiene que tener al menos 8 caracteres (mejor letras y números al azar).' });
    }

    const { data: existente } = await supabase
      .from('codigos_seccion')
      .select('id')
      .eq('colegio_id', cid)
      .eq('grado', g)
      .eq('turno', t)
      .eq('division', d)
      .maybeSingle();

    await verificarSinChoqueCodigoCurso(supabase, cid, g, t, d);
    if (await codigoSeccionEnUso(supabase, codigoNormalizado, existente?.id || null)) {
      return res.status(409).json({ success: false, error: 'Ese código ya lo está usando otra sección. Elegí uno distinto.' });
    }

    if (existente?.id) {
      const { error } = await supabase.from('codigos_seccion').update({ codigo_secreto: codigoNormalizado }).eq('id', existente.id);
      if (error) throw error;
    } else {
      const { error } = await supabase
        .from('codigos_seccion')
        .insert({ colegio_id: cid, grado: g, turno: t, division: d, codigo_secreto: codigoNormalizado });
      if (error) throw error;
    }
    invalidarCacheCodigosSeccion();

    return res.json({ success: true, codigo: codigoNormalizado });
  } catch (err: any) {
    console.error('Error al actualizar código de sección:', err);
    return res.status(err instanceof ErrorChoqueCodigoCurso ? 409 : 500).json({ success: false, error: err?.message || 'Error al actualizar el código' });
  }
});

// La nómina (`crearBuscadorEnNomina`, cursos válidos) está en ./cursosNomina.ts (12/10/2026).

// Inscripción pública: valida contra el padrón autorizado del colegio y asigna código al instante si coincide.
// Todo el acceso a `padres_autorizados` e `inscripciones` pasa exclusivamente por acá, del lado del servidor
// (con la Service Role Key) — el navegador nunca consulta esas tablas directamente.
// Auditoría 2026-09-23: este endpoint público no tenía límite de frecuencia (manda correos y
// escribe en la base), a diferencia del resto de los formularios públicos.
/** Auditoría 2026-09-27: aviso al admin de una inscripción del padrón que quedó para revisar. */
async function avisarAdminInscripcionParaRevisar(datos: { padreNombre: string; alumno: string; curso: string; colegio: string; hermanos: string[]; motivo?: string }) {
  const resend = getResendClient();
  if (!resend) return;
  // Auditoría 03/10 (alto 15/28): con muchos envíos del formulario (o un ataque) esto llenaba la
  // casilla de Pablo y gastaba el cupo de Resend. La inscripción queda igual en el panel.
  if (!(await hayCupoGlobal('aviso-inscripcion-revisar', 60, 3600))) return;
  const fromEmail = process.env.RESEND_FROM_EMAIL || 'Retrato Escolar <fotos@retratoescolar.com.ar>';
  const hermanosTxt = datos.hermanos.length
    ? `<p>Hermanos sin confirmar en la nómina: ${datos.hermanos.map(escapeHtml).join(', ')}</p>`
    : '';
  const { error } = await resend.emails.send({
    from: fromEmail,
    to: [casillaAvisosAdmin()],
    subject: `Inscripción para revisar: ${datos.alumno}`,
    html: `<div style="font-family:Arial,sans-serif">
<p>${escapeHtml(datos.motivo || 'Una familia del padrón se inscribió pero el curso no coincide con la nómina, así que quedó')} <strong>pendiente</strong>.</p>
<p><strong>${escapeHtml(datos.padreNombre)}</strong> — ${escapeHtml(datos.alumno)} — ${escapeHtml(datos.curso)} — ${escapeHtml(datos.colegio)}</p>
${hermanosTxt}
<p>Revisala en el panel → Inscriptos y aprobala si el curso es correcto.</p></div>`,
  });
  if (error) console.warn('[Resend] Aviso de inscripción para revisar rechazado:', error);
}

// Auditoría 03/10 (alto 15/28): además del tope en memoria (por instancia), uno persistente por IP:
// cada envío escribe en la base y puede mandar emails. Alto para no frenar el WiFi de un colegio.
// Auditoría 03/10 (2ª vuelta): límites por IP altos a propósito — en un colegio muchas familias salen
// por la misma IP (WiFi del colegio, CGNAT de las telefónicas).
rutas.post('/api/inscripciones/validar', limitarFrecuencia('inscripciones-validar', 300, 15 * 60 * 1000), limitarFrecuenciaPersistente('inscripciones-validar-ip', 300, 15 * 60 * 1000), async (req: Request, res: Response) => {
  // Auditoría 03/10 (2ª vuelta): fila del padrón reservada (usado=true) por ESTE envío que todavía
  // no quedó respaldada por una inscripción guardada. Si algo falla después de reservarla (excepción
  // en cualquier paso) o el envío termina usando otra fila, se libera (usado=false); si no, la
  // familia quedaba sin poder aprobarse sola nunca más.
  let padronReservadoSinGuardar: string | null = null;
  const liberarPadronReservado = async () => {
    const id = padronReservadoSinGuardar;
    padronReservadoSinGuardar = null;
    const sb = id ? getServerSupabase() : null;
    if (id && sb) await sb.from('padres_autorizados').update({ usado: false }).eq('id', id).then(() => undefined, () => undefined);
  };
  try {
    // 10/10 (pedido de Pablo): «PABLITA Alderete» se guarda «Pablita Alderete» (ver nombrePropio).
    const cuerpo = { ...(req.body || {}) };
    for (const campo of ['padreNombre', 'alumnoNombre', 'alumnoApellido']) {
      if (typeof cuerpo[campo] === 'string') cuerpo[campo] = nombrePropio(cuerpo[campo]);
    }
    if (Array.isArray(cuerpo.hermanos)) {
      cuerpo.hermanos = cuerpo.hermanos.map((h: any) =>
        h && typeof h === 'object'
          ? {
              ...h,
              ...(typeof h.alumnoNombre === 'string' ? { alumnoNombre: nombrePropio(h.alumnoNombre) } : {}),
              ...(typeof h.alumnoApellido === 'string' ? { alumnoApellido: nombrePropio(h.alumnoApellido) } : {}),
            }
          : h
      );
    }
    const {
      colegioId,
      colegioNombre,
      padreNombre,
      padreDni,
      telefonoWhatsApp,
      email,
      alumnoNombre,
      alumnoApellido,
      alumnoDni,
      grado,
      division,
      turno,
      solicitaFotoHermanos,
      hermanos: hermanosRecibidos,
      consentimientos: consentimientosRecibidos,
      versionTerminos: versionConsentimientos,
    } = cuerpo;
    // Marco legal (27/9): consentimientos de imagen y datos, en casillas separadas (CCyC art. 53,
    // Ley 11.723 art. 31, Ley 25.326 arts. 5, 6 y 12). Los tres primeros son obligatorios para
    // prestar el servicio; el uso promocional es opcional. Se guardan con fecha, versión e IP.
    const consentimientos = {
      toma: consentimientosRecibidos?.toma === true,
      grupal: consentimientosRecibidos?.grupal === true,
      transferencia: consentimientosRecibidos?.transferencia === true,
      promocional: consentimientosRecibidos?.promocional === true,
    };
    if (!consentimientos.toma || !consentimientos.grupal || !consentimientos.transferencia || versionConsentimientos !== VERSION_TERMINOS_SERVIDOR) {
      return res.status(400).json({ success: false, error: 'Para inscribirte tenés que tildar las tres autorizaciones obligatorias (fotos, fotos grupales y privacidad). Si ya las tildaste, recargá la página e intentá de nuevo.' });
    }
    const camposConsentimiento = {
      consentimientos,
      consentimientos_version: VERSION_TERMINOS_SERVIDOR,
      consentimientos_at: new Date().toISOString(),
      consentimientos_ip: ipDelCliente(req),
    };
    // Tope defensivo: un array enorme de "hermanos" se guardaba entero en la fila (jsonb).
    const hermanos = Array.isArray(hermanosRecibidos) ? hermanosRecibidos.slice(0, 10) : [];
    // 08/10 (pedido de Pablo): la foto de hermanos se guarda tal como la tildó la familia (y sólo si
    // anotó hermanos). Antes se marcaba sola a TODA familia con hermanos, tildara o no la casilla.
    const pideFotoHermanos = solicitaFotoHermanos === true && hermanos.length > 0;

    if (!padreNombre || !alumnoNombre || !colegioId || !telefonoWhatsApp || !email) {
      return res.status(400).json({ success: false, error: 'Faltan datos obligatorios para la inscripción' });
    }
    // Auditoría 03/10 noche (A3): el nombre del alumno se compara con las etiquetas de las fotos
    // individuales; un nombre larguísimo coincidía con muchos chicos. Tope razonable de largo y de
    // palabras (también para cada hermano).
    const nombreDemasiadoLargo = (nombre: unknown, apellido: unknown) => {
      const palabras = normalizarNombreComparable(`${nombre || ''} ${apellido || ''}`).split(' ').filter(Boolean);
      return (
        String(nombre || '').trim().length > 80 ||
        String(apellido || '').trim().length > 80 ||
        palabras.length > 12 ||
        // "de", "la", "del"… no cuentan: "Juan Martín de la Fuente Rodríguez Peña" pasa.
        palabras.filter((p) => p.length >= 3).length > 7
      );
    };
    if (
      nombreDemasiadoLargo(alumnoNombre, alumnoApellido) ||
      hermanos.some((h: any) => nombreDemasiadoLargo(h?.alumnoNombre, h?.alumnoApellido))
    ) {
      return res.status(400).json({ success: false, error: 'Escribí sólo el nombre y el apellido de cada alumno/a (sin otros datos).' });
    }
    const alumnoDniLimpio = String(alumnoDni || '').replace(/\D/g, '');
    if (alumnoDniLimpio.length < 6 || alumnoDniLimpio.length > 9) {
      return res.status(400).json({ success: false, error: 'El DNI del alumno/a no es válido' });
    }
    // Auditoría 2026-09-22 (pedido de Pablo, ronda 2 — el formulario de inscripción todavía no
    // pedía el DNI del tutor, sólo se lo agregué al ingreso posterior): se pide acá también, de
    // entrada, para que quede cargado desde el primer momento y no dependa de identificar por
    // nombre en el primer ingreso (ver `/api/inscripciones/buscar`) — ese camino por nombre
    // queda sólo como respaldo para las familias aprobadas ANTES de este cambio.
    const padreDniLimpio = normalizarDniServidor(padreDni);
    if (padreDniLimpio.length < 6 || padreDniLimpio.length > 9) {
      return res.status(400).json({ success: false, error: 'El DNI del padre, madre o tutor no es válido' });
    }

    const supabase = getServerSupabase();
    if (!supabase) {
      return res.status(500).json({ success: false, error: 'Supabase no configurado en el servidor' });
    }

    const colegioReal = await buscarColegioReal(supabase, colegioId);
    if (!colegioReal) {
      return res.status(400).json({ success: false, error: ERROR_COLEGIO_NO_VALIDO });
    }
    // 12/10: sólo cursos que existen en la nómina del colegio (ver cursosNomina.ts).
    const errorCurso = await cursoFueraDeNomina(supabase, colegioReal.id, { grado, division, turno }, hermanos);
    if (errorCurso) return res.status(400).json({ success: false, error: errorCurso });

    const telDigits = normalizarTelefonoServidor(telefonoWhatsApp);
    const telUltimos = telDigits.length >= 8 ? telDigits.slice(-8) : telDigits;
    const cleanEmail = String(email || '').trim().toLowerCase();

    let matchPadre: any = null;
    let candidatosPadron: any[] = [];
    try {
      // Paginado: un colegio grande supera las 1000 filas de padrón y la coincidencia se perdía.
      // Auditoría 03/10 (alto 15): sólo las columnas que se usan (antes `*` del padrón entero).
      const candidatos = await traerTodasLasFilas<any>((desde, hasta) =>
        supabase
          .from('padres_autorizados')
          .select('id, nombre, email, telefono, alumno_nombre, grado, turno, division, codigo_asignado, origen')
          .eq('colegio_id', colegioId)
          .eq('usado', false)
          .order('id')
          .range(desde, hasta)
      );

      if (Array.isArray(candidatos)) {
        candidatosPadron = candidatos;
        // Auditoría 03/10 noche (C1): si la familia tiene varias filas en el padrón (una por hijo, con
        // el mismo contacto), se prefiere la del alumno que se está inscribiendo.
        const mismoContacto = candidatos.filter((p: any) => filaPadronConMismoContacto(p, cleanEmail, telDigits, telUltimos));
        const nombreAlumnoFormulario = `${alumnoNombre || ''} ${alumnoApellido || ''}`;
        matchPadre =
          mismoContacto.find((p: any) => p.alumno_nombre && nombresCompatibles(p.alumno_nombre, nombreAlumnoFormulario)) ||
          mismoContacto[0] ||
          null;
      }
    } catch (e) {
      console.warn('Advertencia al consultar padres_autorizados:', e);
    }

    // Auditoría 2026-09-21 (refuerzo — hallazgo: hermanos nunca se reconciliaban contra el
    // padrón, a diferencia del alumno principal). Antes, el array "hermanos" se guardaba tal
    // cual lo mandara el navegador — grado/turno/división (e incluso colegioId) totalmente
    // inventados por quien completa el formulario. Como `/api/familia/hijos` resuelve (y CREA
    // si no existe) el código secreto real de cualquier grado/turno/división que le pidan para
    // cada "hermano" sin ninguna verificación, esto permitía que una familia YA aprobada (un
    // estado perfectamente normal, no un ataque sofisticado) agregara un "hermano" inventado
    // con la sección de otro curso — o de otro colegio — y se le devolviera el código secreto
    // real de esa sección ajena, sin pasar por ninguna revisión. Mismo criterio que ya se aplica
    // al alumno principal (matchPadre, más arriba): el colegio SIEMPRE es el de esta inscripción
    // (nunca el que declare el hermano), y si hay una fila del padrón oficial de ESTE colegio con
    // el mismo contacto (teléfono/email) y un nombre que matchea, su grado/turno/división real
    // manda por sobre lo que haya tipeado la familia — igual que ya ocurre con el alumno
    // principal cuando el padrón trae esos datos cargados.
    const cursoEnNomina = await crearBuscadorEnNomina(supabase, colegioReal.id);
    const hermanosReconciliados = await Promise.all((Array.isArray(hermanos) ? hermanos : []).map(async (h: any) => {
      const nombreCompletoHermano = normalizarNombrePorPalabras(`${h?.alumnoNombre || ''} ${h?.alumnoApellido || ''}`);
      const matchHermano = nombreCompletoHermano
        ? candidatosPadron.find((p: any) => normalizarNombrePorPalabras(p.alumno_nombre) === nombreCompletoHermano)
        : null;
      const nominaHermano = await cursoEnNomina(`${h?.alumnoNombre || ''} ${h?.alumnoApellido || ''}`, h?.grado);
      // Auditoría 03/10 noche (A3): para aprobarse SOLA, cada hermano tiene que figurar en una fila
      // del padrón cargada por el colegio con el MISMO contacto de esta familia. Que el nombre exista
      // en la nómina no prueba que sea hermano (con eso cualquier familia agregaba chicos ajenos y
      // recibía el código de su curso y sus fotos individuales).
      const hermanoEnPadronMismoContacto = candidatosPadron.some(
        (p: any) =>
          p.origen !== 'link' &&
          p.alumno_nombre &&
          filaPadronConMismoContacto(p, cleanEmail, telDigits, telUltimos) &&
          nombresCompatibles(p.alumno_nombre, `${h?.alumnoNombre || ''} ${h?.alumnoApellido || ''}`)
      );
      return {
        verificadoEnPadron: hermanoEnPadronMismoContacto,
        // Auditoría 30/9: sólo los campos conocidos y con largo acotado (antes se guardaba el
        // objeto tal cual lo mandaba el navegador, con cualquier clave y tamaño).
        id: String(h?.id ?? '').trim().slice(0, 60) || undefined,
        alumnoNombre: String(h?.alumnoNombre ?? '').trim().slice(0, 120),
        alumnoApellido: String(h?.alumnoApellido ?? '').trim().slice(0, 120),
        alumnoDni: normalizarDniServidor(h?.alumnoDni).slice(0, 12),
        // Auditoría 2026-09-27: si el curso del hermano no se pudo confirmar con el padrón ni con la
        // nómina, la inscripción no se aprueba sola (ver `cursoVerificado` más abajo).
        verificadoEnNomina: Boolean((matchHermano?.grado && String(matchHermano.grado).trim()) || nominaHermano),
        colegioId, // nunca el que venga en el hermano: siempre el colegio de esta inscripción
        grado: (matchHermano?.grado && String(matchHermano.grado).trim()) || nominaHermano?.grado || String(h?.grado ?? '').trim().slice(0, 60),
        turno: (matchHermano?.turno && String(matchHermano.turno).trim()) || nominaHermano?.turno || String(h?.turno ?? '').trim().slice(0, 60),
        division: (matchHermano?.division && String(matchHermano.division).trim()) || nominaHermano?.division || String(h?.division ?? '').trim().slice(0, 60),
      };
    }));

    // Buscar si esta misma familia (mismo colegio + mismo WhatsApp o email) ya tiene una
    // inscripción cargada, para actualizarla en vez de crear un duplicado (por ejemplo, cuando
    // la familia usa "Modificar datos de inscripción" y vuelve a enviar el formulario).
    let inscripcionExistente: any = null;
    let inscripcionesDelColegio: any[] = [];
    try {
      // Paginado: con más de 1000 inscripciones en el colegio, la existente podía no aparecer y
      // se creaba un duplicado.
      // Auditoría 03/10 (alto 15): sólo las columnas que se usan acá (antes `*`, con consentimientos,
      // IP, DNI de todos los chicos del colegio, etc.).
      const existentes = await traerTodasLasFilas<any>((desde, hasta) =>
        supabase
          .from('inscripciones')
          .select(COLUMNAS_INSCRIPCION_VALIDAR)
          .eq('colegio_id', colegioId)
          .neq('estado', 'rechazado')
          .order('id')
          .range(desde, hasta)
      );

      if (Array.isArray(existentes)) {
        inscripcionesDelColegio = existentes;
        inscripcionExistente = existentes.find((i: any) => {
          if (cleanEmail && i.email && String(i.email).trim().toLowerCase() === cleanEmail) return true;
          if (telDigits) {
            const iTel = normalizarTelefonoServidor(i.telefono_whatsapp || '');
            if (iTel && (iTel === telDigits || (telUltimos.length >= 8 && iTel.endsWith(telUltimos)))) return true;
          }
          return false;
        }) || null;
      }
    } catch (e) {
      console.warn('Advertencia al buscar inscripción existente:', e);
    }

    // Auditoría 30/9 (A2): el email y el teléfono no son secretos. Una inscripción PENDIENTE sólo se
    // actualiza si quien vuelve a mandar el formulario usa el mismo email y el mismo DNI de tutor
    // (o la guardada todavía no tenía DNI); si no, se crea una fila nueva y el fotógrafo ve las dos.
    // Antes cualquiera que supiera el teléfono de otra familia le pisaba el email y el DNI, y el
    // código le llegaba al atacante cuando el fotógrafo aprobaba.
    if (inscripcionExistente && inscripcionExistente.estado !== 'aceptado') {
      const mismoEmail = Boolean(cleanEmail) && String(inscripcionExistente.email || '').trim().toLowerCase() === cleanEmail;
      const dniGuardado = normalizarDniServidor(inscripcionExistente.padre_dni || '');
      const mismoDni = !dniGuardado || dniGuardado === padreDniLimpio;
      if (!mismoEmail || !mismoDni) inscripcionExistente = null;
    }

    const now = new Date();
    const fechaStr = formatearFechaHoraArgentina(now);

    // Si la familia ya estaba aceptada (con código asignado), mantenemos su estado y código:
    // sólo actualizamos sus datos de contacto/curso, nunca le hacemos perder el acceso ya otorgado.
    let estado: 'aceptado' | 'pendiente' = inscripcionExistente?.estado === 'aceptado' ? 'aceptado' : 'pendiente';
    let codigoAcceso: string | null = inscripcionExistente?.estado === 'aceptado'
      ? (inscripcionExistente.codigo_asignado || null)
      : null;

    // Curso que efectivamente se aprueba: si hay una fila autorizada en `padres_autorizados`
    // que ya trae su propio grado/turno/división cargados (por ejemplo, subidos junto con el
    // padrón oficial del colegio), ese es el curso que manda — nunca lo que haya tipeado quien
    // completa el formulario. Auditoría 2026-09-09 (revisión a fondo): antes se usaba siempre
    // grado/turno/división del body de la petición pública para generar el código real de
    // sección, incluso cuando la aprobación automática venía por `matchPadre` — es decir que
    // alguien con acceso al link de padrón de una familia (colegio_id + código) podía
    // autoinscribirse con su propio contacto y pedir el código real de CUALQUIER grado/turno/
    // división que quisiera, no sólo el que le corresponde, y así ver las fotos de cursos
    // ajenos. Si la fila autorizada no tiene su propio grado/turno/división cargados (padrones
    // viejos, sin esos datos), se sigue aceptando lo que mande el formulario como antes.
    // Orden de prioridad del curso: padrón (si trae curso) > nómina oficial (ver
    // crearBuscadorEnNomina) > lo que eligió la familia en el formulario.
    const cursoNominaPrincipal = await cursoEnNomina(`${alumnoNombre || ''} ${alumnoApellido || ''}`, grado);
    const gradoAprobado = (matchPadre?.grado && String(matchPadre.grado).trim()) || cursoNominaPrincipal?.grado || grado;
    const turnoAprobado = (matchPadre?.turno && String(matchPadre.turno).trim()) || cursoNominaPrincipal?.turno || turno;
    const divisionAprobada = (matchPadre?.division && String(matchPadre.division).trim()) || cursoNominaPrincipal?.division || division;


    // Auditoría 2026-09-09 (revisión a fondo, hallazgo reportado por Pablo): hasta acá, con sólo
    // escribir el número de WhatsApp (o el email) de CUALQUIER fila del padrón oficial en este
    // formulario público — un dato que de ninguna manera es secreto, lo puede tener cualquier
    // compañero de curso, un grupo de WhatsApp del colegio, etc. — se aprobaba la inscripción al
    // instante y el código de acceso real se devolvía directo en la respuesta de esta misma
    // petición, visible para quien la hizo, sin importar si esa persona era realmente el padre o
    // no. Es decir: el número de teléfono de un padre funcionaba como si fuera su contraseña.
    // Ahora, para aprobar automáticamente, además de encontrar la coincidencia en el padrón hace
    // falta un email cargado en esa fila (el que subió el colegio, nunca el que haya tipeado
    // quien completa el formulario) — el código se manda SOLO por correo a esa dirección, y
    // nunca viaja en la respuesta de esta petición. Así, aunque alguien conozca o adivine el
    // teléfono de un padre, no puede ver el código: sólo quien tiene acceso a esa casilla de
    // correo puede. Si la fila del padrón no tiene email cargado, no se puede entregar el código
    // de forma segura por acá — la inscripción queda "pendiente" para que el fotógrafo la revise
    // y envíe el código a mano desde el panel, en vez de exponerlo.
    // Auditoría 2026-09-27: el padrón se autocarga desde un link que el colegio comparte con todas
    // las familias, así que una fila de padrón no prueba el curso. Sólo se aprueba sola si el curso
    // del alumno (y el de cada hermano) coincide con el padrón o con la nómina oficial; si no,
    // queda pendiente para que el fotógrafo la revise desde el panel.
    // Auditoría 30/9 (C1): además, nunca se aprueba sola si alguno de los chicos ya figura en OTRA
    // inscripción de este colegio (otra familia que lo anotó antes: el fotógrafo decide), ni si la
    // fila del padrón la cargó cualquiera desde el link compartido (origen 'link') y trae hermanos.
    // Antes, con una fila autocargada desde el link y el nombre de un chico ajeno tal como figura
    // en la nómina, se aprobaba sola y la galería le mostraba las fotos individuales de ese chico.
    const nombresDeEstaFamilia = [
      normalizarNombrePorPalabras(`${alumnoNombre || ''} ${alumnoApellido || ''}`),
      ...hermanosReconciliados.map((h: any) => normalizarNombrePorPalabras(`${h?.alumnoNombre || ''} ${h?.alumnoApellido || ''}`)),
    ].filter(Boolean);
    const chicoYaInscriptoPorOtraFamilia = inscripcionesDelColegio.some((i: any) => {
      if (inscripcionExistente && i.id === inscripcionExistente.id) return false;
      const suyos = [
        normalizarNombrePorPalabras(`${i.alumno_nombre || ''} ${i.alumno_apellido || ''}`),
        ...(Array.isArray(i.hermanos) ? i.hermanos : []).map((h: any) => normalizarNombrePorPalabras(`${h?.alumnoNombre || ''} ${h?.alumnoApellido || ''}`)),
      ].filter(Boolean);
      // Auditoría 03/10 noche (A3): antes sólo contaba el nombre exacto ("Juan Pérez" no chocaba con
      // "Juan Martín Pérez" ya inscripto). Ahora cuenta cualquier nombre compatible.
      return suyos.some((n) => nombresDeEstaFamilia.some((m) => n === m || nombresCompatibles(n, m)));
    });
    // Auditoría 03/10 noche (C1): la fila del padrón se elige sólo por teléfono o email (datos que
    // no son secretos). Para aprobarse SOLA, además, el alumno escrito tiene que ser el de esa fila y
    // el tutor tiene que compartir al menos una palabra con el nombre cargado por el colegio. Si no,
    // queda pendiente para que el fotógrafo la revise.
    const alumnoCoincideConPadron = Boolean(
      matchPadre?.alumno_nombre && nombresCompatibles(matchPadre.alumno_nombre, `${alumnoNombre || ''} ${alumnoApellido || ''}`)
    );
    const palabrasTutorPadron = new Set(normalizarNombreComparable(matchPadre?.nombre).split(' ').filter((p) => p.length >= 3));
    const tutorCoincideConPadron =
      palabrasTutorPadron.size === 0 ||
      normalizarNombreComparable(padreNombre).split(' ').some((p) => p.length >= 3 && palabrasTutorPadron.has(p));
    // Auditoría 03/10 (crítico 1): una fila del padrón cargada desde el link compartido (origen
    // 'link') la puede haber cargado CUALQUIERA con su propio email: nunca aprueba sola una
    // inscripción (antes alcanzaba con poner el nombre de un chico ajeno tal como figura en la
    // nómina para recibir el código y ver sus fotos individuales). Queda pendiente y se avisa.
    const filaPadronDelLink = matchPadre?.origen === 'link';
    const cursoVerificado =
      Boolean((matchPadre?.grado && String(matchPadre.grado).trim()) || cursoNominaPrincipal) &&
      hermanosReconciliados.every((h: any) => h.verificadoEnNomina && h.verificadoEnPadron) &&
      !chicoYaInscriptoPorOtraFamilia &&
      !filaPadronDelLink &&
      alumnoCoincideConPadron &&
      tutorCoincideConPadron;
    let emailEnviado = false;
    let reenvioReciente = false;
    let emailDestinoNotificacion: string | null = null;
    let envioAutoAprobado: DatosCorreoCodigoAcceso | null = null;
    if (estado !== 'aceptado' && matchPadre && !cursoVerificado) {
      void avisarAdminInscripcionParaRevisar({
        motivo: filaPadronDelLink
          ? 'Una familia cargada desde el link del padrón (no verificada por el colegio) se inscribió y quedó'
          : chicoYaInscriptoPorOtraFamilia
            ? 'Una familia se inscribió con un alumno que ya figura en otra inscripción del colegio, así que quedó'
            : !alumnoCoincideConPadron
              ? 'Una familia se inscribió con el teléfono/email de una fila del padrón pero con OTRO alumno (o la fila no tiene alumno), así que quedó'
              : !tutorCoincideConPadron
                ? 'Una familia se inscribió con el teléfono/email de una fila del padrón pero con otro nombre de tutor, así que quedó'
                : hermanosReconciliados.some((h: any) => !h.verificadoEnPadron)
                  ? 'Una familia del padrón se inscribió con hermanos que no figuran en el padrón con su mismo contacto, así que quedó'
                  : undefined,
        padreNombre: String(padreNombre).trim(),
        alumno: `${String(alumnoNombre).trim()} ${String(alumnoApellido || '').trim()}`.trim(),
        curso: `${gradoAprobado} ${divisionAprobada} (${turnoAprobado})`,
        colegio: colegioReal.nombre,
        hermanos: hermanosReconciliados.filter((h: any) => !h.verificadoEnNomina).map((h: any) => `${h.alumnoNombre || ''} ${h.alumnoApellido || ''}`.trim()),
      }).catch((e) => console.warn('No se pudo avisar la inscripción para revisar:', e));
    }
    if (estado !== 'aceptado' && matchPadre && cursoVerificado) {
      const emailOficialPadron = matchPadre.email ? String(matchPadre.email).trim().toLowerCase() : '';
      // Auditoría 03/10 (alto 15): la fila del padrón se "toma" con un UPDATE condicional (sólo si
      // sigue sin usar) ANTES de aprobar y mandar el código: dos envíos simultáneos con el mismo
      // contacto ya no aprueban dos inscripciones con la misma fila.
      let filaPadronTomada = false;
      if (emailOficialPadron && emailOficialPadron.includes('@')) {
        const { data: tomadas, error: errTomar } = await supabase
          .from('padres_autorizados')
          .update({ usado: true, updated_at: new Date().toISOString() })
          .eq('id', matchPadre.id)
          .eq('usado', false)
          .select('id');
        filaPadronTomada = !errTomar && Array.isArray(tomadas) && tomadas.length > 0;
        if (filaPadronTomada) padronReservadoSinGuardar = matchPadre.id;
      }
      // Auditoría 11/10 (FAM-2): si la sección choca con otra del colegio, queda pendiente con una alerta.
      const codigoSeccionAuto = filaPadronTomada
        ? await obtenerOCrearCodigoSeccion(supabase, colegioId, gradoAprobado, turnoAprobado, divisionAprobada, matchPadre.codigo_asignado).catch(async (e) => {
            if (!(e instanceof ErrorChoqueCodigoCurso)) throw e;
            await registrarAlertaPago(supabase, `choque-curso:${colegioId}:${gradoAprobado}:${turnoAprobado}:${divisionAprobada}`, `INSCRIPCIÓN PARA REVISAR: ${e.message}`, { colegio: colegioId });
            await liberarPadronReservado();
            return null;
          })
        : null;
      if (codigoSeccionAuto) {
        estado = 'aceptado';
        codigoAcceso = codigoSeccionAuto;
        emailDestinoNotificacion = emailOficialPadron;
        // Auditoría 03/10 noche (C1): el email con el código (y el botón "confirmar mi email") sale
        // DESPUÉS de guardar la inscripción, porque el link lleva su id. Hasta que se confirme, la
        // familia no puede ingresar al portal (ver /api/inscripciones/buscar).
        envioAutoAprobado = {
          to: emailOficialPadron,
          padreNombre: (matchPadre.nombre && String(matchPadre.nombre).trim()) || String(padreNombre).trim(),
          colegioNombre: colegioReal.nombre,
          codigo: codigoAcceso,
          alumnos: alumnosParaCorreo(
            { nombre: String(alumnoNombre).trim(), apellido: String(alumnoApellido || '').trim(), grado: gradoAprobado, division: divisionAprobada, turno: turnoAprobado },
            hermanosReconciliados
          ),
          solicitaFotoHermanos: pideFotoHermanos,
        };
      }
      // Si la fila del padrón no tiene email cargado, la inscripción queda "pendiente" (no se
      // aprueba automáticamente) — ver comentario de auditoría arriba.
    } else if (estado === 'aceptado' && inscripcionExistente?.email && codigoAcceso && !(await hayCupoReenvioCodigo(String(inscripcionExistente.id)))) {
      // Auditoría 03/10 (alto 24): como mucho un reenvío del código cada 10 minutos por inscripción
      // (antes se podía llenar de mails la casilla de una familia mandando el formulario con su
      // teléfono). Se responde como enviado: el último ya está en su correo.
      emailEnviado = true;
      reenvioReciente = true;
      emailDestinoNotificacion = String(inscripcionExistente.email).trim().toLowerCase();
    } else if (estado === 'aceptado' && inscripcionExistente?.email && codigoAcceso) {
      // Reenvío: la familia ya estaba aprobada y volvió a completar el formulario (por ejemplo,
      // porque no encontró el correo original). Se reenvía SIEMPRE al email que ya estaba
      // guardado en la inscripción (el que se validó en su momento contra el padrón) — nunca al
      // que haya tipeado ahora, por la misma razón de seguridad de arriba.
      try {
        // Se reenvía con los datos YA GUARDADOS (los que aprobó el fotógrafo), no con lo tipeado.
        const resultadoReenvio = await enviarCorreoCodigoAcceso({
          to: String(inscripcionExistente.email).trim().toLowerCase(),
          padreNombre: String(inscripcionExistente.padre_nombre || padreNombre).trim(),
          colegioNombre: String(inscripcionExistente.colegio_nombre || colegioNombre || 'Colegio').trim(),
          codigo: codigoAcceso,
          alumnos: alumnosDeInscripcion(inscripcionExistente),
          solicitaFotoHermanos: Boolean(inscripcionExistente.solicita_foto_hermanos),
          ...(inscripcionSinConfirmar(inscripcionExistente) && linkConfirmacionAcceso(inscripcionExistente.id)
            ? { confirmacion: { link: linkConfirmacionAcceso(inscripcionExistente.id) as string, tutor: String(inscripcionExistente.padre_nombre || '').trim(), dniParcial: dniParcialServidor(inscripcionExistente.padre_dni) } }
            : {}),
        });
        emailEnviado = Boolean(resultadoReenvio.success);
        if (emailEnviado) emailDestinoNotificacion = String(inscripcionExistente.email).trim().toLowerCase();
      } catch (e) {
        console.warn('No se pudo reenviar el email de código de acceso:', e);
      }
    }

    // El contacto que queda guardado para una inscripción APROBADA es siempre uno ya validado —
    // el del padrón oficial (matchPadre) si se acaba de aprobar recién, o el que ya estaba
    // guardado de una aprobación anterior — NUNCA lo que haya tipeado quien completó el
    // formulario esta vez. Es "pegajoso" a propósito: si no, alguien podría volver a mandar el
    // mismo formulario con el teléfono real de una familia YA aprobada (así matchea contra su
    // inscripción existente) pero con SU PROPIO email, y ese email reemplazaría al real —
    // dejando el reenvío manual futuro desde el panel apuntando a la casilla del atacante. Para
    // una inscripción que sigue "pendiente" sí se guarda el contacto tal como lo escribió la
    // persona, porque ahí no se aprueba ni se entrega ningún código automáticamente — el
    // fotógrafo revisa a mano antes de aprobar.
    const emailGuardado = estado === 'aceptado'
      ? (matchPadre?.email ? String(matchPadre.email).trim().toLowerCase() : (inscripcionExistente?.email || cleanEmail))
      : cleanEmail;
    const telefonoGuardado = estado === 'aceptado'
      ? (matchPadre?.telefono ? String(matchPadre.telefono).trim() : (inscripcionExistente?.telefono_whatsapp || String(telefonoWhatsApp).trim()))
      : String(telefonoWhatsApp).trim();

    const inscripcionRow: Record<string, any> = {
      ...camposConsentimiento,
      padre_nombre: String(padreNombre).trim(),
      padre_dni: padreDniLimpio,
      telefono_whatsapp: telefonoGuardado,
      email: emailGuardado,
      alumno_nombre: String(alumnoNombre).trim(),
      alumno_apellido: String(alumnoApellido || '').trim(),
      alumno_dni: alumnoDniLimpio,
      // El curso corregido (padrón/nómina) se guarda también en las pendientes: así, cuando el
      // fotógrafo la aprueba desde el panel, el código que se genera es el de la sección real.
      turno: String(turnoAprobado || 'Mañana').trim(),
      grado: String(gradoAprobado || 'Sala 3 años').trim(),
      division: String(divisionAprobada || 'A').trim(),
      colegio_id: colegioReal.id,
      colegio_nombre: colegioReal.nombre,
      estado,
      codigo_asignado: codigoAcceso,
      codigo_familiar: codigoAcceso,
      solicita_foto_hermanos: pideFotoHermanos,
      // 08/10: con hermanos anotados, lo que se guarda es lo que la familia eligió (casilla real): ya está
      // confirmado y no entra en la consulta «foto de hermanos» (ver CONSULTA «FOTO DE HERMANOS»).
      foto_hermanos_confirmada_at: hermanos.length > 0 ? new Date().toISOString() : null,
      hermanos: hermanosReconciliados,
      fecha_inscripcion: inscripcionExistente?.fecha_inscripcion || fechaStr,
      fecha_aprobacion: estado === 'aceptado' ? (inscripcionExistente?.fecha_aprobacion || fechaStr) : null,
      notificacion_whatsapp_enviada: inscripcionExistente ? Boolean(inscripcionExistente.notificacion_whatsapp_enviada) : false,
      notificacion_email_enviada: emailEnviado || (inscripcionExistente ? Boolean(inscripcionExistente.notificacion_email_enviada) : false),
      // Auditoría 03/10 noche (C1): aprobada sola = falta que el titular del email del padrón confirme.
      ...(envioAutoAprobado ? { acceso_confirmado_at: null } : {}),
    };

    // Auditoría 2026-09-23 (bug de seguridad, ALTO): una inscripción YA APROBADA se encuentra
    // acá sólo por teléfono o email — datos que no son secretos (los tiene cualquiera del grupo
    // de WhatsApp del curso). Antes, reenviar este formulario público con el teléfono de otra
    // familia aprobada REESCRIBÍA su fila: nombre y DNI del tutor (el DNI es lo que ahora se usa
    // para ingresar al portal), alumnos, hermanos y hasta el curso (regenerando el código). Con
    // eso alguien podía (a) apropiarse del acceso de esa familia poniendo su propio DNI, o (b)
    // agregarle un "hermano" en cualquier otro curso y obtener el código real de ese curso vía
    // /api/familia/hijos. Ahora una inscripción aprobada NO se modifica desde el formulario
    // público: sólo se le reenvía el código a su correo ya validado. Cualquier corrección de
    // datos de una familia aprobada la hace el fotógrafo desde el panel.
    const congelarInscripcionAprobada = inscripcionExistente?.estado === 'aceptado';
    // Auditoría 03/10 noche (M10): en una inscripción aprobada tampoco se pisan los consentimientos
    // (son la prueba legal de lo que autorizó la familia; antes los reescribía cualquiera que mandara
    // el formulario con su teléfono o email).
    const filaAGuardar: Record<string, any> = congelarInscripcionAprobada
      ? { notificacion_email_enviada: inscripcionRow.notificacion_email_enviada }
      : inscripcionRow;

    let resultadoFila: any = null;
    let errGuardar: any = null;

    if (inscripcionExistente?.id) {
      const { data: actualizada, error } = await supabase
        .from('inscripciones')
        .update(filaAGuardar)
        .eq('id', inscripcionExistente.id)
        .select()
        .single();
      resultadoFila = actualizada;
      errGuardar = error;
    } else {
      // Auditoría 03/10 (alto 15): doble envío del formulario (doble toque, reintento por red mala):
      // los dos pedidos leían "no hay inscripción" y se creaban dos filas. Justo antes de insertar
      // se busca una inscripción del mismo tutor y alumno (DNI) en este colegio de los últimos
      // 10 minutos; si existe, se usa ésa. (La garantía completa necesita un índice único: ver
      // migraciones pendientes.)
      const { data: recientes } = await supabase
        .from('inscripciones')
        .select('*')
        .eq('colegio_id', colegioReal.id)
        .eq('alumno_dni', alumnoDniLimpio)
        .eq('padre_dni', padreDniLimpio)
        .neq('estado', 'rechazado')
        .gte('created_at', new Date(Date.now() - 10 * 60 * 1000).toISOString())
        .order('created_at', { ascending: false })
        .limit(1);
      const candidataDuplicada = Array.isArray(recientes) && recientes.length > 0 ? recientes[0] : null;
      // Igual que arriba (A2): una pendiente sólo se reutiliza si además coincide el email.
      const duplicadaReciente =
        candidataDuplicada &&
        (candidataDuplicada.estado === 'aceptado' || String(candidataDuplicada.email || '').trim().toLowerCase() === String(emailGuardado || '').trim().toLowerCase())
          ? candidataDuplicada
          : null;
      if (duplicadaReciente?.estado === 'aceptado') {
        // Este envío "perdió" la carrera contra uno que ya quedó aprobado: no se toca esa fila (y la
        // fila del padrón que haya reservado este envío no se usó: se libera).
        resultadoFila = duplicadaReciente;
        estado = 'aceptado';
        envioAutoAprobado = null;
        await liberarPadronReservado();
      } else if (duplicadaReciente) {
        const { data: actualizada, error } = await supabase
          .from('inscripciones')
          .update(inscripcionRow)
          .eq('id', duplicadaReciente.id)
          .neq('estado', 'aceptado')
          .select()
          .maybeSingle();
        resultadoFila = actualizada || duplicadaReciente;
        errGuardar = error;
        if (!actualizada) {
          envioAutoAprobado = null;
          estado = duplicadaReciente.estado === 'aceptado' ? 'aceptado' : 'pendiente';
          // No se guardó la aprobación de este envío: la fila del padrón reservada se libera.
          if (!error) await liberarPadronReservado();
        }
      } else {
        const { data: creada, error } = await supabase
          .from('inscripciones')
          .insert(inscripcionRow)
          .select()
          .single();
        resultadoFila = creada;
        errGuardar = error;
      }
    }

    if (errGuardar) {
      // La fila del padrón se tomó para esta aprobación: si no se pudo guardar, se libera.
      // (lo hace el catch de abajo con liberarPadronReservado).
      throw errGuardar;
    }
    // Inscripción guardada: la fila del padrón reservada ya quedó respaldada.
    padronReservadoSinGuardar = null;

    // Auditoría 03/10 noche (C1): email de la aprobación automática, con el botón de confirmación.
    // 14/10/2026 (auditoría): el cupo de reenvío (10 min) se consume DESPUÉS de un envío exitoso: si Resend
    // falla, el reintento manda de verdad; si salió, el reintento (ya aprobada → rama de reenvío) no repite.
    if (envioAutoAprobado && resultadoFila?.id && resultadoFila.estado === 'aceptado') {
      const link = linkConfirmacionAcceso(resultadoFila.id);
      try {
        const resultadoEnvio = await enviarCorreoCodigoAcceso({
          ...envioAutoAprobado,
          ...(link ? { confirmacion: { link, tutor: String(padreNombre).trim(), dniParcial: dniParcialServidor(padreDniLimpio) } } : {}),
        });
        emailEnviado = Boolean(resultadoEnvio.success);
      } catch (e) {
        console.warn('No se pudo enviar el email de código de acceso automático:', e);
      }
      if (emailEnviado) {
        await hayCupoPorClave(`reenvio-codigo:${resultadoFila.id}`, 1, 600);
        await supabase.from('inscripciones').update({ notificacion_email_enviada: true }).eq('id', resultadoFila.id).then(() => undefined, () => undefined);
      }
    }

    // Auditoría 2026-09-09 (revisión a fondo): el código de acceso real YA NO viaja en esta
    // respuesta — ver comentario de auditoría más arriba. El frontend debe indicarle a la
    // familia que revise su correo (o que espere la revisión manual del fotógrafo), nunca
    // mostrar un código en pantalla en este flujo automático. Ojo: no alcanza con sacar
    // `codigoAcceso` del nivel superior de la respuesta — `resultadoFila` es la fila cruda de
    // Supabase e incluye igual las columnas `codigo_asignado`/`codigo_familiar`, así que hay
    // que sacarlas explícitamente antes de devolverla, si no el mismo código se sigue filtrando
    // por esta otra puerta.
    const { codigo_asignado: _codigoAsignadoOculto, codigo_familiar: _codigoFamiliarOculto, ...inscripcionSinCodigo } = resultadoFila || {};
    // Auditoría 2026-09-23 (bug de privacidad, ALTO): cuando el formulario coincide (por teléfono o
    // email, datos NO secretos) con una inscripción YA APROBADA, `resultadoFila` es la fila de ESA
    // familia — que puede no ser quien completó el formulario. Se devolvía completa: DNI del tutor
    // (la llave que hoy se usa junto al código del curso para entrar al portal), DNI del alumno,
    // email, teléfono y hermanos. Ahora, en ese caso, sólo viaja lo mínimo para mostrar la pantalla
    // de "revisá tu correo", con los nombres que escribió quien envió el formulario.
    // Lo mismo aplica a una aprobación automática recién hecha: el email/teléfono guardados son
    // los del padrón oficial, no necesariamente los que escribió quien completó el formulario.
    const inscripcionRespuesta = estado === 'aceptado'
      ? {
          id: inscripcionSinCodigo.id,
          estado: inscripcionSinCodigo.estado,
          colegio_id: inscripcionSinCodigo.colegio_id,
          colegio_nombre: inscripcionSinCodigo.colegio_nombre,
          padre_nombre: String(padreNombre).trim(),
          alumno_nombre: String(alumnoNombre).trim(),
          alumno_apellido: String(alumnoApellido || '').trim(),
          grado: congelarInscripcionAprobada ? String(grado || '') : inscripcionSinCodigo.grado,
          division: congelarInscripcionAprobada ? String(division || '') : inscripcionSinCodigo.division,
          turno: congelarInscripcionAprobada ? String(turno || '') : inscripcionSinCodigo.turno,
          // Sólo los nombres que escribió quien envió el formulario (para el "y N hermanos más").
          hermanos: (Array.isArray(hermanos) ? hermanos : []).map((h: any, idx: number) => ({
            id: String(h?.id || `hermano-${idx}`),
            alumnoNombre: String(h?.alumnoNombre || ''),
            alumnoApellido: String(h?.alumnoApellido || ''),
          })),
        }
      : inscripcionSinCodigo;
    return res.json({
      success: true,
      estado,
      emailEnviado,
      // El correo destino de una familia ya aprobada tampoco se muestra completo (ver arriba).
      // Auditoría 03/10 noche (M10): siempre enmascarado (antes, si coincidía con el escrito, se
      // devolvía completo y confirmaba que ese email estaba inscripto en el colegio).
      emailDestino: emailEnviado && emailDestinoNotificacion ? enmascararEmailServidor(emailDestinoNotificacion) : null,
      ...(reenvioReciente ? { reenvioReciente: true } : {}),
      // 14/10/2026: la familia ya estaba aprobada y lo que escribió NO se guardó (el front lo explica).
      ...(congelarInscripcionAprobada ? { congelada: true } : {}),
      inscripcion: inscripcionRespuesta,
    });
  } catch (err: any) {
    await liberarPadronReservado();
    console.error('Error al validar inscripción:', err);
    return res.status(500).json({ success: false, error: err?.message || 'Error interno al procesar inscripción' });
  }
});

/** 14/10/2026: nombre del tutor a medias para mostrar en pantalla («Pablo A.»), sin el apellido completo. */
export function tutorParcial(nombre: unknown): string {
  const partes = String(nombre || '').trim().split(/\s+/).filter(Boolean);
  if (partes.length === 0) return '';
  return partes.length > 1 ? `${partes[0]} ${partes[1].charAt(0).toLocaleUpperCase('es-AR')}.` : partes[0];
}

const COLUMNAS_INSCRIPCION_VALIDAR =
  'id, estado, email, telefono_whatsapp, padre_nombre, padre_dni, alumno_nombre, alumno_apellido, hermanos, grado, division, turno, colegio_nombre, codigo_asignado, solicita_foto_hermanos, fecha_inscripcion, fecha_aprobacion, notificacion_whatsapp_enviada, notificacion_email_enviada, acceso_confirmado_at';

/** ¿Esta fila del padrón tiene el mismo email o teléfono que el formulario? */
function filaPadronConMismoContacto(p: any, cleanEmail: string, telDigits: string, telUltimos: string): boolean {
  if (cleanEmail && p?.email && String(p.email).trim().toLowerCase() === cleanEmail) return true;
  if (telDigits) {
    const pTel = normalizarTelefonoServidor(p?.telefono || '');
    if (pTel && (pTel === telDigits || (telUltimos.length >= 8 && pTel.endsWith(telUltimos)))) return true;
  }
  return false;
}

// Recuperar mi inscripción por código, teléfono o email (público). Devuelve como máximo UN
// registro propio — nunca la tabla completa — y usa siempre comparaciones exactas/parametrizadas
// (nada de interpolar el texto del usuario en un filtro .or() crudo, que sería explotable).
//
// Auditoría 2026-09-09 (revisión a fondo, hallazgo reportado por Pablo): "cualquier persona,
// poniendo el número de teléfono de alguno de los empadronados, puede acceder al código". Esta
// era exactamente la puerta: esta ruta (usada tanto por la pestaña "Ya me inscribí" como por el
// cuadro de "ingresar código" para ver las fotos) buscaba por teléfono O email y, si encontraba
// una familia YA aprobada, devolvía la fila completa —con `codigo_asignado` incluido— a quien
// sea que haya escrito ese teléfono, sin ninguna prueba de que esa persona fuera realmente el
// padre/madre. El teléfono de un padre empadronado no es un secreto: lo puede tener cualquier
// compañero de curso. Ahora: si lo que se escribió ES el código real (coincide exacto contra
// `codigo_asignado`/`codigo_familiar`), quien lo escribió ya demostró tenerlo — se devuelve la
// familia completa. Si lo que se escribió es un teléfono o un email y esa familia todavía está
// "pendiente" (no tiene código asignado), no hay ningún secreto que proteger todavía, así que se
// puede informar el estado igual. Pero si esa familia YA tiene un código asignado, esta ruta
// nunca lo devuelve por acá: como mucho reenvía el código al correo de confianza YA guardado
// (nunca a uno nuevo) y responde sin datos de la familia.
/** Auditoría 2026-09-27: copia de una fila de `inscripciones` sin los DNI de los alumnos. */
function inscripcionSinDnis(fila: any, dniTutorConocido?: string) {
  const { padre_dni: _dniTutor, alumno_dni: _dniAlumno, hermanos: hermanosFila, ...resto } = fila || {};
  const hermanos = Array.isArray(hermanosFila)
    ? hermanosFila.map(({ alumnoDni: _dniHermano, ...h }: any) => h)
    : [];
  // Auditoría 28/9: llave de la galería de ESTA familia (ver /api/fotos): con ella el servidor le
  // devuelve las fotos individuales de sus hijos y ninguna de otros chicos del curso.
  return { ...resto, hermanos, acceso_galeria: tokenAccesoGaleria(fila?.id), ...(dniTutorConocido ? { padre_dni: dniTutorConocido } : {}) };
}

/**
 * Auditoría 03/10 noche (C1): respuesta de /api/inscripciones/buscar para una inscripción aprobada
 * sola que todavía no confirmó el email del padrón. Reenvía (como mucho 1 cada 10 min) el email con
 * el botón "Sí, fui yo".
 */
async function respuestaFaltaConfirmar(supabase: SupabaseClient, fila: any, opciones: { primerIngreso?: boolean } = {}) {
  const email = String(fila?.email || '').trim().toLowerCase();
  const link = linkConfirmacionAcceso(fila?.id);
  const primerIngreso = opciones.primerIngreso === true;
  if (primerIngreso && !email.includes('@')) {
    return {
      success: false,
      requiereConfirmacion: true,
      error: 'Para tu primer ingreso necesitamos confirmar tu identidad y tu inscripción no tiene un email cargado. Escribinos a contacto@retratoescolar.com.ar y te habilitamos.',
    };
  }
  // Auditoría 08/10 (A2): además de 1 cada 10 min, como mucho 4 por día por inscripción.
  if (
    email.includes('@') && link && fila?.codigo_asignado &&
    (await hayCupoPorClave(`reenvio-codigo:${fila.id}`, 1, 600)) &&
    (await hayCupoPorClave(`reenvio-codigo-dia:${fila.id}`, 4, 24 * 60 * 60))
  ) {
    try {
      await enviarCorreoCodigoAcceso({
        to: email,
        padreNombre: String(fila.padre_nombre || '').trim() || 'Familia',
        colegioNombre: String(fila.colegio_nombre || 'Colegio').trim(),
        codigo: fila.codigo_asignado,
        alumnos: alumnosDeInscripcion(fila),
        solicitaFotoHermanos: Boolean(fila.solicita_foto_hermanos),
        confirmacion: { link, tutor: String(fila.padre_nombre || '').trim(), dniParcial: dniParcialServidor(fila.padre_dni), primerIngreso },
      });
    } catch (e) {
      console.warn('No se pudo reenviar el email de confirmación de acceso:', e);
    }
  }
  if (primerIngreso) {
    return {
      success: false,
      requiereConfirmacion: true,
      error: `Por seguridad, tu primer ingreso se confirma por email: te mandamos un correo${email.includes('@') ? ` a ${enmascararEmailServidor(email)}` : ''} con el botón "Sí, fui yo". Tocalo, escribí tu DNI y después entrá con el código del curso, tu nombre y ese DNI. Revisá también la carpeta de spam.`,
    };
  }
  return {
    success: false,
    requiereConfirmacion: true,
    error: `Antes de entrar tenés que confirmar tu email: te mandamos un correo${email.includes('@') ? ` a ${enmascararEmailServidor(email)}` : ''} con el botón "Sí, fui yo: confirmar mi email". Revisá también la carpeta de spam.`,
  };
}

function tokenAccesoGaleria(inscripcionId: unknown): string | null {
  const secreto = process.env.PEDIDOS_ACCESO_SECRET?.trim() || getAdminSessionSecret();
  if (!secreto || !inscripcionId) return null;
  return crypto.createHmac('sha256', secreto).update(`acceso-galeria:${inscripcionId}`).digest('base64url').slice(0, 32);
}

/** Nombres de los hijos de una inscripción, si la llave de galería es válida; si no, null. */
export async function hijosDeFamiliaConAcceso(supabase: SupabaseClient, familiaId: unknown, acceso: unknown): Promise<string[] | null> {
  const id = String(familiaId || '');
  const esperado = tokenAccesoGaleria(id);
  if (!/^[0-9a-f-]{36}$/i.test(id) || !esperado || typeof acceso !== 'string' || !compararTimingSafe(acceso, esperado)) return null;
  const { data } = await supabase.from('inscripciones').select('estado, acceso_confirmado_at, alumno_nombre, alumno_apellido, hermanos').eq('id', id).maybeSingle();
  if (!data) return null;
  // Auditoría 08/10 (M3): una inscripción rechazada o vuelta a "pendiente" pierde la galería
  // aunque conserve su llave (la llave no vence: es un HMAC del id).
  if (data.estado !== 'aceptado') return null;
  if (inscripcionSinConfirmar(data)) return null;
  const nombres = [`${data.alumno_nombre || ''} ${data.alumno_apellido || ''}`];
  for (const h of Array.isArray(data.hermanos) ? data.hermanos : []) nombres.push(`${h?.alumnoNombre || ''} ${h?.alumnoApellido || ''}`);
  return nombres.map((n) => n.trim()).filter(Boolean);
}

rutas.post('/api/inscripciones/buscar', limitarFrecuencia('inscripciones-buscar', 150, 10 * 60 * 1000), async (req: Request, res: Response) => {
  try {
    const { query, tutorNombre, dni } = req.body || {};
    const q = String(query || '').trim();
    if (q.length < 3) {
      return res.status(400).json({ success: false, error: 'Ingresá tu código, teléfono o email.' });
    }

    const supabase = getServerSupabase();
    if (!supabase) {
      return res.status(500).json({ success: false, error: 'Supabase no configurado en el servidor' });
    }

    const qUpper = q.toUpperCase();
    const qEmail = q.toLowerCase();
    const qTel = normalizarTelefonoServidor(q);

    // Paso 1: ¿lo que se escribió es el código? El código es, en los hechos, el de la sección (el colegio lo reparte a
    // todo el curso), así que no alcanza solo (auditorías 16/09 y 22/09, pedido de Pablo): se piden SIEMPRE código +
    // nombre + DNI del tutor y se traen TODAS las filas del código para identificar a la familia. Las que todavía no
    // tienen `padre_dni` se identifican por nombre (sin tildes ni orden) y el DNI se fija desde el email de confirmación.
    let candidatos: any[] = [];
    const tryEqCodigoTodas = async (column: string, value: string) => {
      if (candidatos.length || !value) return;
      const { data, error } = await supabase.from('inscripciones').select('*').eq(column, value);
      if (error) throw error; // auditoría 11/10 (FAM-8): un error de la base no es "código no encontrado"
      if (data && data.length > 0) candidatos = data;
    };
    await tryEqCodigoTodas('codigo_asignado', qUpper);
    await tryEqCodigoTodas('codigo_familiar', qUpper);
    // Auditoría 2026-09-23: la galería (/api/fotos) acepta el código con o sin guion/espacios, pero
    // acá se exigía el texto exacto — una familia que tipeaba "AB12CD34" en vez de "AB12-CD34" (o
    // al revés, para códigos fijados a mano) recibía "código no encontrado". Se prueban también
    // las variantes normalizadas.
    const qNormalizado = normalizarCodigoSeccion(q);
    if (qNormalizado.length >= 4) {
      const variantes = [qNormalizado];
      if (qNormalizado.length === 8) variantes.push(`${qNormalizado.slice(0, 4)}-${qNormalizado.slice(4)}`);
      for (const variante of variantes) {
        if (variante === qUpper) continue;
        await tryEqCodigoTodas('codigo_asignado', variante);
        await tryEqCodigoTodas('codigo_familiar', variante);
      }
    }
    // 13/10 (caso real): si no apareció, se prueba el código «plegado» (O/0; I/L/1) contra los códigos de sección.
    const parecida = candidatos.length ? null : seccionConCodigoParecido(await traerTodosLosCodigosSeccion(supabase), q);
    for (const v of parecida ? [String(parecida.codigo_secreto), normalizarCodigoSeccion(parecida.codigo_secreto)] : []) {
      await tryEqCodigoTodas('codigo_asignado', v);
      await tryEqCodigoTodas('codigo_familiar', v);
    }

    if (candidatos.length > 0) {
      const soloCurso = (fila: any) => ({
        estado: fila.estado,
        codigo_asignado: fila.codigo_asignado,
        codigo_familiar: fila.codigo_familiar,
        colegio_id: fila.colegio_id,
        colegio_nombre: fila.colegio_nombre,
        grado: fila.grado,
        division: fila.division,
        turno: fila.turno,
      });

      const tutorNombreInput = String(tutorNombre || '').trim();
      const dniInput = normalizarDniServidor(dni);

      if (!tutorNombreInput || dniInput.length < 6) {
        return res.json({
          success: true,
          requiereDatosTutor: true,
          inscripcion: soloCurso(candidatos[0]),
        });
      }

      // Auditoría 03/10 (alto 24): el código del curso lo tienen todas las familias de la sección;
      // lo que identifica a cada una es nombre + DNI del tutor. Tope persistente POR CÓDIGO (todas
      // las IPs juntas) para que no se puedan probar DNIs en cadena contra un mismo curso. Generoso:
      // una sección entera ingresando el mismo día entra holgada (2ª vuelta: 400 cada 15 min, la
      // reunión de padres o el aviso de "ya están las fotos" hace entrar a todo el curso junto).
      const claveCodigo = normalizarCodigoSeccion(String(candidatos[0]?.codigo_asignado || qNormalizado));
      // Auditoría 03/10 noche (M13): antes el tope por código contaba TODOS los ingresos (también los
      // correctos): con el código del curso, alguien podía dejar a todo el curso afuera con 429 el día
      // del aviso de fotos. Ahora cuentan sólo los intentos FALLIDOS (se suman abajo, cuando nombre +
      // DNI no coinciden), y además hay un tope por código + DNI escrito.
      // Revisión 03/10 noche: el tope de fallas es por código + IP (bajo); el total por código queda
      // muy alto, sólo contra un ataque grande, para que nadie pueda dejar afuera a todo el curso.
      const ipIngreso = String(req.ip || 'sin-ip').slice(0, 80);
      if (
        (await superoTopeIntentos(`inscripciones-buscar-fallas-ip:${claveCodigo}:${ipIngreso}`, 30, 15 * 60)) ||
        (await superoTopeIntentos(`inscripciones-buscar-fallas:${claveCodigo}`, 3000, 15 * 60)) ||
        // Auditoría 11/10 (FAM-5): conteo atómico ANTES de comparar (la lectura de arriba se esquivaba con pedidos simultáneos).
        !(await hayCupoPorClave(`inscripciones-buscar-ip:${claveCodigo}:${ipIngreso}`, 60, 15 * 60))
      ) {
        return res.status(429).json({ success: false, error: 'Hubo demasiados intentos fallidos de ingreso con este código. Probá de nuevo en unos minutos.' });
      }
      if (!(await hayCupoPorClave(`inscripciones-buscar-dni:${claveCodigo}:${dniInput}`, 12, 15 * 60))) {
        return res.status(429).json({ success: false, error: 'Hubo demasiados intentos de ingreso con este DNI. Probá de nuevo en unos minutos.' });
      }

      // 1) ¿alguna fila ya tiene guardado justo este DNI? (ingresos posteriores al primero)
      // Auditoría 30/9 (M1): además del DNI, el nombre del tutor tiene que compartir al menos una
      // palabra con el guardado (tolerante a segundos nombres o apellidos de más), así el DNI de un
      // padre (que no es secreto) no alcanza solo junto al código del curso.
      const palabrasTutor = new Set(normalizarNombrePorPalabras(tutorNombreInput).split(' ').filter((p) => p.length >= 2));
      const nombreTutorCoincide = (c: any) => normalizarNombrePorPalabras(c.padre_nombre).split(' ').some((p) => palabrasTutor.has(p));
      // Auditoría 08/10 (M3): sólo entran inscripciones ACEPTADAS. Una rechazada (o devuelta a
      // "pendiente" porque el DNI no coincidió al confirmar) conserva el código del curso, y antes
      // seguía recibiendo la llave de galería con las fotos individuales.
      const aceptadas = candidatos.filter((c: any) => c.estado === 'aceptado');
      let match = aceptadas.find((c: any) => c.padre_dni && normalizarDniServidor(c.padre_dni) === dniInput && nombreTutorCoincide(c)) || null;

      // 2) si ninguna lo tenía guardado, se identifica por nombre entre las que todavía no
      // tienen DNI cargado.
      // Auditoría 08/10 (A2): antes el DNI escrito quedaba fijado en el momento y entraba quien
      // llegara primero con el código del curso + el nombre del tutor (que se conoce en el grupo de
      // WhatsApp). Ahora el DNI sólo se fija desde el link que llega al email de la inscripción
      // (/api/inscripciones/confirmar-acceso): acá se manda ese email y no se entrega la llave.
      if (!match) {
        const nombreNormEntrada = normalizarNombrePorPalabras(tutorNombreInput);
        let porNombre = aceptadas.filter(
          (c: any) => !c.padre_dni && normalizarNombrePorPalabras(c.padre_nombre) === nombreNormEntrada && nombreNormEntrada.length > 0
        );
        // 13/10 (pedido de Pablo): muchos escriben sólo primer nombre y apellido. Sin coincidencia exacta, alcanza con que
        // TODAS las palabras escritas (2 o más) estén en el nombre inscripto y sea una sola familia (igual sólo se manda el
        // email de confirmación a la casilla de la inscripción: acá no se entrega la galería).
        if (porNombre.length === 0 && palabrasTutor.size >= 2) {
          const contiene = (c: any) => { const g = new Set(normalizarNombrePorPalabras(c.padre_nombre).split(' ')); return [...palabrasTutor].every((p) => g.has(p)); };
          porNombre = aceptadas.filter((c: any) => !c.padre_dni && contiene(c));
        }
        if (porNombre.length === 1) {
          // Auditoría 03/10 noche (C1): una inscripción aprobada sola que todavía no confirmó su email
          // no fija DNI ni deja entrar.
          if (inscripcionSinConfirmar(porNombre[0])) return res.json(await respuestaFaltaConfirmar(supabase, porNombre[0]));
          return res.json(await respuestaFaltaConfirmar(supabase, porNombre[0], { primerIngreso: true }));
        }
      }

      if (!match) {
        await hayCupoPorClave(`inscripciones-buscar-fallas-ip:${claveCodigo}:${ipIngreso}`, 30, 15 * 60);
        await hayCupoPorClave(`inscripciones-buscar-fallas:${claveCodigo}`, 3000, 15 * 60);
        return res.json({
          success: true,
          requiereDatosTutor: true,
          datosNoCoinciden: true,
          inscripcion: soloCurso(candidatos[0]),
        });
      }

      // Auditoría 03/10 noche (C1): aprobada sola contra el padrón y sin confirmar el email: todavía
      // no se entrega la llave de galería (se reenvía el email con el botón de confirmación).
      if (inscripcionSinConfirmar(match)) return res.json(await respuestaFaltaConfirmar(supabase, match));

      // Auditoría 2026-09-27: no se devuelven los DNI de los chicos ni el DNI guardado (sólo el
      // que la familia acaba de escribir, que ya lo conoce).
      return res.json({ success: true, inscripcion: inscripcionSinDnis(match, dniInput) });
    }

    // Paso 2: no era el código. Buscar por contacto (teléfono o email) — ver auditoría arriba,
    // el resultado de esta búsqueda NUNCA puede filtrar un código ya asignado.
    let porContacto: any = null;
    if (qEmail.includes('@')) {
      const { data, error } = await supabase.from('inscripciones').select('*').eq('email', qEmail).limit(1);
      if (error) throw error;
      if (data && data.length > 0) porContacto = data[0];
    }
    // Auditoría 2026-09-09: antes esto buscaba con ilike '%qTel%' aceptando desde 6 dígitos
    // sueltos en cualquier parte del teléfono guardado — eso es fuerza-bruteable (basta con
    // probar secuencias de 6 dígitos) y podía traer coincidencias parciales casuales de OTRA
    // familia. Ahora exige el teléfono completo (mínimo 8 dígitos) y sólo lo compara, ya
    // normalizado, contra el final exacto del teléfono guardado — no contra cualquier subcadena.
    if (!porContacto && qTel.length >= 8) {
      const sufijo = qTel.slice(-8);
      const { data, error } = await supabase.from('inscripciones').select('*').ilike('telefono_whatsapp', `%${sufijo}`).limit(5);
      if (error) throw error;
      if (data && data.length > 0) {
        porContacto = data.find((i: any) => normalizarTelefonoServidor(i.telefono_whatsapp || '').endsWith(qTel.length >= 10 ? qTel : sufijo)) || null;
      }
    }

    if (!porContacto) {
      return res.json({ success: false });
    }

    if (porContacto.estado !== 'aceptado' || !porContacto.codigo_asignado) {
      // Todavía no tiene código asignado: se informa el estado. Auditoría 2026-09-23 (privacidad):
      // antes se devolvía la fila completa a quien escribiera un teléfono/email ajeno — incluidos
      // el DNI del tutor (que después, junto al código del curso, es la llave para entrar al
      // portal) y los DNI de los chicos. La pantalla sólo necesita nombres, curso y estado.
      // Auditoría 30/9 (M2): sólo lo que la pantalla muestra (antes iban también email, teléfono,
      // IP de los consentimientos, etc. a quien escribiera un teléfono ajeno).
      // Auditoría 03/10 noche (M10): a quien escribe un teléfono o email ajeno no se le devuelven los
      // nombres de los chicos, el curso ni el tutor (datos de menores): sólo el estado y el colegio.
      return res.json({
        success: true,
        inscripcion: {
          estado: porContacto.estado,
          colegio_nombre: porContacto.colegio_nombre,
        },
      });
    }

    // Ya tiene código asignado: por acá nunca se devuelve. Se reenvía al correo de confianza que
    // ya estaba guardado (el validado en su momento contra el padrón, nunca uno nuevo) y se
    // responde sin ningún dato de la familia — sólo si se pudo reenviar y a qué correo (parcial).
    let emailReenviado = false;
    let reenvioReciente = false;
    const emailConfianza = porContacto.email ? String(porContacto.email).trim().toLowerCase() : '';
    // Auditoría 03/10 (alto 24): como mucho un reenvío cada 10 minutos por inscripción (antes se
    // podía llenar de mails la casilla de una familia escribiendo su teléfono una y otra vez). Se
    // responde como reenviado: el último sigue en su correo.
    if (emailConfianza && emailConfianza.includes('@') && !(await hayCupoReenvioCodigo(String(porContacto.id)))) {
      emailReenviado = true;
      reenvioReciente = true;
    } else if (emailConfianza && emailConfianza.includes('@')) {
      try {
        const resultadoReenvio = await enviarCorreoCodigoAcceso({
          to: emailConfianza,
          padreNombre: String(porContacto.padre_nombre || '').trim() || 'Familia',
          colegioNombre: String(porContacto.colegio_nombre || 'Colegio').trim(),
          codigo: porContacto.codigo_asignado,
          alumnos: alumnosDeInscripcion(porContacto),
          solicitaFotoHermanos: Boolean(porContacto.solicita_foto_hermanos),
          ...(inscripcionSinConfirmar(porContacto) && linkConfirmacionAcceso(porContacto.id)
            ? { confirmacion: { link: linkConfirmacionAcceso(porContacto.id) as string, tutor: String(porContacto.padre_nombre || '').trim(), dniParcial: dniParcialServidor(porContacto.padre_dni) } }
            : {}),
        });
        emailReenviado = Boolean(resultadoReenvio.success);
      } catch (e) {
        console.warn('No se pudo reenviar el código de acceso desde /api/inscripciones/buscar:', e);
      }
    }

    return res.json({
      success: false,
      yaRegistrado: true,
      emailReenviado,
      ...(reenvioReciente ? { reenvioReciente: true } : {}),
      emailDestino: emailReenviado ? enmascararEmailServidor(emailConfianza) : null,
    });
  } catch (err: any) {
    console.error('Error al buscar inscripción:', err);
    return res.status(500).json({ success: false, error: err?.message || 'Error al buscar la inscripción' });
  }
});

// Auditoría 2026-09-16 (pedido de Pablo: la web y el mail de aprobación prometen "1 solo Código
// Familiar... vas a poder ver a todos tus hijos y alternar entre ellos con un solo toque", pero
// el Código Familiar siempre fue, en los hechos, el código de la sección del hijo PRINCIPAL
// nada más — cada hermano ya se guardaba con su propio grado/turno/división al inscribirse
// (columna `hermanos`, ver `AlumnoHermano`), pero nunca se le generaba ni resolvía un código de
// su propia sección, así que no había forma real de ver su galería con el mismo código. Este
// endpoint es el que le faltaba: dado el Código Familiar ya validado, devuelve el hijo principal
// + cada hermano con SU PROPIO código real de sección (generándolo recién ahora si esa sección
// todavía no tenía uno, con la misma función que ya usa "Códigos y difusión"). El frontend
// (`PortalFamiliasModal.tsx`) usa esto para poder alternar la galería mostrada sin pedirle a la
// familia un código distinto por cada hijo — nunca se le entrega grado/turno/división "en
// crudo" al navegador como si fuera la llave: la llave sigue siendo siempre un código secreto.
// Auditoría 03/10 noche (C1): botón "Sí, fui yo: confirmar mi email" del correo del código. Sólo lo
// tiene quien recibe el email del padrón; con eso la inscripción aprobada sola queda habilitada y se
// devuelve el código del curso para precargarlo en el ingreso.
rutas.post('/api/inscripciones/confirmar-acceso', limitarFrecuenciaPersistente('confirmar-acceso', 30, 15 * 60 * 1000), async (req: Request, res: Response) => {
  try {
    const id = String(req.body?.id || '').trim();
    const token = String(req.body?.token || '').trim();
    const dniEscrito = normalizarDniServidor(req.body?.dni);
    const esperado = tokenConfirmacionAcceso(id);
    if (!/^[0-9a-f-]{36}$/i.test(id) || !esperado || !token || !compararTimingSafe(token, esperado)) {
      return res.status(400).json({ success: false, error: 'El link de confirmación no es válido. Abrilo de nuevo desde el último email que te mandamos.' });
    }
    const supabase = getServerSupabase();
    if (!supabase) return res.status(503).json({ success: false, error: 'Servicio no disponible' });
    const { data: fila, error } = await supabase
      .from('inscripciones')
      .select('id, estado, codigo_asignado, acceso_confirmado_at, padre_dni, padre_nombre, alumno_nombre, alumno_apellido, colegio_nombre')
      .eq('id', id)
      .maybeSingle();
    if (error) throw error;
    if (!fila || fila.estado !== 'aceptado' || !fila.codigo_asignado) {
      return res.status(404).json({ success: false, error: 'No encontramos esa inscripción o todavía no está aprobada.' });
    }
    // Auditoría 08/10 (A2): primer ingreso de una inscripción aprobada SIN DNI del tutor. El DNI se
    // fija recién acá, porque llegar acá prueba que se tiene el email de la inscripción.
    if (!normalizarDniServidor(fila.padre_dni)) {
      if (dniEscrito.length < 6) {
        return res.status(400).json({ success: false, requiereDni: true, error: 'Escribí tu DNI (el de la persona que hizo la inscripción) para confirmar.' });
      }
      const ahora = new Date().toISOString();
      const { data: fijadas, error: errorDni } = await supabase
        .from('inscripciones')
        .update({ padre_dni: dniEscrito, acceso_confirmado_at: fila.acceso_confirmado_at || ahora, updated_at: ahora })
        .eq('id', id)
        .is('padre_dni', null)
        .select('id');
      if (errorDni) throw errorDni;
      if (fijadas && fijadas.length > 0) return res.json({ success: true, codigo: fila.codigo_asignado });
      // Otra pestaña lo fijó en el medio: se sigue con el control normal contra el DNI guardado.
      const { data: actual } = await supabase.from('inscripciones').select('padre_dni').eq('id', id).maybeSingle();
      if (!actual || !compararTimingSafe(dniEscrito, normalizarDniServidor(actual.padre_dni))) {
        return res.status(409).json({ success: false, dniNoCoincide: true, error: 'El DNI no coincide con el de la inscripción. Revisalo o respondé el email para avisarnos.' });
      }
      return res.json({ success: true, codigo: fila.codigo_asignado });
    }
    if (!fila.acceso_confirmado_at) {
      // Revisión 03/10 noche: además del link, el titular del email escribe el DNI del tutor. Si no es
      // el que se cargó en la inscripción (otra persona se inscribió con este contacto), no se confirma.
      // 14/10/2026 (auditoría): a la 3ª vez en 24 h ya NO vuelve a «pendiente» (eso le sacaba el acceso a la
      // familia real por errores de tipeo): se frenan los intentos hasta el día siguiente y a Pablo le llega
      // un solo aviso (registrarAlertaPago no repite la misma clave). El mensaje nombra al tutor a medias.
      const dniGuardado = normalizarDniServidor(fila.padre_dni);
      if (dniEscrito.length < 6) {
        return res.status(400).json({ success: false, requiereDni: true, error: 'Escribí el DNI de la persona que hizo la inscripción para confirmar.' });
      }
      if (!dniGuardado || !compararTimingSafe(dniEscrito, dniGuardado)) {
        const dentroDelCupo = await hayCupoPorClave(`confirmar-acceso-dni:${id}`, 2, 24 * 60 * 60);
        await registrarAlertaPago(supabase, `confirmacion-dni:${id}`, `INSCRIPCIÓN PARA REVISAR: el titular del email del padrón intentó confirmar la inscripción de ${String(fila.alumno_nombre || '')} ${String(fila.alumno_apellido || '')} (${String(fila.colegio_nombre || '')}) con un DNI que NO coincide con el cargado. Puede ser que otra persona se haya inscripto con su contacto.`, { inscripcion: id });
        const quien = tutorParcial(fila.padre_nombre);
        if (!dentroDelCupo) {
          return res.status(429).json({ success: false, dniNoCoincide: true, bloqueado: true, error: `Hubo varios intentos con un DNI que no coincide con el de quien hizo la inscripción${quien ? ` (${quien})` : ''}. Por seguridad, probá de nuevo mañana o respondé el email del código para que te ayudemos.` });
        }
        return res.status(409).json({ success: false, dniNoCoincide: true, error: `El DNI no coincide con el de quien hizo la inscripción${quien ? `: ${quien}` : ''}. Revisalo; si vos NO hiciste esta inscripción, no sigas y respondé el email del código para avisarnos.` });
      }
      const { error: errorUpdate } = await supabase
        .from('inscripciones')
        .update({ acceso_confirmado_at: new Date().toISOString(), updated_at: new Date().toISOString() })
        .eq('id', id)
        .is('acceso_confirmado_at', null);
      if (errorUpdate) throw errorUpdate;
    }
    return res.json({ success: true, codigo: fila.codigo_asignado });
  } catch (err: any) {
    console.error('[inscripciones] Error al confirmar el acceso:', err);
    return res.status(500).json({ success: false, error: 'No pudimos confirmar tu email. Probá de nuevo en unos minutos.' });
  }
});

rutas.get('/api/familia/hijos', limitarFrecuencia('familia-hijos', 500, 10 * 60 * 1000), async (req: Request, res: Response) => {
  try {
    const codigo = String(req.query.codigo || '').trim().toUpperCase();
    if (!codigo) {
      return res.status(400).json({ success: false, error: 'Falta el código familiar.' });
    }
    const supabase = getServerSupabase();
    if (!supabase) return res.status(500).json({ success: false, error: 'Supabase no configurado en el servidor' });

    // Auditoría 2026-09-22 (mismo código de sección compartido por todo el curso, ver
    // `/api/inscripciones/buscar` más arriba): este endpoint pedía la fila con `.limit(1)`, así
    // que si dos o más familias comparten `codigo_asignado` (lo normal, es el código del curso)
    // siempre devolvía los hijos de la PRIMERA que apareciera en la tabla — no necesariamente la
    // familia que está mirando la pantalla. Ahora se piden TODAS las filas de ese código y, si
    // hay más de una, se identifica la correcta por el DNI del tutor (`padre_dni`, ya validado en
    // `/api/inscripciones/buscar` antes de llegar acá) — si por algún motivo no llega o no
    // coincide, se cae de nuevo a la primera fila en vez de romper la pantalla.
    // Auditoría 30/9 (M1): la familia se identifica con su llave de galería (la que entrega
    // /api/inscripciones/buscar después de validar código + nombre + DNI), no con el DNI suelto:
    // el DNI de un padre no es secreto y esta respuesta trae los códigos de sección de los hermanos.
    const familiaId = String(req.query.familia || '');
    const esperado = tokenAccesoGaleria(familiaId);
    const acceso = String(req.query.acceso || '');
    if (!/^[0-9a-f-]{36}$/i.test(familiaId) || !esperado || !acceso || !compararTimingSafe(acceso, esperado)) {
      return res.status(403).json({
        success: false,
        requiereDatosTutor: true,
        error: 'Para ver a tus hijos/as necesitamos identificarte con el nombre y DNI del tutor. Volvé a ingresar.',
      });
    }
    const { data: filas, error: errorFilas } = await supabase
      .from('inscripciones')
      .select('id, colegio_id, colegio_nombre, alumno_nombre, alumno_apellido, grado, division, turno, estado, codigo_asignado, padre_dni, hermanos, acceso_confirmado_at')
      .eq('id', familiaId)
      .eq('codigo_asignado', codigo);
    if (errorFilas) throw errorFilas; // auditoría 11/10 (FAM-8): 500, no "código no encontrado"

    if (!filas || filas.length === 0) {
      return res.status(404).json({ success: false, error: 'Código familiar no encontrado o todavía no aprobado.' });
    }
    // Auditoría 2026-09-23 / 30/9 (M1): la fila es la de la llave de galería (id + código), nunca "la primera" del curso.
    const fila: any = filas[0];
    if (fila.estado !== 'aceptado' || !fila.codigo_asignado) {
      return res.status(404).json({ success: false, error: 'Código familiar no encontrado o todavía no aprobado.' });
    }
    if (inscripcionSinConfirmar(fila)) {
      return res.status(403).json({ success: false, requiereDatosTutor: true, error: 'Antes de entrar tenés que confirmar tu email (revisá el correo con el código).' });
    }

    const candidatos = [
      {
        id: 'principal',
        nombreCompleto: `${fila.alumno_nombre || ''} ${fila.alumno_apellido || ''}`.trim() || 'Alumno/a',
        colegioId: fila.colegio_id,
        colegioNombre: fila.colegio_nombre,
        grado: fila.grado,
        turno: fila.turno,
        division: fila.division,
      },
      ...((Array.isArray(fila.hermanos) ? fila.hermanos : []) as any[]).map((h: any, idx: number) => ({
        id: h?.id || `hermano-${idx}`,
        nombreCompleto: `${h?.alumnoNombre || ''} ${h?.alumnoApellido || ''}`.trim() || 'Hermano/a',
        colegioId: h?.colegioId || fila.colegio_id,
        colegioNombre: h?.colegioNombre || fila.colegio_nombre,
        grado: h?.grado,
        turno: h?.turno,
        division: h?.division,
      })),
    ].filter((c) => c.colegioId && c.grado && c.turno);

    const hijos = await Promise.all(
      candidatos.map(async (c) => {
        const codigoSeccion = await obtenerOCrearCodigoSeccion(supabase, c.colegioId, c.grado, c.turno, c.division || '');
        return {
          id: c.id,
          nombreCompleto: c.nombreCompleto,
          colegioNombre: c.colegioNombre,
          grado: c.grado,
          turno: c.turno,
          division: c.division,
          codigoSeccion,
        };
      })
    );

    return res.json({ success: true, hijos });
  } catch (err: any) {
    console.error('Error al resolver los hijos del código familiar:', err);
    return res.status(500).json({ success: false, error: err?.message || 'Error al resolver los hijos de esta familia' });
  }
});

// --- Rutas de administración de inscripciones y padrón (protegidas con requireAdminAuth) ---

rutas.get('/api/admin/inscripciones', requireAdminAuth, async (req: Request, res: Response) => {
  try {
    const supabase = getServerSupabase();
    if (!supabase) {
      return res.status(500).json({ success: false, error: 'Supabase no configurado en el servidor' });
    }
    const data = await traerTodasLasFilas((desde, hasta) =>
      supabase.from('inscripciones').select('*').order('created_at', { ascending: false }).order('id').range(desde, hasta)
    );
    return res.json({ success: true, inscripciones: data });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err?.message || 'Error al obtener inscripciones' });
  }
});

rutas.post('/api/admin/inscripciones/:id/aprobar', requireAdminAuth, async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const { codigo } = req.body || {};
    const supabase = getServerSupabase();
    if (!supabase) {
      return res.status(500).json({ success: false, error: 'Supabase no configurado en el servidor' });
    }

    const { data: existente, error: errGet } = await supabase.from('inscripciones').select('*').eq('id', id).single();
    if (errGet || !existente) {
      return res.status(404).json({ success: false, error: 'Inscripción no encontrada' });
    }
    // Auditoría 11/10 (INS-2): sólo se aprueba una pendiente; una rechazada o ya aprobada, sólo con `forzar: true`.
    if (existente.estado !== 'pendiente' && req.body?.forzar !== true) {
      return res.status(409).json({ success: false, error: `Esta inscripción está «${existente.estado}»: sólo se aprueban las pendientes.` });
    }

    // El código final SIEMPRE es el código real y secreto de esa sección (colegio+grado+turno+
    // división) guardado en `codigos_seccion` — nunca la fórmula pública. Si la sección ya
    // tenía un código asignado (por ejemplo, otra familia del mismo curso ya fue aprobada antes),
    // se reutiliza ese mismo código para todos; si es la primera vez, se usa lo que haya escrito
    // el fotógrafo (o el código previo de esta inscripción) como sugerencia, y si no, se genera
    // uno nuevo al azar.
    const codigoFinal = await obtenerOCrearCodigoSeccion(
      supabase,
      existente.colegio_id,
      existente.grado,
      existente.turno,
      existente.division,
      codigo || existente.codigo_asignado
    );

    const now = new Date();
    const fechaStr = formatearFechaHoraArgentina(now);

    const { data, error } = await supabase
      .from('inscripciones')
      .update({
        estado: 'aceptado',
        codigo_asignado: codigoFinal,
        codigo_familiar: codigoFinal,
        fecha_aprobacion: fechaStr,
        // Auditoría 03/10 noche (C1): la aprobó el fotógrafo a mano: no hace falta que la familia
        // confirme el email.
        acceso_confirmado_at: existente.acceso_confirmado_at || new Date().toISOString(),
        // 14/10/2026: código nuevo = email pendiente otra vez (si no, enviar-email lo daría por ya enviado).
        ...(codigoFinal !== existente.codigo_asignado ? { notificacion_email_enviada: false } : {}),
        updated_at: new Date().toISOString(),
      })
      .eq('id', id)
      .select()
      .single();

    if (error) throw error;

    return res.json({ success: true, inscripcion: data, codigo: codigoFinal });
  } catch (err: any) {
    return res.status(err instanceof ErrorChoqueCodigoCurso ? 409 : 500).json({ success: false, error: err?.message || 'Error al aprobar inscripción' });
  }
});

// → 14/10/2026: «enviar-email», «rechazar» y «whatsapp-enviado» pasaron a inscripcionesAdmin.ts.

// Auditoría 03/10 noche (C1): el fotógrafo verificó a mano a una familia aprobada sola que todavía
// no confirmó su email (por ejemplo, la llamó por teléfono).
rutas.post('/api/admin/inscripciones/:id/confirmar-acceso', requireAdminAuth, async (req: Request, res: Response) => {
  try {
    const supabase = getServerSupabase();
    if (!supabase) return res.status(500).json({ success: false, error: 'Supabase no configurado en el servidor' });
    const { data, error } = await supabase
      .from('inscripciones')
      .update({ acceso_confirmado_at: new Date().toISOString(), updated_at: new Date().toISOString() })
      .eq('id', req.params.id)
      .select('id, acceso_confirmado_at')
      .maybeSingle();
    if (error) throw error;
    if (!data) return res.status(404).json({ success: false, error: 'Inscripción no encontrada' });
    return res.json({ success: true, inscripcion: data });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err?.message || 'No se pudo marcar como verificada' });
  }
});

// Auditoría 2026-09-27: el DNI del tutor queda fijado en el primer ingreso. Si lo fijó otra
// persona (o la familia se equivocó), el admin lo borra y el próximo ingreso lo vuelve a registrar.
rutas.post('/api/admin/inscripciones/:id/borrar-dni', requireAdminAuth, async (req: Request, res: Response) => {
  try {
    const supabase = getServerSupabase();
    if (!supabase) {
      return res.status(500).json({ success: false, error: 'Supabase no configurado en el servidor' });
    }
    const { data, error } = await supabase
      .from('inscripciones')
      .update({ padre_dni: null, updated_at: new Date().toISOString() })
      .eq('id', req.params.id)
      .select()
      .single();
    if (error) throw error;
    return res.json({ success: true, inscripcion: data });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err?.message || 'Error al borrar el DNI' });
  }
});

// Auditoría 2026-09-22 (pedido de Pablo: "como hago para eliminar a un inscripto?"): antes NO
// existía ninguna forma de borrar una fila de `inscripciones` — "Rechazar" (arriba) sólo cambia
// el estado a "rechazado" y sólo está disponible para inscripciones pendientes; una ya aprobada
// se quedaba en el listado para siempre. Este DELETE borra directamente la fila de `inscripciones`
// (pendiente, rechazada o aprobada). Es seguro: aprobar una inscripción sólo actualiza esta misma
// fila (ver POST .../aprobar más arriba) — NO crea filas en `familias`/`alumnos`/`pedidos`, esas
// se crean recién cuando la familia usa su Código Familiar desde el Portal — así que borrar acá
// nunca borra en cascada pedidos, fotos ni el acceso que la familia ya haya generado.
rutas.delete('/api/admin/inscripciones/:id', requireAdminAuth, async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const supabase = getServerSupabase();
    if (!supabase) {
      return res.status(500).json({ success: false, error: 'Supabase no configurado en el servidor' });
    }
    const { error } = await supabase.from('inscripciones').delete().eq('id', id);
    if (error) throw error;
    return res.json({ success: true });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err?.message || 'Error al eliminar la inscripción' });
  }
});

rutas.get('/api/admin/padron', requireAdminAuth, async (req: Request, res: Response) => {
  try {
    const supabase = getServerSupabase();
    if (!supabase) {
      return res.status(500).json({ success: false, error: 'Supabase no configurado en el servidor' });
    }
    const colegioId = req.query.colegioId as string | undefined;
    const data = await traerTodasLasFilas((desde, hasta) => {
      let builder = supabase.from('padres_autorizados').select('*').order('created_at', { ascending: false }).order('id');
      if (colegioId) {
        builder = builder.eq('colegio_id', colegioId);
      }
      return builder.range(desde, hasta);
    });
    return res.json({ success: true, padron: data });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err?.message || 'Error al obtener el padrón' });
  }
});

// Importar filas del padrón (ya parseadas desde el Excel/CSV en el navegador con la librería xlsx)
rutas.post('/api/admin/padron/importar', requireAdminAuth, async (req: Request, res: Response) => {
  try {
    const { filas, colegioId } = req.body || {};
    if (!Array.isArray(filas) || filas.length === 0) {
      return res.status(400).json({ success: false, error: 'No se recibieron filas para importar' });
    }
    if (filas.length > 2000) {
      return res.status(400).json({ success: false, error: 'Demasiadas filas en un solo lote (máximo 2000)' });
    }

    const supabase = getServerSupabase();
    if (!supabase) {
      return res.status(500).json({ success: false, error: 'Supabase no configurado en el servidor' });
    }

    const filasNormalizadas = filas
      .map((f: any) => ({
        colegio_id: f.colegioId || f.colegio_id || colegioId,
        nombre: String(f.nombre || '').trim(),
        telefono: f.telefono ? String(f.telefono).trim() : null,
        email: f.email ? String(f.email).trim().toLowerCase() : null,
        alumno_nombre: f.alumnoNombre || f.alumno_nombre || null,
        grado: f.grado || null,
        division: f.division || null,
        turno: f.turno || null,
        codigo_asignado: String(f.codigoAsignado || f.codigo_asignado || '').trim().toUpperCase() || null,
      }))
      .filter((f: any) => f.colegio_id && f.nombre && (f.telefono || f.email));

    if (filasNormalizadas.length === 0) {
      return res.status(400).json({ success: false, error: 'Ninguna fila tiene los datos mínimos (colegio, nombre y teléfono o email)' });
    }

    // 14/10/2026: un reintento (respuesta perdida) no duplica el padrón: se saltean las filas que ya están.
    const { nuevas, repetidas } = await separarYaImportadas(supabase, 'padres_autorizados', ['grado', 'division', 'turno', 'nombre', 'alumno_nombre'], filasNormalizadas);
    const { data, error } = nuevas.length ? await supabase.from('padres_autorizados').insert(nuevas).select() : { data: [], error: null };
    if (error) throw error;
    return res.json({ success: true, importados: data?.length || 0, descartados: filas.length - filasNormalizadas.length, repetidos: repetidas });
  } catch (err: any) {
    console.error('Error al importar padrón:', err);
    return res.status(500).json({ success: false, error: err?.message || 'Error al importar el padrón' });
  }
});

rutas.delete('/api/admin/padron/:id', requireAdminAuth, async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const supabase = getServerSupabase();
    if (!supabase) {
      return res.status(500).json({ success: false, error: 'Supabase no configurado en el servidor' });
    }
    const { error } = await supabase.from('padres_autorizados').delete().eq('id', id);
    if (error) throw error;
    return res.json({ success: true });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err?.message || 'Error al eliminar del padrón' });
  }
});

export { rutas as rutasInscripciones };
