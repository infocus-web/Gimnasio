// Encuesta de satisfacción a las familias (25/10/2026, pedido de Pablo): un mail a todas las familias inscriptas
// (aprobadas, colegios públicos) con una disculpa por los problemas, el compromiso de que todos los chicos tengan su
// foto y un link personal a una encuesta corta (3 estrellas, «¿nos recomendarías?» y sugerencias).
// - El link lleva el id de la inscripción y una firma (HMAC), como «Confirmar mi email»: nadie responde por otro.
// - Una respuesta por inscripción (tabla encuestas_familias, migración 20261025230000); si vuelve a entrar, la corrige.
// - El mail se manda desde el panel «Emails» (tipo «encuesta»), que anota inscripciones.encuesta_enviada_at.
import crypto from 'crypto';
import express from 'express';
import type { Request, Response } from 'express';
import { getAdminSessionSecret, requireAdminAuth } from '../nucleo/auth.js';
import { getServerSupabase, resendReplyTo } from '../nucleo/clientes.js';
import { limitarFrecuencia } from '../nucleo/limites.js';
import { escapeHtml, traerTodasLasFilas } from '../nucleo/utilidades.js';

const rutas = express.Router();
const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
/** Link de muestra del mail de prueba: muestra la encuesta pero no guarda nada. */
export const TOKEN_PRUEBA = 'prueba';

export function tokenEncuesta(inscripcionId: unknown): string | null {
  const secreto = process.env.PEDIDOS_ACCESO_SECRET?.trim() || getAdminSessionSecret();
  if (!secreto || !inscripcionId) return null;
  return crypto.createHmac('sha256', secreto).update(`encuesta:${inscripcionId}`).digest('base64url').slice(0, 32);
}

export function linkEncuesta(inscripcionId: string | null): string {
  const appUrl = (process.env.APP_URL || 'https://www.retratoescolar.com.ar').replace(/\/+$/, '');
  if (!inscripcionId) return `${appUrl}/?encuesta=${TOKEN_PRUEBA}`;
  return `${appUrl}/?encuesta=${encodeURIComponent(`${inscripcionId}.${tokenEncuesta(inscripcionId)}`)}`;
}

/** «<id>.<firma>» → id de la inscripción si la firma es válida; 'prueba' para el link de muestra; null si no. */
export function leerTokenEncuesta(t: unknown): string | null {
  const valor = String(t || '').trim();
  if (valor === TOKEN_PRUEBA) return TOKEN_PRUEBA;
  const [id, firma] = valor.split('.');
  if (!id || !firma || !UUID_RE.test(id)) return null;
  const esperada = tokenEncuesta(id);
  if (!esperada || esperada.length !== firma.length) return null;
  return crypto.timingSafeEqual(Buffer.from(esperada), Buffer.from(firma)) ? id : null;
}

function primerNombre(nombre: unknown): string {
  return String(nombre || '').trim().split(/\s+/)[0] || '';
}

export function correoEncuesta(destino: { email: string; tutor: string; inscripcionId: string | null }) {
  const link = linkEncuesta(destino.inscripcionId);
  const nombre = primerNombre(destino.tutor);
  const boton = (texto: string) =>
    `<a href="${escapeHtml(link)}" style="display:inline-block;background:#f59e0b;color:#0f172a;text-decoration:none;font-weight:800;font-size:16px;padding:14px 28px;border-radius:12px">${texto}</a>`;
  return {
    from: process.env.RESEND_FROM_EMAIL || 'Retrato Escolar <fotos@retratoescolar.com.ar>',
    replyTo: resendReplyTo,
    to: [destino.email],
    subject: 'Queremos que todos los chicos tengan su foto 📸 ¿Nos ayudás con 1 minuto?',
    html: `<!doctype html><html lang="es"><body style="margin:0;background:#f8fafc;font-family:Arial,sans-serif;color:#1e293b"><div style="max-width:600px;margin:24px auto;background:#fff;border:1px solid #e2e8f0;border-radius:16px;overflow:hidden"><div style="background:#0f172a;padding:28px 24px;text-align:center;border-bottom:3px solid #f59e0b"><div style="color:#f59e0b;font-size:11px;font-weight:800;letter-spacing:2px">RETRATO ESCOLAR</div><h1 style="color:#fff;font-size:22px;margin:8px 0 0">Gracias por confiarnos este recuerdo</h1></div><div style="padding:28px 24px;line-height:1.65;font-size:15px"><p>Hola${nombre ? ` <strong>${escapeHtml(nombre)}</strong>` : ''},</p><p>Sabemos lo importante que es la foto escolar: es el recuerdo de un año que no se repite, y queremos que <strong>todos los chicos tengan la suya</strong>.</p><p>Si en este proceso tuviste algún inconveniente (una foto que no aparecía, un curso mal cargado, un código que no llegaba o una demora en responderte), te pedimos disculpas. Estamos trabajando todos los días para corregir cada caso y mejorar la plataforma.</p><p>Si a tu hijo/a le falta alguna foto, avisanos desde la galería con el botón <strong>«Mi hijo/a no tiene esta foto»</strong>, hasta el 15 de noviembre inclusive: <strong>esta semana sacamos las fotos que faltan</strong> y te avisamos por email el día. En secundaria (de 2° a 6° año), las individuales también las sacamos esta semana en el colegio: no hace falta que las pidas.</p><p>Tu opinión nos ayuda muchísimo. Son 4 preguntas y te lleva menos de un minuto:</p><p style="text-align:center;margin:28px 0">${boton('Responder la encuesta')}</p><p>Al final hay un espacio para que nos dejes tus sugerencias. Las leemos todas.</p><p>¡Gracias por acompañarnos!<br><strong>Equipo de Retrato Escolar</strong></p><p style="font-size:12px;color:#64748b;border-top:1px solid #e2e8f0;padding-top:14px;margin-top:24px">Si tenés un problema puntual con tus fotos o tu pedido, escribinos desde <a href="https://www.retratoescolar.com.ar/?consulta=1#contacto" style="color:#d97706">el formulario de consultas</a> o respondé este email.</p></div></div></body></html>`,
  };
}

const ENTERO_1_5 = (v: unknown) => (Number.isInteger(Number(v)) && Number(v) >= 1 && Number(v) <= 5 ? Number(v) : null);

export function validarRespuesta(cuerpo: any): { ok: true; datos: { fotos: number | null; web: number | null; atencion: number | null; recomendaria: string | null; sugerencias: string | null; quiere_contacto: boolean } } | { ok: false; error: string } {
  const fotos = ENTERO_1_5(cuerpo?.fotos);
  const web = ENTERO_1_5(cuerpo?.web);
  const atencion = cuerpo?.atencion === null || cuerpo?.atencion === undefined ? null : ENTERO_1_5(cuerpo.atencion);
  const recomendaria = ['si', 'tal_vez', 'no'].includes(cuerpo?.recomendaria) ? String(cuerpo.recomendaria) : null;
  const sugerencias = String(cuerpo?.sugerencias || '').trim().slice(0, 2000) || null;
  if (fotos === null || web === null || recomendaria === null) return { ok: false, error: 'Respondé las preguntas con estrellas y si nos recomendarías.' };
  return { ok: true, datos: { fotos, web, atencion, recomendaria, sugerencias, quiere_contacto: cuerpo?.quiereContacto === true } };
}

// --- Familias ---------------------------------------------------------------------------------------------------

rutas.get('/api/encuesta', limitarFrecuencia('encuesta', 60, 15 * 60 * 1000), async (req: Request, res: Response) => {
  try {
    const id = leerTokenEncuesta(req.query.t);
    if (!id) return res.status(404).json({ success: false, error: 'El link de la encuesta no es válido.' });
    if (id === TOKEN_PRUEBA) return res.json({ success: true, prueba: true, tutor: '', respuesta: null });
    const supabase = getServerSupabase();
    if (!supabase) return res.status(500).json({ success: false, error: 'Supabase no configurado en el servidor' });
    const { data: insc } = await supabase.from('inscripciones').select('id, padre_nombre').eq('id', id).maybeSingle();
    if (!insc) return res.status(404).json({ success: false, error: 'El link de la encuesta no es válido.' });
    const { data: previa } = await supabase.from('encuestas_familias').select('fotos, web, atencion, recomendaria, sugerencias, quiere_contacto').eq('inscripcion_id', id).maybeSingle();
    return res.json({ success: true, prueba: false, tutor: primerNombre(insc.padre_nombre), respuesta: previa || null });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err?.message || 'No se pudo abrir la encuesta.' });
  }
});

rutas.post('/api/encuesta', limitarFrecuencia('encuesta-respuesta', 20, 15 * 60 * 1000), async (req: Request, res: Response) => {
  try {
    const id = leerTokenEncuesta(req.body?.t);
    if (!id) return res.status(404).json({ success: false, error: 'El link de la encuesta no es válido.' });
    const validacion = validarRespuesta(req.body);
    if (validacion.ok === false) return res.status(400).json({ success: false, error: validacion.error });
    if (id === TOKEN_PRUEBA) return res.json({ success: true, prueba: true });
    const supabase = getServerSupabase();
    if (!supabase) return res.status(500).json({ success: false, error: 'Supabase no configurado en el servidor' });
    const { data: insc } = await supabase.from('inscripciones').select('id, colegio_id, email, padre_nombre').eq('id', id).maybeSingle();
    if (!insc) return res.status(404).json({ success: false, error: 'El link de la encuesta no es válido.' });
    const { error } = await supabase.from('encuestas_familias').upsert(
      { inscripcion_id: insc.id, colegio_id: insc.colegio_id, email: insc.email, tutor_nombre: insc.padre_nombre, ...validacion.datos, updated_at: new Date().toISOString() },
      { onConflict: 'inscripcion_id' }
    );
    if (error) throw error;
    return res.json({ success: true });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err?.message || 'No se pudo guardar la respuesta.' });
  }
});

// --- Panel --------------------------------------------------------------------------------------------------------

async function destinatariosPendientes(supabase: NonNullable<ReturnType<typeof getServerSupabase>>) {
  const { data: colegios, error: errColegios } = await supabase.from('colegios').select('id').eq('activo_publico', true);
  if (errColegios) throw errColegios;
  const ids = (colegios || []).map((c: any) => c.id);
  if (ids.length === 0) return { pendientes: [] as any[], total: 0 };
  const filas = await traerTodasLasFilas<any>((desde, hasta) =>
    supabase.from('inscripciones').select('id, email, padre_nombre, encuesta_enviada_at').eq('estado', 'aceptado').in('colegio_id', ids).order('created_at').order('id').range(desde, hasta)
  );
  // Un mail por casilla (una familia puede tener más de una inscripción con el mismo email).
  const porEmail = new Map<string, { email: string; tutor: string; inscripcionId: string; ids: string[]; enviada: boolean }>();
  for (const f of filas) {
    const email = String(f.email || '').trim().toLowerCase();
    if (!EMAIL_RE.test(email)) continue;
    const actual = porEmail.get(email) || { email, tutor: f.padre_nombre || '', inscripcionId: f.id, ids: [], enviada: false };
    actual.ids.push(f.id);
    actual.enviada = actual.enviada || Boolean(f.encuesta_enviada_at);
    porEmail.set(email, actual);
  }
  const todos = [...porEmail.values()];
  return { pendientes: todos.filter((d) => !d.enviada), total: todos.length };
}

rutas.get('/api/admin/encuesta', requireAdminAuth, async (_req: Request, res: Response) => {
  try {
    const supabase = getServerSupabase();
    if (!supabase) return res.status(500).json({ success: false, error: 'Supabase no configurado en el servidor' });
    const [{ pendientes, total }, respuestas] = await Promise.all([
      destinatariosPendientes(supabase),
      traerTodasLasFilas<any>((desde, hasta) =>
        supabase.from('encuestas_familias').select('id, email, tutor_nombre, fotos, web, atencion, recomendaria, sugerencias, quiere_contacto, created_at, updated_at').order('updated_at', { ascending: false }).order('id').range(desde, hasta)
      ),
    ]);
    return res.json({ success: true, destinatarios: total, pendientesDeEnvio: pendientes.length, respuestas });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err?.message || 'No se pudo leer la encuesta.' });
  }
});

// 26/10: el envío del mail de la encuesta pasó al panel «Emails» (servidor/panel/emailsFamilias.ts, tipo «encuesta»).

export { rutas as rutasEncuesta };
