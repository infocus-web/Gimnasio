// Nómina oficial del colegio (tabla `alumnos`, la carga Pablo desde el panel) y los cursos que existen en
// ella. Se movió acá desde inscripciones.ts el 12/10/2026, cuando se sumaron los cursos válidos:
//   - `crearBuscadorEnNomina`: el curso real de un alumno por su nombre (ya existía).
//   - `cursosDeLaNomina` + `GET /api/colegios/:id/cursos`: qué combinaciones grado / división / turno
//     existen, para que el formulario de inscripción sólo ofrezca ésas.
//   - `cursoFueraDeNomina`: la misma regla del lado del servidor.
//   - `PATCH /api/admin/alumnos/:id/curso` (13/10): el panel pasa a un alumno mal cargado a otro curso de la nómina.
// Caso real (12/10, Divino Pastor): «Jornada Extendida» figura como división del colegio (existe en 5° y
// 6° grado), y familias de Sala 4 y de 1° a 3° grado la elegían cuando en la nómina sus hijos son de la
// división A o C con turno «Jornada Extendida / Completa». Quedaban en un curso que no existe: no iban a
// ver las fotos de su curso, y dos de esos cursos inventados chocaban en el código interno (SALA4-JOJE).
import type { SupabaseClient } from '@supabase/supabase-js';
import express from 'express';
import type { Request, Response } from 'express';
import { requireAdminAuth } from '../nucleo/auth.js';
import { getServerSupabase } from '../nucleo/clientes.js';
import { buscarColegioReal } from '../nucleo/colegios.js';
import { limitarFrecuencia } from '../nucleo/limites.js';
import { nombresCompatibles } from '../nucleo/nombres.js';
import { normalizarNombrePorPalabras, traerTodasLasFilas } from '../nucleo/utilidades.js';

const rutas = express.Router();

// Auditoría 2026-09-24 (bug real en datos de producción, CRÍTICO): de las inscripciones cuyo
// alumno figura en la nómina oficial del colegio (tabla `alumnos`, cargada desde el panel), 1 de
// cada 3 quedó en una DIVISIÓN distinta a la real — casi siempre la "A" (la que el formulario
// traía preseleccionada) o "Jornada Extendida" (que el formulario ponía solo al elegir ese turno,
// cuando en la nómina esos chicos son de la división C). Como el código de acceso es por sección,
// esas familias reciben el código de OTRO curso: verían fotos de otros chicos y no las de su hijo.
// Cuando el nombre del alumno coincide sin ambigüedad con la nómina, el curso de la nómina manda.
export type CursoNomina = { grado: string; turno: string | null; division: string };
export async function crearBuscadorEnNomina(supabase: SupabaseClient, colegioId: string) {
  let nomina: { claves: string[]; palabras: Set<string>; curso: CursoNomina }[] | null = null;
  const cargar = async () => {
    if (nomina) return nomina;
    const filas = await traerTodasLasFilas<any>((desde, hasta) =>
      supabase.from('alumnos').select('nombre, grado, turno, division').eq('colegio_id', colegioId).order('id').range(desde, hasta)
    );
    nomina = filas
      .filter((a) => a.nombre && a.grado && a.division)
      .map((a) => {
        const clave = normalizarNombrePorPalabras(a.nombre);
        return {
          claves: [clave],
          palabras: new Set(clave.split(' ').filter(Boolean)),
          curso: { grado: String(a.grado).trim(), turno: a.turno ? String(a.turno).trim() : null, division: String(a.division).trim() },
        };
      });
    return nomina;
  };
  const mismaSeccion = (a: CursoNomina, b: CursoNomina) => a.grado === b.grado && a.division === b.division && (a.turno || '') === (b.turno || '');
  const unico = (cursos: CursoNomina[]): CursoNomina | null =>
    cursos.length > 0 && cursos.every((c) => mismaSeccion(c, cursos[0])) ? cursos[0] : null;

  return async (nombreCompleto: string, gradoEscrito?: unknown): Promise<CursoNomina | null> => {
    const clave = normalizarNombrePorPalabras(nombreCompleto);
    const palabras = clave.split(' ').filter(Boolean);
    if (palabras.length < 2) return null;
    try {
      const lista = await cargar();
      const exactos = lista.filter((a) => a.claves[0] === clave).map((a) => a.curso);
      if (exactos.length > 0) return unico(exactos);
      // La familia pudo escribir sólo uno de los nombres ("Juan Pérez" por "Juan Martín Pérez"):
      // se acepta si todas sus palabras están en un único alumno de la nómina. Como una
      // coincidencia parcial es más débil ("Juan Perez" también está contenido en "Alvarez
      // Perez, Juan Martin", de otro año), sólo se usa si además coincide el grado elegido.
      const grado = String(gradoEscrito || '').trim();
      if (!grado) return null;
      // 14/10/2026 (caso «Adriana Yanet Noguera Cabral» vs «NOGUERA CABRAL, ADRIANA»): también al revés, si la
      // familia escribió un nombre de más: todas las palabras del alumno de la nómina (2 o más) están en lo escrito.
      const parciales = lista
        .filter((a) => a.curso.grado === grado && (palabras.every((w) => a.palabras.has(w)) || (a.palabras.size >= 2 && [...a.palabras].every((w) => palabras.includes(w)))))
        .map((a) => a.curso);
      // Auditoría 03/10 noche (A3): una coincidencia parcial tiene que ser UN solo alumno (antes
      // alcanzaba con que todos los que coincidían fueran de la misma sección).
      return parciales.length === 1 ? parciales[0] : null;
    } catch (e) {
      console.warn('[inscripciones] No se pudo consultar la nómina para corregir el curso:', e);
      return null;
    }
  };
}

// ---------------------------------------------------------------------------------------------
// Cursos que existen en la nómina (grado + división + turno). El turno puede faltar (secundaria):
// en ese caso cualquier turno vale para esa división.
// ---------------------------------------------------------------------------------------------
const DURACION_CACHE_CURSOS_MS = 5 * 60 * 1000;
const cacheCursos = new Map<string, { cursos: CursoNomina[]; vence: number }>();

/** Para comparar textos de cursos: sin tildes, mayúsculas ni espacios de más. */
export const normalizarTextoCurso = (v: unknown) =>
  String(v ?? '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/\s+/g, ' ').trim();

export async function cursosDeLaNomina(supabase: SupabaseClient, colegioId: string): Promise<CursoNomina[]> {
  const guardado = cacheCursos.get(colegioId);
  if (guardado && guardado.vence > Date.now()) return guardado.cursos;
  const filas = await traerTodasLasFilas<any>((desde, hasta) =>
    supabase.from('alumnos').select('grado, division, turno').eq('colegio_id', colegioId).order('id').range(desde, hasta)
  );
  const vistos = new Map<string, CursoNomina>();
  for (const f of filas) {
    const grado = String(f?.grado || '').trim();
    const division = String(f?.division || '').trim();
    if (!grado || !division) continue;
    const turno = f?.turno ? String(f.turno).trim() : null;
    const clave = [grado, division, turno || ''].map(normalizarTextoCurso).join('|');
    if (!vistos.has(clave)) vistos.set(clave, { grado, division, turno });
  }
  const cursos = [...vistos.values()];
  cacheCursos.set(colegioId, { cursos, vence: Date.now() + DURACION_CACHE_CURSOS_MS });
  return cursos;
}

/** Pruebas, y al cambiar de curso a un alumno desde el panel (13/10). */
export function limpiarCacheCursosNomina() {
  cacheCursos.clear();
}

const etiquetaDivision = (division: string) => (/jornada|extendida/i.test(division) ? division : `división ${division}`);

/**
 * Los cursos que existen en un grado según la nómina, en texto («división A (Mañana), división C
 * (Tarde)»), ordenados. null si el grado no tiene alumnos en la nómina. Lo usan el mensaje de abajo y la
 * ficha que recibe la IA de consultas (13/10), para que nunca proponga un curso que no existe.
 */
export function cursosDelGradoEnTexto(cursos: CursoNomina[], grado: unknown): string | null {
  const buscado = normalizarTextoCurso(grado);
  const delGrado = buscado ? cursos.filter((c) => normalizarTextoCurso(c.grado) === buscado) : [];
  if (delGrado.length === 0) return null;
  return delGrado
    .map((c) => `${etiquetaDivision(c.division)}${c.turno ? ` (${c.turno})` : ''}`)
    .sort((a, b) => a.localeCompare(b, 'es'))
    .join(', ');
}

/**
 * Si el grado tiene alumnos en la nómina y la división + turno elegidos no existen en ese grado, devuelve
 * el mensaje para la familia (con los cursos que sí hay). Si el grado no está en la nómina (colegio sin
 * nómina, o un grado que no se cargó), no frena nada.
 */
export function mensajeCursoFueraDeNomina(
  cursos: CursoNomina[],
  elegido: { grado?: unknown; division?: unknown; turno?: unknown },
  quien = 'El alumno/a'
): string | null {
  const grado = normalizarTextoCurso(elegido.grado);
  if (!grado) return null;
  const delGrado = cursos.filter((c) => normalizarTextoCurso(c.grado) === grado);
  if (delGrado.length === 0) return null;
  const division = normalizarTextoCurso(elegido.division);
  const turno = normalizarTextoCurso(elegido.turno);
  const existe = delGrado.some(
    (c) => normalizarTextoCurso(c.division) === division && (!c.turno || normalizarTextoCurso(c.turno) === turno)
  );
  if (existe) return null;
  return `${quien}: en ${String(elegido.grado).trim()} no existe ${etiquetaDivision(String(elegido.division || '').trim() || '—')}${
    elegido.turno ? ` con turno ${String(elegido.turno).trim()}` : ''
  }. En ese grado hay: ${cursosDelGradoEnTexto(cursos, elegido.grado)}. Elegí el curso que figura en la escuela.`;
}

/** La regla anterior para el alumno principal y cada hermano (todos del mismo colegio). */
export async function cursoFueraDeNomina(
  supabase: SupabaseClient,
  colegioId: string,
  principal: { grado?: unknown; division?: unknown; turno?: unknown },
  hermanos: any[]
): Promise<string | null> {
  let cursos: CursoNomina[];
  try {
    cursos = await cursosDeLaNomina(supabase, colegioId);
  } catch (e) {
    // Sin la nómina no se frena la inscripción: queda como antes (la revisa Pablo).
    console.warn('[inscripciones] No se pudo leer la nómina para validar el curso:', e);
    return null;
  }
  const errorPrincipal = mensajeCursoFueraDeNomina(cursos, principal);
  if (errorPrincipal) return errorPrincipal;
  for (const h of Array.isArray(hermanos) ? hermanos : []) {
    const nombre = `${h?.alumnoNombre || ''} ${h?.alumnoApellido || ''}`.trim() || 'Un hermano/a';
    const errorHermano = mensajeCursoFueraDeNomina(cursos, h || {}, nombre);
    if (errorHermano) return errorHermano;
  }
  return null;
}

// Pública (la usa el formulario de inscripción antes de que la familia se identifique): sólo grado,
// división y turno, sin ningún dato de los alumnos. Se puede cachear 5 minutos.
rutas.get('/api/colegios/:id/cursos', limitarFrecuencia('colegio-cursos', 120, 15 * 60 * 1000), async (req: Request, res: Response) => {
  try {
    const supabase = getServerSupabase();
    if (!supabase) return res.status(503).json({ success: false, error: 'Servicio no disponible.' });
    const colegio = await buscarColegioReal(supabase, req.params.id);
    if (!colegio) return res.status(404).json({ success: false, error: 'Colegio no encontrado.' });
    const cursos = await cursosDeLaNomina(supabase, colegio.id);
    res.setHeader('Cache-Control', 'public, max-age=300');
    return res.json({ success: true, cursos });
  } catch (err: any) {
    console.error('[cursos] Error al leer los cursos del colegio:', err);
    return res.status(500).json({ success: false, error: 'No se pudieron cargar los cursos.' });
  }
});

// Panel: cambiar de curso a un alumno mal cargado en la nómina (pedido de Pablo, 13/10/2026). Sólo mueve la
// fila de `alumnos` a OTRO curso que ya exista en la nómina del mismo colegio (no se inventan cursos: la
// nómina manda sobre los cursos válidos de la inscripción). Queda último en la lista del curso nuevo.
// 14/10/2026 (caso Tomás Hernando Paludi: se movía la nómina pero la familia seguía con el código del curso
// viejo): también mueve la inscripción de la familia que tenía al chico anotado en el curso viejo. Si es el hijo
// principal, la inscripción toma el código del curso nuevo (el panel ofrece mandárselo por email); si es un
// hermano, sólo cambia su curso dentro de la inscripción (el código de la familia no cambia). No toca pedidos.
export type InscripcionMovida = { id: string; padre: string; email: string; esHermano: boolean; codigoNuevo: string | null };

async function moverInscripcionesDelAlumno(
  supabase: SupabaseClient,
  alumno: { colegio_id: unknown; nombre: string; grado: string; division: string; turno: string | null },
  nuevo: { grado: string; division: string; turno: string | null }
): Promise<{ movidas: InscripcionMovida[]; cursoSinCodigo: boolean }> {
  const igual = (a: unknown, b: unknown) => normalizarTextoCurso(a) === normalizarTextoCurso(b);
  const enCursoViejo = (c: any) => igual(c?.grado, alumno.grado) && igual(c?.division, alumno.division) && igual(c?.turno, alumno.turno);
  const esElChico = (nombre: unknown, apellido: unknown) => nombresCompatibles(`${nombre || ''} ${apellido || ''}`.trim(), alumno.nombre);
  const filas = await traerTodasLasFilas<any>((desde, hasta) =>
    supabase
      .from('inscripciones')
      .select('id, padre_nombre, email, estado, alumno_nombre, alumno_apellido, grado, division, turno, codigo_asignado, codigo_familiar, hermanos')
      .eq('colegio_id', String(alumno.colegio_id))
      .order('id')
      .range(desde, hasta)
  );

  let codigoDestino: string | null | undefined;
  const buscarCodigoDestino = async () => {
    if (codigoDestino !== undefined) return codigoDestino;
    const { data } = await supabase
      .from('codigos_seccion')
      .select('codigo_secreto')
      .eq('colegio_id', String(alumno.colegio_id))
      .eq('grado', nuevo.grado)
      .eq('division', nuevo.division)
      .eq('turno', nuevo.turno ?? '')
      .maybeSingle();
    codigoDestino = data?.codigo_secreto || null;
    return codigoDestino;
  };

  const movidas: InscripcionMovida[] = [];
  let cursoSinCodigo = false;
  for (const fila of filas) {
    if (fila.estado === 'rechazado') continue;
    const datosFamilia = { id: String(fila.id), padre: String(fila.padre_nombre || ''), email: String(fila.email || '') };
    if (enCursoViejo(fila) && esElChico(fila.alumno_nombre, fila.alumno_apellido)) {
      const codigo = await buscarCodigoDestino();
      if (!codigo) {
        // Sin código del curso nuevo no se mueve: la familia quedaría con un curso y un código que no coinciden.
        cursoSinCodigo = true;
        continue;
      }
      const cambios: Record<string, unknown> = { grado: nuevo.grado, division: nuevo.division, turno: nuevo.turno, codigo_asignado: codigo, updated_at: new Date().toISOString() };
      if (!fila.codigo_familiar || fila.codigo_familiar === fila.codigo_asignado) cambios.codigo_familiar = codigo;
      const { error } = await supabase.from('inscripciones').update(cambios).eq('id', fila.id);
      if (error) throw error;
      movidas.push({ ...datosFamilia, esHermano: false, codigoNuevo: codigo });
      continue;
    }
    const hermanos = Array.isArray(fila.hermanos) ? fila.hermanos : [];
    let tocado = false;
    const nuevosHermanos = hermanos.map((h: any) => {
      if (h && typeof h === 'object' && enCursoViejo(h) && esElChico(h.alumnoNombre ?? h.alumno_nombre, h.alumnoApellido ?? h.alumno_apellido)) {
        tocado = true;
        return { ...h, grado: nuevo.grado, division: nuevo.division, turno: nuevo.turno };
      }
      return h;
    });
    if (tocado) {
      const { error } = await supabase.from('inscripciones').update({ hermanos: nuevosHermanos, updated_at: new Date().toISOString() }).eq('id', fila.id);
      if (error) throw error;
      movidas.push({ ...datosFamilia, esHermano: true, codigoNuevo: null });
    }
  }
  return { movidas, cursoSinCodigo };
}

rutas.patch('/api/admin/alumnos/:id/curso', requireAdminAuth, async (req: Request, res: Response) => {
  try {
    const texto = (v: unknown) => String(v ?? '').trim().slice(0, 60);
    const destino = { grado: texto(req.body?.grado), division: texto(req.body?.division), turno: texto(req.body?.turno) };
    if (!destino.grado || !destino.division) {
      return res.status(400).json({ success: false, error: 'Falta indicar el grado y la división del curso nuevo.' });
    }
    const supabase = getServerSupabase();
    if (!supabase) return res.status(500).json({ success: false, error: 'Supabase no configurado en el servidor' });

    const { data: alumno, error: errAlumno } = await supabase
      .from('alumnos')
      .select('id, colegio_id, nombre, grado, division, turno')
      .eq('id', req.params.id)
      .maybeSingle();
    if (errAlumno) throw errAlumno;
    if (!alumno) return res.status(404).json({ success: false, error: 'El alumno ya no está en la nómina.' });

    const igual = (a: unknown, b: unknown) => normalizarTextoCurso(a) === normalizarTextoCurso(b);
    const esElDestino = (f: any) => igual(f.grado, destino.grado) && igual(f.division, destino.division) && igual(f.turno, destino.turno);
    // 14/10/2026 (auditoría): si ya está en ese curso (p. ej. un reintento después de un corte), es un éxito.
    if (esElDestino(alumno)) {
      const { data: actual } = await supabase.from('alumnos').select('id, nombre, grado, division, turno, colegio_id, numero_lista, dni, origen').eq('id', alumno.id).maybeSingle();
      return res.json({ success: true, alumno: actual || alumno, sinCambios: true });
    }

    const delColegio = await traerTodasLasFilas<any>((desde, hasta) =>
      supabase.from('alumnos').select('id, grado, division, turno, numero_lista').eq('colegio_id', alumno.colegio_id).order('id').range(desde, hasta)
    );
    const delDestino = delColegio.filter((f) => f.id !== alumno.id && esElDestino(f));
    if (delDestino.length === 0) {
      return res.status(400).json({ success: false, error: 'Ese curso no existe en la nómina de este colegio.' });
    }

    // Se copia el texto exacto del curso destino, para que el alumno no quede en un curso "parecido".
    const modelo = delDestino[0];
    const ultimo = delDestino.reduce((max, f) => (Number.isFinite(f.numero_lista) && f.numero_lista > max ? f.numero_lista : max), 0);
    const cambios = { grado: modelo.grado, division: modelo.division, turno: modelo.turno ?? null, numero_lista: ultimo + 1 };
    const { data: actualizado, error: errUpdate } = await supabase
      .from('alumnos')
      .update(cambios)
      .eq('id', alumno.id)
      .select('id, nombre, grado, division, turno, colegio_id, numero_lista, dni, origen')
      .maybeSingle();
    if (errUpdate) throw errUpdate;
    limpiarCacheCursosNomina();
    // Si falla mover la inscripción, la nómina ya quedó cambiada: se avisa para revisarla a mano.
    let inscripciones: InscripcionMovida[] = [];
    let cursoSinCodigo = false;
    let errorInscripciones: string | undefined;
    try {
      ({ movidas: inscripciones, cursoSinCodigo } = await moverInscripcionesDelAlumno(supabase, alumno, cambios));
    } catch (e) {
      console.error('[nómina] El alumno cambió de curso pero no se pudo mover su inscripción:', e);
      errorInscripciones = 'El alumno cambió de curso, pero no se pudo actualizar la inscripción de su familia: revisala a mano.';
    }
    return res.json({ success: true, alumno: actualizado || { ...alumno, ...cambios }, inscripciones, cursoSinCodigo, errorInscripciones });
  } catch (err: any) {
    console.error('[nómina] Error al cambiar de curso al alumno:', err);
    return res.status(500).json({ success: false, error: err?.message || 'Error al cambiar de curso al alumno' });
  }
});

// 13/10/2026 (Pablo: «los alumnos que fotografiamos hoy, y tildamos, no están»): la marca de
// «fotografiado» de la Nómina vivía sólo en la memoria del navegador y se perdía al recargar. Ahora
// se guarda en `alumnos.fotografiado_at` (null = sin marcar). Sirve para uno o para varios a la vez
// («Chequear filtrados»); devuelve las filas actualizadas.
// 14/10/2026 (grupales que se sacan otro día): con `foto: 'grupal'` marca/desmarca `alumnos.foto_grupal_at`.
// 21/10/2026: con `foto: 'seno'` marca/desmarca la foto con la seño (`alumnos.foto_seno_at`); `fotografiado_at`
// queda sólo para la individual.
const COLUMNA_FOTO = { fotografiado: 'fotografiado_at', seno: 'foto_seno_at', grupal: 'foto_grupal_at' } as const;
const UUID_ALUMNO = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
rutas.post('/api/admin/alumnos/fotografiados', requireAdminAuth, async (req: Request, res: Response) => {
  try {
    const ids = Array.isArray(req.body?.ids) ? Array.from(new Set(req.body.ids.map((v: unknown) => String(v)))) as string[] : [];
    if (ids.length === 0 || ids.length > 1000 || !ids.every((id) => UUID_ALUMNO.test(id))) {
      return res.status(400).json({ success: false, error: 'Lista de alumnos no válida.' });
    }
    if (typeof req.body?.fotografiado !== 'boolean') return res.status(400).json({ success: false, error: 'Falta indicar si se marca o se desmarca.' });
    const foto = req.body?.foto ?? 'fotografiado';
    if (!Object.prototype.hasOwnProperty.call(COLUMNA_FOTO, foto)) return res.status(400).json({ success: false, error: 'Foto no válida.' });
    const columna = COLUMNA_FOTO[foto as keyof typeof COLUMNA_FOTO];
    const supabase = getServerSupabase();
    if (!supabase) return res.status(500).json({ success: false, error: 'Supabase no configurado en el servidor' });
    const fotografiadoAt = req.body.fotografiado ? new Date().toISOString() : null;
    const alumnos: { id: string; fotografiado_at: string | null; foto_seno_at: string | null; foto_grupal_at: string | null }[] = [];
    for (let i = 0; i < ids.length; i += 200) {
      const { data, error } = await supabase
        .from('alumnos')
        .update({ [columna]: fotografiadoAt })
        .in('id', ids.slice(i, i + 200))
        .select('id, fotografiado_at, foto_seno_at, foto_grupal_at');
      if (error) throw error;
      alumnos.push(...(data || []));
    }
    return res.json({ success: true, alumnos });
  } catch (err: any) {
    console.error('[Nómina] Error al guardar «fotografiado»:', err);
    return res.status(500).json({ success: false, error: 'No se pudo guardar la marca de fotografiado. Probá de nuevo.' });
  }
});

export { rutas as rutasCursosNomina };
