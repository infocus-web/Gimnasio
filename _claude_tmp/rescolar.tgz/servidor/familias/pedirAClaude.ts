// 27/10/2026 (Pablo: «en vez de pegarte el email del cliente para pedirte que soluciones el caso, con un botón
// llamarte»): «Pedirle a Claude» en Atender consultas. El servidor dispara una RUTINA de Claude Code (API oficial
// «routines fire», experimental) con los datos de la consulta; la rutina abre una sesión de Claude Code que
// investiga el caso con acceso a la base y el panel abre esa sesión en otra pestaña para seguirla y darle el OK.
// La rutina sólo investiga y propone: no escribe en la base ni le manda nada a la familia sin el OK de Pablo
// en esa sesión (lo dice su propio prompt, configurado en claude.ai/code/routines).
// Variables (Vercel, Production, Sensitive): CLAUDE_RUTINA_ID (trig_…) y CLAUDE_RUTINA_TOKEN (sk-ant-oat01-…,
// token propio de la rutina; no es la ANTHROPIC_API_KEY).

export const URL_RUTINAS = 'https://api.anthropic.com/v1/claude_code/routines';
const MAX_TEXTO = 60_000; // la API acepta hasta 65.536 caracteres

export type ConsultaParaClaude = {
  id: string;
  nombre?: string | null;
  email?: string | null;
  asunto?: string | null;
  mensaje?: string | null;
  colegio?: string | null;
  numero_pedido?: string | null;
  created_at?: string | null;
  verificacion_ia?: any;
};
export type MensajeParaClaude = { direccion?: string | null; contenido?: string | null; created_at?: string | null };

const corto = (v: unknown, n: number) => {
  const t = String(v ?? '').replace(/\r/g, '').trim();
  return t.length > n ? `${t.slice(0, n)}…` : t;
};

/** El texto que recibe la sesión de Claude: qué consulta es, la conversación y lo que ya vio la IA del panel. */
export function textoPedidoClaude(c: ConsultaParaClaude, mensajes: MensajeParaClaude[], nota?: string): string {
  const v = c.verificacion_ia && typeof c.verificacion_ia === 'object' ? c.verificacion_ia : null;
  const conversacion = mensajes.length
    ? mensajes.map((m) => `- ${m.direccion === 'entrante' ? 'Familia' : 'Nosotros'} (${m.created_at || ''}): ${corto(m.contenido, 1500)}`).join('\n')
    : `- Familia (${c.created_at || ''}): ${corto(c.mensaje, 3000)}`;
  const partes = [
    `Pablo tocó «Pedirle a Claude» en Atender consultas. Revisá este caso de Retrato Escolar y solucionalo.`,
    ``,
    `Consulta: ${c.id}`,
    `Familia: ${corto(c.nombre, 120) || '—'} <${corto(c.email, 254) || 'sin email'}>`,
    c.colegio ? `Colegio: ${corto(c.colegio, 160)}` : '',
    c.numero_pedido ? `Pedido: ${corto(c.numero_pedido, 80)}` : '',
    `Asunto: ${corto(c.asunto, 200) || '—'}`,
    ``,
    `Conversación (de la más vieja a la más nueva):`,
    conversacion,
  ];
  if (v?.entendido || v?.motivo) {
    partes.push('', 'Lo que ya vio la IA del panel (puede estar mal: verificalo):');
    if (v.entendido) partes.push(`- Entendió: ${corto(v.entendido, 800)}`);
    if (v.motivo) partes.push(`- Motivo: ${corto(v.motivo, 1500)}`);
    if (Array.isArray(v.ambiguedades) && v.ambiguedades.length) partes.push(`- Dudas: ${v.ambiguedades.map((a: unknown) => corto(a, 400)).join(' | ')}`);
  }
  if (nota && nota.trim()) partes.push('', `Nota de Pablo: ${corto(nota, 1500)}`);
  return partes.filter((p) => p !== '').join('\n').slice(0, MAX_TEXTO);
}

// Un solo tipo (el proyecto no usa strictNullChecks y la unión no se angosta con `!r.ok`).
export type ResultadoRutina = { ok: boolean; url?: string; sesion?: string; status?: number; error?: string };

/** Dispara la rutina. Sin las variables devuelve 503 (el panel lo explica). */
export async function dispararRutinaClaude(texto: string, ms = 20_000): Promise<ResultadoRutina> {
  const id = process.env.CLAUDE_RUTINA_ID?.trim();
  const token = process.env.CLAUDE_RUTINA_TOKEN?.trim();
  if (!id || !token) return { ok: false, status: 503, error: 'Falta configurar la rutina de Claude (CLAUDE_RUTINA_ID y CLAUDE_RUTINA_TOKEN en Vercel).' };
  if (!/^trig_[A-Za-z0-9_-]+$/.test(id)) return { ok: false, status: 503, error: 'CLAUDE_RUTINA_ID no tiene el formato trig_…' };
  let resp: Response;
  try {
    resp = await fetch(`${URL_RUTINAS}/${encodeURIComponent(id)}/fire`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${token}`, 'anthropic-version': '2023-06-01', 'Content-Type': 'application/json' },
      body: JSON.stringify({ text: texto }),
      signal: AbortSignal.timeout(ms),
    });
  } catch {
    return { ok: false, status: 502, error: 'No pudimos comunicarnos con Claude. Probá de nuevo en unos segundos.' };
  }
  const data: any = await resp.json().catch(() => ({}));
  if (resp.ok && typeof data?.claude_code_session_url === 'string' && data.claude_code_session_url.startsWith('https://claude.ai/')) {
    return { ok: true, url: data.claude_code_session_url, sesion: String(data.claude_code_session_id || '') };
  }
  const motivos: Record<number, string> = {
    400: 'La rutina de Claude está pausada o el pedido no es válido.',
    401: 'El token de la rutina de Claude no es válido (generá uno nuevo y actualizá CLAUDE_RUTINA_TOKEN).',
    403: 'La cuenta no tiene acceso a las rutinas de Claude Code.',
    404: 'No existe la rutina de Claude (revisá CLAUDE_RUTINA_ID).',
    429: 'Se llegó al límite de pedidos a Claude por hora. Probá más tarde.',
  };
  console.error('[Pedirle a Claude] La rutina respondió', resp.status, data?.error?.type || '');
  return { ok: false, status: resp.status === 429 ? 429 : 502, error: motivos[resp.status] || 'Claude no pudo tomar el caso. Probá de nuevo en unos segundos.' };
}

/** 28/10/2026: la cuenta de Pablo no tiene el disparador por API de las rutinas (sólo «Programación»). */
export function rutinaClaudeConfigurada(): boolean {
  return Boolean(process.env.CLAUDE_RUTINA_ID?.trim() && process.env.CLAUDE_RUTINA_TOKEN?.trim());
}

/**
 * 28/10/2026: sin rutina, el panel copia este texto al portapapeles y abre Claude en el proyecto Retrato Escolar
 * para que Pablo lo pegue. Lleva las reglas que antes estaban en el prompt de la rutina (resumidas).
 */
export function textoParaPegarEnClaude(caso: string): string {
  return [
    'Revisá este caso de una consulta de Retrato Escolar y dejame la solución lista.',
    'Investigá con Supabase (proyecto ntkqypxvrljuihbxdrtx), sólo con SELECT: inscripciones, alumnos (nómina), fotos, pedidos, consultas_familias y consultas_familias_mensajes. Verificá todo, también lo que vio la IA del panel.',
    'No escribas en la base ni le mandes nada a nadie sin mi OK en esta conversación. Si proponés un cambio, mostrame el SQL exacto y seguro.',
    'Al terminar: 1) qué pasa, con los datos que lo prueban; 2) qué encontraste; 3) qué hay que hacer; 4) el mensaje para la familia listo para copiar, firmado «Pablo – Retrato Escolar»; 5) qué no pudiste verificar.',
    '',
    '---',
    caso,
  ].join('\n').slice(0, MAX_TEXTO);
}
