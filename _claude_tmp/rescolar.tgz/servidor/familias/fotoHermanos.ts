// Consulta «foto de hermanos» (email con Sí / No, página /foto-hermanos.html, panel) (división de
// server.ts, etapa 5, 10/10/2026). El código es el mismo que estaba en la sección CONSULTA «FOTO DE
// HERMANOS» de server.ts: sólo se movió. Detalle en el documento del proyecto
// claude/consulta-foto-hermanos-2026-10-08.md.
import type { SupabaseClient } from '@supabase/supabase-js';
import crypto from 'crypto';
import express from 'express';
import type { Request, Response } from 'express';
import { compararTimingSafe, getAdminSessionSecret, requireAdminAuth } from '../nucleo/auth.js';
import { getResendClient, getServerSupabase, resendReplyTo } from '../nucleo/clientes.js';
import { limitarFrecuencia } from '../nucleo/limites.js';
import { escapeHtml, traerTodasLasFilas } from '../nucleo/utilidades.js';
import { hijosDeFamiliaConAcceso } from './inscripciones.js';
import { requireColegioAuth } from '../colegio/panelColegio.js';
import { citasUltimaCitacion } from './citasHermanos.js';

const rutas = express.Router();

// ==============================================================================
// CONSULTA «FOTO DE HERMANOS» (pedido de Pablo 08/10)
// Hasta el 08/10 la inscripción marcaba la foto de hermanos a TODA familia que anotaba hermanos,
// tildara o no la casilla. A las que quedaron marcadas así (solicita_foto_hermanos = true y
// foto_hermanos_confirmada_at null) se les manda, desde el panel (Inscriptos), un email con dos
// botones: «Sí» y «No». Cada botón abre /foto-hermanos.html?f=<id>.<llave>&r=si|no, donde la familia
// ve las dos casillas, tilda una y toca «Confirmar»: recién ahí se actualiza solicita_foto_hermanos.
// Los botones del email NO guardan nada solos (los antivirus de correo abren los links para
// revisarlos): sólo dejan preseleccionada la casilla.
// ==============================================================================
function tokenFotoHermanos(inscripcionId: unknown): string | null {
  const secreto = process.env.PEDIDOS_ACCESO_SECRET?.trim() || getAdminSessionSecret();
  if (!secreto || !inscripcionId) return null;
  return crypto.createHmac('sha256', secreto).update(`foto-hermanos:${inscripcionId}`).digest('base64url').slice(0, 32);
}

function linkFotoHermanos(inscripcionId: string, respuesta?: 'si' | 'no'): string | null {
  const token = tokenFotoHermanos(inscripcionId);
  if (!token) return null;
  const appUrl = (process.env.APP_URL || 'https://www.retratoescolar.com.ar').replace(/\/+$/, '');
  return `${appUrl}/foto-hermanos.html?f=${encodeURIComponent(`${inscripcionId}.${token}`)}${respuesta ? `&r=${respuesta}` : ''}`;
}

/** Llave del link (`<uuid>.<token>`) → id de la inscripción, o null si no es válida. */
function inscripcionDeLlaveFotoHermanos(llave: unknown): string | null {
  const texto = String(llave || '').trim();
  const punto = texto.indexOf('.');
  if (punto < 0) return null;
  const id = texto.slice(0, punto);
  const token = texto.slice(punto + 1);
  const esperado = tokenFotoHermanos(id);
  if (!/^[0-9a-f-]{36}$/i.test(id) || !esperado || !token || !compararTimingSafe(token, esperado)) return null;
  return id;
}

/** "CIRO gabriel" → "Ciro Gabriel" (los nombres llegan escritos de cualquier manera). */
function nombrePropioFotoHermanos(texto: unknown): string {
  return String(texto || '')
    .trim()
    .replace(/\s+/g, ' ')
    .toLowerCase()
    .replace(/(^|[\s'-])(\p{L})/gu, (_m, separador: string, letra: string) => separador + letra.toUpperCase());
}

/** Nombres (sin apellido) del chico anotado y de sus hermanos, para el saludo "familia de …". */
function chicosDeInscripcionFotoHermanos(fila: any): string[] {
  const hermanos = Array.isArray(fila?.hermanos) ? fila.hermanos : [];
  return [fila?.alumno_nombre, ...hermanos.map((h: any) => h?.alumnoNombre)].map(nombrePropioFotoHermanos).filter(Boolean);
}

/** ["Ana", "Inés"] → "Ana e Inés"; ["Ana", "Luz", "Pía"] → "Ana, Luz y Pía". */
function unirNombresFotoHermanos(nombres: string[]): string {
  const lista = nombres.filter(Boolean);
  if (lista.length <= 1) return lista[0] || '';
  const ultimo = lista[lista.length - 1];
  const conector = /^h?i(?![aeouáéóú])/i.test(ultimo) ? ' e ' : ' y ';
  return `${lista.slice(0, -1).join(', ')}${conector}${ultimo}`;
}

const tieneHermanosFotoHermanos = (fila: any) => Array.isArray(fila?.hermanos) && fila.hermanos.length > 0;
const emailValidoFotoHermanos = (email: unknown) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(email || '').trim());

/** Email de la consulta (se arma aparte para poder verlo y probarlo sin mandarlo). */
function correoConsultaFotoHermanos(datos: { chicos: string[]; colegio: string; linkSi: string; linkNo: string; recordatorio?: boolean }) {
  const familia = escapeHtml(unirNombresFotoHermanos(datos.chicos) || 'sus hijos');
  const colegio = escapeHtml(datos.colegio || 'la institución');
  const asunto = datos.recordatorio ? 'Recordatorio: ¿quieren la foto de hermanos juntos?' : '¿Quieren la foto de hermanos juntos?';
  const html = `<!doctype html>
<html lang="es">
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>${asunto} — Retrato Escolar</title></head>
<body style="margin:0;padding:0;background-color:#f8fafc;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Helvetica,Arial,sans-serif;color:#1e293b;">
  <div style="max-width:600px;margin:24px auto;background-color:#ffffff;border-radius:16px;border:1px solid #e2e8f0;overflow:hidden;">
    <div style="background-color:#0f172a;padding:30px 24px;text-align:center;border-bottom:3px solid #f59e0b;">
      <div style="font-size:11px;font-weight:800;letter-spacing:2px;color:#f59e0b;text-transform:uppercase;margin-bottom:6px;">RETRATO ESCOLAR</div>
      <h1 style="color:#ffffff;margin:0;font-size:22px;font-weight:800;">${asunto}</h1>
      <p style="color:#94a3b8;font-size:13px;margin:6px 0 0 0;">${colegio}</p>
    </div>
    <div style="padding:28px 24px;">
      <p style="font-size:15px;line-height:1.6;margin-top:0;">Hola, familia de <strong>${familia}</strong>:</p>
      <p style="font-size:14px;line-height:1.6;color:#334155;">En la inscripción figuraba la opción de pedir una <strong>foto de hermanos juntos</strong>. Por un error de nuestro sistema, esa opción quedó marcada para todas las familias que anotaron hermanos, aunque no la hayan elegido.</p>
      <p style="font-size:14px;line-height:1.6;color:#334155;">La foto de hermanos se saca aparte, en un día y lugar que todavía vamos a definir. Contanos si la quieren: si es que sí, te vamos a pedir un email y un WhatsApp para avisarte cuándo y dónde.</p>
      <p style="font-size:14px;line-height:1.6;color:#334155;"><strong>Tiene un costo aparte</strong> (no está incluida en el kit): se vende como las fotos de un evento. Cuando esté publicada, ustedes eligen si la compran.</p>
      <div style="margin:22px 0 8px 0;text-align:center;">
        <a href="${escapeHtml(datos.linkSi)}" style="display:inline-block;margin:6px;background-color:#fbbf24;color:#0f172a;text-decoration:none;font-weight:800;font-size:15px;padding:14px 22px;border-radius:12px;">&#9745; Sí, queremos la foto de hermanos</a>
        <a href="${escapeHtml(datos.linkNo)}" style="display:inline-block;margin:6px;background-color:#ffffff;color:#0f172a;text-decoration:none;font-weight:800;font-size:15px;padding:12px 22px;border-radius:12px;border:2px solid #cbd5e1;">&#9744; No, no la pedimos</a>
      </div>
      <p style="font-size:12px;line-height:1.6;color:#64748b;text-align:center;margin-top:4px;">Al tocar una opción se abre una página donde la confirmás. Si después cambiás de idea, podés volver a entrar desde este mismo email.</p>
      <div style="font-size:13px;color:#334155;line-height:1.6;border-top:1px solid #e2e8f0;padding-top:16px;margin-top:20px;">Perdón por la molestia y gracias por ayudarnos.<br>Si tenés alguna duda, respondé este email.</div>
    </div>
    <div style="background-color:#f1f5f9;padding:16px 24px;text-align:center;font-size:11px;color:#64748b;border-top:1px solid #e2e8f0;">Retrato Escolar · Pilar, Buenos Aires, Argentina · retratoescolar.com.ar</div>
  </div>
</body>
</html>`;
  const texto = `Hola, familia de ${unirNombresFotoHermanos(datos.chicos) || 'sus hijos'}:

En la inscripción (${datos.colegio || 'la institución'}) figuraba la opción de pedir una foto de hermanos juntos. Por un error de nuestro sistema, esa opción quedó marcada para todas las familias que anotaron hermanos, aunque no la hayan elegido.

La foto de hermanos se saca aparte, en un día y lugar que todavía vamos a definir. Tiene un costo aparte (no está incluida en el kit): se vende como las fotos de un evento y, cuando esté publicada, ustedes eligen si la compran.

Contanos si la quieren (si es que sí, te pedimos un email y un WhatsApp para avisarte cuándo y dónde):
Sí, queremos la foto de hermanos: ${datos.linkSi}
No, no la pedimos: ${datos.linkNo}

Al abrir el link confirmás la respuesta. Perdón por la molestia y gracias por ayudarnos.
Retrato Escolar`;
  return { asunto, html, texto };
}

// 08/10 (pedido de Pablo): la foto de hermanos no tiene día fijo. Quien responde que SÍ deja un email y
// un WhatsApp para que le avisen el día y el lugar.
function whatsappValidoFotoHermanos(valor: unknown): boolean {
  const texto = String(valor || '').trim();
  const digitos = texto.replace(/\D/g, '');
  return /^[+\d\s().-]+$/.test(texto) && digitos.length >= 8 && digitos.length <= 15;
}

const MENSAJE_LINK_FOTO_HERMANOS_INVALIDO = 'Este link no es válido. Abrilo de nuevo desde el email que te mandamos.';

rutas.get('/api/foto-hermanos/:llave', limitarFrecuencia('foto-hermanos-get', 60, 10 * 60 * 1000), async (req: Request, res: Response) => {
  res.setHeader('Cache-Control', 'no-store');
  try {
    const id = inscripcionDeLlaveFotoHermanos(req.params.llave);
    if (!id) return res.status(404).json({ success: false, error: MENSAJE_LINK_FOTO_HERMANOS_INVALIDO });
    const supabase = getServerSupabase();
    if (!supabase) return res.status(503).json({ success: false, error: 'Servicio no disponible. Probá de nuevo en un rato.' });
    const { data: fila, error } = await supabase
      .from('inscripciones')
      .select('id, estado, email, alumno_nombre, hermanos, colegio_nombre, solicita_foto_hermanos, foto_hermanos_confirmada_at, foto_hermanos_email, foto_hermanos_whatsapp')
      .eq('id', id)
      .maybeSingle();
    if (error) throw error;
    if (!fila || fila.estado === 'rechazado') return res.status(404).json({ success: false, error: MENSAJE_LINK_FOTO_HERMANOS_INVALIDO });
    if (!tieneHermanosFotoHermanos(fila)) return res.status(409).json({ success: false, error: 'En esta inscripción no hay hermanos anotados, así que no hace falta responder nada.' });
    return res.json({
      success: true,
      chicos: chicosDeInscripcionFotoHermanos(fila),
      colegio: fila.colegio_nombre || '',
      respuesta: fila.foto_hermanos_confirmada_at ? (fila.solicita_foto_hermanos ? 'si' : 'no') : null,
      // Para precargar los campos: el email con el que se inscribieron (ahí les llegó este link) o el que
      // dejaron antes. El WhatsApp de la inscripción no se muestra: sólo el que escribieron en esta página.
      contacto: {
        email: fila.foto_hermanos_email || fila.email || '',
        whatsapp: fila.foto_hermanos_whatsapp || '',
      },
    });
  } catch (err: any) {
    console.error('[Foto de hermanos] Error al leer la consulta:', err);
    return res.status(500).json({ success: false, error: 'No pudimos cargar la consulta. Probá de nuevo en un rato.' });
  }
});

rutas.post('/api/foto-hermanos/:llave', limitarFrecuencia('foto-hermanos-post', 20, 10 * 60 * 1000), async (req: Request, res: Response) => {
  res.setHeader('Cache-Control', 'no-store');
  try {
    const id = inscripcionDeLlaveFotoHermanos(req.params.llave);
    if (!id) return res.status(404).json({ success: false, error: MENSAJE_LINK_FOTO_HERMANOS_INVALIDO });
    const quiere = req.body?.quiere;
    if (typeof quiere !== 'boolean') return res.status(400).json({ success: false, error: 'Tildá una de las dos opciones.' });
    const emailAviso = String(req.body?.email ?? '').trim().toLowerCase().slice(0, 200);
    const whatsappAviso = String(req.body?.whatsapp ?? '').trim().slice(0, 30);
    if (quiere && !emailValidoFotoHermanos(emailAviso)) return res.status(400).json({ success: false, error: 'Escribí un email válido para avisarte el día y el lugar.' });
    if (quiere && !whatsappValidoFotoHermanos(whatsappAviso)) return res.status(400).json({ success: false, error: 'Escribí un WhatsApp válido (con código de área), para avisarte el día y el lugar.' });
    const supabase = getServerSupabase();
    if (!supabase) return res.status(503).json({ success: false, error: 'Servicio no disponible. Probá de nuevo en un rato.' });
    const { data: fila, error } = await supabase.from('inscripciones').select('id, estado, hermanos').eq('id', id).maybeSingle();
    if (error) throw error;
    if (!fila || fila.estado === 'rechazado') return res.status(404).json({ success: false, error: MENSAJE_LINK_FOTO_HERMANOS_INVALIDO });
    if (!tieneHermanosFotoHermanos(fila)) return res.status(409).json({ success: false, error: 'En esta inscripción no hay hermanos anotados.' });
    const { error: errorGuardar } = await supabase
      .from('inscripciones')
      .update({
        solicita_foto_hermanos: quiere,
        foto_hermanos_confirmada_at: new Date().toISOString(),
        foto_hermanos_email: quiere ? emailAviso : null,
        foto_hermanos_whatsapp: quiere ? whatsappAviso : null,
      })
      .eq('id', id);
    if (errorGuardar) throw errorGuardar;
    return res.json({ success: true, respuesta: quiere ? 'si' : 'no', ...(quiere ? { contacto: { email: emailAviso, whatsapp: whatsappAviso } } : {}) });
  } catch (err: any) {
    console.error('[Foto de hermanos] Error al guardar la respuesta:', err);
    return res.status(500).json({ success: false, error: 'No pudimos guardar tu respuesta. Probá de nuevo en un rato.' });
  }
});

// 14/10/2026 (pedido de Pablo: «agreguemos esa opción como producto a elegir en cualquier momento»): desde el
// portal, la familia ya identificada (llave de galería) se anota o se baja de la foto de hermanos cuando quiera.
// Guarda lo mismo que la página del email; la foto se paga después, al elegirla publicada (como un evento).
rutas.post('/api/familia/foto-hermanos', limitarFrecuencia('familia-foto-hermanos', 20, 10 * 60 * 1000), async (req: Request, res: Response) => {
  res.setHeader('Cache-Control', 'no-store');
  try {
    const quiere = req.body?.quiere;
    if (typeof quiere !== 'boolean') return res.status(400).json({ success: false, error: 'Elegí si querés la foto de hermanos.' });
    const emailAviso = String(req.body?.email ?? '').trim().toLowerCase().slice(0, 200);
    const whatsappAviso = String(req.body?.whatsapp ?? '').trim().slice(0, 30);
    if (quiere && !emailValidoFotoHermanos(emailAviso)) return res.status(400).json({ success: false, error: 'Escribí un email válido para avisarte el día.' });
    if (quiere && !whatsappValidoFotoHermanos(whatsappAviso)) return res.status(400).json({ success: false, error: 'Escribí un WhatsApp válido (con código de área), para avisarte el día.' });
    const supabase = getServerSupabase();
    if (!supabase) return res.status(503).json({ success: false, error: 'Servicio no disponible. Probá de nuevo en un rato.' });
    const id = String(req.body?.familia || '');
    if (!(await hijosDeFamiliaConAcceso(supabase, id, req.body?.acceso))) {
      return res.status(403).json({ success: false, requiereDatosTutor: true, error: 'Para anotarte volvé a ingresar con tu nombre y DNI.' });
    }
    const { data: fila, error } = await supabase.from('inscripciones').select('id, hermanos').eq('id', id).maybeSingle();
    if (error) throw error;
    if (!fila || !tieneHermanosFotoHermanos(fila)) return res.status(409).json({ success: false, error: 'En tu inscripción no hay hermanos anotados.' });
    const cambios = {
      solicita_foto_hermanos: quiere,
      foto_hermanos_confirmada_at: new Date().toISOString(),
      foto_hermanos_email: quiere ? emailAviso : null,
      foto_hermanos_whatsapp: quiere ? whatsappAviso : null,
    };
    const { error: errorGuardar } = await supabase.from('inscripciones').update(cambios).eq('id', id);
    if (errorGuardar) throw errorGuardar;
    return res.json({ success: true, quiere, fotoHermanosConfirmadaAt: cambios.foto_hermanos_confirmada_at });
  } catch (err: any) {
    console.error('[Foto de hermanos] Error al guardar desde el portal:', err);
    return res.status(500).json({ success: false, error: 'No pudimos guardar tu respuesta. Probá de nuevo en un rato.' });
  }
});

/** Filas con hermanos (sin las rechazadas) y su situación respecto de la consulta. */
async function filasConsultaFotoHermanos(supabase: SupabaseClient) {
  const filas = await traerTodasLasFilas<any>((desde, hasta) =>
    supabase
      .from('inscripciones')
      .select('id, estado, colegio_id, email, telefono_whatsapp, padre_nombre, alumno_nombre, alumno_apellido, grado, division, turno, hermanos, colegio_nombre, solicita_foto_hermanos, foto_hermanos_confirmada_at, foto_hermanos_consulta_at, foto_hermanos_email, foto_hermanos_whatsapp')
      .neq('estado', 'rechazado')
      .order('id')
      .range(desde, hasta)
  );
  return (filas || []).filter(tieneHermanosFotoHermanos);
}

/** Marcada por defecto (antes del arreglo del 08/10) y la familia todavía no confirmó. */
const sinConfirmarFotoHermanos = (f: any) => Boolean(f.solicita_foto_hermanos) && !f.foto_hermanos_confirmada_at;
const HORAS_ENTRE_RECORDATORIOS_FOTO_HERMANOS = 20;

function resumenConsultaFotoHermanos(filas: any[]) {
  const sinConfirmar = filas.filter(sinConfirmarFotoHermanos);
  const hace = Date.now() - HORAS_ENTRE_RECORDATORIOS_FOTO_HERMANOS * 60 * 60 * 1000;
  return {
    conHermanos: filas.length,
    confirmaronSi: filas.filter((f) => f.foto_hermanos_confirmada_at && f.solicita_foto_hermanos).length,
    confirmaronNo: filas.filter((f) => f.foto_hermanos_confirmada_at && !f.solicita_foto_hermanos).length,
    sinConfirmar: sinConfirmar.length,
    porEnviar: sinConfirmar.filter((f) => !f.foto_hermanos_consulta_at && emailValidoFotoHermanos(f.email)).length,
    enviadasSinRespuesta: sinConfirmar.filter((f) => f.foto_hermanos_consulta_at).length,
    paraRecordar: sinConfirmar.filter((f) => f.foto_hermanos_consulta_at && new Date(f.foto_hermanos_consulta_at).getTime() < hace && emailValidoFotoHermanos(f.email)).length,
    sinEmail: sinConfirmar.filter((f) => !emailValidoFotoHermanos(f.email)).length,
  };
}

rutas.get('/api/admin/foto-hermanos/consulta', requireAdminAuth, async (_req: Request, res: Response) => {
  try {
    const supabase = getServerSupabase();
    if (!supabase) return res.status(500).json({ success: false, error: 'Supabase no configurado' });
    return res.json({ success: true, ...resumenConsultaFotoHermanos(await filasConsultaFotoHermanos(supabase)) });
  } catch (err: any) {
    console.error('[Foto de hermanos] Error al armar el resumen:', err);
    return res.status(500).json({ success: false, error: 'No se pudo leer la consulta de foto de hermanos.' });
  }
});

// Lista de las familias que QUIEREN la foto de hermanos (confirmadas), con el contacto para avisarles
// el día y el lugar: el que dejaron en la consulta o, si eligieron en el formulario corregido, el de la
// inscripción.
rutas.get('/api/admin/foto-hermanos/lista', requireAdminAuth, async (_req: Request, res: Response) => {
  try {
    const supabase = getServerSupabase();
    if (!supabase) return res.status(500).json({ success: false, error: 'Supabase no configurado' });
    const filas = (await filasConsultaFotoHermanos(supabase))
      .filter((f) => f.solicita_foto_hermanos && f.foto_hermanos_confirmada_at)
      .sort((a, b) => String(a.padre_nombre || '').localeCompare(String(b.padre_nombre || ''), 'es'));
    const citas = await citasUltimaCitacion(supabase);
    return res.json({
      success: true,
      familias: filas.map((f) => ({
        tutor: f.padre_nombre || '',
        chicos: chicosFotoHermanos(f),
        email: f.foto_hermanos_email || f.email || '',
        whatsapp: f.foto_hermanos_whatsapp || f.telefono_whatsapp || '',
        contactoDeLaConsulta: Boolean(f.foto_hermanos_email || f.foto_hermanos_whatsapp),
        colegio: f.colegio_nombre || '',
        confirmo: f.foto_hermanos_confirmada_at,
        cita: citas[String(f.foto_hermanos_email || f.email || '').trim().toLowerCase()] || null,
      })),
    });
  } catch (err: any) {
    console.error('[Foto de hermanos] Error al armar la lista:', err);
    return res.status(500).json({ success: false, error: 'No se pudo armar la lista.' });
  }
});

const cursoFotoHermanos = (grado: unknown, division: unknown, turno: unknown) => [grado, division].filter(Boolean).join(' ') + (turno ? ` · ${turno}` : '');
/** «Nombre Apellido — 2° grado B · Tarde», uno por chico (el de la inscripción y sus hermanos). */
function chicosFotoHermanos(f: any): string[] {
  return [
    `${nombrePropioFotoHermanos(`${f.alumno_nombre || ''} ${f.alumno_apellido || ''}`)} — ${cursoFotoHermanos(f.grado, f.division, f.turno)}`,
    ...(f.hermanos || []).map((h: any) => `${nombrePropioFotoHermanos(`${h?.alumnoNombre || ''} ${h?.alumnoApellido || ''}`)} — ${cursoFotoHermanos(h?.grado, h?.division, h?.turno)}`),
  ];
}

// 26/10/2026 (Pablo: «me lo pide el colegio»): en el panel del colegio, las familias que confirmaron la foto de
// hermanos con el día y el horario asignados. Sólo nombres y cursos: sin emails ni teléfonos de las familias.
rutas.get('/api/colegio/foto-hermanos', requireColegioAuth, async (_req: Request, res: Response) => {
  try {
    const supabase = getServerSupabase();
    if (!supabase) return res.status(503).json({ success: false, error: 'Servicio no disponible.' });
    const colegioId = String(res.locals.colegioId);
    const filas = (await filasConsultaFotoHermanos(supabase)).filter((f) => f.solicita_foto_hermanos && f.foto_hermanos_confirmada_at && String(f.colegio_id) === colegioId);
    const citas = await citasUltimaCitacion(supabase);
    const familias = filas
      .map((f) => {
        const cita = citas[String(f.foto_hermanos_email || f.email || '').trim().toLowerCase()];
        return { tutor: String(f.padre_nombre || '').trim(), chicos: chicosFotoHermanos(f), dia: cita?.dia || null, hora: cita?.hora || null };
      })
      .sort((a, b) => `${a.dia || '9'} ${a.hora || ''}`.localeCompare(`${b.dia || '9'} ${b.hora || ''}`) || a.tutor.localeCompare(b.tutor, 'es'));
    res.setHeader('Cache-Control', 'private, no-store');
    return res.json({ success: true, familias });
  } catch (err: any) {
    console.error('[Foto de hermanos] Error en el panel del colegio:', err);
    return res.status(500).json({ success: false, error: 'No pudimos cargar la foto de hermanos. Probá de nuevo en unos segundos.' });
  }
});

// Manda la consulta (o el recordatorio, con `recordatorio: true`) a las familias marcadas por defecto
// que todavía no respondieron. De a un lote de Resend (hasta 100) por llamada: el panel repite
// mientras `restantes` > 0. Un recordatorio sale sólo si pasaron 20 h desde el envío anterior.
rutas.post('/api/admin/foto-hermanos/consulta/enviar', requireAdminAuth, async (req: Request, res: Response) => {
  try {
    const supabase = getServerSupabase();
    if (!supabase) return res.status(500).json({ success: false, error: 'Supabase no configurado' });
    const resend = getResendClient();
    if (!resend) return res.status(500).json({ success: false, error: 'RESEND_API_KEY no está configurada.' });
    const recordatorio = req.body?.recordatorio === true;
    const filas = await filasConsultaFotoHermanos(supabase);
    const hace = Date.now() - HORAS_ENTRE_RECORDATORIOS_FOTO_HERMANOS * 60 * 60 * 1000;
    const pendientes = filas.filter(
      (f) =>
        sinConfirmarFotoHermanos(f) &&
        emailValidoFotoHermanos(f.email) &&
        (recordatorio ? f.foto_hermanos_consulta_at && new Date(f.foto_hermanos_consulta_at).getTime() < hace : !f.foto_hermanos_consulta_at)
    );
    const TAMANO_LOTE = 100;
    const lote = pendientes.slice(0, TAMANO_LOTE);
    if (lote.length === 0) return res.json({ success: true, enviados: 0, errores: 0, restantes: 0, ...resumenConsultaFotoHermanos(filas) });

    const correos = lote.map((f) => {
      const linkSi = linkFotoHermanos(f.id, 'si');
      const linkNo = linkFotoHermanos(f.id, 'no');
      if (!linkSi || !linkNo) throw new Error('Falta ADMIN_SESSION_SECRET para firmar los links.');
      const correo = correoConsultaFotoHermanos({ chicos: chicosDeInscripcionFotoHermanos(f), colegio: f.colegio_nombre || '', linkSi, linkNo, recordatorio });
      return {
        from: process.env.RESEND_FROM_EMAIL || 'Retrato Escolar <fotos@retratoescolar.com.ar>',
        replyTo: resendReplyTo,
        to: [String(f.email).trim().toLowerCase()],
        subject: correo.asunto,
        html: correo.html,
        text: correo.texto,
      };
    });
    const dia = new Date().toLocaleDateString('en-CA', { timeZone: 'America/Argentina/Buenos_Aires' });
    const huella = crypto.createHash('sha256').update(lote.map((f) => f.id).join(',')).digest('hex');
    const resultado = await resend.batch.send(correos, {
      idempotencyKey: `foto-hermanos-${recordatorio ? `rec-${dia}-` : ''}${huella}`,
      batchValidation: 'permissive',
    });
    if (resultado.error) {
      console.error('[Foto de hermanos] Resend rechazó el lote:', resultado.error);
      return res.status(502).json({ success: false, error: `Resend no aceptó los correos: ${resultado.error.message || resultado.error.name || 'error desconocido'}` });
    }
    const rechazados = new Set<number>(((resultado.data as any)?.errors || []).map((e: any) => Number(e?.index)));
    const idsEnviados = lote.filter((_f, i) => !rechazados.has(i)).map((f) => f.id);
    if (rechazados.size > 0) console.error('[Foto de hermanos] Correos rechazados por Resend:', (resultado.data as any).errors);
    if (idsEnviados.length > 0) {
      const { error: errorMarcar } = await supabase.from('inscripciones').update({ foto_hermanos_consulta_at: new Date().toISOString() }).in('id', idsEnviados);
      if (errorMarcar) console.error('[Foto de hermanos] Se enviaron los correos pero no se pudo registrar el envío:', errorMarcar);
    }
    const filasDespues = await filasConsultaFotoHermanos(supabase);
    return res.json({
      success: true,
      enviados: idsEnviados.length,
      errores: rechazados.size,
      restantes: Math.max(0, pendientes.length - lote.length),
      ...resumenConsultaFotoHermanos(filasDespues),
    });
  } catch (err: any) {
    console.error('[Foto de hermanos] Error al enviar la consulta:', err);
    return res.status(500).json({ success: false, error: err?.message || 'No se pudo enviar la consulta.' });
  }
});

export { rutas as rutasFotoHermanos };
