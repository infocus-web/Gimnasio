// «Convocar» en «Faltantes solicitadas» (25/10/2026, pedido de Pablo): a las familias que pidieron que le saquen una
// foto faltante a su hijo/a se les manda un mail con el día, la hora y el lugar en que se saca. La grupal no se
// convoca (no se puede volver a sacar). Un mail por familia (email), aunque tenga varios chicos o varias fotos.
// Se manda con la API de lotes de Resend (hasta 100 por pedido, de a un lote, con pausa): no se pasa del límite.
// Queda anotado en cada pedido (convocatoria_*, convocada_at; migración 20261025140000). Se puede volver a convocar.
import crypto from 'crypto';
import express from 'express';
import type { Request, Response } from 'express';
import { requireAdminAuth } from '../nucleo/auth.js';
import { getResendClient, getServerSupabase, resendReplyTo } from '../nucleo/clientes.js';
import type { LugarPack } from '../nucleo/fotosFaltantes.js';
import { escapeHtml } from '../nucleo/utilidades.js';
import { NOMBRE_LUGAR_FALTANTE, TABLA_FALTANTES } from './faltantesPendientes.js';

const rutas = express.Router();
const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const DIA_RE = /^\d{4}-\d{2}-\d{2}$/;
const ZONA = 'America/Argentina/Buenos_Aires';

/** «sábado 07/11» a partir de «2026-11-07» (hora argentina). */
export function diaLegible(dia: string): string {
  const d = new Date(`${dia}T12:00:00-03:00`);
  return d.toLocaleDateString('es-AR', { weekday: 'long', day: '2-digit', month: '2-digit', timeZone: ZONA });
}

/** Hoy en Argentina como «AAAA-MM-DD». */
function hoyArgentina(): string {
  return new Date().toLocaleDateString('en-CA', { timeZone: ZONA });
}

export interface DatosConvocatoria {
  dia: string;
  hora: string;
  lugar: string;
  nota: string;
}

export function validarConvocatoria(cuerpo: any): { ok: true; datos: DatosConvocatoria; ids: string[] } | { ok: false; error: string } {
  const ids = Array.isArray(cuerpo?.ids) ? [...new Set(cuerpo.ids.filter((v: unknown): v is string => typeof v === 'string' && UUID_RE.test(v)))] as string[] : [];
  const dia = String(cuerpo?.dia || '').trim();
  const hora = String(cuerpo?.hora || '').trim();
  const lugar = String(cuerpo?.lugar || '').trim();
  const nota = String(cuerpo?.nota || '').trim();
  if (ids.length === 0) return { ok: false, error: 'Elegí al menos un pedido para convocar.' };
  if (ids.length > 300) return { ok: false, error: 'Máximo 300 pedidos por convocatoria.' };
  if (!DIA_RE.test(dia) || Number.isNaN(new Date(`${dia}T12:00:00-03:00`).getTime())) return { ok: false, error: 'Elegí el día.' };
  if (dia < hoyArgentina()) return { ok: false, error: 'El día ya pasó: elegí una fecha de hoy en adelante.' };
  if (!hora || hora.length > 40) return { ok: false, error: 'Indicá la hora.' };
  if (lugar.length < 2 || lugar.length > 200) return { ok: false, error: 'Indicá el lugar.' };
  if (nota.length > 500) return { ok: false, error: 'La nota puede tener hasta 500 caracteres.' };
  return { ok: true, ids, datos: { dia, hora, lugar, nota } };
}

export function correoConvocatoria(familia: { email: string; tutor: string; pedidos: any[] }, datos: DatosConvocatoria) {
  const alumnos = [...new Set(familia.pedidos.map((p) => String(p.alumno_nombre || '').trim()).filter(Boolean))];
  const items = familia.pedidos
    .map((p) => `<li>${escapeHtml(NOMBRE_LUGAR_FALTANTE[p.lugar as LugarPack] || 'la foto')} de <strong>${escapeHtml(p.alumno_nombre)}</strong> (${escapeHtml(`${p.grado || ''} "${p.division || ''}"${p.turno ? ` · Turno ${p.turno}` : ''}`)})</li>`)
    .join('');
  const fila = (etiqueta: string, valor: string) =>
    `<tr><td style="padding:6px 12px 6px 0;color:#64748b;font-size:13px;white-space:nowrap">${etiqueta}</td><td style="padding:6px 0;font-weight:700;font-size:15px">${valor}</td></tr>`;
  return {
    from: process.env.RESEND_FROM_EMAIL || 'Retrato Escolar <fotos@retratoescolar.com.ar>',
    replyTo: resendReplyTo,
    to: [familia.email],
    subject: `Día para la foto de ${alumnos.join(' y ') || 'tu hijo/a'}: ${diaLegible(datos.dia)}`,
    html: `<!doctype html><html lang="es"><body style="margin:0;background:#f8fafc;font-family:Arial,sans-serif;color:#1e293b"><div style="max-width:600px;margin:24px auto;background:#fff;border:1px solid #e2e8f0;border-radius:16px;overflow:hidden"><div style="background:#0f172a;padding:28px 24px;text-align:center;border-bottom:3px solid #f59e0b"><div style="color:#f59e0b;font-size:11px;font-weight:800;letter-spacing:2px">RETRATO ESCOLAR</div><h1 style="color:#fff;font-size:22px;margin:8px 0 0">Te esperamos para la foto</h1></div><div style="padding:28px 24px;line-height:1.6"><p>Hola <strong>${escapeHtml(familia.tutor || 'familia')}</strong>,</p><p>Vamos a sacar la foto que nos pediste:</p><ul style="margin:0 0 16px;padding-left:20px">${items}</ul><div style="background:#fffbeb;border:1px solid #fcd34d;border-radius:12px;padding:14px 18px;margin:0 0 16px"><table role="presentation" style="border-collapse:collapse">${fila('Día', escapeHtml(diaLegible(datos.dia)))}${fila('Hora', escapeHtml(datos.hora))}${fila('Lugar', escapeHtml(datos.lugar))}</table></div>${datos.nota ? `<p style="white-space:pre-line">${escapeHtml(datos.nota)}</p>` : ''}<p>Cuando la publiquemos te avisamos por email para que la elijas y cierres el kit. Hasta entonces, el kit queda en espera.</p><p style="font-size:13px;color:#475569">Si no pueden venir ese día, respondé este email.</p><p>Saludos,<br>Equipo de Retrato Escolar</p></div></div></body></html>`,
  };
}

rutas.post('/api/admin/fotos-faltantes/convocar', requireAdminAuth, async (req: Request, res: Response) => {
  try {
    const validacion = validarConvocatoria(req.body);
    if (validacion.ok === false) return res.status(400).json({ success: false, error: validacion.error });
    const { ids, datos } = validacion;
    const supabase = getServerSupabase();
    if (!supabase) return res.status(500).json({ success: false, error: 'Supabase no configurado en el servidor' });
    const resend = getResendClient();
    if (!resend) return res.status(503).json({ success: false, error: 'El envío de emails no está configurado (RESEND_API_KEY).' });

    const filas: any[] = [];
    for (let i = 0; i < ids.length; i += 150) {
      const { data, error } = await supabase
        .from(TABLA_FALTANTES)
        .select('id, alumno_nombre, grado, division, turno, lugar, estado, tutor_nombre, contacto_email')
        .in('id', ids.slice(i, i + 150));
      if (error) throw error;
      filas.push(...(data || []));
    }
    const convocables = filas.filter((f) => f.estado === 'pendiente' && f.lugar !== 'grupal');
    const sinEmail = convocables.filter((f) => !EMAIL_RE.test(String(f.contacto_email || '').trim())).map((f) => f.alumno_nombre);
    const familias = new Map<string, { email: string; tutor: string; pedidos: any[] }>();
    for (const f of convocables) {
      const email = String(f.contacto_email || '').trim().toLowerCase();
      if (!EMAIL_RE.test(email)) continue;
      const fam = familias.get(email) || { email, tutor: f.tutor_nombre || '', pedidos: [] };
      fam.pedidos.push(f);
      familias.set(email, fam);
    }
    const lista = [...familias.values()];
    const marca = `${datos.dia}|${datos.hora}|${datos.lugar}|${datos.nota}`;
    let familiasConvocadas = 0;
    let pedidosConvocados = 0;
    const fallidos: string[] = [];
    for (let i = 0; i < lista.length; i += 100) {
      const lote = lista.slice(i, i + 100);
      try {
        const clave = crypto.createHash('sha256').update(`${marca}|${lote.flatMap((f) => f.pedidos.map((p: any) => p.id)).sort().join(',')}`).digest('hex');
        const r = await resend.batch.send(lote.map((f) => correoConvocatoria(f, datos)), { idempotencyKey: `convocatoria-faltantes-${clave}`, batchValidation: 'permissive' });
        if (r.error) {
          console.error('[faltantes] Falló un lote de convocatorias:', r.error);
          fallidos.push(...lote.flatMap((f) => f.pedidos.map((p: any) => p.alumno_nombre)));
          continue;
        }
        const rechazados: Array<{ index?: number }> = (r.data as any)?.errors || [];
        const sinIndice = rechazados.some((e) => !Number.isInteger(e?.index));
        const indices = new Set(rechazados.map((e) => Number(e?.index)));
        const salieron = sinIndice ? [] : lote.filter((_, j) => !indices.has(j));
        for (const f of lote) if (sinIndice || indices.has(lote.indexOf(f))) fallidos.push(...f.pedidos.map((p: any) => p.alumno_nombre));
        const idsSalieron = salieron.flatMap((f) => f.pedidos.map((p: any) => p.id));
        if (idsSalieron.length > 0) {
          const { error } = await supabase
            .from(TABLA_FALTANTES)
            .update({ convocatoria_dia: datos.dia, convocatoria_hora: datos.hora, convocatoria_lugar: datos.lugar, convocatoria_nota: datos.nota || null, convocada_at: new Date().toISOString() })
            .in('id', idsSalieron);
          if (error) console.error('[faltantes] Convocatoria enviada pero no se pudo anotar:', error.message);
        }
        familiasConvocadas += salieron.length;
        pedidosConvocados += idsSalieron.length;
      } catch (errLote) {
        console.error('[faltantes] Error de red enviando convocatorias:', errLote);
        fallidos.push(...lote.flatMap((f) => f.pedidos.map((p: any) => p.alumno_nombre)));
      }
      if (i + 100 < lista.length) await new Promise((ok) => setTimeout(ok, 600));
    }
    return res.json({
      success: true,
      familiasConvocadas,
      pedidosConvocados,
      omitidos: filas.length - convocables.length,
      sinEmail,
      fallidos,
    });
  } catch (err: any) {
    console.error('[faltantes] Error al convocar:', err);
    return res.status(500).json({ success: false, error: 'No se pudo mandar la convocatoria. Intentá de nuevo.' });
  }
});

export { rutas as rutasConvocatoriaFaltantes };
