// "Solicitar mi código" de las familias y su bandeja en el panel (división de server.ts, etapa 5,
// 10/10/2026). El código es el mismo que estaba en la sección "4D. SOLICITUDES DE CÓDIGO DE CURSO" de
// server.ts: sólo se movió de lugar.
import express from 'express';
import type { Request, Response } from 'express';
import { requireAdminAuth } from '../nucleo/auth.js';
import { getResendClient, getServerSupabase } from '../nucleo/clientes.js';
import { hayCupoReenvioCodigo, limitarFrecuencia } from '../nucleo/limites.js';
import { escapeHtml, traerTodasLasFilas } from '../nucleo/utilidades.js';
import { dniParcialServidor, enviarCorreoCodigoAcceso, inscripcionSinConfirmar, linkConfirmacionAcceso } from './accesoFamilias.js';
import { claveEnvioValida } from './consultasAdmin.js';
import { alumnosDeInscripcion, claveCodigoAcceso } from './inscripcionesAdmin.js';

const rutas = express.Router();

// ==============================================================================
// 4D. SOLICITUDES DE CÓDIGO DE CURSO (reemplaza el botón "Solicitar por WhatsApp")
// Una familia que no encuentra su código deja sus datos acá en vez de escribirle
// directo al fotógrafo por WhatsApp; queda listado en el panel admin para que lo
// atienda cuando pueda, sin flood de mensajes individuales.
// ==============================================================================

// Envío público: cualquier familia puede dejar su solicitud, sin login
const ultimoReenvioCodigoPorInscripcion = new Map<string, number>();

rutas.post('/api/solicitudes-codigo', limitarFrecuencia('solicitudes-codigo', 60, 15 * 60 * 1000), async (req: Request, res: Response) => {
  try {
    // 27/10: el resto de los datos del formulario (alumno, curso) ya no se guardan: ver el bloqueo de abajo.
    const { nombreSolicitante, contacto, colegioId: colegioIdRecibido } = req.body || {};
    // Auditoría 2026-09-27: colegio con formato válido (antes un valor raro terminaba en un error 500).
    const colegioId = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(String(colegioIdRecibido || ''))
      ? String(colegioIdRecibido)
      : null;

    const nombre = String(nombreSolicitante || '').trim().slice(0, 120);
    const contactoLimpio = String(contacto || '').trim().slice(0, 160);
    if (!nombre || !contactoLimpio) {
      return res.status(400).json({ success: false, error: 'Faltan tu nombre y el email con el que te registraste' });
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(contactoLimpio)) {
      return res.status(400).json({ success: false, error: 'Ingresá un email válido' });
    }

    const supabase = getServerSupabase();
    if (!supabase) {
      return res.status(500).json({ success: false, error: 'Supabase no configurado en el servidor' });
    }

    // Si escribió el mismo email con el que se registró, el código sólo se reenvía a esa
    // dirección. No se devuelve en la respuesta pública ni se revela si pertenece a otra persona.
    // Auditoría 11/10 (FAM-3): PostgREST toma `*` como `%` y no se puede escapar: un email con `*`, `%` o `\`
    // no busca nada (queda como solicitud para el panel, con la misma respuesta). `_` se sigue escapando.
    if (!/[*%\\]/.test(contactoLimpio)) {
      // Auditoría 2026-09-22 (bug real encontrado en auditoría de código, MEDIO): la regex de
      // arriba valida "forma de email" pero no excluye los comodines de ilike ('%' y '_'), así
      // que un input como "%@gmail.com" la pasaba igual y convertía este "match exacto" en un
      // patrón que matcheaba CUALQUIER inscripción aceptada con ese dominio — rompiendo la
      // garantía de coincidencia exacta que promete el comentario de arriba (vector de spam:
      // reenviar el código de una familia al azar a partir de su dominio de email). Se escapan
      // los caracteres especiales de ilike antes de usarlos para que sólo pueda matchear el
      // email exacto (case-insensitive), nunca un patrón.
      const emailParaIlike = contactoLimpio.replace(/[%_\\]/g, (c) => `\\${c}`);
      let inscripcionesQuery = supabase
        .from('inscripciones')
        .select('id,estado,email,padre_nombre,padre_dni,colegio_id,colegio_nombre,codigo_asignado,alumno_nombre,alumno_apellido,grado,division,turno,hermanos,solicita_foto_hermanos,acceso_confirmado_at')
        .ilike('email', emailParaIlike)
        .order('updated_at', { ascending: false })
        .limit(20);

      const { data: coincidencias, error: errorBusqueda } = await inscripcionesQuery;
      if (errorBusqueda) throw errorBusqueda;
      // 27/10 (pedido de Pablo): se busca en todos los colegios y se prefiere el elegido, así un
      // colegio mal elegido en el formulario no hace creer a la familia que no está inscripta.
      const aprobadas = (coincidencias || []).filter((i: any) => i.estado === 'aceptado');
      const inscripcion = aprobadas.find((i: any) => colegioId && i.colegio_id === colegioId) || aprobadas[0];
      // Inscripta pero todavía sin aprobar: el código le llega solo al aprobarse. No se guarda pedido.
      if (!inscripcion && (coincidencias || []).length > 0) return res.json(RESPUESTA_INSCRIPCION_PENDIENTE);
      if (inscripcion?.codigo_asignado && inscripcion.email) {
        // Auditoría 2026-09-27: como mucho un reenvío cada 10 minutos por familia (evita usar el
        // formulario para llenarle la casilla de correos a alguien).
        const ahora = Date.now();
        const ultimo = ultimoReenvioCodigoPorInscripcion.get(inscripcion.id) || 0;
        // Auditoría 03/10 noche (H8): la respuesta es la MISMA exista o no el email (antes confirmaba
        // a cualquiera si un email estaba inscripto en el colegio).
        const respuestaReenvio = RESPUESTA_SOLICITUD_CODIGO;
        if (ahora - ultimo < 10 * 60 * 1000) return res.json(respuestaReenvio);
        // Mismo límite, pero compartido entre todas las instancias del servidor.
        if (!(await hayCupoReenvioCodigo(String(inscripcion.id)))) return res.json(respuestaReenvio);
        ultimoReenvioCodigoPorInscripcion.set(inscripcion.id, ahora);
        if (ultimoReenvioCodigoPorInscripcion.size > 5000) ultimoReenvioCodigoPorInscripcion.clear();
        const alumnos = [
          { nombre: inscripcion.alumno_nombre, apellido: inscripcion.alumno_apellido || '', grado: inscripcion.grado, division: inscripcion.division, turno: inscripcion.turno },
          ...(Array.isArray(inscripcion.hermanos) ? inscripcion.hermanos : []).map((h: any) => ({
            nombre: h.alumnoNombre || h.alumno_nombre,
            apellido: h.alumnoApellido || h.alumno_apellido || '',
            grado: h.grado,
            division: h.division,
            turno: h.turno,
          })),
        ];
        const resultadoEmail = await enviarCorreoCodigoAcceso({
          to: inscripcion.email,
          padreNombre: inscripcion.padre_nombre,
          colegioNombre: inscripcion.colegio_nombre,
          codigo: inscripcion.codigo_asignado,
          alumnos,
          solicitaFotoHermanos: Boolean(inscripcion.solicita_foto_hermanos),
          // Revisión 03/10 noche (C1): si todavía no confirmó, el reenvío lleva el botón.
          ...(inscripcionSinConfirmar(inscripcion) && linkConfirmacionAcceso(inscripcion.id)
            ? { confirmacion: { link: linkConfirmacionAcceso(inscripcion.id) as string, tutor: String(inscripcion.padre_nombre || '').trim(), dniParcial: dniParcialServidor(inscripcion.padre_dni) } }
            : {}),
        });
        if (!resultadoEmail.success) {
          ultimoReenvioCodigoPorInscripcion.delete(inscripcion.id);
          throw new Error(resultadoEmail.error || 'No se pudo reenviar el código por email');
        }

        return res.json(respuestaReenvio);
      }
      // Aprobada pero sin código asignado todavía: le llega cuando se le asigne.
      if (inscripcion) return res.json(RESPUESTA_INSCRIPCION_PENDIENTE);
    }

    // 27/10 (pedido de Pablo): sin inscripción con ese email ya no se guarda la solicitud en el panel
    // (casi todas eran familias que todavía no se habían inscripto o que se inscribieron después).
    // Se le avisa que se inscriba: al aprobarse la inscripción, el código le llega por email.
    return res.json(RESPUESTA_SIN_INSCRIPCION);
  } catch (err: any) {
    console.error('Error al guardar solicitud de código:', err);
    return res.status(500).json({ success: false, error: err?.message || 'Error al enviar la solicitud' });
  }
});

// 27/10: con el bloqueo, la respuesta ya distingue si el email está inscripto (antes era única, H8).
// Lo decidió Pablo: es más importante que la familia sepa que tiene que inscribirse.
const RESPUESTA_SOLICITUD_CODIGO = {
  success: true,
  envioAutomatico: true,
  mensaje: 'Te mandamos el código al email con el que te inscribiste. Si no lo ves en unos minutos, revisá también la carpeta de Spam o Correo no deseado.',
};

const RESPUESTA_INSCRIPCION_PENDIENTE = {
  success: true,
  envioAutomatico: false,
  bloqueado: true,
  motivo: 'pendiente',
  mensaje: 'Tu inscripción todavía está en revisión. Cuando se apruebe vas a recibir el código en tu correo (revisá también Spam o Correo no deseado).',
};

const RESPUESTA_SIN_INSCRIPCION = {
  success: true,
  envioAutomatico: false,
  bloqueado: true,
  motivo: 'sin_inscripcion',
  mensaje: 'Aún no te inscribiste con ese email. Inscribite gratis y, cuando se apruebe tu inscripción, vas a recibir el código en tu correo.',
};

// Listado para el panel admin (por defecto solo las pendientes, o todas con ?estado=todas)
rutas.get('/api/admin/solicitudes-codigo', requireAdminAuth, async (req: Request, res: Response) => {
  try {
    const supabase = getServerSupabase();
    if (!supabase) {
      return res.status(500).json({ success: false, error: 'Supabase no configurado en el servidor' });
    }
    const estado = req.query.estado as string | undefined;
    const data = await traerTodasLasFilas((desde, hasta) => {
      let builder = supabase.from('solicitudes_codigo').select('*').order('created_at', { ascending: false }).order('id');
      if (estado && estado !== 'todas') {
        builder = builder.eq('estado', estado);
      }
      return builder.range(desde, hasta);
    });
    // 25/10 (caso Marlen Bertone): el email pudo corregirse en la inscripción DESPUÉS del pedido.
    // Se marca si hoy coincide con una inscripción aprobada, para no invitarla a inscribirse de nuevo.
    const variantes = [...new Set((data || []).flatMap((s: any) => [String(s.contacto || '').trim(), String(s.contacto || '').trim().toLowerCase()]).filter(Boolean))];
    const aprobados = new Set<string>();
    for (let i = 0; i < variantes.length; i += 200) {
      const { data: filas } = await supabase.from('inscripciones').select('email').eq('estado', 'aceptado').in('email', variantes.slice(i, i + 200));
      (filas || []).forEach((f: any) => aprobados.add(String(f.email || '').trim().toLowerCase()));
    }
    const solicitudes = (data || []).map((s: any) => ({ ...s, inscripcion_aprobada: aprobados.has(String(s.contacto || '').trim().toLowerCase()) }));
    return res.json({ success: true, solicitudes });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err?.message || 'Error al obtener las solicitudes' });
  }
});

// Marca una solicitud como atendida (ya se le envió el código por fuera del panel)
rutas.post('/api/admin/solicitudes-codigo/:id/atender', requireAdminAuth, async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const supabase = getServerSupabase();
    if (!supabase) {
      return res.status(500).json({ success: false, error: 'Supabase no configurado en el servidor' });
    }
    const { data, error } = await supabase
      .from('solicitudes_codigo')
      .update({ estado: 'atendido', updated_at: new Date().toISOString() })
      .eq('id', id)
      .select();
    if (error) throw error;
    return res.json({ success: true, solicitud: data?.[0] });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err?.message || 'Error al actualizar la solicitud' });
  }
});

rutas.delete('/api/admin/solicitudes-codigo/:id', requireAdminAuth, async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const supabase = getServerSupabase();
    if (!supabase) {
      return res.status(500).json({ success: false, error: 'Supabase no configurado en el servidor' });
    }
    const { error } = await supabase.from('solicitudes_codigo').delete().eq('id', id);
    if (error) throw error;
    return res.json({ success: true });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err?.message || 'Error al eliminar la solicitud' });
  }
});

// Auditoría 2026-09-16 (pedido de Pablo): el cartel de esta pestaña ya decía "Respondeles por
// WhatsApp o email", pero "por email" quería decir abrir su propio cliente de correo a mano —
// no había forma de contestar desde el sistema, con la misma cuenta oficial que ya usa para todo
// lo demás (Mercado Pago, avisos de fotos listas, etc.). Este endpoint replica el patrón que ya
// existe para "Consultas de familias" (mismo remitente, mismo servicio de Resend), pero más
// simple: acá no hay un hilo de conversación guardado (no existe una tabla de mensajes para
// solicitudes, a diferencia de consultas_familias_mensajes) — es un email suelto de una vía. Al
// enviarse con éxito, se marca la solicitud como atendida automáticamente (si ya se le contestó,
// no tiene sentido que siga apareciendo en "Pendientes").
//
// Auditoría 2026-09-16, segunda vuelta (pedido de Pablo: "no puede ser automático?"): cuando la
// familia sí dejó colegio+grado+turno+división al pedir el código (el panel se lo busca solo con
// `asegurarCodigoSeccionAdmin`/`codigos_seccion` antes de abrir este cuadro), el frontend manda
// `codigo` acá y el email sale con la misma caja destacada que ya usa el aviso de "inscripción
// validada" (ver `enviarCorreoCodigoAcceso` más abajo) en vez de un párrafo de texto libre — así
// Pablo no tiene que escribir ni tipear el código a mano, solo revisar y apretar enviar. `mensaje`
// pasa a ser opcional en ese caso (una aclaración extra, si quiere agregar algo); sigue siendo
// obligatorio cuando no hay código (la familia no dejó grado/turno/división, o esa sección
// todavía no tiene código asignado) y Pablo responde a mano como antes.
rutas.post('/api/admin/solicitudes-codigo/:id/responder', requireAdminAuth, async (req: Request, res: Response) => {
  try {
    const mensaje = String(req.body?.mensaje || '').trim();
    const codigo = String(req.body?.codigo || '').trim().toUpperCase();
    if (!codigo && (mensaje.length < 2 || mensaje.length > 5000)) {
      return res.status(400).json({ success: false, error: 'La respuesta debe tener entre 2 y 5000 caracteres.' });
    }
    if (mensaje.length > 5000) {
      return res.status(400).json({ success: false, error: 'La aclaración no puede superar los 5000 caracteres.' });
    }

    const supabase = getServerSupabase();
    if (!supabase) return res.status(500).json({ success: false, error: 'Supabase no configurado.' });
    const { data: solicitud, error } = await supabase
      .from('solicitudes_codigo')
      .select('id,nombre_solicitante,contacto,estado')
      .eq('id', req.params.id)
      .single();
    if (error || !solicitud) return res.status(404).json({ success: false, error: 'No encontramos la solicitud.' });
    if (!solicitud.contacto || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(solicitud.contacto)) {
      return res.status(400).json({ success: false, error: 'Esta solicitud no tiene un email válido cargado.' });
    }

    const resend = getResendClient();
    if (!resend) return res.status(503).json({ success: false, error: 'El servicio de email no está configurado.' });
    const nombreDestinatario = escapeHtml(solicitud.nombre_solicitante || 'Familia');
    const htmlContent = codigo
      ? `<!DOCTYPE html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>Tu Código de Acceso - Retrato Escolar</title></head><body style="margin:0;padding:0;background-color:#f8fafc;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Helvetica,Arial,sans-serif;color:#1e293b;"><div style="max-width:600px;margin:24px auto;background-color:#ffffff;border-radius:16px;border:1px solid #e2e8f0;overflow:hidden;box-shadow:0 4px 6px -1px rgba(0,0,0,0.05);"><div style="background-color:#0f172a;padding:32px 24px;text-align:center;border-bottom:3px solid #f59e0b;"><div style="font-size:11px;font-weight:800;letter-spacing:2px;color:#f59e0b;text-transform:uppercase;margin-bottom:6px;">RETRATO ESCOLAR • EDICIÓN 2026</div><h1 style="color:#ffffff;margin:0;font-size:22px;font-weight:800;letter-spacing:-0.5px;">Encontramos tu Código de Acceso</h1></div><div style="padding:28px 24px;"><p style="font-size:15px;line-height:1.6;margin-top:0;">Hola <strong>${nombreDestinatario}</strong>,</p><p style="font-size:14px;line-height:1.6;color:#334155;">Nos pediste una mano para encontrar tu Código de Acceso — acá lo tenés:</p><div style="margin:24px 0;text-align:center;background-color:#fffbeb;border:1px solid #fde68a;border-radius:12px;padding:18px;"><div style="font-size:11px;font-weight:800;text-transform:uppercase;letter-spacing:1px;color:#92400e;margin-bottom:6px;">Tu Código de Acceso</div><div style="font-size:26px;font-weight:800;color:#0f172a;font-family:monospace;letter-spacing:2px;">${escapeHtml(codigo)}</div></div>${mensaje ? `<div style="white-space:pre-wrap;line-height:1.6;font-size:14px;color:#334155;margin-bottom:16px;">${escapeHtml(mensaje)}</div>` : ''}<p style="font-size:13px;line-height:1.6;color:#334155;">Con este código podés ingresar a <strong>retratoescolar.com.ar</strong>, ver la galería y elegir tus fotos.</p><div style="font-size:12px;color:#64748b;line-height:1.6;border-top:1px solid #e2e8f0;padding-top:16px;margin-top:16px;">Podés responder directamente a este correo si necesitás algo más.</div></div><div style="background-color:#f1f5f9;padding:18px 24px;text-align:center;font-size:11px;color:#64748b;border-top:1px solid #e2e8f0;">© 2026 Retrato Escolar • Fotografía Escolar Profesional<br><a href="https://retratoescolar.com.ar" style="color:#d97706;text-decoration:none;font-weight:600;">retratoescolar.com.ar</a></div></div></body></html>`
      : `<div style="font-family:Arial,sans-serif;max-width:640px;margin:auto;color:#0f172a"><p>Hola ${nombreDestinatario},</p><div style="white-space:pre-wrap;line-height:1.6">${escapeHtml(mensaje)}</div><p style="margin-top:24px">Saludos,<br><strong>Retrato Escolar</strong></p><hr style="margin:24px 0;border:0;border-top:1px solid #e2e8f0"><p style="font-size:12px;color:#64748b">Podés responder directamente a este correo si necesitás algo más.</p></div>`;
    // 14/10/2026 (auditoría): con la `clave` del panel (una por texto a enviar), un reintento tras un corte de
    // red no le manda dos veces el email a la familia (Resend descarta el segundo en 24 h).
    const clave = claveEnvioValida(req.body?.clave);
    const resultado = await resend.emails.send({
      from: process.env.RESEND_FROM_EMAIL || 'Retrato Escolar <fotos@retratoescolar.com.ar>',
      to: [solicitud.contacto],
      subject: 'Retrato Escolar: tu código de acceso', // el código va sólo en el cuerpo (auditoría 28/9: se veía en la notificación del celular)
      html: htmlContent,
    }, clave ? { idempotencyKey: `respuesta-solicitud-${solicitud.id}-${clave}` } : undefined);
    if (resultado.error) throw resultado.error;

    if (solicitud.estado !== 'atendido') {
      const { error: updateError } = await supabase
        .from('solicitudes_codigo')
        .update({ estado: 'atendido', updated_at: new Date().toISOString() })
        .eq('id', solicitud.id);
      if (updateError) console.error('[Solicitudes código] La respuesta se envió, pero no se marcó como atendida:', updateError);
    }
    return res.json({ success: true });
  } catch (err: any) {
    console.error('[Solicitudes código] Error al responder:', err);
    return res.status(500).json({ success: false, error: 'No pudimos enviar la respuesta. Intentá nuevamente.' });
  }
});

// 28/10/2026 (pedido de Pablo: «¿debo responder a cada uno y buscar el código a mano?»): si el email de la
// solicitud HOY coincide con una inscripción aprobada con código, el panel le reenvía con un clic el MISMO
// email de «Reenviar Email» de Inscriptos (código + alumnos vinculados) y marca atendidas la solicitud y sus
// repetidas del mismo email. Si no hay inscripción aprobada, no manda nada (409): ahí sigue «Responder».
rutas.post('/api/admin/solicitudes-codigo/:id/reenviar-codigo', requireAdminAuth, async (req: Request, res: Response) => {
  try {
    const supabase = getServerSupabase();
    if (!supabase) return res.status(500).json({ success: false, error: 'Supabase no configurado.' });
    const { data: solicitud, error } = await supabase
      .from('solicitudes_codigo')
      .select('id,contacto,colegio_id,estado')
      .eq('id', req.params.id)
      .single();
    if (error || !solicitud) return res.status(404).json({ success: false, error: 'No encontramos la solicitud.' });
    const email = String(solicitud.contacto || '').trim();
    // Mismo criterio que el portal: coincidencia exacta (sin comodines), sin distinguir mayúsculas.
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || /[*%\\]/.test(email)) {
      return res.status(400).json({ success: false, error: 'Esta solicitud no tiene un email válido cargado.' });
    }
    const { data: coincidencias, error: errBusqueda } = await supabase
      .from('inscripciones')
      .select('*')
      .ilike('email', email.replace(/[%_\\]/g, (c) => `\\${c}`))
      .eq('estado', 'aceptado')
      .order('updated_at', { ascending: false })
      .limit(20);
    if (errBusqueda) throw errBusqueda;
    const conCodigo = (coincidencias || []).filter((i: any) => i.codigo_asignado && i.email);
    const inscripcion = conCodigo.find((i: any) => solicitud.colegio_id && i.colegio_id === solicitud.colegio_id) || conCodigo[0];
    if (!inscripcion) {
      return res.status(409).json({ success: false, error: 'Ese email ya no tiene una inscripción aprobada con código. Respondele con «Responder».' });
    }

    const link = inscripcionSinConfirmar(inscripcion) ? linkConfirmacionAcceso(inscripcion.id) : null;
    const resultado = await enviarCorreoCodigoAcceso({
      to: inscripcion.email,
      padreNombre: inscripcion.padre_nombre,
      colegioNombre: inscripcion.colegio_nombre,
      codigo: inscripcion.codigo_asignado,
      alumnos: alumnosDeInscripcion(inscripcion),
      solicitaFotoHermanos: Boolean(inscripcion.solicita_foto_hermanos),
      ...(link ? { confirmacion: { link, tutor: String(inscripcion.padre_nombre || '').trim(), dniParcial: dniParcialServidor(inscripcion.padre_dni) } } : {}),
      // Misma clave que el reenvío de Inscriptos: un doble clic (o el reenvío desde las dos pestañas) en 2 min sale una sola vez.
      idempotencyKey: claveCodigoAcceso(String(inscripcion.id), String(inscripcion.codigo_asignado), true),
    });
    if (!resultado.success) return res.status(502).json({ success: false, error: resultado.error || 'No se pudo enviar el email.' });

    // Se cierran también las repetidas pendientes del mismo email (p. ej. la familia lo pidió 3 veces).
    const { data: pendientes } = await supabase.from('solicitudes_codigo').select('id,contacto').eq('estado', 'pendiente');
    const ids = new Set<string>([String(solicitud.id)]);
    (pendientes || []).forEach((s: any) => { if (String(s.contacto || '').trim().toLowerCase() === email.toLowerCase()) ids.add(String(s.id)); });
    const { error: errUpd } = await supabase
      .from('solicitudes_codigo')
      .update({ estado: 'atendido', updated_at: new Date().toISOString() })
      .in('id', [...ids]);
    if (errUpd) console.error('[Solicitudes código] El código se reenvió, pero no se marcaron como atendidas:', errUpd);
    return res.json({ success: true, atendidas: errUpd ? [] : [...ids], email: inscripcion.email, colegioNombre: inscripcion.colegio_nombre || '' });
  } catch (err: any) {
    console.error('[Solicitudes código] Error al reenviar el código:', err);
    return res.status(500).json({ success: false, error: 'No pudimos reenviar el código. Intentá nuevamente.' });
  }
});

export { rutas as rutasSolicitudesCodigo };
