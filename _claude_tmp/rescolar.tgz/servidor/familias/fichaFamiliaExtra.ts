// 26/10/2026 (Pablo: «no me sirve una IA que responda tan mal y genéricamente»). Lo que le faltaba a la ficha de la
// familia que lee la IA de consultas (armarFichaFamilia en consultas.ts), y que la hacía inventar:
// - la foto de hermanos de la familia: si la pidió, si confirmó y el día y horario que le tocó (caso Colomba: «no
//   figura ninguna convocatoria», y estaba citado el 29/10);
// - qué clases de fotos hay publicadas en el curso de cada chico (caso Arbelo: 1° año C no tiene tercera foto);
// - un nombre muy parecido en la nómina cuando no está tal cual (caso Villar: «Riesmersma» por «Riemersma»);
// - las consultas anteriores de la misma familia.
import type { SupabaseClient } from '@supabase/supabase-js';
import { normalizarNombreComparable, traerTodasLasFilas } from '../nucleo/utilidades.js';
import { citasUltimaCitacion, diaLargoCita, type CitaHermanos } from './citasHermanos.js';

type Chico = { nombre: string; grado: unknown; division: unknown; turno: unknown };

/** Distancia de edición (para nombres mal escritos en la nómina). */
export function distanciaEdicion(a: string, b: string): number {
  if (a === b) return 0;
  const fila = Array.from({ length: b.length + 1 }, (_, j) => j);
  for (let i = 1; i <= a.length; i++) {
    let anterior = fila[0];
    fila[0] = i;
    for (let j = 1; j <= b.length; j++) {
      const temp = fila[j];
      fila[j] = Math.min(fila[j] + 1, fila[j - 1] + 1, anterior + (a[i - 1] === b[j - 1] ? 0 : 1));
      anterior = temp;
    }
  }
  return fila[b.length];
}

const tolerancia = (palabra: string) => (palabra.length >= 7 ? 2 : palabra.length >= 4 ? 1 : 0);
const palabrasDe = (nombre: unknown) => normalizarNombreComparable(nombre).split(' ').filter((p) => p.length >= 2);
const mismoGrado = (a: unknown, b: unknown) => normalizarNombreComparable(a) === normalizarNombreComparable(b);

export type AlumnoNomina = { nombre: string; grado: string; division: string; turno: string | null };

/**
 * Un alumno de la nómina del mismo grado cuyo nombre es casi igual al inscripto (cada palabra escrita está, o
 * difiere en 1-2 letras). Sólo si hay uno solo así: con dos candidatos no adivina.
 */
export function nombreParecidoEnNomina(nomina: AlumnoNomina[], nombre: string, grado: unknown): AlumnoNomina | null {
  const escritas = palabrasDe(nombre);
  if (escritas.length < 2) return null;
  const candidatos: { alumno: AlumnoNomina; distancia: number }[] = [];
  for (const alumno of nomina) {
    if (!mismoGrado(alumno.grado, grado)) continue;
    const suyas = palabrasDe(alumno.nombre);
    let distancia = 0;
    let todas = true;
    for (const w of escritas) {
      const mejor = Math.min(...suyas.map((s) => distanciaEdicion(w, s)));
      if (mejor > tolerancia(w)) { todas = false; break; }
      distancia += mejor;
    }
    if (todas && distancia > 0) candidatos.push({ alumno, distancia });
  }
  if (candidatos.length === 0) return null;
  candidatos.sort((a, b) => a.distancia - b.distancia);
  if (candidatos.length > 1 && candidatos[1].distancia === candidatos[0].distancia) return null;
  return candidatos[0].alumno;
}

export async function cargarNominaColegio(supabase: SupabaseClient, colegioId: string): Promise<AlumnoNomina[]> {
  const filas = await traerTodasLasFilas<any>((desde, hasta) =>
    supabase.from('alumnos').select('nombre, grado, division, turno').eq('colegio_id', colegioId).order('id').range(desde, hasta)
  ).catch(() => []);
  return (filas || []).filter((a: any) => a.nombre && a.grado).map((a: any) => ({ nombre: String(a.nombre), grado: String(a.grado), division: String(a.division || ''), turno: a.turno ? String(a.turno) : null }));
}

const CLASES = [
  ['grupal', 'grupales'],
  ['individual', 'individuales'],
  ['docente', 'con la seño'],
  ['familia', 'con familia y/o amigos'],
] as const;

/** Qué clases de fotos hay publicadas en el curso de un chico, y qué le falta al kit de ese curso. */
export async function clasesDeFotosDelCurso(supabase: SupabaseClient, colegioId: string, chico: Chico): Promise<string> {
  const cuenta: Record<string, number> = {};
  for (const [categoria] of CLASES) {
    const { count } = await supabase
      .from('fotos')
      .select('id', { count: 'exact', head: true })
      .eq('colegio_id', colegioId)
      .eq('grado', chico.grado)
      .eq('division', chico.division)
      .eq('turno', chico.turno)
      .eq('categoria', categoria)
      .not('publicada_at', 'is', null);
    cuenta[categoria] = count || 0;
  }
  const total = Object.values(cuenta).reduce((a, n) => a + n, 0);
  if (total === 0) return `Clases de fotos del curso de ${chico.nombre}: todavía no hay ninguna publicada.`;
  const partes = CLASES.filter(([c]) => cuenta[c] > 0).map(([c, texto]) => `${cuenta[c]} ${texto}`);
  const faltan: string[] = [];
  if (!cuenta.grupal) faltan.push('todavía NO hay grupales');
  if (!cuenta.individual) faltan.push('todavía NO hay individuales');
  if (!cuenta.docente && !cuenta.familia) faltan.push('NO hay ninguna tercera foto (ni con la seño ni con familia y/o amigos): mientras no haya, el kit de este curso se arma con la grupal y la individual. Si la familia lo reclama o pregunta cuándo se saca, es una DECISIÓN del equipo (no prometas fecha, toma ni descuento)');
  return `Clases de fotos publicadas en el curso de ${chico.nombre}: ${partes.join(', ')}${faltan.length ? `. ${faltan.join('; ')}` : ''}.`;
}

/** Foto de hermanos de una inscripción: si la pidió, si confirmó y el día y horario asignados. */
export function textoFotoHermanos(insc: any, citas: Record<string, CitaHermanos>): string | null {
  if (!Array.isArray(insc.hermanos) || insc.hermanos.length === 0) return null;
  const nombres = [insc.alumno_nombre, ...insc.hermanos.map((h: any) => h?.alumnoNombre)].filter(Boolean).join(', ');
  const confirmo = insc.foto_hermanos_confirmada_at ? new Date(insc.foto_hermanos_confirmada_at).toLocaleDateString('es-AR', { day: '2-digit', month: '2-digit', timeZone: 'America/Argentina/Buenos_Aires' }) : null;
  if (!insc.solicita_foto_hermanos) {
    return confirmo
      ? `Foto de hermanos (${nombres}): la familia respondió el ${confirmo} que NO la quiere.`
      : `Foto de hermanos (${nombres}): la familia no la pidió.`;
  }
  if (!confirmo) return `Foto de hermanos (${nombres}): figura marcada pero la familia nunca la confirmó; no está citada.`;
  const cita = citas[String(insc.foto_hermanos_email || insc.email || '').trim().toLowerCase()];
  return cita?.dia
    ? `Foto de hermanos (${nombres}): la pidió y la confirmó el ${confirmo}. Está CITADA el ${diaLargoCita(cita.dia)}${cita.hora ? `, de ${cita.hora}` : ''}, en el colegio (ya se le avisó por email). La foto de hermanos se vende aparte: no es parte del kit. Cambiar el día u horario es una DECISIÓN del equipo.`
    : `Foto de hermanos (${nombres}): la pidió y la confirmó el ${confirmo}, pero todavía no tiene día asignado (no entró en la citación enviada).`;
}

/** Datos de la foto de hermanos de todas las inscripciones de la familia (una sola lectura de la citación). */
export async function datosFotoHermanos(supabase: SupabaseClient, inscripciones: any[]): Promise<string[]> {
  if (!inscripciones.some((i) => Array.isArray(i.hermanos) && i.hermanos.length > 0)) return [];
  const citas = await citasUltimaCitacion(supabase).catch(() => ({}));
  return inscripciones.map((i) => textoFotoHermanos(i, citas)).filter((t): t is string => Boolean(t));
}

/** Las otras consultas de la misma familia (las 3 últimas), para no contestar como si fuera la primera vez. */
export async function consultasAnteriores(supabase: SupabaseClient, patronEmail: string | null, idActual?: string): Promise<string[]> {
  if (!patronEmail) return [];
  const { data } = await supabase.from('consultas_familias').select('id, asunto, estado, created_at').ilike('email', patronEmail).order('created_at', { ascending: false }).limit(5);
  return (data || [])
    .filter((c: any) => c.id !== idActual)
    .slice(0, 3)
    .map((c: any) => `Consulta anterior de esta familia (${c.created_at ? new Date(c.created_at).toLocaleDateString('es-AR', { day: '2-digit', month: '2-digit', timeZone: 'America/Argentina/Buenos_Aires' }) : 'sin fecha'}): «${String(c.asunto || '').slice(0, 120)}» — ${c.estado}.`);
}

/** 29/10: «ma***@hotmail.com»: para decirle a la familia con qué email se inscribió sin mostrarlo entero. */
export function enmascararEmail(email: unknown): string {
  const [usuario, dominio] = String(email || '').trim().toLowerCase().split('@');
  if (!usuario || !dominio) return 'otro email';
  return `${usuario.slice(0, 2)}***@${dominio}`;
}

/**
 * 29/10/2026 (Pablo: «la IA sigue respondiendo con un desconocimiento que me enoja»): la familia escribió con un email
 * distinto al de la inscripción (caso Pavan: mariaemiliapavan@gmail.com vs maemiliapavan@hotmail.com). Se busca por el
 * nombre que puso en la consulta: el tutor de la inscripción tiene que compartir al menos 2 palabras con ese nombre y
 * todas sus palabras tienen que estar en él (o al revés): «Emilia Pavan» ↔ «María Emilia Pavan».
 */
export async function buscarInscripcionesPorNombre(supabase: SupabaseClient, nombre: unknown, columnas: string): Promise<any[]> {
  const palabras = normalizarNombreComparable(nombre).split(' ').filter((p) => p.length >= 3);
  if (palabras.length < 2) return [];
  // Las 2 palabras más largas (un nombre muy común como «María» solo podría dejar afuera al que buscamos).
  const claves = [...palabras].sort((a, b) => b.length - a.length).slice(0, 2).filter((c) => /^[a-z]+$/.test(c));
  const data: any[] = [];
  for (const clave of claves) {
    const { data: filas, error } = await supabase.from('inscripciones').select(columnas).ilike('padre_nombre', `%${clave}%`).limit(200);
    if (error) throw error;
    for (const f of (filas || []) as any[]) if (!data.some((d) => d.id === f.id)) data.push(f);
  }
  const coincide = (tutor: unknown) => {
    const t = normalizarNombreComparable(tutor).split(' ').filter((p) => p.length >= 3);
    const comunes = t.filter((p) => palabras.includes(p)).length;
    return comunes >= 2 && (comunes === t.length || comunes === palabras.length);
  };
  const filas = data.filter((i) => coincide(i.padre_nombre));
  // Si aparecen tutores distintos, no se adivina: sólo se usa si todas son del mismo email.
  return new Set(filas.map((i) => String(i.email || '').toLowerCase())).size === 1 ? filas : [];
}
