// Padrón cargado por el colegio (/padron.html: link con token o código corto) (división de server.ts,
// etapa 5, 10/10/2026). El código es el mismo que estaba en la sección "4C. PADRÓN" de server.ts: sólo
// se movió de lugar.
import express from 'express';
import type { Request, Response } from 'express';
import { compararTimingSafe } from '../nucleo/auth.js';
import { getServerSupabase } from '../nucleo/clientes.js';
import { limitarFrecuencia, limitarFrecuenciaPersistente } from '../nucleo/limites.js';
import { traerTodasLasFilas } from '../nucleo/utilidades.js';
import { normalizarTelefonoServidor } from './inscripciones.js';

const rutas = express.Router();

// ==============================================================================
// 4C. PADRÓN — AUTOCARGA POR LA INSTITUCIÓN (sin login, protegido por token secreto)
// Usada por la página estática /padron.html: el colegio recibe un link con su propio
// código secreto (generado en 4A) y pega ahí la lista de familias autorizadas, que se
// guarda directo en `padres_autorizados`. Nunca se expone el token en /api/colegios.
// ==============================================================================

async function validarTokenPadronInstitucion(colegioId: string, codigo: string) {
  const supabase = getServerSupabase();
  if (!supabase) {
    return { ok: false as const, status: 500, error: 'Supabase no configurado en el servidor' };
  }
  if (!colegioId || !codigo || !String(codigo).trim()) {
    return { ok: false as const, status: 400, error: 'Falta el código de acceso al padrón' };
  }
  const { data: colegio, error } = await supabase
    .from('colegios')
    .select('id, nombre, codigo_padron')
    .eq('id', colegioId)
    .single();

  if (error || !colegio || !colegio.codigo_padron) {
    return { ok: false as const, status: 404, error: 'Link no válido' };
  }
  if (!compararTimingSafe(String(codigo).trim().toUpperCase(), String(colegio.codigo_padron).trim().toUpperCase())) {
    return { ok: false as const, status: 403, error: 'El código de este link no es correcto' };
  }
  return { ok: true as const, supabase, colegio };
}

// Resuelve el colegio únicamente por su código de padrón (10 caracteres, ya es único de por
// sí), sin necesitar el UUID del colegio en la URL. Es lo que permite el link corto
// /padron.html?c=CODIGO en vez de .../padron.html?colegio=<uuid>&codigo=<codigo>.
async function resolverColegioPorCodigoPadron(codigo: string) {
  const supabase = getServerSupabase();
  if (!supabase) {
    return { ok: false as const, status: 500, error: 'Supabase no configurado en el servidor' };
  }
  const codigoLimpio = String(codigo || '').trim().toUpperCase();
  if (!codigoLimpio) {
    return { ok: false as const, status: 400, error: 'Falta el código del link' };
  }
  const { data: colegio, error } = await supabase
    .from('colegios')
    .select('id, nombre, codigo_padron')
    .eq('codigo_padron', codigoLimpio)
    .maybeSingle();

  if (error || !colegio) {
    return { ok: false as const, status: 404, error: 'Link no válido' };
  }
  return { ok: true as const, supabase, colegio };
}

// Normaliza las filas recibidas, descarta inválidas/duplicadas del mismo envío, filtra las
// que ya estaban cargadas para ese colegio y guarda el resto en padres_autorizados. Usada
// tanto por la ruta vieja (colegio + código en la URL) como por la ruta corta (solo código).
async function procesarCargaPadron(
  supabase: NonNullable<ReturnType<typeof getServerSupabase>>,
  colegioId: string,
  filas: any,
  res: Response
) {
  if (!Array.isArray(filas) || filas.length === 0) {
    return res.status(400).json({ success: false, error: 'No se recibieron filas para cargar' });
  }
  // Auditoría 03/10 (alto 28): el link lo usa cada familia para cargarSE (una fila, la suya); se
  // aceptaban 2000 filas por envío, lo que permitía llenar el padrón (y la casilla del panel) con un
  // solo pedido. La carga masiva la hace el fotógrafo desde el panel (/api/admin/padron/importar).
  if (filas.length > 5) {
    return res.status(400).json({ success: false, error: 'Demasiadas filas en un solo envío (máximo 5). Cada familia carga sus propios datos.' });
  }

  const vistas = new Set<string>();
  const filasNormalizadas = filas
    .map((f: any) => {
      const nombre = String(f.nombre || '').trim();
      const email = f.email ? String(f.email).trim().toLowerCase() : '';
      const telefono = f.telefono ? normalizarTelefonoServidor(String(f.telefono)) : '';
      return { nombre, email: email || null, telefono: telefono || null };
    })
    .filter((f: any) => f.nombre && (f.telefono || f.email))
    .filter((f: any) => {
      // Descarta duplicados dentro del mismo envío
      const clave = f.email || f.telefono;
      if (vistas.has(clave)) return false;
      vistas.add(clave);
      return true;
    });

  const invalidas = filas.length - filasNormalizadas.length;

  if (filasNormalizadas.length === 0) {
    return res.status(400).json({ success: false, error: 'Ninguna fila tiene los datos mínimos (nombre y al menos email o teléfono)' });
  }

  // Evitar duplicados contra lo que ya está cargado para este colegio
  const existentes = await traerTodasLasFilas<any>((desde, hasta) =>
    supabase
      .from('padres_autorizados')
      .select('email, telefono')
      .eq('colegio_id', colegioId)
      .order('id')
      .range(desde, hasta)
  );

  const emailsExistentes = new Set((existentes || []).map((r: any) => (r.email || '').toLowerCase()).filter(Boolean));
  const telefonosExistentes = new Set((existentes || []).map((r: any) => normalizarTelefonoServidor(r.telefono || '')).filter(Boolean));

  const filasNuevas = filasNormalizadas.filter((f: any) => {
    if (f.email && emailsExistentes.has(f.email)) return false;
    if (f.telefono && telefonosExistentes.has(f.telefono)) return false;
    return true;
  });
  const duplicadas = filasNormalizadas.length - filasNuevas.length;

  if (filasNuevas.length === 0) {
    // Auditoría 03/10 noche (H8): este link es público (circula por WhatsApp): la respuesta es la misma
    // esté o no ese contacto en el padrón (antes confirmaba si un teléfono/email ya figuraba).
    void duplicadas;
    return res.json({ success: true, invalidas });
  }

  const { data, error } = await supabase
    .from('padres_autorizados')
    // origen 'link': la cargó alguien desde el link que el colegio comparte con todas las familias
    // (no prueba que sea el padre de ningún alumno en particular; ver /api/inscripciones/validar).
    .insert(filasNuevas.map((f: any) => ({ colegio_id: colegioId, nombre: f.nombre, email: f.email, telefono: f.telefono, origen: 'link' })))
    .select();
  if (error) throw error;

  void data;
  return res.json({ success: true, invalidas });
}

// Valida el link (colegioId + código) y devuelve el nombre del colegio para mostrar en la página
// Auditoría 2026-09-21 (refuerzo): endpoint público sin autenticación más allá del código de la
// URL — sin límite de frecuencia, se podía probar por fuerza bruta un código de padrón válido.
rutas.get('/api/padron/institucion/:colegioId', limitarFrecuencia('padron-institucion-get', 20, 10 * 60 * 1000), async (req: Request, res: Response) => {
  const { colegioId } = req.params;
  const codigo = String(req.query.codigo || '');
  const resultado = await validarTokenPadronInstitucion(colegioId, codigo);
  if (!resultado.ok) {
    return res.status(resultado.status).json({ success: false, error: resultado.error });
  }
  return res.json({ success: true, colegioNombre: resultado.colegio.nombre });
});

// Recibe los datos que cada padre/madre/tutor/a carga desde padron.html (una fila,
// la suya propia) y los guarda en padres_autorizados, evitando duplicados (por
// teléfono o email) contra lo ya cargado para ese colegio. Acepta también varias
// filas de una vez por si en el futuro se vuelve a usar una carga masiva.
// Auditoría 03/10 (2ª vuelta): 60 cargas por hora por IP (varias familias en el WiFi del colegio).
rutas.post('/api/padron/institucion/:colegioId', limitarFrecuencia('padron-institucion-post', 20, 10 * 60 * 1000), limitarFrecuenciaPersistente('padron-carga-ip', 60, 60 * 60 * 1000), async (req: Request, res: Response) => {
  try {
    const { colegioId } = req.params;
    const { codigo, filas } = req.body || {};

    const resultado = await validarTokenPadronInstitucion(colegioId, codigo);
    if (!resultado.ok) {
      return res.status(resultado.status).json({ success: false, error: resultado.error });
    }
    return await procesarCargaPadron(resultado.supabase, resultado.colegio.id, filas, res);
  } catch (err: any) {
    console.error('Error al cargar padrón desde la institución:', err);
    return res.status(500).json({ success: false, error: err?.message || 'Error al guardar los datos' });
  }
});

// Versión de link corto: el mismo flujo de arriba, pero identificando el colegio solo por
// su código de padrón (sin el UUID en la URL) — así el link que se comparte con cada familia
// es bastante más corto: /padron.html?c=CODIGO en vez de .../padron.html?colegio=<uuid>&codigo=<codigo>.
// Auditoría 2026-09-21 (refuerzo): mismo motivo que /api/padron/institucion — es un lookup
// público por código, sin límite de frecuencia se podía probar por fuerza bruta.
rutas.get('/api/padron/link/:codigo', limitarFrecuencia('padron-link-get', 20, 10 * 60 * 1000), async (req: Request, res: Response) => {
  const { codigo } = req.params;
  const resultado = await resolverColegioPorCodigoPadron(codigo);
  if (!resultado.ok) {
    return res.status(resultado.status).json({ success: false, error: resultado.error });
  }
  return res.json({ success: true, colegioNombre: resultado.colegio.nombre });
});

rutas.post('/api/padron/link/:codigo', limitarFrecuencia('padron-link-post', 20, 10 * 60 * 1000), limitarFrecuenciaPersistente('padron-carga-ip', 60, 60 * 60 * 1000), async (req: Request, res: Response) => {
  try {
    const { codigo } = req.params;
    const { filas } = req.body || {};
    const resultado = await resolverColegioPorCodigoPadron(codigo);
    if (!resultado.ok) {
      return res.status(resultado.status).json({ success: false, error: resultado.error });
    }
    return await procesarCargaPadron(resultado.supabase, resultado.colegio.id, filas, res);
  } catch (err: any) {
    console.error('Error al cargar padrón desde la institución (link corto):', err);
    return res.status(500).json({ success: false, error: err?.message || 'Error al guardar los datos' });
  }
});

export { rutas as rutasPadron };
