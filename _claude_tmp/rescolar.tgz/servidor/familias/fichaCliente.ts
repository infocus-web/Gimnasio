// Ficha del cliente (19/10/2026, pedido de Pablo: «desde el panel de consultas no puedo investigar al cliente: no
// puedo ver sus datos, nombres de sus hijos, kit contratado, si pagó o no; necesito ver todo lo referente a ese
// cliente desde un panel»). Junta en una sola respuesta todo lo que hay de una familia: inscripciones (tutor,
// contacto, estado, código), hijos con su curso contra la nómina y las fotos publicadas del curso, pedidos del
// colegio (kit, fotos elegidas, pago, laboratorio, HD), pedidos de eventos, observaciones de la toma y las otras
// consultas que mandó. Busca por email, teléfono (últimos 10 dígitos) y/o número de pedido. Sólo lectura, sólo admin.
import type { SupabaseClient } from '@supabase/supabase-js';
import express from 'express';
import type { Request, Response } from 'express';
import { requireAdminAuth } from '../nucleo/auth.js';
import { getServerSupabase } from '../nucleo/clientes.js';
import { nombresCompatibles } from '../nucleo/nombres.js';
import { normalizarNombrePorPalabras } from '../nucleo/utilidades.js';
import { crearBuscadorEnNomina } from './cursosNomina.js';

const rutas = express.Router();

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const PEDIDO_RE = /^[A-Za-z0-9-]{3,40}$/;
const MAX_FILAS = 200;

const COLUMNAS_INSCRIPCION =
  'id, padre_nombre, padre_dni, telefono_whatsapp, email, alumno_nombre, alumno_apellido, alumno_dni, grado, division, turno, colegio_id, colegio_nombre, estado, codigo_asignado, hermanos, solicita_foto_hermanos, notificacion_email_enviada, acceso_confirmado_at, fecha_aprobacion, created_at';
const COLUMNAS_PEDIDO =
  'id, familia_id, alumno_id, pedido_friendly_id, alumno_nombre, colegio_nombre, grado, division, turno, kit_nombre, tipo_kit, carpetas_impresas, copias_extras, fotos_seleccionadas, seleccion_pendiente, total, estado, metodo_pago, created_at, pagado_at, aprobado_manual_at, comprobante_path, transferencia_vencida_at, cancelado_definitivo, estado_lab, fecha_entregado, email_enviado, fecha_envio_email, descargas_hd, archivado, en_espera, nota_espera, grupo_pago_id, mejora_de_pedido_id';
const COLUMNAS_PEDIDO_EVENTO =
  'id, numero, evento_id, comprador_nombre, comprador_email, comprador_whatsapp, nino_nombre, nino_curso, total, medio_pago, estado, estado_entrega, fecha_pago, fecha_entregado, email_digitales_enviado, creado_en';

// PostgREST toma `*` como `%` y no se puede escapar: con `*`, `%` o `\` no se busca. `_` se escapa.
function escaparIlike(valor: string): string | null {
  return /[*%\\]/.test(valor) ? null : valor.replace(/_/g, '\\_');
}

/** Regex (imatch) para un teléfono guardado como lo tipeó la familia: últimos 10 dígitos, con separadores. */
export function patronTelefono(telefono: unknown): string | null {
  const digitos = String(telefono ?? '').replace(/\D/g, '');
  if (digitos.length < 8) return null;
  return `${digitos.slice(-10).split('').join('[^0-9]*')}[^0-9]*$`;
}

/** Cuántas fotos tiene el pedido (pack + sueltas). 22/10: sin contar `sinFoto` ni los lugares vacíos. */
function contarFotosElegidas(sel: any): number {
  if (Array.isArray(sel)) return sel.length;
  if (!sel || typeof sel !== 'object') return 0;
  const pack = Object.values(sel).filter((id) => typeof id === 'string' && id).length;
  return pack + (Array.isArray(sel.otrasIds) ? sel.otrasIds.length : 0);
}

function unicosPorId<T extends { id: any }>(filas: T[]): T[] {
  const vistos = new Map<string, T>();
  for (const f of filas) if (f && !vistos.has(String(f.id))) vistos.set(String(f.id), f);
  return [...vistos.values()];
}

async function filas(promesa: PromiseLike<{ data: any; error: any }>): Promise<any[]> {
  const { data, error } = await promesa;
  if (error) throw error;
  return data || [];
}

export async function armarFichaCliente(
  supabase: SupabaseClient,
  criterios: { email?: string; telefono?: string; pedido?: string }
) {
  const email = String(criterios.email || '').trim().toLowerCase();
  const patronEmail = email && EMAIL_RE.test(email) ? escaparIlike(email) : null;
  const telefonos = new Set<string>();
  const patronTel0 = patronTelefono(criterios.telefono);
  if (patronTel0) telefonos.add(patronTel0);
  const numeroPedido = String(criterios.pedido || '').trim();

  // 1) Inscripciones por email y por teléfono.
  let inscripciones: any[] = [];
  if (patronEmail) inscripciones.push(...await filas(supabase.from('inscripciones').select(COLUMNAS_INSCRIPCION).ilike('email', patronEmail).limit(MAX_FILAS)));
  if (patronTel0) inscripciones.push(...await filas(supabase.from('inscripciones').select(COLUMNAS_INSCRIPCION).filter('telefono_whatsapp', 'imatch', patronTel0).limit(MAX_FILAS)));
  inscripciones = unicosPorId(inscripciones);
  // Los teléfonos de esas inscripciones también identifican a la familia (suele pagar con otro email).
  for (const i of inscripciones) {
    const p = patronTelefono(i.telefono_whatsapp);
    if (p && telefonos.size < 4) telefonos.add(p);
  }
  const emails = new Set<string>();
  if (patronEmail) emails.add(email);
  for (const i of inscripciones) {
    const e = String(i.email || '').trim().toLowerCase();
    if (e && emails.size < 4) emails.add(e);
  }

  // 2) Familias (las crea cada compra) por email y por teléfono.
  let familias: any[] = [];
  for (const e of emails) {
    const patron = escaparIlike(e);
    if (patron) familias.push(...await filas(supabase.from('familias').select('id, nombre, email, whatsapp, created_at').ilike('email', patron).limit(MAX_FILAS)));
  }
  for (const t of telefonos) familias.push(...await filas(supabase.from('familias').select('id, nombre, email, whatsapp, created_at').filter('whatsapp', 'imatch', t).limit(MAX_FILAS)));
  familias = unicosPorId(familias);
  const idsFamilia = familias.map((f) => f.id);

  // 3) Pedidos del colegio de esas familias, más el número de pedido mencionado.
  let pedidos: any[] = [];
  if (idsFamilia.length > 0) {
    pedidos.push(...await filas(supabase.from('pedidos').select(COLUMNAS_PEDIDO).in('familia_id', idsFamilia.slice(0, 100)).order('created_at', { ascending: false }).limit(MAX_FILAS)));
  }
  let pedidoMencionado: { numero: string; encontrado: boolean; deEstaFamilia: boolean } | null = null;
  if (numeroPedido && PEDIDO_RE.test(numeroPedido)) {
    const yaEsta = pedidos.some((p) => String(p.pedido_friendly_id || '').toUpperCase() === numeroPedido.toUpperCase());
    let encontrado = yaEsta;
    if (!yaEsta) {
      const patron = escaparIlike(numeroPedido);
      const porNumero = patron ? await filas(supabase.from('pedidos').select(COLUMNAS_PEDIDO).ilike('pedido_friendly_id', patron).limit(5)) : [];
      encontrado = porNumero.length > 0;
      pedidos.push(...porNumero.map((p) => ({ ...p, soloPorNumero: true })));
    }
    pedidoMencionado = { numero: numeroPedido, encontrado, deEstaFamilia: yaEsta };
  }
  pedidos = unicosPorId(pedidos);

  // 4) Pedidos de eventos (comuniones, hermanos…) por email y teléfono del comprador.
  let pedidosEventos: any[] = [];
  for (const e of emails) {
    const patron = escaparIlike(e);
    if (patron) pedidosEventos.push(...await filas(supabase.from('ev_pedidos').select(COLUMNAS_PEDIDO_EVENTO).ilike('comprador_email', patron).limit(MAX_FILAS)));
  }
  for (const t of telefonos) pedidosEventos.push(...await filas(supabase.from('ev_pedidos').select(COLUMNAS_PEDIDO_EVENTO).filter('comprador_whatsapp', 'imatch', t).limit(MAX_FILAS)));
  pedidosEventos = unicosPorId(pedidosEventos).sort((a, b) => String(b.creado_en).localeCompare(String(a.creado_en)));
  const idsEventos = [...new Set(pedidosEventos.map((p) => p.evento_id).filter(Boolean))];
  const eventos = idsEventos.length ? await filas(supabase.from('ev_eventos').select('id, nombre, codigo').in('id', idsEventos)) : [];
  const eventoPorId = new Map(eventos.map((e: any) => [e.id, e]));

  // 5) Hijos: el de la inscripción y sus hermanos, con el curso de la nómina y las fotos publicadas del curso.
  const hijos: any[] = [];
  const buscadores = new Map<string, Awaited<ReturnType<typeof crearBuscadorEnNomina>>>();
  const fotosPorCurso = new Map<string, number>();
  for (const insc of inscripciones) {
    const chicos = [
      { nombre: `${insc.alumno_nombre || ''} ${insc.alumno_apellido || ''}`.trim(), dni: insc.alumno_dni || null, grado: insc.grado, division: insc.division, turno: insc.turno },
      ...(Array.isArray(insc.hermanos) ? insc.hermanos : []).map((h: any) => ({
        nombre: `${h?.alumnoNombre || ''} ${h?.alumnoApellido || ''}`.trim(), dni: h?.alumnoDni || null, grado: h?.grado, division: h?.division, turno: h?.turno,
      })),
    ];
    for (const chico of chicos) {
      if (!chico.nombre) continue;
      const clave = `${insc.colegio_id}|${normalizarNombrePorPalabras(chico.nombre)}`;
      if (hijos.some((h) => h.clave === clave)) continue;
      let nomina: { grado: string; division: string; turno: string | null } | null = null;
      if (insc.colegio_id) {
        if (!buscadores.has(insc.colegio_id)) buscadores.set(insc.colegio_id, await crearBuscadorEnNomina(supabase, insc.colegio_id));
        nomina = await buscadores.get(insc.colegio_id)!(chico.nombre, chico.grado);
      }
      const coincide = Boolean(nomina && nomina.grado === chico.grado && nomina.division === chico.division && (!nomina.turno || nomina.turno === chico.turno));
      let fotosPublicadas: number | null = null;
      if (insc.colegio_id && chico.grado && chico.division) {
        const claveCurso = `${insc.colegio_id}|${chico.grado}|${chico.division}|${chico.turno || ''}`;
        if (!fotosPorCurso.has(claveCurso)) {
          let q = supabase.from('fotos').select('id', { count: 'exact', head: true })
            .eq('colegio_id', insc.colegio_id).eq('grado', chico.grado).eq('division', chico.division).not('publicada_at', 'is', null);
          if (chico.turno) q = q.eq('turno', chico.turno);
          const { count } = await q;
          fotosPorCurso.set(claveCurso, count || 0);
        }
        fotosPublicadas = fotosPorCurso.get(claveCurso) ?? null;
      }
      const pedidosDelHijo = pedidos.filter((p) => !p.soloPorNumero && nombresCompatibles(p.alumno_nombre, chico.nombre));
      hijos.push({
        clave,
        nombre: chico.nombre,
        dni: chico.dni,
        colegio: insc.colegio_nombre,
        inscripcionId: insc.id,
        curso: { grado: chico.grado, division: chico.division, turno: chico.turno },
        cursoNomina: nomina,
        enNomina: Boolean(nomina),
        coincideConNomina: coincide,
        fotosPublicadas,
        pagado: pedidosDelHijo.some((p) => p.estado === 'pagado' || p.estado === 'entregado'),
        pedidos: pedidosDelHijo.length,
      });
    }
  }

  // 6) Observaciones de la toma (no quiso la individual, ausente…) de esos chicos.
  const idsAlumnos = new Set(pedidos.map((p) => p.alumno_id).filter(Boolean));
  const colegios = [...new Set(inscripciones.map((i) => i.colegio_id).filter(Boolean))].slice(0, 10);
  const observaciones: any[] = [];
  for (const colegioId of colegios) {
    const obs = await filas(supabase.from('observaciones_alumnos').select('id, alumno_id, alumno_nombre, grado, division, turno, tipo, detalle, created_at').eq('colegio_id', colegioId).order('created_at', { ascending: false }).limit(1000)).catch(() => []);
    for (const o of obs) {
      if (idsAlumnos.has(o.alumno_id) || hijos.some((h) => nombresCompatibles(o.alumno_nombre, h.nombre))) observaciones.push(o);
    }
  }

  // 7) Otras consultas de los mismos emails.
  let consultas: any[] = [];
  for (const e of emails) {
    const patron = escaparIlike(e);
    if (patron) consultas.push(...await filas(supabase.from('consultas_familias').select('id, asunto, estado, origen, created_at').ilike('email', patron).order('created_at', { ascending: false }).limit(30)));
  }
  consultas = unicosPorId(consultas).sort((a, b) => String(b.created_at).localeCompare(String(a.created_at)));

  return {
    encontrado: inscripciones.length + familias.length + pedidos.length + pedidosEventos.length > 0,
    buscado: { email: email || null, telefono: criterios.telefono || null, pedido: numeroPedido || null },
    inscripciones: inscripciones.map((i) => ({
      id: i.id,
      tutor: i.padre_nombre,
      dniTutor: i.padre_dni,
      email: i.email,
      telefono: i.telefono_whatsapp,
      colegio: i.colegio_nombre,
      estado: i.estado,
      codigo: i.codigo_asignado,
      emailCodigoEnviado: Boolean(i.notificacion_email_enviada),
      accesoConfirmadoAt: i.acceso_confirmado_at,
      fotoHermanos: Boolean(i.solicita_foto_hermanos),
      fechaAprobacion: i.fecha_aprobacion,
      createdAt: i.created_at,
    })),
    familias: familias.map((f) => ({ id: f.id, nombre: f.nombre, email: f.email, whatsapp: f.whatsapp })),
    hijos: hijos.map(({ clave: _clave, ...h }) => h),
    pedidos: pedidos
      .sort((a, b) => String(b.created_at).localeCompare(String(a.created_at)))
      .map((p) => ({
        id: p.id,
        numero: p.pedido_friendly_id,
        alumno: p.alumno_nombre,
        colegio: p.colegio_nombre,
        curso: [p.grado, p.division, p.turno].filter(Boolean).join(' · '),
        kit: p.kit_nombre || p.tipo_kit,
        carpetasImpresas: p.carpetas_impresas ?? null,
        copiasExtras: Array.isArray(p.copias_extras) ? p.copias_extras.length : 0,
        fotosElegidas: contarFotosElegidas(p.fotos_seleccionadas),
        seleccionPendiente: Boolean(p.seleccion_pendiente),
        total: Number(p.total) || 0,
        estado: p.estado,
        metodoPago: p.metodo_pago,
        createdAt: p.created_at,
        pagadoAt: p.pagado_at,
        aprobadoManual: Boolean(p.aprobado_manual_at),
        comprobante: Boolean(p.comprobante_path),
        transferenciaVencida: Boolean(p.transferencia_vencida_at),
        canceladoDefinitivo: Boolean(p.cancelado_definitivo),
        estadoLab: p.estado_lab,
        entregadoAt: p.fecha_entregado,
        hdEnviado: Boolean(p.email_enviado),
        hdEnviadoAt: p.fecha_envio_email,
        descargasHd: p.descargas_hd ?? 0,
        archivado: Boolean(p.archivado),
        enEspera: Boolean(p.en_espera),
        notaEspera: p.nota_espera,
        esMejora: Boolean(p.mejora_de_pedido_id),
        soloPorNumero: Boolean(p.soloPorNumero),
      })),
    pedidoMencionado,
    pedidosEventos: pedidosEventos.map((p) => ({
      id: p.id,
      numero: p.numero,
      evento: eventoPorId.get(p.evento_id)?.nombre || null,
      comprador: p.comprador_nombre,
      nino: p.nino_nombre,
      curso: p.nino_curso,
      total: Number(p.total) || 0,
      medioPago: p.medio_pago,
      estado: p.estado,
      estadoEntrega: p.estado_entrega,
      fechaPago: p.fecha_pago,
      entregadoAt: p.fecha_entregado,
      digitalesEnviados: Boolean(p.email_digitales_enviado),
      createdAt: p.creado_en,
    })),
    observaciones: observaciones.map((o) => ({ id: o.id, alumno: o.alumno_nombre, curso: [o.grado, o.division, o.turno].filter(Boolean).join(' · '), tipo: o.tipo, detalle: o.detalle, createdAt: o.created_at })),
    consultas: consultas.map((c) => ({ id: c.id, asunto: c.asunto, estado: c.estado, origen: c.origen, createdAt: c.created_at })),
  };
}

rutas.get('/api/admin/ficha-cliente', requireAdminAuth, async (req: Request, res: Response) => {
  try {
    const email = typeof req.query.email === 'string' ? req.query.email.trim().slice(0, 200) : '';
    const telefono = typeof req.query.telefono === 'string' ? req.query.telefono.trim().slice(0, 40) : '';
    const pedido = typeof req.query.pedido === 'string' ? req.query.pedido.trim().slice(0, 40) : '';
    const emailValido = EMAIL_RE.test(email);
    if (!emailValido && !patronTelefono(telefono) && !PEDIDO_RE.test(pedido)) {
      return res.status(400).json({ success: false, error: 'Indicá un email, un teléfono (8 dígitos o más) o un número de pedido.' });
    }
    const supabase = getServerSupabase();
    if (!supabase) return res.status(500).json({ success: false, error: 'Supabase no configurado en el servidor' });
    const ficha = await armarFichaCliente(supabase, { email: emailValido ? email : '', telefono, pedido });
    return res.json({ success: true, ficha });
  } catch (err: any) {
    console.error('[ficha-cliente] Error:', err);
    return res.status(500).json({ success: false, error: 'No se pudo armar la ficha del cliente.' });
  }
});

export { rutas as rutasFichaCliente };
