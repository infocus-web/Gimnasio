// «Faltantes solicitadas» (22/10/2026): lo que usa la compra (validarSeleccionFotos en servidor/pagos/crearPedido.ts)
// para dejar en espera el kit de un chico cuya familia pidió que le saquen una foto. Separado de
// solicitudesFaltantes.ts para no armar un import circular con crearPedido.ts.
import type { SupabaseClient } from '@supabase/supabase-js';
import type { LugarPack } from '../nucleo/fotosFaltantes.js';
import { normalizarNombrePorPalabras } from '../nucleo/utilidades.js';

export const TABLA_FALTANTES = 'fotos_faltantes_solicitudes';
export const NOMBRE_LUGAR_FALTANTE: Record<LugarPack, string> = { individual: 'la foto individual', grupal: 'la foto grupal', docente: 'la 3ª foto (con la seño o con familia/amigos)' };

/** Si la tabla todavía no existe (migración sin aplicar) no se frena nada: se sigue como antes. */
export const tablaFaltantesNoExiste = (error: any) => ['42P01', 'PGRST205'].includes(String(error?.code || ''));

/** Mismo chico: el pedido de foto guarda el nombre de la inscripción; se compara exacto (sin tildes ni mayúsculas). */
export const mismoAlumno = (a: unknown, b: unknown) => {
  const na = normalizarNombrePorPalabras(a);
  return Boolean(na) && na === normalizarNombrePorPalabras(b);
};

/**
 * Pedido de foto pendiente que frena cerrar el kit de este chico: sólo si ese lugar del pack sigue «sin foto»
 * (si la familia ya eligió una foto para ese lugar, no frena). null = nada que frene.
 */
export async function faltantePendienteQueFrena(
  supabase: SupabaseClient,
  colegioId: string,
  codigoCurso: string,
  nombres: string[],
  sinFoto: readonly LugarPack[]
): Promise<{ alumno: string; lugar: LugarPack } | null> {
  if (sinFoto.length === 0) return null;
  const { data, error } = await supabase
    .from(TABLA_FALTANTES)
    .select('alumno_nombre, lugar')
    .eq('colegio_id', colegioId)
    .eq('codigo_curso', codigoCurso)
    .eq('estado', 'pendiente')
    .in('lugar', [...sinFoto])
    .limit(500);
  if (error) {
    if (tablaFaltantesNoExiste(error)) return null;
    throw error;
  }
  const fila = (data || []).find((s: any) => nombres.some((n) => mismoAlumno(s.alumno_nombre, n)));
  return fila ? { alumno: fila.alumno_nombre, lugar: fila.lugar } : null;
}

export function mensajeFaltantePendiente(f: { alumno: string; lugar: LugarPack }): string {
  return `Pediste que le saquemos ${NOMBRE_LUGAR_FALTANTE[f.lugar]} a ${f.alumno}. Cuando la publiquemos te avisamos por mail para que la elijas y cierres el kit. Si preferís otra foto del curso en su lugar, cancelá el pedido de foto en la galería y elegila.`;
}

/**
 * 26/10/2026 (Pablo): «el kit sí o sí lleva 3 fotos». Un lugar marcado «no tiene esta foto» ya no puede quedar vacío:
 * va con otra foto del curso o, si la familia pidió que se la saquen (Faltantes solicitadas), el kit espera esa foto.
 * Devuelve el error para la familia, o null si no hay lugares vacíos.
 */
export async function errorLugarSinFotoVacio(
  supabase: SupabaseClient,
  colegioId: string,
  cursoCodigo: string,
  nombres: string[],
  vacios: readonly LugarPack[],
  fotosDelKit: number,
  nombreAlumno: string
): Promise<string | null> {
  if (vacios.length === 0) return null;
  const frena = await faltantePendienteQueFrena(supabase, colegioId, cursoCodigo, nombres, vacios);
  if (frena) return mensajeFaltantePendiente(frena);
  return `El kit${nombreAlumno} lleva siempre ${fotosDelKit} fotos: elegí otra foto del curso en el lugar de la que falta (o, si no está en la grupal, escribinos).`;
}
