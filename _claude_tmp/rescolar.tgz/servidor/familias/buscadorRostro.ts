// Buscador por reconocimiento facial (24/10/2026, pedido de Pablo). En la toma del Divino Pastor se mezclaron alumnos
// entre cursos: la familia sube una foto del rostro de su hijo/a y se buscan en AWS Rekognition las individuales del
// colegio donde aparece. Cada foto encontrada en OTRO curso se copia al curso de la familia ETIQUETADA con el nombre
// del chico: así la ve y la compra sólo esa familia (regla de siempre de las individuales con nombre) y funciona sola
// con todo lo demás (galería, lupa, pedido, laboratorio, HD), sin tocar pagos.
// - La foto que sube la familia NO se guarda: se manda a Rekognition para buscar y se descarta.
// - Consentimiento obligatorio (casilla) y tope de BUSQUEDAS_POR_DIA por inscripción.
// - La colección REKOGNITION_COLECCION (por defecto divino-pastor-2026-buscador) tiene SÓLO la cara principal de cada
//   individual (MaxFaces=1), con el nombre del archivo como ExternalImageId (FOTO-2600.jpg = nombre_original de `fotos`).
//   La arma _ubicador/indexar_buscador.py. Grupales y fotos con la seño no están: nunca disparan una copia.
// - Revisión 24/10: no se copia una foto ya etiquetada con OTRO chico; umbral 97 %; el panel muestra de qué curso y
//   foto vino cada copia (para auditar y deshacer). Riesgo residual aceptado por Pablo (búsqueda automática): una
//   familia que sube la cara de un chico ajeno podría ver sus individuales sin etiquetar de otro curso.
// - «Cerrar año» borra las caras en AWS y las tres tablas (borrarRostrosDelColegio).
// Tablas: migración 20261024180000_buscador_rostro.sql. Detalle: claude/fotos-mezcladas-por-rostro-2026-10-24.md.
import { DeleteCollectionCommand, RekognitionClient, SearchFacesByImageCommand } from '@aws-sdk/client-rekognition';
import type { SupabaseClient } from '@supabase/supabase-js';
import crypto from 'crypto';
import express from 'express';
import type { Request, Response } from 'express';
import { requireAdminAuth } from '../nucleo/auth.js';
import { getServerSupabase } from '../nucleo/clientes.js';
import { buscarSeccionPorCodigoSecreto, determinarCodigoCursoServidor } from '../nucleo/codigosCurso.js';
import { hayCupoPorClave, limitarFrecuencia } from '../nucleo/limites.js';
import { buscadorRostroConfigurado, colegioTieneBuscadorRostro, colegiosConBuscadorRostro, cursoTieneFotosPublicadas, tablaRostrosNoExiste } from '../nucleo/rostros.js';
import { enLotes, traerTodasLasFilas } from '../nucleo/utilidades.js';
import { mismoAlumno } from './faltantesPendientes.js';
import { familiaYCurso } from './solicitudesFaltantes.js';

const rutas = express.Router();

export const BUSQUEDAS_POR_DIA = 5;
export const UMBRAL_SIMILITUD = 97;
const MAX_FOTOS_NUEVAS = 12;
const MAX_BYTES_IMAGEN = 3 * 1024 * 1024;
const RESERVA_VENCIDA_MS = 2 * 60 * 1000;
const CURSO_SIN_PUBLICAR = 'Todavía no publicamos las fotos de tu curso. Cuando estén online vas a poder usar el buscador.';
// Errores de AWS que son nuestros (colección borrada, clave o región mal): «no disponible», no «probá otra foto».
const AWS_NO_DISPONIBLE = new Set(['ResourceNotFoundException', 'AccessDeniedException', 'UnrecognizedClientException', 'InvalidSignatureException', 'ThrottlingException', 'ProvisionedThroughputExceededException', 'ServiceUnavailableException']);
const AWS_IMAGEN_INVALIDA = new Set(['InvalidImageFormatException', 'ImageTooLargeException']);
const ERROR_ACCESO = 'Para buscar tenés que ingresar a la galería con los datos de tu familia (DNI del tutor). Volvé a ingresar e intentá de nuevo.';

let clienteCache: { clave: string; cliente: RekognitionClient } | null = null;

/** Cliente de Rekognition con la clave del usuario IAM limitado (variables de Vercel). null = no configurado. */
export function clienteRekognition(): RekognitionClient | null {
  if (!buscadorRostroConfigurado()) return null;
  const accessKeyId = (process.env.AWS_REKOGNITION_ACCESS_KEY_ID || '').trim();
  const secretAccessKey = (process.env.AWS_REKOGNITION_SECRET_ACCESS_KEY || '').trim();
  // La cuenta (plan gratuito, «proyecto» de AWS) sólo habilita us-east-2 (Ohio).
  const region = (process.env.AWS_REKOGNITION_REGION || 'us-east-2').trim();
  const clave = `${accessKeyId}|${region}`;
  if (!clienteCache || clienteCache.clave !== clave) {
    clienteCache = { clave, cliente: new RekognitionClient({ region, credentials: { accessKeyId, secretAccessKey } }) };
  }
  return clienteCache.cliente;
}

export function coleccionRekognition(): string {
  return (process.env.REKOGNITION_COLECCION || 'divino-pastor-2026-buscador').trim();
}

/** Imagen que mandó el navegador (base64 de un JPEG o PNG, ya achicada) → bytes, o null si no es válida. */
export function imagenDesdeBase64(valor: unknown): Buffer | null {
  if (typeof valor !== 'string') return null;
  const limpio = valor.replace(/^data:image\/(jpeg|jpg|png);base64,/i, '').trim();
  if (!limpio || limpio.length > Math.ceil((MAX_BYTES_IMAGEN * 4) / 3) + 8 || !/^[A-Za-z0-9+/=\s]+$/.test(limpio)) return null;
  const bytes = Buffer.from(limpio, 'base64');
  if (bytes.length < 1000 || bytes.length > MAX_BYTES_IMAGEN) return null;
  const esJpeg = bytes[0] === 0xff && bytes[1] === 0xd8;
  const esPng = bytes[0] === 0x89 && bytes[1] === 0x50 && bytes[2] === 0x4e && bytes[3] === 0x47;
  return esJpeg || esPng ? bytes : null;
}

/**
 * Nombre de archivo → «base» del original: FOTO-2600.jpg, FOTO-2600__copia-desde-2B_TARDE.jpg (copias del script
 * del fotógrafo) y FOTO-2600__rostro.jpg (copias de este buscador) dan todas «FOTO-2600» (en mayúsculas, para comparar
 * igual que el ilike). null si no es un nombre seguro (va adentro de un filtro de PostgREST).
 */
export function nombreBase(nombre: unknown): string | null {
  const sinExt = String(nombre || '').trim().replace(/\.(jpe?g|png)$/i, '');
  const base = sinExt.split('__')[0];
  return /^[A-Za-z0-9_-]{1,120}$/.test(base) ? base.toUpperCase() : null;
}

/** Ruta dentro del bucket a partir de la URL pública guardada (igual que servidor/panel/fotos.ts). */
function rutaEnBucket(valor: unknown, bucket: string): string | null {
  const texto = String(valor || '').trim();
  if (!texto) return null;
  const marca = `/object/public/${bucket}/`;
  const i = texto.indexOf(marca);
  const ruta = (i >= 0 ? texto.slice(i + marca.length) : texto.startsWith('http') ? '' : texto).split('?')[0];
  try {
    return decodeURIComponent(ruta) || null;
  } catch {
    return ruta || null;
  }
}

type FotoOrigen = { id: string; categoria: string; codigo_curso: string | null; alumno_nombre: string | null; storage_path: string | null; thumb_path: string | null; preview_path: string | null; nombre_original: string | null; bytes_original: number | null };
type Destino = { colegioId: string; codigoCurso: string; seccion: { grado: string; turno: string; division: string }; hijo: string };

/** Copia una foto encontrada al curso de la familia, etiquetada con el chico. Si algo falla, borra lo ya copiado. */
async function copiarFotoAlCurso(supabase: SupabaseClient, origen: FotoOrigen, destino: Destino, base: string): Promise<string> {
  const id = crypto.randomUUID();
  const hd = String(origen.storage_path || '');
  const anio = /^(\d{4})\//.exec(hd)?.[1] || String(new Date().getFullYear());
  const carpeta = `${anio}/rostro/${destino.codigoCurso}`;
  const copiados: Array<{ bucket: string; ruta: string }> = [];
  const copiar = async (bucket: string, desde: string, hacia: string) => {
    const { error } = await supabase.storage.from(bucket).copy(desde, hacia);
    if (error) throw error;
    copiados.push({ bucket, ruta: hacia });
    return hacia;
  };
  try {
    const storagePath = await copiar('fotos-hd', hd, `${carpeta}/originales/${id}.jpg`);
    const urlWeb = async (valor: string | null, tipo: string): Promise<string | null> => {
      const ruta = rutaEnBucket(valor, 'fotos-web');
      if (!ruta) return null;
      const nueva = await copiar('fotos-web', ruta, `${carpeta}/${tipo}/${id}.jpg`);
      return supabase.storage.from('fotos-web').getPublicUrl(nueva).data.publicUrl;
    };
    const previewPath = await urlWeb(origen.preview_path, 'muestras');
    const thumbPath = (await urlWeb(origen.thumb_path === origen.preview_path ? null : origen.thumb_path, 'miniaturas')) || previewPath;
    const { error } = await supabase.from('fotos').insert({
      id,
      colegio_id: destino.colegioId,
      categoria: 'individual',
      grado: destino.seccion.grado || null,
      turno: destino.seccion.turno || null,
      division: destino.seccion.division || null,
      codigo_curso: destino.codigoCurso,
      storage_path: storagePath,
      preview_path: previewPath,
      thumb_path: thumbPath,
      alumno_nombre: destino.hijo, // etiquetada: sólo la ve y la compra la familia de este chico
      publicada_at: new Date().toISOString(),
      nombre_original: `${base}__rostro.jpg`,
      bytes_original: origen.bytes_original,
    });
    if (error) throw error;
    return id;
  } catch (err) {
    for (const c of copiados) await supabase.storage.from(c.bucket).remove([c.ruta]).catch(() => undefined);
    throw err;
  }
}

async function registrarBusqueda(supabase: SupabaseClient, fila: Record<string, unknown>): Promise<string | null> {
  const id = crypto.randomUUID();
  const { error } = await supabase.from('rostros_busquedas').insert({ id, ...fila });
  if (error) {
    console.warn('[rostro] No se pudo registrar la búsqueda:', error.message);
    return null;
  }
  return id;
}

// Portal: ¿muestro el botón? (sólo si el colegio del código tiene caras cargadas, AWS está configurado y, desde el
// 25/10, el curso del código ya tiene fotos publicadas).
rutas.get('/api/fotos/buscador-rostro', limitarFrecuencia('buscador-rostro-disponible', 300, 10 * 60 * 1000), async (req: Request, res: Response) => {
  try {
    const supabase = getServerSupabase();
    if (!supabase) return res.json({ success: true, disponible: false });
    const seccion = await buscarSeccionPorCodigoSecreto(supabase, String(req.query.codigo || ''));
    if (!seccion || !(await colegioTieneBuscadorRostro(supabase, seccion.colegioId))) return res.json({ success: true, disponible: false });
    const codigoCurso = determinarCodigoCursoServidor(seccion.grado, seccion.turno, seccion.division);
    return res.json({ success: true, disponible: await cursoTieneFotosPublicadas(supabase, seccion.colegioId, codigoCurso) });
  } catch {
    return res.json({ success: true, disponible: false });
  }
});

rutas.post('/api/fotos/buscar-rostro', limitarFrecuencia('buscar-rostro', 30, 10 * 60 * 1000), async (req: Request, res: Response) => {
  try {
    if (req.body?.consentimiento !== true) {
      return res.status(400).json({ success: false, error: 'Para buscar tenés que aceptar el uso de la foto para esta búsqueda.' });
    }
    const imagen = imagenDesdeBase64(req.body?.imagen);
    if (!imagen) return res.status(400).json({ success: false, error: 'No pudimos leer la foto. Probá con otra (JPG o PNG).' });
    const supabase = getServerSupabase();
    const rekognition = clienteRekognition();
    if (!supabase || !rekognition) return res.status(503).json({ success: false, error: 'El buscador no está disponible en este momento.' });

    const acceso = await familiaYCurso(supabase, req.body, String(req.body?.alumnoNombre || '').slice(0, 200));
    if (!acceso) return res.status(403).json({ success: false, error: ERROR_ACCESO });
    if (!(await colegioTieneBuscadorRostro(supabase, acceso.colegioId))) {
      return res.status(503).json({ success: false, error: 'El buscador no está disponible para este colegio.' });
    }
    // 25/10: antes de gastar cupo; las copias nacen publicadas, así que el curso tiene que estar publicado.
    if (!(await cursoTieneFotosPublicadas(supabase, acceso.colegioId, acceso.codigoCurso))) {
      return res.status(409).json({ success: false, error: CURSO_SIN_PUBLICAR });
    }
    const familiaId = String(req.body.familia);
    if (!(await hayCupoPorClave(`buscar-rostro:${familiaId}`, BUSQUEDAS_POR_DIA, 24 * 60 * 60))) {
      return res.status(429).json({ success: false, error: `Llegaste al máximo de ${BUSQUEDAS_POR_DIA} búsquedas por día. Probá de nuevo mañana.` });
    }
    const registro = { colegio_id: acceso.colegioId, codigo_curso: acceso.codigoCurso, inscripcion_id: familiaId, alumno_nombre: acceso.hijo };

    // 1) Rekognition: caras parecidas a la cara más grande de la foto (la imagen no se guarda en ningún lado).
    let archivos: string[] = [];
    try {
      const r = await rekognition.send(new SearchFacesByImageCommand({
        CollectionId: coleccionRekognition(),
        Image: { Bytes: imagen },
        FaceMatchThreshold: UMBRAL_SIMILITUD,
        MaxFaces: 100, // grupales y fotos con la seño también suman caras: con pocas se perderían individuales
        QualityFilter: 'AUTO',
      }));
      archivos = (r.FaceMatches || []).map((m) => String(m.Face?.ExternalImageId || '')).filter(Boolean);
    } catch (err: any) {
      if (err?.name === 'InvalidParameterException') {
        await registrarBusqueda(supabase, { ...registro, resultado: 'sin_cara' });
        return res.status(422).json({ success: false, error: 'No encontramos una cara en la foto. Probá con otra de frente, con buena luz y sin anteojos de sol.' });
      }
      // 25/10: el resto de los errores de AWS queda registrado (el panel lo ve) con un mensaje claro.
      await registrarBusqueda(supabase, { ...registro, resultado: 'error' });
      console.error('[rostro] Rekognition falló:', err?.name || '', err?.message || err);
      if (AWS_IMAGEN_INVALIDA.has(String(err?.name))) {
        return res.status(422).json({ success: false, error: 'No pudimos leer la foto. Probá con otra (JPG o PNG, de menos de 3 MB).' });
      }
      if (AWS_NO_DISPONIBLE.has(String(err?.name))) {
        return res.status(503).json({ success: false, error: 'El buscador no está disponible en este momento. Probá de nuevo más tarde.' });
      }
      throw err;
    }

    // 2) Cara → archivo original (ExternalImageId). Sólo se buscan fotos del colegio de la familia (paso 3).
    const nombres = new Set<string>();
    for (const archivo of archivos) {
      const base = nombreBase(archivo);
      if (base) nombres.add(base);
    }

    // 3) Individuales publicadas del colegio con ese original (o sus copias), en cualquier curso.
    const candidatas: FotoOrigen[] = [];
    for (const lote of enLotes(Array.from(nombres), 40)) {
      const filtro = lote.flatMap((b) => [`nombre_original.ilike.${b}.*`, `nombre_original.ilike.${b}__*`]).join(',');
      const filas = await traerTodasLasFilas<FotoOrigen>((desde, hasta) =>
        supabase
          .from('fotos')
          .select('id, categoria, codigo_curso, alumno_nombre, storage_path, thumb_path, preview_path, nombre_original, bytes_original')
          .eq('colegio_id', acceso.colegioId)
          .eq('categoria', 'individual')
          .not('publicada_at', 'is', null)
          .or(filtro)
          .order('id')
          .range(desde, hasta)
      );
      candidatas.push(...filas);
    }
    // Sólo las que esta familia puede tener: sin etiqueta o etiquetadas con su hijo (nunca la de otro chico).
    const deEsteChico = (f: FotoOrigen) => !f.alumno_nombre || mismoAlumno(f.alumno_nombre, acceso.hijo);
    const porBase = new Map<string, FotoOrigen[]>();
    for (const f of candidatas) {
      const base = nombreBase(f.nombre_original);
      if (!base || !nombres.has(base) || !deEsteChico(f)) continue; // el ilike «FOTO-26*» no debe traer FOTO-2600
      porBase.set(base, [...(porBase.get(base) || []), f]);
    }

    // 4) Hallazgos previos: los que tienen copia cuentan como ya hechos; una reserva vieja sin copia (se cortó a
    //    mitad) se borra para poder reintentar.
    const { data: previos, error: errPrevios } = await supabase
      .from('rostros_hallazgos')
      .select('id, nombre_base, alumno_nombre, foto_copia_id, created_at')
      .eq('inscripcion_id', familiaId);
    if (errPrevios) throw errPrevios;
    const yaCopiadas = new Set<string>();
    const copiaDe = new Map<string, string>(); // 25/10: base → id de la copia ya hecha (para mostrársela a la familia)
    for (const h of (previos || []).filter((p: any) => mismoAlumno(p.alumno_nombre, acceso.hijo))) {
      if (h.foto_copia_id) { yaCopiadas.add(String(h.nombre_base)); copiaDe.set(String(h.nombre_base), String(h.foto_copia_id)); }
      else if (Date.now() - Date.parse(h.created_at || '') > RESERVA_VENCIDA_MS) await supabase.from('rostros_hallazgos').delete().eq('id', h.id);
      else yaCopiadas.add(String(h.nombre_base)); // otra búsqueda la está copiando ahora
    }
    let yaEnGaleria = 0;
    // 25/10/2026 (Pablo: «ni siquiera pueden ver la foto que encontró el sistema»): ids de las fotos encontradas que la
    // familia ya ve en su galería (las de su curso, las copiadas antes y las que se copian ahora), para mostrárselas.
    const encontradas: string[] = [];
    const aCopiar: Array<{ base: string; origen: FotoOrigen }> = [];
    for (const [base, fotos] of porBase) {
      if (fotos.some((f) => f.codigo_curso === acceso.codigoCurso) || yaCopiadas.has(base)) {
        yaEnGaleria++;
        const visible = fotos.find((f) => f.codigo_curso === acceso.codigoCurso)?.id || copiaDe.get(base);
        if (visible) encontradas.push(String(visible));
        continue;
      }
      const origen = fotos.find((f) => !String(f.nombre_original || '').includes('__')) || fotos[0];
      if (origen?.storage_path) aCopiar.push({ base, origen });
    }

    const busquedaId = await registrarBusqueda(supabase, {
      ...registro,
      caras_coincidentes: archivos.length,
      fotos_ya_en_galeria: yaEnGaleria,
      resultado: aCopiar.length + yaEnGaleria > 0 ? 'ok' : 'sin_resultados',
    });

    let nuevas = 0;
    let fallidas = 0;
    for (const { base, origen } of aCopiar.slice(0, MAX_FOTOS_NUEVAS)) {
      // Primero se reserva el hallazgo (índice único): dos búsquedas a la vez no copian dos veces la misma foto.
      const hallazgoId = crypto.randomUUID();
      const { error: errReserva } = await supabase.from('rostros_hallazgos').insert({
        id: hallazgoId, colegio_id: acceso.colegioId, inscripcion_id: familiaId, alumno_nombre: acceso.hijo,
        nombre_base: base, foto_origen_id: origen.id, busqueda_id: busquedaId,
      });
      if (errReserva) {
        if ((errReserva as any).code === '23505') continue;
        throw errReserva;
      }
      try {
        const copiaId = await copiarFotoAlCurso(supabase, origen, acceso, base);
        const { error: errUpd } = await supabase.from('rostros_hallazgos').update({ foto_copia_id: copiaId }).eq('id', hallazgoId);
        if (errUpd) console.warn('[rostro] Copia hecha pero sin anotar en el hallazgo:', errUpd.message);
        nuevas++;
        encontradas.push(copiaId);
      } catch (err: any) {
        fallidas++;
        await supabase.from('rostros_hallazgos').delete().eq('id', hallazgoId); // se puede reintentar
        console.error('[rostro] No se pudo copiar la foto', origen.id, err?.message || err);
      }
    }
    if (busquedaId) {
      await supabase.from('rostros_busquedas').update({ fotos_nuevas: nuevas, ...(fallidas > 0 && nuevas === 0 ? { resultado: 'error' } : {}) }).eq('id', busquedaId);
    }
    if (fallidas > 0 && nuevas === 0 && yaEnGaleria === 0) {
      return res.status(500).json({ success: false, error: 'Encontramos fotos pero no pudimos sumarlas a tu galería. Probá de nuevo en un rato.' });
    }

    return res.json({ success: true, nuevas, yaEnGaleria, sinResultados: nuevas + yaEnGaleria === 0, fotos: encontradas.slice(0, 24) });
  } catch (err: any) {
    console.error('[rostro] Error en la búsqueda:', err?.name || '', err?.message || err);
    return res.status(500).json({ success: false, error: 'No pudimos hacer la búsqueda en este momento. Probá de nuevo en un rato.' });
  }
});

// Panel de Pablo: cada búsqueda (quién, cuándo, qué encontró y DE DÓNDE vino cada copia). La imagen nunca se guarda.
rutas.get('/api/admin/rostros/busquedas', requireAdminAuth, async (req: Request, res: Response) => {
  try {
    const supabase = getServerSupabase();
    if (!supabase) return res.status(503).json({ success: false, error: 'Servicio no disponible' });
    const colegioId = String(req.query.colegioId || '');
    let q = supabase
      .from('rostros_busquedas')
      .select('id, created_at, codigo_curso, inscripcion_id, alumno_nombre, caras_coincidentes, fotos_nuevas, fotos_ya_en_galeria, resultado')
      .order('created_at', { ascending: false })
      .limit(500);
    if (colegioId) q = q.eq('colegio_id', colegioId);
    const { data, error } = await q;
    if (error && !tablaRostrosNoExiste(error)) throw error;
    const busquedas = (data || []) as any[];
    // Origen de cada copia: curso y archivo de la foto original.
    const porBusqueda = new Map<string, Array<{ nombre: string; cursoOrigen: string | null; copiaId: string | null }>>();
    for (const lote of enLotes(busquedas.map((b) => b.id), 100)) {
      const { data: hallazgos, error: errH } = await supabase.from('rostros_hallazgos').select('busqueda_id, nombre_base, foto_origen_id, foto_copia_id').in('busqueda_id', lote);
      if (errH) throw errH;
      const origenes = Array.from(new Set((hallazgos || []).map((h: any) => h.foto_origen_id).filter(Boolean)));
      const cursoDe = new Map<string, string>();
      for (const l2 of enLotes(origenes, 100)) {
        const { data: fotos, error: errF } = await supabase.from('fotos').select('id, codigo_curso').in('id', l2);
        if (errF) throw errF;
        for (const f of fotos || []) cursoDe.set(String(f.id), String(f.codigo_curso || ''));
      }
      for (const h of hallazgos || []) {
        const lista = porBusqueda.get(String(h.busqueda_id)) || [];
        lista.push({ nombre: String(h.nombre_base), cursoOrigen: h.foto_origen_id ? cursoDe.get(String(h.foto_origen_id)) || null : null, copiaId: h.foto_copia_id || null });
        porBusqueda.set(String(h.busqueda_id), lista);
      }
    }
    return res.json({
      success: true,
      busquedas: busquedas.map((b) => ({ ...b, copias: porBusqueda.get(String(b.id)) || [] })),
      configurado: Boolean(clienteRekognition()),
    });
  } catch (err: any) {
    console.error('[rostro] Error al listar búsquedas:', err);
    return res.status(500).json({ success: false, error: 'No pudimos traer las búsquedas.' });
  }
});

/**
 * «Cerrar año»: si se cierra un colegio con buscador (o «todos»), borra la colección de caras en Rekognition, y las
 * filas de `rostros_hallazgos` / `rostros_busquedas`. Las copias en `fotos` se borran con el resto de las fotos del
 * colegio. Sin la migración aplicada no rompe. Devuelve un aviso (si AWS falló) o null.
 */
export async function borrarRostrosDelColegio(supabase: SupabaseClient, colegioId: string): Promise<string | null> {
  let aviso: string | null = null;
  const tieneColeccion = colegioId === 'todos' || colegiosConBuscadorRostro().includes(colegioId);
  if (tieneColeccion) {
    const rekognition = clienteRekognition();
    if (!rekognition) {
      aviso = 'Reconocimiento facial: AWS no está configurado; la colección de caras hay que borrarla a mano (indexar_buscador.py --borrar).';
    } else {
      try {
        await rekognition.send(new DeleteCollectionCommand({ CollectionId: coleccionRekognition() }));
      } catch (err: any) {
        if (err?.name !== 'ResourceNotFoundException') {
          aviso = `Reconocimiento facial: no se pudo borrar la colección de caras en AWS (${err?.name || err?.message || 'error'}); reintentá el cierre o borrala con indexar_buscador.py --borrar.`;
        }
      }
    }
  }
  for (const tabla of ['rostros_hallazgos', 'rostros_busquedas', 'rostros_caras']) {
    const q = supabase.from(tabla).delete();
    const { error } = colegioId === 'todos' ? await q.not('id', 'is', null) : await q.eq('colegio_id', colegioId);
    if (error && !tablaRostrosNoExiste(error)) throw error;
  }
  return aviso;
}

export { rutas as rutasBuscadorRostro };
