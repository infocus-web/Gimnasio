// Galería pública de los colegios (/api/fotos con el código del curso) y la lupa (/api/fotos/:id/lupa)
// (división de server.ts, etapa 5, 10/10/2026). El código es el mismo que estaba en server.ts: sólo se
// movió de lugar.
import type { SupabaseClient } from '@supabase/supabase-js';
import crypto from 'crypto';
import express from 'express';
import type { Request, Response } from 'express';
import { getServerSupabase } from '../nucleo/clientes.js';
import { buscarSeccionPorCodigoSecreto, determinarCodigoCursoServidor } from '../nucleo/codigosCurso.js';
import { limitarFrecuencia, limitarFrecuenciaPersistenteSinEspera } from '../nucleo/limites.js';
import { etiquetasDelAlumno } from '../nucleo/nombres.js';
import { normalizarNombrePorPalabras, traerTodasLasFilas } from '../nucleo/utilidades.js';
import { UUID_FOTO_RE } from '../panel/fotos.js';
import { hijosDeFamiliaConAcceso } from './inscripciones.js';

import { calcularRegion, codigoCorto, encabezadosRecorte, leerPedidoRecorte, obtenerFuenteLupa, recortarConSello, rutaCopiaLupa } from '../../lupa/recorte.js';
const rutas = express.Router();

// Galería pública: fotos reales de un curso puntual, para el portal de familias.
// SEGURIDAD: esta ruta es pública (sin sesión), así que la única puerta de entrada es el
// código secreto de la sección (`codigo_seccion`, ver `codigos_seccion` más arriba). Antes
// esta ruta aceptaba directamente grado/turno/división —datos públicos, visibles en un
// combo del sitio— y devolvía las fotos reales sin pedir ningún código: cualquiera podía
// ver las fotos de cualquier curso con sólo elegir las opciones del desplegable. Ahora el
// grado/turno/división salen del código validado, nunca de lo que mande el navegador.
// 25/10/2026: número visible de la foto (misma regla que src/utils/numeroFoto.ts): «FOTO-3486.jpg» → «3486».
function numeroDeFoto(nombreOriginal: string | null | undefined): string | null {
  const base = String(nombreOriginal || '').replace(/\.[^./\\]+$/, '').split('__')[0];
  const numeros = base.match(/\d+/g);
  return numeros ? numeros[numeros.length - 1].replace(/^0+(?=\d)/, '') : null;
}

rutas.get('/api/fotos', limitarFrecuencia('fotos-galeria', 2000, 10 * 60 * 1000), async (req: Request, res: Response) => {
  try {
    const { codigo } = req.query as Record<string, string | undefined>;
    if (!codigo || !codigo.trim()) {
      return res.status(401).json({ success: false, error: 'Falta el código de acceso para ver esta galería' });
    }
    const supabase = getServerSupabase();
    if (!supabase) {
      return res.status(500).json({ success: false, error: 'Supabase no configurado en el servidor' });
    }

    const seccion = await buscarSeccionPorCodigoSecreto(supabase, codigo);
    if (!seccion) {
      return res.status(401).json({ success: false, error: 'Código de acceso incorrecto o vencido' });
    }

    const codigoCurso = determinarCodigoCursoServidor(seccion.grado, seccion.turno, seccion.division);
    // Auditoría 2026-09-09 (revisión a fondo): antes esto era select('*'), que además de las
    // columnas que la galería pública necesita (categoria, alumno_nombre, grado, division,
    // preview_path, thumb_path) devolvía también storage_path — la ruta interna dentro del
    // bucket privado 'fotos-hd' (las fotos originales, el producto pago). Ese path por sí solo
    // no alcanza para descargar el archivo (el bucket es privado, hace falta una URL firmada
    // que este endpoint nunca genera), pero no hay ningún motivo para exponerlo en una
    // respuesta pública: se acota a las columnas que la vista previa realmente usa.
    // Auditoría 11/10 (FAM-6): paginado con orden estable (PostgREST corta en 1000 filas).
    const data = await traerTodasLasFilas<any>((desde, hasta) =>
      supabase
        .from('fotos')
        .select('id, categoria, alumno_nombre, grado, division, preview_path, thumb_path, created_at, nombre_original')
        .eq('colegio_id', seccion.colegioId)
        .eq('codigo_curso', codigoCurso)
        // 06/10: las familias sólo ven las fotos que Pablo publicó (botón «Publicar» del panel).
        .not('publicada_at', 'is', null)
        .order('created_at', { ascending: true })
        .order('id', { ascending: true })
        .range(desde, hasta)
    );

    // Auditoría 28/9 (privacidad de menores): el código del curso lo tienen todas las familias del
    // curso, y antes esta respuesta traía TODAS las fotos individuales (con su miniatura sin marca
    // de agua): el filtro "cada familia ve sólo a su hijo" estaba únicamente en la pantalla. Ahora
    // el servidor devuelve las individuales etiquetadas sólo a la familia dueña (llave de galería
    // que recibe al ingresar con código + nombre + DNI). Sin llave, no va ninguna individual etiquetada.
    const hijos = await hijosDeFamiliaConAcceso(supabase, req.query.familia, req.query.acceso);
    // Auditoría 03/10 noche (A3): cada hijo ve sólo las etiquetas que MEJOR coinciden con su nombre
    // (ver etiquetasDelAlumno), no cualquier nombre "compatible".
    const etiquetasCurso = (data || []).filter((f: any) => f.categoria === 'individual' && f.alumno_nombre).map((f: any) => f.alumno_nombre);
    const clavesVisibles = new Set<string>();
    for (const n of hijos || []) for (const clave of etiquetasDelAlumno(n, etiquetasCurso)) clavesVisibles.add(clave);
    const fotosVisibles = (data || []).filter(
      // 11/10 (Pablo, «opción 3»): las individuales se suben por curso, sin nombre: una individual SIN nombre la ve
      // todo el curso (como antes del 08/10); una CON nombre, sólo la familia de ese chico.
      (f: any) => f.categoria !== 'individual' || !f.alumno_nombre || clavesVisibles.has(normalizarNombrePorPalabras(f.alumno_nombre))
    )
      // 06/10: la foto con familia/amigos la ve todo el curso; si el fotógrafo la etiquetó con un chico
      // (para ordenarse en el panel), ese nombre no se manda a las demás familias.
      .map((f: any) => (f.categoria === 'familia' && f.alumno_nombre ? { ...f, alumno_nombre: null } : f))
      // 25/10: el número de la foto (lo ve la familia, para pedir «la N° 3486»); el nombre del archivo no se manda.
      .map(({ nombre_original, ...f }: any) => ({ ...f, numero: numeroDeFoto(nombre_original) }));

    // 04/10: ¿el colegio tiene prendido «Muestras con lupa»? (si no, el portal no muestra la lupa).
    const { data: colegioLupa } = await supabase.from('colegios').select('muestras_lupa').eq('id', seccion.colegioId).maybeSingle();

    return res.json({
      success: true,
      fotos: fotosVisibles,
      lupa: colegioLupa?.muestras_lupa === true,
      seccion: { colegioId: seccion.colegioId, grado: seccion.grado, turno: seccion.turno, division: seccion.division }
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err?.message || 'Error al obtener la galería' });
  }
});

// LUPA de la galería (04/10, pedido de Pablo). La muestra que ve la familia está apenas desenfocada
// y dice "PASÁ LA LUPA POR LA IMAGEN"; al pasar la lupa, el navegador pide acá SÓLO el pedacito que
// está mirando (cx, cy = centro de 0 a 1; s = lado como fracción del ancho). Se recorta de una copia
// de 800 px en memoria (nunca se manda el original). Desde el 04/10 va sin sellos (pedido de Pablo);
// el código FAM-xxxxx / CUR-xxxxx se sigue calculando por si se quieren volver a poner. Mismas reglas de acceso que GET /api/fotos: el código del
// curso, y para una individual etiquetada, la llave de la familia dueña. Sólo en colegios con el
// interruptor «Muestras con lupa» prendido.
const accesoLupaGaleria = new Map<string, { hasta: number; storagePath: string; sello: string }>();
const MS_ACCESO_LUPA = 60 * 1000; // auditoría 11/10 (FAM-7): antes 5 min (despublicar tardaba en cortar la lupa)

async function accesoLupaFoto(
  supabase: SupabaseClient,
  fotoId: string,
  query: Record<string, unknown>
): Promise<{ storagePath: string; sello: string } | null> {
  const codigo = String(query.codigo || '').trim();
  const familia = typeof query.familia === 'string' ? query.familia : '';
  const acceso = typeof query.acceso === 'string' ? query.acceso : '';
  const clave = crypto.createHash('sha256').update(`${fotoId}|${codigo}|${familia}|${acceso}`).digest('hex');
  const guardado = accesoLupaGaleria.get(clave);
  if (guardado && guardado.hasta > Date.now()) return guardado;
  if (!codigo) return null;

  const seccion = await buscarSeccionPorCodigoSecreto(supabase, codigo);
  if (!seccion) return null;
  // Sólo si el colegio tiene prendido «Muestras con lupa» (interruptor del panel).
  const { data: colegio, error: errColegio } = await supabase.from('colegios').select('muestras_lupa').eq('id', seccion.colegioId).maybeSingle();
  if (errColegio) throw errColegio;
  if (colegio?.muestras_lupa !== true) return null;
  const codigoCurso = determinarCodigoCursoServidor(seccion.grado, seccion.turno, seccion.division);
  const { data: foto, error } = await supabase
    .from('fotos')
    .select('id, categoria, alumno_nombre, storage_path, colegio_id, codigo_curso, publicada_at')
    .eq('id', fotoId)
    .maybeSingle();
  if (error) throw error;
  if (!foto || !foto.storage_path || foto.colegio_id !== seccion.colegioId || foto.codigo_curso !== codigoCurso) return null;
  // 06/10: una foto sin publicar no se muestra (ni de a pedacitos).
  if (!foto.publicada_at) return null;

  const hijos = familia && acceso ? await hijosDeFamiliaConAcceso(supabase, familia, acceso) : null;
  // 11/10 (Pablo): una individual sin nombre la ve todo el curso (igual que la galería); con nombre, sólo su familia.
  if (foto.categoria === 'individual' && foto.alumno_nombre) {
    // Igual que la galería: sólo la familia cuyo hijo MEJOR coincide con la etiqueta.
    if (!hijos || hijos.length === 0) return null;
    const etiquetadas = await traerTodasLasFilas<any>((desde, hasta) =>
      supabase
        .from('fotos')
        .select('alumno_nombre')
        .eq('colegio_id', seccion.colegioId)
        .eq('codigo_curso', codigoCurso)
        .eq('categoria', 'individual')
        .not('alumno_nombre', 'is', null)
        .not('publicada_at', 'is', null)
        .order('created_at', { ascending: true })
        .order('id', { ascending: true })
        .range(desde, hasta)
    );
    const etiquetasCurso = (etiquetadas || []).map((f: any) => f.alumno_nombre);
    const visibles = new Set<string>();
    for (const n of hijos) for (const c of etiquetasDelAlumno(n, etiquetasCurso)) visibles.add(c);
    if (!visibles.has(normalizarNombrePorPalabras(foto.alumno_nombre))) return null;
  }

  const sello = hijos ? `FAM-${codigoCorto(familia)}` : `CUR-${codigoCorto(`${seccion.colegioId}|${codigoCurso}`)}`;
  const resultado = { hasta: Date.now() + MS_ACCESO_LUPA, storagePath: String(foto.storage_path), sello };
  accesoLupaGaleria.set(clave, resultado);
  if (accesoLupaGaleria.size > 5000) accesoLupaGaleria.clear();
  return resultado;
}

// Auditoría 08/10 (A1): además del tope en memoria, uno persistente por IP y por hora (vale para todas
// las instancias): frena a quien recorre la galería entera armando las fotos limpias con un script.
rutas.get('/api/fotos/:id/lupa', limitarFrecuencia('fotos-lupa', 3000, 10 * 60 * 1000), limitarFrecuenciaPersistenteSinEspera('fotos-lupa-hora', 2000, 60 * 60 * 1000), async (req: Request, res: Response) => {
  try {
    const fotoId = String(req.params.id || '');
    const pedido = leerPedidoRecorte(req.query as Record<string, unknown>);
    if (!UUID_FOTO_RE.test(fotoId) || !pedido) {
      return res.status(400).json({ success: false, error: 'Pedido de lupa inválido' });
    }
    const supabase = getServerSupabase();
    if (!supabase) {
      return res.status(500).json({ success: false, error: 'Supabase no configurado en el servidor' });
    }
    const acceso = await accesoLupaFoto(supabase, fotoId, req.query as Record<string, unknown>);
    if (!acceso) {
      return res.status(404).json({ success: false, error: 'No encontramos esa foto' });
    }
    // 09/10: la copia de 800 px queda guardada al lado del original (bucket privado) para que la
    // primera vez no haya que bajar el original entero (lupa/recorte.ts, rutaCopiaLupa).
    const rutaCopia = rutaCopiaLupa(acceso.storagePath);
    const fuente = await obtenerFuenteLupa(
      `colegio:${fotoId}:${acceso.storagePath}`,
      async () => {
        const { data: archivo, error } = await supabase.storage.from('fotos-hd').download(acceso.storagePath);
        if (error || !archivo) throw error || new Error('No se pudo descargar el original');
        return Buffer.from(await archivo.arrayBuffer());
      },
      {
        leer: async () => {
          const { data, error } = await supabase.storage.from('fotos-hd').download(rutaCopia);
          return error || !data ? null : Buffer.from(await data.arrayBuffer());
        },
        guardar: async (copia) => {
          await supabase.storage.from('fotos-hd').upload(rutaCopia, copia, { contentType: 'image/jpeg', upsert: true });
        },
      }
    );
    const region = calcularRegion(fuente, pedido);
    // 04/10: sin sellos dentro de la lupa (pedido de Pablo).
    const recorte = await recortarConSello(fuente, region);
    res.set(encabezadosRecorte(region, fuente));
    return res.send(recorte);
  } catch (err: any) {
    console.error('[lupa] No se pudo armar el recorte:', err);
    return res.status(500).json({ success: false, error: 'No pudimos mostrar la lupa' });
  }
});

export { rutas as rutasGaleria };
