// Respuestas del panel a las familias (14/10/2026, auditoría). Salió de consultas.ts (cerca de las 1.000
// líneas) con estos arreglos:
// - «Responder» y «Escribir a esta familia» no tenían freno ante un reintento (corte de red, doble clic): la
//   familia recibía dos veces el mismo email y «Escribir…» creaba otra conversación por intento. Ahora el panel
//   manda una `clave` (una por texto a enviar): Resend recibe la clave de idempotencia
//   `respuesta-<consulta>-<clave>` y el mensaje queda guardado con `clave_envio` (migración 20261014020200);
//   un reintento con la misma clave responde «listo» sin mandar ni guardar de nuevo, e «Iniciar» reusa la
//   conversación creada con esa clave.
// - «Archivar» (o cualquier cambio de estado) desde una lista vieja enterraba una respuesta nueva de la
//   familia (el correo entrante la vuelve a «nueva»): el panel manda `estadoAnterior` y el cambio sólo se
//   aplica si la consulta sigue en ese estado (409 «la familia escribió de nuevo» si no).
import type { SupabaseClient } from '@supabase/supabase-js';
import express from 'express';
import type { Request, Response } from 'express';
import { requireAdminAuth } from '../nucleo/auth.js';
import { getResendClient, getServerSupabase } from '../nucleo/clientes.js';
import { escapeHtml } from '../nucleo/utilidades.js';
import { dispararRutinaClaude, rutinaClaudeConfigurada, textoParaPegarEnClaude, textoPedidoClaude } from './pedirAClaude.js';

const rutas = express.Router();
const ESTADOS = ['nueva', 'en_proceso', 'resuelta', 'archivada'];
const CLAVE_RE = /^[A-Za-z0-9-]{8,64}$/;

/** La clave de envío que mandó el panel (null si no vino o no es válida: se envía como antes). */
export function claveEnvioValida(valor: unknown): string | null {
  return typeof valor === 'string' && CLAVE_RE.test(valor) ? valor : null;
}

/** Columna `clave_envio` todavía sin crear (migración sin aplicar): se sigue sin la clave. */
function faltaColumnaClave(error: any): boolean {
  return Boolean(error) && /clave_envio/.test(String(error?.message || '')) && ['42703', 'PGRST204', 'PGRST200'].includes(String(error?.code || ''));
}

async function mensajeYaEnviado(supabase: SupabaseClient, clave: string): Promise<{ consulta_id: string } | null> {
  const { data, error } = await supabase.from('consultas_familias_mensajes').select('consulta_id').eq('clave_envio', clave).limit(1).maybeSingle();
  if (error) {
    if (!faltaColumnaClave(error)) console.error('[Consultas] No se pudo revisar la clave de envío:', error);
    return null;
  }
  return data ?? null;
}

// Envía la respuesta por email a la familia, la guarda en la conversación y pasa la consulta a
// "en proceso". La usan el botón "Responder" del panel, «Escribir a esta familia» y el envío automático.
// Devuelve `yaEnviada` si esa clave ya se había mandado (no manda ni guarda nada de nuevo).
export async function enviarRespuestaConsulta(
  supabase: SupabaseClient,
  consulta: { id: string; nombre: string; email: string; asunto: string; estado: string },
  mensaje: string,
  automatica: boolean,
  opciones: { primerMensaje?: boolean; clave?: string | null } = {}
): Promise<{ yaEnviada: boolean }> {
  const clave = opciones.clave || null;
  if (clave && (await mensajeYaEnviado(supabase, clave))) return { yaEnviada: true };
  const resend = getResendClient();
  if (!resend) throw new Error('El servicio de email no está configurado.');
  // Una conversación iniciada desde el panel lleva el asunto tal cual (sin "Re:").
  const asuntoEmail = opciones.primerMensaje ? consulta.asunto : `Re: ${consulta.asunto}`;
  const resultado = await resend.emails.send({
    from: process.env.RESEND_FROM_EMAIL || 'Retrato Escolar <fotos@retratoescolar.com.ar>',
    replyTo: `consulta-${consulta.id}@${process.env.RESEND_INBOUND_DOMAIN || 'respuestas.retratoescolar.com.ar'}`,
    to: [consulta.email],
    subject: asuntoEmail,
    // Auditoría 03/10 noche: en las respuestas AUTOMÁTICAS el saludo no lleva el nombre que escribió
    // quien mandó la consulta (texto libre, no verificado, que llegaba con la marca de Retrato Escolar).
    html: `<div style="font-family:Arial,sans-serif;max-width:640px;margin:auto;color:#0f172a"><p>${automatica ? '¡Hola!' : `Hola ${escapeHtml(consulta.nombre)},`}</p><div style="white-space:pre-wrap;line-height:1.6">${escapeHtml(mensaje)}</div><p style="margin-top:24px">Saludos,<br><strong>Retrato Escolar</strong></p><hr style="margin:24px 0;border:0;border-top:1px solid #e2e8f0"><p style="font-size:12px;color:#64748b">Podés responder directamente a este correo si necesitás continuar la conversación.</p></div>`,
  }, clave ? { idempotencyKey: `respuesta-${consulta.id}-${clave}` } : undefined);
  if (resultado.error) throw resultado.error;

  const fila: Record<string, unknown> = {
    consulta_id: consulta.id,
    direccion: 'saliente',
    remitente: process.env.RESEND_FROM_EMAIL || 'fotos@retratoescolar.com.ar',
    destinatario: consulta.email,
    asunto: asuntoEmail,
    contenido: mensaje,
    resend_email_id: resultado.data?.id || null,
    automatica,
    ...(clave ? { clave_envio: clave } : {}),
  };
  let { error: messageError } = await supabase.from('consultas_familias_mensajes').insert(fila);
  if (messageError && faltaColumnaClave(messageError)) {
    delete fila.clave_envio;
    ({ error: messageError } = await supabase.from('consultas_familias_mensajes').insert(fila));
  }
  // 23505 = otro intento con la misma clave ya lo guardó (Resend no lo mandó dos veces).
  if (messageError && String((messageError as any).code) !== '23505') console.error('[Consultas] El correo se envió, pero no se guardó en el historial:', messageError);

  const cambios: Record<string, unknown> = { borrador_ia: null, updated_at: new Date().toISOString() };
  if (consulta.estado === 'nueva') cambios.estado = 'en_proceso';
  const { error: updateError } = await supabase.from('consultas_familias').update(cambios).eq('id', consulta.id);
  if (updateError) console.error('[Consultas] La respuesta se envió, pero no se actualizó la consulta:', updateError);
  return { yaEnviada: false };
}

rutas.patch('/api/admin/consultas-familias/:id/estado', requireAdminAuth, async (req: Request, res: Response) => {
  try {
    const estado = String(req.body?.estado || '');
    if (!ESTADOS.includes(estado)) return res.status(400).json({ success: false, error: 'Estado inválido.' });
    const estadoAnterior = typeof req.body?.estadoAnterior === 'string' && ESTADOS.includes(req.body.estadoAnterior) ? req.body.estadoAnterior : null;
    const supabase = getServerSupabase();
    if (!supabase) return res.status(500).json({ success: false, error: 'Supabase no configurado.' });
    let consulta = supabase.from('consultas_familias').update({ estado, updated_at: new Date().toISOString() }).eq('id', req.params.id);
    if (estadoAnterior) consulta = consulta.eq('estado', estadoAnterior);
    const { data, error } = await consulta.select('id').maybeSingle();
    if (error) throw error;
    if (!data) {
      const { data: actual } = await supabase.from('consultas_familias').select('estado').eq('id', req.params.id).maybeSingle();
      if (!actual) return res.status(404).json({ success: false, error: 'No encontramos la consulta.' });
      return res.status(409).json({ success: false, estado: actual.estado, error: actual.estado === 'nueva' ? 'La familia escribió de nuevo: revisá su mensaje antes de cambiar el estado.' : 'La consulta cambió mientras tanto. Recargá la lista.' });
    }
    return res.json({ success: true, consulta: data });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err?.message || 'No se pudo actualizar la consulta.' });
  }
});

// 25/10/2026 (Pablo): marca «Atención especial» (pestaña propia; la IA nunca la responde sola). No cambia el estado.
rutas.patch('/api/admin/consultas-familias/:id/especial', requireAdminAuth, async (req: Request, res: Response) => {
  try {
    if (typeof req.body?.valor !== 'boolean') return res.status(400).json({ success: false, error: 'Valor inválido.' });
    const supabase = getServerSupabase();
    if (!supabase) return res.status(500).json({ success: false, error: 'Supabase no configurado.' });
    const { data, error } = await supabase.from('consultas_familias').update({ atencion_especial: req.body.valor }).eq('id', req.params.id).select('id').maybeSingle();
    if (error) {
      if (String(error.message || '').includes('atencion_especial')) {
        return res.status(500).json({ success: false, error: 'Falta aplicar la migración 20261025190000_consultas_atencion_especial.sql en Supabase.' });
      }
      throw error;
    }
    if (!data) return res.status(404).json({ success: false, error: 'No encontramos la consulta.' });
    return res.json({ success: true });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err?.message || 'No se pudo marcar la consulta.' });
  }
});

// "Escribir a esta familia" (pedido de Pablo, 25/9): el fotógrafo le escribe a una familia desde
// el buscador de alumnos sin que ella haya consultado antes. Se crea una conversación en Consultas
// (origen "panel") y el email sale igual que una respuesta: desde el dominio, con reply-to a la
// dirección de la conversación, así lo que conteste la familia vuelve al mismo hilo.
rutas.post('/api/admin/consultas-familias/iniciar', requireAdminAuth, async (req: Request, res: Response) => {
  try {
    const { nombre, email, telefono, colegio, numeroPedido, asunto, mensaje } = req.body || {};
    const clave = claveEnvioValida(req.body?.clave);
    const datos = {
      nombre: String(nombre || '').trim().slice(0, 120) || 'Familia',
      email: String(email || '').trim().toLowerCase(),
      telefono: String(telefono || '').trim().slice(0, 50),
      colegio: String(colegio || '').trim().slice(0, 160),
      numeroPedido: String(numeroPedido || '').trim().slice(0, 80),
      asunto: String(asunto || '').trim(),
      mensaje: String(mensaje || '').trim(),
    };
    if (datos.nombre.length < 2) datos.nombre = 'Familia';
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(datos.email) || datos.email.length > 254) return res.status(400).json({ success: false, error: 'El email de la familia no es válido.' });
    if (datos.asunto.length < 2 || datos.asunto.length > 160) return res.status(400).json({ success: false, error: 'Escribí un asunto (entre 2 y 160 caracteres).' });
    if (datos.mensaje.length < 5 || datos.mensaje.length > 3000) return res.status(400).json({ success: false, error: 'El mensaje debe tener entre 5 y 3000 caracteres.' });

    const supabase = getServerSupabase();
    if (!supabase) return res.status(500).json({ success: false, error: 'Supabase no configurado.' });
    if (!getResendClient()) return res.status(503).json({ success: false, error: 'El servicio de email no está configurado.' });

    // 14/10: con la misma clave se reusa la conversación del intento anterior (no se crea otra).
    let consulta: any = null;
    if (clave) {
      const { data, error } = await supabase.from('consultas_familias').select('id,nombre,email,asunto,estado').eq('clave_envio', clave).limit(1).maybeSingle();
      if (error && !faltaColumnaClave(error)) throw error;
      consulta = data ?? null;
    }
    let creadaAhora = !consulta;
    if (!consulta) {
      const fila: Record<string, unknown> = {
        nombre: datos.nombre,
        email: datos.email,
        telefono: datos.telefono || null,
        colegio: datos.colegio || null,
        numero_pedido: datos.numeroPedido || null,
        asunto: datos.asunto,
        mensaje: datos.mensaje,
        estado: 'en_proceso',
        origen: 'panel',
        ...(clave ? { clave_envio: clave } : {}),
      };
      let { data, error } = await supabase.from('consultas_familias').insert(fila).select('id,nombre,email,asunto,estado').single();
      if (error && faltaColumnaClave(error)) {
        delete fila.clave_envio;
        ({ data, error } = await supabase.from('consultas_familias').insert(fila).select('id,nombre,email,asunto,estado').single());
      }
      if (error && clave && String((error as any).code) === '23505') {
        // Otro intento con la misma clave la creó recién: se usa esa. 14/10/2026: no es nuestra, así que si
        // este envío falla no se borra (la conversación es del otro pedido, que pudo haber mandado el email).
        creadaAhora = false;
        ({ data, error } = await supabase.from('consultas_familias').select('id,nombre,email,asunto,estado').eq('clave_envio', clave).single());
      }
      if (error || !data) throw error || new Error('No se pudo crear la conversación.');
      consulta = data;
    }

    try {
      await enviarRespuestaConsulta(supabase, consulta, datos.mensaje, false, { primerMensaje: true, clave });
    } catch (errorEnvio) {
      // Si el email no salió, no se deja una conversación "fantasma" que parezca enviada.
      if (creadaAhora) await supabase.from('consultas_familias').delete().eq('id', consulta.id);
      throw errorEnvio;
    }
    return res.json({ success: true, consultaId: consulta.id });
  } catch (err: any) {
    console.error('[Consultas] Error al iniciar conversación:', err);
    return res.status(500).json({ success: false, error: 'No pudimos enviar el email. Intentá nuevamente.' });
  }
});

rutas.post('/api/admin/consultas-familias/:id/responder', requireAdminAuth, async (req: Request, res: Response) => {
  try {
    const mensaje = String(req.body?.mensaje || '').trim();
    if (mensaje.length < 2 || mensaje.length > 5000) {
      return res.status(400).json({ success: false, error: 'La respuesta debe tener entre 2 y 5000 caracteres.' });
    }

    const supabase = getServerSupabase();
    if (!supabase) return res.status(500).json({ success: false, error: 'Supabase no configurado.' });
    const { data: consulta, error } = await supabase
      .from('consultas_familias')
      .select('id,nombre,email,asunto,estado')
      .eq('id', req.params.id)
      .single();
    if (error || !consulta) return res.status(404).json({ success: false, error: 'No encontramos la consulta.' });

    if (!getResendClient()) return res.status(503).json({ success: false, error: 'El servicio de email no está configurado.' });
    const { yaEnviada } = await enviarRespuestaConsulta(supabase, consulta, mensaje, false, { clave: claveEnvioValida(req.body?.clave) });
    return res.json({ success: true, yaEnviada });
  } catch (err: any) {
    console.error('[Consultas] Error al responder:', err);
    return res.status(500).json({ success: false, error: 'No pudimos enviar la respuesta. Intentá nuevamente.' });
  }
});

// 27/10/2026 (Pablo): «Pedirle a Claude» — abre una sesión de Claude Code que investiga y soluciona el caso
// (pedirAClaude.ts). Devuelve el link de la sesión para abrirla en otra pestaña. No cambia la consulta.
rutas.post('/api/admin/consultas-familias/:id/pedir-a-claude', requireAdminAuth, async (req: Request, res: Response) => {
  try {
    const supabase = getServerSupabase();
    if (!supabase) return res.status(500).json({ success: false, error: 'Supabase no configurado.' });
    const { data: consulta, error } = await supabase
      .from('consultas_familias')
      .select('id, nombre, email, asunto, mensaje, colegio, numero_pedido, created_at, verificacion_ia')
      .eq('id', req.params.id)
      .maybeSingle();
    if (error) throw error;
    if (!consulta) return res.status(404).json({ success: false, error: 'No encontramos la consulta.' });
    const { data: mensajes } = await supabase
      .from('consultas_familias_mensajes')
      .select('direccion, contenido, created_at')
      .eq('consulta_id', consulta.id)
      .order('created_at', { ascending: false })
      .limit(12);
    const nota = typeof req.body?.nota === 'string' ? req.body.nota : '';
    const caso = textoPedidoClaude(consulta, (mensajes || []).reverse(), nota);
    // 28/10/2026: sin rutina configurada (la cuenta no tiene el disparador por API), el panel copia el caso y abre Claude.
    if (!rutinaClaudeConfigurada()) return res.json({ success: true, texto: textoParaPegarEnClaude(caso) });
    const r = await dispararRutinaClaude(caso);
    if (!r.ok) return res.status(r.status || 502).json({ success: false, error: r.error || 'No pudimos pedirle el caso a Claude.' });
    return res.json({ success: true, url: r.url });
  } catch (err: any) {
    console.error('[Pedirle a Claude] Error:', err);
    return res.status(500).json({ success: false, error: 'No pudimos pedirle el caso a Claude.' });
  }
});

export { rutas as rutasConsultasAdmin };
