// Acciones del panel sobre una inscripción ya cargada (14/10/2026, auditoría): mandar el email con el código,
// rechazar y anotar «WhatsApp enviado». Salieron de inscripciones.ts (que estaba en su techo de líneas) con
// estos arreglos:
// - «Enviar todos los emails pendientes» podía mandar dos veces el mismo código (dos pestañas, o el bucle del
//   panel que seguía corriendo): ahora el servidor «reserva» la fila (notificacion_email_enviada → true) antes
//   de mandar, y la libera si falla; además Resend recibe una clave de idempotencia. El botón manual de reenvío
//   manda `reenviar: true` y sí sale aunque ya figure enviado.
// - «Rechazar» pisaba una inscripción ya aprobada (la de una lista vieja): ahora sólo rechaza pendientes
//   (409 si no), salvo `forzar: true`, igual que «Aprobar».
// - notificacion_whatsapp_enviada nunca se marcaba: ahora el panel lo anota al abrir el chat de WhatsApp.
import crypto from 'crypto';
import express from 'express';
import type { Request, Response } from 'express';
import { requireAdminAuth } from '../nucleo/auth.js';
import { getServerSupabase } from '../nucleo/clientes.js';
import { enviarCorreoCodigoAcceso } from './accesoFamilias.js';

const rutas = express.Router();

/**
 * 10/10/2026 (prueba de Pablo: el email del código sólo nombraba al primer hijo, no a su hermana): todos
 * los chicos de una inscripción —el principal y sus hermanos— para la lista «Alumnos vinculados» del email.
 */
export function alumnosParaCorreo(principal: { nombre: string; apellido: string; grado: string; division: string; turno: string }, hermanos: unknown) {
  const lista = [principal];
  for (const h of Array.isArray(hermanos) ? hermanos : []) {
    if (!h || typeof h !== 'object') continue;
    const nombre = String((h as any).alumnoNombre || (h as any).alumno_nombre || '').trim();
    if (!nombre) continue;
    lista.push({
      nombre,
      apellido: String((h as any).alumnoApellido || (h as any).alumno_apellido || '').trim(),
      grado: (h as any).grado,
      division: (h as any).division,
      turno: (h as any).turno,
    });
  }
  return lista;
}

/** Los chicos de una fila de `inscripciones` guardada (principal + hermanos). */
export function alumnosDeInscripcion(fila: any) {
  return alumnosParaCorreo(
    { nombre: String(fila?.alumno_nombre || '').trim(), apellido: String(fila?.alumno_apellido || '').trim(), grado: fila?.grado, division: fila?.division, turno: fila?.turno },
    fila?.hermanos
  );
}

/** Clave de Resend del email con el código: una por inscripción y código (el código va resumido). */
export function claveCodigoAcceso(id: string, codigo: string, reenvio = false, ahora = Date.now()): string {
  const base = `codigo-acceso-${id}-${crypto.createHash('sha256').update(String(codigo)).digest('hex').slice(0, 16)}`;
  return reenvio ? `${base}-r${Math.floor(ahora / 120_000)}` : base;
}

// Envía por email (de verdad, vía Resend) el Código de Acceso a una familia ya aprobada.
// Se llama justo después de aprobar, o para reintentar el envío si falló la primera vez.
rutas.post('/api/admin/inscripciones/:id/enviar-email', requireAdminAuth, async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const reenviar = req.body?.reenviar === true;
    const supabase = getServerSupabase();
    if (!supabase) {
      return res.status(500).json({ success: false, error: 'Supabase no configurado en el servidor' });
    }

    const { data: existente, error: errGet } = await supabase.from('inscripciones').select('*').eq('id', id).single();
    if (errGet || !existente) {
      return res.status(404).json({ success: false, error: 'Inscripción no encontrada' });
    }
    if (!existente.codigo_asignado) {
      return res.status(400).json({ success: false, error: 'Esta inscripción todavía no tiene un código asignado. Aprobala primero.' });
    }
    if (!existente.email) {
      return res.status(400).json({ success: false, error: 'Esta familia no cargó un email.' });
    }

    // Reserva: sólo la primera llamada pasa la marca de false/null a true; las demás no vuelven a mandar.
    // 14/10/2026: limitación aceptada: si la función muere entre la marca y Resend, la marca queda en true
    // (inscripciones no tiene una columna con la hora de la marca para liberarla sola; updated_at la tocan
    // otras acciones). El panel muestra `yaEnviado` como «ya figuraba enviado» (no como enviado ahora) y
    // «Reenviar» de la ficha manda igual.
    if (!reenviar) {
      const { data: reservada, error: errReserva } = await supabase
        .from('inscripciones')
        .update({ notificacion_email_enviada: true, updated_at: new Date().toISOString() })
        .eq('id', id)
        .not('notificacion_email_enviada', 'is', true)
        .select('id');
      if (errReserva) throw errReserva;
      if (!reservada || reservada.length === 0) return res.json({ success: true, yaEnviado: true });
    }
    const liberar = async () => {
      if (reenviar) return;
      const { error } = await supabase.from('inscripciones').update({ notificacion_email_enviada: false }).eq('id', id);
      if (error) console.error('[inscripciones] No se pudo liberar la marca del email fallido:', error);
    };

    let resultado: Awaited<ReturnType<typeof enviarCorreoCodigoAcceso>>;
    try {
      resultado = await enviarCorreoCodigoAcceso({
        to: existente.email,
        padreNombre: existente.padre_nombre,
        colegioNombre: existente.colegio_nombre,
        codigo: existente.codigo_asignado,
        alumnos: alumnosDeInscripcion(existente),
        solicitaFotoHermanos: Boolean(existente.solicita_foto_hermanos),
        idempotencyKey: claveCodigoAcceso(String(id), String(existente.codigo_asignado), reenviar),
      });
    } catch (errEnvio) {
      await liberar();
      throw errEnvio;
    }

    if (!resultado.success) {
      await liberar();
      return res.status(502).json({ success: false, error: resultado.error || 'No se pudo enviar el email' });
    }

    if (reenviar) {
      await supabase
        .from('inscripciones')
        .update({ notificacion_email_enviada: true, updated_at: new Date().toISOString() })
        .eq('id', id);
    }

    return res.json({ success: true, messageId: (resultado as any).messageId });
  } catch (err: any) {
    console.error('Error al enviar email de código de acceso:', err);
    return res.status(500).json({ success: false, error: err?.message || 'Error al enviar el email' });
  }
});

rutas.post('/api/admin/inscripciones/:id/rechazar', requireAdminAuth, async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const supabase = getServerSupabase();
    if (!supabase) {
      return res.status(500).json({ success: false, error: 'Supabase no configurado en el servidor' });
    }
    let consulta = supabase
      .from('inscripciones')
      .update({ estado: 'rechazado', updated_at: new Date().toISOString() })
      .eq('id', id);
    if (req.body?.forzar !== true) consulta = consulta.eq('estado', 'pendiente');
    const { data, error } = await consulta.select().maybeSingle();
    if (error) throw error;
    if (!data) {
      const { data: actual, error: errActual } = await supabase.from('inscripciones').select('estado').eq('id', id).maybeSingle();
      if (errActual) throw errActual;
      if (!actual) return res.status(404).json({ success: false, error: 'Inscripción no encontrada' });
      return res.status(409).json({ success: false, estado: actual.estado, error: `Esta inscripción está «${actual.estado}»: sólo se rechazan las pendientes. Recargá la lista.` });
    }
    return res.json({ success: true, inscripcion: data });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err?.message || 'Error al rechazar inscripción' });
  }
});

rutas.post('/api/admin/inscripciones/:id/whatsapp-enviado', requireAdminAuth, async (req: Request, res: Response) => {
  try {
    const supabase = getServerSupabase();
    if (!supabase) return res.status(500).json({ success: false, error: 'Supabase no configurado en el servidor' });
    const { data, error } = await supabase
      .from('inscripciones')
      .update({ notificacion_whatsapp_enviada: true, updated_at: new Date().toISOString() })
      .eq('id', req.params.id)
      .select('id, notificacion_whatsapp_enviada')
      .maybeSingle();
    if (error) throw error;
    if (!data) return res.status(404).json({ success: false, error: 'Inscripción no encontrada' });
    return res.json({ success: true, inscripcion: data });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err?.message || 'No se pudo anotar el WhatsApp enviado' });
  }
});

export { rutas as rutasInscripcionesAdmin };
