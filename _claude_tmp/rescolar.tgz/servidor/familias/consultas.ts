// Consultas de las familias: formulario, bandeja del panel, borrador y respuestas automáticas con IA
// (con el contexto del negocio y del evento de hermanos), campaña de pago anticipado y mensajes nuevos
// desde el panel (división de server.ts, etapa 5, 10/10/2026). El código es el mismo que estaba en
// server.ts (secciones "1. CONFIGURACIÓN" —el contexto de la IA— y "4C. CONSULTAS DE FAMILIAS"): sólo
// se movió. correoEntrante.ts usa procesarConsultaConIA y conLimiteDeTiempo.
import type { SupabaseClient } from '@supabase/supabase-js';
import crypto from 'crypto';
import express from 'express';
import type { Request, Response } from 'express';
import { mismoDatoSeccion } from '../entrega/correos.js';
import { requireAdminAuth } from '../nucleo/auth.js';
import { casillaAvisosAdmin, getResendClient, getServerSupabase, resendReplyTo } from '../nucleo/clientes.js';
import { AVISO_IA_SATURADA, ERROR_IA_NO_CONFIGURADA, esIaSaturada, generarTextoIA, iaConfigurada } from '../nucleo/ia.js';
import { hayCupoGlobal, hayCupoPorClave, limitarFrecuencia } from '../nucleo/limites.js';
import { escapeHtml, normalizarNombrePorPalabras, traerTodasLasFilas } from '../nucleo/utilidades.js';
import { enviarRespuestaConsulta } from './consultasAdmin.js';
import { colegioTieneBuscadorRostro } from '../nucleo/rostros.js';
import { contextoNegocioConsultas, fijarNovedadesEquipo } from './contextoConsultas.js';
import { diaLegible } from './convocatoriaFaltantes.js';
import { crearBuscadorEnNomina, cursosDeLaNomina, cursosDelGradoEnTexto, mensajeCursoFueraDeNomina } from './cursosNomina.js';
import { investigarYResponder } from './agenteConsultas.js';
import { analisisParaPanel, analisisPermiteEnvio, redactarYControlar, type DecisionIA } from './respuestaVerificada.js';
import { buscarInscripcionesPorNombre, cargarNominaColegio, clasesDeFotosDelCurso, consultasAnteriores, datosFotoHermanos, enmascararEmail, nombreParecidoEnNomina, type AlumnoNomina } from './fichaFamiliaExtra.js';

const rutas = express.Router();

// 08/10 (pedido de Pablo): la foto de hermanos NO es gratis: se vende aparte, como un evento del módulo
// de eventos («Fotos de Hermanos juntos», BROTHERS2026-D3EB). Antes la IA respondía que no tenía costo.
// Los precios, el día y el lugar salen del evento más nuevo cuyo nombre dice «herman», así la IA no
// queda desactualizada si se cambian desde el panel de eventos.
type EventoFotoHermanos = {
  precio_digital: number | null;
  precio_15x21: number | null;
  precio_20x30: number | null;
  impresa_incluye_digital: boolean | null;
  fecha_evento: string | null;
  lugar: string | null;
  /** 29/10: para decir dónde se ven las fotos que ya se sacaron. */
  codigo?: string | null;
  publicado?: boolean | null;
  fotos?: number;
};

function describirEventoFotoHermanos(ev: EventoFotoHermanos | null): string {
  if (!ev) return '';
  const $ = (n: number) => `$${n.toLocaleString('es-AR')}`;
  const formatos: string[] = [];
  if (Number(ev.precio_digital) > 0) formatos.push(`digital ${$(Number(ev.precio_digital))}`);
  if (Number(ev.precio_15x21) > 0) formatos.push(`impresa 15x21 ${$(Number(ev.precio_15x21))}`);
  if (Number(ev.precio_20x30) > 0) formatos.push(`impresa 20x30 ${$(Number(ev.precio_20x30))}`);
  if (formatos.length === 0) return '';
  const incluye = ev.impresa_incluye_digital && Number(ev.precio_digital) > 0 ? ' (cada impresa incluye también la digital)' : '';
  const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(String(ev.fecha_evento || ''));
  const fecha = m ? `${m[3]}/${m[2]}/${m[1]}` : '';
  const lugar = String(ev.lugar || '').trim();
  // 14/10/2026: el lugar puede estar definido sin el día (Pablo: «se harán en la misma escuela»).
  // 29/10 (Pablo): ya no se dice «el día no está definido»: los días de toma salen de las NOVEDADES DEL EQUIPO y de la
  // citación de cada familia (ficha). Acá sólo el lugar/fecha si están cargados y dónde se ven las fotos publicadas.
  const cuando = fecha && lugar
    ? `Día y lugar de la foto de hermanos: ${fecha}, ${lugar}.`
    : lugar
      ? `Lugar de la foto de hermanos: ${lugar}. Los días de toma son los que figuran en las NOVEDADES DEL EQUIPO y en la citación de la ficha de la familia.`
      : 'Los días de toma son los que figuran en las NOVEDADES DEL EQUIPO y en la citación de la ficha de la familia.';
  const publicadas = ev.publicado && ev.codigo && Number(ev.fotos) > 0
    ? `\n  YA HAY ${ev.fotos} FOTOS DE HERMANOS PUBLICADAS (las de las tomas ya hechas): se ven y se compran en retratoescolar.com.ar/eventos/${ev.codigo} (no en la galería del kit). Si la familia ya se sacó la foto, decile que la busque ahí.`
    : '';
  return `  Precio por foto de hermanos: ${formatos.join(', ')}${incluye}.\n  ${cuando}${publicadas}`;
}

let cacheEventoFotoHermanos: { texto: string; vence: number } | null = null;

// 25/10/2026: «Lo que la IA tiene que saber» (Consultas): se relee cada 30 s, así la IA sabe las decisiones del momento.
let novedadesVencen = 0;
async function refrescarNovedadesEquipo(): Promise<void> {
  if (novedadesVencen > Date.now()) return;
  try {
    const supabase = getServerSupabase();
    if (!supabase) return;
    // borradores_admin: sólo el servidor (configuracion tiene lectura pública). Ver novedadesIa.ts.
    const { data, error } = await supabase.from('borradores_admin').select('contenido').eq('clave', 'novedades-ia').abortSignal(AbortSignal.timeout(4000)).maybeSingle();
    if (error) throw error;
    fijarNovedadesEquipo(typeof data?.contenido === 'string' ? data.contenido : '');
    novedadesVencen = Date.now() + 30_000;
  } catch (err) {
    console.error('[Consultas] No se pudieron leer las novedades para la IA:', err);
  }
}
export function olvidarNovedadesEquipo(): void {
  novedadesVencen = 0;
}

/** Texto con precios/día/lugar de la foto de hermanos para la IA (y refresca las novedades del equipo). Nunca tira error. */
export async function textoEventoFotoHermanos(): Promise<string> {
  await refrescarNovedadesEquipo();
  if (cacheEventoFotoHermanos && cacheEventoFotoHermanos.vence > Date.now()) return cacheEventoFotoHermanos.texto;
  try {
    const supabase = getServerSupabase();
    if (!supabase) return '';
    const { data, error } = await supabase
      .from('ev_eventos')
      .select('id, codigo, publicado, precio_digital, precio_15x21, precio_20x30, impresa_incluye_digital, fecha_evento, lugar')
      .ilike('nombre', '%herman%')
      .order('creado_en', { ascending: false })
      .limit(1)
      .abortSignal(AbortSignal.timeout(4000));
    if (error) throw error;
    const ev = (data?.[0] as (EventoFotoHermanos & { id?: string }) | undefined) ?? null;
    const { count } = ev?.id ? await supabase.from('ev_fotos').select('id', { count: 'exact', head: true }).eq('evento_id', ev.id) : { count: 0 };
    const texto = describirEventoFotoHermanos(ev ? { ...ev, fotos: count || 0 } : null);
    cacheEventoFotoHermanos = { texto, vence: Date.now() + 60_000 };
    return texto;
  } catch (err) {
    console.error('[Consultas] No se pudo leer el evento de la foto de hermanos:', err);
    return '';
  }
}

// Catálogo y reglas de negocio de la IA: en contextoConsultas.ts.
// ==============================================================================
// 4C. CONSULTAS DE FAMILIAS (formulario público + bandeja administrativa)
// La web nunca escribe directamente en Supabase: valida, limita intentos y usa el cliente
// privado del servidor. La tabla no concede ningún permiso a anon/authenticated.
// ==============================================================================

rutas.post('/api/consultas-familias', limitarFrecuencia('consultas-familias', 40, 15 * 60 * 1000), async (req: Request, res: Response) => {
  try {
    const { nombre, email, telefono, colegio, numeroPedido, asunto, mensaje, sitioWeb } = req.body || {};
    if (String(sitioWeb || '').trim()) return res.json({ success: true });

    const datos = {
      nombre: String(nombre || '').trim(),
      email: String(email || '').trim().toLowerCase(),
      telefono: String(telefono || '').trim(),
      colegio: String(colegio || '').trim(),
      numeroPedido: String(numeroPedido || '').trim(),
      asunto: String(asunto || '').trim(),
      mensaje: String(mensaje || '').trim(),
    };
    if (datos.nombre.length < 2 || datos.nombre.length > 120) return res.status(400).json({ success: false, error: 'Revisá el nombre ingresado.' });
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(datos.email) || datos.email.length > 254) return res.status(400).json({ success: false, error: 'Ingresá un email válido.' });
    if (datos.asunto.length < 2 || datos.asunto.length > 160) return res.status(400).json({ success: false, error: 'Seleccioná un motivo válido.' });
    if (datos.mensaje.length < 5 || datos.mensaje.length > 3000) return res.status(400).json({ success: false, error: 'El mensaje debe tener entre 5 y 3000 caracteres.' });
    if (datos.telefono.length > 50 || datos.colegio.length > 160 || datos.numeroPedido.length > 80) return res.status(400).json({ success: false, error: 'Uno de los datos ingresados es demasiado largo.' });

    const supabase = getServerSupabase();
    if (!supabase) return res.status(500).json({ success: false, error: 'El servicio de consultas no está disponible.' });

    const { data: consulta, error } = await supabase.from('consultas_familias').insert({
      nombre: datos.nombre,
      email: datos.email,
      telefono: datos.telefono || null,
      colegio: datos.colegio || null,
      numero_pedido: datos.numeroPedido || null,
      asunto: datos.asunto,
      mensaje: datos.mensaje,
      estado: 'nueva',
      origen: 'web',
    }).select('id').single();
    if (error) throw error;

    const resend = (await hayCupoGlobal('aviso-consulta-email', 120, 3600)) ? getResendClient() : null;
    if (resend) {
      const destino = casillaAvisosAdmin();
      const detalle = [
        datos.colegio ? `<p><strong>Colegio:</strong> ${escapeHtml(datos.colegio)}</p>` : '',
        datos.numeroPedido ? `<p><strong>Pedido:</strong> ${escapeHtml(datos.numeroPedido)}</p>` : '',
        datos.telefono ? `<p><strong>Teléfono:</strong> ${escapeHtml(datos.telefono)}</p>` : '',
      ].join('');
      const aviso = await resend.emails.send({
        from: process.env.RESEND_FROM_EMAIL || 'Retrato Escolar <fotos@retratoescolar.com.ar>',
        replyTo: datos.email,
        to: [destino],
        subject: `Nueva consulta web: ${datos.asunto}`,
        html: `<div style="font-family:Arial,sans-serif;max-width:640px;margin:auto;color:#0f172a"><h2>Nueva consulta de una familia</h2><p><strong>Nombre:</strong> ${escapeHtml(datos.nombre)}</p><p><strong>Email:</strong> ${escapeHtml(datos.email)}</p>${detalle}<p><strong>Motivo:</strong> ${escapeHtml(datos.asunto)}</p><div style="padding:16px;background:#f8fafc;border:1px solid #e2e8f0;border-radius:12px;white-space:pre-wrap">${escapeHtml(datos.mensaje)}</div><p style="font-size:12px;color:#64748b">Consulta ${escapeHtml(consulta.id)} · También está disponible en el panel administrativo.</p></div>`,
      });
      if (aviso.error) console.error('[Consultas] No se pudo enviar el aviso por email:', aviso.error);
    }

    // Revisión automática con los datos de la familia y, si todo está OK, respuesta al instante.
    // Se espera acá (con tope de tiempo) porque en Vercel la función se congela al responder.
    // Tope global de la IA (costo): pasado el tope, la consulta queda "nueva" para responder a mano.
    if (await hayCupoGlobal('ia-consultas', 200, 3600)) {
      await conLimiteDeTiempo(procesarConsultaConIA(supabase, consulta.id), 25000);
    }

    return res.status(201).json({ success: true });
  } catch (err: any) {
    console.error('[Consultas] Error al guardar consulta:', err);
    return res.status(500).json({ success: false, error: 'No pudimos guardar tu consulta. Intentá nuevamente.' });
  }
});

rutas.get('/api/admin/consultas-familias', requireAdminAuth, async (req: Request, res: Response) => {
  try {
    const supabase = getServerSupabase();
    if (!supabase) return res.status(500).json({ success: false, error: 'Supabase no configurado.' });
    const estado = String(req.query.estado || 'nueva');
    const estadosValidos = ['nueva', 'en_proceso', 'resuelta', 'archivada', 'todas', 'especial'];
    if (!estadosValidos.includes(estado)) return res.status(400).json({ success: false, error: 'Estado inválido.' });
    let query = supabase.from('consultas_familias').select('*, consultas_familias_mensajes(*)').order('created_at', { ascending: false }).limit(500);
    // 25/10/2026: «Atención especial» = las marcadas por Pablo que no están archivadas (en cualquier otro estado).
    if (estado === 'especial') query = query.eq('atencion_especial', true).neq('estado', 'archivada');
    else if (estado !== 'todas') query = query.eq('estado', estado);
    const { data, error } = await query;
    if (error) throw error;
    return res.json({ success: true, consultas: data || [] });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err?.message || 'No se pudieron obtener las consultas.' });
  }
});

rutas.delete('/api/admin/consultas-familias/:id', requireAdminAuth, async (req: Request, res: Response) => {
  try {
    const supabase = getServerSupabase();
    if (!supabase) return res.status(500).json({ success: false, error: 'Supabase no configurado.' });
    const { id } = req.params;

    await supabase.from('consultas_familias_mensajes').delete().eq('consulta_id', id);
    const { error } = await supabase.from('consultas_familias').delete().eq('id', id);
    if (error) throw error;

    return res.json({ success: true });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err?.message || 'No se pudo eliminar la consulta.' });
  }
});

// ==============================================================================
// RESPUESTAS AUTOMÁTICAS A CONSULTAS (pedido de Pablo, 24/9: "respuestas automáticas ante
// cualquier consulta sobre el funcionamiento de la página, donde se revise que está ok y se le
// responda correctamente"). Por cada consulta (o respuesta de la familia) se arma una "ficha"
// con los datos REALES de esa familia — inscripción, curso de cada hijo contra la nómina
// oficial, código de acceso, fotos cargadas y pedidos — y la IA redacta la respuesta con esos
// datos. Se envía sola SÓLO si: la ficha no marca ningún problema, la IA clasifica la pregunta
// como del funcionamiento de la página y dice que puede responderla completa. En cualquier otro
// caso queda como borrador en el panel, con la verificación a la vista, para que la mande Pablo.
// Se puede apagar el envío automático con la variable RESPUESTAS_AUTOMATICAS=off.
// ==============================================================================
type ChequeoFicha = { ok: boolean; texto: string };
interface FichaFamilia {
  encontrada: boolean;
  todoOk: boolean;
  chequeos: ChequeoFicha[];
  datos: string[];
  /** 26/10: colegios de la familia (para que el agente busque en su nómina y sus cursos). */
  colegios?: string[];
}

// Auditoría 11/10 (FAM-3): PostgREST toma `*` como `%` y no se puede escapar: con `*`, `%` o `\` no se busca
// (null = sin coincidencia). `_` se escapa (es común en emails reales).
function escaparIlike(valor: string): string | null {
  return /[*%\\]/.test(valor) ? null : valor.replace(/_/g, '\\_');
}

// 25/10/2026: textos para la ficha (fotos faltantes) y fechas cortas en hora argentina.
const NOMBRE_LUGAR_FALTANTE: Record<string, string> = { individual: 'la individual', grupal: 'la grupal', docente: 'la foto con la seño (o con familia y/o amigos en secundaria)' };
const MOTIVO_FALTANTE_TEXTO: Record<string, string> = { ausente: 'no estuvo ese día', no_quiso: 'no quiso sacársela', no_encontrada: 'se la sacaron pero no la encontraba' };
function fechaCorta(valor: string | null | undefined): string {
  const d = new Date(String(valor || ''));
  if (Number.isNaN(d.getTime())) return 'fecha desconocida';
  return d.toLocaleDateString('es-AR', { day: '2-digit', month: '2-digit', timeZone: 'America/Argentina/Buenos_Aires' });
}

async function armarFichaFamilia(
  supabase: SupabaseClient,
  consulta: { id?: string; email: string; numero_pedido?: string | null; nombre?: string | null }
): Promise<FichaFamilia> {
  const chequeos: ChequeoFicha[] = [];
  const datos: string[] = [];
  const email = String(consulta.email || '').trim().toLowerCase();

  const patronEmail = escaparIlike(email);
  const COLUMNAS_FICHA = 'id, email, colegio_id, colegio_nombre, padre_nombre, padre_dni, alumno_nombre, alumno_apellido, grado, turno, division, estado, codigo_asignado, hermanos, notificacion_email_enviada, solicita_foto_hermanos, foto_hermanos_confirmada_at, foto_hermanos_email';
  const { data: porEmail, error } = patronEmail === null ? { data: [] as any[], error: null } : await supabase
    .from('inscripciones')
    .select(COLUMNAS_FICHA)
    .ilike('email', patronEmail);
  if (error) throw error;
  let inscripciones: any[] = porEmail || [];

  if (inscripciones.length === 0) {
    // 29/10 (Pablo: «la IA responde con un desconocimiento que me enoja»): muchas familias escriben con otro email. Se busca
    // por el nombre que pusieron en la consulta; si aparece, se usa esa inscripción (con el email enmascarado).
    const porNombre = await buscarInscripcionesPorNombre(supabase, consulta.nombre, COLUMNAS_FICHA);
    if (porNombre.length > 0) {
      inscripciones = porNombre;
      chequeos.push({ ok: false, texto: `No hay inscripción con el email ${email}, pero sí a nombre de ${porNombre[0].padre_nombre} con otro email (${enmascararEmail(porNombre[0].email)}). Es casi seguro la misma familia: los datos de abajo son de esa inscripción. NO digas que no la encontramos ni que el equipo la revisa; respondé con estos datos y, si sirve, contale que se inscribió con ${enmascararEmail(porNombre[0].email)}.` });
    } else {
      chequeos.push({ ok: false, texto: `No hay ninguna inscripción con el email ${email} ni a nombre de «${String(consulta.nombre || '').trim() || 'sin nombre'}». Preguntale con qué email y a nombre de quién se inscribió (no digas que el equipo la revisa).` });
    }
  }

  const gradosListados = new Set<string>();
  for (const insc of inscripciones || []) {
    const tutor = insc.padre_nombre || 'sin nombre';
    datos.push(`Inscripción a nombre de ${tutor} en ${insc.colegio_nombre || 'colegio sin nombre'} — estado: ${insc.estado}${insc.padre_dni ? ', DNI del tutor cargado' : ', DNI del tutor todavía no cargado (se registra en su primer ingreso)'}.`);
    const aprobada = insc.estado === 'aceptado';
    let seccionesColegio: any[] = [];
    if (!aprobada) {
      chequeos.push({ ok: false, texto: `La inscripción de ${tutor} está "${insc.estado}" (todavía no aprobada).` });
    } else {
      if (!insc.notificacion_email_enviada) {
        chequeos.push({ ok: false, texto: `A ${tutor} todavía no se le envió el email con el código.` });
      }
      const { data: secciones } = await supabase
        .from('codigos_seccion')
        .select('grado, turno, division, codigo_secreto')
        .eq('colegio_id', insc.colegio_id);
      seccionesColegio = secciones || [];
      const codigoSeccion = (secciones || []).find((sec: any) => sec.grado === insc.grado && sec.turno === insc.turno && sec.division === insc.division)?.codigo_secreto || null;
      if (!insc.codigo_asignado || codigoSeccion !== insc.codigo_asignado) {
        chequeos.push({ ok: false, texto: `El código asignado (${insc.codigo_asignado || 'ninguno'}) no coincide con el de su curso ${insc.grado} "${insc.division}" ${insc.turno}.` });
      }
    }

    // 13/10 (Pablo: «Gemini no tiene los datos de los alumnos y cursos»): el curso de cada chico contra la
    // nómina también en las pendientes (suele ser el motivo), y qué cursos existen en su grado.
    const buscarEnNomina = await crearBuscadorEnNomina(supabase, insc.colegio_id);
    let nominaColegio: AlumnoNomina[] | null = null; // 26/10: para buscar un nombre parecido (sólo si hace falta)
    const cursosColegio = await cursosDeLaNomina(supabase, insc.colegio_id).catch(() => []);
    const chicos = [
      { nombre: `${insc.alumno_nombre || ''} ${insc.alumno_apellido || ''}`.trim(), grado: insc.grado, turno: insc.turno, division: insc.division },
      ...(Array.isArray(insc.hermanos) ? insc.hermanos : []).map((h: any) => ({
        nombre: `${h?.alumnoNombre || ''} ${h?.alumnoApellido || ''}`.trim(), grado: h?.grado, turno: h?.turno, division: h?.division,
      })),
    ];
    for (const chico of chicos) {
      const curso = `${chico.grado} "${chico.division}" turno ${chico.turno}${mensajeCursoFueraDeNomina(cursosColegio, chico) ? ' (curso que NO existe en el colegio)' : ''}`;
      const enNomina = await buscarEnNomina(chico.nombre, chico.grado);
      const parecido = enNomina ? null : nombreParecidoEnNomina((nominaColegio ??= await cargarNominaColegio(supabase, insc.colegio_id)), chico.nombre, chico.grado);
      if (parecido) {
        // 26/10 (caso Villar: «Riesmersma» en la nómina por «Riemersma»): no decirle a la familia que no está inscripto.
        chequeos.push({ ok: false, texto: `${chico.nombre} (${curso}) no figura tal cual en la nómina, pero hay un nombre casi igual: «${parecido.nombre}» (${parecido.grado} "${parecido.division}"${parecido.turno ? ` ${parecido.turno}` : ''}). Casi seguro es el mismo chico con el nombre mal escrito en la lista del colegio: NO le digas a la familia que no figura ni que no está inscripto; el equipo corrige la nómina.` });
      } else if (!enNomina) {
        chequeos.push({ ok: false, texto: `${chico.nombre} (${curso}) no figura en la nómina del colegio — revisar a mano.` });
      } else if (
        enNomina.grado !== chico.grado ||
        enNomina.division !== chico.division ||
        (enNomina.turno && enNomina.turno !== chico.turno)
      ) {
        chequeos.push({ ok: false, texto: `${chico.nombre} está inscripto en ${curso}, pero en la nómina figura en ${enNomina.grado} "${enNomina.division}"${enNomina.turno ? ` turno ${enNomina.turno}` : ''}.` });
      } else {
        chequeos.push({ ok: true, texto: `${chico.nombre}: ${curso}, coincide con la nómina.` });
      }
      const existentes = cursosDelGradoEnTexto(cursosColegio, chico.grado);
      if (existentes && !gradosListados.has(`${insc.colegio_id}|${chico.grado}`)) {
        gradosListados.add(`${insc.colegio_id}|${chico.grado}`);
        datos.push(`Cursos que existen en ${chico.grado} según la nómina del colegio: ${existentes}.`);
      }
      if (!aprobada) continue;
      const { count } = await supabase
        .from('fotos')
        .select('id', { count: 'exact', head: true })
        .eq('colegio_id', insc.colegio_id)
        .eq('grado', chico.grado)
        .eq('division', chico.division)
        .eq('turno', chico.turno)
        .not('publicada_at', 'is', null);
      datos.push(`Fotos cargadas del curso de ${chico.nombre}: ${count ? `${count} (ya puede elegirlas)` : 'todavía ninguna (aún no se sacaron o no se subieron)'}.`);
      if (count) datos.push(await clasesDeFotosDelCurso(supabase, insc.colegio_id, chico)); // 26/10: qué clases hay y cuál falta
      // 25/10/2026 (Pablo): para responder sobre el aviso «ya están tus fotos» con datos reales.
      const codigoChico = seccionesColegio.find((sec: any) => sec.grado === chico.grado && sec.turno === chico.turno && sec.division === chico.division)?.codigo_secreto;
      if (count && codigoChico && email) {
        const { data: aviso, error: errorAviso } = await supabase
          .from('avisos_fotos_destinatarios')
          .select('enviado_at')
          .eq('colegio_id', insc.colegio_id)
          .eq('codigo_curso', codigoChico)
          .eq('email_hash', crypto.createHash('sha256').update(email).digest('hex'))
          .maybeSingle();
        if (!errorAviso) datos.push(aviso?.enviado_at
          ? `Aviso «las fotos ya están online» del curso de ${chico.nombre}: enviado a este email el ${fechaCorta(aviso.enviado_at)}.`
          : `Aviso «las fotos ya están online» del curso de ${chico.nombre}: no figura enviado a este email (puede haberse mandado antes de que registráramos cada envío). Igual puede entrar con su código.`);
      }
    }

    // 25/10/2026 (Pablo): buscador por rostro y pedidos de fotos faltantes de esta inscripción.
    if (aprobada) {
      datos.push(`Buscador por rostro en su colegio: ${(await colegioTieneBuscadorRostro(supabase, insc.colegio_id)) ? 'sí (aparece en «Individual» cuando el curso tiene fotos publicadas)' : 'no disponible'}.`);
      const { data: solicitudes } = await supabase
        .from('fotos_faltantes_solicitudes')
        .select('alumno_nombre, lugar, motivo, estado, created_at, resuelta_at, cancelada_por, aviso_enviado_at, convocatoria_dia, convocatoria_hora, convocatoria_lugar')
        .eq('inscripcion_id', String(insc.id))
        .order('created_at', { ascending: false })
        .limit(10);
      for (const sol of solicitudes || []) {
        const convocada = sol.convocatoria_dia ? `; CONVOCADA por email para el ${diaLegible(sol.convocatoria_dia)}${sol.convocatoria_hora ? `, ${sol.convocatoria_hora}` : ''}${sol.convocatoria_lugar ? `, en ${sol.convocatoria_lugar}` : ''}` : '; todavía sin convocar';
        const estado = sol.estado === 'pendiente'
          ? `PENDIENTE (todavía no la publicamos; el kit de ese chico está en espera${convocada})`
          : sol.estado === 'resuelta'
            ? `RESUELTA: ya la publicamos${sol.aviso_enviado_at ? ` y le avisamos por email el ${fechaCorta(sol.aviso_enviado_at)}` : ''}; tiene que entrar a elegirla`
            : sol.cancelada_por === 'familia'
              ? 'CANCELADA por la familia («Ya no la queremos»)'
              : `CERRADA por el equipo sin foto${sol.aviso_enviado_at ? ` (email «Ya podés cerrar el kit» del ${fechaCorta(sol.aviso_enviado_at)})` : ''}; puede terminar el kit con otra foto del curso en su lugar`;
        datos.push(`Pedido de foto faltante: ${NOMBRE_LUGAR_FALTANTE[sol.lugar] || sol.lugar} de ${sol.alumno_nombre} (${MOTIVO_FALTANTE_TEXTO[sol.motivo] || sol.motivo}), hecho el ${fechaCorta(sol.created_at)} — ${estado}.`);
      }
      const { data: busquedas } = await supabase
        .from('rostros_busquedas')
        .select('alumno_nombre, resultado, fotos_nuevas, fotos_ya_en_galeria, created_at')
        .eq('inscripcion_id', String(insc.id))
        .order('created_at', { ascending: false })
        .limit(5);
      for (const b of busquedas || []) {
        const resultado = b.resultado === 'ok'
          ? `encontró ${b.fotos_nuevas || 0} foto(s) nueva(s) que ya se sumaron a su galería${b.fotos_ya_en_galeria ? ` y ${b.fotos_ya_en_galeria} que ya tenía` : ''}`
          : b.resultado === 'sin_resultados' ? 'no encontró fotos con esa cara'
            : b.resultado === 'sin_cara' ? 'no se detectó una cara en la foto que subió'
              : 'falló por un problema del servicio (no fue culpa de su foto)';
        datos.push(`Búsqueda por rostro de ${b.alumno_nombre} el ${fechaCorta(b.created_at)}: ${resultado}.`);
      }
      if ((busquedas || [])[0]?.resultado === 'error') {
        chequeos.push({ ok: false, texto: 'Su última búsqueda por rostro falló por un error del servicio (AWS): revisar el buscador antes de responder.' });
      }
    }
  }

  // 26/10: foto de hermanos (pidió / confirmó / día y horario) y consultas anteriores de la familia.
  datos.push(...(await datosFotoHermanos(supabase, inscripciones || [])), ...(await consultasAnteriores(supabase, patronEmail, consulta.id)));

  // 29/10: también las familias del email con el que se inscribió (si se la encontró por nombre).
  const emailsFamilia = [...new Set([patronEmail, ...inscripciones.map((i: any) => escaparIlike(String(i.email || '').trim().toLowerCase()))].filter((e): e is string => Boolean(e)))];
  const familias: any[] = [];
  for (const e of emailsFamilia) familias.push(...(((await supabase.from('familias').select('id').ilike('email', e)).data) || []));
  const idsFamilia = (familias || []).map((f: any) => f.id);
  let pedidos: any[] = [];
  if (idsFamilia.length > 0) {
    const { data } = await supabase
      .from('pedidos')
      .select('pedido_friendly_id, alumno_nombre, kit_nombre, estado, estado_lab, total, metodo_pago, created_at, descargas_hd, fotos_seleccionadas, seleccion_pendiente')
      .in('familia_id', idsFamilia)
      .order('created_at', { ascending: false })
      .limit(10);
    pedidos = data || [];
  }
  const numeroPedido = String(consulta.numero_pedido || '').trim();
  if (numeroPedido && !pedidos.some((p) => String(p.pedido_friendly_id || '').toUpperCase() === numeroPedido.toUpperCase())) {
    const patronPedido = escaparIlike(numeroPedido);
    const { data } = patronPedido === null ? { data: [] as any[] } : await supabase
      .from('pedidos')
      .select('pedido_friendly_id, alumno_nombre, kit_nombre, estado, estado_lab, total, metodo_pago, created_at, descargas_hd')
      .ilike('pedido_friendly_id', patronPedido)
      .limit(1);
    // Auditoría 30/9 (A6): un pedido de OTRA familia nunca entra en los datos que ve la IA (antes
    // se sumaba y la respuesta automática podía contarle a quien escribía el alumno, el kit y el
    // estado de un pedido ajeno). Queda como chequeo no-OK: no se responde solo y el fotógrafo lo ve.
    if (data && data.length > 0) {
      datos.push(`El número de pedido mencionado (${numeroPedido}) no corresponde a pedidos hechos con este email.`);
      chequeos.push({ ok: false, texto: `Mencionó el pedido ${numeroPedido}, que existe pero no es de este email: revisar a mano en el panel antes de responder.` });
    } else datos.push(`El número de pedido mencionado (${numeroPedido}) no existe en el sistema.`);
  }
  if (pedidos.length === 0) {
    datos.push('No tiene pedidos hechos todavía.');
  }
  // 25/10 noche (Pablo: «quiero que la IA responda bien»): qué fotos tiene elegidas cada pedido, con el número que ve la
  // familia («N° 3512»). Así la IA sabe si un cambio de foto ya está hecho y no lo niega.
  const idsElegidas = [...new Set(pedidos.flatMap((p) => {
    const f = p.fotos_seleccionadas && typeof p.fotos_seleccionadas === 'object' ? p.fotos_seleccionadas : {};
    return [f.individualId, f.grupalId, f.docenteId].filter((v: unknown): v is string => typeof v === 'string' && v.length > 0);
  }))];
  const numeroPorFoto = new Map<string, string>();
  if (idsElegidas.length > 0) {
    const { data: fotosElegidas } = await supabase.from('fotos').select('id, nombre_original').in('id', idsElegidas.slice(0, 60));
    for (const f of fotosElegidas || []) {
      const numeros = String(f.nombre_original || '').replace(/\.[^./\\]+$/, '').split('__')[0].match(/\d+/g);
      if (numeros) numeroPorFoto.set(f.id, numeros[numeros.length - 1].replace(/^0+(?=\d)/, ''));
    }
  }
  const elegidasTexto = (p: any): string => {
    if (p.seleccion_pendiente) return 'fotos todavía sin elegir';
    if (Array.isArray(p.fotos_seleccionadas?.extras)) return `pedido de FOTOS EXTRA (copias impresas aparte del kit): ${p.kit_nombre || ''}`;
    const f = p.fotos_seleccionadas && typeof p.fotos_seleccionadas === 'object' ? p.fotos_seleccionadas : {};
    const partes = ([['individual', f.individualId], ['grupal', f.grupalId], ['3ª foto', f.docenteId]] as [string, unknown][])
      .filter(([, id]) => typeof id === 'string' && id)
      .map(([lugar, id]) => `${lugar} N° ${numeroPorFoto.get(String(id)) || '?'}`);
    return partes.length ? `fotos elegidas para imprimir: ${partes.join(', ')}` : 'sin fotos elegidas';
  };
  for (const p of pedidos) {
    datos.push(`Pedido ${p.pedido_friendly_id || '(sin número)'} de ${p.alumno_nombre || 'alumno'}: ${p.kit_nombre || 'kit'}, total $${Number(p.total) || 0}, pago "${p.estado}" (${p.metodo_pago || 'sin método'}), laboratorio "${p.estado_lab || 'sin estado'}", descargas HD: ${Number(p.descargas_hd) || 0}, ${elegidasTexto(p)}.`);
  }

  const encontrada = Boolean(inscripciones && inscripciones.length > 0);
  const colegios = [...new Set((inscripciones || []).map((i: any) => String(i.colegio_id || '')).filter(Boolean))];
  return { encontrada, todoOk: encontrada && chequeos.every((c) => c.ok), chequeos, datos, colegios };
}

// 26/10/2026: la redacción pasó a respuestaVerificada.ts (dos pasos: redacción con cada afirmación respaldada por un
// dato de la ficha + control frase por frase). Acá sólo se arma el contexto del negocio.
async function redactarRespuestaConsulta(
  consulta: any,
  ficha: FichaFamilia,
  esfuerzo?: 'low' | 'medium',
  idea?: string,
  alTenerBorrador?: (borrador: DecisionIA) => Promise<void>
): Promise<DecisionIA> {
  if (!iaConfigurada()) throw new Error(ERROR_IA_NO_CONFIGURADA);
  return redactarYControlar({ consulta, ficha, sistema: contextoNegocioConsultas(await textoEventoFotoHermanos()), esfuerzo, idea, alTenerBorrador });
}

const MAX_RESPUESTAS_AUTOMATICAS_POR_CONSULTA = 3;

/** 14/10/2026: la respuesta promete un cambio que hace el equipo a mano (corregir el curso, mandar un código nuevo). */
export function respuestaPrometeCambio(texto: string): boolean {
  return [
    /\b(pasamos|pas[eé]|derivamos|deriv[eé])\s[^.]{0,40}\bal equipo\b/i,
    /\b(ya|vamos a|van a|va a)\s+(lo |la |los |las |te |le )?(corregir|corregimos|corregido|cambiar|cambiamos|modificar|modificamos|actualizar|actualizamos)/i,
    /\b(nuevo c[oó]digo|c[oó]digo nuevo)\b/i,
    // Auditoría 28/10 (M3): tampoco sale sola una respuesta que promete plata o algo gratis (un reintegro, un
    // descuento, una bonificación): eso lo decide Pablo, y puede venir dictado por quien escribió la consulta.
    /\b(te|les)\s+(lo |la |los |las )?(vamos a |podemos |van a )?(devolv|devolvemos|reintegr|reembols|bonific|regal|descont)/i,
    /\b(te|les)\s+(vamos a |podemos )?(hacer|hacemos|damos|dar)\s+(un|una)\s+(descuento|bonificaci[oó]n|excepci[oó]n|reintegro|devoluci[oó]n)/i,
    /\b(sin cargo|sin costo|gratis|de regalo)\b/i,
  ].some((r) => r.test(String(texto || '')));
}

// Auditoría 28/10 (M2): ¿la respuesta trae un link o un dominio que no es de Retrato Escolar? Se mira el
// dominio real de cada link (antes alcanzaba con que la URL tuviera «retratoescolar.com.ar» en cualquier
// parte: pasaban «retratoescolar.com.ar.estafa.xyz» u «otro.com/retratoescolar.com.ar») y también los
// dominios escritos sin «http»/«www» («pago-retrato.com/x»). Los emails tienen su propio control.
const DOMINIO_PROPIO = /(^|\.)retratoescolar\.com\.ar$/i;
const LINK_RE = /(https?:\/\/|www\.)[^\s)<>"']+/gi;
export function hayLinkAjeno(texto: string): boolean {
  const sinEmails = String(texto || '').replace(/[\w.+-]+@[\w-]+(\.[\w-]+)+/g, ' ');
  for (const crudo of sinEmails.match(LINK_RE) || []) {
    const link = crudo.replace(/[.,;:!?]+$/, '');
    try {
      const host = new URL(/^https?:\/\//i.test(link) ? link : `https://${link}`).hostname.replace(/\.$/, '');
      if (!DOMINIO_PROPIO.test(host)) return true;
    } catch {
      return true;
    }
  }
  const sueltos = sinEmails.replace(LINK_RE, ' ').match(/\b[a-z0-9-]+(\.[a-z0-9-]+)*\.(com|net|org|ar|xyz|app|link|io|info|site|online|shop|store|me|co|ly|gl|click|top|live|lat)\b/gi) || [];
  return sueltos.some((d) => !DOMINIO_PROPIO.test(d));
}

// 25/10 (auditoría): una consulta por fotos que faltan (ausentes, foto que no aparece, repetir una foto) siempre
// queda como borrador para Pablo: la regla de no hablar de repeticiones es delicada y no conviene que salga sola.
export function hablaDeFotoFaltante(texto: string): boolean {
  // [^.?!\n] = dentro de la misma frase. Siempre con «foto», «día» o «colegio» cerca: «no vino el código», «pago
  // repetido» o «las fotos todavía no están» (la consulta más común) no cuentan.
  const F = '[^.?!\\n]{0,40}';
  return [
    new RegExp(`\\b(falt(o|ó|aba|aron)|le falta|no (estuvo|fue|vino|asisti[oó]|pudo ir)|estaba enferm[oa])(?![a-záéíóúñ])${F}\\b(fotos?|d[ií]a|colegio|escuela|toma)\\b`, 'i'),
    /\bausent/i,
    new RegExp(`\\bno (aparece|aparecen|encuentro|encontramos|encontr[aá]s|tiene|sali[oó])(?![a-záéíóúñ])${F}\\b(fotos? (individual|grupal|con (la|el) (se[ñn]o|docente|maestr[oa])|de [a-záéíóúñ]+)|(la|en la) (individual|grupal))`, 'i'),
    new RegExp(`\\bfotos? (individual|grupal|con (la|el) (se[ñn]o|docente|maestr[oa])|de mi [a-záéíóúñ]+)\\b${F}\\bno (aparece|est[aá](?![a-záéíóúñ]))`, 'i'),
    new RegExp(`\\brepet(ir|irla|irle|imos)\\b${F}\\bfoto|\\bfotos?\\b${F}\\brepet(ir|ida|irla)\\b`, 'i'),
    /\b(volver a sacar|sacar de nuevo|tomar de nuevo|nueva toma|otra toma|retomar)\b/i,
    /\b(sacar(le)?|saquen(le)?|saquemos|tomen(le)?|tomar(le)?)\s+(otra|la|una)\s+foto/i,
    new RegExp(`\\bfotos?\\b[^.?!\\n]{0,20}\\bde nuevo\\b`, 'i'),
  ].some((r) => r.test(String(texto || '')));
}

// Revisa la consulta, redacta la respuesta y la envía sola si corresponde; si no, la deja como
// borrador. Nunca tira error hacia afuera: si algo falla, la consulta queda para responder a mano.
export async function procesarConsultaConIA(
  supabase: SupabaseClient,
  consultaId: string,
  opciones: { permitirEnvio: boolean; esRespuestaAutomaticaDeLaFamilia?: boolean; esfuerzo?: 'low' | 'medium'; lanzarErrores?: boolean; idea?: string; investigar?: boolean } = { permitirEnvio: true }
): Promise<{ ficha: FichaFamilia; decision: DecisionIA; enviada: boolean } | null> {
  try {
    const { data: consulta, error } = await supabase
      .from('consultas_familias')
      .select('*,consultas_familias_mensajes(direccion,contenido,created_at,automatica)') // 25/10: '*' trae atencion_especial (y no falla si todavía no existe la columna)
      .eq('id', consultaId)
      .single();
    if (error || !consulta) return null;

    const ficha = await armarFichaFamilia(supabase, consulta);
    // 26/10: la idea de Pablo sólo llega desde el panel (permitirEnvio false): nunca sale sola.
    const idea = opciones.permitirEnvio ? undefined : opciones.idea;
    const baseVerificacion = { encontrada: ficha.encontrada, todoOk: ficha.todoOk, chequeos: ficha.chequeos, datos: ficha.datos };
    // 26/10: el borrador se guarda apenas está (antes del control), así no se pierde si se corta el tiempo; sin control no sale solo.
    const guardarBorradorPrevio = async (b: DecisionIA) => {
      await supabase.from('consultas_familias').update({
        verificacion_ia: { ...baseVerificacion, tema: b.tema, motivo: b.motivo, motivoNoEnvio: 'Borrador todavía sin controlar: revisalo a mano.', enviadaAutomaticamente: false, ...analisisParaPanel(b) },
        borrador_ia: b.respuesta || null,
        procesada_ia_at: new Date().toISOString(),
      }).eq('id', consulta.id);
    };
    // 26/10 (Pablo eligió Opus): desde el panel la responde un agente que investiga con herramientas de sólo lectura
    // (agenteConsultas.ts). Nunca sale sola (permitirEnvio es false en el panel). Si no termina, va el borrador común.
    let decision: DecisionIA;
    if (opciones.investigar && !opciones.permitirEnvio && iaConfigurada()) {
      const inicio = Date.now();
      try {
        const colegios = ficha.colegios?.length ? ficha.colegios : ((await supabase.from('colegios').select('id')).data || []).map((c: any) => String(c.id));
        decision = await investigarYResponder({ supabase, consulta, ficha, colegios, sistema: contextoNegocioConsultas(await textoEventoFotoHermanos()), idea });
      } catch (err) {
        if (Date.now() - inicio > 70_000) throw err;
        console.error('[Consultas] El agente no pudo terminar; va el borrador común:', err);
        decision = { ...(await redactarRespuestaConsulta(consulta, ficha, opciones.esfuerzo, idea)), nota: 'La investigación completa no pudo terminar: este es el borrador rápido. Probá «Pedir otra a la IA» de nuevo.' };
      }
    } else {
      decision = await redactarRespuestaConsulta(consulta, ficha, opciones.esfuerzo, idea, guardarBorradorPrevio);
    }
    const automaticasPrevias = (consulta.consultas_familias_mensajes || []).filter((m: any) => m.automatica).length;
    // Auditoría 30/9 (M3): el email del formulario web no se verifica y el mensaje lo escribe quien
    // quiera (puede intentar dirigir a la IA). Una respuesta automática nunca sale si trae links
    // ajenos al sitio, un CBU/CVU que no es el oficial o un alias que no es RETRATO.ESCOLAR; y a un
    // mismo email le llegan como máximo 3 automáticas por día.
    const textoRespuesta = String(decision.respuesta || '');
    const linkAjeno = hayLinkAjeno(textoRespuesta);
    const numeroCuentaAjeno = (textoRespuesta.match(/\d{20,}/g) || []).some((n) => n !== '0070313830004052956749');
    const aliasAjeno = /alias[:\s]+(?!retrato\.escolar\b)[a-z0-9.]{6,}/i.test(textoRespuesta);
    // Auditoría 03/10 noche: tampoco sale sola si trae un email que no es de Retrato Escolar o un
    // número de teléfono (la IA no tiene por qué dar otro contacto; si lo da, puede venir dictado por
    // quien escribió la consulta).
    const emailAjeno = (textoRespuesta.match(/[\w.+-]+@[\w-]+(\.[\w-]+)+/g) || []).some((e) => !/@(contacto\.|respuestas\.)?retratoescolar\.com\.ar$/i.test(e));
    const telefonoAjeno = (textoRespuesta.replace(/\d{20,}/g, '').match(/\+?\d[\d\s().-]{7,}\d/g) || []).some((t) => t.replace(/\D/g, '').length >= 10);
    const respuestaSegura = !linkAjeno && !numeroCuentaAjeno && !aliasAjeno && !emailAjeno && !telefonoAjeno;
    // 14/10/2026 (caso Paludi): una respuesta automática le dijo a la familia «ya le pasamos la información al
    // equipo para que corrija el curso… te va a llegar el nuevo código», y nadie hizo el cambio. Si la
    // respuesta promete una corrección o un código nuevo, queda como borrador para Pablo.
    const prometeCambio = respuestaPrometeCambio(textoRespuesta);
    // Sólo lo que escribió la familia (no nuestras respuestas ni la de la IA, que pueden decir «todavía no están»).
    const deLaFamilia = (consulta.consultas_familias_mensajes || []).filter((m: any) => m.direccion === 'entrante').map((m: any) => m.contenido);
    const fotoFaltante = [consulta.asunto, consulta.mensaje, ...deLaFamilia].some((t) => hablaDeFotoFaltante(String(t || '')));
    let dentroDelCupoDiario = true;
    if (opciones.permitirEnvio && respuestaSegura && !prometeCambio) {
      // Auditoría 11/10 (DB-5): el email va hasheado en la clave (limites_intentos no guarda emails); mismo tope.
      const huellaEmail = crypto.createHash('sha256').update(String(consulta.email || '').trim().toLowerCase()).digest('hex');
      dentroDelCupoDiario = await hayCupoPorClave(`auto-respuesta:${huellaEmail}`, 3, 24 * 60 * 60);
    }
    const envioActivado = String(process.env.RESPUESTAS_AUTOMATICAS || 'on').trim().toLowerCase() !== 'off';
    const enviar =
      opciones.permitirEnvio &&
      envioActivado &&
      !opciones.esRespuestaAutomaticaDeLaFamilia &&
      ficha.todoOk &&
      decision.tema === 'funcionamiento' &&
      decision.respondible &&
      decision.respuesta.length >= 20 &&
      analisisPermiteEnvio(decision) && // 26/10: control sin problemas, sin dudas ni decisiones pendientes
      automaticasPrevias < MAX_RESPUESTAS_AUTOMATICAS_POR_CONSULTA &&
      respuestaSegura &&
      !prometeCambio &&
      !fotoFaltante &&
      !consulta.atencion_especial &&
      dentroDelCupoDiario &&
      consulta.estado !== 'archivada';

    const motivoNoEnvio = !enviar
      ? !respuestaSegura
        ? 'La respuesta trae un link, email, teléfono, alias o número de cuenta que no son los oficiales: revisala antes de enviarla.'
        : prometeCambio
          ? 'La respuesta promete una corrección o un código nuevo: hacé el cambio y revisala antes de enviarla.'
        : fotoFaltante
          ? 'La consulta es sobre fotos que faltan o repetir una foto: revisala antes de enviarla.'
        : consulta.atencion_especial
          ? 'Marcada como «Atención especial»: la respondés vos.'
        : decision.decisiones.length > 0
          ? 'Hay algo que tenés que decidir vos (abajo están las opciones).'
        : decision.ambiguedades.length > 0
          ? 'La consulta se puede entender de más de una forma: revisá cómo la interpretó la IA.'
        : decision.alertas.length > 0
          ? 'El control encontró frases sin respaldo en los datos: revisá el borrador.'
        : !decision.verificado && decision.respuesta
          ? 'El borrador no pasó el control automático: revisalo a mano.'
        : !dentroDelCupoDiario
          ? 'Ya se enviaron 3 respuestas automáticas a este email hoy.'
          : !ficha.todoOk
        ? 'Hay datos de la familia para revisar.'
        : decision.tema !== 'funcionamiento'
          ? `La consulta es de tipo "${decision.tema}", no del funcionamiento de la página.`
          : !decision.respondible
            ? 'La IA no puede responderla completa con los datos disponibles.'
            : automaticasPrevias >= MAX_RESPUESTAS_AUTOMATICAS_POR_CONSULTA
              ? 'Ya se enviaron varias respuestas automáticas en esta conversación.'
              : null
      : null;

    await supabase.from('consultas_familias').update({
      verificacion_ia: {
        ...baseVerificacion,
        tema: decision.tema,
        motivo: decision.motivo,
        motivoNoEnvio,
        enviadaAutomaticamente: enviar,
        ...analisisParaPanel(decision), // 26/10: qué entendió, dudas, decisiones y alertas del control
      },
      borrador_ia: enviar ? null : decision.respuesta || null,
      procesada_ia_at: new Date().toISOString(),
    }).eq('id', consulta.id);
    // 25/10 noche: la copia guardada del cuadro de respuesta (borradores_admin) le ganaba al borrador nuevo y el panel
    // mostraba un texto viejo. Con un borrador nuevo (o respondida sola), esa copia se descarta.
    await supabase.from('borradores_admin').delete().eq('clave', `consulta-${consulta.id}`).then(undefined, () => undefined);

    if (enviar) {
      await enviarRespuestaConsulta(supabase, consulta, decision.respuesta, true);
    }
    return { ficha, decision, enviada: enviar };
  } catch (err: any) {
    console.error('[Consultas] No se pudo procesar la consulta con IA:', err);
    // 28/9: antes el error se perdía (los registros de Vercel duran 1 hora). Ahora queda guardado en
    // la consulta, así se ve en el panel por qué la IA no la contestó.
    try {
      await supabase
        .from('consultas_familias')
        .update({
          verificacion_ia: {
            encontrada: false, todoOk: false, chequeos: [], datos: [], tema: 'error', enviadaAutomaticamente: false,
            motivoNoEnvio: `⚠️ La IA no pudo procesar esta consulta: ${String(err?.message || err).slice(0, 400)}`,
          },
          procesada_ia_at: new Date().toISOString(),
        })
        .eq('id', consultaId);
    } catch {
      /* sin base: no hay dónde guardarlo */
    }
    if (opciones.lanzarErrores) throw err; // 13/10: el panel necesita saber si fue la IA saturada
    return null;
  }
}

// Corta la espera si la IA tarda demasiado: la consulta igual queda guardada y se responde a mano.
export function conLimiteDeTiempo<T>(promesa: Promise<T>, ms: number): Promise<T | null> {
  return Promise.race([promesa, new Promise<null>((resolve) => setTimeout(() => resolve(null), ms))]);
}

// ==============================================================================
// CAMPAÑA "PAGO ANTICIPADO" (pedido de Pablo, 25/9): un único email a las familias ya inscriptas
// cuyos hijos están en cursos que todavía no tienen fotos, contándoles que pueden dejar el kit
// pago por adelantado. El panel muestra primero cuántas familias lo recibirían y la vista previa;
// sólo se envía cuando el fotógrafo confirma. Cada email enviado queda registrado en
// envios_campana_familias, así un segundo clic (o un reintento) nunca repite a nadie.
// ==============================================================================
const CAMPANA_PAGO_ANTICIPADO = 'pago-anticipado-2026';

type DestinatarioCampana = { email: string; tutor: string; alumnos: string[]; colegio: string };

async function armarDestinatariosPagoAnticipado(supabase: SupabaseClient): Promise<DestinatarioCampana[]> {
  const [inscripciones, fotos, reservas, yaEnviados] = await Promise.all([
    traerTodasLasFilas<any>((desde, hasta) =>
      supabase.from('inscripciones').select('id,email,padre_nombre,alumno_nombre,alumno_apellido,colegio_id,colegio_nombre,grado,turno,division,hermanos').eq('estado', 'aceptado').order('id').range(desde, hasta)
    ),
    traerTodasLasFilas<any>((desde, hasta) =>
      supabase.from('fotos').select('colegio_id,grado,turno,division').not('publicada_at', 'is', null).order('id').range(desde, hasta)
    ),
    traerTodasLasFilas<any>((desde, hasta) =>
      supabase.from('pedidos').select('colegio_id,alumno_nombre').eq('seleccion_pendiente', true).eq('estado', 'pagado').order('id').range(desde, hasta)
    ),
    traerTodasLasFilas<any>((desde, hasta) =>
      supabase.from('envios_campana_familias').select('email').eq('campana', CAMPANA_PAGO_ANTICIPADO).order('email').range(desde, hasta)
    ),
  ]);
  const seccionesConFotos = fotos.map((f: any) => f);
  const tieneFotos = (colegioId: string, a: { grado: string; turno: string; division: string }) =>
    seccionesConFotos.some((f: any) => f.colegio_id === colegioId && mismoDatoSeccion(f.grado, a.grado) && mismoDatoSeccion(f.turno, a.turno) && mismoDatoSeccion(f.division, a.division));
  const reservados = new Set(reservas.map((r: any) => `${r.colegio_id}|${normalizarNombrePorPalabras(r.alumno_nombre)}`));
  const enviados = new Set(yaEnviados.map((e: any) => String(e.email).toLowerCase()));

  const porEmail = new Map<string, DestinatarioCampana>();
  for (const insc of inscripciones) {
    const email = String(insc.email || '').trim().toLowerCase();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || enviados.has(email)) continue;
    const alumnos = [
      { nombre: `${insc.alumno_nombre || ''} ${insc.alumno_apellido || ''}`.trim(), colegioId: insc.colegio_id, grado: insc.grado, turno: insc.turno, division: insc.division },
      ...(Array.isArray(insc.hermanos) ? insc.hermanos.map((h: any) => ({
        nombre: `${h.alumnoNombre || h.alumno_nombre || ''} ${h.alumnoApellido || h.alumno_apellido || ''}`.trim(),
        colegioId: h.colegioId || insc.colegio_id,
        grado: h.grado, turno: h.turno, division: h.division,
      })) : []),
    ].filter((a) => a.nombre && !tieneFotos(a.colegioId, a) && !reservados.has(`${a.colegioId}|${normalizarNombrePorPalabras(a.nombre)}`));
    if (alumnos.length === 0) continue;
    const previo = porEmail.get(email);
    const nombres = alumnos.map((a) => {
      const primero = a.nombre.split(' ')[0].toLowerCase();
      return primero.charAt(0).toUpperCase() + primero.slice(1);
    });
    if (previo) {
      for (const n of nombres) if (!previo.alumnos.includes(n)) previo.alumnos.push(n);
    } else {
      porEmail.set(email, { email, tutor: insc.padre_nombre || 'Familia', alumnos: nombres, colegio: insc.colegio_nombre || 'tu colegio' });
    }
  }
  return Array.from(porEmail.values());
}

function correoCampanaPagoAnticipado(d: DestinatarioCampana) {
  const hijos = d.alumnos.length > 1 ? `${d.alumnos.slice(0, -1).join(', ')} y ${d.alumnos[d.alumnos.length - 1]}` : d.alumnos[0];
  const asunto = `Novedad: ya podés dejar pago el kit de fotos de ${hijos}`;
  const html = `<!doctype html><html lang="es"><body style="margin:0;background:#f8fafc;font-family:Arial,sans-serif;color:#1e293b"><div style="max-width:600px;margin:24px auto;background:#fff;border:1px solid #e2e8f0;border-radius:16px;overflow:hidden"><div style="background:#0f172a;padding:28px 24px;text-align:center;border-bottom:3px solid #f59e0b"><div style="color:#f59e0b;font-size:11px;font-weight:800;letter-spacing:2px">RETRATO ESCOLAR</div><h1 style="color:#fff;font-size:22px;margin:8px 0 0">Ahora podés pagar por adelantado</h1></div><div style="padding:28px 24px;line-height:1.6"><p>Hola <strong>${escapeHtml(d.tutor)}</strong>,</p><p>Las fotos de <strong>${escapeHtml(hijos)}</strong> en ${escapeHtml(d.colegio)} todavía no están online, y muchas familias nos pidieron poder dejar el kit pago antes. Ahora se puede, y tenés dos opciones:</p><div style="margin:16px 0;padding:14px 16px;background:#fffbeb;border:1px solid #fcd34d;border-radius:12px"><p style="margin:0 0 6px"><strong>1. Pagar por adelantado:</strong> entrá a la web con tu código de acceso y vas a ver <em>"Reservá tu kit ahora"</em>. Elegís el kit, lo pagás con Mercado Pago, Nave o transferencia, y cuando se suban las fotos sólo elegís tus 3 favoritas, <strong>sin volver a pagar</strong>.</p><p style="margin:0"><strong>2. Pagar al elegir las fotos:</strong> si preferís, esperás a que estén online (te avisamos por email), elegís y pagás en ese momento.</p></div><p>El precio es el mismo en los dos casos, y comprar sigue siendo opcional.</p><div style="margin:24px 0;text-align:center"><a href="https://retratoescolar.com.ar" style="display:inline-block;background:#fbbf24;color:#0f172a;text-decoration:none;font-weight:800;padding:13px 22px;border-radius:10px">Reservar mi kit</a></div><p style="font-size:12px;color:#64748b">Entrá con el mismo código de acceso que recibiste al aprobarse tu inscripción. Si tenés dudas, respondé este correo.</p></div></div></body></html>`;
  return { asunto, html };
}

rutas.get('/api/admin/campanas/pago-anticipado', requireAdminAuth, async (_req: Request, res: Response) => {
  try {
    const supabase = getServerSupabase();
    if (!supabase) return res.status(500).json({ success: false, error: 'Supabase no configurado.' });
    const destinatarios = await armarDestinatariosPagoAnticipado(supabase);
    const { count: yaEnviados } = await supabase.from('envios_campana_familias').select('email', { count: 'exact', head: true }).eq('campana', CAMPANA_PAGO_ANTICIPADO);
    const ejemplo = correoCampanaPagoAnticipado(destinatarios[0] || { email: '', tutor: 'Nombre del tutor', alumnos: ['Nombre del alumno'], colegio: 'el colegio' });
    return res.json({ success: true, pendientes: destinatarios.length, yaEnviados: yaEnviados || 0, asunto: ejemplo.asunto, html: ejemplo.html });
  } catch (err: any) {
    console.error('[Campaña pago anticipado] Error al armar la vista previa:', err);
    return res.status(500).json({ success: false, error: 'No se pudo armar la lista de familias.' });
  }
});

rutas.post('/api/admin/campanas/pago-anticipado/enviar', requireAdminAuth, async (req: Request, res: Response) => {
  try {
    if (req.body?.confirmar !== true) return res.status(400).json({ success: false, error: 'Falta confirmar el envío.' });
    const supabase = getServerSupabase();
    const resend = getResendClient();
    if (!supabase || !resend) return res.status(500).json({ success: false, error: 'El servicio de email no está configurado.' });
    const destinatarios = await armarDestinatariosPagoAnticipado(supabase);
    let enviados = 0;
    let fallidos = 0;
    const TAMANO_LOTE = 100;
    for (let i = 0; i < destinatarios.length; i += TAMANO_LOTE) {
      const lote = destinatarios.slice(i, i + TAMANO_LOTE);
      const resultado = await resend.batch.send(
        lote.map((d) => {
          const { asunto, html } = correoCampanaPagoAnticipado(d);
          return { from: process.env.RESEND_FROM_EMAIL || 'Retrato Escolar <fotos@retratoescolar.com.ar>', replyTo: resendReplyTo, to: [d.email], subject: asunto, html };
        }),
        { idempotencyKey: `${CAMPANA_PAGO_ANTICIPADO}-${crypto.createHash('sha256').update(lote.map((d) => d.email).join(',')).digest('hex')}`, batchValidation: 'permissive' }
      );
      if (resultado.error) {
        console.error('[Campaña pago anticipado] Falló un lote:', resultado.error);
        fallidos += lote.length;
        continue;
      }
      const rechazados = new Set<number>(((resultado.data as any)?.errors || []).map((e: any) => Number(e.index)));
      const ok = lote.filter((_, idx) => !rechazados.has(idx));
      fallidos += lote.length - ok.length;
      enviados += ok.length;
      if (ok.length > 0) {
        const { error } = await supabase.from('envios_campana_familias').upsert(ok.map((d) => ({ campana: CAMPANA_PAGO_ANTICIPADO, email: d.email })));
        if (error) console.error('[Campaña pago anticipado] Se envió pero no se registró el lote:', error);
      }
      if (i + TAMANO_LOTE < destinatarios.length) await new Promise((resolve) => setTimeout(resolve, 600));
    }
    return res.json({ success: true, enviados, fallidos });
  } catch (err: any) {
    console.error('[Campaña pago anticipado] Error al enviar:', err);
    return res.status(500).json({ success: false, error: 'No se pudo completar el envío.' });
  }
});

// Borrador con IA para "Escribir a esta familia": no envía nada, sólo devuelve el texto.
rutas.post(
  '/api/admin/consultas-familias/sugerir-mensaje',
  requireAdminAuth,
  limitarFrecuencia('sugerir-mensaje', 20, 10 * 60 * 1000),
  async (req: Request, res: Response) => {
    try {
      if (!iaConfigurada()) return res.status(503).json({ success: false, error: ERROR_IA_NO_CONFIGURADA });
      const supabase = getServerSupabase();
      if (!supabase) return res.status(500).json({ success: false, error: 'Supabase no configurado.' });
      const email = String(req.body?.email || '').trim().toLowerCase();
      const numeroPedido = String(req.body?.numeroPedido || '').trim() || null;
      const motivo = String(req.body?.motivo || '').trim().slice(0, 500);
      if (!email.includes('@')) return res.status(400).json({ success: false, error: 'Falta el email de la familia.' });
      if (motivo.length < 3) return res.status(400).json({ success: false, error: 'Escribí en pocas palabras de qué querés hablarle (en el asunto).' });

      const ficha = await armarFichaFamilia(supabase, { email, numero_pedido: numeroPedido });
      const prompt = `
Retrato Escolar le va a escribir un email a una familia (la familia NO escribió antes; el mensaje lo inicia el fotógrafo).
- Tutor/a: ${String(req.body?.nombre || 'la familia').slice(0, 120)}
- Alumno/a: ${String(req.body?.alumno || '').slice(0, 120) || 'no especificado'}
- Tema del mensaje (lo que el fotógrafo quiere comunicar): ${motivo}

Datos REALES de esta familia en el sistema (son la única fuente válida):
${ficha.chequeos.map((c) => `${c.ok ? '[OK]' : '[PROBLEMA]'} ${c.texto}`).join('\n') || '(sin chequeos)'}
${ficha.datos.map((d) => `- ${d}`).join('\n')}

Escribí SOLO el cuerpo del email: español rioplatense ("vos"), breve, claro y cálido, sin saludo inicial ni firma (el sistema los agrega). No inventes fechas, montos ni promesas que no estén en los datos o en el tema. Nunca incluyas códigos de acceso ni DNIs.
`.trim();
      const sugerencia = await generarTextoIA({ sistema: contextoNegocioConsultas(await textoEventoFotoHermanos()), prompt, esfuerzo: 'medium' });
      return res.json({ success: true, sugerencia });
    } catch (err: any) {
      console.error('[Consultas] Error al sugerir mensaje con IA:', err);
      return res.status(esIaSaturada(err) ? 503 : 500).json({ success: false, error: esIaSaturada(err) ? AVISO_IA_SATURADA : 'No pudimos generar un borrador. Escribilo a mano o intentá de nuevo.' });
    }
  }
);

// → 14/10/2026: cambiar estado, «Responder», «Escribir a esta familia» y el envío de la respuesta pasaron a
// consultasAdmin.ts (con clave de envío para no duplicar). Redacta un borrador de respuesta con IA para que el
// fotógrafo lo revise y envíe a mano desde el botón "Responder" — esta ruta NUNCA envía el mensaje ni lo guarda en
// consultas_familias_mensajes, solo devuelve el texto sugerido.
rutas.post(
  '/api/admin/consultas-familias/:id/sugerir-respuesta',
  requireAdminAuth,
  limitarFrecuencia('sugerir-respuesta', 20, 10 * 60 * 1000),
  async (req: Request, res: Response) => {
    try {
      if (!iaConfigurada()) {
        return res.status(503).json({ success: false, error: ERROR_IA_NO_CONFIGURADA });
      }

      const supabase = getServerSupabase();
      if (!supabase) return res.status(500).json({ success: false, error: 'Supabase no configurado.' });
      // Mismo proceso que el automático (revisa los datos reales de la familia), pero sin enviar:
      // el texto queda en el cuadro de respuesta para que el fotógrafo lo revise.
      // 13/10: Pablo espera la respuesta en el panel (sin el tope de 12 s del webhook): Claude piensa más.
      // 26/10: Pablo puede escribir una idea («decile que…») y la IA redacta la respuesta a partir de eso.
      const idea = typeof req.body?.idea === 'string' ? req.body.idea.trim().slice(0, 1500) : '';
      const resultado = await procesarConsultaConIA(supabase, String(req.params.id), { permitirEnvio: false, esfuerzo: 'medium', lanzarErrores: true, idea: idea || undefined, investigar: true });
      if (!resultado) throw new Error('No se pudo procesar la consulta.');
      const sugerencia = resultado.decision.respuesta;
      const analisis = analisisParaPanel(resultado.decision); // 26/10: qué entendió, dudas, decisiones y alertas
      if (!sugerencia) {
        return res.json({ success: true, sugerencia: '', analisis, aviso: resultado.decision.motivo || 'La IA considera que no hace falta responder.' });
      }
      return res.json({ success: true, sugerencia, analisis });
    } catch (err: any) {
      console.error('[Consultas] Error al sugerir respuesta con IA:', err);
      if (esIaSaturada(err)) return res.json({ success: true, sugerencia: '', aviso: AVISO_IA_SATURADA });
      return res.status(500).json({ success: false, error: 'No pudimos generar una sugerencia. Intentá nuevamente o escribila a mano.' });
    }
  }
);

export { rutas as rutasConsultas };
