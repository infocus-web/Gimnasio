// Email con el código de acceso de la familia y la confirmación del primer ingreso con DNI (división de
// server.ts, etapa 5, 10/10/2026). Lo usan inscripciones y solicitudes de código. El código es el mismo
// que estaba en la sección 5 de server.ts: sólo se movió de lugar.
import crypto from 'crypto';
import { getAdminSessionSecret } from '../nucleo/auth.js';
import { getResendClient, resendReplyTo } from '../nucleo/clientes.js';
import { escapeHtml } from '../nucleo/utilidades.js';

export interface DatosCorreoCodigoAcceso {
  to: string;
  padreNombre: string;
  colegioNombre: string;
  codigo: string;
  alumnos: { nombre: string; apellido: string; grado: string; division: string; turno: string }[];
  solicitaFotoHermanos?: boolean;
  /**
   * Auditoría 03/10 noche (C1): inscripción aprobada sola contra el padrón. El email lleva un botón
   * para que el titular de la casilla del padrón confirme que fue él quien se inscribió (con el
   * tutor y el DNI parcial que se cargaron); hasta entonces no se puede ingresar al portal.
   */
  confirmacion?: { link: string; tutor: string; dniParcial: string; primerIngreso?: boolean };
  /** 14/10/2026: clave de Resend (descarta un segundo envío igual en 24 h): «Enviar todos» no lo duplica. */
  idempotencyKey?: string;
}

/** Auditoría 03/10 noche (C1): llave del link "Confirmar mi email" de una inscripción. */
export function tokenConfirmacionAcceso(inscripcionId: unknown): string | null {
  const secreto = process.env.PEDIDOS_ACCESO_SECRET?.trim() || getAdminSessionSecret();
  if (!secreto || !inscripcionId) return null;
  return crypto.createHmac('sha256', secreto).update(`confirmar-acceso:${inscripcionId}`).digest('base64url').slice(0, 32);
}

export function linkConfirmacionAcceso(inscripcionId: string): string | null {
  const token = tokenConfirmacionAcceso(inscripcionId);
  if (!token) return null;
  const appUrl = (process.env.APP_URL || 'https://www.retratoescolar.com.ar').replace(/\/+$/, '');
  return `${appUrl}/?confirmar-acceso=${encodeURIComponent(`${inscripcionId}.${token}`)}`;
}

export function dniParcialServidor(dni: unknown): string {
  const d = String(dni || '').replace(/\D/g, '');
  return d.length > 3 ? `${'•'.repeat(d.length - 3)}${d.slice(-3)}` : '•••';
}

/**
 * Auditoría 03/10 noche (C1): una inscripción aprobada sola (padrón) queda con acceso_confirmado_at
 * en null hasta que el titular del email del padrón toca "Confirmar mi email". `undefined` (la
 * columna todavía no existe en la base) se toma como confirmada para no trabar a nadie.
 */
export function inscripcionSinConfirmar(fila: any): boolean {
  return Boolean(fila) && fila.estado === 'aceptado' && fila.acceso_confirmado_at === null;
}

/** Envía por email el Código de Acceso a una familia recién aprobada (panel admin -> Inscriptos -> Aceptar y Enviar) */
export async function enviarCorreoCodigoAcceso(datos: DatosCorreoCodigoAcceso) {
  const { to, padreNombre, colegioNombre, codigo, alumnos, solicitaFotoHermanos, confirmacion } = datos;

  if (!to || !to.includes('@')) {
    return { success: false, error: 'Email de destino inválido' };
  }

  const resend = getResendClient();
  if (!resend) {
    return { success: false, error: 'RESEND_API_KEY no está configurada en el servidor.' };
  }

  const fromEmail = process.env.RESEND_FROM_EMAIL || 'Retrato Escolar <fotos@retratoescolar.com.ar>';
  // Escapados porque van directo dentro del HTML del correo (ver escapeHtml arriba) — vienen
  // del formulario público de inscripción, así que no se puede confiar en que no traigan HTML.
  const nombreDestinatario = escapeHtml(padreNombre?.trim() || 'Familia');
  const colegioStr = escapeHtml(colegioNombre?.trim() || 'la institución');

  const listaHijosHtml = alumnos
    .map(
      (a) =>
        `<li style="margin-bottom:4px;">${escapeHtml(a.nombre)} ${escapeHtml(a.apellido)} — ${escapeHtml(a.grado)} "${escapeHtml(a.division)}", Turno ${escapeHtml(a.turno)}</li>`
    )
    .join('');

  const htmlContent = `
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Tu Código de Acceso - Retrato Escolar</title>
</head>
<body style="margin: 0; padding: 0; background-color: #f8fafc; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; color: #1e293b;">
  <div style="max-width: 600px; margin: 24px auto; background-color: #ffffff; border-radius: 16px; border: 1px solid #e2e8f0; overflow: hidden; box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.05);">
    <div style="background-color: #0f172a; padding: 32px 24px; text-align: center; border-bottom: 3px solid #f59e0b;">
      <div style="font-size: 11px; font-weight: 800; letter-spacing: 2px; color: #f59e0b; text-transform: uppercase; margin-bottom: 6px;">
        RETRATO ESCOLAR • EDICIÓN 2026
      </div>
      <h1 style="color: #ffffff; margin: 0; font-size: 22px; font-weight: 800; letter-spacing: -0.5px;">
        ¡Tu inscripción fue validada!
      </h1>
      <p style="color: #94a3b8; font-size: 13px; margin: 6px 0 0 0;">${colegioStr}</p>
    </div>
    <div style="padding: 28px 24px;">
      <p style="font-size: 15px; line-height: 1.6; margin-top: 0;">Hola <strong>${nombreDestinatario}</strong>,</p>
      <p style="font-size: 14px; line-height: 1.6; color: #334155;">
        Te confirmamos que tu registro familiar para el ciclo escolar 2026 en <strong>${colegioStr}</strong> ha sido validado con éxito.
      </p>
      <p style="font-size: 13px; font-weight: 700; color: #0f172a; margin-bottom: 6px;">Alumnos vinculados a su cuenta familiar:</p>
      <ul style="font-size: 13px; color: #334155; padding-left: 20px; margin-top: 0;">${listaHijosHtml}</ul>
      ${solicitaFotoHermanos ? '<p style="font-size:12px;color:#334155;">✓ Foto de hermanos juntos: solicitada (tiene un costo aparte, no está incluida en el kit; te avisamos el día y el lugar)</p>' : ''}
      <div style="margin: 24px 0; text-align: center; background-color: #fffbeb; border: 1px solid #fde68a; border-radius: 12px; padding: 18px;">
        <div style="font-size: 11px; font-weight: 800; text-transform: uppercase; letter-spacing: 1px; color: #92400e; margin-bottom: 6px;">
          Su Código de Acceso
        </div>
        <div style="font-size: 26px; font-weight: 800; color: #0f172a; font-family: monospace; letter-spacing: 2px;">
          ${escapeHtml(codigo)}
        </div>
      </div>
      ${confirmacion ? `<div style="margin: 0 0 20px 0; background-color: #eff6ff; border: 1px solid #bfdbfe; border-radius: 12px; padding: 16px; font-size: 13px; line-height: 1.6; color: #1e3a8a;">
        ${confirmacion.primerIngreso
          ? `<strong>Para tu primer ingreso, confirmá que sos vos.</strong> Tocá el botón y escribí el DNI de <strong>${escapeHtml(confirmacion.tutor)}</strong>: desde ahí ese DNI queda como tu clave para entrar, junto con el código del curso.`
          : `<strong>Antes de entrar, confirmá que fuiste vos.</strong> La inscripción se hizo a nombre de <strong>${escapeHtml(confirmacion.tutor)}</strong> (DNI terminado en ${escapeHtml(confirmacion.dniParcial)}).`}
        <div style="text-align:center;margin:14px 0 8px 0;"><a href="${escapeHtml(confirmacion.link)}" style="display:inline-block;background-color:#1d4ed8;color:#ffffff;text-decoration:none;font-weight:800;padding:12px 22px;border-radius:10px;">Sí, fui yo: confirmar mi email</a></div>
        Si vos <strong>no</strong> hiciste esta inscripción, no toques el botón y respondé este email para avisarnos.
      </div>` : ''}
      <p style="font-size: 13px; line-height: 1.6; color: #334155;">Con este único código podrá:</p>
      <ol style="font-size: 13px; color: #334155; padding-left: 20px;">
        <li>Ingresar a retratoescolar.com.ar con su nombre y apellido, su DNI y este código</li>
        <li>Ver las galerías individuales y grupales de todos sus hijos sin usar códigos diferentes</li>
        <li>Seleccionar las fotos favoritas y armar un pedido consolidado en un solo pago</li>
      </ol>
      <p style="font-size: 13px; line-height: 1.6; color: #334155;"><strong>¿Preferís dejarlo pago?</strong> Si todavía no están las fotos, al ingresar podés reservar el kit y pagarlo por adelantado; cuando estén, elegís las fotos sin volver a pagar.</p>
      <!-- Auditoría 2026-09-22 (pedido de Pablo): este código lo comparte todo el curso, así que
           además de él hace falta escribir el nombre y DNI del tutor para que el sitio identifique
           a la familia exacta — se lo aclaramos acá para que no se sorprendan al entrar. -->
      <p style="font-size: 12px; color: #92400e; background-color: #fffbeb; border: 1px solid #fde68a; border-radius: 8px; padding: 10px 12px; line-height: 1.5;">
        <strong>Importante:</strong> este código es el mismo para todo el curso. Al ingresar, además del código va a tener que completar el <strong>nombre y apellido</strong> y el <strong>DNI</strong> de quien se inscribió, para que el sistema reconozca a sus hijos.
      </p>
      <div style="font-size: 12px; color: #64748b; line-height: 1.6; border-top: 1px solid #e2e8f0; padding-top: 16px; margin-top: 16px;">
        Para cualquier consulta, nuestro equipo fotográfico está a su entera disposición.
      </div>
    </div>
    <div style="background-color: #f1f5f9; padding: 18px 24px; text-align: center; font-size: 11px; color: #64748b; border-top: 1px solid #e2e8f0;">
      © 2026 Retrato Escolar • Fotografía Escolar Profesional<br>
      <a href="https://retratoescolar.com.ar" style="color: #d97706; text-decoration: none; font-weight: 600;">retratoescolar.com.ar</a>
    </div>
  </div>
</body>
</html>
  `;

  // Mismo bug que enviarCorreoFotosHD: sin mirar `error`, un envío rechazado por Resend se
  // informaba como exitoso (al panel, y a la familia como "te enviamos el código por email").
  const data = await resend.emails.send({
    from: fromEmail,
    replyTo: resendReplyTo,
    to: [to],
    subject: `Retrato Escolar: tu código de acceso — ${colegioNombre?.trim() || 'la institución'}`, // sin el código en el asunto (auditoría 28/9)
    html: htmlContent,
  }, datos.idempotencyKey ? { idempotencyKey: datos.idempotencyKey } : undefined);
  if (data.error) {
    console.error('[Resend] No se pudo enviar el correo con el código de acceso:', data.error);
    return { success: false, error: data.error.message || 'Resend rechazó el envío del correo.' };
  }

  return { success: true, messageId: data.data?.id, from: fromEmail, to };
}
