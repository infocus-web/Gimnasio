// «Lo que la IA tiene que saber» (25/10/2026, Pablo: «debe actualizarse en tiempo real, con todos los cambios que
// vamos haciendo»). Texto libre que Pablo escribe en Consultas con las decisiones del momento (por ejemplo, el día de
// la grupal de Sala 4 C). Se guarda en borradores_admin (clave 'novedades-ia': RLS sin políticas, sólo el servidor;
// NO en configuracion, que tiene lectura pública) y la IA de consultas lo recibe en cada respuesta, con prioridad sobre
// las reglas fijas (contextoConsultas.ts). No hace falta un deploy.
import express from 'express';
import type { Request, Response } from 'express';
import { requireAdminAuth } from '../nucleo/auth.js';
import { getServerSupabase } from '../nucleo/clientes.js';
import { fijarNovedadesEquipo } from './contextoConsultas.js';
import { olvidarNovedadesEquipo } from './consultas.js';

const rutas = express.Router();
const CLAVE = 'novedades-ia';

rutas.get('/api/admin/novedades-ia', requireAdminAuth, async (_req: Request, res: Response) => {
  try {
    const supabase = getServerSupabase();
    if (!supabase) return res.status(500).json({ success: false, error: 'Supabase no configurado en el servidor' });
    const { data, error } = await supabase.from('borradores_admin').select('contenido, updated_at').eq('clave', CLAVE).maybeSingle();
    if (error) throw error;
    return res.json({ success: true, texto: typeof data?.contenido === 'string' ? data.contenido : '', actualizado: data?.updated_at || null });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err?.message || 'No se pudo leer.' });
  }
});

rutas.put('/api/admin/novedades-ia', requireAdminAuth, async (req: Request, res: Response) => {
  try {
    const supabase = getServerSupabase();
    if (!supabase) return res.status(500).json({ success: false, error: 'Supabase no configurado en el servidor' });
    const texto = String(req.body?.texto ?? '').trim();
    if (texto.length > 4000) return res.status(400).json({ success: false, error: 'Hasta 4000 caracteres.' });
    const ahora = new Date().toISOString();
    const { error } = await supabase.from('borradores_admin').upsert([{ clave: CLAVE, contenido: texto, updated_at: ahora }], { onConflict: 'clave' });
    if (error) throw error;
    fijarNovedadesEquipo(texto); // esta instancia ya la usa; las demás la releen en menos de 30 s
    olvidarNovedadesEquipo();
    return res.json({ success: true, actualizado: ahora });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err?.message || 'No se pudo guardar.' });
  }
});

export { rutas as rutasNovedadesIa };
