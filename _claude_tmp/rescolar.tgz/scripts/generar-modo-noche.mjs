// Genera src/modoNoche.css: el "modo noche" rápido (pedido de Pablo, 27/9/2026).
// Recorre las clases de Tailwind que usa la web y, dentro de un contenedor con la clase
// `modo-noche`, cambia los colores claros por equivalentes oscuros. Se corre solo antes de cada
// build (ver "build" en package.json), así las pantallas nuevas quedan cubiertas sin tocar nada.
import { readdirSync, readFileSync, statSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';

const RAIZ = new URL('../src/', import.meta.url).pathname;
const NEUTROS = ['slate', 'gray', 'zinc', 'neutral', 'stone'];
const COLORES = ['red', 'orange', 'amber', 'yellow', 'lime', 'green', 'emerald', 'teal', 'cyan', 'sky', 'blue', 'indigo', 'violet', 'purple', 'fuchsia', 'pink', 'rose'];
const V = (c, s) => `var(--color-${c}-${s})`;
const FONDO = V('slate', 950); // fondo de página
const SUPERFICIE = V('slate', 900); // tarjetas (antes blanco)
const mezcla = (c, pct, base = SUPERFICIE) => `color-mix(in oklab, ${V(c, 500)} ${pct}%, ${base})`;

function archivos(dir) {
  return readdirSync(dir).flatMap((n) => {
    const p = join(dir, n);
    if (statSync(p).isDirectory()) return n === '__tests__' ? [] : archivos(p);
    return /\.(tsx|ts)$/.test(n) ? [p] : [];
  });
}

const tokens = new Set();
for (const f of archivos(RAIZ)) {
  for (const t of readFileSync(f, 'utf8').split(/[\s"'`{}()]+/)) {
    if (/^([a-z-]+:)*(bg|text|border|border-[trblxy]|divide|ring|from|via|to|placeholder)-[a-z]+(-\d{2,3})?(\/\d+)?$/.test(t)) tokens.add(t);
  }
}

// Devuelve [propiedad, valor] para el color de noche de una utilidad, o null si queda igual.
function reemplazo(prop, color, tono) {
  const s = Number(tono);
  const neutro = NEUTROS.includes(color);
  const esColor = COLORES.includes(color);
  const esBlanco = color === 'white';
  const esNegro = color === 'black';
  if (!neutro && !esColor && !esBlanco && !esNegro) return null;
  if (prop === 'bg') {
    if (esBlanco) return ['background-color', SUPERFICIE];
    if (neutro) return ({ 50: FONDO, 100: V('slate', 800), 200: V('slate', 700), 300: V('slate', 600) })[s] ? ['background-color', ({ 50: FONDO, 100: V('slate', 800), 200: V('slate', 700), 300: V('slate', 600) })[s]] : null;
    if (esColor) return ({ 50: 12, 100: 20, 200: 30 })[s] ? ['background-color', mezcla(color, ({ 50: 12, 100: 20, 200: 30 })[s])] : null;
    return null;
  }
  if (prop === 'text' || prop === 'placeholder') {
    if (esNegro) return ['color', V('slate', 100)];
    if (neutro) return ({ 950: 100, 900: 100, 800: 100, 700: 200, 600: 300, 500: 400 })[s] ? ['color', V('slate', ({ 950: 100, 900: 100, 800: 100, 700: 200, 600: 300, 500: 400 })[s])] : null;
    if (esColor) return ({ 950: 200, 900: 200, 800: 200, 700: 300, 600: 400 })[s] ? ['color', V(color, ({ 950: 200, 900: 200, 800: 200, 700: 300, 600: 400 })[s])] : null;
    return null;
  }
  if (prop.startsWith('border') || prop === 'divide' || prop === 'ring') {
    const cssProp = prop === 'ring' ? '--tw-ring-color' : 'border-color';
    if (esBlanco) return [cssProp, V('slate', 700)];
    if (neutro) return s <= 300 ? [cssProp, V('slate', s <= 100 ? 800 : 700)] : null;
    if (esColor) return s <= 300 ? [cssProp, mezcla(color, 45)] : null;
    return null;
  }
  if (prop === 'from' || prop === 'via' || prop === 'to') {
    const v = esBlanco ? SUPERFICIE : neutro && s <= 200 ? (s <= 50 ? FONDO : V('slate', 800)) : esColor && s <= 200 ? mezcla(color, s <= 50 ? 12 : 22) : null;
    return v ? [`--tw-gradient-${prop}`, v] : null;
  }
  return null;
}

const escapar = (t) => t.replace(/([:/.[\]])/g, '\\$1');
const PSEUDO = { hover: ':hover', focus: ':focus', 'focus-visible': ':focus-visible', active: ':active', disabled: ':disabled', 'focus-within': ':focus-within' };
const MEDIA = { sm: 640, md: 768, lg: 1024, xl: 1280, '2xl': 1536 };

const reglas = [];
const medias = {};
for (const t of [...tokens].sort()) {
  const partes = t.split(':');
  const base = partes.pop();
  const m = base.match(/^(bg|text|border(?:-[trblxy])?|divide|ring|from|via|to|placeholder)-([a-z]+)(?:-(\d{2,3}))?(?:\/\d+)?$/);
  if (!m) continue;
  const [, prop, color, tono = ''] = m;
  const r = reemplazo(prop, color, tono);
  if (!r) continue;
  let selector = `.modo-noche .${escapar(t)}`;
  let media = null;
  let valido = true;
  for (const v of partes) {
    if (PSEUDO[v]) selector += PSEUDO[v];
    else if (v === 'group-hover') selector = selector.replace('.modo-noche ', '.modo-noche .group:hover ');
    else if (MEDIA[v]) media = MEDIA[v];
    else valido = false;
  }
  if (!valido) continue;
  if (prop === 'divide') selector += ' > :not(:last-child)';
  if (prop === 'placeholder') selector += '::placeholder';
  const regla = `${selector}{${r[0]}:${r[1]}}`;
  if (media) (medias[media] ||= []).push(regla);
  else reglas.push(regla);
}

// Textos oscuros sobre botones/carteles de color fuerte (ej. botón amarillo con letra negra): se
// dejan como estaban para que se sigan leyendo.
const fuertes = [...tokens].filter((t) => /^bg-([a-z]+)-(300|400|500)$/.test(t) && COLORES.includes(t.split('-')[1]));
const textosOscuros = [...tokens].filter((t) => /^text-(slate|gray|zinc|neutral|stone)-(700|800|900|950)$/.test(t) || t === 'text-black');
for (const b of fuertes) {
  for (const tx of textosOscuros) {
    const original = tx === 'text-black' ? '#000' : V(tx.split('-')[1], tx.split('-')[2]);
    reglas.push(`.modo-noche .${escapar(b)}.${escapar(tx)},.modo-noche .${escapar(b)} .${escapar(tx)}{color:${original}}`);
  }
}

const css = [
  '/* ARCHIVO GENERADO por scripts/generar-modo-noche.mjs — no editar a mano. */',
  `.modo-noche{color-scheme:dark;background-color:${FONDO};color:${V('slate', 100)}}`,
  `.modo-noche :where(input,select,textarea){background-color:${SUPERFICIE};color:${V('slate', 100)};border-color:${V('slate', 700)}}`,
  `.modo-noche :where(img,video,canvas){color-scheme:normal}`,
  ...reglas,
  ...Object.entries(medias).sort((a, b) => a[0] - b[0]).map(([px, rs]) => `@media (min-width:${px}px){${rs.join('')}}`),
].join('\n');
writeFileSync(join(RAIZ, 'modoNoche.css'), css + '\n');
console.log(`modo noche: ${reglas.length} reglas a partir de ${tokens.size} clases`);
