// Genera public/eventos/lupa.js (la lupa de la galería de eventos) a partir de src/utils/lupaMuestra.ts,
// que es la que usa el portal de colegios. Así hay una sola lupa para mantener. Se corre sola antes de
// cada build (ver "build" en package.json). 04/10/2026.
import { buildSync } from 'esbuild';

buildSync({
  entryPoints: [new URL('../src/utils/lupaMuestra.ts', import.meta.url).pathname],
  outfile: new URL('../public/eventos/lupa.js', import.meta.url).pathname,
  bundle: true,
  format: 'iife',
  globalName: 'LupaMuestra',
  target: 'es2018',
  charset: 'utf8',
  banner: { js: '// GENERADO desde src/utils/lupaMuestra.ts por scripts/generar-lupa-eventos.mjs: no editar a mano.' },
  logLevel: 'warning',
});
