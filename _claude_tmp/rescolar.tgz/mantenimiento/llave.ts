// MODO MANTENIMIENTO (09/10/2026, pedido de Pablo): mientras está prendido, toda la web muestra
// "Estamos realizando mantenimiento a la plataforma…" (middleware.ts, en la raíz). Pablo entra igual
// con su PIN de admin desde esa pantalla: el servidor le deja una cookie con una llave firmada que
// vale 24 h y el middleware la controla. Este archivo lo usan los dos lados (servidor Node y
// middleware de Vercel), por eso usa Web Crypto (crypto.subtle), que existe en ambos.

/** Nombre de la cookie que deja pasar a Pablo mientras la web está en mantenimiento. */
export const COOKIE_MANTENIMIENTO = 'rs_mantenimiento';
/** Cuánto dura la llave (segundos). */
export const DURACION_LLAVE_MANTENIMIENTO_SEG = 24 * 60 * 60;
/** Clave de la tabla `configuracion` donde se guarda el interruptor ('activo' / 'inactivo'). */
export const CLAVE_CONFIG_MANTENIMIENTO = 'mantenimiento';

const codificador = new TextEncoder();

function base64url(bytes: ArrayBuffer): string {
  let binario = '';
  for (const b of new Uint8Array(bytes)) binario += String.fromCharCode(b);
  return btoa(binario).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

async function firmar(secreto: string, texto: string): Promise<string> {
  const clave = await crypto.subtle.importKey('raw', codificador.encode(secreto), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']);
  return base64url(await crypto.subtle.sign('HMAC', clave, codificador.encode(texto)));
}

function igualesSinFugas(a: string, b: string): boolean {
  if (a.length !== b.length) return false;
  let diferencia = 0;
  for (let i = 0; i < a.length; i++) diferencia |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return diferencia === 0;
}

/** Arma la llave "vence.firma" (vence = segundos Unix). */
export async function crearLlaveMantenimiento(secreto: string, ahoraMs: number = Date.now()): Promise<string> {
  const vence = Math.floor(ahoraMs / 1000) + DURACION_LLAVE_MANTENIMIENTO_SEG;
  return `${vence}.${await firmar(secreto, `mantenimiento-bypass:${vence}`)}`;
}

/** ¿La llave es válida y no venció? */
export async function llaveMantenimientoValida(secreto: string | null | undefined, llave: string | null | undefined, ahoraMs: number = Date.now()): Promise<boolean> {
  if (!secreto || !llave) return false;
  const coincidencia = /^(\d{9,12})\.([A-Za-z0-9_-]{20,100})$/.exec(llave);
  if (!coincidencia) return false;
  const vence = Number(coincidencia[1]);
  if (!Number.isFinite(vence) || vence * 1000 < ahoraMs) return false;
  // Una llave que vence en más de 24 h no la armó este código: se rechaza.
  if (vence * 1000 > ahoraMs + (DURACION_LLAVE_MANTENIMIENTO_SEG + 300) * 1000) return false;
  const esperada = await firmar(secreto, `mantenimiento-bypass:${vence}`);
  return igualesSinFugas(coincidencia[2], esperada);
}

/** Valor de la cookie `nombre` en un encabezado Cookie. */
export function leerCookie(encabezado: string | null | undefined, nombre: string): string | null {
  for (const parte of String(encabezado || '').split(';')) {
    const [k, ...resto] = parte.trim().split('=');
    if (k === nombre) return resto.join('=') || null;
  }
  return null;
}

/**
 * Rutas que siguen andando durante el mantenimiento: avisos de pago (Mercado Pago, Nave, eventos),
 * correo entrante, tareas automáticas y el ingreso de Pablo. Así no se pierde un pago que se estaba
 * haciendo justo cuando se prendió el mantenimiento.
 */
export function rutaLibreEnMantenimiento(pathname: string): boolean {
  const p = pathname.replace(/\/+$/, '') || '/';
  return (
    p.startsWith('/api/webhooks/') ||
    p.startsWith('/api/cron/') ||
    p === '/api/mercadopago/webhook' ||
    p === '/mercadopago/webhook' ||
    p === '/api/nave/webhook' ||
    p === '/api/nave/webhook-sandbox' ||
    p === '/api/eventos/webhook-mp' ||
    p === '/api/mantenimiento/acceso'
  );
}

/** Texto que pidió Pablo. */
export const TEXTO_MANTENIMIENTO = 'Estamos realizando mantenimiento a la plataforma, en unas horas estará nuevamente online';

/** Página que ve cualquiera mientras dura el mantenimiento (sin scripts: sólo HTML y estilos). */
export function paginaMantenimiento(error?: 'pin' | 'muchos' | null): string {
  const aviso =
    error === 'pin'
      ? '<p class="error">PIN incorrecto.</p>'
      : error === 'muchos'
        ? '<p class="error">Demasiados intentos. Probá de nuevo en unos minutos.</p>'
        : '';
  return `<!doctype html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex">
<title>Retrato Escolar · Mantenimiento</title>
<style>
  *{box-sizing:border-box}
  body{margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;padding:24px 16px;background:#f8fafc;color:#0f172a;font:16px/1.5 system-ui,-apple-system,"Segoe UI",Roboto,sans-serif}
  main{max-width:520px;width:100%;text-align:center}
  .marca{font-weight:800;letter-spacing:.02em;color:#334155;margin:0 0 28px}
  .icono{width:56px;height:56px;margin:0 auto 20px;border-radius:50%;background:#e2e8f0;display:flex;align-items:center;justify-content:center;font-size:26px}
  h1{font-size:22px;line-height:1.35;margin:0 0 12px}
  p{margin:0;color:#475569}
  /* Acceso de Pablo: discreto, en la esquina de abajo a la derecha (pedido de Pablo 09/10). */
  details{position:fixed;right:16px;bottom:14px;font-size:12px;color:#94a3b8;text-align:right;max-width:calc(100vw - 32px)}
  summary{cursor:pointer;list-style:none}
  summary::-webkit-details-marker{display:none}
  form{margin-top:8px;display:flex;gap:8px;justify-content:flex-end;flex-wrap:wrap}
  input{padding:8px 10px;border:1px solid #cbd5e1;border-radius:8px;font:inherit;min-width:0;width:180px}
  button{padding:8px 14px;border:0;border-radius:8px;background:#0f172a;color:#fff;font:inherit;font-weight:700;cursor:pointer}
  .error{color:#b91c1c;font-weight:700;margin-top:8px}
  @media (prefers-color-scheme: dark){
    body{background:#0f172a;color:#f1f5f9}
    .marca{color:#cbd5e1}
    .icono{background:#1e293b}
    p{color:#cbd5e1}
    input{background:#1e293b;border-color:#334155;color:#f1f5f9}
    button{background:#f1f5f9;color:#0f172a}
  }
</style>
</head>
<body>
<main>
  <p class="marca">RETRATO ESCOLAR</p>
  <div class="icono" aria-hidden="true">🛠️</div>
  <h1>${TEXTO_MANTENIMIENTO}</h1>
  <p>Gracias por la paciencia.</p>
  <details${aviso ? ' open' : ''}>
    <summary>Administrador</summary>
    <form method="post" action="/api/mantenimiento/acceso">
      <input type="password" name="pin" placeholder="PIN del panel" autocomplete="current-password" required>
      <button type="submit">Entrar</button>
    </form>
    ${aviso}
  </details>
</main>
</body>
</html>`;
}
