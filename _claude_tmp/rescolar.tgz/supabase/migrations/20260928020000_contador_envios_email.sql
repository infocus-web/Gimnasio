-- Auditoría 28/9: cuenta los emails enviados por día para avisar antes de llegar al cupo de Resend
-- (plan gratuito: 100 por día y 3.000 por mes). Ver contarEnviosEmail en server.ts.
create table if not exists public.envios_email_diarios (
  dia date primary key,
  cantidad integer not null default 0
);
alter table public.envios_email_diarios enable row level security;
revoke all on public.envios_email_diarios from anon, authenticated;

create or replace function public.sumar_envios_email(p_cantidad integer)
returns table (hoy integer, mes integer)
language plpgsql
security definer
set search_path = public
as $$
declare
  v_dia date := (now() at time zone 'America/Argentina/Buenos_Aires')::date;
begin
  insert into public.envios_email_diarios as e (dia, cantidad) values (v_dia, p_cantidad)
  on conflict (dia) do update set cantidad = e.cantidad + p_cantidad;
  return query
    select (select cantidad from public.envios_email_diarios where dia = v_dia),
           (select coalesce(sum(cantidad), 0)::integer from public.envios_email_diarios where dia > v_dia - 30);
end;
$$;
revoke all on function public.sumar_envios_email(integer) from public, anon, authenticated;
grant execute on function public.sumar_envios_email(integer) to service_role;
