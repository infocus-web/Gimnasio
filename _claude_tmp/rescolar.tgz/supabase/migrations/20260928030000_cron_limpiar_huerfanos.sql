-- Auditoría 28/9: limpieza semanal de archivos huérfanos (fotos que ya no están en el catálogo y
-- .zip de pedidos no cobrados, con más de 3 días). Domingos 07:30 UTC = 04:30 de Argentina.
select cron.schedule('limpiar-huerfanos', '30 7 * * 0', $$
  select net.http_post(
    url := 'https://www.retratoescolar.com.ar/api/cron/limpiar-huerfanos',
    headers := jsonb_build_object('Authorization', 'Bearer ' || (select secreto from public.tareas_programadas_secreto where id = 1), 'Content-Type', 'application/json'),
    body := '{}'::jsonb,
    timeout_milliseconds := 120000
  );
$$);
