-- Panel del laboratorio (27/9/2026): lotes de descarga sin repetir y aviso diario.
create table if not exists public.lotes_laboratorio (
  id uuid primary key default gen_random_uuid(),
  numero bigint generated always as identity,
  created_at timestamptz not null default now(),
  cantidad integer not null default 0,
  en_produccion_at timestamptz
);
alter table public.lotes_laboratorio enable row level security;
revoke all on public.lotes_laboratorio from anon, authenticated;
alter table public.pedidos add column if not exists lote_lab_id uuid references public.lotes_laboratorio(id) on delete set null;
create index if not exists pedidos_lote_lab_id_idx on public.pedidos (lote_lab_id);
-- Aviso diario al laboratorio: 12:00 UTC = 9:00 de Argentina.
select cron.schedule('aviso-laboratorio', '0 12 * * *', $$
  select net.http_post(
    url := 'https://www.retratoescolar.com.ar/api/cron/aviso-laboratorio',
    headers := jsonb_build_object('Authorization', 'Bearer ' || (select secreto from public.tareas_programadas_secreto where id = 1), 'Content-Type', 'application/json'),
    body := '{}'::jsonb,
    timeout_milliseconds := 30000
  );
$$);
