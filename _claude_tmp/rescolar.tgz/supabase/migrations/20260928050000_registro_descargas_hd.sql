-- Registro de descargas HD (pedido de Pablo 28/9): el botón de descarga del correo pasa por
-- /api/descargas/:id, que anota la primera vez que la familia lo tocó, la última y cuántas veces.
-- El panel lo muestra como "⬇ Descargado dd/mm". Los pedidos digitales con el correo HD enviado
-- pasan a la lista "Entregados" del panel (eso sale de email_enviado, que ya existía).
alter table public.pedidos add column if not exists descarga_hd_at timestamptz;
alter table public.pedidos add column if not exists descarga_hd_ultima_at timestamptz;
alter table public.pedidos add column if not exists descargas_hd integer not null default 0;
