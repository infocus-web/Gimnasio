-- Recordatorio automático de pago pendiente (pedido de Pablo 28/9): a las 12 hs de registrado un
-- pedido que sigue sin pagar y sin comprobante, la familia recibe UN email recordándoselo (ver
-- /api/cron/recordar-pagos-pendientes en server.ts). Esta columna marca cuándo se mandó, para no
-- repetirlo; el panel la muestra como "Recordatorio enviado".
alter table public.pedidos add column if not exists recordatorio_pago_at timestamptz;

-- Cada hora, a los 20 minutos.
select cron.unschedule('recordar-pagos-pendientes') where exists (select 1 from cron.job where jobname = 'recordar-pagos-pendientes');
select cron.schedule(
  'recordar-pagos-pendientes',
  '20 * * * *',
  $$select net.http_post(
      url := 'https://www.retratoescolar.com.ar/api/cron/recordar-pagos-pendientes',
      headers := jsonb_build_object('Authorization', 'Bearer ' || (select secreto from public.tareas_programadas_secreto where id = 1), 'Content-Type', 'application/json'),
      body := '{}'::jsonb,
      timeout_milliseconds := 55000
    )$$
);
