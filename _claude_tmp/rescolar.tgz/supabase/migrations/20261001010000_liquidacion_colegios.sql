-- Participación del colegio sobre la GANANCIA NETA (pedido de Pablo 1/10). Ver la sección
-- "LIQUIDACIÓN AL COLEGIO" de server.ts y la cláusula OCTAVA BIS de public/convenio.html.
alter table public.colegios add column if not exists porcentaje_participacion numeric(5,2) not null default 30
  check (porcentaje_participacion >= 0 and porcentaje_participacion <= 100);
-- Porcentaje que quedó en el convenio que firmó cada colegio (manda sobre el de la tabla colegios).
alter table public.convenios_colegios add column if not exists porcentaje_participacion numeric(5,2);

-- Costos que se descuentan de la venta para calcular la ganancia neta (una sola fila, id = 1).
create table if not exists public.costos_liquidacion (
  id integer primary key default 1 check (id = 1),
  costo_carpeta numeric(12,2) not null default 0,
  costo_foto_20x30 numeric(12,2) not null default 0,
  costo_foto_15x21 numeric(12,2) not null default 0,
  comision_mercadopago_pct numeric(5,2) not null default 0,
  comision_nave_pct numeric(5,2) not null default 0,
  impuestos_pct numeric(5,2) not null default 0,
  updated_at timestamptz not null default now()
);
alter table public.costos_liquidacion enable row level security;
revoke all on public.costos_liquidacion from anon, authenticated;
insert into public.costos_liquidacion (id) values (1) on conflict (id) do nothing;
