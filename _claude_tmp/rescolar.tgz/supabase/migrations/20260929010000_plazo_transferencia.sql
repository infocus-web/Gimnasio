-- Plazo de la transferencia (pedido de Pablo 29/9): si la familia elige transferencia y no sube el
-- comprobante dentro de las 48 horas, el pedido se cancela solo (ver cancelarTransferenciasVencidas
-- en server.ts, que corre dentro de /api/cron/recordar-pagos-pendientes cada hora). La familia lo
-- ve antes de confirmar el pedido (casilla obligatoria) y con fecha y hora al subir el comprobante.
--
-- transferencia_desde: cuándo el pedido pasó a transferencia (al crearlo o al cambiar de medio de
--   pago; si vuelve a elegir transferencia después de probar otro medio, el reloj arranca de nuevo).
--   La completa el trigger de abajo, así ningún camino del servidor se la olvida. Los pedidos
--   anteriores a esta regla quedan en null y nunca se cancelan solos (no se les avisó el plazo).
-- transferencia_vencida_at: cuándo se canceló por vencer el plazo (para el mensaje a la familia y
--   para distinguirlo de otras cancelaciones).
alter table public.pedidos add column if not exists transferencia_desde timestamptz;
alter table public.pedidos add column if not exists transferencia_vencida_at timestamptz;

create or replace function public.pedidos_marcar_transferencia_desde()
returns trigger
language plpgsql
set search_path = public
as $$
begin
  if new.metodo_pago = 'transferencia' then
    if tg_op = 'INSERT' then
      new.transferencia_desde := coalesce(new.transferencia_desde, now());
    elsif old.metodo_pago is distinct from 'transferencia' then
      new.transferencia_desde := now();
    end if;
  end if;
  return new;
end;
$$;

drop trigger if exists pedidos_transferencia_desde on public.pedidos;
create trigger pedidos_transferencia_desde
  before insert or update of metodo_pago on public.pedidos
  for each row execute function public.pedidos_marcar_transferencia_desde();

create index if not exists pedidos_transferencias_por_vencer_idx
  on public.pedidos (transferencia_desde)
  where estado = 'pendiente_pago' and metodo_pago = 'transferencia' and comprobante_subido_at is null;
