-- Auditoría de seguridad 30/9 (ver server.ts, comentarios "Auditoría 30/9").
--
-- pedidos.cancelado_definitivo: pedido cancelado por el fotógrafo o por un arrepentimiento. Un pago
--   que llegue después (por ejemplo, la conciliación de un carrito de hermanos con reembolso parcial)
--   ya no lo vuelve a "pagado" ni le reenvía las fotos HD. Los cancelados por la pasarela (tarjeta
--   rechazada) siguen en false: si después se aprueba un pago, se registran como siempre.
alter table public.pedidos add column if not exists cancelado_definitivo boolean not null default false;
update public.pedidos set cancelado_definitivo = true
where estado = 'cancelado' and nota_espera like 'Cancelado por solicitud%';

-- padres_autorizados.origen: 'panel' (cargado por el fotógrafo) o 'link' (cargado desde el link de
--   padrón que el colegio comparte con todas las familias). Una fila de origen 'link' no alcanza
--   para aprobar sola una inscripción con hermanos.
alter table public.padres_autorizados add column if not exists origen text not null default 'panel';
-- Las filas que ya existían sin alumno ni curso vinieron todas del link del padrón (aplicado el 1/10).
update public.padres_autorizados set origen = 'link'
where origen = 'panel' and coalesce(alumno_nombre, '') = '' and coalesce(grado, '') = '';
