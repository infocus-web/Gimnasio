-- Convenio con cada colegio (27/9): el colegio lo completa y firma online desde /convenio.html?c=CODIGO,
-- haciéndose cargo de las autorizaciones de familias y docentes. Link propio (distinto del de padrón,
-- que se reenvía a las familias). Solo el servidor (Service Role) accede a la tabla.
alter table public.colegios add column if not exists codigo_convenio text;
create unique index if not exists colegios_codigo_convenio_unico on public.colegios (codigo_convenio) where codigo_convenio is not null;

create table if not exists public.convenios_colegios (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  colegio_id uuid not null references public.colegios(id) on delete cascade,
  version text not null,
  razon_social text not null,
  cuit text not null,
  domicilio text not null,
  email text not null,
  firmante_nombre text not null,
  firmante_dni text not null,
  firmante_cargo text not null,
  sin_restricciones boolean not null default false,
  alumnos_restringidos jsonb not null default '[]'::jsonb,
  texto_firmado text not null,
  hash_texto text not null,
  ip text,
  user_agent text
);
create index if not exists convenios_colegios_colegio_idx on public.convenios_colegios (colegio_id, created_at desc);
alter table public.convenios_colegios enable row level security;
revoke all on public.convenios_colegios from anon, authenticated;
