-- Auditoría 28/9: límite de intentos que sobrevive entre instancias de Vercel (antes vivía en la
-- memoria de cada instancia y en la práctica no limitaba: cada instancia nueva arrancaba de cero).
-- Lo usan el PIN del panel y el buscador público de pedidos (ver limitarFrecuenciaPersistente).
create table if not exists public.limites_intentos (
  clave text primary key,
  cantidad integer not null default 0,
  desde timestamptz not null default now()
);
alter table public.limites_intentos enable row level security;
revoke all on public.limites_intentos from anon, authenticated;

-- Suma un intento y devuelve cuántos segundos faltan para poder reintentar (0 = permitido).
create or replace function public.registrar_intento(p_clave text, p_max integer, p_ventana_seg integer)
returns integer
language plpgsql
security definer
set search_path = public
as $$
declare
  fila public.limites_intentos%rowtype;
begin
  insert into public.limites_intentos as l (clave, cantidad, desde)
  values (p_clave, 1, now())
  on conflict (clave) do update
    set cantidad = case when l.desde < now() - make_interval(secs => p_ventana_seg) then 1 else l.cantidad + 1 end,
        desde = case when l.desde < now() - make_interval(secs => p_ventana_seg) then now() else l.desde end
  returning * into fila;
  if fila.cantidad > p_max then
    return greatest(1, ceil(extract(epoch from (fila.desde + make_interval(secs => p_ventana_seg) - now())))::integer);
  end if;
  return 0;
end;
$$;
revoke all on function public.registrar_intento(text, integer, integer) from public, anon, authenticated;
grant execute on function public.registrar_intento(text, integer, integer) to service_role;

-- Limpieza diaria de claves viejas.
select cron.schedule('limpiar-limites-intentos', '17 4 * * *', $$delete from public.limites_intentos where desde < now() - interval '2 days'$$)
where exists (select 1 from pg_extension where extname = 'pg_cron');
