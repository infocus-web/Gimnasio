-- Totales de impresión por lote (27/9/2026): lo que el laboratorio le factura a Retrato Escolar.
alter table public.lotes_laboratorio
  add column if not exists carpetas integer not null default 0,
  add column if not exists fotos_20x30 integer not null default 0,
  add column if not exists fotos_15x21 integer not null default 0,
  add column if not exists fotos_sueltas integer not null default 0;
