-- Marco legal (27/9): prueba de lo que aceptó cada familia + Botón de arrepentimiento (Disp. 954/2025).

-- Aceptación de los términos al pagar (versión de src/legal/textosLegales.ts, fecha e IP).
alter table public.pedidos add column if not exists terminos_version text;
alter table public.pedidos add column if not exists terminos_aceptados_at timestamptz;
alter table public.pedidos add column if not exists terminos_ip text;
-- Confirmación expresa de la personalización al elegir las fotos de un pago anticipado (CCyC 1116).
alter table public.pedidos add column if not exists seleccion_confirmada_at timestamptz;
alter table public.pedidos add column if not exists seleccion_confirmada_version text;

-- Consentimientos de imagen y datos dados en la inscripción (casillas separadas).
alter table public.inscripciones add column if not exists consentimientos jsonb;
alter table public.inscripciones add column if not exists consentimientos_version text;
alter table public.inscripciones add column if not exists consentimientos_at timestamptz;
alter table public.inscripciones add column if not exists consentimientos_ip text;

-- Solicitudes hechas con el BOTÓN DE ARREPENTIMIENTO. Solo el servidor (Service Role) accede.
create table if not exists public.solicitudes_arrepentimiento (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  codigo text not null unique,
  pedido_ref text not null,
  pedido_id uuid references public.pedidos(id) on delete set null,
  nombre text not null,
  email text not null,
  motivo text,
  ip text,
  user_agent text,
  estado text not null default 'nueva' check (estado in ('nueva','aceptada','rechazada_excepcion','resuelta')),
  nota_admin text,
  atendida_at timestamptz
);
create index if not exists solicitudes_arrepentimiento_estado_idx on public.solicitudes_arrepentimiento (estado, created_at desc);
alter table public.solicitudes_arrepentimiento enable row level security;
revoke all on public.solicitudes_arrepentimiento from anon, authenticated;
