-- Pasar de Kit Solo Digital a Kit Impreso pagando la diferencia (27/9/2026).
-- La mejora es un pedido aparte (sólo la carpeta impresa, con las mismas fotos) que apunta al
-- pedido digital original. Así el laboratorio la ve como un pedido impreso más y el pedido digital
-- ya entregado no se toca.
alter table public.pedidos add column if not exists mejora_de_pedido_id uuid references public.pedidos(id) on delete set null;
create index if not exists pedidos_mejora_de_pedido_id_idx on public.pedidos (mejora_de_pedido_id) where mejora_de_pedido_id is not null;
