import app from '../eventos/servidor.js';

export default app;
