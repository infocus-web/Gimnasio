// MÓDULO DE EVENTOS (comuniones, actos) — servidor PARALELO al de kits (función aparte: api/eventos.ts).
// No importa nada de server.ts ni de src/; tablas `ev_*`, buckets `eventos-web`/`eventos-hd`, rutas `/api/eventos/...`.
import express, { Request, Response, NextFunction } from 'express';
import crypto from 'crypto';
import { createClient, SupabaseClient } from '@supabase/supabase-js';
import { Resend } from 'resend';
import QRCode from 'qrcode';
import { MercadoPagoConfig, Preference, Payment } from 'mercadopago';
import { columnasDescuentoEvento, consumirUsoEvento, devolverUsoEvento, ERROR_DESCUENTO_EVENTO, hayCodigoDescuento, registrarRutaDescuento, resolverDescuentoEvento, type DescuentoEvento } from './descuentos.js'; // 27/10/2026
import { calcularPedido, eventoCerrado, fechaOpcional, fechaPrimerEnvio, primerEnvioDespuesDelCierre, validarComprador } from './precios.js';
import { generarMuestras, sufijoMuestra } from './marcaAgua.js';
import { calcularRegion, encabezadosRecorte, leerPedidoRecorte, obtenerFuenteLupa, recortarConSello, rutaCopiaLupa } from '../lupa/recorte.js';
import { marcarPedidosVistos, ventasPorEvento, ventasVacias } from './resumenVentas.js';
import { archivosDelLote, puedePasarA, ETAPAS_ENTREGA, type ArchivoLote, type EtapaEntrega, type PedidoLote } from './laboratorio.js';
import {
  correoAvisoAdmin, correoFotosOnline, correoListoRetiro, correoPagoConfirmado, correoPagoPendienteMp, correoTransferenciaPendiente, escapeHtml, fechaHoraArgentina, pesos,
  DATOS_TRANSFERENCIA, PLAZO_TRANSFERENCIA_HORAS, type DatosCorreoPedido,
} from './correos.js';
import { enviarXlsx, estilarHoja, nuevoLibro } from './excel.js';
import { emailsFotoHermanos, esEventoFotoHermanos } from './fotoHermanos.js';
import { buscarEventoPorCodigo, guardarCodigoAnterior, motivoCodigoBloqueado, registrarRutasEdicion } from './edicionEvento.js';
import { asegurarOriginales, cargarOriginalEvento, copiarOriginalesDelPedido, registrarRutasDrive } from './originalesDrive.js'; // 17/10/2026: originales en Drive

const app = express();
// 4 MB: alcanza para el comprobante de transferencia en base64 (máx. 2,5 MB).
app.use(express.json({ limit: '4mb' }));

const BUCKET_WEB = 'eventos-web';
const BUCKET_HD = 'eventos-hd';
const MAX_ARCHIVOS_POR_TANDA = 40;

// ---------------------------------------------------------------------------
// Supabase (Service Role) — mismo criterio que el servidor de kits.
// ---------------------------------------------------------------------------
let supabaseInstancia: SupabaseClient | null = null;
function urlSupabase(): string {
  return (process.env.SUPABASE_URL || process.env.VITE_SUPABASE_URL || 'https://ntkqypxvrljuihbxdrtx.supabase.co').replace(/\/+$/, '');
}
function getSupabase(): SupabaseClient | null {
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!key) {
    console.error('[eventos] Falta SUPABASE_SERVICE_ROLE_KEY.');
    return null;
  }
  if (!supabaseInstancia) {
    supabaseInstancia = createClient(urlSupabase(), key.trim(), {
      auth: { persistSession: false, autoRefreshToken: false },
    });
  }
  return supabaseInstancia;
}
function urlPublicaWeb(ruta: string): string {
  return `${urlSupabase()}/storage/v1/object/public/${BUCKET_WEB}/${ruta.split('/').map(encodeURIComponent).join('/')}`;
}

// ---------------------------------------------------------------------------
// Autenticación: acepta el MISMO token que entrega /api/admin/login (server.ts).
// Copia de la verificación (función pura) para no tener que importar ni tocar server.ts.
// ---------------------------------------------------------------------------
function compararTimingSafe(a: string, b: string): boolean {
  try {
    const bufA = Buffer.from(a);
    const bufB = Buffer.from(b);
    return bufA.length === bufB.length && crypto.timingSafeEqual(bufA, bufB);
  } catch {
    return false;
  }
}

export function verificarTokenAdmin(token: string | undefined, secreto: string | undefined, ahora = Date.now()): boolean {
  if (!token || !secreto || !secreto.trim()) return false;
  const partes = token.split('.');
  if (partes.length !== 3) return false;
  const [ts, random, firma] = partes;
  if (!/^[0-9a-f]{32}$/.test(random) || !/^\d{10,16}$/.test(ts)) return false;
  const momento = parseInt(ts, 10);
  if (isNaN(momento) || ahora - momento > 24 * 60 * 60 * 1000) return false;
  const esperada = crypto.createHmac('sha256', secreto.trim()).update(`${ts}.${random}`).digest('hex');
  return compararTimingSafe(firma, esperada);
}

function tokenDelPedido(req: Request): string | undefined {
  const auth = req.headers.authorization;
  return auth?.startsWith('Bearer ') ? auth.substring(7) : (req.headers['x-admin-token'] as string | undefined);
}

function requireAdmin(req: Request, res: Response, next: NextFunction) {
  if (!process.env.ADMIN_SESSION_SECRET) {
    return res.status(500).json({ success: false, error: 'ADMIN_SESSION_SECRET no configurada en el servidor.' });
  }
  if (!verificarTokenAdmin(tokenDelPedido(req), process.env.ADMIN_SESSION_SECRET)) {
    return res.status(401).json({ success: false, error: 'Sesión vencida o inválida. Volvé a ingresar con el PIN.' });
  }
  next();
}

function conSupabase(res: Response): SupabaseClient | null {
  const sb = getSupabase();
  if (!sb) res.status(500).json({ success: false, error: 'Supabase no configurado en el servidor.' });
  return sb;
}

function errorInterno(res: Response, contexto: string, err: any) {
  console.error(`[eventos] ${contexto}:`, err);
  // Auditoría 02/10: nunca se devuelve el detalle técnico (Postgres, Storage, Mercado Pago) al navegador.
  return res.status(500).json({ success: false, error: `No se pudo ${contexto}. Probá de nuevo en un rato.` });
}

/** Lee TODAS las filas de una consulta en páginas de 1000 (Supabase corta en 1000 sin avisar). */
async function todasLasFilas<T = any>(armar: (desde: number, hasta: number) => PromiseLike<{ data: T[] | null; error: any }>): Promise<T[]> {
  const filas: T[] = [];
  for (let desde = 0; ; desde += 1000) {
    const { data, error } = await armar(desde, desde + 999);
    if (error) throw error;
    filas.push(...(data || []));
    if (!data || data.length < 1000) break;
  }
  return filas;
}

/** Corre una tarea por elemento con un máximo de N en paralelo (para no pasar el tiempo de la función). */
async function enParalelo<T, R>(lista: T[], maximo: number, tarea: (x: T) => Promise<R>): Promise<R[]> {
  const salida: R[] = new Array(lista.length);
  let i = 0;
  const trabajador = async () => {
    while (i < lista.length) {
      const pos = i++;
      salida[pos] = await tarea(lista[pos]);
    }
  };
  await Promise.all(Array.from({ length: Math.min(maximo, lista.length) }, trabajador));
  return salida;
}

const esUuid = (v: unknown): v is string => typeof v === 'string' && /^[0-9a-f-]{36}$/i.test(v);

// ---------------------------------------------------------------------------
// Validación de los datos de un evento (crear / editar).
// ---------------------------------------------------------------------------
export function normalizarCodigo(v: unknown): string {
  return String(v ?? '')
    .normalize('NFD').replace(/[̀-ͯ]/g, '')
    .toUpperCase().replace(/\s+/g, '').replace(/[^A-Z0-9-]/g, '');
}

// Auditoría 03/10 noche: los eventos NUEVOS llevan al final un sufijo al azar de 4 caracteres (sin
// O/0/I/1, con al menos una letra y un número) para que el código no se pueda adivinar
// (COMUNION26 → COMUNION26-K7QF). Los eventos que ya existen conservan su código.
const LETRAS_SUFIJO = 'ABCDEFGHJKLMNPQRSTUVWXYZ';
const DIGITOS_SUFIJO = '23456789';
const ALFABETO_SUFIJO = LETRAS_SUFIJO + DIGITOS_SUFIJO;
export function tieneSufijoAzar(codigo: string): boolean {
  const m = /-([A-HJ-NP-Z2-9]{4})$/.exec(codigo);
  return !!m && /[A-Z]/.test(m[1]) && /[2-9]/.test(m[1]);
}
export function sufijoAzar(azar: (n: number) => number = (n) => crypto.randomInt(n)): string {
  const c = Array.from({ length: 4 }, () => ALFABETO_SUFIJO[azar(ALFABETO_SUFIJO.length)]);
  if (!c.some((x) => DIGITOS_SUFIJO.includes(x))) c[azar(4)] = DIGITOS_SUFIJO[azar(DIGITOS_SUFIJO.length)];
  else if (!c.some((x) => LETRAS_SUFIJO.includes(x))) c[azar(4)] = LETRAS_SUFIJO[azar(LETRAS_SUFIJO.length)];
  return c.join('');
}
/** Código final de un evento nuevo: si ya trae el sufijo al azar se respeta; si no, se agrega (máx. 30). */
export function codigoConSufijo(codigo: string, azar?: (n: number) => number): string {
  if (tieneSufijoAzar(codigo)) return codigo;
  const base = codigo.slice(0, 25).replace(/-+$/, '');
  return `${base}-${sufijoAzar(azar)}`;
}

function precio(v: unknown): number | undefined {
  if (v === undefined || v === null || v === '') return undefined;
  const n = Math.round(Number(v));
  return Number.isFinite(n) && n >= 0 && n <= 10_000_000 ? n : undefined;
}

export function validarDatosEvento(entrada: any, parcial: boolean): { datos?: Record<string, unknown>; error?: string } {
  const e = entrada || {};
  const datos: Record<string, unknown> = {};
  if (e.codigo !== undefined || !parcial) {
    const codigo = normalizarCodigo(e.codigo);
    if (!/^[A-Z0-9-]{4,30}$/.test(codigo)) return { error: 'El código tiene que tener entre 4 y 30 letras o números (sin espacios). Ej: COMUNION26' };
    datos.codigo = codigo;
  }
  if (e.nombre !== undefined || !parcial) {
    const nombre = String(e.nombre ?? '').trim();
    if (nombre.length < 3 || nombre.length > 120) return { error: 'Poné un nombre para el evento (3 a 120 caracteres).' };
    datos.nombre = nombre;
  }
  if (e.lugar !== undefined) datos.lugar = String(e.lugar ?? '').trim().slice(0, 160) || null;
  if (e.lugar_retiro !== undefined) datos.lugar_retiro = String(e.lugar_retiro ?? '').trim().slice(0, 300) || null;
  for (const campo of ['fecha_evento', 'fecha_limite', 'fecha_primer_envio'] as const) {
    if (e[campo] !== undefined) {
      const f = fechaOpcional(e[campo]);
      if (f === undefined) return { error: `Fecha inválida en ${campo.replace(/_/g, ' ')}.` };
      datos[campo] = f;
    }
  }
  if (primerEnvioDespuesDelCierre(datos)) return { error: 'El 1.º envío al laboratorio tiene que ser antes de la fecha límite para pedir.' };
  for (const campo of ['precio_digital', 'precio_15x21', 'precio_20x30'] as const) {
    if (e[campo] !== undefined) {
      const p = precio(e[campo]);
      if (p === undefined) return { error: `Precio inválido en ${campo.replace('precio_', '')}.` };
      datos[campo] = p;
    }
  }
  if (e.impresa_incluye_digital !== undefined) datos.impresa_incluye_digital = Boolean(e.impresa_incluye_digital);
  if (e.publicado !== undefined) datos.publicado = Boolean(e.publicado);
  // 04/10: interruptor «Muestras con lupa» (ver eventos/marcaAgua.ts).
  if (e.muestras_lupa !== undefined) datos.muestras_lupa = Boolean(e.muestras_lupa);
  return { datos };
}

// ---------------------------------------------------------------------------
// Rutas
// ---------------------------------------------------------------------------
app.get('/api/eventos/salud', (_req, res) => {
  res.json({ success: true, modulo: 'eventos' });
});

// Lista de eventos con cantidad de fotos (panel).
app.get('/api/eventos/admin/eventos', requireAdmin, async (_req, res) => {
  const sb = conSupabase(res);
  if (!sb) return;
  try {
    const { data, error } = await sb
      .from('ev_eventos')
      .select('*, ev_fotos(count), ev_avisos(avisado_en)')
      .order('creado_en', { ascending: false });
    if (error) throw error;
    const ventas = await ventasPorEvento(sb, todasLasFilas, data || []); // 11/10: compras nuevas y recaudado por tarjeta
    const eventos = (data || []).map((ev: any) => {
      const { ev_fotos, ev_avisos, ...resto } = ev;
      return {
        ...resto,
        ventas: ventas.get(ev.id) ?? ventasVacias(),
        cantidad_fotos: ev_fotos?.[0]?.count ?? 0,
        primer_envio_efectivo: fechaPrimerEnvio(resto),
        avisos_pendientes: (ev_avisos || []).filter((a: any) => !a.avisado_en).length,
      };
    });
    return res.json({ success: true, eventos });
  } catch (err) {
    return errorInterno(res, 'listar eventos', err);
  }
});

app.post('/api/eventos/admin/eventos', requireAdmin, async (req, res) => {
  const { datos, error: errorValidacion } = validarDatosEvento(req.body, false);
  if (errorValidacion) return res.status(400).json({ success: false, error: errorValidacion });
  const sb = conSupabase(res);
  if (!sb) return;
  try {
    // Auditoría 03/10 noche: el servidor le agrega el sufijo al azar al código (ver codigoConSufijo).
    // Si justo choca con otro evento, se prueba con otro sufijo.
    const base = String(datos!.codigo);
    const yaTraeSufijo = tieneSufijoAzar(base);
    for (let intento = 0; intento < 5; intento++) {
      const codigo = yaTraeSufijo ? base : codigoConSufijo(base);
      const { data, error } = await sb.from('ev_eventos').insert({ ...datos!, codigo }).select().single();
      if (!error) return res.json({ success: true, evento: data, codigo: data?.codigo || codigo });
      if ((error as any).code !== '23505') throw error;
      if (yaTraeSufijo) break;
    }
    return res.status(409).json({ success: false, error: 'Ya existe un evento con ese código. Elegí otro.' });
  } catch (err) {
    return errorInterno(res, 'crear el evento', err);
  }
});

app.put('/api/eventos/admin/eventos/:id', requireAdmin, async (req, res) => {
  if (!esUuid(req.params.id)) return res.status(400).json({ success: false, error: 'Evento inválido' });
  const { datos, error: errorValidacion } = validarDatosEvento(req.body, true);
  if (errorValidacion) return res.status(400).json({ success: false, error: errorValidacion });
  const sb = conSupabase(res);
  if (!sb) return;
  // 14/10/2026: el panel manda el `actualizado_en` que cargó; si otro dispositivo guardó en el medio, 409 (antes
  // un formulario viejo pisaba todo el evento, incluso `publicado` y los precios). Sin el dato, como antes.
  const previo = typeof req.body?.actualizado_en === 'string' && Number.isFinite(Date.parse(req.body.actualizado_en)) ? req.body.actualizado_en : null;
  try {
    let codigoAnterior: string | null = null;
    if (datos!.codigo !== undefined) {
      const { data: actual, error: errAct } = await sb.from('ev_eventos').select('id, codigo, publicado').eq('id', req.params.id).maybeSingle();
      if (errAct) throw errAct;
      if (actual && actual.codigo === datos!.codigo) delete datos!.codigo;
      else if (actual) {
        // 14/10/2026: publicado o con fotos/pedidos el código ya no cambia (el QR impreso y los links dejarían de andar).
        const freno = await motivoCodigoBloqueado(sb, actual);
        if (freno) return res.status(409).json({ success: false, codigoBloqueado: true, error: freno });
        // Auditoría 11/10: un código CAMBIADO también lleva el sufijo al azar (los viejos sin sufijo se conservan).
        if (!tieneSufijoAzar(String(datos!.codigo))) datos!.codigo = codigoConSufijo(String(datos!.codigo));
        codigoAnterior = actual.codigo;
      }
    }
    let q = sb.from('ev_eventos').update({ ...datos, actualizado_en: new Date().toISOString() }).eq('id', req.params.id);
    if (previo) q = q.eq('actualizado_en', previo);
    const { data, error } = await q.select().maybeSingle();
    if (error) {
      if ((error as any).code === '23505') return res.status(409).json({ success: false, error: 'Ya existe un evento con ese código. Elegí otro.' });
      throw error;
    }
    if (!data) {
      const { data: existe } = previo ? await sb.from('ev_eventos').select('id').eq('id', req.params.id).maybeSingle() : { data: null };
      if (existe) return res.status(409).json({ success: false, conflicto: true, error: 'El evento cambió en otro dispositivo: recargá antes de guardar.' });
      return res.status(404).json({ success: false, error: 'No se encontró el evento' });
    }
    if (codigoAnterior) await guardarCodigoAnterior(sb, data.id, codigoAnterior);
    // Auditoría 03/10 noche: los avisos salen con presupuesto de tiempo; si quedan, el panel sigue
    // mandándolos en tandas con /avisar-anotados (avisosRestantes).
    const avisos = data.publicado ? await avisarAnotados(sb, data.id, baseUrl(req)) : { enviados: 0, restantes: 0 };
    return res.json({ success: true, evento: data, avisados: avisos.enviados, avisosRestantes: avisos.restantes });
  } catch (err) {
    return errorInterno(res, 'guardar el evento', err);
  }
});

// Borrar un evento con todo lo suyo (2/10, para eventos de PRUEBA). Con pedidos pagados, sólo con ?confirmar=CÓDIGO.
app.delete('/api/eventos/admin/eventos/:id', requireAdmin, async (req, res) => {
  if (!esUuid(req.params.id)) return res.status(400).json({ success: false, error: 'Evento inválido' });
  const sb = conSupabase(res);
  if (!sb) return;
  try {
    const { data: ev, error: errEv } = await sb.from('ev_eventos').select('id, codigo').eq('id', req.params.id).maybeSingle();
    if (errEv) throw errEv;
    if (!ev) return res.status(404).json({ success: false, error: 'No se encontró el evento' });
    const pedidos = await todasLasFilas<any>((d, h) =>
      sb.from('ev_pedidos').select('id, numero, estado, medio_pago, mp_preference_id, comprobante_path, comprobante_subido_en').eq('evento_id', ev.id).order('id').range(d, h));
    const pagados = pedidos.filter((p) => p.estado === 'pagado').length;
    // 14/10/2026: una transferencia pendiente CON comprobante (la familia ya pagó) también pide confirmar.
    const conComprobante = pedidos.filter((p) => p.estado === 'pendiente' && p.comprobante_subido_en).length;
    const confirmado = normalizarCodigo(req.query.confirmar) === ev.codigo;
    if (pagados + conComprobante > 0 && !confirmado) {
      return res.status(409).json({
        success: false,
        requiereConfirmacion: true,
        pagados,
        conComprobante,
        codigo: ev.codigo,
        error: `Este evento tiene ${pagados ? `${pagados} pedido(s) PAGADO(S)` : ''}${pagados && conComprobante ? ' y ' : ''}${conComprobante ? `${conComprobante} transferencia(s) con comprobante subido` : ''}. Para borrarlo igual (por ejemplo, si era una prueba), confirmá escribiendo el código del evento.`,
      });
    }
    // Auditoría 03/10 noche: antes de borrar pedidos de Mercado Pago sin pagar se consulta a MP y se dan
    // de baja sus links de pago (si no, la familia podía terminar de pagar un pedido que ya no existe).
    const freno = await frenoBorradoMercadoPago(pedidos);
    if (freno) return res.status(freno.status).json({ success: false, error: freno.error });
    const fotos = await todasLasFilas((d, h) =>
      sb.from('ev_fotos').select('storage_path_hd, preview_path, thumb_path').eq('evento_id', ev.id).order('id').range(d, h));
    if (pedidos.length > 0) {
      const { error: errPed } = await sb.from('ev_pedidos').delete().eq('evento_id', ev.id); // ítems: en cascada
      if (errPed) throw errPed;
    }
    const { error: errLotes } = await sb.from('ev_lotes').delete().eq('evento_id', ev.id);
    if (errLotes) throw errLotes;
    // Fotos y avisos se borran en cascada con el evento.
    const { error } = await sb.from('ev_eventos').delete().eq('id', ev.id);
    if (error) {
      if ((error as any).code === '23503') return res.status(409).json({ success: false, error: 'Justo entró un pedido nuevo: volvé a intentar.' });
      throw error;
    }
    await borrarArchivos(sb, fotos);
    const comprobantes = pedidos.map((p) => p.comprobante_path).filter(Boolean);
    if (comprobantes.length) {
      const { error: errComp } = await sb.storage.from('comprobantes').remove(comprobantes);
      if (errComp) console.error('[eventos] No se pudieron borrar comprobantes:', errComp);
    }
    return res.json({ success: true, pedidosBorrados: pedidos.length });
  } catch (err) {
    return errorInterno(res, 'borrar el evento', err);
  }
});

async function borrarArchivos(sb: SupabaseClient, fotos: Array<{ storage_path_hd: string; preview_path: string; thumb_path: string }>) {
  // 09/10: con cada original va también la copia de la lupa guardada al lado.
  const hd = fotos.flatMap((f) => (f.storage_path_hd ? [f.storage_path_hd, rutaCopiaLupa(f.storage_path_hd)] : []));
  const web = fotos.flatMap((f) => [f.preview_path, f.thumb_path]).filter(Boolean);
  for (let i = 0; i < hd.length; i += 500) {
    const { error } = await sb.storage.from(BUCKET_HD).remove(hd.slice(i, i + 500));
    if (error) console.error('[eventos] No se pudieron borrar originales:', error);
  }
  for (let i = 0; i < web.length; i += 500) {
    const { error } = await sb.storage.from(BUCKET_WEB).remove(web.slice(i, i + 500));
    if (error) console.error('[eventos] No se pudieron borrar muestras:', error);
  }
}

// 03/10: rehace muestra y miniatura desde el original en rutas NUEVAS (las viejas tienen caché de un año),
// actualiza la fila si nadie la cambió y borra las viejas. Con presupuesto de tiempo; el panel repite mientras queden.
app.post('/api/eventos/admin/eventos/:id/reforzar-marca', requireAdmin, async (req, res) => {
  const eventoId = req.params.id;
  if (!esUuid(eventoId)) return res.status(400).json({ success: false, error: 'Evento inválido' });
  const sb = conSupabase(res);
  if (!sb) return;
  const inicio = Date.now();
  // Tandas cortas (~12 s) para que la barra del panel avance seguido en vez de a saltos de 40 s.
  const PRESUPUESTO_MS = 12000;
  try {
    // 04/10: la muestra se rehace con el estilo que tiene elegido el evento (interruptor «Muestras con lupa»).
    const { data: ev, error: errEv } = await sb.from('ev_eventos').select('id, muestras_lupa').eq('id', eventoId).maybeSingle();
    if (errEv) throw errEv;
    if (!ev) return res.status(404).json({ success: false, error: 'No se encontró el evento' });
    const conLupa = ev.muestras_lupa === true;
    const sufijo = sufijoMuestra(conLupa);
    const pendientesDe = (filas: any[]) => filas.filter((f) => !String(f.preview_path || '').endsWith(sufijo));
    const fotos = await todasLasFilas<any>((desde, hasta) =>
      sb.from('ev_fotos').select('id, storage_path_hd, preview_path, thumb_path')
        .eq('evento_id', eventoId).order('orden', { ascending: true }).order('id').range(desde, hasta)
    );
    const pendientes = pendientesDe(fotos);
    let procesadas = 0;
    const errores: string[] = [];
    let indice = 0;
    const trabajador = async () => {
      while (indice < pendientes.length && Date.now() - inicio < PRESUPUESTO_MS) {
        const foto = pendientes[indice++];
        try {
          const original = await cargarOriginalEvento(sb, foto.storage_path_hd); // 17/10: de Storage o de Drive
          const { muestra, mini } = await generarMuestras(original, conLupa);
          const base = `${eventoId}/${crypto.randomUUID()}`;
          const nuevas = { preview: `${base}-muestra${sufijo}`, thumb: `${base}-mini${sufijo}` };
          const opciones = { contentType: 'image/jpeg', cacheControl: '31536000', upsert: false };
          const [a, b] = await Promise.all([
            sb.storage.from(BUCKET_WEB).upload(nuevas.preview, muestra, opciones),
            sb.storage.from(BUCKET_WEB).upload(nuevas.thumb, mini, opciones),
          ]);
          if (a.error || b.error) {
            await sb.storage.from(BUCKET_WEB).remove([nuevas.preview, nuevas.thumb]);
            throw a.error || b.error;
          }
          const { data: cambiada, error: errUpd } = await sb.from('ev_fotos')
            .update({ preview_path: nuevas.preview, thumb_path: nuevas.thumb })
            .eq('id', foto.id).eq('preview_path', foto.preview_path).select('id');
          if (errUpd || !cambiada?.length) {
            // Otra pestaña la procesó (o la borraron) en el medio: se descartan las copias nuevas.
            await sb.storage.from(BUCKET_WEB).remove([nuevas.preview, nuevas.thumb]);
            if (errUpd) throw errUpd;
            continue;
          }
          const viejas = [foto.preview_path, foto.thumb_path].filter(Boolean);
          if (viejas.length) await sb.storage.from(BUCKET_WEB).remove(viejas);
          procesadas++;
        } catch (e: any) {
          console.error('[eventos] No se pudo reforzar la marca de', foto.id, e?.message || e);
          errores.push(foto.id);
        }
      }
    };
    await Promise.all(Array.from({ length: Math.min(2, pendientes.length) }, trabajador));
    const restantes = Math.max(pendientes.length - procesadas - errores.length, 0) + errores.length;
    return res.json({ success: true, procesadas, conError: errores.length, restantes, total: fotos.length });
  } catch (err) {
    return errorInterno(res, 'reforzar la marca de agua', err);
  }
});

// Fotos de un evento (panel), con URL pública de la miniatura y la muestra.
app.get('/api/eventos/admin/eventos/:id/fotos', requireAdmin, async (req, res) => {
  if (!esUuid(req.params.id)) return res.status(400).json({ success: false, error: 'Evento inválido' });
  const sb = conSupabase(res);
  if (!sb) return;
  try {
    const fotos: any[] = [];
    for (let desde = 0; ; desde += 1000) {
      const { data, error } = await sb
        .from('ev_fotos')
        .select('id, nombre_archivo, preview_path, thumb_path, ancho, alto, orden, creado_en')
        .eq('evento_id', req.params.id)
        .order('orden', { ascending: true })
        .order('nombre_archivo', { ascending: true })
        .range(desde, desde + 999);
      if (error) throw error;
      fotos.push(...(data || []));
      if (!data || data.length < 1000) break;
    }
    return res.json({
      success: true,
      fotos: fotos.map((f) => ({ ...f, thumb_url: urlPublicaWeb(f.thumb_path), preview_url: urlPublicaWeb(f.preview_path) })),
    });
  } catch (err) {
    return errorInterno(res, 'listar las fotos', err);
  }
});

// Paso 1 de la subida: el navegador pide URLs firmadas (un solo uso) para subir directo a
// Storage el original (bucket privado) y las dos copias con marca de agua (bucket público).
// Así los archivos grandes nunca pasan por la función de Vercel (límite de 4,5 MB por pedido).
app.post('/api/eventos/admin/eventos/:id/subidas', requireAdmin, async (req, res) => {
  const eventoId = req.params.id;
  if (!esUuid(eventoId)) return res.status(400).json({ success: false, error: 'Evento inválido' });
  const cantidad = Math.floor(Number(req.body?.cantidad));
  if (!Number.isFinite(cantidad) || cantidad < 1 || cantidad > MAX_ARCHIVOS_POR_TANDA) {
    return res.status(400).json({ success: false, error: `Pedí entre 1 y ${MAX_ARCHIVOS_POR_TANDA} subidas por vez.` });
  }
  const sb = conSupabase(res);
  if (!sb) return;
  try {
    const { data: ev, error: errEv } = await sb.from('ev_eventos').select('id, muestras_lupa').eq('id', eventoId).maybeSingle();
    if (errEv) throw errEv;
    if (!ev) return res.status(404).json({ success: false, error: 'No se encontró el evento' });
    // 04/10: el estilo de la muestra lo decide el evento; el navegador dibuja la que le dice el servidor (conLupa).
    const conLupa = ev.muestras_lupa === true;
    const sufijo = sufijoMuestra(conLupa);
    // 03/10: el 03/10 este pedido se colgó 60 s (Storage lento) y Vercel lo cortó con 504. Ahora las URLs
    // se piden en paralelo (de a 5 fotos) y cada llamada tiene un tope de 15 s: si Storage no responde, se
    // devuelve un 503 rápido y el navegador reintenta la tanda, en vez de esperar el corte de Vercel.
    const conTope = <T,>(p: PromiseLike<T>): Promise<T> =>
      Promise.race([
        Promise.resolve(p),
        new Promise<T>((_, mal) => setTimeout(() => mal(Object.assign(new Error('Storage no respondió a tiempo'), { lento: true })), 15000)),
      ]);
    const prepararUna = async () => {
      const base = `${eventoId}/${crypto.randomUUID()}`;
      // Sufijo según el estilo del evento (-m4 clásica, -m6 con lupa; ver eventos/marcaAgua.ts).
      const rutas = { hd: `${base}.jpg`, preview: `${base}-muestra${sufijo}`, thumb: `${base}-mini${sufijo}` };
      const [hd, preview, thumb] = await Promise.all([
        conTope(sb.storage.from(BUCKET_HD).createSignedUploadUrl(rutas.hd)),
        conTope(sb.storage.from(BUCKET_WEB).createSignedUploadUrl(rutas.preview)),
        conTope(sb.storage.from(BUCKET_WEB).createSignedUploadUrl(rutas.thumb)),
      ]);
      const fallo = hd.error || preview.error || thumb.error;
      if (fallo) throw fallo;
      return {
        rutas,
        conLupa,
        urls: { hd: hd.data!.signedUrl, preview: preview.data!.signedUrl, thumb: thumb.data!.signedUrl },
      };
    };
    const subidas: Awaited<ReturnType<typeof prepararUna>>[] = new Array(cantidad);
    let siguiente = 0;
    const trabajador = async () => {
      while (siguiente < cantidad) {
        const i = siguiente++;
        subidas[i] = await prepararUna();
      }
    };
    try {
      await Promise.all(Array.from({ length: Math.min(5, cantidad) }, trabajador));
    } catch (e: any) {
      if (e?.lento) {
        console.error('[Eventos] Storage lento al preparar la subida:', e.message);
        return res.status(503).json({ success: false, error: 'El almacenamiento está lento; reintentando…' });
      }
      throw e;
    }
    return res.json({ success: true, subidas });
  } catch (err) {
    return errorInterno(res, 'preparar la subida', err);
  }
});

// Paso 2: con los archivos ya subidos, se registran las fotos en la base.
app.post('/api/eventos/admin/eventos/:id/fotos', requireAdmin, async (req, res) => {
  const eventoId = req.params.id;
  if (!esUuid(eventoId)) return res.status(400).json({ success: false, error: 'Evento inválido' });
  const lista = req.body?.fotos;
  if (!Array.isArray(lista) || lista.length === 0 || lista.length > MAX_ARCHIVOS_POR_TANDA) {
    return res.status(400).json({ success: false, error: 'Lista de fotos inválida' });
  }
  const prefijo = `${eventoId}/`;
  const rutaValida = (r: unknown, sufijo: string) =>
    typeof r === 'string' && r.startsWith(prefijo) && /^[0-9a-f-]{36}\/[0-9a-f-]{36}(-muestra|-mini)?(-m[2-6])?\.jpg$/i.test(r) && r.endsWith(sufijo);
  const filas = [];
  for (const f of lista) {
    const nombre = String(f?.nombreArchivo ?? '').trim().slice(0, 200);
    if (!nombre || !rutaValida(f?.rutaHd, '.jpg') || !/-muestra(-m[456])?\.jpg$/i.test(String(f?.rutaPreview)) || !rutaValida(f?.rutaPreview, '.jpg') || !/-mini(-m[456])?\.jpg$/i.test(String(f?.rutaThumb)) || !rutaValida(f?.rutaThumb, '.jpg')) {
      return res.status(400).json({ success: false, error: `Datos inválidos para la foto "${nombre || '?'}"` });
    }
    const entero = (v: unknown) => (Number.isFinite(Number(v)) && Number(v) > 0 ? Math.round(Number(v)) : null);
    filas.push({
      evento_id: eventoId,
      nombre_archivo: nombre,
      storage_path_hd: f.rutaHd,
      preview_path: f.rutaPreview,
      thumb_path: f.rutaThumb,
      ancho: entero(f.ancho),
      alto: entero(f.alto),
      orden: entero(f.orden) ?? 0,
    });
  }
  const sb = conSupabase(res);
  if (!sb) return;
  try {
    const { data, error } = await sb.from('ev_fotos').insert(filas).select('id');
    if (error) {
      if ((error as any).code === '23505') return res.status(409).json({ success: false, error: 'Alguna foto ya estaba cargada con el mismo nombre de archivo.' });
      throw error;
    }
    return res.json({ success: true, registradas: data?.length || 0 });
  } catch (err) {
    return errorInterno(res, 'registrar las fotos', err);
  }
});

// Al terminar TODA la subida (no por tanda): avisa a los anotados si el evento ya está publicado.
app.post('/api/eventos/admin/eventos/:id/avisar-anotados', requireAdmin, async (req, res) => {
  if (!esUuid(req.params.id)) return res.status(400).json({ success: false, error: 'Evento inválido' });
  const sb = conSupabase(res);
  if (!sb) return;
  try {
    const avisos = await avisarAnotados(sb, req.params.id, baseUrl(req));
    return res.json({ success: true, avisados: avisos.enviados, avisosRestantes: avisos.restantes });
  } catch (err) {
    return errorInterno(res, 'avisar a los anotados', err);
  }
});

// Borra una foto (y sus archivos) si nadie la compró.
app.delete('/api/eventos/admin/fotos/:id', requireAdmin, async (req, res) => {
  if (!esUuid(req.params.id)) return res.status(400).json({ success: false, error: 'Foto inválida' });
  const sb = conSupabase(res);
  if (!sb) return;
  try {
    const { count, error: errItems } = await sb
      .from('ev_items_pedido').select('id', { count: 'exact', head: true }).eq('foto_id', req.params.id);
    if (errItems) throw errItems;
    if ((count || 0) > 0) return res.status(409).json({ success: false, error: 'Esta foto ya está en algún pedido: no se puede borrar.' });
    const { data: foto, error: errFoto } = await sb
      .from('ev_fotos').select('storage_path_hd, preview_path, thumb_path').eq('id', req.params.id).maybeSingle();
    if (errFoto) throw errFoto;
    if (!foto) return res.status(404).json({ success: false, error: 'No se encontró la foto' });
    // Primero la fila (si justo la compraron, la base lo frena) y recién después los archivos.
    const { error } = await sb.from('ev_fotos').delete().eq('id', req.params.id);
    if (error) {
      if ((error as any).code === '23503') return res.status(409).json({ success: false, error: 'Esta foto ya está en algún pedido: no se puede borrar.' });
      throw error;
    }
    await borrarArchivos(sb, [foto]);
    return res.json({ success: true });
  } catch (err) {
    return errorInterno(res, 'borrar la foto', err);
  }
});

// ===========================================================================
// FASE 2 — Página de familias, pedidos, pagos (Mercado Pago + transferencia) y descargas.
// ===========================================================================

// ---------------- Límite de intentos por IP (en memoria, por instancia) ----------------
const intentosPorClave = new Map<string, { n: number; desde: number }>();
function ipDe(req: Request): string {
  const reenviada = String(req.headers['x-forwarded-for'] || '').split(',')[0].trim();
  return reenviada || req.ip || 'desconocida';
}
function limitar(nombre: string, maximo: number, ventanaMs: number) {
  return (req: Request, res: Response, next: NextFunction) => {
    const clave = `${nombre}:${ipDe(req)}`;
    const ahora = Date.now();
    const entrada = intentosPorClave.get(clave);
    if (!entrada || ahora - entrada.desde > ventanaMs) {
      intentosPorClave.set(clave, { n: 1, desde: ahora });
      if (intentosPorClave.size > 5000) intentosPorClave.clear();
      return next();
    }
    entrada.n += 1;
    if (entrada.n > maximo) {
      return res.status(429).json({ success: false, error: 'Demasiados intentos seguidos. Esperá unos minutos y probá de nuevo.' });
    }
    return next();
  };
}

/**
 * Límite guardado en la base (tabla limites_intentos, función registrar_intento: la misma del
 * servidor principal), así vale para todas las instancias de Vercel. Si la base no responde, cae
 * al contador en memoria. Devuelve los segundos de espera (0 = puede seguir).
 */
async function esperaPersistente(clave: string, maximo: number, ventanaSeg: number): Promise<number> {
  const sb = getSupabase();
  if (!sb) return -1;
  try {
    const { data, error } = await sb.rpc('registrar_intento', { p_clave: clave, p_max: maximo, p_ventana_seg: ventanaSeg });
    if (error) throw error;
    return Number(data) || 0;
  } catch (err) {
    console.warn('[eventos] registrar_intento no respondió:', err);
    return -1;
  }
}
function limitarPersistente(nombre: string, maximo: number, ventanaMs: number) {
  const respaldo = limitar(nombre, maximo, ventanaMs);
  return async (req: Request, res: Response, next: NextFunction) => {
    const espera = await esperaPersistente(`ev-${nombre}:${ipDe(req)}`, maximo, Math.round(ventanaMs / 1000));
    if (espera < 0) return respaldo(req, res, next);
    if (espera > 0) return res.status(429).json({ success: false, error: 'Demasiados intentos seguidos. Esperá unos minutos y probá de nuevo.' });
    return next();
  };
}
// 09/10: como limitarPersistente pero SIN hacer esperar el pedido (la lupa se sentía trabada): el
// intento se anota en paralelo y, si esa IP ya pasó el tope, esta instancia la frena en los siguientes.
function limitarPersistenteSinEspera(nombre: string, maximo: number, ventanaMs: number) {
  const bloqueadasHasta = new Map<string, number>();
  return (req: Request, res: Response, next: NextFunction) => {
    const clave = `ev-${nombre}:${ipDe(req)}`;
    const hasta = bloqueadasHasta.get(clave);
    if (hasta && hasta > Date.now()) {
      return res.status(429).json({ success: false, error: 'Demasiados intentos seguidos. Esperá unos minutos y probá de nuevo.' });
    }
    void esperaPersistente(clave, maximo, Math.round(ventanaMs / 1000)).then((segundos) => {
      if (segundos > 0) {
        if (bloqueadasHasta.size > 5000) bloqueadasHasta.clear();
        bloqueadasHasta.set(clave, Date.now() + segundos * 1000);
      }
    });
    return next();
  };
}
/** true sólo la primera vez que se pide esa clave dentro de la ventana (para no repetir avisos). */
async function primeraVez(clave: string, ventanaSeg: number): Promise<boolean> {
  return (await esperaPersistente(clave, 1, ventanaSeg)) <= 0;
}
/**
 * Auditoría 03/10 noche: ¿la clave ya pasó el máximo dentro de la ventana? Sólo LEE (no suma un intento).
 * Si la base no responde, no frena (queda el límite en memoria de la ruta).
 */
async function bloqueadoPersistente(sb: SupabaseClient, clave: string, maximo: number, ventanaSeg: number): Promise<boolean> {
  try {
    const { data, error } = await sb.from('limites_intentos').select('cantidad, desde').eq('clave', clave).maybeSingle();
    if (error || !data) return false;
    return Number(data.cantidad) > maximo && Date.parse(data.desde) + ventanaSeg * 1000 > Date.now();
  } catch {
    return false;
  }
}
// Galería pública: cuántos códigos distintos SIN galería puede pedir una IP por ventana.
// Revisión 03/10 noche: 40 (no 20) para no frenar a familias detrás de la misma IP (wifi del salón).
const MAX_CODIGOS_SIN_GALERIA = 40;
const VENTANA_CODIGOS_SEG = 15 * 60;
/** Cuenta un código sin galería para la IP (una vez por código y ventana). Galería y pedidos (auditoría 11/10). */
async function contarCodigoSinGaleria(ip: string, codigo: string): Promise<void> {
  if (await primeraVez(`ev-galeria-visto:${ip}:${codigo}`, VENTANA_CODIGOS_SEG)) await esperaPersistente(`ev-galeria-fallos:${ip}`, MAX_CODIGOS_SIN_GALERIA, VENTANA_CODIGOS_SEG);
}

// ---------------- Llave de acceso de un pedido (va en el link del mail) ----------------
function secretoAcceso(): string | null {
  return process.env.PEDIDOS_ACCESO_SECRET?.trim() || process.env.ADMIN_SESSION_SECRET?.trim() || null;
}
export function llavePedidoEvento(pedidoId: string, secreto: string): string {
  return crypto.createHmac('sha256', secreto).update(`evento-pedido:${pedidoId}`).digest('base64url').slice(0, 32);
}
function llaveValida(pedidoId: string, llave: unknown): boolean {
  const secreto = secretoAcceso();
  if (!secreto || typeof llave !== 'string' || !llave) return false;
  return compararTimingSafe(llave, llavePedidoEvento(pedidoId, secreto));
}

function baseUrl(req?: Request): string {
  if (process.env.APP_URL) return process.env.APP_URL.replace(/\/+$/, '');
  const host = req?.get('host') || '';
  if (!host) return 'https://www.retratoescolar.com.ar';
  return /^(localhost|127\.0\.0\.1)(:\d+)?$/i.test(host) ? `http://${host}` : `https://${host}`;
}
function urlPedido(base: string, codigo: string, pedidoId: string): string {
  const llave = secretoAcceso() ? llavePedidoEvento(pedidoId, secretoAcceso()!) : '';
  return `${base}/eventos/${encodeURIComponent(codigo)}?pedido=${pedidoId}&t=${llave}`;
}

// ---------------- Mercado Pago / Resend ----------------
function getMercadoPago(): MercadoPagoConfig | null {
  const token = process.env.MERCADOPAGO_ACCESS_TOKEN?.trim();
  return token ? new MercadoPagoConfig({ accessToken: token }) : null;
}
function getResend(): Resend | null {
  const key = process.env.RESEND_API_KEY?.trim();
  return key ? new Resend(key) : null;
}
const REMITENTE = () => process.env.RESEND_FROM_EMAIL || 'Retrato Escolar <fotos@retratoescolar.com.ar>';
const RESPONDER_A = () => process.env.RESEND_REPLY_TO_EMAIL || 'contacto@retratoescolar.com.ar';
const CASILLA_ADMIN = () => process.env.CONSULTAS_EMAIL || process.env.CASILLA_REENVIO_ENTRANTE?.trim() || 'colegios@contacto.retratoescolar.com.ar';

async function enviarCorreo(datos: { to: string; subject: string; html: string; replyTo?: string; attachments?: Array<{ filename: string; content: string }> }): Promise<boolean> {
  const resend = getResend();
  if (!resend) {
    console.warn('[eventos] RESEND_API_KEY no configurada: no se envió', datos.subject);
    return false;
  }
  for (let intento = 0; intento < 3; intento++) {
    try {
      const r: any = await resend.emails.send({
        from: REMITENTE(),
        replyTo: datos.replyTo || RESPONDER_A(),
        to: [datos.to],
        subject: datos.subject,
        html: datos.html,
        ...(datos.attachments ? { attachments: datos.attachments } : {}),
      });
      if (!r?.error) return true;
      const reintentable = r.error.statusCode === 429 || Number(r.error.statusCode) >= 500;
      console.error('[eventos] Resend:', r.error);
      if (!reintentable) return false;
    } catch (err) {
      console.error('[eventos] Resend (red):', err);
    }
    await new Promise((ok) => setTimeout(ok, 800 * (intento + 1)));
  }
  return false;
}

const avisarOriginalesPerdidos = (nombres: string[]) => avisarAdmin('⚠️ Faltan originales en Drive', `<p>No encontramos en Drive el original de: <strong>${nombres.map(escapeHtml).join(', ')}</strong>. Se borró o se movió de la carpeta del evento. Volvé a ponerlo con el mismo nombre y la descarga se arma sola.</p>`);
async function avisarAdmin(asunto: string, html: string, attachments?: Array<{ filename: string; content: string }>) {
  await enviarCorreo({ to: CASILLA_ADMIN(), subject: asunto, html, attachments });
}

// ---------------- Lectura de pedidos ----------------
const SELECT_PEDIDO = '*, ev_eventos(codigo, nombre, fecha_evento, fecha_limite, fecha_primer_envio), ev_items_pedido(id, foto_id, formato, cantidad, precio_unitario, subtotal, incluye_digital, ev_fotos(nombre_archivo, thumb_path))';

async function leerPedido(sb: SupabaseClient, pedidoId: string): Promise<any | null> {
  const { data, error } = await sb.from('ev_pedidos').select(SELECT_PEDIDO).eq('id', pedidoId).maybeSingle();
  if (error) throw error;
  return data;
}

const DIAS_LINK_MP = 3;
const venceLinkMp = () => new Date(Date.now() + DIAS_LINK_MP * 24 * 3600 * 1000).toISOString();

/**
 * Transferencia sin comprobante pasadas las 48 h, o Mercado Pago sin pagar pasados los 3 días que
 * dura el link (antes se consulta a Mercado Pago): queda "vencido" (se hace al leerlo).
 */
async function vencerSiCorresponde(sb: SupabaseClient, pedido: any): Promise<any> {
  if (
    pedido &&
    pedido.estado === 'pendiente' &&
    pedido.medio_pago === 'mercadopago' &&
    // vence_en = cuándo vence el link de pago (+1 h de margen); pedidos viejos sin dato: desde que se creó.
    (pedido.vence_en ? Date.parse(pedido.vence_en) : Date.parse(pedido.creado_en) + 7 * 24 * 3600 * 1000) + 3600 * 1000 < Date.now()
  ) {
    const mp = getMercadoPago();
    if (!mp) return pedido;
    try {
      const enCurso = await pagoMercadoPagoEnCurso(mp, pedido.id);
      if (enCurso === 'aprobado') await conciliarConMercadoPago(sb, pedido, baseUrl()); // se perdió el aviso: se marca pagado
      if (enCurso !== null) return pedido;
    } catch {
      return pedido;
    }
    const { data } = await sb.from('ev_pedidos').update({ estado: 'vencido' }).eq('id', pedido.id).eq('estado', 'pendiente').eq('medio_pago', 'mercadopago').select('id');
    if (data && data.length > 0) pedido.estado = 'vencido';
    return pedido;
  }
  if (
    pedido &&
    pedido.estado === 'pendiente' &&
    pedido.medio_pago === 'transferencia' &&
    !pedido.comprobante_subido_en &&
    pedido.vence_en &&
    Date.parse(pedido.vence_en) < Date.now()
  ) {
    const { data } = await sb
      .from('ev_pedidos')
      .update({ estado: 'vencido' })
      .eq('id', pedido.id)
      .eq('estado', 'pendiente')
      .is('comprobante_subido_en', null)
      .select('id');
    if (data && data.length > 0) pedido.estado = 'vencido';
  }
  return pedido;
}

function datosCorreo(pedido: any, base: string): DatosCorreoPedido {
  const items = (pedido.ev_items_pedido || []) as any[];
  return {
    numero: pedido.numero,
    eventoNombre: pedido.ev_eventos?.nombre || 'Evento',
    compradorNombre: pedido.comprador_nombre,
    ninoNombre: pedido.nino_nombre,
    ninoCurso: pedido.nino_curso,
    total: pedido.total,
    descuento: Number(pedido.descuento_monto) > 0 ? { codigo: String(pedido.codigo_descuento || ''), monto: Number(pedido.descuento_monto) } : null, // 27/10
    urlPedido: urlPedido(base, pedido.ev_eventos?.codigo || '', pedido.id),
    venceEn: pedido.vence_en,
    items: items
      .slice()
      .sort((a, b) => String(a.ev_fotos?.nombre_archivo).localeCompare(String(b.ev_fotos?.nombre_archivo), 'es', { numeric: true }))
      .map((it) => ({ nombre_archivo: it.ev_fotos?.nombre_archivo || '?', formato: it.formato, cantidad: it.cantidad, subtotal: it.subtotal })),
  };
}

const MEDIO = (m: string) => (m === 'mercadopago' ? 'Mercado Pago' : m === 'bonificado' ? 'Sin cargo (código de descuento)' : 'Transferencia');

/**
 * Mail de "¡Gracias por tu compra!". Auditoría 03/10 noche: el envío se "reserva" ANTES de mandarlo con un
 * UPDATE condicional (email_digitales_enviado false → true), así el webhook y la conciliación que llegan a
 * la vez no lo mandan dos veces; si el envío falla, se vuelve a false para que se reintente.
 * `forzar` (reenvío manual desde el panel) lo manda aunque ya figure enviado.
 */
async function enviarCorreoPagado(sb: SupabaseClient, pedido: any, base: string, forzar = false): Promise<boolean> {
  if (!forzar) {
    const { data: reservado, error: errReserva } = await sb
      .from('ev_pedidos')
      .update({ email_digitales_enviado: true })
      .eq('id', pedido.id)
      .eq('email_digitales_enviado', false)
      .select('id');
    // Si la base no respondió, se manda igual (como antes): mejor un mail repetido que ninguno.
    if (errReserva) console.error('[eventos] No se pudo reservar el envío del mail de pago:', errReserva);
    else if (!reservado?.length) return true; // otro proceso ya lo mandó (o lo está mandando)
  }
  const items = (pedido.ev_items_pedido || []) as any[];
  const d = datosCorreo(pedido, base);
  const hayDigitales = items.some((it) => it.incluye_digital);
  const hayImpresas = items.some((it) => it.formato !== 'digital');
  const codigoEvento = pedido.ev_eventos?.codigo || '';
  const urlGaleria = codigoEvento ? `${base}/eventos/${encodeURIComponent(codigoEvento)}` : null;
  const { subject, html } = correoPagoConfirmado({ ...d, hayDigitales, hayImpresas, urlGaleria, fechaLimite: pedido.ev_eventos?.fecha_limite ?? null, pagadoEn: pedido.fecha_pago ?? null, primerEnvio: fechaPrimerEnvio(pedido.ev_eventos) });
  const ok = await enviarCorreo({ to: pedido.comprador_email, subject, html });
  if (ok) {
    await sb
      .from('ev_pedidos')
      .update({ email_digitales_enviado: true, fecha_email_digitales: new Date().toISOString(), link_digitales: d.urlPedido })
      .eq('id', pedido.id);
  } else if (!forzar) {
    await sb.from('ev_pedidos').update({ email_digitales_enviado: false }).eq('id', pedido.id);
  }
  return ok;
}

/**
 * Marca un pedido como pagado (idempotente: sólo si estaba pendiente o vencido) y manda los mails.
 * Control de monto: lo cobrado tiene que cubrir el total guardado del pedido.
 */
// 05/10: exportada sólo para probarla directo (eventos/__tests__/servidor-rutas.test.ts); no cambia su comportamiento.
export async function procesarPagoAprobado(
  sb: SupabaseClient,
  pedidoId: string,
  montoPagado: number,
  extras: Record<string, unknown>,
  base: string
): Promise<'pagado' | 'ya_pagado' | 'rechazado'> {
  const pedido = await leerPedido(sb, pedidoId);
  if (!pedido) {
    // Auditoría 03/10 noche: pago aprobado para un pedido que ya no existe (se borró desde el panel
    // mientras la familia pagaba). Se avisa al admin una sola vez por pago.
    const idPago = extras.mp_payment_id ? String(extras.mp_payment_id) : '';
    if (idPago && (await primeraVez(`ev-pago-huerfano:${idPago}`, 2 * 24 * 3600))) {
      await avisarAdmin(`⚠️ Pago recibido para un pedido de evento BORRADO (${pesos(montoPagado)})`,
        `<div style="font-family:Arial,sans-serif;max-width:640px;margin:auto;color:#0f172a"><h2>Pago sin pedido</h2>
<p>Mercado Pago acreditó el pago <strong>${escapeHtml(idPago)}</strong> de <strong>${pesos(montoPagado)}</strong> para el pedido de evento <code>${escapeHtml(pedidoId)}</code>, que ya no existe (se borró). No se entregó nada.</p>
<p><strong>Qué hacer:</strong> buscá el pago ${escapeHtml(idPago)} en Mercado Pago para ver quién pagó y, o bien <strong>devolvé el pago desde Mercado Pago</strong>, o bien pedile a la familia que haga el pedido de nuevo desde la galería eligiendo <strong>transferencia</strong> (sin pagar otra vez) y aprobalo a mano desde el panel de eventos.</p>
<p>Panel: <a href="https://www.retratoescolar.com.ar/eventos-admin">retratoescolar.com.ar/eventos-admin</a></p></div>`);
    }
    return 'rechazado';
  }
  const datos = datosCorreo(pedido, base);
  const avisoBase = { ...datos, compradorEmail: pedido.comprador_email, compradorWhatsapp: pedido.comprador_whatsapp, medioPago: MEDIO(pedido.medio_pago) };

  if (extras.mp_payment_id) {
    const { data: usado } = await sb.from('ev_pedidos').select('id').eq('mp_payment_id', String(extras.mp_payment_id)).neq('id', pedidoId).limit(1);
    if (usado && usado.length > 0) {
      if (!(await primeraVez(`ev-pago-reusado:${extras.mp_payment_id}`, 2 * 24 * 3600))) return 'rechazado';
      const a = correoAvisoAdmin('⚠️ Pago reusado en eventos', avisoBase, `<p>El pago de Mercado Pago ${escapeHtml(extras.mp_payment_id)} ya estaba asignado a otro pedido. No se marcó como pagado.</p>`);
      await avisarAdmin(a.subject, a.html);
      return 'rechazado';
    }
  }
  if (!Number.isFinite(montoPagado) || montoPagado + 1 < Number(pedido.total)) {
    if (!(await primeraVez(`ev-monto:${pedidoId}:${extras.mp_payment_id || 'manual'}`, 2 * 24 * 3600))) return 'rechazado';
    const a = correoAvisoAdmin('⚠️ Monto insuficiente en eventos', avisoBase, `<p>Se cobró ${pesos(montoPagado)} y el pedido vale ${pesos(pedido.total)}. No se marcó como pagado: revisalo a mano.</p>`);
    await avisarAdmin(a.subject, a.html);
    return 'rechazado';
  }
  const { data: actualizados, error } = await sb
    .from('ev_pedidos')
    .update({ estado: 'pagado', fecha_pago: new Date().toISOString(), ...extras })
    .eq('id', pedidoId)
    .in('estado', ['pendiente', 'vencido'])
    .select('id');
  if (error) throw error;
  if (!actualizados || actualizados.length === 0) {
    const idPago = extras.mp_payment_id ? String(extras.mp_payment_id) : '';
    // Se relee: si otro proceso (webhook duplicado o la conciliación) lo acaba de marcar pagado con
    // ESTE mismo pago, no hay nada que avisar (antes salía un falso "posible pago doble").
    const { data: fresco } = await sb.from('ev_pedidos').select('estado, mp_payment_id, email_digitales_enviado, notas').eq('id', pedidoId).maybeSingle();
    const marca = `[pago-extra:${idPago}]`;
    // Auditoría 02/10: un pago de Mercado Pago que llega a un pedido CANCELADO o YA PAGADO por otro
    // medio/pago siempre avisa, una sola vez por pago (la marca queda guardada en las notas del pedido).
    if (
      fresco && idPago &&
      (fresco.estado === 'pagado' || fresco.estado === 'cancelado') &&
      String(fresco.mp_payment_id || '') !== idPago &&
      !String(fresco.notas || '').includes(marca) &&
      (await primeraVez(`ev-pago-extra:${idPago}`, 2 * 24 * 3600))
    ) {
      const notas = `${fresco.notas ? `${fresco.notas}\n` : ''}${marca} ${new Date().toISOString()} ${pesos(montoPagado)}`;
      // Sólo un pedido CANCELADO se queda con el id del pago (así un reembolso posterior lo encuentra).
      // En uno pagado por otro medio NO: si Pablo devuelve el pago extra, el reembolso no tiene que anularlo.
      const cambios: Record<string, unknown> = { notas };
      if (fresco.estado === 'cancelado' && !fresco.mp_payment_id) cambios.mp_payment_id = idPago;
      await sb.from('ev_pedidos').update(cambios).eq('id', pedidoId);
      const cancelado = fresco.estado === 'cancelado';
      const a = correoAvisoAdmin(cancelado ? '⚠️ Pago recibido en un pedido CANCELADO' : '⚠️ Posible pago doble en eventos', avisoBase,
        cancelado
          // Auditoría 03/10 noche: el aviso decía "reactivalo" pero el panel no tiene cómo; ahora dice qué hacer.
          ? `<p>Mercado Pago acreditó el pago ${escapeHtml(idPago)} de ${pesos(montoPagado)} para un pedido que estaba <strong>cancelado</strong>. No se entregó nada y el pedido sigue cancelado (no se puede reactivar desde el panel).</p>
<p><strong>Qué hacer:</strong> si la familia ya no quiere las fotos, <strong>devolvé el pago ${escapeHtml(idPago)} desde Mercado Pago</strong>. Si sí las quiere, pedile que haga el pedido de nuevo desde la galería eligiendo <strong>transferencia</strong> (sin pagar otra vez) y aprobalo a mano desde el panel de eventos → Pedidos → <strong>Aprobar pago</strong> (la plata ya está cobrada con el pago ${escapeHtml(idPago)}).</p>`
          : `<p>Llegó otro pago aprobado (${escapeHtml(idPago)}, ${pesos(montoPagado)}) para un pedido que ya estaba pagado${fresco.mp_payment_id ? ` con el pago ${escapeHtml(fresco.mp_payment_id)}` : ' (por transferencia o aprobado a mano)'}. Revisá en Mercado Pago si corresponde devolver el pago ${escapeHtml(idPago)}.</p>`);
      await avisarAdmin(a.subject, a.html);
    }
    // Si el mail de "pago confirmado" no salió (la función se cortó justo después de marcarlo), se reintenta.
    if (fresco?.estado === 'pagado' && !fresco.email_digitales_enviado && (await primeraVez(`ev-reenvio-pagado:${pedidoId}`, 600))) {
      pedido.estado = 'pagado';
      await enviarCorreoPagado(sb, pedido, base);
    }
    return 'ya_pagado';
  }
  pedido.estado = 'pagado'; await copiarOriginalesDelPedido(sb, pedidoId, avisarOriginalesPerdidos); // 17/10: originales de Drive a Storage
  // Aprobado sin pago de Mercado Pago (transferencia o a mano): se da de baja el link de pago que haya quedado vivo.
  if (!extras.mp_payment_id && pedido.mp_preference_id) await vencerPreferencia(pedido.mp_preference_id);
  // Auditoría 03/10 noche: la suscripción a novedades se registra recién con el pedido PAGADO (antes se
  // hacía al crear el pedido, aunque nunca se pagara y con un email que nadie había usado).
  if (extras.mp_payment_id && pedido.medio_pago === 'transferencia') { // auditoría 11/10: posible pago doble
    const t = correoAvisoAdmin('⚠️ Pago de Mercado Pago en un pedido por TRANSFERENCIA', avisoBase, `<p>Entró el pago ${escapeHtml(extras.mp_payment_id)} por un link viejo de Mercado Pago, pero el pedido estaba en transferencia${pedido.comprobante_subido_en ? ' y <strong>ya había subido comprobante</strong>' : ''}. Revisá si también transfirió (posible pago doble).</p>`);
    await avisarAdmin(t.subject, t.html);
  }
  if (pedido.acepta_novedades === true) await registrarSuscriptor(sb, pedido.comprador_email, pedido.comprador_nombre, `Compra · ${pedido.ev_eventos?.nombre || 'Evento'}`);
  await enviarCorreoPagado(sb, pedido, base);
  const a = correoAvisoAdmin('✅ Pedido de evento pagado', avisoBase);
  await avisarAdmin(a.subject, a.html);
  return 'pagado';
}

/** Da de baja un link de pago (Checkout Pro) para que no se pueda pagar más con él. */
async function vencerPreferencia(preferenciaId: string | null | undefined): Promise<void> {
  const mp = getMercadoPago();
  if (!mp || !preferenciaId) return;
  try {
    const ahora = new Date().toISOString();
    await new Preference(mp).update({
      id: String(preferenciaId),
      updatePreferenceRequest: { expires: true, expiration_date_from: new Date(Date.now() - 24 * 3600 * 1000).toISOString(), expiration_date_to: ahora } as any,
    });
  } catch (err) {
    console.warn('[eventos] No se pudo dar de baja el link de Mercado Pago:', err);
  }
}

/** Respaldo por si se pierde el aviso de Mercado Pago: busca el pago por la referencia. */
async function conciliarConMercadoPago(sb: SupabaseClient, pedido: any, base: string): Promise<void> {
  const mp = getMercadoPago();
  if (!mp || pedido.estado !== 'pendiente' || pedido.medio_pago !== 'mercadopago') return;
  try {
    const busqueda = await new Payment(mp).search({ options: { external_reference: `ev:${pedido.id}`, sort: 'date_created', criteria: 'desc' } });
    const aprobado = (busqueda?.results || []).find((p: any) => p.status === 'approved');
    if (aprobado) {
      const r = await procesarPagoAprobado(sb, pedido.id, Number(aprobado.transaction_amount), { mp_payment_id: String(aprobado.id) }, base);
      if (r === 'pagado') pedido.estado = 'pagado';
    }
  } catch (err) {
    console.warn('[eventos] No se pudo conciliar con Mercado Pago:', err);
  }
}

async function idsDeFotos(sb: SupabaseClient, eventoId: string): Promise<Set<string>> {
  const ids = new Set<string>();
  for (let desde = 0; ; desde += 1000) {
    const { data, error } = await sb.from('ev_fotos').select('id').eq('evento_id', eventoId).order('id').range(desde, desde + 999);
    if (error) throw error;
    (data || []).forEach((f: any) => ids.add(f.id));
    if (!data || data.length < 1000) break;
  }
  return ids;
}

function numeroPedido(): string {
  const anio = new Date().getFullYear() % 100;
  return `EV${anio}-${crypto.randomInt(10000, 99999)}`;
}

// ---------------- Rutas públicas ----------------

// Galería de un evento publicado (el código es la llave de acceso).
app.get('/api/eventos/publico/:codigo', limitar('ev-galeria', 120, 10 * 60 * 1000), async (req, res) => {
  const codigo = normalizarCodigo(req.params.codigo);
  if (!/^[A-Z0-9-]{4,30}$/.test(codigo)) return res.status(404).json({ success: false, error: 'No encontramos un evento con ese código.' });
  const sb = conSupabase(res);
  if (!sb) return;
  try {
    // Auditoría 03/10 noche: contra adivinar códigos. Límite guardado en la base (vale para todas las
    // instancias) que cuenta los códigos DISTINTOS sin galería que pide cada IP: una familia que recarga el
    // QR de un evento todavía sin publicar (o 100 familias en el wifi del salón) cuenta una sola vez.
    const ip = ipDe(req);
    const claveFallos = `ev-galeria-fallos:${ip}`;
    if (await bloqueadoPersistente(sb, claveFallos, MAX_CODIGOS_SIN_GALERIA, VENTANA_CODIGOS_SEG)) {
      return res.status(429).json({ success: false, error: 'Demasiados intentos seguidos. Esperá unos minutos y probá de nuevo.' });
    }
    // 14/10/2026: también por un código ANTERIOR (QR impreso antes de cambiarlo); la respuesta trae el actual.
    const ev = await buscarEventoPorCodigo(sb, codigo, 'id, codigo, nombre, lugar, fecha_evento, fecha_limite, fecha_primer_envio, precio_digital, precio_15x21, precio_20x30, impresa_incluye_digital, publicado, muestras_lupa');
    // Sin galería para mostrar (el código no existe, el evento no está publicado o no tiene fotos):
    // Auditoría 03/10 noche: SIEMPRE la misma respuesta, sin datos del evento, para que no sirva para
    // saber qué códigos existen. La familia ve el "próximamente" genérico y puede dejar su email.
    const proximamente = async () => {
      await contarCodigoSinGaleria(ip, codigo);
      res.setHeader('Cache-Control', 'no-store');
      return res.json({ success: true, proximamente: true, evento: { codigo } });
    };
    if (!ev || !ev.publicado) return await proximamente();
    const fotos: any[] = [];
    for (let desde = 0; ; desde += 1000) {
      const { data, error: errFotos } = await sb
        .from('ev_fotos')
        .select('id, nombre_archivo, preview_path, thumb_path, ancho, alto')
        .eq('evento_id', ev.id)
        .order('orden', { ascending: true })
        .order('nombre_archivo', { ascending: true })
        .range(desde, desde + 999);
      if (errFotos) throw errFotos;
      fotos.push(...(data || []));
      if (!data || data.length < 1000) break;
    }
    if (fotos.length === 0) return await proximamente();
    const { id: _id, publicado: _pub, ...publico } = ev as any;
    void _id; void _pub;
    res.setHeader('Cache-Control', 'no-store');
    return res.json({
      success: true,
      evento: { ...publico, fecha_primer_envio: fechaPrimerEnvio(ev), cerrado: eventoCerrado(ev.fecha_limite) },
      fotos: fotos.map((f) => ({
        id: f.id,
        nombre: f.nombre_archivo,
        thumb: urlPublicaWeb(f.thumb_path),
        muestra: urlPublicaWeb(f.preview_path),
        ancho: f.ancho,
        alto: f.alto,
      })),
    });
  } catch (err) {
    return errorInterno(res, 'cargar la galería', err);
  }
});

// LUPA (04/10): manda SÓLO el pedacito mirado (cx, cy centro 0-1; s lado/ancho), recortado de una copia de 800 px.
const fotosLupaEvento = new Map<string, { hasta: number; ruta: string | null }>();
// Auditoría 08/10 (A1): además del tope en memoria, uno persistente por IP y por hora.
app.get('/api/eventos/publico/:codigo/lupa/:fotoId', limitar('ev-lupa', 3000, 10 * 60 * 1000), limitarPersistenteSinEspera('ev-lupa-hora', 2000, 60 * 60 * 1000), async (req, res) => {
  const codigo = normalizarCodigo(req.params.codigo);
  const fotoId = String(req.params.fotoId || '');
  const pedido = leerPedidoRecorte(req.query as Record<string, unknown>);
  if (!/^[A-Z0-9-]{4,30}$/.test(codigo) || !esUuid(fotoId) || !pedido) {
    return res.status(400).json({ success: false, error: 'Pedido de lupa inválido' });
  }
  const sb = conSupabase(res);
  if (!sb) return;
  try {
    const clave = `${codigo}|${fotoId}`;
    let guardada = fotosLupaEvento.get(clave);
    if (!guardada || guardada.hasta < Date.now()) {
      // Sólo fotos de un evento PUBLICADO con ese código (lo mismo que la galería) y con la lupa prendida.
      const { data: ev, error } = await sb.from('ev_eventos').select('id, publicado, muestras_lupa').eq('codigo', codigo).maybeSingle();
      if (error) throw error;
      let ruta: string | null = null;
      if (ev && ev.publicado && ev.muestras_lupa === true) {
        const { data: foto, error: errFoto } = await sb
          .from('ev_fotos').select('storage_path_hd').eq('id', fotoId).eq('evento_id', ev.id).maybeSingle();
        if (errFoto) throw errFoto;
        ruta = foto?.storage_path_hd || null;
      }
      guardada = { hasta: Date.now() + 60 * 1000, ruta };
      fotosLupaEvento.set(clave, guardada);
      if (fotosLupaEvento.size > 5000) fotosLupaEvento.clear();
    }
    const ruta = guardada.ruta;
    if (!ruta) return res.status(404).json({ success: false, error: 'No encontramos esa foto.' });
    // 09/10: la copia de 800 px queda guardada al lado del original (bucket privado), así la primera
    // vez no hay que bajar el original entero (lupa/recorte.ts, rutaCopiaLupa).
    const rutaCopia = rutaCopiaLupa(ruta);
    const fuente = await obtenerFuenteLupa(
      `evento:${fotoId}:${ruta}`,
      () => cargarOriginalEvento(sb, ruta), // 17/10: si el original está sólo en Drive, lo baja de ahí
      {
        leer: async () => {
          const { data, error } = await sb.storage.from(BUCKET_HD).download(rutaCopia);
          return error || !data ? null : Buffer.from(await data.arrayBuffer());
        },
        guardar: async (copia) => {
          await sb.storage.from(BUCKET_HD).upload(rutaCopia, copia, { contentType: 'image/jpeg', upsert: true });
        },
      }
    );
    const region = calcularRegion(fuente, pedido);
    // 04/10: sin sellos dentro de la lupa (pedido de Pablo).
    const recorte = await recortarConSello(fuente, region);
    res.set(encabezadosRecorte(region, fuente));
    return res.send(recorte);
  } catch (err) {
    return errorInterno(res, 'mostrar la lupa', err);
  }
});

// Crear un pedido (total calculado en el servidor). 05/10: 80 por IP cada 10 min + 6 por IP+email (tras validar el cuerpo).
const MAX_PEDIDOS_POR_EMAIL = 6;
const VENTANA_PEDIDOS_SEG = 10 * 60;
app.post('/api/eventos/publico/:codigo/pedidos', limitarPersistente('pedido', 80, VENTANA_PEDIDOS_SEG * 1000), async (req, res) => {
  const codigo = normalizarCodigo(req.params.codigo);
  const medioPago = String(req.body?.medioPago || '');
  // 27/10/2026: con un código de descuento el pedido puede quedar en $0 (sin medio de pago): se decide más abajo.
  const conCodigo = hayCodigoDescuento(req.body?.codigoDescuento), medioValido = medioPago === 'mercadopago' || medioPago === 'transferencia';
  if (!medioValido && !conCodigo) return res.status(400).json({ success: false, error: 'Elegí cómo vas a pagar.' });
  if (req.body?.aceptaCondiciones !== true) return res.status(400).json({ success: false, error: 'Tenés que aceptar las condiciones de compra.' });
  const comprador = validarComprador(req.body);
  if (comprador.error) return res.status(400).json({ success: false, error: comprador.error });
  const sb = conSupabase(res);
  if (!sb) return;
  {
    const esperaEmail = await esperaPersistente(`ev-pedido-email:${ipDe(req)}:${comprador.datos!.comprador_email}`, MAX_PEDIDOS_POR_EMAIL, VENTANA_PEDIDOS_SEG);
    if (esperaEmail > 0) return res.status(429).json({ success: false, error: 'Demasiados pedidos seguidos con este email. Esperá unos minutos y probá de nuevo.' });
  }
  const mp = medioPago === 'mercadopago' ? getMercadoPago() : null;
  if (medioPago === 'mercadopago' && !mp && !conCodigo) {
    return res.status(503).json({ success: false, error: 'Mercado Pago no está disponible en este momento. Elegí transferencia.' });
  }
  let descuento: DescuentoEvento | null = null, usoGastado = false;
  try {
    // Auditoría 11/10: mismo freno que la galería; código inexistente = la MISMA respuesta que una foto ajena.
    const ip = ipDe(req);
    if (await bloqueadoPersistente(sb, `ev-galeria-fallos:${ip}`, MAX_CODIGOS_SIN_GALERIA, VENTANA_CODIGOS_SEG)) {
      return res.status(429).json({ success: false, error: 'Demasiados intentos seguidos. Esperá unos minutos y probá de nuevo.' });
    }
    const { data: ev, error: errEv } = await sb
      .from('ev_eventos')
      .select('id, codigo, nombre, fecha_limite, precio_digital, precio_15x21, precio_20x30, impresa_incluye_digital')
      .eq('codigo', codigo)
      .eq('publicado', true)
      .maybeSingle();
    if (errEv) throw errEv;
    if (!ev) {
      await contarCodigoSinGaleria(ip, codigo);
      const sinEvento = calcularPedido(req.body?.items, { precio_digital: 0, precio_15x21: 0, precio_20x30: 0, impresa_incluye_digital: false }, new Set());
      return res.status(400).json({ success: false, error: sinEvento.error });
    }
    if (eventoCerrado(ev.fecha_limite)) return res.status(410).json({ success: false, error: 'El plazo para hacer pedidos de este evento ya terminó.' }); // la galería ya lo dice

    const calculo = calcularPedido(req.body?.items, ev as any, await idsDeFotos(sb, ev.id));
    if (calculo.error !== undefined) return res.status(400).json({ success: false, error: calculo.error });

    // 27/10/2026: código de descuento (ver eventos/descuentos.ts). Sin código, totalFinal = calculo.total.
    const conDescuento = await resolverDescuentoEvento(sb, req.body?.codigoDescuento, ip, calculo.items, (clave, max, seg) => esperaPersistente(clave, max, seg));
    if (conDescuento.error) return res.status(conDescuento.status!).json({ success: false, error: conDescuento.error, codigoInvalido: conDescuento.status === 400 || undefined });
    const { monto: montoDescuento, total: totalFinal, sinCargo } = conDescuento; descuento = conDescuento.descuento;
    if (!sinCargo && !medioValido) return res.status(400).json({ success: false, error: 'Elegí cómo vas a pagar.' });
    if (!sinCargo && medioPago === 'mercadopago' && !mp) return res.status(503).json({ success: false, error: 'Mercado Pago no está disponible en este momento. Elegí transferencia.' });
    const medioFinal = sinCargo ? 'bonificado' : medioPago;
    const base = baseUrl(req);
    // Auditoría 03/10 noche: la preferencia se guarda en el pedido (acepta_novedades) y la suscripción se
    // registra recién cuando el pedido queda pagado (ver procesarPagoAprobado).
    const aceptaNovedades = req.body?.aceptaNovedades === true;
    // Auditoría 02/10: si la respuesta anterior no le llegó a la familia (se cortó la señal) y vuelve a
    // tocar "Confirmar", se devuelve el MISMO pedido en vez de crear otro (mismo email, mismas fotos, 15 min).
    const firma = (lineas: Array<{ foto_id: string; formato: string; cantidad: number }>) =>
      lineas.map((it) => `${it.foto_id}|${it.formato}|${it.cantidad}`).sort().join(',');
    const { data: recientes, error: errRec } = await sb
      .from('ev_pedidos')
      .select('id, numero, total, medio_pago, vence_en, nino_nombre, nino_curso, comprador_nombre, comprador_email, mp_preference_id, ev_items_pedido(foto_id, formato, cantidad)')
      .eq('evento_id', ev.id)
      .eq('comprador_email', comprador.datos!.comprador_email)
      .eq('nino_nombre', comprador.datos!.nino_nombre) // mellizos: misma foto para dos chicos = dos pedidos
      .eq('estado', 'pendiente')
      .is('comprobante_subido_en', null)
      .gte('creado_en', new Date(Date.now() - 15 * 60 * 1000).toISOString())
      .limit(5);
    if (errRec) throw errRec;
    const repetido = (recientes || []).find((r: any) =>
      Number(r.total) === totalFinal &&
      (r.nino_curso || null) === (comprador.datos!.nino_curso || null) &&
      firma(r.ev_items_pedido || []) === firma(calculo.items));
    if (repetido) {
      // Auditoría 03/10 noche: NO se entrega la llave ni se toca el pedido: se reenvía su link al email (1 cada 10 min).
      if (await primeraVez(`ev-repetido-mail:${repetido.id}`, 600)) {
        const completoRep = await leerPedido(sb, repetido.id);
        if (completoRep && completoRep.estado === 'pendiente') {
          const correoRep = completoRep.medio_pago === 'transferencia'
            ? correoTransferenciaPendiente(datosCorreo(completoRep, base))
            : correoPagoPendienteMp(datosCorreo(completoRep, base));
          await enviarCorreo({ to: completoRep.comprador_email, subject: correoRep.subject, html: correoRep.html });
        }
      }
      return res.json({ success: true, repetido: true, sinLlave: true, mensaje: 'Ya registramos este pedido: te reenviamos el link por email.' });
    }

    const venceEn = medioFinal === 'mercadopago' ? venceLinkMp() : new Date(Date.now() + PLAZO_TRANSFERENCIA_HORAS * 3600 * 1000).toISOString();
    // 27/10: el uso del código se gasta justo antes de registrar el pedido (atómico); si no se registra, se devuelve.
    if (descuento && !(usoGastado = await consumirUsoEvento(sb, descuento))) return res.status(400).json({ success: false, error: ERROR_DESCUENTO_EVENTO, codigoInvalido: true });
    let pedido: any = null;
    for (let intento = 0; intento < 6 && !pedido; intento++) {
      const { data, error } = await sb
        .from('ev_pedidos')
        .insert({ numero: numeroPedido(), evento_id: ev.id, ...comprador.datos, estado: 'pendiente', total: totalFinal, medio_pago: medioFinal, vence_en: venceEn, acepta_novedades: aceptaNovedades, ...columnasDescuentoEvento(descuento, montoDescuento) })
        .select()
        .single();
      if (error && (error as any).code !== '23505') throw error;
      pedido = data;
    }
    if (!pedido) throw new Error('No se pudo generar el número de pedido');

    const { error: errItems } = await sb.from('ev_items_pedido').insert(calculo.items.map((it) => ({ ...it, pedido_id: pedido.id })));
    if (errItems) {
      await sb.from('ev_pedidos').delete().eq('id', pedido.id);
      throw errItems;
    }
    usoGastado = false; // el pedido quedó registrado: el uso ya no se devuelve

    const enlace = urlPedido(base, ev.codigo, pedido.id);
    const llave = enlace.split('&t=')[1] || '';

    // 27/10: sin cargo por el código → se marca pagado ya (mails de «pago confirmado» con la descarga, como cualquier pago).
    if (sinCargo && (await procesarPagoAprobado(sb, pedido.id, 0, {}, base))) return res.json({ success: true, pedidoId: pedido.id, numero: pedido.numero, total: 0, llave, bonificado: true });
    if (medioPago === 'transferencia') {
      const completo = await leerPedido(sb, pedido.id);
      const { subject, html } = correoTransferenciaPendiente(datosCorreo(completo, base));
      await enviarCorreo({ to: pedido.comprador_email, subject, html });
      return res.json({ success: true, pedidoId: pedido.id, numero: pedido.numero, total: pedido.total, llave, venceEn });
    }

    // 05/10: si MP no responde, el pedido ya existe: mail + llave con initPoint null (reintenta o pasa a transferencia).
    let initPoint: string | undefined;
    let mpNoDisponible = false;
    try {
      initPoint = await crearPreferenciaEvento(sb, mp!, pedido, ev.nombre, base, enlace);
    } catch (err) {
      console.error('[eventos] Mercado Pago no respondió al crear la preferencia del pedido', pedido.numero, err);
      mpNoDisponible = true;
    }
    // Mail con el link del pedido también para Mercado Pago: si cierran el pago o cambian de
    // navegador, pueden volver a pagar (o pasar a transferencia) desde ahí.
    const completoMp = await leerPedido(sb, pedido.id);
    const correoMp = correoPagoPendienteMp(datosCorreo(completoMp, base));
    await enviarCorreo({ to: pedido.comprador_email, subject: correoMp.subject, html: correoMp.html });
    if (mpNoDisponible) {
      return res.json({
        success: true, pedidoId: pedido.id, numero: pedido.numero, total: pedido.total, llave, initPoint: null, mpNoDisponible: true,
        mensaje: 'Mercado Pago no respondió. Tu pedido quedó registrado: podés reintentar el pago desde acá o pagar por transferencia.',
      });
    }
    return res.json({ success: true, pedidoId: pedido.id, numero: pedido.numero, total: pedido.total, llave, initPoint });
  } catch (err) {
    if (usoGastado) await devolverUsoEvento(sb, descuento);
    return errorInterno(res, 'crear el pedido', err);
  }
});

/** Preferencia de Checkout Pro para un pedido (también al reintentar el pago). Devuelve el link de pago. */
async function crearPreferenciaEvento(sb: SupabaseClient, mp: MercadoPagoConfig, pedido: any, eventoNombre: string, base: string, enlace: string): Promise<string | undefined> {
  const preferencia = await new Preference(mp).create({
    body: {
      items: [{
        id: pedido.numero,
        title: `Fotos ${eventoNombre}`.slice(0, 250),
        description: `Pedido ${pedido.numero} — ${pedido.nino_nombre}`,
        quantity: 1,
        unit_price: Number(pedido.total),
        currency_id: 'ARS',
      }],
      payer: { name: pedido.comprador_nombre, email: pedido.comprador_email },
      back_urls: { success: enlace, failure: enlace, pending: enlace },
      auto_return: 'approved',
      external_reference: `ev:${pedido.id}`,
      notification_url: `${base}/api/eventos/webhook-mp`,
      statement_descriptor: 'RETRATO ESCOLAR',
      expires: true,
      expiration_date_from: new Date(Date.now() - 60 * 1000).toISOString(),
      expiration_date_to: new Date(Date.now() + DIAS_LINK_MP * 24 * 3600 * 1000).toISOString(),
    },
  });
  if (preferencia.id) {
    // Auditoría 11/10: si no se guarda el id, el link quedaría vivo sin que el panel pueda darlo de baja.
    // 14/10/2026: se guarda sólo si nadie cambió el link en el medio (otro dispositivo a la vez): el que
    // pierde da de baja el suyo y devuelve el link del que ganó (queda un solo link de pago vivo).
    const previa = pedido.mp_preference_id ? String(pedido.mp_preference_id) : null;
    let q = sb.from('ev_pedidos').update({ mp_preference_id: String(preferencia.id) }).eq('id', pedido.id);
    q = previa ? q.eq('mp_preference_id', previa) : q.is('mp_preference_id', null);
    const { data: guardada, error } = await q.select('id');
    if (error || !guardada?.length) await vencerPreferencia(String(preferencia.id));
    if (error) throw error;
    if (!guardada?.length) {
      const { data: fresco } = await sb.from('ev_pedidos').select('mp_preference_id').eq('id', pedido.id).maybeSingle();
      if (!fresco?.mp_preference_id) throw new Error('No se pudo guardar el link de pago');
      return (await new Preference(mp).get({ preferenceId: String(fresco.mp_preference_id) })).init_point;
    }
  }
  return preferencia.init_point;
}

/** ¿Hay un pago de Mercado Pago aprobado o en proceso para este pedido? (para no cobrar dos veces). */
async function pagoMercadoPagoEnCurso(mp: MercadoPagoConfig, pedidoId: string): Promise<'aprobado' | 'en_proceso' | null> {
  const busqueda = await new Payment(mp).search({ options: { external_reference: `ev:${pedidoId}`, sort: 'date_created', criteria: 'desc' } });
  const pagos = (busqueda?.results || []) as any[];
  if (pagos.some((x) => x.status === 'approved')) return 'aprobado';
  if (pagos.some((x) => x.status === 'pending' || x.status === 'in_process' || x.status === 'authorized')) return 'en_proceso';
  return null;
}

/**
 * Auditoría 03/10 noche: antes de BORRAR pedidos (o un evento con sus pedidos), los de Mercado Pago sin
 * pagar se consultan en MP. Si alguno tiene un pago aprobado o en proceso, no se borra nada (409); si
 * MP no responde, tampoco (503). Si está todo limpio, se dan de baja sus links de pago antes de borrar.
 * Devuelve null si se puede borrar.
 */
async function frenoBorradoMercadoPago(pedidos: Array<{ id: string; numero?: string; estado: string; medio_pago?: string; mp_preference_id?: string | null }>): Promise<{ status: number; error: string } | null> {
  // Revisión 03/10 noche: sólo los que pueden tener un pago en curso (con link de MP, pendientes o
  // vencidos); los cancelados ya tienen el link dado de baja. Así un evento con muchos checkouts
  // abandonados no tarda de más.
  const sinPagar = pedidos.filter((p) => p.medio_pago === 'mercadopago' && (p.estado === 'pendiente' || p.estado === 'vencido') && Boolean(p.mp_preference_id));
  if (sinPagar.length === 0) return null;
  const mp = getMercadoPago();
  if (mp) {
    let estados: Array<'aprobado' | 'en_proceso' | null>;
    try {
      estados = await enParalelo(sinPagar, 4, (p) => pagoMercadoPagoEnCurso(mp, p.id));
    } catch (err) {
      console.error('[eventos] No se pudo consultar Mercado Pago antes de borrar:', err);
      return { status: 503, error: 'No pudimos consultar Mercado Pago para ver si hay pagos en curso. No se borró nada: probá de nuevo en un rato.' };
    }
    const conPago = sinPagar.filter((_, i) => estados[i] !== null).map((p) => p.numero || p.id);
    if (conPago.length > 0) {
      return {
        status: 409,
        error: `Mercado Pago tiene un pago aprobado o en proceso para ${conPago.length === 1 ? 'el pedido' : 'los pedidos'} ${conPago.slice(0, 10).join(', ')}${conPago.length > 10 ? '…' : ''}. No se borró nada: actualizá la lista (si se aprobó, tocá «Aprobar pago» para registrarlo) o esperá a que se resuelva.`,
      };
    }
  }
  await enParalelo(sinPagar.filter((p) => p.mp_preference_id), 4, (p) => vencerPreferencia(p.mp_preference_id));
  return null;
}

function pedidoParaFamilia(pedido: any) {
  const items = ((pedido.ev_items_pedido || []) as any[])
    .map((it) => ({
      fotoId: it.foto_id,
      nombre: it.ev_fotos?.nombre_archivo || '',
      thumb: it.ev_fotos?.thumb_path ? urlPublicaWeb(it.ev_fotos.thumb_path) : null,
      formato: it.formato,
      cantidad: it.cantidad,
      subtotal: it.subtotal,
      incluyeDigital: it.incluye_digital,
    }))
    .sort((a, b) => a.nombre.localeCompare(b.nombre, 'es', { numeric: true }));
  const descargables = pedido.estado === 'pagado'
    ? [...new Map(items.filter((it) => it.incluyeDigital).map((it) => [it.fotoId, { fotoId: it.fotoId, nombre: it.nombre, thumb: it.thumb }])).values()]
    : [];
  return {
    numero: pedido.numero,
    estado: pedido.estado,
    estadoEntrega: pedido.estado_entrega,
    medioPago: pedido.medio_pago,
    total: pedido.total,
    descuento: Number(pedido.descuento_monto) > 0 ? { codigo: pedido.codigo_descuento, monto: Number(pedido.descuento_monto) } : null, // 27/10
    venceEn: pedido.vence_en,
    comprobanteSubidoEn: pedido.comprobante_subido_en,
    ninoNombre: pedido.nino_nombre,
    ninoCurso: pedido.nino_curso,
    compradorEmail: pedido.comprador_email,
    evento: { codigo: pedido.ev_eventos?.codigo, nombre: pedido.ev_eventos?.nombre },
    items,
    descargables,
    transferencia: pedido.medio_pago === 'transferencia' && pedido.estado === 'pendiente' ? DATOS_TRANSFERENCIA : null,
  };
}

// Estado del pedido (con la llave del link). Si está pago, incluye las fotos para descargar.
app.get('/api/eventos/pedido/:id', limitar('ev-estado', 300, 10 * 60 * 1000), async (req, res) => {
  const id = req.params.id;
  if (!esUuid(id) || !llaveValida(id, req.query.t)) return res.status(403).json({ success: false, error: 'El link del pedido no es válido. Usá el del correo.' });
  const sb = conSupabase(res);
  if (!sb) return;
  try {
    let pedido = await leerPedido(sb, id);
    if (!pedido) return res.status(404).json({ success: false, error: 'No encontramos el pedido.' });
    pedido = await vencerSiCorresponde(sb, pedido);
    if (pedido.estado === 'pendiente' && pedido.medio_pago === 'mercadopago') await conciliarConMercadoPago(sb, pedido, baseUrl(req));
    res.setHeader('Cache-Control', 'no-store');
    return res.json({ success: true, pedido: pedidoParaFamilia(pedido) });
  } catch (err) {
    return errorInterno(res, 'consultar el pedido', err);
  }
});

// Cambiar o reintentar el medio de pago de un pedido sin pagar (pedido de Pablo, 02/10/2026):
// si Mercado Pago falló, la familia puede reintentar o pasar a transferencia; y al revés si todavía
// no subió el comprobante. Antes se controla en Mercado Pago que no haya un pago hecho o en curso.
app.post('/api/eventos/pedido/:id/medio-pago', limitarPersistente('medio-pago', 15, 10 * 60 * 1000), async (req, res) => {
  const id = req.params.id;
  if (!esUuid(id) || !llaveValida(id, req.query.t)) return res.status(403).json({ success: false, error: 'El link del pedido no es válido. Usá el del correo.' });
  const medio = String(req.body?.medioPago || '');
  if (medio !== 'mercadopago' && medio !== 'transferencia') return res.status(400).json({ success: false, error: 'Elegí cómo vas a pagar.' });
  const sb = conSupabase(res);
  if (!sb) return;
  try {
    let pedido = await leerPedido(sb, id);
    if (!pedido) return res.status(404).json({ success: false, error: 'No encontramos el pedido.' });
    pedido = await vencerSiCorresponde(sb, pedido);
    const base = baseUrl(req);
    if (pedido.estado === 'pendiente' && pedido.medio_pago === 'mercadopago') await conciliarConMercadoPago(sb, pedido, base);
    if (pedido.estado === 'pagado') return res.json({ success: true, estado: 'pagado' });
    if (pedido.estado !== 'pendiente') {
      return res.status(409).json({ success: false, error: pedido.estado === 'vencido' ? 'El pedido venció. Hacé un pedido nuevo desde la galería.' : 'Este pedido fue cancelado. Hacé un pedido nuevo desde la galería.' });
    }
    if (pedido.comprobante_subido_en) return res.status(409).json({ success: false, error: 'Ya subiste el comprobante de la transferencia: lo estamos verificando.' });
    // Auditoría 02/10: con el evento cerrado hace más de 2 días ya no se reabre el pago (el lote del
    // laboratorio ya salió). Los 2 días de margen cubren a quien pidió el último día y le falló el pago.
    const limite = pedido.ev_eventos?.fecha_limite;
    if (limite && eventoCerrado(limite, Date.now() - 2 * 24 * 3600 * 1000)) {
      return res.status(410).json({ success: false, error: 'El plazo de este evento ya terminó. Si querías pagar este pedido, respondé el mail del pedido y lo vemos.' });
    }

    const mp = getMercadoPago();
    if (pedido.medio_pago === 'mercadopago' && mp) {
      const enCurso = await pagoMercadoPagoEnCurso(mp, pedido.id);
      if (enCurso === 'aprobado') return res.json({ success: true, estado: 'pagado' }); // el aviso llega en segundos
      if (enCurso === 'en_proceso') {
        return res.status(409).json({ success: false, error: 'Mercado Pago tiene un pago tuyo en proceso para este pedido. Esperá a que se acredite o se rechace antes de pagar de otra forma.' });
      }
    }

    if (medio === 'mercadopago') {
      if (!mp) return res.status(503).json({ success: false, error: 'Mercado Pago no está disponible en este momento. Pagá por transferencia.' });
      await vencerPreferencia(pedido.mp_preference_id); // un solo link de pago vivo por pedido
      const { error } = await sb.from('ev_pedidos').update({ medio_pago: 'mercadopago', vence_en: venceLinkMp() }).eq('id', pedido.id).eq('estado', 'pendiente');
      if (error) throw error;
      const initPoint = await crearPreferenciaEvento(sb, mp, pedido, pedido.ev_eventos?.nombre || 'Evento', base, urlPedido(base, pedido.ev_eventos?.codigo || '', pedido.id));
      if (!initPoint) throw new Error('Mercado Pago no devolvió el link de pago');
      return res.json({ success: true, estado: 'pendiente', initPoint });
    }

    // A transferencia: plazo nuevo para subir el comprobante y mail con los datos.
    if (pedido.medio_pago === 'transferencia') return res.json({ success: true, estado: 'pendiente', venceEn: pedido.vence_en });
    const venceEn = new Date(Date.now() + PLAZO_TRANSFERENCIA_HORAS * 3600 * 1000).toISOString();
    await vencerPreferencia(pedido.mp_preference_id); // el link viejo de Mercado Pago deja de servir
    const { error } = await sb.from('ev_pedidos').update({ medio_pago: 'transferencia', vence_en: venceEn }).eq('id', pedido.id).eq('estado', 'pendiente');
    if (error) throw error;
    pedido.medio_pago = 'transferencia';
    pedido.vence_en = venceEn;
    const { subject, html } = correoTransferenciaPendiente(datosCorreo(pedido, base));
    await enviarCorreo({ to: pedido.comprador_email, subject, html });
    return res.json({ success: true, estado: 'pendiente', venceEn });
  } catch (err) {
    return errorInterno(res, 'cambiar el medio de pago', err);
  }
});

// Descarga de una foto digital comprada (redirige a un link firmado de 10 minutos).
app.get('/api/eventos/pedido/:id/descargar/:fotoId', limitar('ev-descarga', 400, 10 * 60 * 1000), async (req, res) => {
  const { id, fotoId } = req.params;
  if (!esUuid(id) || !esUuid(fotoId) || !llaveValida(id, req.query.t)) return res.status(403).send('Link inválido.');
  const sb = conSupabase(res);
  if (!sb) return;
  try {
    const pedido = await leerPedido(sb, id);
    if (!pedido || pedido.estado !== 'pagado') return res.status(403).send('El pedido todavía no está pago.');
    const item = (pedido.ev_items_pedido || []).find((it: any) => it.foto_id === fotoId && it.incluye_digital);
    if (!item) return res.status(404).send('Esa foto no está en el pedido.');
    const { data: foto, error } = await sb.from('ev_fotos').select('storage_path_hd, nombre_archivo').eq('id', fotoId).maybeSingle();
    if (error) throw error;
    if (!foto) return res.status(404).send('No encontramos la foto.'); if ((await asegurarOriginales(sb, [foto.storage_path_hd], 40000, avisarOriginalesPerdidos)) > 0) return res.status(503).send('Estamos preparando la foto en alta. Probá de nuevo en un minuto.');
    const nombre = `${pedido.numero}-${foto.nombre_archivo}`.replace(/[^\w.\-]/g, '_');
    const { data: firmada, error: errFirma } = await sb.storage.from(BUCKET_HD).createSignedUrl(foto.storage_path_hd, 600, { download: nombre });
    if (errFirma) throw errFirma;
    res.setHeader('Cache-Control', 'no-store');
    return res.redirect(302, firmada.signedUrl);
  } catch (err) {
    console.error('[eventos] descarga:', err);
    return res.status(500).send('No pudimos preparar la descarga. Probá de nuevo en un rato.');
  }
});

const TIPOS_COMPROBANTE: Record<string, string> = {
  'image/jpeg': 'jpg', 'image/jpg': 'jpg', 'image/png': 'png', 'image/webp': 'webp', 'image/heic': 'heic', 'image/heif': 'heif', 'application/pdf': 'pdf',
};
const COMPROBANTE_MAX_BYTES = 2.5 * 1024 * 1024;

export function firmaArchivoValida(buffer: Buffer, extension: string): boolean {
  const c = buffer.subarray(0, 16);
  return (
    (extension === 'jpg' && c[0] === 0xff && c[1] === 0xd8 && c[2] === 0xff) ||
    (extension === 'png' && c.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))) ||
    (extension === 'webp' && c.subarray(0, 4).toString('latin1') === 'RIFF' && c.subarray(8, 12).toString('latin1') === 'WEBP') ||
    ((extension === 'heic' || extension === 'heif') && c.subarray(4, 8).toString('latin1') === 'ftyp' &&
      ['heic', 'heix', 'hevc', 'hevx', 'heim', 'heis', 'mif1', 'msf1'].includes(c.subarray(8, 12).toString('latin1'))) ||
    (extension === 'pdf' && c.subarray(0, 5).toString('latin1') === '%PDF-')
  );
}

/** 05/10: borra un comprobante de Storage (best-effort: si falla, sólo log). No borra si es la misma ruta que `salvo`. */
async function borrarComprobante(sb: SupabaseClient, rutaAnterior: string | null | undefined, salvo?: string): Promise<void> {
  if (!rutaAnterior || rutaAnterior === salvo) return;
  try {
    const { error } = await sb.storage.from('comprobantes').remove([rutaAnterior]);
    if (error) console.error('[eventos] No se pudo borrar el comprobante anterior:', error);
  } catch (err) {
    console.error('[eventos] No se pudo borrar el comprobante anterior:', err);
  }
}

// Subir el comprobante de la transferencia.
app.post('/api/eventos/pedido/:id/comprobante', limitarPersistente('comprobante', 20, 10 * 60 * 1000), async (req, res) => {
  const id = req.params.id;
  if (!esUuid(id) || !llaveValida(id, req.query.t)) return res.status(403).json({ success: false, error: 'El link del pedido no es válido. Usá el del correo.' });
  const sb = conSupabase(res);
  if (!sb) return;
  try {
    let pedido = await leerPedido(sb, id);
    if (!pedido) return res.status(404).json({ success: false, error: 'No encontramos el pedido.' });
    pedido = await vencerSiCorresponde(sb, pedido);
    if (pedido.medio_pago !== 'transferencia') return res.status(409).json({ success: false, error: 'Este pedido no es por transferencia.' });
    if (pedido.estado === 'pagado') return res.status(409).json({ success: false, error: 'Este pedido ya está pago.' });
    if (pedido.estado !== 'pendiente') return res.status(410).json({ success: false, error: 'Este pedido venció o se canceló. Si ya transferiste, respondé el correo del pedido con el comprobante.' });
    const coincidencia = /^data:([\w/+.-]+);base64,(.+)$/s.exec(String(req.body?.archivo || ''));
    const tipo = coincidencia?.[1]?.toLowerCase() || '';
    const extension = TIPOS_COMPROBANTE[tipo];
    if (!coincidencia || !extension) return res.status(400).json({ success: false, error: 'Subí una foto (JPG, PNG) o un PDF del comprobante.' });
    const buffer = Buffer.from(coincidencia[2], 'base64');
    if (buffer.length === 0 || buffer.length > COMPROBANTE_MAX_BYTES) return res.status(400).json({ success: false, error: 'El archivo es muy grande (máximo 2,5 MB). Probá con una captura de pantalla.' });
    if (!firmaArchivoValida(buffer, extension)) return res.status(400).json({ success: false, error: 'El archivo no parece una imagen o PDF válido.' });
    if (pedido.comprobante_subido_en && Date.now() - Date.parse(pedido.comprobante_subido_en) < 2 * 60 * 1000) {
      return res.status(429).json({ success: false, error: 'Ya recibimos un comprobante hace un momento. Esperá 2 minutos si querés reemplazarlo.' });
    }
    const ruta = `eventos/${id}/${Date.now()}.${extension}`;
    const { error: errSubida } = await sb.storage.from('comprobantes').upload(ruta, buffer, { contentType: tipo, upsert: false });
    if (errSubida) throw errSubida;
    const ahora = new Date().toISOString();
    // 14/10/2026: condicional (sigue pendiente por transferencia y nadie subió otro en el medio): si dos dispositivos
    // lo suben a la vez, gana uno solo y a Pablo le llega un solo mail; un pedido cancelado no recibe comprobantes.
    let q = sb.from('ev_pedidos').update({ comprobante_path: ruta, comprobante_subido_en: ahora }).eq('id', id).eq('estado', 'pendiente').eq('medio_pago', 'transferencia');
    q = pedido.comprobante_subido_en ? q.eq('comprobante_subido_en', pedido.comprobante_subido_en) : q.is('comprobante_subido_en', null);
    const { data: guardado, error: errUpd } = await q.select('id');
    if (errUpd || !guardado?.length) await borrarComprobante(sb, ruta);
    if (errUpd) throw errUpd;
    if (!guardado?.length) return res.status(409).json({ success: false, error: 'Ya recibimos un comprobante para este pedido (o cambió de estado). Recargá la página para ver cómo quedó.' });
    // 05/10: el comprobante anterior (si lo reemplazó) quedaba huérfano en Storage. Se borra; si falla, sólo log.
    await borrarComprobante(sb, pedido.comprobante_path, ruta);
    const d = datosCorreo(pedido, baseUrl(req));
    const aviso = correoAvisoAdmin('🧾 Comprobante de transferencia (evento)', { ...d, compradorEmail: pedido.comprador_email, compradorWhatsapp: pedido.comprador_whatsapp, medioPago: 'Transferencia' },
      '<p>El comprobante va adjunto. Si la transferencia está acreditada, aprobalo desde el panel de eventos → Pedidos → <strong>Aprobar pago</strong>.</p>');
    // El nombre del adjunto lo pone el servidor (nunca el que manda el navegador).
    const nombreSeguro = `comprobante-${String(pedido.numero).replace(/[^\w-]/g, '_')}.${extension}`;
    await avisarAdmin(aviso.subject, aviso.html, [{ filename: nombreSeguro, content: buffer.toString('base64') }]);
    return res.status(201).json({ success: true, fecha: ahora });
  } catch (err) {
    return errorInterno(res, 'guardar el comprobante', err);
  }
});

// Webhook de Mercado Pago propio del módulo (notification_url de cada preferencia de eventos).
app.post('/api/eventos/webhook-mp', async (req, res) => {
  try {
    const mp = getMercadoPago();
    if (!mp) return res.status(200).send('OK');
    // 10/10: los IPN (`?topic=…&id=…`, sin data.id) no se pueden firmar: 200 sin procesar (vale el aviso firmado).
    if (typeof req.query.topic === 'string' && req.query['data.id'] === undefined) return res.status(200).send('OK');
    const topic = req.query.topic || req.query.type || req.body?.type || req.body?.topic;
    const paymentId = req.query.id || req.query['data.id'] || req.body?.data?.id;
    // Auditoría 03/10 noche: sin MERCADOPAGO_WEBHOOK_SECRET falla cerrado; firma obligatoria y ts ≤ 72 h.
    const secreto = process.env.MERCADOPAGO_WEBHOOK_SECRET?.trim();
    if (!secreto) {
      console.error('[eventos] Falta MERCADOPAGO_WEBHOOK_SECRET: aviso de Mercado Pago rechazado.');
      return res.status(401).send('Webhook secret not configured');
    }
    {
      const firma = String(req.headers['x-signature'] || '');
      let ts = '';
      let v1 = '';
      for (const parte of firma.split(',')) {
        const [k, v] = parte.split('=');
        if (k?.trim() === 'ts') ts = (v || '').trim();
        if (k?.trim() === 'v1') v1 = (v || '').trim();
      }
      const manifiesto = `id:${paymentId};request-id:${req.headers['x-request-id'] || ''};ts:${ts};`;
      const esperada = crypto.createHmac('sha256', secreto).update(manifiesto).digest('hex');
      if (!ts || !v1 || !compararTimingSafe(v1, esperada)) {
        console.warn('[eventos] Webhook MP con firma inválida — rechazado.');
        return res.status(401).send('Invalid signature');
      }
      const tsNumero = Number(ts);
      const tsMs = tsNumero > 1e12 ? tsNumero : tsNumero * 1000;
      if (!Number.isFinite(tsMs) || Math.abs(Date.now() - tsMs) > 72 * 60 * 60 * 1000) {
        console.warn('[eventos] Webhook MP con ts vencido — rechazado.');
        return res.status(401).send('Stale notification');
      }
    }
    if (!(topic === 'payment' || String(req.body?.action || '').includes('payment')) || !paymentId) return res.status(200).send('OK');

    const pago: any = await new Payment(mp).get({ id: String(paymentId), requestOptions: { timeout: 8000 } });
    const referencia = String(pago.external_reference || '');
    if (!referencia.startsWith('ev:')) return res.status(200).send('OK');
    const pedidoId = referencia.slice(3);
    if (!esUuid(pedidoId)) return res.status(200).send('OK');
    const sb = getSupabase();
    if (!sb) return res.status(500).send('Error');

    if (pago.status === 'approved') {
      await procesarPagoAprobado(sb, pedidoId, Number(pago.transaction_amount), { mp_payment_id: String(paymentId) }, baseUrl());
    } else if (pago.status === 'refunded' || pago.status === 'charged_back') {
      const { data: revertidos, error: errRev } = await sb
        .from('ev_pedidos')
        .update({ estado: 'cancelado' })
        .eq('mp_payment_id', String(paymentId))
        .select('numero, estado_entrega');
      if (errRev) throw errRev; // auditoría 11/10: 500 → Mercado Pago reintenta (antes 200 y el pedido seguía pagado)
      if (revertidos && revertidos.length > 0) {
        await avisarAdmin(`⚠️ Pago devuelto en eventos (${revertidos.map((r: any) => r.numero).join(', ')})`,
          `<p>Mercado Pago informó "${escapeHtml(pago.status)}" para el pago ${escapeHtml(paymentId)}. El pedido quedó cancelado y ya no se pueden descargar las fotos. Si estaba en el laboratorio, frenalo.</p>`);
      }
    }
    // Rechazos: el pedido queda pendiente (la familia puede volver a intentar desde el link).
    return res.status(200).send('OK');
  } catch (err) {
    console.error('[eventos] Webhook MP:', err);
    return res.status(500).send('Error'); // Mercado Pago reintenta; el proceso es idempotente.
  }
});

// ---------------- Panel: pedidos (mínimo para la fase 2; la fase 3 suma entregas y laboratorio) ----------------
app.get('/api/eventos/admin/eventos/:id/pedidos', requireAdmin, async (req, res) => {
  if (!esUuid(req.params.id)) return res.status(400).json({ success: false, error: 'Evento inválido' });
  const sb = conSupabase(res);
  if (!sb) return;
  try {
    const vistoHasta = new Date().toISOString(); // 11/10: lo que se ve ahora deja de ser «compra nueva» en la tarjeta
    const data = await todasLasFilas((d, h) =>
      sb.from('ev_pedidos').select(SELECT_PEDIDO).eq('evento_id', req.params.id).order('creado_en', { ascending: false }).order('id').range(d, h));
    const actualizados = await enParalelo(data, 6, (p: any) => vencerSiCorresponde(sb, p));
    const pedidos = [];
    for (const actual of actualizados) {
      const { ev_items_pedido, ev_eventos, ...resto } = actual as any;
      void ev_eventos;
      pedidos.push({
        ...resto,
        items: (ev_items_pedido || []).map((it: any) => ({ nombre: it.ev_fotos?.nombre_archivo, formato: it.formato, cantidad: it.cantidad, subtotal: it.subtotal })),
      });
    }
    // 14/10/2026: sólo al abrir la lista a propósito (?vistos=1); el refresco automático de cada minuto no borra el aviso.
    if (req.query.vistos === '1') await marcarPedidosVistos(sb, req.params.id, vistoHasta);
    return res.json({ success: true, pedidos });
  } catch (err) {
    return errorInterno(res, 'listar los pedidos', err);
  }
});

app.post('/api/eventos/admin/pedidos/:id/aprobar', requireAdmin, async (req, res) => {
  if (!esUuid(req.params.id)) return res.status(400).json({ success: false, error: 'Pedido inválido' });
  const sb = conSupabase(res);
  if (!sb) return;
  try {
    const pedido = await leerPedido(sb, req.params.id);
    if (!pedido) return res.status(404).json({ success: false, error: 'No se encontró el pedido' });
    if (pedido.estado === 'pagado') return res.json({ success: true, estado: 'pagado', yaEstaba: true });
    if (pedido.estado === 'cancelado') return res.status(409).json({ success: false, error: 'El pedido está cancelado.' });
    // Auditoría 02/10: un pedido de Mercado Pago se aprueba solo. A mano, sólo si Pablo confirma que le
    // pagaron por otro medio, y nunca si Mercado Pago tiene un pago aprobado o en curso.
    if (pedido.medio_pago === 'mercadopago') {
      const mp = getMercadoPago();
      const enCurso = mp ? await pagoMercadoPagoEnCurso(mp, pedido.id) : null;
      if (enCurso === 'aprobado') {
        // Ya pagó por Mercado Pago (se perdió el aviso): se marca con ESE pago, no "a mano".
        pedido.estado = 'pendiente';
        await conciliarConMercadoPago(sb, pedido, baseUrl(req));
        const fresco = await leerPedido(sb, pedido.id);
        if (fresco?.estado !== 'pagado') {
          return res.status(409).json({ success: false, error: 'Mercado Pago figura aprobado pero no se pudo marcar como pagado (monto distinto o pago ya usado). Revisá el mail de aviso.' });
        }
        return res.json({ success: true, estado: 'pagado', yaEstaba: true });
      }
      if (enCurso === 'en_proceso') {
        return res.status(409).json({ success: false, error: 'Mercado Pago tiene un pago en proceso para este pedido: esperá a que se acredite o se rechace.' });
      }
      if (req.body?.pagoPorOtroMedio !== true) {
        return res.status(409).json({ success: false, error: 'Este pedido es con Mercado Pago y no figura ningún pago acreditado. Aprobalo a mano sólo si te pagó por otro medio.' });
      }
    }
    const r = await procesarPagoAprobado(sb, pedido.id, Number(pedido.total), {}, baseUrl(req));
    return res.json({ success: r !== 'rechazado', estado: r === 'rechazado' ? pedido.estado : 'pagado', error: r === 'rechazado' ? 'No se pudo aprobar' : undefined });
  } catch (err) {
    return errorInterno(res, 'aprobar el pago', err);
  }
});

app.post('/api/eventos/admin/pedidos/:id/cancelar', requireAdmin, async (req, res) => {
  if (!esUuid(req.params.id)) return res.status(400).json({ success: false, error: 'Pedido inválido' });
  const sb = conSupabase(res);
  if (!sb) return;
  try {
    const pedido = await leerPedido(sb, req.params.id);
    if (!pedido) return res.status(404).json({ success: false, error: 'No se encontró el pedido' });
    // Auditoría 02/10: antes de cancelar un pedido de Mercado Pago se consulta si ya pagó o está pagando.
    if (pedido.medio_pago === 'mercadopago' && (pedido.estado === 'pendiente' || pedido.estado === 'vencido')) {
      const mp = getMercadoPago();
      if (mp) {
        const enCurso = await pagoMercadoPagoEnCurso(mp, pedido.id);
        if (enCurso === 'aprobado') {
          if (pedido.estado === 'vencido') pedido.estado = 'pendiente';
          await conciliarConMercadoPago(sb, pedido, baseUrl(req));
          return res.status(409).json({ success: false, error: 'Este pedido ya se pagó por Mercado Pago: no se puede cancelar. Actualizá la lista.' });
        }
        if (enCurso === 'en_proceso') return res.status(409).json({ success: false, error: 'Mercado Pago tiene un pago en proceso para este pedido: esperá a que se resuelva.' });
      }
    }
    const { data, error } = await sb.from('ev_pedidos').update({ estado: 'cancelado' }).eq('id', req.params.id).in('estado', ['pendiente', 'vencido']).select('id');
    if (error) throw error;
    if (!data || data.length === 0) return res.status(409).json({ success: false, error: 'Sólo se pueden cancelar pedidos sin pagar.' });
    await vencerPreferencia(pedido.mp_preference_id); // el link de pago deja de servir
    // 05/10: un pedido cancelado no necesita el comprobante en Storage (best-effort).
    if (pedido.comprobante_path) {
      await borrarComprobante(sb, pedido.comprobante_path);
      await sb.from('ev_pedidos').update({ comprobante_path: null }).eq('id', req.params.id);
    }
    return res.json({ success: true });
  } catch (err) {
    return errorInterno(res, 'cancelar el pedido', err);
  }
});

// 03/10: borrar un pedido (pensado para pedidos de PRUEBA). Un pedido pagado sólo se borra si se
// confirma escribiendo su número (?confirmar=EV26-12345). Si ya está en un lote del laboratorio no se
// borra (puede estar imprimiéndose). No devuelve plata: eso se hace aparte en Mercado Pago o a mano.
app.delete('/api/eventos/admin/pedidos/:id', requireAdmin, async (req, res) => {
  if (!esUuid(req.params.id)) return res.status(400).json({ success: false, error: 'Pedido inválido' });
  const sb = conSupabase(res);
  if (!sb) return;
  try {
    const { data: pedido, error: errPed } = await sb.from('ev_pedidos')
      .select('id, numero, estado, medio_pago, mp_preference_id, lote_id, comprobante_path, comprobante_subido_en').eq('id', req.params.id).maybeSingle();
    if (errPed) throw errPed;
    if (!pedido) return res.status(404).json({ success: false, error: 'No se encontró el pedido' });
    if (pedido.lote_id) {
      return res.status(409).json({ success: false, error: `El pedido ${pedido.numero} ya está en un lote del laboratorio: no se puede borrar.` });
    }
    const confirmado = String(req.query.confirmar || '').trim().toUpperCase() === String(pedido.numero).toUpperCase();
    // 14/10/2026: una transferencia pendiente con comprobante subido (ya pagó) también pide confirmar.
    const conComprobante = pedido.estado === 'pendiente' && !!pedido.comprobante_subido_en;
    if ((pedido.estado === 'pagado' || conComprobante) && !confirmado) {
      return res.status(409).json({
        success: false,
        requiereConfirmacion: true,
        numero: pedido.numero,
        error: `El pedido ${pedido.numero} ${conComprobante ? 'ya subió el comprobante de la transferencia' : 'está PAGADO'}. Borrarlo no devuelve la plata. Si era una prueba, confirmá escribiendo el número del pedido.`,
      });
    }
    // Auditoría 03/10 noche: si es de Mercado Pago sin pagar, antes se consulta a MP y se da de baja el link.
    const freno = await frenoBorradoMercadoPago([pedido]);
    if (freno) return res.status(freno.status).json({ success: false, error: freno.error });
    // Ítems en cascada. Sólo si sigue sin lote (por si justo lo agregaron a uno).
    const { data: borrado, error } = await sb.from('ev_pedidos').delete().eq('id', pedido.id).is('lote_id', null).select('id');
    if (error) throw error;
    if (!borrado?.length) return res.status(409).json({ success: false, error: 'El pedido cambió mientras tanto: actualizá la lista.' });
    if (pedido.comprobante_path) {
      const { error: errComp } = await sb.storage.from('comprobantes').remove([pedido.comprobante_path]);
      if (errComp) console.error('[eventos] No se pudo borrar el comprobante:', errComp);
    }
    return res.json({ success: true });
  } catch (err) {
    return errorInterno(res, 'borrar el pedido', err);
  }
});

app.post('/api/eventos/admin/pedidos/:id/reenviar-mail', requireAdmin, async (req, res) => {
  if (!esUuid(req.params.id)) return res.status(400).json({ success: false, error: 'Pedido inválido' });
  const sb = conSupabase(res);
  if (!sb) return;
  try {
    const pedido = await leerPedido(sb, req.params.id);
    if (!pedido || pedido.estado !== 'pagado') return res.status(409).json({ success: false, error: 'Sólo se reenvía el mail de pedidos pagados.' });
    const ok = await enviarCorreoPagado(sb, pedido, baseUrl(req), true); // reenvío manual: aunque ya figure enviado
    return ok ? res.json({ success: true }): res.status(502).json({ success: false, error: 'No se pudo enviar el correo (revisá Resend).' });
  } catch (err) {
    return errorInterno(res, 'reenviar el correo', err);
  }
});

app.get('/api/eventos/admin/pedidos/:id/comprobante', requireAdmin, async (req, res) => {
  if (!esUuid(req.params.id)) return res.status(400).json({ success: false, error: 'Pedido inválido' });
  const sb = conSupabase(res);
  if (!sb) return;
  try {
    const { data: p, error } = await sb.from('ev_pedidos').select('comprobante_path').eq('id', req.params.id).maybeSingle();
    if (error) throw error;
    if (!p?.comprobante_path) return res.status(404).json({ success: false, error: 'Este pedido no tiene comprobante.' });
    const { data, error: errFirma } = await sb.storage.from('comprobantes').createSignedUrl(p.comprobante_path, 600);
    if (errFirma) throw errFirma;
    return res.json({ success: true, url: data.signedUrl });
  } catch (err) {
    return errorInterno(res, 'abrir el comprobante', err);
  }
});

// ===========================================================================
// FASE 3 — Entregas (estados + mail de "listo para retirar"), planilla, lotes y laboratorio.
// ===========================================================================

// Token del laboratorio: el MISMO que entrega /api/lab/login (LAB_PIN) en server.ts.
export function verificarTokenLab(token: string | undefined, secreto: string | undefined, ahora = Date.now()): boolean {
  if (!token || !secreto || !secreto.trim()) return false;
  const partes = token.split('.');
  if (partes.length !== 4 || partes[0] !== 'lab') return false;
  const [, ts, random, firma] = partes;
  const momento = parseInt(ts, 10);
  if (isNaN(momento) || ahora - momento > 12 * 60 * 60 * 1000) return false;
  const esperada = crypto.createHmac('sha256', secreto.trim()).update(`lab:${ts}.${random}`).digest('hex');
  return compararTimingSafe(firma, esperada);
}

function requireLab(req: Request, res: Response, next: NextFunction) {
  const secreto = process.env.ADMIN_SESSION_SECRET;
  const token = tokenDelPedido(req);
  if (verificarTokenLab(token, secreto)) {
    res.locals.esLaboratorio = true;
    return next();
  }
  if (verificarTokenAdmin(token, secreto)) return next();
  return res.status(401).json({ success: false, error: 'Sesión vencida. Volvé a ingresar con el PIN del laboratorio.' });
}

const SELECT_PEDIDO_LAB = 'id, numero, estado, estado_entrega, nino_nombre, nino_curso, lote_id, ev_items_pedido(formato, cantidad, foto_id, ev_fotos(nombre_archivo, storage_path_hd))';

function aPedidoLote(p: any): PedidoLote {
  return {
    numero: p.numero,
    nino_nombre: p.nino_nombre,
    nino_curso: p.nino_curso,
    items: (p.ev_items_pedido || []).map((it: any) => ({
      formato: it.formato,
      cantidad: it.cantidad,
      foto_id: it.foto_id,
      nombre_archivo: it.ev_fotos?.nombre_archivo || 'foto',
      storage_path_hd: it.ev_fotos?.storage_path_hd || '',
    })),
  };
}
const tieneImpresas = (p: any) => (p.ev_items_pedido || []).some((it: any) => it.formato !== 'digital');

const NOMBRE_ENTREGA: Record<string, string> = { en_laboratorio: 'En laboratorio', listo_retiro: 'Listo para retirar', entregado: 'Entregado' };

// Etapa de entrega ("listo_retiro" manda mail). 02/10: "en_laboratorio" sólo al armar lote; "listo" sólo con lote y
// reenvío de a uno; cambio condicional (un doble clic no duplica mails).
const VENTANA_AVISO_RETIRO_SEG = 2 * 60; // 05/10: un aviso «listo para retirar» no se repite dentro de esta ventana salvo reenvío explícito
app.post('/api/eventos/admin/pedidos/entrega', requireAdmin, async (req, res) => {
  const ids: unknown = req.body?.ids;
  const nueva = String(req.body?.estado || '') as EtapaEntrega;
  if (!Array.isArray(ids) || ids.length === 0 || ids.length > 300 || !ids.every(esUuid)) return res.status(400).json({ success: false, error: 'Elegí al menos un pedido.' });
  if (!ETAPAS_ENTREGA.includes(nueva)) return res.status(400).json({ success: false, error: 'Etapa inválida.' });
  if (nueva === 'en_laboratorio') return res.status(400).json({ success: false, error: 'Los pedidos pasan al laboratorio al armar un lote (sección Laboratorio).' });
  const sb = conSupabase(res);
  if (!sb) return;
  try {
    const base = baseUrl(req);
    // Auditoría 03/10 noche: el panel manda las selecciones grandes en tandas de 20 con `enBloque: true`;
    // una tanda de un solo pedido dentro de un envío en bloque NO cuenta como "reenviar a uno".
    const unico = ids.length === 1 && req.body?.enBloque !== true;
    const lugares = new Map<string, string | null>();
    const lugarRetiro = async (eventoId: string) => {
      if (!lugares.has(eventoId)) {
        const { data: ev } = await sb.from('ev_eventos').select('lugar_retiro').eq('id', eventoId).maybeSingle();
        lugares.set(eventoId, ev?.lugar_retiro || null);
      }
      return lugares.get(eventoId) || null;
    };
    const resultados = await enParalelo([...new Set(ids as string[])], 2, async (id): Promise<{ id: string; numero?: string; ok: boolean; error?: string; mail?: boolean; omitido?: boolean; sinAvisar?: boolean; recienAvisado?: boolean }> => {
      const pedido = await leerPedido(sb, id);
      if (!pedido) return { id, ok: false, error: 'No existe' };
      if (pedido.estado !== 'pagado') return { id, ok: false, error: `${pedido.numero}: no está pagado` };
      if (!tieneImpresas(pedido)) return { id, ok: false, error: `${pedido.numero}: es sólo digital` };
      if (nueva === 'listo_retiro' && !pedido.lote_id) return { id, ok: false, error: `${pedido.numero}: todavía no se mandó al laboratorio (armá un lote)` };
      const reenvio = nueva === 'listo_retiro' && pedido.estado_entrega === 'listo_retiro';
      if (reenvio && !unico) return { id, ok: true, omitido: true }; // ya estaba avisado: no se le reenvía en bloque
      // 05/10: si la primera llamada hizo el cambio y mandó el mail pero la respuesta se perdió, el reintento
      // automático del panel entraba como "reenvío a uno" y mandaba el mail otra vez. Sólo el botón explícito
      // «Reenviar el aviso» manda `reenviar: true`; sin eso, un aviso de hace menos de 2 minutos no se repite.
      const claveAviso = `ev-aviso-retiro:${id}`;
      let avisoMarcado = false; // ya se contó este envío en la ventana de 2 minutos
      if (reenvio && req.body?.reenviar !== true) {
        const hace = Date.parse(String(pedido.fecha_listo_retiro || ''));
        const reciente = Number.isFinite(hace) && Date.now() - hace < VENTANA_AVISO_RETIRO_SEG * 1000;
        if (reciente || (await esperaPersistente(claveAviso, 1, VENTANA_AVISO_RETIRO_SEG)) > 0) {
          return { id, numero: pedido.numero, ok: true, omitido: true, recienAvisado: true };
        }
        avisoMarcado = true;
      }
      if (!puedePasarA(pedido.estado_entrega, nueva)) {
        return { id, ok: false, error: `${pedido.numero}: está en "${NOMBRE_ENTREGA[pedido.estado_entrega] || 'Pagado'}", no puede pasar a "${NOMBRE_ENTREGA[nueva]}"` };
      }
      if (!reenvio) {
        const campoFecha = nueva === 'listo_retiro' ? 'fecha_listo_retiro' : 'fecha_entregado';
        const cambios: Record<string, unknown> = { estado_entrega: nueva };
        if (!pedido[campoFecha]) cambios[campoFecha] = new Date().toISOString();
        let q = sb.from('ev_pedidos').update(cambios).eq('id', id).eq('estado', 'pagado');
        q = pedido.estado_entrega ? q.eq('estado_entrega', pedido.estado_entrega) : q.is('estado_entrega', null);
        const { data: cambiados, error } = await q.select('id');
        if (error) throw error;
        if (!cambiados?.length) return { id, ok: true, omitido: true }; // otro clic ya lo cambió
      }
      let mail: boolean | undefined;
      if (nueva === 'listo_retiro') {
        if (!avisoMarcado) await esperaPersistente(claveAviso, 1, VENTANA_AVISO_RETIRO_SEG); // 05/10: se cuenta el envío
        const { subject, html } = correoListoRetiro(datosCorreo(pedido, base), await lugarRetiro(pedido.evento_id));
        mail = await enviarCorreo({ to: pedido.comprador_email, subject, html });
        if (!mail && !reenvio) {
          // Auditoría 03/10 noche: si el mail no salió, el pedido vuelve a como estaba (sin avisar), así
          // el próximo "Avisar listo para retirar" (también en bloque) lo vuelve a intentar.
          const { error: errVuelta } = await sb.from('ev_pedidos')
            .update({ estado_entrega: pedido.estado_entrega ?? null, fecha_listo_retiro: pedido.fecha_listo_retiro ?? null })
            .eq('id', id).eq('estado', 'pagado').eq('estado_entrega', 'listo_retiro');
          if (errVuelta) console.error('[eventos] No se pudo volver atrás el aviso de retiro de', pedido.numero, errVuelta);
          return { id, numero: pedido.numero, ok: true, mail, sinAvisar: !errVuelta };
        }
      }
      return { id, numero: pedido.numero, ok: true, mail };
    });
    // Auditoría 03/10 noche: números de pedido cuyo mail no salió (el panel los muestra).
    const mailFallidos = resultados.filter((r) => r.mail === false).map((r) => r.numero || r.id);
    return res.json({ success: true, resultados, mailFallidos });
  } catch (err) {
    return errorInterno(res, 'actualizar la entrega', err);
  }
});

// Planilla de entregas (Excel): todos los pedidos pagados del evento, ordenados por chico/a.
app.get('/api/eventos/admin/eventos/:id/planilla-entregas', requireAdmin, async (req, res) => {
  if (!esUuid(req.params.id)) return res.status(400).json({ success: false, error: 'Evento inválido' });
  const sb = conSupabase(res);
  if (!sb) return;
  try {
    const { data: ev, error: errEv } = await sb.from('ev_eventos').select('nombre, codigo').eq('id', req.params.id).maybeSingle();
    if (errEv) throw errEv;
    if (!ev) return res.status(404).json({ success: false, error: 'No se encontró el evento' });
    const data = await todasLasFilas((d, h) =>
      sb
        .from('ev_pedidos')
        .select('numero, comprador_nombre, comprador_whatsapp, comprador_email, nino_nombre, nino_curso, total, medio_pago, estado_entrega, fecha_pago, ev_lotes(numero), ev_items_pedido(formato, cantidad)')
        .eq('evento_id', req.params.id)
        .eq('estado', 'pagado')
        .order('id')
        .range(d, h));
    const filas = data.slice().sort((a: any, b: any) => String(a.nino_nombre).localeCompare(String(b.nino_nombre), 'es'));
    const libro = await nuevoLibro();
    const hoja = libro.addWorksheet('Entregas', { pageSetup: { orientation: 'landscape', fitToPage: true, fitToWidth: 1, fitToHeight: 0 } });
    hoja.addRow([`Entregas — ${ev.nombre}`]).font = { bold: true, size: 14 };
    hoja.addRow([`Generada el ${fechaHoraArgentina(new Date())} · ${filas.length} pedidos pagados`]).font = { color: { argb: 'FF64748B' } };
    hoja.addRow([]);
    hoja.columns = [
      { key: 'nino', width: 26 }, { key: 'curso', width: 10 }, { key: 'pedido', width: 13 }, { key: 'comprador', width: 24 },
      { key: 'whatsapp', width: 16 }, { key: 'email', width: 28 }, { key: 'c15', width: 8 }, { key: 'c20', width: 8 },
      { key: 'dig', width: 9 }, { key: 'total', width: 11 }, { key: 'pago', width: 14 }, { key: 'entrega', width: 18 },
      { key: 'lote', width: 7 }, { key: 'firma', width: 26 },
    ];
    hoja.addRow(['Para', 'Curso', 'Pedido', 'Comprador', 'WhatsApp', 'Email', '15x21', '20x30', 'Digitales', 'Total', 'Pago', 'Entrega', 'Lote', 'Retiró (firma / fecha)']);
    for (const p of filas as any[]) {
      const cuenta = { digital: 0, '15x21': 0, '20x30': 0 } as Record<string, number>;
      for (const it of p.ev_items_pedido || []) cuenta[it.formato] += it.formato === 'digital' ? 1 : it.cantidad;
      const soloDigital = !cuenta['15x21'] && !cuenta['20x30'];
      hoja.addRow([
        p.nino_nombre, p.nino_curso || '', p.numero, p.comprador_nombre, p.comprador_whatsapp, p.comprador_email,
        cuenta['15x21'] || '', cuenta['20x30'] || '', cuenta.digital || '', p.total,
        MEDIO(p.medio_pago),
        soloDigital ? 'Sólo digital (por mail)' : NOMBRE_ENTREGA[p.estado_entrega] || 'Pagado (falta lab.)',
        p.ev_lotes?.numero ?? '', '',
      ]);
    }
    hoja.getColumn('total').numFmt = '"$"#,##0';
    estilarHoja(hoja, 4);
    return await enviarXlsx(res, libro, `entregas-${ev.codigo}.xlsx`);
  } catch (err) {
    return errorInterno(res, 'armar la planilla', err);
  }
});

// Armar un lote para el laboratorio con todos los pedidos pagados con impresas que todavía no
// están en ningún lote. Esos pedidos pasan a "En laboratorio".
app.post('/api/eventos/admin/eventos/:id/lotes', requireAdmin, async (req, res) => {
  const eventoId = req.params.id;
  if (!esUuid(eventoId)) return res.status(400).json({ success: false, error: 'Evento inválido' });
  const sb = conSupabase(res);
  if (!sb) return;
  try {
    const data = await todasLasFilas((d, h) =>
      sb.from('ev_pedidos').select(SELECT_PEDIDO_LAB).eq('evento_id', eventoId).eq('estado', 'pagado').is('lote_id', null).order('id').range(d, h));
    // Auditoría 02/10: también entran los que quedaron "En laboratorio" sin lote (botón manual viejo).
    const candidatos = data.filter((p: any) => tieneImpresas(p) && (!p.estado_entrega || p.estado_entrega === 'en_laboratorio'));
    if (candidatos.length === 0) return res.status(409).json({ success: false, error: 'No hay pedidos pagados con copias impresas pendientes de mandar al laboratorio.' });
    const { data: ultimo } = await sb.from('ev_lotes').select('numero').eq('evento_id', eventoId).order('numero', { ascending: false }).limit(1);
    let lote: any = null;
    for (let intento = 0; intento < 3 && !lote; intento++) {
      const { data: nuevo, error: errLote } = await sb
        .from('ev_lotes')
        .insert({ evento_id: eventoId, numero: (ultimo?.[0]?.numero || 0) + 1 + intento, estado: 'armado' })
        .select()
        .single();
      if (errLote && (errLote as any).code !== '23505') throw errLote;
      lote = nuevo;
    }
    if (!lote) throw new Error('No se pudo numerar el lote');
    const ahora = new Date().toISOString();
    // De a 100 ids (una lista enorme no entra en la URL). "is lote_id null": si dos clics arman lotes
    // a la vez, cada pedido queda en uno solo.
    let movidos = 0;
    const ids = candidatos.map((p: any) => p.id);
    try {
      for (let i = 0; i < ids.length; i += 100) {
        const { data: tanda, error: errUpd } = await sb
          .from('ev_pedidos')
          .update({ lote_id: lote.id, estado_entrega: 'en_laboratorio', fecha_en_laboratorio: ahora })
          .in('id', ids.slice(i, i + 100))
          .is('lote_id', null)
          .eq('estado', 'pagado')
          .select('id');
        if (errUpd) throw errUpd;
        movidos += tanda?.length || 0;
      }
    } catch (errMover) {
      // 05/10: si falla el UPDATE (base caída a mitad de camino), antes quedaba un lote vacío o a medias a
      // la vista del laboratorio. Se vuelven atrás los pedidos que alcanzaron a entrar y se borra el lote
      // (best-effort); el error se relanza para que el panel lo informe.
      try {
        if (movidos > 0) {
          await sb.from('ev_pedidos').update({ lote_id: null, estado_entrega: null, fecha_en_laboratorio: null }).eq('lote_id', lote.id);
        }
        await sb.from('ev_lotes').delete().eq('id', lote.id);
      } catch (errLimpieza) {
        console.error('[eventos] No se pudo deshacer el lote', lote.id, 'tras fallar el UPDATE:', errLimpieza);
      }
      throw errMover;
    }
    if (movidos === 0) {
      // Otro clic se llevó todos los pedidos: no se deja un lote vacío a la vista del laboratorio.
      await sb.from('ev_lotes').delete().eq('id', lote.id);
      return res.status(409).json({ success: false, error: 'Esos pedidos ya se mandaron en otro lote. Actualizá la lista.' });
    }
    return res.json({ success: true, lote, pedidos: movidos });
  } catch (err) {
    return errorInterno(res, 'armar el lote', err);
  }
});

async function resumenLotes(sb: SupabaseClient, eventoId?: string) {
  // Auditoría 02/10: todos los lotes sin terminar (antes se cortaba en los últimos 200 y un lote
  // viejo pendiente desaparecía) + los últimos 100 terminados para el archivo.
  const campos = 'id, numero, estado, creado_en, fecha_descargado, fecha_terminado, evento_id, ev_eventos(nombre, codigo)';
  let qAbiertos = sb.from('ev_lotes').select(campos).neq('estado', 'terminado').order('creado_en', { ascending: false });
  let qTerminados = sb.from('ev_lotes').select(campos).eq('estado', 'terminado').order('creado_en', { ascending: false }).limit(100);
  if (eventoId) {
    qAbiertos = qAbiertos.eq('evento_id', eventoId);
    qTerminados = qTerminados.eq('evento_id', eventoId);
  }
  const [abiertos, terminados] = await Promise.all([qAbiertos, qTerminados]);
  if (abiertos.error) throw abiertos.error;
  if (terminados.error) throw terminados.error;
  const lotes = [...(abiertos.data || []), ...(terminados.data || [])];
  if (lotes.length === 0) return [];
  const pedidos: any[] = [];
  const idsLotes = lotes.map((l: any) => l.id);
  for (let i = 0; i < idsLotes.length; i += 50) {
    const parte = idsLotes.slice(i, i + 50);
    pedidos.push(...(await todasLasFilas((d, h) =>
      sb.from('ev_pedidos').select('id, numero, nino_nombre, lote_id, estado, estado_entrega, ev_items_pedido(formato, cantidad)').in('lote_id', parte).order('id').range(d, h))));
  }
  return lotes.map((l: any) => {
    const delLoteTodos = pedidos.filter((p: any) => p.lote_id === l.id);
    // Un pedido devuelto/anulado después de armar el lote no se imprime: no cuenta (y se informa aparte).
    const delLote = delLoteTodos.filter((p: any) => p.estado === 'pagado');
    const copias = { '15x21': 0, '20x30': 0 } as Record<string, number>;
    for (const p of delLote) for (const it of p.ev_items_pedido || []) if (it.formato !== 'digital') copias[it.formato] += it.cantidad;
    return {
      id: l.id, numero: l.numero, estado: l.estado, creado_en: l.creado_en, fecha_descargado: l.fecha_descargado, fecha_terminado: l.fecha_terminado,
      evento: l.ev_eventos, evento_id: l.evento_id,
      pedidos: delLote.length,
      anulados: delLoteTodos.length - delLote.length,
      // 14/10/2026: cuáles (número y chico/a), para que el laboratorio no imprima uno que ya bajó en el ZIP.
      anuladosDetalle: delLoteTodos.filter((p: any) => p.estado !== 'pagado').map((p: any) => `${p.numero} (${p.nino_nombre})`),
      pedidoIds: delLote.map((p: any) => p.id),
      listos: delLote.filter((p: any) => p.estado_entrega === 'listo_retiro' || p.estado_entrega === 'entregado').length,
      copias15x21: copias['15x21'],
      copias20x30: copias['20x30'],
    };
  });
}

app.get('/api/eventos/admin/eventos/:id/lotes', requireAdmin, async (req, res) => {
  if (!esUuid(req.params.id)) return res.status(400).json({ success: false, error: 'Evento inválido' });
  const sb = conSupabase(res);
  if (!sb) return;
  try {
    return res.json({ success: true, lotes: await resumenLotes(sb, req.params.id) });
  } catch (err) {
    return errorInterno(res, 'listar los lotes', err);
  }
});

// ---------------- Laboratorio (LAB_PIN o admin) ----------------
app.get('/api/eventos/lab/lotes', requireLab, async (_req, res) => {
  const sb = conSupabase(res);
  if (!sb) return;
  try {
    const lotes = (await resumenLotes(sb)).map(({ pedidoIds, ...resto }) => { void pedidoIds; return resto; });
    return res.json({ success: true, lotes });
  } catch (err) {
    return errorInterno(res, 'listar los lotes', err);
  }
});

async function archivosDeLoteId(sb: SupabaseClient, loteId: string): Promise<{ lote: any; archivos: ArchivoLote[] } | null> {
  const { data: lote, error } = await sb.from('ev_lotes').select('id, numero, estado, ev_eventos(nombre, codigo)').eq('id', loteId).maybeSingle();
  if (error) throw error;
  if (!lote) return null;
  const pedidos = await todasLasFilas((d, h) =>
    sb.from('ev_pedidos').select(SELECT_PEDIDO_LAB).eq('lote_id', loteId).eq('estado', 'pagado').order('id').range(d, h));
  const ordenados = pedidos.slice().sort((a: any, b: any) => String(a.nino_nombre).localeCompare(String(b.nino_nombre), 'es'));
  return { lote, archivos: archivosDelLote(ordenados.map(aPedidoLote)) };
}

// Lista de archivos del lote con links firmados (2 h): la página del laboratorio arma el ZIP en
// el navegador (así los originales no pasan por la función de Vercel).
app.get('/api/eventos/lab/lotes/:id/manifiesto', requireLab, async (req, res) => {
  if (!esUuid(req.params.id)) return res.status(400).json({ success: false, error: 'Lote inválido' });
  const sb = conSupabase(res);
  if (!sb) return;
  try {
    const r = await archivosDeLoteId(sb, req.params.id);
    if (!r) return res.status(404).json({ success: false, error: 'No se encontró el lote' });
    const rutas = [...new Set(r.archivos.map((a) => a.storage_path_hd).filter(Boolean))]; await asegurarOriginales(sb, rutas, 45000, avisarOriginalesPerdidos); // 17/10: los que estén sólo en Drive
    const urlPorRuta = new Map<string, string>();
    for (let i = 0; i < rutas.length; i += 100) {
      const { data, error } = await sb.storage.from(BUCKET_HD).createSignedUrls(rutas.slice(i, i + 100), 2 * 3600);
      if (error) throw error;
      for (const f of data || []) if (f.path && f.signedUrl) urlPorRuta.set(f.path, f.signedUrl);
    }
    return res.json({
      success: true,
      lote: { numero: r.lote.numero, evento: r.lote.ev_eventos },
      archivos: r.archivos.map((a) => ({ carpeta: a.carpeta, nombre: a.nombre, url: urlPorRuta.get(a.storage_path_hd) || null })),
    });
  } catch (err) {
    return errorInterno(res, 'preparar los archivos del lote', err);
  }
});

// Excel del lote para el laboratorio: una fila por foto y tamaño (sin datos de contacto).
app.get('/api/eventos/lab/lotes/:id/excel', requireLab, async (req, res) => {
  if (!esUuid(req.params.id)) return res.status(400).json({ success: false, error: 'Lote inválido' });
  const sb = conSupabase(res);
  if (!sb) return;
  try {
    const r = await archivosDeLoteId(sb, req.params.id);
    if (!r) return res.status(404).json({ success: false, error: 'No se encontró el lote' });
    const filas = new Map<string, { carpeta: string; numero: string; nino: string; curso: string | null; foto: string; copias: number; archivos: string[] }>();
    for (const a of r.archivos) {
      const clave = `${a.carpeta}|${a.numero}|${a.foto}`;
      const f = filas.get(clave) || { carpeta: a.carpeta, numero: a.numero, nino: a.nino, curso: a.curso, foto: a.foto, copias: a.copias, archivos: [] };
      f.archivos.push(a.nombre);
      filas.set(clave, f);
    }
    const total15 = r.archivos.filter((a) => a.carpeta === '15x21').length;
    const total20 = r.archivos.filter((a) => a.carpeta === '20x30').length;
    const libro = await nuevoLibro();
    const hoja = libro.addWorksheet(`Lote ${r.lote.numero}`, { pageSetup: { orientation: 'landscape', fitToPage: true, fitToWidth: 1, fitToHeight: 0 } });
    hoja.addRow([`Lote ${r.lote.numero} — ${r.lote.ev_eventos?.nombre || ''}`]).font = { bold: true, size: 14 };
    hoja.addRow([`15x21: ${total15} copias · 20x30: ${total20} copias · Generado el ${fechaHoraArgentina(new Date())}`]).font = { bold: true, color: { argb: 'FF92400E' } };
    hoja.addRow([]);
    hoja.columns = [
      { key: 'tam', width: 9 }, { key: 'copias', width: 8 }, { key: 'nino', width: 28 }, { key: 'curso', width: 10 },
      { key: 'pedido', width: 13 }, { key: 'foto', width: 22 }, { key: 'archivos', width: 60 }, { key: 'ok', width: 8 },
    ];
    hoja.addRow(['Tamaño', 'Copias', 'Para', 'Curso', 'Pedido', 'Foto original', 'Archivo(s) en el ZIP', 'Hecho']);
    for (const f of [...filas.values()].sort((a, b) => a.carpeta.localeCompare(b.carpeta) || a.nino.localeCompare(b.nino, 'es'))) {
      hoja.addRow([f.carpeta, f.copias, f.nino, f.curso || '', f.numero, f.foto, f.archivos.join('\n'), '☐']);
    }
    estilarHoja(hoja, 4);
    return await enviarXlsx(res, libro, `lote-${r.lote.ev_eventos?.codigo || 'evento'}-${r.lote.numero}.xlsx`);
  } catch (err) {
    return errorInterno(res, 'armar el Excel del lote', err);
  }
});

// El laboratorio avisa que descargó el lote o que lo terminó (a Pablo le llega un mail).
app.post('/api/eventos/lab/lotes/:id/estado', requireLab, async (req, res) => {
  if (!esUuid(req.params.id)) return res.status(400).json({ success: false, error: 'Lote inválido' });
  const paso = String(req.body?.paso || '');
  if (paso !== 'descargado' && paso !== 'terminado') return res.status(400).json({ success: false, error: 'Paso inválido' });
  const sb = conSupabase(res);
  if (!sb) return;
  try {
    const { data: lote, error } = await sb.from('ev_lotes').select('id, numero, estado, fecha_descargado, fecha_terminado, ev_eventos(nombre)').eq('id', req.params.id).maybeSingle();
    if (error) throw error;
    if (!lote) return res.status(404).json({ success: false, error: 'No se encontró el lote' });
    // Auditoría 02/10: si Pablo abre el lote con su sesión de admin, no cuenta como "lo descargó el laboratorio".
    if (paso === 'descargado' && !res.locals.esLaboratorio) return res.json({ success: true, sinCambios: true });
    if (paso === 'terminado' && lote.estado === 'armado') {
      return res.status(409).json({ success: false, error: 'Primero descarguen el lote (ZIP) y después márquenlo terminado.' });
    }
    const ahora = new Date().toISOString();
    const cambios: Record<string, unknown> = paso === 'descargado'
      ? { estado: lote.estado === 'terminado' ? 'terminado' : 'en_laboratorio', ...(lote.fecha_descargado ? {} : { fecha_descargado: ahora }) }
      : { estado: 'terminado', ...(lote.fecha_terminado ? {} : { fecha_terminado: ahora }) };
    // 14/10/2026: «terminado» condicional (fecha_terminado vacía): si dos del laboratorio lo marcan a la vez, el mail sale una vez.
    const primeraVezTerminado = paso === 'terminado' && !lote.fecha_terminado;
    let q = sb.from('ev_lotes').update(cambios).eq('id', lote.id);
    if (primeraVezTerminado) q = q.is('fecha_terminado', null);
    const { data: cambiado, error: errUpd } = await q.select('id');
    if (errUpd) throw errUpd;
    if (primeraVezTerminado && cambiado?.length) {
      const nombreEvento = escapeHtml((lote as any).ev_eventos?.nombre || '');
      await avisarAdmin(`🖨️ Lote ${lote.numero} terminado — ${(lote as any).ev_eventos?.nombre || 'evento'}`,
        `<p>El laboratorio marcó como <strong>terminado</strong> el lote ${lote.numero} de ${nombreEvento}.</p><p>Cuando tengas las copias, avisá a las familias desde el panel de eventos → Lotes → <strong>Avisar "listo para retirar"</strong>.</p>`);
    }
    return res.json({ success: true });
  } catch (err) {
    return errorInterno(res, 'actualizar el lote', err);
  }
});

// ---------------- QR del evento (lleva directo a la galería) ----------------
app.get('/api/eventos/admin/eventos/:id/qr', requireAdmin, async (req, res) => {
  if (!esUuid(req.params.id)) return res.status(400).json({ success: false, error: 'Evento inválido' });
  const sb = conSupabase(res);
  if (!sb) return;
  try {
    const { data: ev, error } = await sb.from('ev_eventos').select('codigo').eq('id', req.params.id).maybeSingle();
    if (error) throw error;
    if (!ev) return res.status(404).json({ success: false, error: 'No se encontró el evento' });
    const url = `${baseUrl(req)}/eventos/${encodeURIComponent(ev.codigo)}`;
    const png = await QRCode.toBuffer(url, { type: 'png', width: 1200, margin: 2, errorCorrectionLevel: 'M' });
    res.setHeader('Content-Type', 'image/png');
    res.setHeader('Content-Disposition', `attachment; filename="QR-${ev.codigo}.png"`);
    res.setHeader('Cache-Control', 'no-store');
    res.setHeader('X-Url-Qr', url);
    return res.send(png);
  } catch (err) {
    return errorInterno(res, 'generar el QR', err);
  }
});

// ---------------- "Avisame cuando estén las fotos" ----------------
app.post('/api/eventos/publico/:codigo/avisame', limitarPersistente('avisame', 10, 10 * 60 * 1000), async (req, res) => {
  const codigo = normalizarCodigo(req.params.codigo);
  const email = String(req.body?.email ?? '').trim().toLowerCase().slice(0, 160);
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) return res.status(400).json({ success: false, error: 'Revisá el email.' });
  const sb = conSupabase(res);
  if (!sb) return;
  try {
    const ev = await buscarEventoPorCodigo(sb, codigo, 'id, fecha_limite'); // 14/10/2026: también códigos anteriores
    // Auditoría 02/10: la misma respuesta exista o no el evento (no sirve para adivinar códigos).
    if (!ev || eventoCerrado(ev.fecha_limite)) return res.json({ success: true });
    const { error: errIns } = await sb.from('ev_avisos').upsert({ evento_id: ev.id, email }, { onConflict: 'evento_id,email', ignoreDuplicates: true });
    if (errIns) throw errIns;
    return res.json({ success: true });
  } catch (err) {
    return errorInterno(res, 'guardar tu email', err);
  }
});

// ---------------- Foto de hermanos (08/10): evento «Fotos de Hermanos juntos» (BROTHERS2026-D3EB) ----------------
// Antes de avisar se suman al «Avisame» las inscripciones ACEPTADAS que confirmaron SÍ; las que dijeron NO se sacan
// si no se les avisó. Auditoría 11/10: sólo por código BROTHERS… o nombre específico (antes bastaba «herman»).
// 14/10/2026: las funciones puras pasaron a eventos/fotoHermanos.ts (techo de líneas); se reexportan.
export { emailsFotoHermanos, esEventoFotoHermanos };

/** Suma al «Avisame» del evento de hermanos a las familias que la quieren. Nunca frena los avisos. */
async function sincronizarAvisosFotoHermanos(sb: SupabaseClient, eventoId: string): Promise<void> {
  try {
    const filas = await todasLasFilas<any>((desde, hasta) =>
      sb
        .from('inscripciones')
        .select('estado, hermanos, email, foto_hermanos_email, solicita_foto_hermanos, foto_hermanos_confirmada_at')
        .not('foto_hermanos_confirmada_at', 'is', null)
        .order('id', { ascending: true })
        .range(desde, hasta)
    );
    const { si, no } = emailsFotoHermanos(filas);
    for (let i = 0; i < si.length; i += 500) {
      const { error } = await sb
        .from('ev_avisos')
        .upsert(si.slice(i, i + 500).map((email) => ({ evento_id: eventoId, email })), { onConflict: 'evento_id,email', ignoreDuplicates: true });
      if (error) throw error;
    }
    for (let i = 0; i < no.length; i += 200) {
      const { error } = await sb.from('ev_avisos').delete().eq('evento_id', eventoId).is('avisado_en', null).in('email', no.slice(i, i + 200));
      if (error) throw error;
    }
  } catch (err) {
    console.error('[eventos] No se pudo sumar al «Avisame» a las familias de la foto de hermanos:', err);
  }
}

/**
 * Si el evento ya está publicado y tiene fotos, avisa por mail a los anotados (una sola vez).
 * Auditoría 03/10 noche: con presupuesto de tiempo (~20 s) para no pasar los 60 s de Vercel dentro del
 * guardado del evento; devuelve cuántos se avisaron y cuántos quedan (el panel sigue en tandas).
 */
async function avisarAnotados(sb: SupabaseClient, eventoId: string, base: string, presupuestoMs = 20000): Promise<{ enviados: number; restantes: number }> {
  const inicio = Date.now();
  const nada = { enviados: 0, restantes: 0 };
  const { data: ev } = await sb.from('ev_eventos').select('codigo, nombre, publicado').eq('id', eventoId).maybeSingle();
  if (!ev?.publicado) return nada;
  const { count } = await sb.from('ev_fotos').select('id', { count: 'exact', head: true }).eq('evento_id', eventoId);
  if (!count) return nada;
  if (esEventoFotoHermanos(ev.nombre, ev.codigo)) await sincronizarAvisosFotoHermanos(sb, eventoId);
  const { data: pendientes, error } = await sb.from('ev_avisos').select('id, email').eq('evento_id', eventoId).is('avisado_en', null).limit(150);
  if (error || !pendientes?.length) return nada;
  const { subject, html } = correoFotosOnline(ev.nombre, `${base}/eventos/${encodeURIComponent(ev.codigo)}`, ev.codigo);
  let enviados = 0;
  await enParalelo(pendientes, 2, async (a: any) => {
    if (Date.now() - inicio > presupuestoMs) return; // se acabó el tiempo: queda para la próxima tanda
    // Se marca antes de mandar: si dos guardados coinciden, nadie recibe el aviso dos veces.
    const { data: marcado } = await sb.from('ev_avisos').update({ avisado_en: new Date().toISOString() }).eq('id', a.id).is('avisado_en', null).select('id');
    if (!marcado?.length) return;
    if (await enviarCorreo({ to: a.email, subject, html })) enviados++;
    else await sb.from('ev_avisos').update({ avisado_en: null }).eq('id', a.id);
  });
  const { count: quedan } = await sb.from('ev_avisos').select('id', { count: 'exact', head: true }).eq('evento_id', eventoId).is('avisado_en', null);
  return { enviados, restantes: quedan || 0 };
}

// ---------------- Suscriptores (Ley 25.326): casilla tildada + pedido pagado; una baja nunca se reactiva ----------------
async function registrarSuscriptor(sb: SupabaseClient, email: string, nombre: string, origen: string): Promise<void> {
  try {
    const { error } = await sb.from('ev_suscriptores').upsert(
      { email: String(email || '').trim().toLowerCase(), nombre: String(nombre || '').slice(0, 120), origen: origen.slice(0, 160), acepto_en: new Date().toISOString() },
      { onConflict: 'email', ignoreDuplicates: true }
    );
    if (error) console.error('[eventos] No se pudo guardar el suscriptor:', error);
  } catch (err) {
    console.error('[eventos] No se pudo guardar el suscriptor:', err);
  }
}

export function llaveBaja(email: string, secreto: string): string {
  return crypto.createHmac('sha256', secreto).update(`baja-novedades:${email.trim().toLowerCase()}`).digest('base64url').slice(0, 24);
}
function linkBaja(base: string, email: string): string | null {
  const secreto = secretoAcceso();
  if (!secreto) return null;
  return `${base}/api/eventos/baja?e=${encodeURIComponent(email)}&t=${llaveBaja(email, secreto)}`;
}

function paginaSimple(titulo: string, texto: string, extraHtml = ''): string {
  return `<!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex"><title>${escapeHtml(titulo)}</title></head>
<body style="margin:0;background:#f8fafc;font-family:system-ui,-apple-system,Segoe UI,Roboto,sans-serif;color:#0f172a">
<div style="background:#0f172a;color:#fff;padding:14px 18px;font-weight:700">Retrato Escolar <span style="color:#f59e0b">· Fotos de eventos</span></div>
<div style="max-width:460px;margin:40px auto;background:#fff;border:1px solid #e2e8f0;border-radius:16px;padding:24px;text-align:center">
<h1 style="font-size:1.3rem;margin:0 0 10px">${escapeHtml(titulo)}</h1><p style="color:#475569;line-height:1.5">${texto}</p>${extraHtml}</div></body></html>`;
}

// Link de baja (sin login). 03/10: el GET sólo muestra un botón; la baja es POST a la misma URL (los escáneres abren GET).
function bajaValida(req: Request): string | null {
  const email = String(req.query.e || '').trim().toLowerCase();
  const secreto = secretoAcceso();
  if (!email || !secreto || typeof req.query.t !== 'string' || !compararTimingSafe(req.query.t, llaveBaja(email, secreto))) return null;
  return email;
}
app.get('/api/eventos/baja', limitar('ev-baja', 60, 10 * 60 * 1000), (req, res) => {
  res.setHeader('Content-Type', 'text/html; charset=utf-8');
  res.setHeader('Cache-Control', 'no-store');
  const email = bajaValida(req);
  if (!email) {
    return res.status(400).send(paginaSimple('Link inválido', 'El link de baja no es válido. Respondé cualquiera de nuestros correos y te damos de baja a mano.'));
  }
  const accion = `/api/eventos/baja?e=${encodeURIComponent(email)}&t=${encodeURIComponent(String(req.query.t))}`;
  return res.send(paginaSimple('¿Querés darte de baja?',
    `Vas a dejar de recibir novedades y promociones en <strong>${escapeHtml(email)}</strong>. Los avisos de tus pedidos (pagos, descargas, retiro) te siguen llegando igual.`,
    `<form method="post" action="${escapeHtml(accion)}" style="margin:18px 0 0"><button type="submit" style="background:#0f172a;color:#fff;border:0;border-radius:10px;padding:12px 20px;font-size:1rem;font-weight:700;cursor:pointer">Sí, darme de baja</button></form>`));
});
app.post('/api/eventos/baja', limitar('ev-baja-post', 30, 10 * 60 * 1000), async (req, res) => {
  res.setHeader('Content-Type', 'text/html; charset=utf-8');
  res.setHeader('Cache-Control', 'no-store');
  const email = bajaValida(req);
  if (!email) {
    return res.status(400).send(paginaSimple('Link inválido', 'El link de baja no es válido. Respondé cualquiera de nuestros correos y te damos de baja a mano.'));
  }
  const sb = getSupabase();
  if (!sb) return res.status(500).send(paginaSimple('No pudimos procesarlo', 'Probá de nuevo en unos minutos.'));
  const { error } = await sb.from('ev_suscriptores').update({ baja_en: new Date().toISOString() }).eq('email', email).is('baja_en', null);
  if (error) return res.status(500).send(paginaSimple('No pudimos procesarlo', 'Probá de nuevo en unos minutos.'));
  return res.send(paginaSimple('Listo, te diste de baja', `No vas a recibir más novedades ni promociones en <strong>${escapeHtml(email)}</strong>. Los avisos de tus pedidos (pagos, descargas, retiro) te siguen llegando normalmente.`));
});

async function listarSuscriptores(sb: SupabaseClient): Promise<any[]> {
  return todasLasFilas<any>((d, h) => sb.from('ev_suscriptores').select('email, nombre, origen, acepto_en, baja_en').order('acepto_en', { ascending: false }).range(d, h));
}

app.get('/api/eventos/admin/suscriptores', requireAdmin, async (req, res) => {
  const sb = conSupabase(res);
  if (!sb) return;
  try {
    const filas = await listarSuscriptores(sb);
    return res.json({ success: true, activos: filas.filter((f) => !f.baja_en).length, bajas: filas.filter((f) => f.baja_en).length });
  } catch (err) {
    return errorInterno(res, 'contar los suscriptores', err);
  }
});

// Excel con los suscriptores ACTIVOS y su link de baja (para pegar en cada promoción).
app.get('/api/eventos/admin/suscriptores.xlsx', requireAdmin, async (req, res) => {
  const sb = conSupabase(res);
  if (!sb) return;
  try {
    const base = baseUrl(req);
    const filas = (await listarSuscriptores(sb)).filter((f) => !f.baja_en);
    const libro = await nuevoLibro();
    const hoja = libro.addWorksheet('Suscriptores');
    hoja.addRow(['Suscriptores a novedades y promociones — Retrato Escolar']).font = { bold: true, size: 14 };
    hoja.addRow([`${filas.length} activos · Generado el ${fechaHoraArgentina(new Date())} · Usar sólo para novedades/promociones e incluir siempre el link de baja.`]).font = { color: { argb: 'FF64748B' } };
    hoja.addRow([]);
    hoja.columns = [{ key: 'email', width: 34 }, { key: 'nombre', width: 26 }, { key: 'origen', width: 40 }, { key: 'fecha', width: 18 }, { key: 'baja', width: 70 }];
    hoja.addRow(['Email', 'Nombre', 'Se suscribió en', 'Fecha', 'Link de baja (incluirlo en cada mail)']);
    for (const f of filas) {
      hoja.addRow([f.email, f.nombre || '', f.origen || '', fechaHoraArgentina(f.acepto_en), linkBaja(base, f.email) || '']);
    }
    estilarHoja(hoja, 4);
    return await enviarXlsx(res, libro, 'suscriptores-retrato-escolar.xlsx');
  } catch (err) {
    return errorInterno(res, 'armar la lista de suscriptores', err);
  }
});

registrarRutasEdicion(app, { requireAdmin, requireLab, conSupabase, errorInterno }); registrarRutasDrive(app, { requireAdmin, conSupabase, errorInterno }); registrarRutaDescuento(app, { limitarPersistente, conSupabase, errorInterno }); // 14/10 edicionEvento.ts · 17/10 originalesDrive.ts · 27/10 descuentos.ts

app.use('/api/eventos', (_req, res) => {
  res.status(404).json({ success: false, error: 'Ruta de eventos inexistente' });
});

if (process.env.EVENTOS_DEV_PORT) {
  const puerto = Number(process.env.EVENTOS_DEV_PORT);
  app.listen(puerto, () => console.log(`[eventos] escuchando en http://localhost:${puerto}`));
}

export default app;
