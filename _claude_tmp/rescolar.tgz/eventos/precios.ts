// Cálculo del pedido de un evento — funciones puras (sin base ni red), así se pueden probar.
// El monto SIEMPRE lo calcula el servidor con los precios guardados del evento; lo que manda el
// navegador sólo dice qué fotos, qué formato y cuántas copias.

export type FormatoEvento = 'digital' | '15x21' | '20x30';
export const FORMATOS: FormatoEvento[] = ['digital', '15x21', '20x30'];
export const MAX_COPIAS_POR_FOTO = 50;
export const MAX_LINEAS_POR_PEDIDO = 200;

export interface PreciosEvento {
  precio_digital: number;
  precio_15x21: number;
  precio_20x30: number;
  impresa_incluye_digital: boolean;
}

export interface ItemCalculado {
  foto_id: string;
  formato: FormatoEvento;
  cantidad: number;
  precio_unitario: number;
  subtotal: number;
  incluye_digital: boolean;
}

export function precioDeFormato(evento: PreciosEvento, formato: FormatoEvento): number {
  const p = formato === 'digital' ? evento.precio_digital : formato === '15x21' ? evento.precio_15x21 : evento.precio_20x30;
  return Math.max(0, Math.round(Number(p) || 0));
}

/** Un formato con precio 0 no se ofrece en ese evento. */
export function formatoDisponible(evento: PreciosEvento, formato: FormatoEvento): boolean {
  return precioDeFormato(evento, formato) > 0;
}

/**
 * Valida la selección del navegador y devuelve las líneas con precio.
 * - Junta líneas repetidas (misma foto y formato).
 * - El digital es siempre 1 por foto.
 * - Si la impresa incluye el digital y la foto ya tiene una copia impresa, se saca el digital
 *   (no se cobra dos veces la misma foto digital).
 */
export function calcularPedido(
  entrada: unknown,
  evento: PreciosEvento,
  fotosDelEvento: Set<string>
): { items: ItemCalculado[]; total: number; error?: undefined } | { error: string; items?: undefined; total?: undefined } {
  if (!Array.isArray(entrada) || entrada.length === 0) return { error: 'Elegí al menos una foto.' };
  if (entrada.length > MAX_LINEAS_POR_PEDIDO) return { error: 'El pedido tiene demasiadas líneas.' };

  const porClave = new Map<string, { foto_id: string; formato: FormatoEvento; cantidad: number }>();
  for (const bruto of entrada) {
    const fotoId = String((bruto as any)?.fotoId ?? '');
    const formato = String((bruto as any)?.formato ?? '') as FormatoEvento;
    const cantidad = Math.floor(Number((bruto as any)?.cantidad ?? 1));
    if (!fotosDelEvento.has(fotoId)) return { error: 'Alguna foto elegida ya no está en la galería. Recargá la página.' };
    if (!FORMATOS.includes(formato)) return { error: 'Formato de foto inválido.' };
    if (!formatoDisponible(evento, formato)) return { error: `El formato ${formato === 'digital' ? 'digital' : formato} no está disponible en este evento.` };
    if (!Number.isFinite(cantidad) || cantidad < 1 || cantidad > MAX_COPIAS_POR_FOTO) return { error: `La cantidad tiene que ser entre 1 y ${MAX_COPIAS_POR_FOTO}.` };
    const clave = `${fotoId}|${formato}`;
    const previo = porClave.get(clave);
    if (previo) previo.cantidad = Math.min(MAX_COPIAS_POR_FOTO, previo.cantidad + cantidad);
    else porClave.set(clave, { foto_id: fotoId, formato, cantidad });
  }

  const conImpresa = new Set(
    [...porClave.values()].filter((l) => l.formato !== 'digital').map((l) => l.foto_id)
  );
  const items: ItemCalculado[] = [];
  for (const linea of porClave.values()) {
    if (linea.formato === 'digital' && evento.impresa_incluye_digital && conImpresa.has(linea.foto_id)) continue;
    const cantidad = linea.formato === 'digital' ? 1 : linea.cantidad;
    const precio = precioDeFormato(evento, linea.formato);
    items.push({
      foto_id: linea.foto_id,
      formato: linea.formato,
      cantidad,
      precio_unitario: precio,
      subtotal: precio * cantidad,
      // 05/10: la impresa sólo "incluye el digital" si el evento vende digitales (precio > 0);
      // si no, no se entregaba la descarga HD de una foto que el evento no ofrece.
      incluye_digital:
        linea.formato === 'digital' ||
        (Boolean(evento.impresa_incluye_digital) && formatoDisponible(evento, 'digital')),
    });
  }
  const total = items.reduce((acc, it) => acc + it.subtotal, 0);
  if (items.length === 0 || total <= 0) return { error: 'Elegí al menos una foto.' };
  return { items, total };
}

/** Fin del día de la fecha límite (AAAA-MM-DD) en hora de Argentina (UTC-3). */
export function eventoCerrado(fechaLimite: string | null | undefined, ahora = Date.now()): boolean {
  if (!fechaLimite || !/^\d{4}-\d{2}-\d{2}$/.test(fechaLimite)) return false;
  const finDelDia = Date.parse(`${fechaLimite}T23:59:59.999-03:00`);
  return Number.isFinite(finDelDia) && ahora > finDelDia;
}

export function validarComprador(entrada: any): { datos?: { comprador_nombre: string; comprador_whatsapp: string; comprador_email: string; nino_nombre: string; nino_curso: string | null }; error?: string } {
  const texto = (v: unknown, max: number) => String(v ?? '').replace(/\s+/g, ' ').trim().slice(0, max);
  const nombre = texto(entrada?.comprador?.nombre, 120);
  const whatsapp = texto(entrada?.comprador?.whatsapp, 40);
  const email = texto(entrada?.comprador?.email, 160).toLowerCase();
  const nino = texto(entrada?.nino?.nombre, 120);
  const curso = texto(entrada?.nino?.curso, 60);
  if (nombre.length < 3) return { error: 'Completá tu nombre y apellido.' };
  if (whatsapp.replace(/\D/g, '').length < 8) return { error: 'Completá un WhatsApp válido (con código de área).' };
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) return { error: 'Revisá el email: ahí te mandamos las fotos.' };
  if (nino.length < 3) return { error: 'Completá el nombre y apellido del chico o la chica.' };
  return { datos: { comprador_nombre: nombre, comprador_whatsapp: whatsapp, comprador_email: email, nino_nombre: nino, nino_curso: curso || null } };
}

// 11/10/2026 (Pablo): las impresas van al laboratorio en DOS envíos por evento: uno a mitad del plazo
// de pedidos y otro al cierre (fecha_limite). Lo pagado hasta el fin del día del 1.º envío entra en ese
// lote; lo pagado después, en el del cierre. Si el evento no tiene fecha_primer_envio cargada, se usa la
// mitad entre fecha_evento y fecha_limite. Sin fecha límite (o sin lugar para dos cortes) hay un solo envío.
const ISO_FECHA = /^(\d{4})-(\d{2})-(\d{2})$/;
const DIA_MS = 24 * 3600 * 1000;

function fechaUtc(iso: string | null | undefined): number {
  const m = ISO_FECHA.exec(String(iso || ''));
  return m ? Date.UTC(Number(m[1]), Number(m[2]) - 1, Number(m[3])) : NaN;
}

/** Fecha (AAAA-MM-DD) del 1.º envío al laboratorio, o null si el evento tiene un solo envío (el cierre). */
export function fechaPrimerEnvio(ev: { fecha_evento?: string | null; fecha_limite?: string | null; fecha_primer_envio?: string | null } | null | undefined): string | null {
  if (!ev) return null;
  const limite = fechaUtc(ev.fecha_limite);
  if (!Number.isFinite(limite)) return null;
  const elegida = fechaUtc(ev.fecha_primer_envio);
  if (Number.isFinite(elegida)) return elegida < limite ? String(ev.fecha_primer_envio) : null;
  const inicio = fechaUtc(ev.fecha_evento);
  if (!Number.isFinite(inicio)) return null;
  const dias = Math.round((limite - inicio) / DIA_MS);
  if (dias < 4) return null; // con menos de 4 días entre el evento y el cierre no tiene sentido partirlo
  return new Date(inicio + Math.floor(dias / 2) * DIA_MS).toISOString().slice(0, 10);
}

/** Fecha opcional del formulario del evento: undefined = no vino o es inválida, null = vacía. */
export function fechaOpcional(v: unknown): string | null | undefined {
  if (v === undefined) return undefined;
  if (v === null || v === '') return null;
  const s = String(v);
  return ISO_FECHA.test(s) ? s : undefined;
}

/**
 * Al guardar un evento: el 1.º envío tiene que ser antes del cierre (el 2.º envío ES el cierre). Si se guarda
 * sólo una de las dos fechas no se puede comparar, y fechaPrimerEnvio() ignora igual un 1.º envío inválido.
 */
export function primerEnvioDespuesDelCierre(datos: Record<string, unknown>): boolean {
  if (!datos.fecha_primer_envio) return false;
  if (datos.fecha_limite === null) return true;
  return Boolean(datos.fecha_limite) && String(datos.fecha_primer_envio) >= String(datos.fecha_limite);
}
