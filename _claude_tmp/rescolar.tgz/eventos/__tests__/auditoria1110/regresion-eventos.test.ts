// Auditoría 11/10: pruebas de REGRESIÓN de los arreglos del módulo de eventos (base, Resend y Mercado Pago falsos).
// Cada una falla con el código anterior al arreglo.
import { describe, it, expect, vi, beforeAll, afterAll, beforeEach } from 'vitest';
import http from 'http';
import crypto from 'crypto';
import type { AddressInfo } from 'net';

const h = vi.hoisted(() => {
  const estado = {
    intentos: new Map<string, number>(),
    mails: [] as Array<{ to: string[]; subject: string; html: string }>,
    tablas: {} as Record<string, any[]>,
    errorEnUpdate: null as null | string, // tabla cuyo UPDATE devuelve error
    pago: null as any, // lo que devuelve Payment.get
    prefUpdateFalla: false,
    prefUpdates: 0,
    operaciones: [] as Array<{ tabla: string; ops: any[][] }>,
  };
  const tabla = (t: string) => (estado.tablas[t] ||= []);
  function responder(t: string, ops: any[][]): any {
    estado.operaciones.push({ tabla: t, ops });
    const fuente = tabla(t);
    const filtro = (filas: any[]) => filas.filter((f) => ops.every(([op, campo, valor]) =>
      op === 'eq' ? f[campo] === valor
        : op === 'is' ? (f[campo] ?? null) === valor
          : op === 'neq' ? f[campo] !== valor
            : op === 'in' ? (valor as any[]).includes(f[campo])
              : op === 'not' ? (valor === 'is' ? f[campo] != null : true)
                : true));
    const unica = ops.some(([op]) => op === 'maybeSingle' || op === 'single');
    const inserta = ops.find(([op]) => op === 'insert' || op === 'upsert');
    if (inserta) {
      const lista = Array.isArray(inserta[1]) ? inserta[1] : [inserta[1]];
      const nuevas: any[] = [];
      for (const f of lista) {
        if (inserta[0] === 'upsert' && t === 'ev_avisos' && fuente.some((x) => x.evento_id === f.evento_id && x.email === f.email)) continue;
        const fila = { id: f.id || crypto.randomUUID(), creado_en: new Date().toISOString(), avisado_en: null, ...f };
        fuente.push(fila);
        nuevas.push(fila);
      }
      return { data: unica ? nuevas[0] : nuevas, error: null };
    }
    const filas = filtro(fuente);
    if (ops.some(([op]) => op === 'delete')) {
      for (const f of filas) fuente.splice(fuente.indexOf(f), 1);
      return { data: filas.map((f) => ({ id: f.id })), error: null };
    }
    const actualiza = ops.find(([op]) => op === 'update');
    if (actualiza) {
      if (estado.errorEnUpdate === t) return { data: null, error: { message: 'base caída', code: '57P01' } };
      filas.forEach((f) => Object.assign(f, actualiza[1]));
      return { data: unica ? filas[0] ?? null : filas.map((f) => ({ ...f })), error: null };
    }
    if (ops.some(([op, , o]) => op === 'select' && o?.head)) return { data: null, error: null, count: filas.length };
    return { data: unica ? filas[0] ?? null : filas, error: null };
  }
  function constructor(t: string) {
    const ops: any[][] = [];
    const b: any = new Proxy({}, {
      get(_o, prop) {
        if (prop === 'then') return (ok: any, mal: any) => Promise.resolve().then(() => responder(t, ops)).then(ok, mal);
        return (...args: any[]) => { ops.push([prop, ...args]); return b; };
      },
    });
    return b;
  }
  const cliente = {
    from: (t: string) => constructor(t),
    rpc: async (_n: string, p: { p_clave: string; p_max: number }) => {
      const n = (estado.intentos.get(p.p_clave) || 0) + 1;
      estado.intentos.set(p.p_clave, n);
      return { data: n > p.p_max ? 60 : 0, error: null };
    },
    storage: { from: () => ({ createSignedUrl: async () => ({ data: { signedUrl: 'https://firmada/hd.jpg' }, error: null }), remove: async () => ({ error: null }) }) },
  };
  return { estado, cliente, tabla };
});

vi.mock('@supabase/supabase-js', () => ({ createClient: () => h.cliente }));
vi.mock('resend', () => ({
  Resend: class { emails = { send: async (m: any) => { h.estado.mails.push(m); return { data: { id: 'x' }, error: null }; } }; },
}));
vi.mock('mercadopago', () => ({
  MercadoPagoConfig: class {},
  Preference: class {
    async create() { return { id: 'pref-nueva', init_point: 'https://mp/x' }; }
    async update() { h.estado.prefUpdates++; if (h.estado.prefUpdateFalla) throw new Error('MP no respondió'); return {}; }
  },
  Payment: class { async search() { return { results: [] }; } async get() { return h.estado.pago; } },
}));

const SECRETO = 'secreto-de-prueba';
const SECRETO_WH = 'clave-webhook';
let servidor: http.Server;
let puerto = 0;
let mod: any;

function pedir(metodo: string, ruta: string, cuerpo?: unknown, headers: Record<string, string> = {}): Promise<{ status: number; texto: string; json: any; headers: http.IncomingHttpHeaders }> {
  return new Promise((ok, mal) => {
    const datos = cuerpo === undefined ? undefined : JSON.stringify(cuerpo);
    const req = http.request({ host: '127.0.0.1', port: puerto, path: ruta, method: metodo, headers: { ...(datos ? { 'Content-Type': 'application/json', 'Content-Length': String(Buffer.byteLength(datos)) } : {}), ...headers } }, (res) => {
      let texto = '';
      res.setEncoding('utf8');
      res.on('data', (c) => { texto += c; });
      res.on('end', () => { let json: any = null; try { json = JSON.parse(texto); } catch { /* */ } ok({ status: res.statusCode || 0, texto, json, headers: res.headers }); });
    });
    req.on('error', mal);
    if (datos) req.write(datos);
    req.end();
  });
}
function tokenAdmin() {
  const ts = String(Date.now());
  const random = crypto.randomBytes(16).toString('hex');
  return `${ts}.${random}.${crypto.createHmac('sha256', SECRETO).update(`${ts}.${random}`).digest('hex')}`;
}
function firmaWebhook(id: string, requestId = 'req-1') {
  const ts = String(Math.floor(Date.now() / 1000));
  const v1 = crypto.createHmac('sha256', SECRETO_WH).update(`id:${id};request-id:${requestId};ts:${ts};`).digest('hex');
  return { 'x-signature': `ts=${ts},v1=${v1}`, 'x-request-id': requestId };
}

const EVENTO = '22222222-2222-2222-2222-222222222222';
const FOTO = '11111111-1111-1111-1111-111111111111';
const PEDIDO = '33333333-3333-3333-3333-333333333333';
const OTRO_PEDIDO = '44444444-4444-4444-4444-444444444444';

beforeAll(async () => {
  process.env.SUPABASE_SERVICE_ROLE_KEY = 'prueba';
  process.env.RESEND_API_KEY = 'prueba';
  process.env.ADMIN_SESSION_SECRET = SECRETO;
  process.env.MERCADOPAGO_ACCESS_TOKEN = 'prueba';
  process.env.MERCADOPAGO_WEBHOOK_SECRET = SECRETO_WH;
  mod = await import('../../servidor');
  servidor = mod.default.listen(0);
  await new Promise((ok) => servidor.once('listening', ok));
  puerto = (servidor.address() as AddressInfo).port;
});
afterAll(() => {
  servidor?.close();
  delete process.env.MERCADOPAGO_ACCESS_TOKEN;
  delete process.env.MERCADOPAGO_WEBHOOK_SECRET;
});
beforeEach(() => {
  h.estado.intentos.clear();
  h.estado.mails.length = 0;
  for (const k of Object.keys(h.estado.tablas)) delete h.estado.tablas[k];
  h.estado.errorEnUpdate = null;
  h.estado.pago = null;
  h.estado.prefUpdateFalla = false;
  h.estado.prefUpdates = 0;
  h.estado.operaciones.length = 0;
});

const comprador = { nombre: 'Ana Pérez', whatsapp: '1155556666', email: 'ana@mail.com' };
function pedidoPagado(extra: Record<string, unknown> = {}) {
  return {
    id: PEDIDO, numero: 'EV26-22222', evento_id: EVENTO, estado: 'pagado', medio_pago: 'mercadopago', total: 5000,
    comprador_email: 'ana@mail.com', comprador_nombre: 'Ana Pérez', comprador_whatsapp: '1155556666', nino_nombre: 'Leo Pérez', nino_curso: null,
    email_digitales_enviado: true, mp_payment_id: '999', mp_preference_id: 'pref-1', notas: null, acepta_novedades: false, vence_en: new Date(Date.now() + 86400000).toISOString(),
    ev_items_pedido: [{ foto_id: FOTO, formato: 'digital', cantidad: 1, subtotal: 5000, incluye_digital: true, ev_fotos: { nombre_archivo: 'a.jpg' } }],
    ev_eventos: { codigo: 'COMUNION26-K7QF', nombre: 'Comunión' },
    ...extra,
  };
}

const ADMIN = () => ({ Authorization: `Bearer ${tokenAdmin()}` });
const eventoAbierto = (extra: Record<string, unknown> = {}) => ({ id: EVENTO, codigo: 'COMUNION26-K7QF', nombre: 'Comunión', publicado: true, fecha_limite: null, precio_digital: 5000, precio_15x21: 8000, precio_20x30: 0, impresa_incluye_digital: true, ...extra });

describe('Todas las rutas /admin/ y /lab/ exigen sesión', () => {
  it('sin token devuelven 401 (inventario sacado del router)', async () => {
    const rutas: Array<{ metodo: string; ruta: string }> = [];
    for (const capa of mod.default._router.stack) {
      if (!capa.route) continue;
      for (const metodo of Object.keys(capa.route.methods)) rutas.push({ metodo: metodo.toUpperCase(), ruta: capa.route.path });
    }
    const protegidas = rutas.filter((r) => r.ruta.includes('/admin/') || r.ruta.includes('/lab/'));
    expect(protegidas.length).toBeGreaterThan(24);
    for (const r of protegidas) {
      const ruta = r.ruta.replace(/:id/g, EVENTO).replace(/:fotoId/g, FOTO);
      const res = await pedir(r.metodo, ruta, r.metodo === 'GET' || r.metodo === 'DELETE' ? undefined : {});
      expect(`${r.metodo} ${ruta} → ${res.status}`).toBe(`${r.metodo} ${ruta} → 401`);
    }
  });
});

describe('EVT-3: crear pedido no revela qué códigos existen y usa el freno de la galería', () => {
  const cuerpo = (items: unknown[]) => ({ medioPago: 'transferencia', aceptaCondiciones: true, comprador, nino: { nombre: 'Leo Pérez' }, items });
  beforeEach(() => {
    h.tabla('ev_eventos').push(
      eventoAbierto(),
      { ...eventoAbierto(), id: '55555555-5555-5555-5555-555555555555', codigo: 'VIEJO25-AB2C', fecha_limite: '2020-01-01' },
      { ...eventoAbierto(), id: '66666666-6666-6666-6666-666666666666', codigo: 'OCULTO26-ZZ22', publicado: false },
    );
    h.tabla('ev_fotos').push({ id: FOTO, evento_id: EVENTO });
  });
  // Revisión 11/10: un evento publicado y CERRADO vuelve a responder 410 «el plazo terminó» (la galería ya lo dice).
  it('código inexistente, sin publicar o abierto con fotos ajenas → la MISMA respuesta; cerrado → 410', async () => {
    const cerrado = await pedir('POST', '/api/eventos/publico/VIEJO25-AB2C/pedidos', cuerpo([{ fotoId: OTRO_PEDIDO, formato: 'digital' }]));
    expect(cerrado.status).toBe(410);
    const respuestas = [];
    for (const codigo of ['NOEXISTE-ZZ99', 'OCULTO26-ZZ22', 'COMUNION26-K7QF']) {
      const r = await pedir('POST', `/api/eventos/publico/${codigo}/pedidos`, cuerpo([{ fotoId: OTRO_PEDIDO, formato: 'digital' }]));
      respuestas.push({ status: r.status, json: r.json });
    }
    expect(new Set(respuestas.map((r) => JSON.stringify(r))).size).toBe(1);
    expect(respuestas[0].status).toBe(400);
    for (const codigo of ['NOEXISTE-ZZ99', 'COMUNION26-K7QF']) {
      const r = await pedir('POST', `/api/eventos/publico/${codigo}/pedidos`, cuerpo([]));
      expect(r.json).toEqual({ success: false, error: 'Elegí al menos una foto.' });
    }
  });
  it('los códigos sin evento abierto cuentan en el freno de la galería y, pasado el tope, 429', async () => {
    await pedir('POST', '/api/eventos/publico/NOEXISTE-ZZ99/pedidos', cuerpo([{ fotoId: FOTO, formato: 'digital' }]));
    await pedir('POST', '/api/eventos/publico/NOEXISTE-ZZ99/pedidos', cuerpo([{ fotoId: FOTO, formato: 'digital' }]));
    await pedir('POST', '/api/eventos/publico/OCULTO26-ZZ22/pedidos', cuerpo([{ fotoId: FOTO, formato: 'digital' }]));
    const fallos = [...h.estado.intentos.entries()].filter(([k]) => k.startsWith('ev-galeria-fallos:'));
    expect(fallos.reduce((a, [, n]) => a + n, 0)).toBe(2); // dos códigos distintos (repetir no suma)
    h.tabla('limites_intentos').push({ clave: 'ev-galeria-fallos:127.0.0.1', cantidad: 41, desde: new Date().toISOString() });
    const r = await pedir('POST', '/api/eventos/publico/COMUNION26-K7QF/pedidos', cuerpo([{ fotoId: FOTO, formato: 'digital' }]), { 'X-Forwarded-For': '127.0.0.1' });
    expect(r.status).toBe(429);
  });
  it('un pedido válido sigue funcionando', async () => {
    const r = await pedir('POST', '/api/eventos/publico/COMUNION26-K7QF/pedidos', cuerpo([{ fotoId: FOTO, formato: '15x21', cantidad: 2 }]));
    expect(r.status).toBe(200);
    expect(r.json.total).toBe(16000);
  });
});

describe('EVT-1: evento «de hermanos» sólo por código BROTHERS o nombre específico', () => {
  const inscripciones = () => h.tabla('inscripciones').push(
    { id: 1, estado: 'aceptado', hermanos: [{ alumnoNombre: 'Luz' }], email: 'familia.a@mail.com', solicita_foto_hermanos: true, foto_hermanos_confirmada_at: '2026-10-08T00:00:00Z' },
    { id: 2, estado: 'aceptado', hermanos: [{ alumnoNombre: 'Tomi' }], email: 'familia.b@mail.com', solicita_foto_hermanos: true, foto_hermanos_confirmada_at: '2026-10-08T00:00:00Z' },
  );
  it('reconoce el evento real y no a un colegio «Hermanos …»', () => {
    expect(mod.esEventoFotoHermanos('Fotos de Hermanos juntos', 'BROTHERS2026-D3EB')).toBe(true);
    expect(mod.esEventoFotoHermanos('Cualquier nombre', 'BROTHERS2027-AB2C')).toBe(true);
    expect(mod.esEventoFotoHermanos('Foto de hermanos', 'X-AB2C')).toBe(true);
    expect(mod.esEventoFotoHermanos('Primera Comunión — Colegio Hermanos Maristas', 'COMUNION26-K7QF')).toBe(false);
    expect(mod.esEventoFotoHermanos('Confirmación Hermanas Adoratrices', 'CONF26-AB2C')).toBe(false);
  });
  it('publicar «Primera Comunión — Colegio Hermanos Maristas» NO manda nada a las familias de hermanos', async () => {
    h.tabla('ev_eventos').push({ id: EVENTO, codigo: 'COMUNION26-K7QF', nombre: 'Primera Comunión — Colegio Hermanos Maristas', publicado: false });
    h.tabla('ev_fotos').push({ id: FOTO, evento_id: EVENTO });
    inscripciones();
    const r = await pedir('PUT', `/api/eventos/admin/eventos/${EVENTO}`, { publicado: true }, ADMIN());
    expect(r.status).toBe(200);
    expect(h.estado.mails).toHaveLength(0);
    expect(h.tabla('ev_avisos')).toHaveLength(0);
  });
  it('el evento real de hermanos sí suma y avisa a las familias', async () => {
    h.tabla('ev_eventos').push({ id: EVENTO, codigo: 'BROTHERS2026-D3EB', nombre: 'Fotos de Hermanos juntos', publicado: false });
    h.tabla('ev_fotos').push({ id: FOTO, evento_id: EVENTO });
    inscripciones();
    const r = await pedir('PUT', `/api/eventos/admin/eventos/${EVENTO}`, { publicado: true }, ADMIN());
    expect(r.status).toBe(200);
    expect(h.estado.mails.map((m) => m.to[0]).sort()).toEqual(['familia.a@mail.com', 'familia.b@mail.com']);
  });
});

describe('EVT-2: reembolso con la base caída → 500 para que Mercado Pago reintente', () => {
  it('refunded + error de Supabase → 500 (MP reintenta)', async () => {
    h.tabla('ev_pedidos').push(pedidoPagado());
    h.estado.pago = { id: 999, status: 'refunded', external_reference: `ev:${PEDIDO}`, transaction_amount: 5000 };
    h.estado.errorEnUpdate = 'ev_pedidos';
    const r = await pedir('POST', '/api/eventos/webhook-mp?type=payment&data.id=999', { type: 'payment', data: { id: '999' } }, firmaWebhook('999'));
    expect(r.status).toBe(500);
    // El reintento de MP, ya con la base andando, lo anula y corta la descarga.
    h.estado.errorEnUpdate = null;
    h.tabla('ev_fotos').push({ id: FOTO, storage_path_hd: 'e/1.jpg', nombre_archivo: 'a.jpg' });
    const r2 = await pedir('POST', '/api/eventos/webhook-mp?type=payment&data.id=999', { type: 'payment', data: { id: '999' } }, firmaWebhook('999'));
    expect(r2.status).toBe(200);
    expect(h.tabla('ev_pedidos')[0].estado).toBe('cancelado');
    const llave = mod.llavePedidoEvento(PEDIDO, SECRETO);
    expect((await pedir('GET', `/api/eventos/pedido/${PEDIDO}/descargar/${FOTO}?t=${llave}`)).status).toBe(403);
  });
});

describe('EVT-5: pago de MP en un pedido que estaba en transferencia → alerta al admin', () => {
  it('avisa (con comprobante subido lo dice)', async () => {
    h.tabla('ev_pedidos').push(pedidoPagado({ estado: 'pendiente', medio_pago: 'transferencia', mp_payment_id: null, email_digitales_enviado: false, comprobante_subido_en: new Date().toISOString() }));
    const res = await mod.procesarPagoAprobado(h.cliente, PEDIDO, 5000, { mp_payment_id: '777' }, 'http://local');
    expect(res).toBe('pagado');
    const alerta = h.estado.mails.find((m) => m.subject.includes('TRANSFERENCIA'));
    expect(alerta).toBeTruthy();
    expect(alerta!.to[0]).not.toBe('ana@mail.com');
    expect(alerta!.html).toContain('ya había subido comprobante');
  });
  it('un pedido de Mercado Pago normal no genera esa alerta', async () => {
    h.tabla('ev_pedidos').push(pedidoPagado({ estado: 'pendiente', mp_payment_id: null, email_digitales_enviado: false }));
    await mod.procesarPagoAprobado(h.cliente, PEDIDO, 5000, { mp_payment_id: '778' }, 'http://local');
    expect(h.estado.mails.some((m) => m.subject.includes('TRANSFERENCIA'))).toBe(false);
  });
});

describe('EVT-6: editar el código exige el sufijo al azar', () => {
  it('un código nuevo sin sufijo recibe uno', async () => {
    h.tabla('ev_eventos').push({ ...eventoAbierto(), publicado: false });
    const r = await pedir('PUT', `/api/eventos/admin/eventos/${EVENTO}`, { codigo: 'COMUNION26' }, ADMIN());
    expect(r.status).toBe(200);
    expect(h.tabla('ev_eventos')[0].codigo).toMatch(/^COMUNION26-[A-HJ-NP-Z2-9]{4}$/);
    expect(mod.tieneSufijoAzar(h.tabla('ev_eventos')[0].codigo)).toBe(true);
  });
  it('un evento viejo sin sufijo se puede editar sin cambiarle el código', async () => {
    h.tabla('ev_eventos').push({ ...eventoAbierto(), codigo: 'CONFIRMACION-0309', publicado: false });
    const r = await pedir('PUT', `/api/eventos/admin/eventos/${EVENTO}`, { codigo: 'CONFIRMACION-0309', nombre: 'Confirmaciones' }, ADMIN());
    expect(r.status).toBe(200);
    expect(h.tabla('ev_eventos')[0].codigo).toBe('CONFIRMACION-0309');
  });
});

describe('EVT-7: borrar evento lee las fotos con orden estable', () => {
  it('la lectura paginada de ev_fotos lleva .order()', async () => {
    h.tabla('ev_eventos').push({ ...eventoAbierto(), publicado: false });
    h.tabla('ev_fotos').push({ id: FOTO, evento_id: EVENTO, storage_path_hd: 'e/1.jpg', preview_path: 'p.jpg', thumb_path: 't.jpg' });
    const r = await pedir('DELETE', `/api/eventos/admin/eventos/${EVENTO}`, undefined, ADMIN());
    expect(r.status).toBe(200);
    const lecturas = h.estado.operaciones.filter((o) => o.tabla === 'ev_fotos' && o.ops.some(([op]) => op === 'range'));
    expect(lecturas.length).toBeGreaterThan(0);
    for (const l of lecturas) expect(l.ops.some(([op]) => op === 'order')).toBe(true);
  });
});

describe('EVT-8: si no se puede guardar el id de la preferencia, el link se da de baja', () => {
  it('error al guardar → se vence la preferencia y la familia queda con el pedido para reintentar', async () => {
    h.tabla('ev_eventos').push(eventoAbierto());
    h.tabla('ev_fotos').push({ id: FOTO, evento_id: EVENTO });
    h.estado.errorEnUpdate = 'ev_pedidos';
    const r = await pedir('POST', '/api/eventos/publico/COMUNION26-K7QF/pedidos', { medioPago: 'mercadopago', aceptaCondiciones: true, comprador, nino: { nombre: 'Leo Pérez' }, items: [{ fotoId: FOTO, formato: 'digital' }] });
    expect(r.status).toBe(200);
    expect(r.json.initPoint).toBeNull();
    expect(r.json.mpNoDisponible).toBe(true);
    expect(h.estado.prefUpdates).toBe(1); // vencerPreferencia
  });
});

describe('Controles que ya estaban bien', () => {
  it('pago tardío sobre pedido cancelado no lo pasa a pagado y avisa una vez', async () => {
    h.tabla('ev_pedidos').push(pedidoPagado({ estado: 'cancelado', mp_payment_id: null, email_digitales_enviado: false }));
    const r1 = await mod.procesarPagoAprobado(h.cliente, PEDIDO, 5000, { mp_payment_id: '555' }, 'http://local');
    const r2 = await mod.procesarPagoAprobado(h.cliente, PEDIDO, 5000, { mp_payment_id: '555' }, 'http://local');
    expect([r1, r2]).toEqual(['ya_pagado', 'ya_pagado']);
    expect(h.tabla('ev_pedidos')[0].estado).toBe('cancelado');
    expect(h.estado.mails.filter((m) => m.subject.includes('CANCELADO'))).toHaveLength(1);
  });
  it('descarga HD: sin pagar 403, llave de otro pedido 403, foto fuera del pedido 404', async () => {
    h.tabla('ev_pedidos').push(pedidoPagado({ estado: 'pendiente' }));
    h.tabla('ev_fotos').push({ id: FOTO, storage_path_hd: 'e/1.jpg', nombre_archivo: 'a.jpg' });
    const llave = mod.llavePedidoEvento(PEDIDO, SECRETO);
    expect((await pedir('GET', `/api/eventos/pedido/${PEDIDO}/descargar/${FOTO}?t=${llave}`)).status).toBe(403);
    h.tabla('ev_pedidos')[0].estado = 'pagado';
    const otra = mod.llavePedidoEvento(OTRO_PEDIDO, SECRETO);
    expect((await pedir('GET', `/api/eventos/pedido/${PEDIDO}/descargar/${FOTO}?t=${otra}`)).status).toBe(403);
    expect((await pedir('GET', `/api/eventos/pedido/${PEDIDO}/descargar/${OTRO_PEDIDO}?t=${llave}`)).status).toBe(404);
    expect((await pedir('GET', `/api/eventos/pedido/${PEDIDO}/descargar/${FOTO}?t=${llave}`)).status).toBe(302);
  });
  it('webhook con firma de otro id → 401', async () => {
    h.estado.pago = { id: 1, status: 'approved', external_reference: `ev:${PEDIDO}`, transaction_amount: 1 };
    expect((await pedir('POST', '/api/eventos/webhook-mp?type=payment&data.id=1', {}, firmaWebhook('2'))).status).toBe(401);
  });
  it('monto: cantidades negativas, enormes, formato sin precio o inválido → 400; decimales se truncan', async () => {
    h.tabla('ev_eventos').push(eventoAbierto());
    h.tabla('ev_fotos').push({ id: FOTO, evento_id: EVENTO });
    const base = { medioPago: 'transferencia', aceptaCondiciones: true, comprador, nino: { nombre: 'Leo Pérez' } };
    for (const items of [
      [{ fotoId: FOTO, formato: '15x21', cantidad: -3 }],
      [{ fotoId: FOTO, formato: '15x21', cantidad: 1e9 }],
      [{ fotoId: FOTO, formato: '20x30', cantidad: 1 }],
      [{ fotoId: FOTO, formato: 'A4', cantidad: 1 }],
    ]) expect((await pedir('POST', '/api/eventos/publico/COMUNION26-K7QF/pedidos', { ...base, items })).status).toBe(400);
    const ok = await pedir('POST', '/api/eventos/publico/COMUNION26-K7QF/pedidos', { ...base, items: [{ fotoId: FOTO, formato: '15x21', cantidad: 2.9, precio: 1 }, { fotoId: FOTO, formato: 'digital' }] });
    expect(ok.json.total).toBe(16000);
  });
});
