// @vitest-environment jsdom
// Auditoría 11/10 (EVT-4), regresión: el bloque «Fotos» del panel de eventos va DENTRO de la vista del evento
// y, al volver a la lista, la zona de subida ya no apunta al evento anterior.
import { describe, it, expect, vi } from 'vitest';
import { readFileSync } from 'fs';
import path from 'path';

const raiz = path.resolve(__dirname, '../../../public');
const esperar = () => new Promise((r) => setTimeout(r, 20));

describe('EVT-4: panel de eventos — bloque de fotos', () => {
  it('queda dentro de vista-evento y, tras «Volver», soltar fotos no sube nada al evento anterior', async () => {
    const html = readFileSync(path.join(raiz, 'eventos-admin.html'), 'utf8');
    document.documentElement.innerHTML = html.replace(/<script[^>]*><\/script>/g, '');
    const vista = document.getElementById('vista-evento')!;
    expect(vista.contains(document.getElementById('bloque-fotos'))).toBe(true);

    const evento = { id: '22222222-2222-2222-2222-222222222222', codigo: 'COMUNION26-K7QF', nombre: 'Comunión A', publicado: true, precio_digital: 1, precio_15x21: 0, precio_20x30: 0, cantidad_fotos: 1 };
    const llamadas: string[] = [];
    (globalThis as any).fetch = vi.fn(async (url: string) => {
      const u = String(url);
      llamadas.push(u);
      const json = (d: unknown) => ({ ok: true, status: 200, json: async () => d });
      if (u.endsWith('/admin/eventos')) return json({ success: true, eventos: [evento] });
      if (u.endsWith('/fotos')) return json({ success: true, fotos: [{ id: 'f1', nombre_archivo: 'IMG_1.jpg', thumb_url: 'x', preview_path: 'a-m4.jpg' }] });
      if (u.endsWith('/pedidos')) return json({ success: true, pedidos: [] });
      if (u.endsWith('/lotes')) return json({ success: true, lotes: [] });
      return json({ success: true, activos: 0, bajas: 0, subidas: [] });
    });
    sessionStorage.setItem('infocus_admin_session_token', 't');
    window.scrollTo = () => {};
    // eslint-disable-next-line no-new-func
    new Function(readFileSync(path.join(raiz, 'eventos/admin.js'), 'utf8'))();
    await esperar();
    (document.querySelector('.evento-card') as HTMLElement).click();
    await esperar();
    expect(vista.hidden).toBe(false);
    expect(document.getElementById('bloque-fotos')!.hidden).toBe(false);
    document.getElementById('btn-volver')!.click();
    await esperar();
    expect(vista.hidden).toBe(true);
    expect(document.getElementById('vista-lista')!.hidden).toBe(false);
    // Aunque alguien suelte fotos en la zona, no se pide ninguna subida.
    const archivo = new File(['x'], 'IMG_9.jpg', { type: 'image/jpeg' });
    const soltar = new Event('drop', { cancelable: true }) as any;
    soltar.dataTransfer = { files: [archivo] };
    document.getElementById('zona-subida')!.dispatchEvent(soltar);
    await esperar();
    expect(llamadas.some((u) => u.includes('/subidas'))).toBe(false);
  });
});
