// 10/10/2026 (Pablo): las impresas de eventos se entregan dentro de los 10 días hábiles posteriores al
// cierre de pedidos del evento o al pago, lo que pase último (Ley 24.240, art. 10 inc. e).
import { describe, it, expect } from 'vitest';
import { readFileSync } from 'fs';
import path from 'path';
import { correoPagoConfirmado, DIAS_HABILES_ENTREGA_IMPRESAS, textoPlazoImpresas } from '../correos';
import { fechaPrimerEnvio } from '../precios';

const pedido = {
  numero: 'EV26-00001',
  eventoNombre: 'Primera Comunión',
  compradorNombre: 'Ana Pérez',
  ninoNombre: 'Juan Pérez',
  total: 8000,
  urlPedido: 'https://www.retratoescolar.com.ar/eventos/X/pedido/1',
  items: [{ nombre_archivo: 'IMG_0001.jpg', formato: '15x21' as const, cantidad: 1, subtotal: 8000 }],
};

describe('plazo de entrega de las impresas de eventos', () => {
  it('pagado antes del cierre: cuenta desde el cierre de pedidos', () => {
    expect(textoPlazoImpresas('2026-10-24', '2026-10-11T15:00:00Z')).toBe(
      'dentro de los 10 días hábiles posteriores al cierre de pedidos del evento (el 24/10)',
    );
  });

  it('el último día del cierre (hora de Argentina) todavía cuenta desde el cierre', () => {
    // 02:30 UTC del 25 = 23:30 del 24 en Argentina.
    expect(textoPlazoImpresas('2026-10-24', '2026-10-25T02:30:00Z')).toContain('al cierre de pedidos del evento (el 24/10)');
  });

  it('pagado después del cierre, sin fecha límite o con una fecha rara: cuenta desde el pago', () => {
    const desdeElPago = 'dentro de los 10 días hábiles posteriores a la confirmación del pago';
    expect(textoPlazoImpresas('2026-10-24', '2026-10-25T12:00:00Z')).toBe(desdeElPago);
    expect(textoPlazoImpresas(null, '2026-10-11T15:00:00Z')).toBe(desdeElPago);
    expect(textoPlazoImpresas('24/10/2026')).toBe(desdeElPago);
  });

  it('el mail de pago confirmado dice el plazo sólo si el pedido tiene impresas', () => {
    const conImpresas = correoPagoConfirmado({ ...pedido, hayDigitales: false, hayImpresas: true, fechaLimite: '2099-12-31', pagadoEn: null });
    expect(conImpresas.html).toContain('se entregan dentro de los 10 días hábiles posteriores al cierre de pedidos del evento (el 31/12)');
    const soloDigital = correoPagoConfirmado({ ...pedido, hayDigitales: true, hayImpresas: false });
    expect(soloDigital.html).not.toContain('días hábiles');
  });

  it('la página del evento usa el mismo número de días (portada, antes de pagar y galería)', () => {
    const frase = `${DIAS_HABILES_ENTREGA_IMPRESAS} días hábiles`;
    const html = readFileSync(path.resolve(__dirname, '../../public/eventos.html'), 'utf8');
    const js = readFileSync(path.resolve(__dirname, '../../public/eventos/familias.js'), 'utf8');
    expect(html.split(frase).length - 1).toBe(2);
    expect(js).toContain(frase);
  });

  // 11/10/2026 (Pablo): dos envíos al laboratorio, a mitad del plazo y al cierre.
  describe('dos envíos al laboratorio', () => {
    it('sin fecha cargada, el 1.º envío cae a mitad entre el evento y el cierre', () => {
      expect(fechaPrimerEnvio({ fecha_evento: '2026-10-09', fecha_limite: '2026-11-07' })).toBe('2026-10-23');
      expect(fechaPrimerEnvio({ fecha_evento: '2026-10-03', fecha_limite: '2026-10-31' })).toBe('2026-10-17');
    });

    it('la fecha cargada a mano manda si es antes del cierre; si no, hay un solo envío', () => {
      expect(fechaPrimerEnvio({ fecha_evento: '2026-10-09', fecha_limite: '2026-11-07', fecha_primer_envio: '2026-10-15' })).toBe('2026-10-15');
      expect(fechaPrimerEnvio({ fecha_evento: '2026-10-09', fecha_limite: '2026-11-07', fecha_primer_envio: '2026-11-07' })).toBeNull();
      expect(fechaPrimerEnvio({ fecha_evento: null, fecha_limite: '2026-11-07' })).toBeNull();
      expect(fechaPrimerEnvio({ fecha_evento: '2026-10-09', fecha_limite: null })).toBeNull();
      expect(fechaPrimerEnvio({ fecha_evento: '2026-11-05', fecha_limite: '2026-11-07' })).toBeNull();
    });

    it('pagado hasta el 1.º envío cuenta desde ahí; después, desde el cierre; después del cierre, desde el pago', () => {
      expect(textoPlazoImpresas('2026-11-07', '2026-10-11T16:21:00Z', '2026-10-23')).toBe(
        'dentro de los 10 días hábiles posteriores al primer envío al laboratorio (el 23/10)',
      );
      // 02:30 UTC del 24 = 23:30 del 23 en Argentina: todavía entra en el 1.º envío.
      expect(textoPlazoImpresas('2026-11-07', '2026-10-24T02:30:00Z', '2026-10-23')).toContain('primer envío al laboratorio (el 23/10)');
      expect(textoPlazoImpresas('2026-11-07', '2026-10-24T12:00:00Z', '2026-10-23')).toBe(
        'dentro de los 10 días hábiles posteriores al cierre de pedidos del evento (el 07/11)',
      );
      expect(textoPlazoImpresas('2026-11-07', '2026-11-08T12:00:00Z', '2026-10-23')).toContain('a la confirmación del pago');
    });

    it('el mail de pago confirmado usa el envío que le toca', () => {
      const r = correoPagoConfirmado({ ...pedido, hayDigitales: false, hayImpresas: true, fechaLimite: '2026-11-07', pagadoEn: '2026-10-11T16:21:00Z', primerEnvio: '2026-10-23' });
      expect(r.html).toContain('se entregan dentro de los 10 días hábiles posteriores al primer envío al laboratorio (el 23/10)');
    });
  });
});
