// @vitest-environment jsdom
// 14/10/2026: arreglos del panel de eventos y de la página del laboratorio (mismo patrón que
// auditoria1110/panel-admin-dom.test.ts: el HTML real + el JS real con un fetch falso).
import { describe, it, expect, vi } from 'vitest';
import { readFileSync } from 'fs';
import path from 'path';

const raiz = path.resolve(__dirname, '../../../public');
const esperar = (ms = 20) => new Promise((r) => setTimeout(r, ms));
const VERSION = '2026-10-14T10:00:00.000+00:00';
const evento = { id: '22222222-2222-2222-2222-222222222222', codigo: 'COMUNION26-K7QF', nombre: 'Comunión A', publicado: true, precio_digital: 1, precio_15x21: 0, precio_20x30: 0, cantidad_fotos: 1, actualizado_en: VERSION };

type Llamada = { metodo: string; url: string; cuerpo: any };
function cargarPanel(respuestaGuardar: () => { status: number; json: any }) {
  const html = readFileSync(path.join(raiz, 'eventos-admin.html'), 'utf8');
  document.documentElement.innerHTML = html.replace(/<script[^>]*><\/script>/g, '');
  const llamadas: Llamada[] = [];
  (globalThis as any).fetch = vi.fn(async (url: string, op: any = {}) => {
    const u = String(url);
    const metodo = op.method || 'GET';
    llamadas.push({ metodo, url: u, cuerpo: op.body ? JSON.parse(op.body) : undefined });
    const json = (d: unknown, status = 200) => ({ ok: status < 400, status, json: async () => d });
    if (metodo === 'PUT' || metodo === 'POST') {
      await esperar(30); // el servidor tarda: un segundo clic llega con el primero en vuelo
      const r = respuestaGuardar();
      return json(r.json, r.status);
    }
    if (u.endsWith('/admin/eventos')) return json({ success: true, eventos: [evento] });
    if (u.endsWith('/admin/eventos/' + evento.id)) return json({ success: true, evento: { ...evento, nombre: 'Comunión (del servidor)' }, codigoEditable: false });
    if (u.endsWith('/fotos')) return json({ success: true, fotos: [] });
    if (u.includes('/pedidos')) return json({ success: true, pedidos: [] });
    if (u.endsWith('/lotes')) return json({ success: true, lotes: [] });
    return json({ success: true, activos: 0, bajas: 0 });
  });
  sessionStorage.setItem('infocus_admin_session_token', 't');
  window.scrollTo = () => {};
  // eslint-disable-next-line no-new-func
  new Function(readFileSync(path.join(raiz, 'eventos/admin.js'), 'utf8'))();
  return llamadas;
}

describe('panel de eventos', () => {
  it('al abrir: datos del servidor, código bloqueado con la explicación y pedidos marcados vistos a propósito', async () => {
    const llamadas = cargarPanel(() => ({ status: 200, json: { success: true, evento } }));
    await esperar();
    (document.querySelector('.evento-card') as HTMLElement).click();
    await esperar(60);
    const f = document.getElementById('form-evento') as HTMLFormElement;
    expect((f.elements.namedItem('nombre') as HTMLInputElement).value).toBe('Comunión (del servidor)');
    const codigo = f.elements.namedItem('codigo') as HTMLInputElement;
    expect(codigo.readOnly).toBe(true);
    expect(codigo.parentElement!.querySelector('small')!.textContent).toContain('rompería el QR impreso');
    expect(llamadas.some((l) => l.url.endsWith('/pedidos?vistos=1'))).toBe(true);
  });

  it('guardar manda actualizado_en; un 409 de otro dispositivo recarga el evento y lo dice; doble envío = un solo PUT', async () => {
    const llamadas = cargarPanel(() => ({ status: 409, json: { success: false, conflicto: true, error: 'El evento cambió en otro dispositivo: recargá antes de guardar.' } }));
    await esperar();
    (document.querySelector('.evento-card') as HTMLElement).click();
    await esperar(60);
    const f = document.getElementById('form-evento') as HTMLFormElement;
    const lecturasAntes = llamadas.filter((l) => l.url.endsWith('/admin/eventos/' + evento.id) && l.metodo === 'GET').length;
    f.dispatchEvent(new Event('submit', { cancelable: true }));
    f.dispatchEvent(new Event('submit', { cancelable: true }));
    await esperar(120);
    const puts = llamadas.filter((l) => l.metodo === 'PUT');
    expect(puts).toHaveLength(1);
    expect(puts[0].cuerpo.actualizado_en).toBe(VERSION);
    expect(document.getElementById('evento-error')!.textContent).toContain('otro dispositivo');
    expect(llamadas.filter((l) => l.url.endsWith('/admin/eventos/' + evento.id) && l.metodo === 'GET').length).toBe(lecturasAntes + 1);
  });

  it('crear un evento con doble clic en «Guardar» manda un solo POST', async () => {
    const llamadas = cargarPanel(() => ({ status: 200, json: { success: true, evento: { ...evento, publicado: false, cantidad_fotos: 0 } } }));
    await esperar();
    (document.getElementById('btn-nuevo') as HTMLElement).click();
    const f = document.getElementById('form-evento') as HTMLFormElement;
    (f.elements.namedItem('nombre') as HTMLInputElement).value = 'Comunión B';
    (f.elements.namedItem('codigo') as HTMLInputElement).value = 'COMUNION26';
    f.dispatchEvent(new Event('submit', { cancelable: true }));
    f.dispatchEvent(new Event('submit', { cancelable: true }));
    await esperar(120);
    expect(llamadas.filter((l) => l.metodo === 'POST' && l.url.endsWith('/api/eventos/admin/eventos'))).toHaveLength(1);
  });
});

describe('página del laboratorio', () => {
  it('muestra los pedidos anulados de un lote («Anulado: no imprimir»)', async () => {
    const html = readFileSync(path.join(raiz, 'laboratorio-eventos.html'), 'utf8');
    document.documentElement.innerHTML = html.replace(/<script[^>]*><\/script>/g, '');
    (globalThis as any).fetch = vi.fn(async () => ({
      ok: true, status: 200,
      json: async () => ({ success: true, lotes: [{ id: 'l1', numero: 2, estado: 'en_laboratorio', creado_en: VERSION, pedidos: 3, copias15x21: 3, copias20x30: 0, anulados: 1, anuladosDetalle: ['EV26-33333 (Sol Gómez)'], evento: { nombre: 'Comunión', codigo: 'X' } }] }),
    }));
    sessionStorage.setItem('ev_lab_token', 't');
    // eslint-disable-next-line no-new-func
    new Function(readFileSync(path.join(raiz, 'eventos/laboratorio.js'), 'utf8'))();
    await esperar();
    const texto = document.getElementById('lista')!.textContent || '';
    expect(texto).toContain('Anulado: no imprimir');
    expect(texto).toContain('EV26-33333 (Sol Gómez)');
  });
});

describe('subida de fotos y ZIP por partes (código del navegador)', () => {
  const admin = readFileSync(path.join(raiz, 'eventos/admin.js'), 'utf8');
  const lab = readFileSync(path.join(raiz, 'eventos/laboratorio.js'), 'utf8');
  it('«ya registrada» (409) cuenta como registrada y la tanda se reintenta', () => {
    expect(admin).toContain('if (e.status === 409) ok++;');
    expect(admin).toMatch(/function registrar\(fotos\) \{ return conReintentos\(/);
  });
  it('sesión vencida en medio de la subida: se corta todo con un mensaje claro', () => {
    expect(admin).toContain("if (e.status === 401) { estado.sesionVencida = true; estado.cancelarSubida = true; return; }");
    expect(admin).toContain('Tu sesión venció: volvé a entrar y elegí las mismas fotos; las ya subidas se saltean');
  });
  it('el ZIP por partes guarda el progreso, renueva los links y avisa al cerrar entre partes', () => {
    expect(lab).toContain("'/partes'");
    expect(lab).toContain('function linksFrescos(plan)');
    expect(lab).toContain('if (descargando || planActivo)');
  });
});
