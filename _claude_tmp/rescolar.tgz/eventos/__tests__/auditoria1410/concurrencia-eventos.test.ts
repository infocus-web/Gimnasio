// 14/10/2026: pruebas de los arreglos de la auditoría del módulo de eventos (código del evento, formulario viejo,
// comprobantes y lotes a la vez desde dos dispositivos, compras nuevas, ZIP por partes). Base, Resend y Mercado
// Pago falsos (mismo patrón que auditoria1110/regresion-eventos.test.ts). Cada una falla con el código anterior.
import { describe, it, expect, vi, beforeAll, afterAll, beforeEach } from 'vitest';
import http from 'http';
import crypto from 'crypto';
import type { AddressInfo } from 'net';

const h = vi.hoisted(() => {
  const estado = {
    intentos: new Map<string, number>(),
    mails: [] as Array<{ to: string[]; subject: string; html: string }>,
    tablas: {} as Record<string, any[]>,
    // Simula a OTRO dispositivo que escribe justo antes de un UPDATE (para probar los UPDATE condicionales).
    antesDeUpdate: null as null | ((tabla: string, cambios: any) => void),
    prefUpdates: 0,
    storageBorrados: [] as string[],
  };
  const tabla = (t: string) => (estado.tablas[t] ||= []);
  function responder(t: string, ops: any[][]): any {
    const fuente = tabla(t);
    const actualiza = ops.find(([op]) => op === 'update');
    if (actualiza && estado.antesDeUpdate) estado.antesDeUpdate(t, actualiza[1]);
    const filtro = (filas: any[]) => filas.filter((f) => ops.every(([op, campo, valor]) =>
      op === 'eq' ? f[campo] === valor
        : op === 'is' ? (f[campo] ?? null) === valor
          : op === 'neq' ? f[campo] !== valor
            : op === 'in' ? (valor as any[]).includes(f[campo])
              : op === 'contains' ? (valor as any[]).every((v) => (f[campo] || []).includes(v))
                : true));
    const unica = ops.some(([op]) => op === 'maybeSingle' || op === 'single');
    const inserta = ops.find(([op]) => op === 'insert' || op === 'upsert');
    if (inserta) {
      const lista = Array.isArray(inserta[1]) ? inserta[1] : [inserta[1]];
      const nuevas = lista.map((f: any) => ({ id: f.id || crypto.randomUUID(), creado_en: new Date().toISOString(), ...f }));
      fuente.push(...nuevas);
      return { data: unica ? nuevas[0] : nuevas, error: null };
    }
    const filas = filtro(fuente);
    if (ops.some(([op]) => op === 'delete')) {
      for (const f of filas) fuente.splice(fuente.indexOf(f), 1);
      return { data: filas.map((f) => ({ id: f.id })), error: null };
    }
    if (actualiza) {
      filas.forEach((f) => Object.assign(f, actualiza[1]));
      return { data: unica ? filas[0] ?? null : filas.map((f) => ({ ...f })), error: null };
    }
    if (ops.some(([op, , o]) => op === 'select' && o?.head)) return { data: null, error: null, count: filas.length };
    // Copias (como una base real): lo leído no cambia solo cuando después se actualiza la fila.
    return { data: unica ? (filas[0] ? { ...filas[0] } : null) : filas.map((f) => ({ ...f })), error: null };
  }
  function constructor(t: string) {
    const ops: any[][] = [];
    const b: any = new Proxy({}, {
      get(_o, prop) {
        if (prop === 'then') return (ok: any, mal: any) => Promise.resolve().then(() => responder(t, ops)).then(ok, mal);
        return (...args: any[]) => { ops.push([prop, ...args]); return b; };
      },
    });
    return b;
  }
  const cliente = {
    from: (t: string) => constructor(t),
    rpc: async (_n: string, p: { p_clave: string; p_max: number }) => {
      const n = (estado.intentos.get(p.p_clave) || 0) + 1;
      estado.intentos.set(p.p_clave, n);
      return { data: n > p.p_max ? 60 : 0, error: null };
    },
    storage: {
      from: () => ({
        upload: async () => ({ error: null }),
        remove: async (rutas: string[]) => { estado.storageBorrados.push(...rutas); return { error: null }; },
        createSignedUrl: async () => ({ data: { signedUrl: 'https://firmada/x' }, error: null }),
      }),
    },
  };
  return { estado, cliente, tabla };
});

vi.mock('@supabase/supabase-js', () => ({ createClient: () => h.cliente }));
vi.mock('resend', () => ({
  Resend: class { emails = { send: async (m: any) => { h.estado.mails.push(m); return { data: { id: 'x' }, error: null }; } }; },
}));
vi.mock('mercadopago', () => ({
  MercadoPagoConfig: class {},
  Preference: class {
    async create() { return { id: 'pref-nueva', init_point: 'https://mp/pref-nueva' }; }
    async update() { h.estado.prefUpdates++; return {}; }
    async get({ preferenceId }: { preferenceId: string }) { return { id: preferenceId, init_point: `https://mp/${preferenceId}` }; }
  },
  Payment: class { async search() { return { results: [] }; } async get() { return {}; } },
}));

const SECRETO = 'secreto-de-prueba';
let servidor: http.Server;
let puerto = 0;
let mod: any;

function pedir(metodo: string, ruta: string, cuerpo?: unknown, headers: Record<string, string> = {}): Promise<{ status: number; json: any }> {
  return new Promise((ok, mal) => {
    const datos = cuerpo === undefined ? undefined : JSON.stringify(cuerpo);
    const req = http.request({ host: '127.0.0.1', port: puerto, path: ruta, method: metodo, headers: { ...(datos ? { 'Content-Type': 'application/json', 'Content-Length': String(Buffer.byteLength(datos)) } : {}), ...headers } }, (res) => {
      let texto = '';
      res.setEncoding('utf8');
      res.on('data', (c) => { texto += c; });
      res.on('end', () => { let json: any = null; try { json = JSON.parse(texto); } catch { /* */ } ok({ status: res.statusCode || 0, json }); });
    });
    req.on('error', mal);
    if (datos) req.write(datos);
    req.end();
  });
}
function tokenAdmin() {
  const ts = String(Date.now());
  const random = crypto.randomBytes(16).toString('hex');
  return `${ts}.${random}.${crypto.createHmac('sha256', SECRETO).update(`${ts}.${random}`).digest('hex')}`;
}
const ADMIN = () => ({ Authorization: `Bearer ${tokenAdmin()}` });

const EVENTO = '22222222-2222-2222-2222-222222222222';
const FOTO = '11111111-1111-1111-1111-111111111111';
const PEDIDO = '33333333-3333-3333-3333-333333333333';
const LOTE = '55555555-5555-5555-5555-555555555555';
const VERSION = '2026-10-14T10:00:00.000+00:00';

const evento = (extra: Record<string, unknown> = {}) => ({
  id: EVENTO, codigo: 'COMUNION26-K7QF', nombre: 'Comunión', publicado: false, fecha_limite: null, precio_digital: 5000,
  precio_15x21: 8000, precio_20x30: 0, impresa_incluye_digital: true, actualizado_en: VERSION, codigos_anteriores: [], ...extra,
});
const pedido = (extra: Record<string, unknown> = {}) => ({
  id: PEDIDO, numero: 'EV26-22222', evento_id: EVENTO, estado: 'pendiente', medio_pago: 'transferencia', total: 5000,
  comprador_email: 'ana@mail.com', comprador_nombre: 'Ana Pérez', comprador_whatsapp: '1155556666', nino_nombre: 'Leo Pérez', nino_curso: null,
  email_digitales_enviado: false, mp_payment_id: null, mp_preference_id: null, notas: null, acepta_novedades: false,
  vence_en: new Date(Date.now() + 86400000).toISOString(), comprobante_subido_en: null, comprobante_path: null, lote_id: null,
  ev_items_pedido: [{ foto_id: FOTO, formato: 'digital', cantidad: 1, subtotal: 5000, incluye_digital: true, ev_fotos: { nombre_archivo: 'a.jpg' } }],
  ev_eventos: { codigo: 'COMUNION26-K7QF', nombre: 'Comunión', fecha_limite: null },
  ...extra,
});

beforeAll(async () => {
  process.env.SUPABASE_SERVICE_ROLE_KEY = 'prueba';
  process.env.RESEND_API_KEY = 'prueba';
  process.env.ADMIN_SESSION_SECRET = SECRETO;
  process.env.MERCADOPAGO_ACCESS_TOKEN = 'prueba';
  mod = await import('../../servidor');
  servidor = mod.default.listen(0);
  await new Promise((ok) => servidor.once('listening', ok));
  puerto = (servidor.address() as AddressInfo).port;
});
afterAll(() => {
  servidor?.close();
  delete process.env.MERCADOPAGO_ACCESS_TOKEN;
});
beforeEach(() => {
  h.estado.intentos.clear();
  h.estado.mails.length = 0;
  for (const k of Object.keys(h.estado.tablas)) delete h.estado.tablas[k];
  h.estado.antesDeUpdate = null;
  h.estado.prefUpdates = 0;
  h.estado.storageBorrados.length = 0;
});

describe('A1: cambiar el código de un evento', () => {
  it('publicado → 409 y el código no cambia', async () => {
    h.tabla('ev_eventos').push(evento({ publicado: true }));
    const r = await pedir('PUT', `/api/eventos/admin/eventos/${EVENTO}`, { codigo: 'OTRO26' }, ADMIN());
    expect(r.status).toBe(409);
    expect(r.json.error).toContain('rompe el QR impreso');
    expect(h.tabla('ev_eventos')[0].codigo).toBe('COMUNION26-K7QF');
  });
  it('sin publicar pero con fotos (o pedidos) → 409', async () => {
    h.tabla('ev_eventos').push(evento());
    h.tabla('ev_fotos').push({ id: FOTO, evento_id: EVENTO });
    expect((await pedir('PUT', `/api/eventos/admin/eventos/${EVENTO}`, { codigo: 'OTRO26' }, ADMIN())).status).toBe(409);
    h.tabla('ev_fotos').length = 0;
    h.tabla('ev_pedidos').push(pedido());
    expect((await pedir('PUT', `/api/eventos/admin/eventos/${EVENTO}`, { codigo: 'OTRO26' }, ADMIN())).status).toBe(409);
  });
  it('mismo código con el evento publicado (guardar otros datos) sigue andando', async () => {
    h.tabla('ev_eventos').push(evento({ publicado: true }));
    const r = await pedir('PUT', `/api/eventos/admin/eventos/${EVENTO}`, { codigo: 'COMUNION26-K7QF', nombre: 'Comunión 2026' }, ADMIN());
    expect(r.status).toBe(200);
    expect(h.tabla('ev_eventos')[0].nombre).toBe('Comunión 2026');
  });
  it('sin publicar, sin fotos ni pedidos: cambia, guarda el viejo y el QR viejo lleva al código nuevo', async () => {
    h.tabla('ev_eventos').push(evento());
    const r = await pedir('PUT', `/api/eventos/admin/eventos/${EVENTO}`, { codigo: 'OTRO26' }, ADMIN());
    expect(r.status).toBe(200);
    const ev = h.tabla('ev_eventos')[0];
    expect(ev.codigo).toMatch(/^OTRO26-[A-HJ-NP-Z2-9]{4}$/);
    expect(ev.codigos_anteriores).toEqual(['COMUNION26-K7QF']);
    ev.publicado = true;
    h.tabla('ev_fotos').push({ id: FOTO, evento_id: EVENTO, nombre_archivo: 'a.jpg', preview_path: 'p.jpg', thumb_path: 't.jpg' });
    const g = await pedir('GET', '/api/eventos/publico/COMUNION26-K7QF');
    expect(g.status).toBe(200);
    expect(g.json.proximamente).toBeUndefined();
    expect(g.json.evento.codigo).toBe(ev.codigo);
    expect(g.json.fotos).toHaveLength(1);
  });
  it('el «Avisame» con el código viejo se anota en el evento', async () => {
    h.tabla('ev_eventos').push(evento({ codigo: 'NUEVO26-AB2C', codigos_anteriores: ['COMUNION26-K7QF'] }));
    const r = await pedir('POST', '/api/eventos/publico/COMUNION26-K7QF/avisame', { email: 'ana@mail.com' });
    expect(r.status).toBe(200);
    expect(h.tabla('ev_avisos')).toEqual([expect.objectContaining({ evento_id: EVENTO, email: 'ana@mail.com' })]);
  });
  it('GET de un evento dice si el código se puede cambiar', async () => {
    h.tabla('ev_eventos').push(evento());
    expect((await pedir('GET', `/api/eventos/admin/eventos/${EVENTO}`, undefined, ADMIN())).json.codigoEditable).toBe(true);
    h.tabla('ev_eventos')[0].publicado = true;
    const r = await pedir('GET', `/api/eventos/admin/eventos/${EVENTO}`, undefined, ADMIN());
    expect(r.json.codigoEditable).toBe(false);
    expect(r.json.evento.actualizado_en).toBe(VERSION);
  });
});

describe('A2: un formulario viejo no pisa el evento', () => {
  it('actualizado_en distinto → 409 y no cambia nada (ni `publicado` ni precios)', async () => {
    h.tabla('ev_eventos').push(evento({ publicado: true, actualizado_en: '2026-10-14T11:00:00.000+00:00' }));
    const r = await pedir('PUT', `/api/eventos/admin/eventos/${EVENTO}`, { publicado: false, precio_digital: 1, actualizado_en: VERSION }, ADMIN());
    expect(r.status).toBe(409);
    expect(r.json.conflicto).toBe(true);
    expect(r.json.error).toContain('cambió en otro dispositivo');
    expect(h.tabla('ev_eventos')[0]).toMatchObject({ publicado: true, precio_digital: 5000 });
  });
  it('actualizado_en igual → guarda y devuelve la versión nueva', async () => {
    h.tabla('ev_eventos').push(evento());
    const r = await pedir('PUT', `/api/eventos/admin/eventos/${EVENTO}`, { precio_digital: 6000, actualizado_en: VERSION }, ADMIN());
    expect(r.status).toBe(200);
    expect(r.json.evento.precio_digital).toBe(6000);
    expect(r.json.evento.actualizado_en).not.toBe(VERSION);
  });
});

describe('M2: transferencias con comprobante piden confirmar antes de borrar', () => {
  it('borrar el evento', async () => {
    h.tabla('ev_eventos').push(evento());
    h.tabla('ev_pedidos').push(pedido({ comprobante_subido_en: new Date().toISOString(), comprobante_path: 'eventos/x/1.png' }));
    const r = await pedir('DELETE', `/api/eventos/admin/eventos/${EVENTO}`, undefined, ADMIN());
    expect(r.status).toBe(409);
    expect(r.json.requiereConfirmacion).toBe(true);
    expect(h.tabla('ev_pedidos')).toHaveLength(1);
    expect(h.estado.storageBorrados).toEqual([]);
    expect((await pedir('DELETE', `/api/eventos/admin/eventos/${EVENTO}?confirmar=COMUNION26-K7QF`, undefined, ADMIN())).status).toBe(200);
    expect(h.tabla('ev_pedidos')).toHaveLength(0);
  });
  it('borrar un pedido', async () => {
    h.tabla('ev_pedidos').push(pedido({ comprobante_subido_en: new Date().toISOString(), comprobante_path: 'eventos/x/1.png' }));
    const r = await pedir('DELETE', `/api/eventos/admin/pedidos/${PEDIDO}`, undefined, ADMIN());
    expect(r.status).toBe(409);
    expect(r.json.requiereConfirmacion).toBe(true);
    expect((await pedir('DELETE', `/api/eventos/admin/pedidos/${PEDIDO}?confirmar=EV26-22222`, undefined, ADMIN())).status).toBe(200);
    expect(h.tabla('ev_pedidos')).toHaveLength(0);
  });
  it('un pendiente sin comprobante se sigue borrando sin confirmar', async () => {
    h.tabla('ev_pedidos').push(pedido());
    expect((await pedir('DELETE', `/api/eventos/admin/pedidos/${PEDIDO}`, undefined, ADMIN())).status).toBe(200);
  });
});

describe('B2: comprobante subido desde dos dispositivos a la vez', () => {
  const png = 'data:image/png;base64,' + Buffer.concat([Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]), Buffer.alloc(32)]).toString('base64');
  const ruta = () => `/api/eventos/pedido/${PEDIDO}/comprobante?t=${mod.llavePedidoEvento(PEDIDO, SECRETO)}`;
  it('gana uno solo: el otro recibe 409, se borra su archivo y a Pablo le llega un solo mail', async () => {
    h.tabla('ev_pedidos').push(pedido());
    h.estado.antesDeUpdate = (t, cambios) => {
      if (t === 'ev_pedidos' && cambios.comprobante_path) h.tabla('ev_pedidos')[0].comprobante_subido_en = '2026-10-14T09:00:00.000Z';
    };
    const r = await pedir('POST', ruta(), { archivo: png });
    expect(r.status).toBe(409);
    expect(h.estado.mails).toHaveLength(0);
    expect(h.estado.storageBorrados).toHaveLength(1);
  });
  it('sin carrera: se guarda y avisa una vez', async () => {
    h.tabla('ev_pedidos').push(pedido());
    expect((await pedir('POST', ruta(), { archivo: png })).status).toBe(201);
    expect(h.estado.mails.filter((m) => m.subject.includes('Comprobante'))).toHaveLength(1);
  });
  it('pedido cancelado → no se acepta', async () => {
    h.tabla('ev_pedidos').push(pedido({ estado: 'cancelado' }));
    expect((await pedir('POST', ruta(), { archivo: png })).status).toBe(410);
    expect(h.estado.mails).toHaveLength(0);
  });
});

describe('B3: lote «terminado» por dos del laboratorio', () => {
  const lote = () => ({ id: LOTE, evento_id: EVENTO, numero: 1, estado: 'en_laboratorio', fecha_descargado: '2026-10-13T10:00:00Z', fecha_terminado: null, ev_eventos: { nombre: 'Comunión' } });
  it('si el otro lo marcó en el medio, no sale un segundo mail', async () => {
    h.tabla('ev_lotes').push(lote());
    h.estado.antesDeUpdate = (t) => { if (t === 'ev_lotes') h.tabla('ev_lotes')[0].fecha_terminado = '2026-10-14T09:00:00Z'; };
    expect((await pedir('POST', `/api/eventos/lab/lotes/${LOTE}/estado`, { paso: 'terminado' }, ADMIN())).status).toBe(200);
    expect(h.estado.mails).toHaveLength(0);
  });
  it('el primero manda el mail una vez', async () => {
    h.tabla('ev_lotes').push(lote());
    await pedir('POST', `/api/eventos/lab/lotes/${LOTE}/estado`, { paso: 'terminado' }, ADMIN());
    await pedir('POST', `/api/eventos/lab/lotes/${LOTE}/estado`, { paso: 'terminado' }, ADMIN());
    expect(h.estado.mails.filter((m) => m.subject.includes('terminado'))).toHaveLength(1);
  });
});

describe('B4: «compras nuevas» se borra sólo al abrir los pedidos a propósito', () => {
  it('el refresco automático no los marca vistos; ?vistos=1 sí', async () => {
    h.tabla('ev_eventos').push(evento({ pedidos_vistos_en: null }));
    await pedir('GET', `/api/eventos/admin/eventos/${EVENTO}/pedidos`, undefined, ADMIN());
    expect(h.tabla('ev_eventos')[0].pedidos_vistos_en).toBeNull();
    await pedir('GET', `/api/eventos/admin/eventos/${EVENTO}/pedidos?vistos=1`, undefined, ADMIN());
    expect(h.tabla('ev_eventos')[0].pedidos_vistos_en).toEqual(expect.any(String));
  });
});

describe('B5: pasar a Mercado Pago desde dos dispositivos a la vez', () => {
  const ruta = () => `/api/eventos/pedido/${PEDIDO}/medio-pago?t=${mod.llavePedidoEvento(PEDIDO, SECRETO)}`;
  it('el que pierde da de baja su link y devuelve el del que ganó', async () => {
    h.tabla('ev_pedidos').push(pedido({ mp_preference_id: 'pref-vieja' }));
    h.estado.antesDeUpdate = (t, cambios) => {
      if (t === 'ev_pedidos' && cambios.mp_preference_id === 'pref-nueva') h.tabla('ev_pedidos')[0].mp_preference_id = 'pref-ganadora';
    };
    const r = await pedir('POST', ruta(), { medioPago: 'mercadopago' });
    expect(r.status).toBe(200);
    expect(r.json.initPoint).toBe('https://mp/pref-ganadora');
    expect(h.tabla('ev_pedidos')[0].mp_preference_id).toBe('pref-ganadora');
    expect(h.estado.prefUpdates).toBe(2); // la vieja y la propia (la que perdió)
  });
  it('sin carrera: queda la preferencia nueva', async () => {
    h.tabla('ev_pedidos').push(pedido({ mp_preference_id: 'pref-vieja' }));
    const r = await pedir('POST', ruta(), { medioPago: 'mercadopago' });
    expect(r.json.initPoint).toBe('https://mp/pref-nueva');
    expect(h.tabla('ev_pedidos')[0].mp_preference_id).toBe('pref-nueva');
  });
});

describe('B6 y M4: laboratorio', () => {
  it('la lista de lotes dice qué pedidos se anularon', async () => {
    h.tabla('ev_lotes').push({ id: LOTE, evento_id: EVENTO, numero: 1, estado: 'en_laboratorio', ev_eventos: { nombre: 'Comunión', codigo: 'X' } });
    h.tabla('ev_pedidos').push(
      pedido({ estado: 'pagado', lote_id: LOTE }),
      pedido({ id: crypto.randomUUID(), numero: 'EV26-33333', nino_nombre: 'Sol Gómez', estado: 'cancelado', lote_id: LOTE }),
    );
    const r = await pedir('GET', '/api/eventos/lab/lotes', undefined, ADMIN());
    expect(r.json.lotes[0]).toMatchObject({ anulados: 1, anuladosDetalle: ['EV26-33333 (Sol Gómez)'] });
  });
  it('las partes bajadas del ZIP quedan guardadas en el lote', async () => {
    h.tabla('ev_lotes').push({ id: LOTE, evento_id: EVENTO, numero: 1, estado: 'armado', partes_descargadas: null });
    expect((await pedir('POST', `/api/eventos/lab/lotes/${LOTE}/partes`, { total: 200, partes: 3, parte: 0, faltan: 0 }, ADMIN())).status).toBe(200);
    await pedir('POST', `/api/eventos/lab/lotes/${LOTE}/partes`, { total: 200, partes: 3, parte: 2, faltan: 1 }, ADMIN());
    const r = await pedir('GET', `/api/eventos/lab/lotes/${LOTE}/partes`, undefined, ADMIN());
    expect(r.json.progreso).toMatchObject({ total: 200, partes: 3, hechas: { 0: 0, 2: 1 } });
    expect((await pedir('POST', `/api/eventos/lab/lotes/${LOTE}/partes`, { total: 200, partes: 3, parte: 3, faltan: 0 }, ADMIN())).status).toBe(400);
  });
});
