import { describe, it, expect } from 'vitest';
import { calcularPedido, eventoCerrado, validarComprador } from '../precios';

const evento = { precio_digital: 5000, precio_15x21: 8000, precio_20x30: 12000, impresa_incluye_digital: true };
const fotos = new Set(['a', 'b', 'c']);

describe('calcularPedido', () => {
  it('suma digitales e impresas con los precios del evento', () => {
    const r = calcularPedido([
      { fotoId: 'a', formato: 'digital' },
      { fotoId: 'b', formato: '15x21', cantidad: 2 },
      { fotoId: 'c', formato: '20x30', cantidad: 1 },
    ], evento, fotos);
    expect(r.error).toBeUndefined();
    expect(r.total).toBe(5000 + 16000 + 12000);
  });
  it('no cobra el digital si la misma foto tiene impresa y la impresa lo incluye', () => {
    const r = calcularPedido([{ fotoId: 'a', formato: 'digital' }, { fotoId: 'a', formato: '15x21', cantidad: 1 }], evento, fotos);
    expect(r.total).toBe(8000);
    expect(r.items).toHaveLength(1);
    expect(r.items![0].incluye_digital).toBe(true);
  });
  it('si la impresa NO incluye el digital, se cobran los dos', () => {
    const r = calcularPedido([{ fotoId: 'a', formato: 'digital' }, { fotoId: 'a', formato: '15x21' }], { ...evento, impresa_incluye_digital: false }, fotos);
    expect(r.total).toBe(13000);
    expect(r.items!.find((i) => i.formato === '15x21')!.incluye_digital).toBe(false);
  });
  it('05/10: la impresa no incluye el digital si el evento no vende digitales (precio 0)', () => {
    const r = calcularPedido([{ fotoId: 'a', formato: '15x21' }], { ...evento, precio_digital: 0 }, fotos);
    expect(r.error).toBeUndefined();
    expect(r.total).toBe(8000);
    expect(r.items![0].incluye_digital).toBe(false);
    // Con precio digital > 0 sigue incluyéndolo.
    const r2 = calcularPedido([{ fotoId: 'a', formato: '15x21' }], evento, fotos);
    expect(r2.items![0].incluye_digital).toBe(true);
  });
  it('digital siempre 1 y junta líneas repetidas', () => {
    const r = calcularPedido([{ fotoId: 'a', formato: 'digital', cantidad: 5 }, { fotoId: 'b', formato: '20x30', cantidad: 1 }, { fotoId: 'b', formato: '20x30', cantidad: 2 }], evento, fotos);
    expect(r.total).toBe(5000 + 36000);
  });
  it('rechaza fotos de otro evento, formatos sin precio y cantidades raras', () => {
    expect(calcularPedido([{ fotoId: 'z', formato: 'digital' }], evento, fotos).error).toBeTruthy();
    expect(calcularPedido([{ fotoId: 'a', formato: '20x30' }], { ...evento, precio_20x30: 0 }, fotos).error).toBeTruthy();
    expect(calcularPedido([{ fotoId: 'a', formato: '15x21', cantidad: 0 }], evento, fotos).error).toBeTruthy();
    expect(calcularPedido([{ fotoId: 'a', formato: '15x21', cantidad: 51 }], evento, fotos).error).toBeTruthy();
    expect(calcularPedido([{ fotoId: 'a', formato: 'poster' }], evento, fotos).error).toBeTruthy();
    expect(calcularPedido([], evento, fotos).error).toBeTruthy();
  });
  it('ignora cualquier precio que mande el navegador', () => {
    const r = calcularPedido([{ fotoId: 'a', formato: 'digital', precio: 1, subtotal: 1 }], evento, fotos);
    expect(r.total).toBe(5000);
  });
});

describe('eventoCerrado', () => {
  it('cierra al terminar el día de la fecha límite (hora Argentina)', () => {
    expect(eventoCerrado('2026-10-20', Date.parse('2026-10-20T23:00:00-03:00'))).toBe(false);
    expect(eventoCerrado('2026-10-20', Date.parse('2026-10-21T00:01:00-03:00'))).toBe(true);
    expect(eventoCerrado(null)).toBe(false);
  });
});

describe('validarComprador', () => {
  const ok = { comprador: { nombre: 'Ana Pérez', whatsapp: '11 2345-6789', email: 'Ana@Mail.com' }, nino: { nombre: 'Juan Pérez', curso: '4° A' } };
  it('acepta datos completos y normaliza el email', () => {
    expect(validarComprador(ok).datos?.comprador_email).toBe('ana@mail.com');
  });
  it('pide email, WhatsApp y nombre del chico/a', () => {
    expect(validarComprador({ ...ok, comprador: { ...ok.comprador, email: 'x' } }).error).toBeTruthy();
    expect(validarComprador({ ...ok, comprador: { ...ok.comprador, whatsapp: '123' } }).error).toBeTruthy();
    expect(validarComprador({ ...ok, nino: { nombre: '' } }).error).toBeTruthy();
  });
});
