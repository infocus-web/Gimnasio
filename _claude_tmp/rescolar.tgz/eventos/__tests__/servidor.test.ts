import { describe, it, expect } from 'vitest';
import crypto from 'crypto';
import { readFileSync } from 'fs';
import path from 'path';
import { verificarTokenAdmin, normalizarCodigo, validarDatosEvento, esEventoFotoHermanos, emailsFotoHermanos } from '../servidor';

function tokenValido(secreto: string, ts = Date.now()) {
  const random = crypto.randomBytes(16).toString('hex');
  const firma = crypto.createHmac('sha256', secreto).update(`${ts}.${random}`).digest('hex');
  return `${ts}.${random}.${firma}`;
}

describe('verificarTokenAdmin (mismo token que /api/admin/login)', () => {
  it('acepta un token firmado con el secreto', () => {
    expect(verificarTokenAdmin(tokenValido('secreto'), 'secreto')).toBe(true);
  });
  it('rechaza otro secreto, token vencido, vacío o con formato raro', () => {
    expect(verificarTokenAdmin(tokenValido('otro'), 'secreto')).toBe(false);
    expect(verificarTokenAdmin(tokenValido('secreto', Date.now() - 25 * 3600 * 1000), 'secreto')).toBe(false);
    expect(verificarTokenAdmin(undefined, 'secreto')).toBe(false);
    expect(verificarTokenAdmin('lab.1.2.3', 'secreto')).toBe(false);
    expect(verificarTokenAdmin(tokenValido('secreto'), '')).toBe(false);
  });
});

describe('validarDatosEvento', () => {
  it('normaliza el código', () => {
    expect(normalizarCodigo(' comunión 26 ')).toBe('COMUNION26');
  });
  it('crear exige nombre y código', () => {
    expect(validarDatosEvento({ nombre: 'Comunión' }, false).error).toBeTruthy();
    expect(validarDatosEvento({ codigo: 'COMUNION26' }, false).error).toBeTruthy();
    const ok = validarDatosEvento({ nombre: 'Comunión', codigo: 'comunion26', precio_digital: '5000', fecha_evento: '2026-10-02' }, false);
    expect(ok.error).toBeUndefined();
    expect(ok.datos).toMatchObject({ codigo: 'COMUNION26', precio_digital: 5000, fecha_evento: '2026-10-02' });
  });
  it('rechaza precios negativos y fechas mal formadas', () => {
    expect(validarDatosEvento({ precio_15x21: -1 }, true).error).toBeTruthy();
    expect(validarDatosEvento({ fecha_limite: '10/10/2026' }, true).error).toBeTruthy();
  });
  it('editar permite cambios parciales', () => {
    expect(validarDatosEvento({ publicado: true }, true).datos).toEqual({ publicado: true });
  });
  it('04/10: guarda el interruptor «Muestras con lupa»', () => {
    expect(validarDatosEvento({ muestras_lupa: true }, true).datos).toEqual({ muestras_lupa: true });
    expect(validarDatosEvento({ muestras_lupa: 0 }, true).datos).toEqual({ muestras_lupa: false });
    expect(validarDatosEvento({ publicado: true }, true).datos).not.toHaveProperty('muestras_lupa');
  });
});

import { llavePedidoEvento, firmaArchivoValida } from '../servidor';

describe('llave del pedido y comprobantes', () => {
  it('la llave depende del pedido y del secreto', () => {
    const a = llavePedidoEvento('p1', 's');
    expect(a).toHaveLength(32);
    expect(llavePedidoEvento('p2', 's')).not.toBe(a);
    expect(llavePedidoEvento('p1', 'otro')).not.toBe(a);
  });
  it('controla la firma real del archivo', () => {
    expect(firmaArchivoValida(Buffer.from([0xff, 0xd8, 0xff, 0xe0, 0, 0, 0, 0]), 'jpg')).toBe(true);
    expect(firmaArchivoValida(Buffer.from('%PDF-1.7 hola'), 'pdf')).toBe(true);
    expect(firmaArchivoValida(Buffer.from('<html>'), 'jpg')).toBe(false);
  });
});

import { llaveBaja } from '../servidor';
import { correoPagoConfirmado } from '../correos';

describe('suscriptores y mail de agradecimiento', () => {
  it('la llave de baja no depende de mayúsculas y cambia con el email', () => {
    expect(llaveBaja('Ana@Mail.com', 's')).toBe(llaveBaja('ana@mail.com', 's'));
    expect(llaveBaja('ana@mail.com', 's')).not.toBe(llaveBaja('otra@mail.com', 's'));
  });
  it('el mail de pago agradece, ofrece impresas desde la galería y muestra el Instagram', () => {
    const { html } = correoPagoConfirmado({
      numero: 'EV26-1', eventoNombre: 'Confirmaciones', compradorNombre: 'Ana Pérez', ninoNombre: 'Leo', total: 5000,
      urlPedido: 'https://x/p', items: [], hayDigitales: true, hayImpresas: false, urlGaleria: 'https://x/eventos/COD',
    });
    expect(html).toContain('Gracias por elegirnos, Ana');
    expect(html).toContain('Pedir copias impresas');
    expect(html).toContain('https://x/eventos/COD');
    expect(html).toContain('@retratoescolar.com.ar');
  });
});

// Auditoría 03/10 noche: sufijo al azar en el código de los eventos nuevos.
import { codigoConSufijo, sufijoAzar, tieneSufijoAzar } from '../servidor';

describe('sufijo al azar del código de evento', () => {
  it('agrega 4 caracteres sin O/0/I/1, con al menos una letra y un número', () => {
    for (let i = 0; i < 300; i++) {
      const s = sufijoAzar();
      expect(s).toMatch(/^[A-HJ-NP-Z2-9]{4}$/);
      expect(s).toMatch(/[A-Z]/);
      expect(s).toMatch(/[2-9]/);
    }
    // Aunque el azar dé siempre la misma letra, el sufijo lleva un número.
    expect(sufijoAzar(() => 0)).toMatch(/[2-9]/);
    // Y aunque dé siempre el mismo número, lleva una letra.
    expect(sufijoAzar((n) => n - 1)).toMatch(/[A-Z]/);
  });
  it('arma CODIGO-XXXX, respeta los 30 caracteres y no repite el sufijo si ya lo trae', () => {
    const c = codigoConSufijo('COMUNION26');
    expect(c).toMatch(/^COMUNION26-[A-HJ-NP-Z2-9]{4}$/);
    expect(tieneSufijoAzar(c)).toBe(true);
    expect(codigoConSufijo(c)).toBe(c);
    const largo = codigoConSufijo('A'.repeat(30));
    expect(largo.length).toBeLessThanOrEqual(30);
    expect(validarDatosEvento({ nombre: 'Prueba', codigo: largo }, false).error).toBeUndefined();
    // "-2026" o "-SANT" no cuentan como sufijo al azar (sólo números / sólo letras): se agrega uno.
    expect(tieneSufijoAzar('COMUNION-2026')).toBe(false);
    expect(tieneSufijoAzar('COMUNION-SANT')).toBe(false);
    expect(codigoConSufijo('COMUNION-')).toMatch(/^COMUNION-[A-HJ-NP-Z2-9]{4}$/);
  });
});

// 08/10 (pedido de Pablo): la foto de hermanos se vende como un evento. Las familias que dijeron que SÍ
// quedan en el «Avisame» de ese evento y la pantalla «todavía sin fotos» ya no promete 24 hs.
describe('foto de hermanos como evento', () => {
  const fila = (x: Record<string, unknown>) => ({
    estado: 'aceptado',
    hermanos: [{ alumnoNombre: 'Luz' }],
    email: 'tutor@mail.com',
    foto_hermanos_email: null,
    solicita_foto_hermanos: true,
    foto_hermanos_confirmada_at: '2026-10-08T21:00:00Z',
    ...x,
  });

  it('reconoce el evento de hermanos por el nombre', () => {
    expect(esEventoFotoHermanos('Fotos de Hermanos juntos')).toBe(true);
    expect(esEventoFotoHermanos('Fotos de hermanos 2027')).toBe(true); // 11/10: «herman» suelto ya no alcanza
    expect(esEventoFotoHermanos('Primera Comunión — Colegio Hermanos Maristas')).toBe(false);
    expect(esEventoFotoHermanos('Confirmaciones 02-10-2026')).toBe(false);
    expect(esEventoFotoHermanos(null)).toBe(false);
  });

  it('anota sólo a las aceptadas que confirmaron, con el email de la consulta si lo dejaron', () => {
    const r = emailsFotoHermanos([
      fila({ foto_hermanos_email: 'Aviso@Mail.com ' }),
      fila({ email: 'otra@mail.com' }),
      fila({ email: 'pendiente@mail.com', estado: 'pendiente' }),
      fila({ email: 'rechazada@mail.com', estado: 'rechazado' }),
      fila({ email: 'sinconfirmar@mail.com', foto_hermanos_confirmada_at: null }),
      fila({ email: 'sinhermanos@mail.com', hermanos: [] }),
      fila({ email: 'texto@mail.com', hermanos: '[{"alumnoNombre":"Ana"}]' }),
      fila({ email: 'roto' }),
      fila({ email: 'otra@mail.com' }),
    ]);
    expect(r.si.sort()).toEqual(['aviso@mail.com', 'otra@mail.com', 'texto@mail.com']);
    expect(r.no).toEqual([]);
  });

  it('a las que dijeron que no las saca, salvo que el mismo email esté en un sí', () => {
    const r = emailsFotoHermanos([
      fila({ email: 'no@mail.com', solicita_foto_hermanos: false }),
      fila({ email: 'ambos@mail.com', solicita_foto_hermanos: false }),
      fila({ email: 'ambos@mail.com' }),
    ]);
    expect(r.si).toEqual(['ambos@mail.com']);
    expect(r.no).toEqual(['no@mail.com']);
  });

  it('se sincroniza antes de avisar a los anotados de un evento de hermanos', () => {
    const fuente = readFileSync(path.resolve(__dirname, '../servidor.ts'), 'utf8').replace(/\r\n/g, '\n');
    const avisar = fuente.slice(fuente.indexOf('async function avisarAnotados('), fuente.indexOf('// ---------------- Suscriptores a novedades'));
    expect(avisar).toContain("if (esEventoFotoHermanos(ev.nombre, ev.codigo)) await sincronizarAvisosFotoHermanos(sb, eventoId);");
    expect(avisar.indexOf('sincronizarAvisosFotoHermanos')).toBeLessThan(avisar.indexOf(".from('ev_avisos').select('id, email')"));
  });

  it('la pantalla del evento sin fotos ya no promete 24 hs', () => {
    const html = readFileSync(path.resolve(__dirname, '../../public/eventos.html'), 'utf8');
    expect(html).not.toContain('24 hs');
    expect(html).toContain('<h1>Las fotos todavía no están online</h1>');
  });
});
