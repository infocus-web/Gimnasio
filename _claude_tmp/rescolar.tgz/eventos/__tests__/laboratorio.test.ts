import { describe, it, expect } from 'vitest';
import crypto from 'crypto';
import { archivosDelLote, puedePasarA, sanitizarMinilab } from '../laboratorio';
import { verificarTokenLab } from '../servidor';

describe('archivos del lote para el minilab', () => {
  const pedidos = [
    {
      numero: 'EV26-11111', nino_nombre: 'Juan Pérez', nino_curso: '4° A',
      items: [
        { formato: '15x21', cantidad: 2, foto_id: 'f1', nombre_archivo: 'IMG_001.jpg', storage_path_hd: 'e/1.jpg' },
        { formato: 'digital', cantidad: 1, foto_id: 'f2', nombre_archivo: 'IMG_002.jpg', storage_path_hd: 'e/2.jpg' },
        { formato: '20x30', cantidad: 1, foto_id: 'f1', nombre_archivo: 'IMG_001.jpg', storage_path_hd: 'e/1.jpg' },
      ],
    },
  ];
  it('un archivo por copia, carpeta por tamaño, sin digitales', () => {
    const a = archivosDelLote(pedidos);
    expect(a.map((x) => `${x.carpeta}/${x.nombre}`)).toEqual([
      '15x21/4_A_JUAN_PEREZ_EV26_11111_IMG_001.jpg',
      '15x21/4_A_JUAN_PEREZ_EV26_11111_IMG_001_COPIA2.jpg',
      '20x30/4_A_JUAN_PEREZ_EV26_11111_IMG_001.jpg',
    ]);
  });
  it('nunca repite un nombre en la misma carpeta', () => {
    const dobles = archivosDelLote([pedidos[0], { ...pedidos[0] }]);
    const nombres = dobles.map((x) => `${x.carpeta}/${x.nombre}`);
    expect(new Set(nombres).size).toBe(nombres.length);
  });
  it('limpia acentos y símbolos', () => {
    expect(sanitizarMinilab('Sofía Núñez-Ruiz')).toBe('SOFIA_NUNEZ_RUIZ');
  });
});

describe('etapas de entrega', () => {
  it('avanza de a un paso y permite reenviar "listo"', () => {
    expect(puedePasarA(null, 'en_laboratorio')).toBe(true);
    expect(puedePasarA(null, 'listo_retiro')).toBe(false);
    expect(puedePasarA('en_laboratorio', 'listo_retiro')).toBe(true);
    expect(puedePasarA('listo_retiro', 'listo_retiro')).toBe(true);
    expect(puedePasarA('listo_retiro', 'entregado')).toBe(true);
    expect(puedePasarA('entregado', 'en_laboratorio')).toBe(false);
  });
});

describe('token del laboratorio (mismo que /api/lab/login)', () => {
  it('acepta el formato lab.ts.random.firma', () => {
    const ts = String(Date.now());
    const random = crypto.randomBytes(16).toString('hex');
    const firma = crypto.createHmac('sha256', 's').update(`lab:${ts}.${random}`).digest('hex');
    expect(verificarTokenLab(`lab.${ts}.${random}.${firma}`, 's')).toBe(true);
    expect(verificarTokenLab(`lab.${ts}.${random}.${firma}`, 'otro')).toBe(false);
    expect(verificarTokenLab(`${ts}.${random}.${firma}`, 's')).toBe(false);
  });
});
