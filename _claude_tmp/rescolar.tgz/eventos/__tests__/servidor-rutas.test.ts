// Auditoría 03/10 noche: pruebas de rutas del módulo de eventos con una base y un Resend falsos
// (nada sale a la red: Supabase, Resend y Mercado Pago están reemplazados por dobles en memoria).
import { describe, it, expect, vi, beforeAll, afterAll, beforeEach } from 'vitest';
import http from 'http';
import type { AddressInfo } from 'net';

const h = vi.hoisted(() => {
  const estado = {
    intentos: new Map<string, number>(),
    mails: [] as Array<{ to: string[]; subject: string }>,
    eventos: [] as any[],
    pedidos: [] as any[],
    fotos: [] as any[],
    suscriptores: [] as any[],
    items: [] as any[],
    codigos: [] as any[], // 27/10: codigos_descuento
    operaciones: [] as Array<{ tabla: string; ops: any[][] }>,
    mpFalla: false, // 05/10: true = Mercado Pago "caído" (Preference.create tira)
  };
  // Responde según la tabla y la cadena de operaciones (select/eq/update/...).
  function responder(tabla: string, ops: any[][]): { data: any; error: any; count?: number } {
    estado.operaciones.push({ tabla, ops });
    // 05/10: también neq / in (los usa procesarPagoAprobado), insert y delete.
    const filtro = (filas: any[]) => filas.filter((f) => ops.every(([op, campo, valor]) =>
      op === 'eq' ? f[campo] === valor
        : op === 'is' ? (f[campo] ?? null) === valor
          : op === 'neq' ? f[campo] !== valor
            : op === 'in' ? (valor as any[]).includes(f[campo])
              : true));
    const unica = ops.some(([op]) => op === 'maybeSingle' || op === 'single');
    const actualiza = ops.find(([op]) => op === 'update');
    const fuente = tabla === 'ev_eventos' ? estado.eventos : tabla === 'ev_pedidos' ? estado.pedidos : tabla === 'ev_fotos' ? estado.fotos : tabla === 'ev_suscriptores' ? estado.suscriptores : tabla === 'ev_items_pedido' ? estado.items : tabla === 'codigos_descuento' ? estado.codigos : [];
    const inserta = ops.find(([op]) => op === 'insert');
    if (inserta) {
      const nuevas = (Array.isArray(inserta[1]) ? inserta[1] : [inserta[1]]).map((f: any, i: number) => ({ id: f.id || `${tabla}-${fuente.length + i + 1}`, creado_en: new Date().toISOString(), ...(tabla === 'ev_pedidos' ? { email_digitales_enviado: false } : {}), ...f }));
      fuente.push(...nuevas);
      return { data: unica ? nuevas[0] : nuevas, error: null };
    }
    const filas = filtro(fuente);
    if (ops.some(([op]) => op === 'delete')) {
      for (const f of filas) fuente.splice(fuente.indexOf(f), 1);
      return { data: filas.map((f) => ({ id: f.id })), error: null };
    }
    if (actualiza) {
      filas.forEach((f) => Object.assign(f, actualiza[1]));
      return { data: filas.map((f) => ({ id: f.id })), error: null };
    }
    const cabeza = ops.find(([op, , opciones]) => op === 'select' && opciones?.head);
    if (cabeza) return { data: null, error: null, count: filas.length };
    return { data: unica ? filas[0] ?? null : filas, error: null };
  }
  function constructor(tabla: string) {
    const ops: any[][] = [];
    const b: any = new Proxy({}, {
      get(_obj, prop) {
        if (prop === 'then') return (ok: any, mal: any) => Promise.resolve().then(() => responder(tabla, ops)).then(ok, mal);
        return (...args: any[]) => { ops.push([prop, ...args]); return b; };
      },
    });
    return b;
  }
  const cliente = {
    from: (tabla: string) => constructor(tabla),
    rpc: async (_nombre: string, p: { p_clave: string; p_max: number; p_codigo?: string }) => {
      // 27/10: usos de los códigos de descuento (misma lógica que las funciones SQL).
      if (_nombre === 'usar_codigo_descuento') {
        const c = estado.codigos.find((x) => x.codigo === p.p_codigo && x.activo && (!x.usos_max || x.usos < x.usos_max));
        if (!c) return { data: null, error: null };
        c.usos += 1;
        return { data: c.porcentaje, error: null };
      }
      if (_nombre === 'devolver_uso_codigo_descuento') {
        const c = estado.codigos.find((x) => x.codigo === p.p_codigo);
        if (c) c.usos = Math.max(0, c.usos - 1);
        return { data: null, error: null };
      }
      const n = (estado.intentos.get(p.p_clave) || 0) + 1;
      estado.intentos.set(p.p_clave, n);
      return { data: n > p.p_max ? 60 : 0, error: null };
    },
    storage: { from: () => ({}) },
  };
  return { estado, cliente };
});

vi.mock('@supabase/supabase-js', () => ({ createClient: () => h.cliente }));
vi.mock('resend', () => ({
  Resend: class {
    emails = { send: async (m: any) => { h.estado.mails.push(m); return { data: { id: 'x' }, error: null }; } };
  },
}));
vi.mock('mercadopago', () => ({
  MercadoPagoConfig: class {},
  Preference: class { async create() { if (h.estado.mpFalla) throw new Error('MP caído'); return { id: 'pref', init_point: 'https://mp/x' }; } async update() { return {}; } },
  Payment: class { async search() { return { results: [] }; } async get() { return {}; } },
}));

let servidor: http.Server;
let puerto = 0;

function pedir(metodo: string, ruta: string, cuerpo?: unknown): Promise<{ status: number; texto: string; json: any }> {
  return new Promise((ok, mal) => {
    const datos = cuerpo === undefined ? undefined : JSON.stringify(cuerpo);
    const req = http.request({ host: '127.0.0.1', port: puerto, path: ruta, method: metodo, headers: datos ? { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(datos) } : {} }, (res) => {
      let texto = '';
      res.setEncoding('utf8');
      res.on('data', (c) => { texto += c; });
      res.on('end', () => {
        let json: any = null;
        try { json = JSON.parse(texto); } catch { /* html */ }
        ok({ status: res.statusCode || 0, texto, json });
      });
    });
    req.on('error', mal);
    if (datos) req.write(datos);
    req.end();
  });
}

const FOTO = '11111111-1111-1111-1111-111111111111';
const EVENTO = '22222222-2222-2222-2222-222222222222';
const PEDIDO = '33333333-3333-3333-3333-333333333333';

beforeAll(async () => {
  process.env.SUPABASE_SERVICE_ROLE_KEY = 'prueba';
  process.env.RESEND_API_KEY = 'prueba';
  process.env.ADMIN_SESSION_SECRET = 'secreto-de-prueba';
  delete process.env.MERCADOPAGO_ACCESS_TOKEN;
  delete process.env.MERCADOPAGO_WEBHOOK_SECRET;
  const app = (await import('../servidor')).default;
  servidor = app.listen(0);
  await new Promise((ok) => servidor.once('listening', ok));
  puerto = (servidor.address() as AddressInfo).port;
});
afterAll(() => { servidor?.close(); });

beforeEach(() => {
  h.estado.intentos.clear();
  h.estado.mails.length = 0;
  h.estado.operaciones.length = 0;
  h.estado.eventos.length = 0;
  h.estado.pedidos.length = 0;
  h.estado.fotos.length = 0;
  h.estado.suscriptores.length = 0;
  h.estado.items.length = 0;
  h.estado.codigos.length = 0;
  h.estado.mpFalla = false;
});

describe('E5: pedido repetido no entrega la llave', () => {
  it('reenvía el link al email del pedido (una vez cada 10 min) y no devuelve llave ni id', async () => {
    h.estado.eventos.push({ id: EVENTO, codigo: 'COMUNION26-K7QF', nombre: 'Comunión', publicado: true, fecha_limite: null, precio_digital: 5000, precio_15x21: 0, precio_20x30: 0, impresa_incluye_digital: true });
    h.estado.fotos.push({ id: FOTO, evento_id: EVENTO });
    h.estado.pedidos.push({
      id: PEDIDO, numero: 'EV26-11111', evento_id: EVENTO, estado: 'pendiente', medio_pago: 'transferencia', total: 5000,
      comprador_email: 'ana@mail.com', comprador_nombre: 'Ana Pérez', nino_nombre: 'Leo Pérez', nino_curso: null,
      comprobante_subido_en: null, ev_items_pedido: [{ foto_id: FOTO, formato: 'digital', cantidad: 1, subtotal: 5000 }],
      ev_eventos: { codigo: 'COMUNION26-K7QF', nombre: 'Comunión' },
    });
    const cuerpo = {
      medioPago: 'transferencia', aceptaCondiciones: true,
      comprador: { nombre: 'Ana Pérez', whatsapp: '1155556666', email: 'ana@mail.com' },
      nino: { nombre: 'Leo Pérez', curso: '' },
      items: [{ fotoId: FOTO, formato: 'digital', cantidad: 1 }],
    };
    const r = await pedir('POST', '/api/eventos/publico/COMUNION26-K7QF/pedidos', cuerpo);
    expect(r.status).toBe(200);
    expect(r.json).toEqual({ success: true, repetido: true, sinLlave: true, mensaje: 'Ya registramos este pedido: te reenviamos el link por email.' });
    expect(r.texto).not.toContain(PEDIDO);
    expect(h.estado.mails.map((m) => m.to[0])).toEqual(['ana@mail.com']);
    // No se cambió nada del pedido.
    expect(h.estado.operaciones.some((o) => o.tabla === 'ev_pedidos' && o.ops.some(([op]) => op === 'update' || op === 'insert'))).toBe(false);
    // Un segundo intento enseguida no vuelve a mandar el mail.
    const r2 = await pedir('POST', '/api/eventos/publico/COMUNION26-K7QF/pedidos', cuerpo);
    expect(r2.json.sinLlave).toBe(true);
    expect(h.estado.mails).toHaveLength(1);
  });
});

describe('05/10: Mercado Pago caído al crear el pedido', () => {
  const cuerpo = {
    medioPago: 'mercadopago', aceptaCondiciones: true,
    comprador: { nombre: 'Ana Pérez', whatsapp: '1155556666', email: 'ana@mail.com' },
    nino: { nombre: 'Leo Pérez', curso: '' },
    items: [{ fotoId: FOTO, formato: 'digital', cantidad: 1 }],
  };
  beforeEach(() => {
    process.env.MERCADOPAGO_ACCESS_TOKEN = 'prueba';
    h.estado.eventos.push({ id: EVENTO, codigo: 'COMUNION26-K7QF', nombre: 'Comunión', publicado: true, fecha_limite: null, precio_digital: 5000, precio_15x21: 0, precio_20x30: 0, impresa_incluye_digital: true });
    h.estado.fotos.push({ id: FOTO, evento_id: EVENTO });
  });
  afterAll(() => { delete process.env.MERCADOPAGO_ACCESS_TOKEN; });

  it('el pedido queda creado, se manda el mail y se devuelve la llave con initPoint null', async () => {
    h.estado.mpFalla = true;
    const r = await pedir('POST', '/api/eventos/publico/COMUNION26-K7QF/pedidos', cuerpo);
    expect(r.status).toBe(200);
    expect(r.json.success).toBe(true);
    expect(r.json.mpNoDisponible).toBe(true);
    expect(r.json.initPoint).toBeNull();
    expect(r.json.llave).toBeTruthy();
    expect(r.json.pedidoId).toBe(h.estado.pedidos[0].id);
    expect(r.json.total).toBe(5000);
    expect(h.estado.pedidos).toHaveLength(1);
    expect(h.estado.pedidos[0].estado ?? 'pendiente').toBe('pendiente');
    expect(h.estado.items).toHaveLength(1);
    // El mail del pedido (link para reintentar o pasar a transferencia) sale igual.
    expect(h.estado.mails.map((m) => m.to[0])).toEqual(['ana@mail.com']);
  });

  it('con Mercado Pago andando sigue devolviendo el link de pago', async () => {
    const r = await pedir('POST', '/api/eventos/publico/COMUNION26-K7QF/pedidos', cuerpo);
    expect(r.status).toBe(200);
    expect(r.json.initPoint).toBe('https://mp/x');
    expect(r.json.mpNoDisponible).toBeUndefined();
    expect(h.estado.pedidos[0].mp_preference_id).toBe('pref');
  });

  it('frena por IP + email después de 6 pedidos en 10 minutos (los 400 no consumen el cupo)', async () => {
    for (let i = 0; i < 3; i++) await pedir('POST', '/api/eventos/publico/COMUNION26-K7QF/pedidos', { ...cuerpo, medioPago: 'nada' });
    const clave = [...h.estado.intentos.keys()].find((k) => k.startsWith('ev-pedido-email:'));
    expect(clave).toBeUndefined();
    for (let i = 0; i < 6; i++) {
      const r = await pedir('POST', '/api/eventos/publico/COMUNION26-K7QF/pedidos', { ...cuerpo, nino: { nombre: `Chico ${i}`, curso: '' } });
      expect(r.status).toBe(200);
    }
    const r7 = await pedir('POST', '/api/eventos/publico/COMUNION26-K7QF/pedidos', { ...cuerpo, nino: { nombre: 'Chico 7', curso: '' } });
    expect(r7.status).toBe(429);
    expect(h.estado.pedidos).toHaveLength(6);
  });
});

describe('05/10: procesarPagoAprobado (webhook de Mercado Pago)', () => {
  const pedidoBase = () => ({
    id: PEDIDO, numero: 'EV26-22222', evento_id: EVENTO, estado: 'pendiente', medio_pago: 'mercadopago', total: 5000,
    comprador_email: 'ana@mail.com', comprador_nombre: 'Ana Pérez', comprador_whatsapp: '1155556666', nino_nombre: 'Leo Pérez', nino_curso: null,
    email_digitales_enviado: false, mp_payment_id: null, notas: null, acepta_novedades: false,
    ev_items_pedido: [{ foto_id: FOTO, formato: 'digital', cantidad: 1, subtotal: 5000, incluye_digital: true, ev_fotos: { nombre_archivo: 'a.jpg' } }],
    ev_eventos: { codigo: 'COMUNION26-K7QF', nombre: 'Comunión' },
  });

  it('un pago con monto menor al total NO marca pagado y avisa al admin una sola vez', async () => {
    const { procesarPagoAprobado } = await import('../servidor');
    h.estado.pedidos.push(pedidoBase());
    const r1 = await procesarPagoAprobado(h.cliente as any, PEDIDO, 3000, { mp_payment_id: 'pago-1' }, 'http://local');
    expect(r1).toBe('rechazado');
    expect(h.estado.pedidos[0].estado).toBe('pendiente');
    expect(h.estado.pedidos[0].mp_payment_id).toBeNull();
    expect(h.estado.mails).toHaveLength(1);
    expect(h.estado.mails[0].subject).toContain('Monto insuficiente');
    expect(h.estado.mails[0].to[0]).not.toBe('ana@mail.com');
    // El mismo aviso repetido (Mercado Pago reintenta el webhook) no vuelve a avisar.
    const r2 = await procesarPagoAprobado(h.cliente as any, PEDIDO, 3000, { mp_payment_id: 'pago-1' }, 'http://local');
    expect(r2).toBe('rechazado');
    expect(h.estado.pedidos[0].estado).toBe('pendiente');
    expect(h.estado.mails).toHaveLength(1);
  });

  it('dos webhooks del mismo pago: se marca pagado una sola vez y un solo mail a la familia', async () => {
    const { procesarPagoAprobado } = await import('../servidor');
    h.estado.pedidos.push(pedidoBase());
    const r1 = await procesarPagoAprobado(h.cliente as any, PEDIDO, 5000, { mp_payment_id: 'pago-2' }, 'http://local');
    expect(r1).toBe('pagado');
    expect(h.estado.pedidos[0].estado).toBe('pagado');
    expect(h.estado.pedidos[0].mp_payment_id).toBe('pago-2');
    expect(h.estado.pedidos[0].email_digitales_enviado).toBe(true);
    const fechaPago = h.estado.pedidos[0].fecha_pago;
    const aFamilia = () => h.estado.mails.filter((m) => m.to[0] === 'ana@mail.com');
    expect(aFamilia()).toHaveLength(1);
    const r2 = await procesarPagoAprobado(h.cliente as any, PEDIDO, 5000, { mp_payment_id: 'pago-2' }, 'http://local');
    expect(r2).toBe('ya_pagado');
    expect(h.estado.pedidos[0].fecha_pago).toBe(fechaPago);
    expect(aFamilia()).toHaveLength(1);
    // Tampoco sale el aviso de "posible pago doble": es el MISMO pago.
    expect(h.estado.mails.some((m) => m.subject.includes('pago doble'))).toBe(false);
  });
});

describe('E3: galería pública', () => {
  it('responde igual si el código no existe o si el evento no está publicado (sin datos del evento)', async () => {
    h.estado.eventos.push({ id: EVENTO, codigo: 'OCULTO26', nombre: 'Secreto', lugar: 'Parroquia', fecha_evento: '2026-10-02', publicado: false });
    const noExiste = await pedir('GET', '/api/eventos/publico/NOEXISTE26');
    const oculto = await pedir('GET', '/api/eventos/publico/OCULTO26');
    expect(noExiste.status).toBe(oculto.status);
    expect(noExiste.json).toEqual({ success: true, proximamente: true, evento: { codigo: 'NOEXISTE26' } });
    expect(oculto.json).toEqual({ success: true, proximamente: true, evento: { codigo: 'OCULTO26' } });
    expect(oculto.texto).not.toContain('Secreto');
    expect(oculto.texto).not.toContain('Parroquia');
  });
  it('cuenta códigos distintos por IP: recargar el mismo código no suma', async () => {
    for (let i = 0; i < 5; i++) await pedir('GET', '/api/eventos/publico/MISMO26');
    const fallos = [...h.estado.intentos.entries()].filter(([k]) => k.startsWith('ev-galeria-fallos:'));
    expect(fallos).toHaveLength(1);
    expect(fallos[0][1]).toBe(1);
  });
});

describe('E2: baja de novedades', () => {
  it('el GET sólo muestra el botón; la baja se hace con POST a la misma URL', async () => {
    const { llaveBaja } = await import('../servidor');
    h.estado.suscriptores.push({ email: 'ana@mail.com', baja_en: null });
    const ruta = `/api/eventos/baja?e=${encodeURIComponent('ana@mail.com')}&t=${llaveBaja('ana@mail.com', 'secreto-de-prueba')}`;
    const get = await pedir('GET', ruta);
    expect(get.status).toBe(200);
    expect(get.texto).toContain('method="post"');
    expect(h.estado.suscriptores[0].baja_en).toBeNull();
    const post = await pedir('POST', ruta);
    expect(post.status).toBe(200);
    expect(post.texto).toContain('te diste de baja');
    expect(h.estado.suscriptores[0].baja_en).toBeTruthy();
  });
  it('rechaza una llave inválida', async () => {
    const r = await pedir('POST', '/api/eventos/baja?e=ana%40mail.com&t=cualquiera');
    expect(r.status).toBe(400);
  });
});

describe('E8: webhook de eventos', () => {
  it('sin MERCADOPAGO_WEBHOOK_SECRET falla cerrado (401)', async () => {
    process.env.MERCADOPAGO_ACCESS_TOKEN = 'prueba';
    try {
      const r = await pedir('POST', '/api/eventos/webhook-mp?type=payment&data.id=123', { type: 'payment', data: { id: '123' } });
      expect(r.status).toBe(401);
    } finally {
      delete process.env.MERCADOPAGO_ACCESS_TOKEN;
    }
  });

  // 10/10: Mercado Pago manda cada pago también como aviso IPN (`?topic=…&id=…`), que no se puede validar
  // con la clave secreta. Se contesta 200 sin tocar nada (antes 401 → MP lo reintentaba durante días).
  it('un aviso IPN (topic + id, sin data.id) se contesta 200 sin procesar nada', async () => {
    process.env.MERCADOPAGO_ACCESS_TOKEN = 'prueba';
    process.env.MERCADOPAGO_WEBHOOK_SECRET = 'clave-de-prueba';
    try {
      const antes = h.estado.operaciones.length;
      for (const ruta of ['/api/eventos/webhook-mp?topic=payment&id=123', '/api/eventos/webhook-mp?topic=merchant_order&id=456']) {
        const r = await pedir('POST', ruta, { resource: '123', topic: 'payment' });
        expect(r.status).toBe(200);
      }
      expect(h.estado.operaciones.length).toBe(antes);
    } finally {
      delete process.env.MERCADOPAGO_ACCESS_TOKEN;
      delete process.env.MERCADOPAGO_WEBHOOK_SECRET;
    }
  });

  it('un aviso por Webhooks (data.id) sin firma válida se sigue rechazando con 401', async () => {
    process.env.MERCADOPAGO_ACCESS_TOKEN = 'prueba';
    process.env.MERCADOPAGO_WEBHOOK_SECRET = 'clave-de-prueba';
    try {
      const r = await pedir('POST', '/api/eventos/webhook-mp?type=payment&data.id=123', { type: 'payment', data: { id: '123' } });
      expect(r.status).toBe(401);
    } finally {
      delete process.env.MERCADOPAGO_ACCESS_TOKEN;
      delete process.env.MERCADOPAGO_WEBHOOK_SECRET;
    }
  });
});


describe('04/10: lupa de la galería de eventos', () => {
  function pedirImagen(ruta: string): Promise<{ status: number; headers: http.IncomingHttpHeaders; cuerpo: Buffer }> {
    return new Promise((ok, mal) => {
      http.get({ host: '127.0.0.1', port: puerto, path: ruta }, (res) => {
        const partes: Buffer[] = [];
        res.on('data', (c) => partes.push(c));
        res.on('end', () => ok({ status: res.statusCode || 0, headers: res.headers, cuerpo: Buffer.concat(partes) }));
      }).on('error', mal);
    });
  }
  const FOTO2 = '44444444-4444-4444-4444-444444444444';
  let bajadas = 0;
  beforeEach(async () => {
    const sharp = (await import('sharp')).default;
    const original = await sharp({ create: { width: 1200, height: 800, channels: 3, background: { r: 200, g: 120, b: 40 } } }).jpeg().toBuffer();
    bajadas = 0;
    (h.cliente.storage as any).from = () => ({
      download: async (ruta: string) => {
        // 09/10: la copia de la lupa (`.lupa.jpg`) todavía no existe: se arma desde el original.
        if (ruta.endsWith('.lupa.jpg')) return { data: null, error: new Error('Object not found') };
        bajadas++;
        return { data: new Blob([new Uint8Array(original)]), error: null };
      },
      upload: async () => ({ data: {}, error: null }),
    });
    h.estado.eventos.push({ id: EVENTO, codigo: 'CONF26-AB12', publicado: true, muestras_lupa: true });
    h.estado.fotos.push({ id: FOTO, evento_id: EVENTO, storage_path_hd: `${EVENTO}/${FOTO}.jpg` });
  });
  afterAll(() => {
    (h.cliente.storage as any).from = () => ({});
  });

  it('devuelve sólo el pedacito pedido (JPEG) con la región real en el encabezado', async () => {
    const r = await pedirImagen(`/api/eventos/publico/CONF26-AB12/lupa/${FOTO}?cx=0.5&cy=0.5&s=0.5`);
    expect(r.status).toBe(200);
    expect(r.headers['content-type']).toBe('image/jpeg');
    expect(r.headers['x-lupa-region']).toBe('300,100,600,600,1200,800');
    expect(r.headers['cache-control']).toBe('private, max-age=3600');
    expect(r.cuerpo.subarray(0, 2).toString('hex')).toBe('ffd8');
    // Un segundo pedido de la misma foto no vuelve a bajar el original.
    const r2 = await pedirImagen(`/api/eventos/publico/CONF26-AB12/lupa/${FOTO}?cx=0.2&cy=0.3&s=0.3`);
    expect(r2.status).toBe(200);
    expect(bajadas).toBe(1);
  });

  it('no muestra fotos de un evento sin publicar ni de otro evento', async () => {
    h.estado.eventos.push({ id: '55555555-5555-5555-5555-555555555555', codigo: 'OCULTO-ZZ99', publicado: false });
    h.estado.fotos.push({ id: FOTO2, evento_id: '55555555-5555-5555-5555-555555555555', storage_path_hd: 'x.jpg' });
    expect((await pedirImagen(`/api/eventos/publico/OCULTO-ZZ99/lupa/${FOTO2}?cx=0.5&cy=0.5&s=0.5`)).status).toBe(404);
    expect((await pedirImagen(`/api/eventos/publico/CONF26-AB12/lupa/${FOTO2}?cx=0.5&cy=0.5&s=0.5`)).status).toBe(404);
    expect(bajadas).toBe(0);
  });

  it('con «Muestras con lupa» apagado en el evento no hay lupa', async () => {
    h.estado.eventos.push({ id: '66666666-6666-6666-6666-666666666666', codigo: 'SINLUPA-QQ77', publicado: true, muestras_lupa: false });
    h.estado.fotos.push({ id: FOTO2, evento_id: '66666666-6666-6666-6666-666666666666', storage_path_hd: 'y.jpg' });
    expect((await pedirImagen(`/api/eventos/publico/SINLUPA-QQ77/lupa/${FOTO2}?cx=0.5&cy=0.5&s=0.5`)).status).toBe(404);
    expect(bajadas).toBe(0);
  });

  it('rechaza pedidos mal armados', async () => {
    expect((await pedirImagen(`/api/eventos/publico/CONF26-AB12/lupa/${FOTO}?cx=2&cy=0.5&s=0.5`)).status).toBe(400);
    expect((await pedirImagen(`/api/eventos/publico/CONF26-AB12/lupa/no-es-uuid?cx=0.5&cy=0.5&s=0.5`)).status).toBe(400);
    expect((await pedirImagen(`/api/eventos/publico/CONF26-AB12/lupa/${FOTO}`)).status).toBe(400);
  });
});

describe('27/10: código de descuento en pedidos de eventos', () => {
  const FOTO2 = '44444444-4444-4444-4444-444444444444';
  const base = {
    aceptaCondiciones: true,
    comprador: { nombre: 'Laura Gómez', whatsapp: '1155556666', email: 'laura@mail.com' },
    nino: { nombre: 'Renata y Emma', curso: '' },
  };
  const codigo = (extra: Record<string, unknown> = {}) => ({ codigo: 'DOCENTES26', porcentaje: 100, usos_max: null, usos: 0, vence_at: null, activo: true, sin_tope_impreso: false, ambito: 'eventos', ...extra });
  beforeEach(() => {
    h.estado.eventos.push({ id: EVENTO, codigo: 'BROTHERS2026-D3EB', nombre: 'Fotos de Hermanos juntos', publicado: true, fecha_limite: null, precio_digital: 5000, precio_15x21: 8000, precio_20x30: 12000, impresa_incluye_digital: true });
    h.estado.fotos.push({ id: FOTO, evento_id: EVENTO }, { id: FOTO2, evento_id: EVENTO });
  });

  it('al 100% en digitales el pedido nace pagado «bonificado», sin medio de pago, y manda el mail con la descarga', async () => {
    h.estado.codigos.push(codigo());
    const r = await pedir('POST', '/api/eventos/publico/BROTHERS2026-D3EB/pedidos', { ...base, codigoDescuento: ' docentes26 ', items: [{ fotoId: FOTO, formato: 'digital', cantidad: 1 }, { fotoId: FOTO2, formato: 'digital', cantidad: 1 }] });
    expect(r.status).toBe(200);
    expect(r.json).toMatchObject({ success: true, total: 0, bonificado: true });
    expect(r.json.llave).toBeTruthy();
    const p = h.estado.pedidos[0];
    expect(p).toMatchObject({ estado: 'pagado', medio_pago: 'bonificado', total: 0, codigo_descuento: 'DOCENTES26', descuento_pct: 100, descuento_monto: 10000 });
    expect(h.estado.codigos[0].usos).toBe(1);
    expect(h.estado.mails.map((m) => m.to[0])).toContain('laura@mail.com');
    expect(h.estado.mails.find((m) => m.to[0] === 'laura@mail.com')!.subject).toContain('Gracias por tu compra');
  });

  it('en copias impresas el 100% llega al 70% (salvo «sin tope») y hay que elegir cómo pagar', async () => {
    h.estado.codigos.push(codigo());
    const items = [{ fotoId: FOTO, formato: '15x21', cantidad: 1 }];
    const sinMedio = await pedir('POST', '/api/eventos/publico/BROTHERS2026-D3EB/pedidos', { ...base, codigoDescuento: 'DOCENTES26', items });
    expect(sinMedio.status).toBe(400);
    expect(sinMedio.json.error).toBe('Elegí cómo vas a pagar.');
    expect(h.estado.codigos[0].usos).toBe(0); // no se gastó el uso
    const r = await pedir('POST', '/api/eventos/publico/BROTHERS2026-D3EB/pedidos', { ...base, medioPago: 'transferencia', codigoDescuento: 'DOCENTES26', items });
    expect(r.status).toBe(200);
    expect(r.json.total).toBe(2400); // 8000 - 70%
    expect(h.estado.pedidos[0]).toMatchObject({ estado: 'pendiente', medio_pago: 'transferencia', total: 2400, descuento_monto: 5600 });
  });

  it('con «sin tope» la impresa también sale sin cargo', async () => {
    h.estado.codigos.push(codigo({ sin_tope_impreso: true }));
    const r = await pedir('POST', '/api/eventos/publico/BROTHERS2026-D3EB/pedidos', { ...base, codigoDescuento: 'DOCENTES26', items: [{ fotoId: FOTO, formato: '20x30', cantidad: 2 }] });
    expect(r.status).toBe(200);
    expect(r.json.bonificado).toBe(true);
    expect(h.estado.pedidos[0]).toMatchObject({ estado: 'pagado', medio_pago: 'bonificado', total: 0, descuento_monto: 24000 });
  });

  it('un código del kit (o agotado) no sirve en eventos y no se registra el pedido', async () => {
    h.estado.codigos.push(codigo({ codigo: 'KIT-100', ambito: 'kit' }), codigo({ codigo: 'AGOTADO', usos_max: 1, usos: 1 }));
    for (const c of ['KIT-100', 'AGOTADO', 'NO-EXISTE']) {
      const r = await pedir('POST', '/api/eventos/publico/BROTHERS2026-D3EB/pedidos', { ...base, medioPago: 'transferencia', codigoDescuento: c, items: [{ fotoId: FOTO, formato: 'digital', cantidad: 1 }] });
      expect(r.status).toBe(400);
      expect(r.json.codigoInvalido).toBe(true);
    }
    expect(h.estado.pedidos).toHaveLength(0);
    const v = await pedir('POST', '/api/eventos/publico/BROTHERS2026-D3EB/descuento', { codigo: 'KIT-100' });
    expect(v.status).toBe(404);
  });

  it('validar el código devuelve el porcentaje y si tiene tope', async () => {
    h.estado.codigos.push(codigo({ porcentaje: 50 }));
    const v = await pedir('POST', '/api/eventos/publico/BROTHERS2026-D3EB/descuento', { codigo: 'docentes26' });
    expect(v.status).toBe(200);
    expect(v.json).toEqual({ success: true, codigo: 'DOCENTES26', porcentaje: 50, sinTopeImpreso: false });
  });

  it('sin código todo sigue igual (transferencia por el total)', async () => {
    const r = await pedir('POST', '/api/eventos/publico/BROTHERS2026-D3EB/pedidos', { ...base, medioPago: 'transferencia', items: [{ fotoId: FOTO, formato: 'digital', cantidad: 1 }] });
    expect(r.status).toBe(200);
    expect(r.json.total).toBe(5000);
    expect(h.estado.pedidos[0].codigo_descuento).toBeUndefined();
  });
});
