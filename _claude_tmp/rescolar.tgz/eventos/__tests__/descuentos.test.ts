// 27/10/2026: cálculo del descuento por código en los pedidos de eventos (función pura).
import { describe, it, expect } from 'vitest';
import { descuentoDelPedido, porcentajeParaLinea, TOPE_DESCUENTO_IMPRESO_EVENTO } from '../descuentos';

describe('descuento en pedidos de eventos', () => {
  it('digital hasta 100%; impresa hasta 70% salvo «sin tope»', () => {
    expect(porcentajeParaLinea('digital', 100)).toBe(100);
    expect(porcentajeParaLinea('15x21', 100)).toBe(TOPE_DESCUENTO_IMPRESO_EVENTO);
    expect(porcentajeParaLinea('20x30', 100, true)).toBe(100);
    expect(porcentajeParaLinea('15x21', 50)).toBe(50);
  });
  it('suma por línea, redondea a pesos y nunca supera el total', () => {
    const items = [{ formato: 'digital' as const, subtotal: 5000 }, { formato: '15x21' as const, subtotal: 16000 }];
    expect(descuentoDelPedido(items, null)).toBe(0);
    expect(descuentoDelPedido(items, { porcentaje: 100, sinTopeImpreso: false })).toBe(5000 + 11200);
    expect(descuentoDelPedido(items, { porcentaje: 100, sinTopeImpreso: true })).toBe(21000);
    expect(descuentoDelPedido([{ formato: 'digital', subtotal: 4999 }], { porcentaje: 33, sinTopeImpreso: false })).toBe(1650);
  });
});
