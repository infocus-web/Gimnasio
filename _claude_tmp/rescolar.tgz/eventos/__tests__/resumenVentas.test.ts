// @vitest-environment jsdom
// 11/10/2026: compras nuevas y recaudado en la tarjeta de cada evento (eventos/resumenVentas.ts + public/eventos/ventas.js).
import { describe, it, expect } from 'vitest';
import { readFileSync } from 'fs';
import path from 'path';
import { resumirVentas, ventasVacias, type FilaVenta } from '../resumenVentas';

const fila = (evento_id: string, estado: string, total: number, fecha_pago: string | null = null, comprobante_subido_en: string | null = null): FilaVenta =>
  ({ evento_id, estado, total, fecha_pago, comprobante_subido_en });

describe('resumirVentas', () => {
  it('suma sólo lo pagado y cuenta como nuevas las pagadas después de la última vista', () => {
    const filas = [
      fila('A', 'pagado', 5000, '2026-10-10T10:00:00Z'),
      fila('A', 'pagado', 8000, '2026-10-11T15:00:00Z'),
      fila('A', 'pagado', 12000, '2026-10-11T18:00:00Z'),
      fila('A', 'pendiente', 9999),
      fila('A', 'pendiente', 4000, null, '2026-10-11T12:00:00Z'),
      fila('A', 'cancelado', 7000, '2026-10-11T19:00:00Z'),
    ];
    const r = resumirVentas(filas, new Map([['A', '2026-10-11T12:00:00Z']])).get('A')!;
    expect(r).toEqual({ pagados: 3, recaudado: 25000, nuevas: 2, por_revisar: 1 });
  });

  it('si nunca se abrieron los pedidos, todo lo pagado es nuevo; un evento sin pedidos no aparece', () => {
    const m = resumirVentas([fila('B', 'pagado', 5000, '2026-10-01T10:00:00Z'), fila('B', 'pagado', 5000, null)], new Map([['B', null], ['C', null]]));
    expect(m.get('B')).toEqual({ pagados: 2, recaudado: 10000, nuevas: 2, por_revisar: 0 });
    expect(m.get('C')).toBeUndefined();
    expect(ventasVacias()).toEqual({ pagados: 0, recaudado: 0, nuevas: 0, por_revisar: 0 });
  });

  it('un pagado sin fecha de pago no cuenta como nuevo si el evento ya se vio', () => {
    const r = resumirVentas([fila('A', 'pagado', 5000, null)], new Map([['A', '2026-10-11T12:00:00Z']])).get('A')!;
    expect(r.nuevas).toBe(0);
  });
});

describe('ventas.js (tarjeta del panel)', () => {
  // eslint-disable-next-line no-new-func
  new Function(readFileSync(path.resolve(__dirname, '../../public/eventos/ventas.js'), 'utf8'))();
  const el = (tag: string, clase: string, texto?: string) => { const n = document.createElement(tag); if (clase) n.className = clase; if (texto != null) n.textContent = texto; return n; };
  const pesos = (n: number) => '$' + Number(n || 0).toLocaleString('es-AR');
  const bloque = (ventas: unknown) => (window as any).VentasEvento.bloque({ ventas }, el, pesos) as HTMLElement;

  it('muestra compras nuevas, comprobantes y el recaudado', () => {
    const b = bloque({ pagados: 3, recaudado: 25000, nuevas: 2, por_revisar: 1 });
    expect(b.querySelector('.chip-nueva')!.textContent).toContain('2 compras nuevas');
    expect(b.querySelector('.chip-pend')!.textContent).toBe('1 comprobante para revisar');
    expect(b.querySelector('.ventas-total')!.textContent).toBe(pesos(25000) + ' recaudado · 3 pedidos pagados');
  });

  it('sin ventas no muestra chips', () => {
    const b = bloque(undefined);
    expect(b.querySelector('.chip')).toBeNull();
    expect(b.textContent).toBe('Sin ventas todavía');
  });
});
