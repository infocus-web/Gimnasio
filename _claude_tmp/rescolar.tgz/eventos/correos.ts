// Plantillas de correo del módulo de eventos (propias: no son las de "kit escolar").
import type { FormatoEvento } from './precios';

export const DATOS_TRANSFERENCIA = {
  alias: 'RETRATO.ESCOLAR',
  cbu: '0070313830004052956749',
  banco: 'Banco Galicia',
  titular: 'Alderete Pablo Gabriel',
};
export const PLAZO_TRANSFERENCIA_HORAS = 48;

// 10/10/2026 (Pablo): las copias impresas se entregan dentro de los 10 días hábiles posteriores al cierre
// de pedidos del evento (su fecha límite) o al pago, lo que pase último; sin fecha límite, desde el pago.
// 11/10/2026: hay dos envíos al laboratorio (mitad del plazo y cierre): ver fechaPrimerEnvio en precios.ts.
// Ley 24.240, art. 10 inc. e): hay que informar el plazo de entrega. Mismo número en public/eventos.html,
// public/eventos/familias.js y el contexto de la IA (servidor/familias/consultas.ts).
export const DIAS_HABILES_ENTREGA_IMPRESAS = 10;

/**
 * «dentro de los 10 días hábiles posteriores al primer envío al laboratorio (el 23/10)», «… al cierre de
 * pedidos del evento (el 07/11)» o «… a la confirmación del pago». Con primerEnvio (ver fechaPrimerEnvio en
 * precios.ts), lo pagado hasta el fin de ese día va en el 1.º envío; si no, en el del cierre.
 */
export function textoPlazoImpresas(fechaLimite: string | null | undefined, pagadoEn?: string | number | null, primerEnvio?: string | null): string {
  const finDelDia = (f: string | null | undefined) => {
    const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(String(f || ''));
    return m ? { fin: Date.parse(`${m[1]}-${m[2]}-${m[3]}T23:59:59.999-03:00`), dm: `${m[3]}/${m[2]}` } : null;
  };
  const pago = typeof pagadoEn === 'number' ? pagadoEn : Date.parse(String(pagadoEn || ''));
  const momentoPago = Number.isFinite(pago) ? pago : Date.now();
  const cierre = finDelDia(fechaLimite);
  const primero = cierre ? finDelDia(primerEnvio) : null;
  let desde = 'a la confirmación del pago';
  if (primero && Number.isFinite(primero.fin) && primero.fin < cierre!.fin && momentoPago <= primero.fin) {
    desde = `al primer envío al laboratorio (el ${primero.dm})`;
  } else if (cierre && Number.isFinite(cierre.fin) && momentoPago <= cierre.fin) {
    desde = `al cierre de pedidos del evento (el ${cierre.dm})`;
  }
  return `dentro de los ${DIAS_HABILES_ENTREGA_IMPRESAS} días hábiles posteriores ${desde}`;
}

export function escapeHtml(valor: unknown): string {
  return String(valor ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

export const pesos = (n: number) => `$${Math.round(Number(n) || 0).toLocaleString('es-AR')}`;

export function fechaHoraArgentina(fecha: Date | string): string {
  const d = typeof fecha === 'string' ? new Date(fecha) : fecha;
  return new Intl.DateTimeFormat('es-AR', {
    timeZone: 'America/Argentina/Buenos_Aires',
    weekday: 'long', day: 'numeric', month: 'numeric', hour: '2-digit', minute: '2-digit', hourCycle: 'h23',
  }).format(d);
}

const NOMBRE_FORMATO: Record<FormatoEvento, string> = { digital: 'Digital', '15x21': 'Impresa 15x21', '20x30': 'Impresa 20x30' };

export interface DatosCorreoPedido {
  numero: string;
  eventoNombre: string;
  compradorNombre: string;
  ninoNombre: string;
  ninoCurso?: string | null;
  total: number;
  /** 27/10/2026: descuento por código (el total ya lo tiene restado). */
  descuento?: { codigo: string; monto: number } | null;
  urlPedido: string;
  items: Array<{ nombre_archivo: string; formato: FormatoEvento; cantidad: number; subtotal: number }>;
  venceEn?: string | null;
}

function marco(contenido: string): string {
  return `<div style="font-family:Arial,Helvetica,sans-serif;max-width:600px;margin:auto;color:#0f172a;line-height:1.5">
<div style="background:#0f172a;color:#fff;padding:14px 18px;border-radius:12px 12px 0 0;font-weight:bold">Retrato Escolar <span style="color:#f59e0b">· Fotos de eventos</span></div>
<div style="border:1px solid #e2e8f0;border-top:none;border-radius:0 0 12px 12px;padding:18px">${contenido}
<p style="color:#64748b;font-size:12px;margin-top:24px">Si tenés alguna duda, respondé este correo.</p></div></div>`;
}

function boton(url: string, texto: string): string {
  return `<p style="text-align:center;margin:22px 0"><a href="${escapeHtml(url)}" style="background:#f59e0b;color:#0f172a;text-decoration:none;font-weight:bold;padding:12px 22px;border-radius:10px;display:inline-block">${escapeHtml(texto)}</a></p>`;
}

function tablaItems(d: DatosCorreoPedido): string {
  const filas = d.items
    .map((it) => `<tr><td style="padding:4px 0">${escapeHtml(it.nombre_archivo)}</td><td>${NOMBRE_FORMATO[it.formato]}${it.formato !== 'digital' ? ` × ${it.cantidad}` : ''}</td><td style="text-align:right">${pesos(it.subtotal)}</td></tr>`)
    .join('');
  const filaDescuento = d.descuento && d.descuento.monto > 0
    ? `<tr><td colspan="2" style="padding:4px 0">Descuento${d.descuento.codigo ? ` (código ${escapeHtml(d.descuento.codigo)})` : ''}</td><td style="text-align:right">−${pesos(d.descuento.monto)}</td></tr>`
    : '';
  return `<table style="width:100%;font-size:13px;border-collapse:collapse;margin:10px 0">${filas}${filaDescuento}<tr><td colspan="2" style="border-top:1px solid #e2e8f0;padding-top:6px"><strong>Total</strong></td><td style="text-align:right;border-top:1px solid #e2e8f0;padding-top:6px"><strong>${pesos(d.total)}</strong></td></tr></table>`;
}

function para(d: DatosCorreoPedido): string {
  return `${escapeHtml(d.ninoNombre)}${d.ninoCurso ? ` (${escapeHtml(d.ninoCurso)})` : ''}`;
}

export function correoTransferenciaPendiente(d: DatosCorreoPedido): { subject: string; html: string } {
  const datos = DATOS_TRANSFERENCIA;
  return {
    subject: `Tu pedido ${d.numero} — datos para transferir`,
    html: marco(`<p>¡Hola ${escapeHtml(d.compradorNombre)}!</p>
<p>Registramos tu pedido <strong>${escapeHtml(d.numero)}</strong> de fotos de <strong>${escapeHtml(d.eventoNombre)}</strong> para ${para(d)}.</p>
${tablaItems(d)}
<p>Transferí <strong>${pesos(d.total)}</strong> a:</p>
<div style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:10px;padding:12px 14px;font-size:14px">
<strong>Alias:</strong> <span style="font-family:monospace">${datos.alias}</span><br>
<strong>CBU:</strong> <span style="font-family:monospace">${datos.cbu}</span> · ${datos.banco}<br>
<strong>Titular:</strong> ${datos.titular}</div>
<p>Después subí la captura del comprobante desde acá:</p>
${boton(d.urlPedido, 'Subir el comprobante')}
${d.venceEn ? `<p style="background:#fff7ed;border:1px solid #fdba74;border-radius:10px;padding:10px 12px"><strong>Importante:</strong> si no recibimos el comprobante antes del <strong>${escapeHtml(fechaHoraArgentina(d.venceEn))}</strong>, el pedido se cancela automáticamente.</p>` : ''}`),
  };
}

/** Pedido con Mercado Pago recién creado: el link para volver a pagarlo (o pasar a transferencia). */
export function correoPagoPendienteMp(d: DatosCorreoPedido): { subject: string; html: string } {
  return {
    subject: `Tu pedido ${d.numero} — completá el pago`,
    html: marco(`<p>¡Hola ${escapeHtml(d.compradorNombre)}!</p>
<p>Registramos tu pedido <strong>${escapeHtml(d.numero)}</strong> de fotos de <strong>${escapeHtml(d.eventoNombre)}</strong> para ${para(d)}.</p>
${tablaItems(d)}
<p>Si ya pagaste con Mercado Pago, no tenés que hacer nada: en unos minutos te llega la confirmación.</p>
<p>Si el pago no salió o lo cerraste, podés volver a intentarlo (o pagar por transferencia) desde acá:</p>
${boton(d.urlPedido, 'Ver mi pedido')}`),
  };
}

export const INSTAGRAM = { usuario: '@retratoescolar.com.ar', url: 'https://www.instagram.com/retratoescolar.com.ar' };

/**
 * Mail de pago confirmado = también el agradecimiento (pedido de Pablo, 3/10): gracias por elegirnos,
 * descarga, oferta de copias impresas (vuelven a la galería y hacen un pedido nuevo) y recomendación.
 */
export function correoPagoConfirmado(d: DatosCorreoPedido & { hayDigitales: boolean; hayImpresas: boolean; urlGaleria?: string | null; fechaLimite?: string | null; pagadoEn?: string | null; primerEnvio?: string | null }): { subject: string; html: string } {
  const primerNombre = escapeHtml(String(d.compradorNombre || '').trim().split(/\s+/)[0] || '');
  const bloque = (fondo: string, borde: string, contenido: string) =>
    `<div style="background:${fondo};border:1px solid ${borde};border-radius:12px;padding:14px 16px;margin:18px 0">${contenido}</div>`;
  return {
    subject: `¡Gracias por tu compra! Pedido ${d.numero}${d.hayDigitales ? ' — tus fotos ya están listas' : ''}`,
    html: marco(`<h2 style="margin:0 0 6px;font-size:22px">¡Gracias por elegirnos${primerNombre ? `, ${primerNombre}` : ''}! 💛</h2>
<p style="margin-top:0">${d.total === 0 ? 'Confirmamos tu pedido sin cargo' : 'Confirmamos el pago de tu pedido'} <strong>${escapeHtml(d.numero)}</strong> de <strong>${escapeHtml(d.eventoNombre)}</strong> para ${para(d)}. Nos encanta que estos recuerdos queden con ustedes.</p>
${tablaItems(d)}
${d.hayDigitales ? `<p>Ya podés descargar tus fotos digitales en alta resolución, sin marca de agua:</p>${boton(d.urlPedido, 'Descargar mis fotos')}<p style="font-size:13px;color:#64748b;text-align:center;margin-top:-8px">Guardá este correo: el botón sigue funcionando para volver a descargarlas.</p>` : ''}
${d.hayImpresas ? `<p>Las copias impresas pasan al laboratorio y se entregan ${textoPlazoImpresas(d.fechaLimite, d.pagadoEn, d.primerEnvio)}. <strong>Te avisamos por este medio cuando estén listas para retirar.</strong></p>` : ''}
${!d.hayDigitales ? boton(d.urlPedido, 'Ver mi pedido') : ''}
${d.urlGaleria ? bloque('#fffbeb', '#fde68a', `<p style="margin:0 0 6px;font-weight:bold">🖼️ ¿Querés alguna en papel?</p>
<p style="margin:0 0 12px;font-size:14px">Podés pedir copias impresas 15x21 o 20x30 de tus fotos desde la galería del evento. Se hacen en laboratorio profesional.</p>
<p style="margin:0"><a href="${escapeHtml(d.urlGaleria)}" style="background:#0f172a;color:#ffffff;text-decoration:none;font-weight:bold;padding:10px 18px;border-radius:10px;display:inline-block">Pedir copias impresas</a></p>`) : ''}
${bloque('#f8fafc', '#e2e8f0', `<p style="margin:0 0 6px;font-weight:bold">🙌 ¿Te gustó el servicio?</p>
<p style="margin:0;font-size:14px">Recomendanos a otras familias del colegio, ¡nos ayuda muchísimo! Y seguinos en Instagram: <a href="${INSTAGRAM.url}" style="color:#b45309;font-weight:bold;text-decoration:none">${INSTAGRAM.usuario}</a></p>`)}
<p>Gracias por confiar en Retrato Escolar.<br><strong>Pablo</strong></p>`),
  };
}

export function correoAvisoAdmin(titulo: string, d: DatosCorreoPedido & { compradorEmail: string; compradorWhatsapp: string; medioPago: string }, extra = ''): { subject: string; html: string } {
  return {
    subject: `${titulo} ${d.numero} · ${pesos(d.total)} · ${d.ninoNombre}`,
    html: `<div style="font-family:Arial,sans-serif;max-width:640px;margin:auto;color:#0f172a"><h2>${escapeHtml(titulo)}</h2>
<p><strong>Evento:</strong> ${escapeHtml(d.eventoNombre)}<br><strong>Pedido:</strong> ${escapeHtml(d.numero)} · ${escapeHtml(d.medioPago)}<br>
<strong>Para:</strong> ${para(d)}<br><strong>Comprador:</strong> ${escapeHtml(d.compradorNombre)} · ${escapeHtml(d.compradorEmail)} · WhatsApp ${escapeHtml(d.compradorWhatsapp)}</p>
${tablaItems(d)}${extra}<p>Panel: <a href="https://www.retratoescolar.com.ar/eventos-admin">retratoescolar.com.ar/eventos-admin</a></p></div>`,
  };
}

export function correoListoRetiro(d: DatosCorreoPedido, lugarRetiro: string | null): { subject: string; html: string } {
  const impresas = d.items.filter((it) => it.formato !== 'digital');
  const lista = impresas.map((it) => `<li>${escapeHtml(it.nombre_archivo)} — ${NOMBRE_FORMATO[it.formato]} × ${it.cantidad}</li>`).join('');
  return {
    subject: `¡Tus fotos impresas están listas para retirar! Pedido ${d.numero}`,
    html: marco(`<p>¡Hola ${escapeHtml(d.compradorNombre)}!</p>
<p>Las copias impresas de <strong>${escapeHtml(d.eventoNombre)}</strong> para ${para(d)} (pedido <strong>${escapeHtml(d.numero)}</strong>) ya están listas.</p>
<ul style="font-size:14px">${lista}</ul>
${lugarRetiro ? `<p style="background:#ecfdf5;border:1px solid #a7f3d0;border-radius:10px;padding:10px 12px"><strong>Dónde retirarlas:</strong> ${escapeHtml(lugarRetiro)}</p>` : '<p>Respondé este correo y coordinamos la entrega.</p>'}
<p style="font-size:13px;color:#64748b">Al retirar, mencioná el número de pedido o el nombre de ${escapeHtml(d.ninoNombre)}.</p>
${boton(d.urlPedido, 'Ver mi pedido')}`),
  };
}

export function correoFotosOnline(eventoNombre: string, url: string, codigo?: string): { subject: string; html: string } {
  const urlCorta = url.replace(/^https?:\/\/(www\.)?/, '');
  return {
    subject: `¡Ya están online las fotos de ${eventoNombre}!`,
    html: marco(`<p>¡Hola!</p>
<p>Te anotaste para que te avisemos: <strong>ya están online las fotos de ${escapeHtml(eventoNombre)}</strong>.</p>
<p>Entrá, mirá la galería y elegí tus favoritas en digital o impresas.</p>
${boton(url, 'Ver las fotos')}
${codigo ? `<div style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:10px;padding:12px 14px;font-size:14px;text-align:center">
Si el botón no funciona, entrá a <strong>${escapeHtml(urlCorta)}</strong><br>
o a <strong>retratoescolar.com.ar/eventos</strong> con el código <strong style="font-family:monospace;font-size:16px;letter-spacing:.05em">${escapeHtml(codigo)}</strong></div>` : ''}
<p style="font-size:13px;color:#64748b">Te escribimos sólo esta vez porque nos pediste que te avisemos.</p>`),
  };
}
