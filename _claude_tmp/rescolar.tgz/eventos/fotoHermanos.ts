// Foto de hermanos (08/10): evento «Fotos de Hermanos juntos» (BROTHERS2026-D3EB). Funciones puras.
// 14/10/2026: se sacaron tal cual de servidor.ts (techo de líneas); servidor.ts las reexporta.
export function esEventoFotoHermanos(nombre: unknown, codigo?: unknown): boolean {
  return /^BROTHERS/i.test(String(codigo ?? '')) || /\bfotos?\s+de\s+hermanos\b|\bhermanos\s+juntos\b/i.test(String(nombre ?? ''));
}

const EMAIL_AVISO_VALIDO = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

function listaHermanos(valor: unknown): unknown[] {
  if (Array.isArray(valor)) return valor;
  if (typeof valor === 'string') {
    try {
      const v = JSON.parse(valor);
      return Array.isArray(v) ? v : [];
    } catch {
      return [];
    }
  }
  return [];
}

/** Emails (en minúscula, sin repetir) de las familias que quieren la foto de hermanos y de las que no. */
export function emailsFotoHermanos(filas: any[]): { si: string[]; no: string[] } {
  const si = new Set<string>();
  const no = new Set<string>();
  for (const f of filas || []) {
    if (!f || f.estado !== 'aceptado' || !f.foto_hermanos_confirmada_at) continue;
    if (listaHermanos(f.hermanos).length === 0) continue;
    const email = String(f.foto_hermanos_email || f.email || '').trim().toLowerCase();
    if (email.length < 5 || email.length > 160 || !EMAIL_AVISO_VALIDO.test(email)) continue;
    (f.solicita_foto_hermanos === true ? si : no).add(email);
  }
  for (const email of si) no.delete(email);
  return { si: [...si], no: [...no] };
}
