// 11/10/2026 (Pablo): «ver si hay compras nuevas desde la miniatura de cada evento, y el importe recaudado
// hasta la fecha». Resumen de ventas por evento para las tarjetas de /eventos-admin.
//
// - recaudado / pagados: pedidos en estado `pagado` (lo mismo que suma «cobrados» dentro del evento).
// - nuevas: pagados con `fecha_pago` posterior a la última vez que Pablo abrió los pedidos de ese evento
//   (`ev_eventos.pedidos_vistos_en`, lo actualiza GET /api/eventos/admin/eventos/:id/pedidos). Null = nunca
//   los abrió: todos los pagados cuentan como nuevos.
// - por_revisar: transferencias con comprobante subido esperando que Pablo las apruebe.
import type { SupabaseClient } from '@supabase/supabase-js';

export interface VentasEvento { pagados: number; recaudado: number; nuevas: number; por_revisar: number }

export interface FilaVenta {
  evento_id: string;
  estado: string;
  total: number | null;
  fecha_pago: string | null;
  comprobante_subido_en: string | null;
}

type Paginador = <T>(armar: (desde: number, hasta: number) => PromiseLike<{ data: T[] | null; error: any }>) => Promise<T[]>;

export const ventasVacias = (): VentasEvento => ({ pagados: 0, recaudado: 0, nuevas: 0, por_revisar: 0 });

export function resumirVentas(filas: FilaVenta[], vistosEn: Map<string, string | null | undefined>): Map<string, VentasEvento> {
  const salida = new Map<string, VentasEvento>();
  for (const f of filas) {
    let r = salida.get(f.evento_id);
    if (!r) { r = ventasVacias(); salida.set(f.evento_id, r); }
    if (f.estado === 'pagado') {
      r.pagados++;
      r.recaudado += Number(f.total) || 0;
      const visto = vistosEn.get(f.evento_id);
      const vistoMs = visto ? Date.parse(visto) : NaN;
      if (Number.isNaN(vistoMs) || (f.fecha_pago && Date.parse(f.fecha_pago) > vistoMs)) r.nuevas++;
    } else if (f.estado === 'pendiente' && f.comprobante_subido_en) {
      r.por_revisar++;
    }
  }
  return salida;
}

/** Lee los pedidos pagados o pendientes de todos los eventos (sólo 5 columnas) y los resume por evento. */
export async function ventasPorEvento(
  sb: SupabaseClient,
  paginar: Paginador,
  eventos: { id: string; pedidos_vistos_en?: string | null }[],
): Promise<Map<string, VentasEvento>> {
  const filas = await paginar<FilaVenta>((d, h) =>
    sb.from('ev_pedidos').select('evento_id, estado, total, fecha_pago, comprobante_subido_en')
      .in('estado', ['pagado', 'pendiente']).order('id').range(d, h));
  return resumirVentas(filas, new Map(eventos.map((e) => [e.id, e.pedidos_vistos_en])));
}

/**
 * Marca como vistos los pedidos del evento hasta `hasta` (tomado ANTES de leerlos, así un pago que entra
 * mientras se leen sigue contando como nuevo). Si falla (p. ej. falta la migración) no rompe la lista.
 */
export async function marcarPedidosVistos(sb: SupabaseClient, eventoId: string, hasta: string): Promise<void> {
  try {
    const { error } = await sb.from('ev_eventos').update({ pedidos_vistos_en: hasta }).eq('id', eventoId);
    if (error) console.warn('[eventos] no se pudieron marcar los pedidos como vistos:', error.message);
  } catch (err) {
    console.warn('[eventos] no se pudieron marcar los pedidos como vistos:', err);
  }
}
