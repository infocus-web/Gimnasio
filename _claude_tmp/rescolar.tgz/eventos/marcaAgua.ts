// Muestras de EVENTOS.
// 03/10: muestras más chicas (800 px de lado mayor, JPEG 72) y el texto como contornos (en Vercel no hay
// tipografías y librsvg ignora @font-face: el texto salía como cuadraditos).
// 04/10 (pedido de Pablo): cada evento elige con el interruptor «Muestras con lupa» (ev_eventos.muestras_lupa):
//   - apagado (clásica): la marca de siempre "MUESTRA · RETRATO ESCOLAR", sin desenfoque (sufijo -m4);
//   - prendido (lupa): desenfoque suave + "PASÁ LA LUPA POR LA IMAGEN" (sufijo -m6); la foto nítida se
//     ve con la lupa (lupa/recorte.ts). -m5 era la primera versión, con un 50% menos de desenfoque: se rehace.
// Las recetas están en lupa/muestra.ts; las mismas se usan en el navegador (public/eventos/ventas.js, desde el 14/10/2026).
import { generarMuestraConMarca, LADO_MUESTRA, CALIDAD_MUESTRA } from '../lupa/muestra.js';

export { LADO_MUESTRA, CALIDAD_MUESTRA };
export const LADO_MINI = 400;
export const CALIDAD_MINI = 70;

/**
 * Sufijo de las rutas de las muestras según el estilo del evento. Las fotos cuya muestra no termina en el
 * sufijo que corresponde se rehacen con «Actualizar muestras» (-m2 cuadraditos y -m3 recargada también).
 */
export function sufijoMuestra(conLupa: boolean): string {
  return conLupa ? '-m6.jpg' : '-m4.jpg';
}

/** Genera la muestra grande y la miniatura (las dos con la marca del estilo elegido) a partir del original. */
export async function generarMuestras(original: Buffer, conLupa = false): Promise<{ muestra: Buffer; mini: Buffer }> {
  const estilo = conLupa ? 'lupa' : 'clasica';
  const muestra = await generarMuestraConMarca(original, LADO_MUESTRA, CALIDAD_MUESTRA, estilo);
  const mini = await generarMuestraConMarca(original, LADO_MINI, CALIDAD_MINI, estilo);
  return { muestra, mini };
}
