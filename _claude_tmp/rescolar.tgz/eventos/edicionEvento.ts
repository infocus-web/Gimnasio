// 14/10/2026 (auditoría de eventos): piezas nuevas del módulo que no entran en servidor.ts (techo de líneas).
// - Código del evento: no se puede cambiar si ya está publicado o tiene fotos/pedidos (rompe el QR impreso y los
//   links); si se cambia antes, el código viejo queda en `codigos_anteriores` y la galería lo sigue aceptando.
// - GET de UN evento para el panel: el formulario se llena con lo que hay en la base (no con la lista vieja).
// - Laboratorio: qué partes del ZIP de un lote ya se bajaron (para retomar después de recargar la página).
import type { Express, NextFunction, Request, Response } from 'express';
import type { SupabaseClient } from '@supabase/supabase-js';

type Middleware = (req: Request, res: Response, next: NextFunction) => unknown;
export interface DependenciasEdicion {
  requireAdmin: Middleware;
  requireLab: Middleware;
  conSupabase: (res: Response) => SupabaseClient | null;
  errorInterno: (res: Response, contexto: string, err: unknown) => unknown;
}

const esUuid = (v: unknown): v is string => typeof v === 'string' && /^[0-9a-f-]{36}$/i.test(v);
export const MENSAJE_CODIGO_BLOQUEADO = 'Este evento ya está publicado/tiene fotos: cambiar el código rompe el QR impreso y los links.';

/** Null si el código del evento todavía se puede cambiar; si no, el motivo (para el 409). */
export async function motivoCodigoBloqueado(sb: SupabaseClient, ev: { id: string; publicado?: boolean | null }): Promise<string | null> {
  if (ev.publicado) return MENSAJE_CODIGO_BLOQUEADO;
  const [fotos, pedidos] = await Promise.all([
    sb.from('ev_fotos').select('id', { count: 'exact', head: true }).eq('evento_id', ev.id),
    sb.from('ev_pedidos').select('id', { count: 'exact', head: true }).eq('evento_id', ev.id),
  ]);
  if (fotos.error) throw fotos.error;
  if (pedidos.error) throw pedidos.error;
  return (fotos.count || 0) > 0 || (pedidos.count || 0) > 0 ? MENSAJE_CODIGO_BLOQUEADO : null;
}

/** Guarda el código viejo para que el QR o el link que ya circulaban sigan andando (best-effort: sólo log). */
export async function guardarCodigoAnterior(sb: SupabaseClient, eventoId: string, viejo: string): Promise<void> {
  try {
    const { data, error } = await sb.from('ev_eventos').select('codigos_anteriores').eq('id', eventoId).maybeSingle();
    if (error) throw error;
    const lista = ((data?.codigos_anteriores as string[] | null) || []).filter((c) => c !== viejo);
    const { error: errUpd } = await sb.from('ev_eventos').update({ codigos_anteriores: [...lista, viejo].slice(-10) }).eq('id', eventoId);
    if (errUpd) throw errUpd;
  } catch (err) {
    console.error('[eventos] No se pudo guardar el código anterior', viejo, err);
  }
}

/**
 * Evento por su código actual o, si no hay, por uno anterior (QR impreso antes de cambiarlo). Lo que se
 * devuelve trae el código ACTUAL (la página de familias pasa a usarlo). Si falta la columna, sólo el actual.
 */
export async function buscarEventoPorCodigo(sb: SupabaseClient, codigo: string, campos: string): Promise<any | null> {
  const { data, error } = await sb.from('ev_eventos').select(campos).eq('codigo', codigo).maybeSingle();
  if (error) throw error;
  if (data) return data;
  try {
    const { data: viejos, error: errViejo } = await sb.from('ev_eventos').select(campos).contains('codigos_anteriores', [codigo]).limit(1);
    if (errViejo) throw errViejo;
    return (viejos as any[] | null)?.[0] ?? null;
  } catch (err) {
    console.warn('[eventos] No se pudo buscar por código anterior:', err);
    return null;
  }
}

/** Progreso del ZIP por partes guardado en el lote: { total, partes, hechas: { "0": faltantes, … } }. */
export function sumarParte(previo: unknown, total: number, partes: number, parte: number, faltan: number) {
  const p = previo && typeof previo === 'object' ? (previo as any) : null;
  const mismo = p && p.total === total && p.partes === partes && p.hechas && typeof p.hechas === 'object';
  const hechas: Record<string, number> = mismo ? { ...p.hechas } : {};
  hechas[String(parte)] = faltan;
  return { total, partes, hechas, actualizado_en: new Date().toISOString() };
}

const entero = (v: unknown, min: number, max: number) => {
  const n = Number(v);
  return Number.isInteger(n) && n >= min && n <= max ? n : null;
};

export function registrarRutasEdicion(app: Express, d: DependenciasEdicion): void {
  // Un evento (panel): para llenar el formulario con lo último y saber si el código se puede cambiar.
  app.get('/api/eventos/admin/eventos/:id', d.requireAdmin, async (req, res) => {
    if (!esUuid(req.params.id)) return res.status(400).json({ success: false, error: 'Evento inválido' });
    const sb = d.conSupabase(res);
    if (!sb) return;
    try {
      const { data: ev, error } = await sb.from('ev_eventos').select('*').eq('id', req.params.id).maybeSingle();
      if (error) throw error;
      if (!ev) return res.status(404).json({ success: false, error: 'No se encontró el evento' });
      const { count } = await sb.from('ev_fotos').select('id', { count: 'exact', head: true }).eq('evento_id', ev.id);
      const freno = await motivoCodigoBloqueado(sb, ev);
      return res.json({ success: true, evento: { ...ev, cantidad_fotos: count ?? 0 }, codigoEditable: !freno });
    } catch (err) {
      return d.errorInterno(res, 'leer el evento', err);
    }
  });

  // Laboratorio: partes del ZIP ya bajadas. Si falta la columna (migración sin aplicar) responde vacío.
  app.get('/api/eventos/lab/lotes/:id/partes', d.requireLab, async (req, res) => {
    if (!esUuid(req.params.id)) return res.status(400).json({ success: false, error: 'Lote inválido' });
    const sb = d.conSupabase(res);
    if (!sb) return;
    const { data, error } = await sb.from('ev_lotes').select('partes_descargadas').eq('id', req.params.id).maybeSingle();
    if (error) console.warn('[eventos] No se pudo leer el progreso del ZIP:', error);
    return res.json({ success: true, progreso: (!error && data?.partes_descargadas) || null });
  });

  app.post('/api/eventos/lab/lotes/:id/partes', d.requireLab, async (req, res) => {
    if (!esUuid(req.params.id)) return res.status(400).json({ success: false, error: 'Lote inválido' });
    const total = entero(req.body?.total, 1, 100000);
    const partes = entero(req.body?.partes, 1, 2000);
    const parte = entero(req.body?.parte, 0, 1999);
    const faltan = entero(req.body?.faltan, 0, 100000);
    if (total === null || partes === null || parte === null || faltan === null || parte >= partes) {
      return res.status(400).json({ success: false, error: 'Datos de la parte inválidos' });
    }
    const sb = d.conSupabase(res);
    if (!sb) return;
    try {
      const { data, error } = await sb.from('ev_lotes').select('partes_descargadas').eq('id', req.params.id).maybeSingle();
      if (error) throw error;
      if (!data) return res.status(404).json({ success: false, error: 'No se encontró el lote' });
      const progreso = sumarParte(data.partes_descargadas, total, partes, parte, faltan);
      const { error: errUpd } = await sb.from('ev_lotes').update({ partes_descargadas: progreso }).eq('id', req.params.id);
      if (errUpd) throw errUpd;
      return res.json({ success: true, progreso });
    } catch (err) {
      return d.errorInterno(res, 'guardar el progreso del ZIP', err);
    }
  });
}
