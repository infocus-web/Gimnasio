// Códigos de descuento en los pedidos de EVENTOS (27/10/2026, Pablo: «agreguemos una función de código de descuento
// al momento de hacer el pedido», para dar la foto de hermanos sin cargo a profes y directivos).
// - Usa la misma tabla `codigos_descuento` que el kit, pero sólo los códigos con ambito = 'eventos' (los del kit no
//   sirven acá y los de eventos no sirven en el kit: ver servidor/pagos/descuentos.ts).
// - Misma regla que el kit: las digitales aceptan hasta 100%; las copias impresas, como máximo 70%, salvo que el
//   código esté marcado «sin tope en el impreso» (la impresión la paga Pablo).
// - Un uso por pedido. El uso se gasta al registrar el pedido (aunque después no lo paguen), igual que en el kit.
// - Si el pedido queda en $0 nace pagado con medio_pago 'bonificado' (ver la ruta de pedidos en eventos/servidor.ts).
// El monto lo calcula SIEMPRE el servidor. Este archivo no importa nada de server.ts ni de src/ (regla del módulo).
import type { Express, NextFunction, Request, Response } from 'express';
import type { SupabaseClient } from '@supabase/supabase-js';
import type { ItemCalculado } from './precios.js';

export const TOPE_DESCUENTO_IMPRESO_EVENTO = 70; // el mismo número que TOPE_DESCUENTO_IMPRESO del kit
export const ERROR_DESCUENTO_EVENTO = 'El código de descuento no es válido o ya no está disponible. Quitalo para seguir con la compra.';
const CODIGO_RE = /^[A-Z0-9-]{4,32}$/;

export interface DescuentoEvento {
  codigo: string;
  porcentaje: number;
  sinTopeImpreso: boolean;
}

export const normalizarCodigoDescuentoEvento = (valor: unknown) => String(valor ?? '').trim().toUpperCase().replace(/\s+/g, '');

/** Porcentaje que se aplica a una línea: digital hasta 100%; impresa hasta 70% salvo «sin tope». */
export function porcentajeParaLinea(formato: string, porcentaje: number, sinTopeImpreso = false): number {
  const tope = formato === 'digital' || sinTopeImpreso ? 100 : TOPE_DESCUENTO_IMPRESO_EVENTO;
  return Math.max(0, Math.min(tope, Math.floor(Number(porcentaje) || 0)));
}

/** Cuánto se descuenta del pedido (en pesos, redondeado por línea). Nunca más que el total. */
export function descuentoDelPedido(items: Array<Pick<ItemCalculado, 'formato' | 'subtotal'>>, descuento: Pick<DescuentoEvento, 'porcentaje' | 'sinTopeImpreso'> | null): number {
  if (!descuento) return 0;
  const total = items.reduce((a, it) => a + (Number(it.subtotal) || 0), 0);
  const monto = items.reduce((a, it) => a + Math.round(((Number(it.subtotal) || 0) * porcentajeParaLinea(it.formato, descuento.porcentaje, descuento.sinTopeImpreso)) / 100), 0);
  return Math.max(0, Math.min(total, monto));
}

/** El código si se puede usar ahora en un evento (activo, vigente, con usos libres y de ámbito 'eventos'); si no, null. */
export async function codigoVigenteEvento(sb: SupabaseClient, valor: unknown): Promise<DescuentoEvento | null> {
  const codigo = normalizarCodigoDescuentoEvento(valor);
  if (!CODIGO_RE.test(codigo)) return null;
  const { data, error } = await sb
    .from('codigos_descuento')
    .select('codigo, porcentaje, usos_max, usos, vence_at, activo, sin_tope_impreso, ambito')
    .eq('codigo', codigo)
    .maybeSingle();
  if (error) {
    if (['42P01', 'PGRST205', '42703'].includes(String((error as any).code || ''))) return null; // migración sin aplicar
    throw error;
  }
  if (!data || !data.activo || data.ambito !== 'eventos') return null;
  if (data.vence_at && Date.parse(data.vence_at) < Date.now()) return null;
  if (data.usos_max && Number(data.usos) >= Number(data.usos_max)) return null;
  return { codigo, porcentaje: Number(data.porcentaje), sinTopeImpreso: data.sin_tope_impreso === true };
}

/** Suma el uso de forma atómica (misma función SQL que el kit). false = ya no está disponible. */
export async function consumirUsoEvento(sb: SupabaseClient, descuento: DescuentoEvento | null): Promise<boolean> {
  if (!descuento) return true;
  const { data, error } = await sb.rpc('usar_codigo_descuento', { p_codigo: descuento.codigo });
  if (error) throw error;
  const porcentaje = Array.isArray(data) ? data[0] : data;
  if (Number(porcentaje) === descuento.porcentaje) return true;
  if (porcentaje !== null && porcentaje !== undefined) await devolverUsoEvento(sb, descuento); // cambió el % en el medio
  return false;
}

/** Si el pedido no se llegó a registrar, el uso se devuelve. */
export async function devolverUsoEvento(sb: SupabaseClient, descuento: DescuentoEvento | null): Promise<void> {
  if (!descuento) return;
  const { error } = await sb.rpc('devolver_uso_codigo_descuento', { p_codigo: descuento.codigo });
  if (error) console.warn('[eventos] No se pudo devolver el uso del código de descuento:', error.message);
}

/** ¿Vino un código en el pedido? (vacío o sólo espacios = sin código). */
export const hayCodigoDescuento = (valor: unknown) => valor !== undefined && valor !== null && String(valor).trim() !== '';

/**
 * Para la ruta de pedidos, ANTES de escribir nada. Sin código: total = el del cálculo (todo igual que antes).
 * Con código: tope de intentos por IP en la base (60 cada 10 min, como el kit) contra adivinarlos; código que no
 * vale → status 400. `espera` es esperaPersistente de eventos/servidor.ts (devuelve > 0 si hay que frenar).
 */
export async function resolverDescuentoEvento(
  sb: SupabaseClient,
  valor: unknown,
  ip: string,
  items: Array<Pick<ItemCalculado, 'formato' | 'subtotal'>>,
  espera: (clave: string, maximo: number, ventanaSeg: number) => Promise<number>
): Promise<{ descuento: DescuentoEvento | null; monto: number; total: number; sinCargo: boolean; status?: number; error?: string }> {
  const totalLista = items.reduce((a, it) => a + (Number(it.subtotal) || 0), 0);
  const sinDescuento = { descuento: null, monto: 0, total: totalLista, sinCargo: false };
  if (!hayCodigoDescuento(valor)) return sinDescuento;
  if ((await espera(`ev-descuento-intento:${ip}`, 60, 600)) > 0) {
    return { ...sinDescuento, status: 429, error: 'Demasiados intentos con códigos. Esperá unos minutos o quitá el código para seguir.' };
  }
  const descuento = await codigoVigenteEvento(sb, valor);
  if (!descuento) return { ...sinDescuento, status: 400, error: ERROR_DESCUENTO_EVENTO };
  const monto = descuentoDelPedido(items, descuento);
  return { descuento, monto, total: totalLista - monto, sinCargo: totalLista - monto === 0 };
}

/** Columnas del pedido con el descuento aplicado (vacío si no hay). */
export function columnasDescuentoEvento(descuento: DescuentoEvento | null, monto: number): Record<string, unknown> {
  return descuento ? { codigo_descuento: descuento.codigo, descuento_pct: descuento.porcentaje, descuento_monto: monto } : {};
}

type Middleware = (req: Request, res: Response, next: NextFunction) => unknown;
export interface DependenciasDescuento {
  limitarPersistente: (nombre: string, maximo: number, ventanaMs: number) => Middleware;
  conSupabase: (res: Response) => SupabaseClient | null;
  errorInterno: (res: Response, contexto: string, err: unknown) => unknown;
}

/**
 * La familia (o el profe) prueba el código antes de confirmar el pedido. Sólo dice si vale y cuánto; el monto final
 * lo vuelve a calcular el servidor al crear el pedido. Mismo tope por IP que el kit (15 cada 10 min).
 */
export function registrarRutaDescuento(app: Express, d: DependenciasDescuento): void {
  app.post('/api/eventos/publico/:codigo/descuento', d.limitarPersistente('descuento-validar', 15, 10 * 60 * 1000), async (req, res) => {
    const sb = d.conSupabase(res);
    if (!sb) return;
    try {
      const vigente = await codigoVigenteEvento(sb, req.body?.codigo);
      if (!vigente) return res.status(404).json({ success: false, error: ERROR_DESCUENTO_EVENTO });
      return res.json({ success: true, codigo: vigente.codigo, porcentaje: vigente.porcentaje, sinTopeImpreso: vigente.sinTopeImpreso });
    } catch (err) {
      return d.errorInterno(res, 'validar el código de descuento', err);
    }
  });
}
