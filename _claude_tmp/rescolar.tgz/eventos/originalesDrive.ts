// EVENTOS: ORIGINALES EN GOOGLE DRIVE (17/10/2026, pedido de Pablo).
// Pablo sube los originales sólo a Drive (servidor/nucleo/googleDrive.ts). Desde el panel elige la carpeta del
// evento y toca «Importar desde Drive»: por cada foto nueva se arma la muestra, la miniatura y la copia nítida
// de la lupa (eso sí queda en Storage) y se registra la foto con `drive_file_id` y `hd_en_storage = false`.
// El original se copia a Storage (en `storage_path_hd`, la misma ruta que tendría si se hubiera subido) recién
// cuando hace falta: al pagarse un pedido (así el mail de descarga y el lote del laboratorio lo encuentran),
// o al pedir la descarga / el lote si todavía no estaba.
import crypto from 'crypto';
import sharp from 'sharp';
import type { Express, NextFunction, Request, Response } from 'express';
import type { SupabaseClient } from '@supabase/supabase-js';
import { descargarDeDrive, driveConfigurado, idCarpetaDrive, listarFotosDeCarpeta, type ArchivoDrive } from '../servidor/nucleo/googleDrive.js';
import { generarMuestras, sufijoMuestra } from './marcaAgua.js';
import { armarCopiaLupa, rutaCopiaLupa } from '../lupa/recorte.js';

const BUCKET_WEB = 'eventos-web';
const BUCKET_HD = 'eventos-hd';
/** Cada vuelta de la importación trabaja ~20 s: el panel la repite hasta que no queden fotos. */
const PRESUPUESTO_IMPORTAR_MS = 20000;
const EN_PARALELO = 3;

type Middleware = (req: Request, res: Response, next: NextFunction) => unknown;
export interface DependenciasDrive {
  requireAdmin: Middleware;
  conSupabase: (res: Response) => SupabaseClient | null;
  errorInterno: (res: Response, contexto: string, err: unknown) => unknown;
}

const esUuid = (v: unknown): v is string => typeof v === 'string' && /^[0-9a-f-]{36}$/i.test(v);

async function filas<T = any>(armar: (d: number, h: number) => PromiseLike<{ data: T[] | null; error: any }>): Promise<T[]> {
  const out: T[] = [];
  for (let d = 0; ; d += 1000) {
    const { data, error } = await armar(d, d + 999);
    if (error) throw error;
    out.push(...(data || []));
    if (!data || data.length < 1000) return out;
  }
}

/**
 * Original de una foto: de Storage si está; si no, de Drive. No lo guarda (para eso, asegurarOriginales).
 * Lo usan la lupa (si falta su copia) y «Actualizar muestras».
 */
export async function cargarOriginalEvento(sb: SupabaseClient, rutaHd: string): Promise<Buffer> {
  const { data: foto } = await sb.from('ev_fotos').select('drive_file_id, hd_en_storage').eq('storage_path_hd', rutaHd).maybeSingle();
  if (foto?.drive_file_id && foto.hd_en_storage === false) return descargarDeDrive(foto.drive_file_id);
  const { data, error } = await sb.storage.from(BUCKET_HD).download(rutaHd);
  if (!error && data) return Buffer.from(await data.arrayBuffer());
  if (foto?.drive_file_id) return descargarDeDrive(foto.drive_file_id);
  throw error || new Error('sin original');
}

/**
 * Copia de Drive a Storage los originales de esas rutas que todavía no están. Devuelve cuántos quedaron
 * sin copiar (por tiempo o por error). Si un original ya no está en Drive, avisa con `alAvisar`.
 */
export async function asegurarOriginales(
  sb: SupabaseClient,
  rutasHd: string[],
  presupuestoMs = 40000,
  alAvisar?: (nombres: string[]) => Promise<void>
): Promise<number> {
  const rutas = [...new Set(rutasHd.filter(Boolean))];
  if (!rutas.length) return 0;
  const faltan: { id: string; storage_path_hd: string; drive_file_id: string; nombre_archivo: string }[] = [];
  for (let i = 0; i < rutas.length; i += 200) {
    const { data, error } = await sb.from('ev_fotos').select('id, storage_path_hd, drive_file_id, nombre_archivo')
      .in('storage_path_hd', rutas.slice(i, i + 200)).eq('hd_en_storage', false).not('drive_file_id', 'is', null);
    if (error) throw error;
    faltan.push(...((data || []) as any[]));
  }
  if (!faltan.length) return 0;
  const inicio = Date.now();
  const perdidos: string[] = [];
  let pendientes = faltan.length;
  let i = 0;
  const trabajador = async () => {
    while (i < faltan.length && Date.now() - inicio < presupuestoMs) {
      const f = faltan[i++];
      try {
        const original = await descargarDeDrive(f.drive_file_id);
        const { error } = await sb.storage.from(BUCKET_HD).upload(f.storage_path_hd, original, { contentType: 'image/jpeg', upsert: true });
        if (error) throw error;
        await sb.from('ev_fotos').update({ hd_en_storage: true }).eq('id', f.id);
        pendientes--;
      } catch (e: any) {
        console.error('[drive] No se pudo copiar el original', f.nombre_archivo, e?.message || e);
        if (e?.definitivo) perdidos.push(f.nombre_archivo);
      }
    }
  };
  await Promise.all(Array.from({ length: Math.min(EN_PARALELO, faltan.length) }, trabajador));
  if (perdidos.length && alAvisar) await alAvisar(perdidos).catch(() => undefined);
  return pendientes;
}

/** Al pagarse un pedido: deja listos en Storage los originales de sus fotos (como mucho ~25 s; lo que falte se copia al bajarlo). */
export async function copiarOriginalesDelPedido(sb: SupabaseClient, pedidoId: string, alAvisar?: (nombres: string[]) => Promise<void>): Promise<void> {
  try {
    const { data, error } = await sb.from('ev_items_pedido').select('ev_fotos(storage_path_hd)').eq('pedido_id', pedidoId);
    if (error) throw error;
    const rutas = (data || []).map((it: any) => it.ev_fotos?.storage_path_hd).filter(Boolean);
    await asegurarOriginales(sb, rutas, 25000, alAvisar);
  } catch (err) {
    console.error('[drive] No se pudieron preparar los originales del pedido', pedidoId, err);
  }
}

/** Arma y sube muestra, miniatura y copia de la lupa de UNA foto de Drive, y la registra. */
async function importarUna(sb: SupabaseClient, eventoId: string, archivo: ArchivoDrive, conLupa: boolean, orden: number): Promise<'ok' | 'repetida'> {
  const original = await descargarDeDrive(archivo.id);
  const m = await sharp(original, { failOn: 'none' }).metadata().catch(() => null);
  const girada = (m?.orientation || 1) >= 5; // EXIF 5-8: la foto se ve rotada 90°
  const meta = m ? { width: girada ? m.height : m.width, height: girada ? m.width : m.height } : null;
  const [{ muestra, mini }, copia] = await Promise.all([generarMuestras(original, conLupa), armarCopiaLupa(original)]);
  const base = `${eventoId}/${crypto.randomUUID()}`;
  const sufijo = sufijoMuestra(conLupa);
  const rutas = { hd: `${base}.jpg`, preview: `${base}-muestra${sufijo}`, thumb: `${base}-mini${sufijo}` };
  const op = { contentType: 'image/jpeg', cacheControl: '31536000', upsert: false };
  const subidas = await Promise.all([
    sb.storage.from(BUCKET_WEB).upload(rutas.preview, muestra, op),
    sb.storage.from(BUCKET_WEB).upload(rutas.thumb, mini, op),
    sb.storage.from(BUCKET_HD).upload(rutaCopiaLupa(rutas.hd), copia.data, { ...op, upsert: true }),
  ]);
  const limpiar = () =>
    Promise.all([sb.storage.from(BUCKET_WEB).remove([rutas.preview, rutas.thumb]), sb.storage.from(BUCKET_HD).remove([rutaCopiaLupa(rutas.hd)])]);
  const fallo = subidas.find((s) => s.error)?.error;
  if (fallo) {
    await limpiar();
    throw fallo;
  }
  const { error } = await sb.from('ev_fotos').insert({
    evento_id: eventoId,
    nombre_archivo: archivo.nombre.slice(0, 200),
    storage_path_hd: rutas.hd,
    preview_path: rutas.preview,
    thumb_path: rutas.thumb,
    ancho: meta?.width || null,
    alto: meta?.height || null,
    orden,
    drive_file_id: archivo.id,
    hd_en_storage: false,
  });
  if (error) {
    await limpiar();
    if ((error as any).code === '23505') return 'repetida';
    throw error;
  }
  return 'ok';
}

export function registrarRutasDrive(app: Express, { requireAdmin, conSupabase, errorInterno }: DependenciasDrive): void {
  // Una vuelta de la importación (~20 s). El panel la repite mientras `restantes` > 0 y haya avance.
  app.post('/api/eventos/admin/eventos/:id/importar-drive', requireAdmin, async (req, res) => {
    const eventoId = req.params.id;
    if (!esUuid(eventoId)) return res.status(400).json({ success: false, error: 'Evento inválido' });
    if (!driveConfigurado()) return res.status(503).json({ success: false, error: 'Falta configurar la cuenta de Google Drive en Vercel (GOOGLE_SERVICE_ACCOUNT_JSON).' });
    const sb = conSupabase(res);
    if (!sb) return;
    const inicio = Date.now();
    try {
      const { data: ev, error: errEv } = await sb.from('ev_eventos').select('id, muestras_lupa, drive_carpeta_id').eq('id', eventoId).maybeSingle();
      if (errEv) throw errEv;
      if (!ev) return res.status(404).json({ success: false, error: 'No se encontró el evento' });
      const pedida = req.body?.carpeta ? idCarpetaDrive(req.body.carpeta) : ev.drive_carpeta_id;
      if (!pedida) return res.status(400).json({ success: false, error: 'Pegá el link de la carpeta de Drive del evento.' });
      if (pedida !== ev.drive_carpeta_id) await sb.from('ev_eventos').update({ drive_carpeta_id: pedida }).eq('id', eventoId);

      let enDrive: ArchivoDrive[];
      try {
        enDrive = await listarFotosDeCarpeta(pedida);
      } catch (e: any) {
        if (e?.publico) return res.status(404).json({ success: false, error: e.message });
        throw e;
      }
      const yaEstan = new Set(
        (await filas<any>((d, h) => sb.from('ev_fotos').select('nombre_archivo').eq('evento_id', eventoId).range(d, h))).map((f) => String(f.nombre_archivo))
      );
      const pendientes = enDrive.filter((f) => !yaEstan.has(f.nombre.slice(0, 200)));
      const ordenDe = new Map(enDrive.map((f, i) => [f.id, i + 1]));
      let importadas = 0;
      const errores: string[] = [];
      let i = 0;
      const trabajador = async () => {
        while (i < pendientes.length && Date.now() - inicio < PRESUPUESTO_IMPORTAR_MS) {
          const archivo = pendientes[i++];
          try {
            if ((await importarUna(sb, eventoId, archivo, ev.muestras_lupa === true, ordenDe.get(archivo.id) || 0)) === 'ok') importadas++;
          } catch (e: any) {
            console.error('[drive] No se pudo importar', archivo.nombre, e?.message || e);
            errores.push(archivo.nombre);
          }
        }
      };
      await Promise.all(Array.from({ length: Math.min(EN_PARALELO, pendientes.length) }, trabajador));
      return res.json({
        success: true,
        importadas,
        errores,
        restantes: Math.max(pendientes.length - importadas, 0),
        enDrive: enDrive.length,
        carpeta: pedida,
      });
    } catch (err) {
      return errorInterno(res, 'importar desde Drive', err);
    }
  });
}
