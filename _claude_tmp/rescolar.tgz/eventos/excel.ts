// Planillas Excel del módulo de eventos (entregas, lote del laboratorio, suscriptores).
// 14/10/2026: se sacaron tal cual de servidor.ts para hacer lugar a los arreglos de la auditoría (techo de líneas).
import type { Response } from 'express';

export async function enviarXlsx(res: Response, libro: any, nombre: string) {
  const buffer = await libro.xlsx.writeBuffer();
  res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
  res.setHeader('Content-Disposition', `attachment; filename="${nombre.replace(/[^\w.\-]/g, '_')}"`);
  res.setHeader('Cache-Control', 'no-store');
  return res.send(Buffer.from(buffer));
}

export async function nuevoLibro(): Promise<any> {
  const ExcelJS: any = (await import('exceljs')).default;
  const libro = new ExcelJS.Workbook();
  libro.creator = 'Retrato Escolar';
  libro.created = new Date();
  return libro;
}

export function estilarHoja(hoja: any, filaEncabezado: number) {
  const enc = hoja.getRow(filaEncabezado);
  enc.font = { bold: true, color: { argb: 'FFFFFFFF' } };
  enc.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF0F172A' } };
  enc.alignment = { vertical: 'middle' };
  enc.height = 20;
  hoja.views = [{ state: 'frozen', ySplit: filaEncabezado }];
  hoja.eachRow((fila: any, n: number) => {
    if (n <= filaEncabezado) return;
    fila.eachCell((c: any) => {
      c.border = { bottom: { style: 'thin', color: { argb: 'FFE2E8F0' } } };
      c.alignment = { vertical: 'top', wrapText: true };
    });
    if (n % 2 === 0) fila.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFF8FAFC' } };
  });
}
