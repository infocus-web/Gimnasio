// Armado de archivos para el laboratorio (funciones puras, se pueden probar).
// Un archivo por COPIA, como en los kits: el minilab imprime cada archivo una vez.
// Nombre: [CURSO_]NOMBRE_DEL_CHICO_NUMERO-DE-PEDIDO_FOTO[_COPIAn].jpg, en una carpeta por tamaño.

export function sanitizarMinilab(texto: string): string {
  return String(texto || '')
    .normalize('NFD')
    .replace(/[̀-ͯ]/g, '')
    .toUpperCase()
    .replace(/[^A-Z0-9_]/g, '_')
    .replace(/_+/g, '_')
    .replace(/^_|_$/g, '');
}

export interface PedidoLote {
  numero: string;
  nino_nombre: string;
  nino_curso: string | null;
  items: Array<{ formato: string; cantidad: number; foto_id: string; nombre_archivo: string; storage_path_hd: string }>;
}

export interface ArchivoLote {
  carpeta: '15x21' | '20x30';
  nombre: string;
  storage_path_hd: string;
  numero: string;
  nino: string;
  curso: string | null;
  foto: string;
  copia: number;
  copias: number;
}

export function archivosDelLote(pedidos: PedidoLote[]): ArchivoLote[] {
  const salida: ArchivoLote[] = [];
  const usados = new Set<string>();
  for (const p of pedidos) {
    for (const it of p.items) {
      if (it.formato !== '15x21' && it.formato !== '20x30') continue;
      const base = [
        p.nino_curso ? sanitizarMinilab(p.nino_curso) : '',
        sanitizarMinilab(p.nino_nombre),
        sanitizarMinilab(p.numero),
        sanitizarMinilab(String(it.nombre_archivo).replace(/\.[^.]+$/, '')),
      ].filter(Boolean).join('_');
      for (let copia = 1; copia <= it.cantidad; copia++) {
        let nombre = `${base}${copia > 1 ? `_COPIA${copia}` : ''}.jpg`;
        // Nunca dos archivos con el mismo nombre en la misma carpeta (uno pisaría al otro en el ZIP).
        let extra = 2;
        while (usados.has(`${it.formato}/${nombre}`)) nombre = `${base}${copia > 1 ? `_COPIA${copia}` : ''}_${extra++}.jpg`;
        usados.add(`${it.formato}/${nombre}`);
        salida.push({
          carpeta: it.formato,
          nombre,
          storage_path_hd: it.storage_path_hd,
          numero: p.numero,
          nino: p.nino_nombre,
          curso: p.nino_curso,
          foto: it.nombre_archivo,
          copia,
          copias: it.cantidad,
        });
      }
    }
  }
  // Orden estable: por tamaño y, dentro de cada uno, en el orden de los pedidos (ya vienen por nombre).
  return salida.sort((a, b) => a.carpeta.localeCompare(b.carpeta));
}

export const ETAPAS_ENTREGA = ['en_laboratorio', 'listo_retiro', 'entregado'] as const;
export type EtapaEntrega = (typeof ETAPAS_ENTREGA)[number];

/** Sólo se avanza de a un paso (o se repite el mismo para reenviar el aviso de "listo"). */
export function puedePasarA(actual: string | null, nueva: EtapaEntrega): boolean {
  const idxActual = actual ? ETAPAS_ENTREGA.indexOf(actual as EtapaEntrega) : -1;
  const idxNueva = ETAPAS_ENTREGA.indexOf(nueva);
  if (idxNueva < 0) return false;
  return idxNueva === idxActual + 1 || (nueva === 'listo_retiro' && actual === 'listo_retiro');
}
