// Primero de todo: carga el .env de la compu antes que cualquier otro módulo (ver servidor/nucleo/entorno.ts).
import './servidor/nucleo/entorno.js';
import express from 'express';
import path from 'path';
// División de server.ts (plan en el proyecto: claude/plan-division-servidor.md): server.ts sólo arma la
// app y monta los routers de servidor/ en el orden original. Etapa 1: el núcleo (clientes de servicios,
// autenticación, límites, precios y utilidades) vive en servidor/nucleo. Etapa 3 (servicios de entrega
// y reglas compartidas) no deja imports acá: la usan los módulos.
import { asegurarPreciosActualizados } from './servidor/nucleo/precios.js';
// Etapa 2: campaña Zoho, convenio + liquidación y comisiones de cobro.
import { rutasCampanaZoho } from './servidor/campanaZoho.js';
import { rutasConvenioLiquidacion } from './servidor/convenioLiquidacion.js';
// Etapa 4: rutas del panel (pedidos, laboratorio, salud y errores, fotos y storage, cierre de temporada, colegios).
import { rutasCierreTemporada } from './servidor/panel/cierreTemporada.js';
import { rutasColegios } from './servidor/panel/colegios.js';
import { rutasFotosPanel } from './servidor/panel/fotos.js';
import { rutasPrepararLupa } from './servidor/panel/prepararLupa.js';
import { rutasEncuesta } from './servidor/familias/encuesta.js';
import { rutasEmailsFamilias } from './servidor/panel/emailsFamilias.js';
import { rutasNovedadesIa } from './servidor/familias/novedadesIa.js';
import { rutasAvisosFotos } from './servidor/panel/avisosFotos.js';
import { rutasLaboratorio } from './servidor/panel/laboratorio.js';
import { rutasLaboratorioExtras } from './servidor/panel/laboratorioExtras.js';
import { rutasBorrarPedido, rutasOrganizarPedido, rutasPanelPedidos } from './servidor/panel/pedidos.js';
import { rutasObservaciones } from './servidor/panel/observaciones.js';
import { rutasBorradores } from './servidor/panel/borradores.js';
import { rutasSaludErrores } from './servidor/panel/saludErrores.js';
// Etapa 5: familias, correo entrante, sesión del panel y rutas de Resend.
import { rutasCorreoEntrante } from './servidor/correoEntrante.js';
import { rutasResend } from './servidor/entrega/rutasResend.js';
import { rutasCambiarFotosPedido } from './servidor/panel/cambiarFotosPedido.js';
import { rutasConsultas } from './servidor/familias/consultas.js';
import { rutasConsultasAdmin } from './servidor/familias/consultasAdmin.js';
import { rutasFichaCliente } from './servidor/familias/fichaCliente.js';
import { rutasFotoHermanos } from './servidor/familias/fotoHermanos.js';
import { rutasSolicitudesFaltantes } from './servidor/familias/solicitudesFaltantes.js';
import { rutasConvocatoriaFaltantes } from './servidor/familias/convocatoriaFaltantes.js';
import { rutasBuscadorRostro } from './servidor/familias/buscadorRostro.js';
import { rutasDescuentos } from './servidor/pagos/descuentos.js';
import { rutasGaleria } from './servidor/familias/galeria.js';
import { rutasInscripciones } from './servidor/familias/inscripciones.js';
import { rutasInscripcionesAdmin } from './servidor/familias/inscripcionesAdmin.js';
import { rutasSumarHijo } from './servidor/familias/sumarHijo.js';
import { rutasCursosNomina } from './servidor/familias/cursosNomina.js';
import { rutasPadron } from './servidor/familias/padron.js';
import { rutasSolicitudesCodigo } from './servidor/familias/solicitudesCodigo.js';
import { rutasSesionAdmin } from './servidor/panel/sesion.js';
// Etapa 6: pagos, tareas programadas y descargas. Con esto server.ts queda como armador.
import { rutasDescargas } from './servidor/entrega/descargas.js';
import { rutasArrepentimiento } from './servidor/pagos/arrepentimiento.js';
import { rutasBuscadorPedidos } from './servidor/pagos/buscadorPedidos.js';
import { rutasComprobantes } from './servidor/pagos/comprobantes.js';
import { rutasCrearPedido, rutasReservas } from './servidor/pagos/crearPedido.js';
import { rutasEstadoPedido } from './servidor/pagos/estadoPedido.js';
import { rutasMejoraImpreso } from './servidor/pagos/mejoraImpreso.js';
import { rutasFotosExtra } from './servidor/pagos/fotosExtra.js';
import { rutasMercadoPagoPreferencias, rutasMercadoPagoWebhook } from './servidor/pagos/mercadoPago.js';
import { rutasNave } from './servidor/pagos/nave.js';
import { rutasPrecios } from './servidor/pagos/totales.js';
import { rutasConfiguracion } from './servidor/panel/configuracion.js'; // 30/10: panel → Configuración (fechas límite)
import { rutasTareasProgramadas, rutasTareasProgramadasHD } from './servidor/tareasProgramadas.js';
// 10/10: panel propio del colegio (claude/panel-colegio-plan.md).
import { rutasPanelColegio } from './servidor/colegio/panelColegio.js';


const app = express();

// → Movido a servidor/nucleo/precios.ts (división de server.ts, etapa 1): PreciosSitio, PRECIOS_POR_DEFECTO, preciosLeidosAt, validarPrecios, preciosCargadosDeLaBase, …
const PORT = 3000;

// Detrás del proxy de Vercel, sin esto Express cree que cada request llega por "http"
// (aunque el visitante esté en https) — eso rompe cualquier lógica que dependa de
// req.protocol, como la URL de retorno que le mandamos a Mercado Pago más abajo.
app.set('trust proxy', true);

// → Movido a servidor/nucleo/clientes.ts (división de server.ts, etapa 1): CASILLA_REENVIO_ENTRANTE
// → Movido a servidor/correoEntrante.ts (división de server.ts, etapa 5): su ruta y quitarMensajeCitado, reenviarCorreoEntrante, direccionesFamilias, direccionDeCorreo, nombreDeCorreo, DOMINIOS_PROPIOS, …
// Sus rutas se montan acá, en el mismo lugar donde estaban (así el orden de Express no cambia).
app.use(rutasCorreoEntrante);

// Auditoría 2026-09-23 (bug real): express.json() sin opciones corta el body en 100 KB. El panel
// registra en UNA sola llamada todas las fotos de un lote (≈500 bytes por foto: 3 rutas/URLs
// largas + curso), así que un lote de ~200 fotos ya devolvía 413 "request entity too large": las
// fotos quedaban subidas a Storage pero NUNCA se registraban en el catálogo (no aparecían en la
// galería). Lo mismo con el padrón (hasta 2000 filas por importación). Vercel acepta hasta 4,5 MB.
app.use(express.json({ limit: '4mb' }));

// Precios vigentes (ver aplicarPrecios, sección 7): se releen de Supabase como mucho una vez por
// minuto por instancia, antes de atender cualquier /api, así el cobro, los emails y la IA usan
// siempre lo último que se guardó en el panel.
app.use('/api', async (_req, _res, next) => {
  try {
    await asegurarPreciosActualizados();
  } catch {
    // Si falla la lectura se siguen usando los últimos precios conocidos.
  }
  next();
});

// → Movido a servidor/nucleo/limites.ts (división de server.ts, etapa 1): intentosPorClave, limitarFrecuencia, limitarFrecuenciaPersistente, limitarFrecuenciaPersistenteSinEspera, hayCupoGlobal, …

// ==============================================================================
// 1. CONFIGURACIÓN DE SERVICIOS Y CLIENTES
// ==============================================================================


// → Movido a servidor/nucleo/clientes.ts (división de server.ts, etapa 1): getResendClient, contarEnviosEmail, getResendInboundClient

// → Movido a servidor/nucleo/ia.ts (división de server.ts, etapa 1): iaConfigurada, ERROR_IA_NO_CONFIGURADA, generarTextoIA (13/10: sólo Claude, sin Gemini)

// → Movido a servidor/familias/consultas.ts (división de server.ts, etapa 5): EventoFotoHermanos, describirEventoFotoHermanos, cacheEventoFotoHermanos, textoEventoFotoHermanos, contextoNegocioConsultas

// → Movido a servidor/nucleo/clientes.ts (división de server.ts, etapa 1): resendReplyTo, casillaAvisosAdmin, serverSupabaseInstance, getServerSupabase, getMercadoPagoConfig, …

// ==============================================================================


// → Movido a servidor/campanaZoho.ts (división de server.ts, etapa 2): ZOHO_ACCOUNTS_BASE, ZOHO_SCOPES, ZOHO_REMITENTES_PERMITIDOS, getZohoCredenciales, ZohoTokensGuardados, obtenerZohoTokensGuardados, …

// ==============================================================================
// 2. AUTENTICACIÓN ADMINISTRATIVA (ADMIN PIN Y TOKENS FIRMADOS)
// ==============================================================================


// → Movido a servidor/nucleo/auth.ts (división de server.ts, etapa 1): getAdminPin, getAdminSessionSecret, normalizePin, generateAdminToken, verifyAdminToken, …

// → Movido a servidor/nucleo/auth.ts (división de server.ts, etapa 1): pinAdminCorrecto
// → Movido a servidor/panel/sesion.ts (división de server.ts, etapa 5): 5 rutas y leerModoMantenimiento
// Sus rutas se montan acá, en el mismo lugar donde estaban (así el orden de Express no cambia).
app.use(rutasSesionAdmin);

// → Movido a servidor/nucleo/utilidades.ts (división de server.ts, etapa 1): traerTodasLasFilas
// → Movido a servidor/nucleo/utilidades.ts (división de server.ts, etapa 1): normalizarNombreComparable, normalizarNombrePorPalabras
// → Movido a servidor/nucleo/pedidos.ts (división de server.ts, etapa 3): ETAPAS_LAB, EtapaLab, puedeAvanzarEtapaLab
// → Movido a servidor/panel/pedidos.ts (división de server.ts, etapa 4): 13 rutas y COLUMNAS_PEDIDO_PANEL
// Sus rutas se montan acá, en el mismo lugar donde estaban (así el orden de Express no cambia).
app.use(rutasPanelPedidos);
app.use(rutasObservaciones); // 13/10: observaciones de la toma de fotos (pestaña «Observaciones»)
app.use(rutasBorradores); // 14/10: borradores del panel (se guardan solos mientras se escribe)

// → Movido a servidor/nucleo/auth.ts (división de server.ts, etapa 1): getLabPin, generarTokenLab, verificarTokenLab, requireLabAuth
// → Movido a servidor/nucleo/pedidos.ts (división de server.ts, etapa 2): contarImpresionesPedido
// → Movido a servidor/panel/laboratorio.ts (división de server.ts, etapa 4): 10 rutas y COLUMNAS_PEDIDO_LAB, pedidosParaLaboratorio, agruparAnuladosPorLote, anuladosDeLotesLab, idsDeFotosDelPedido, sumarImpresiones, …
// Sus rutas se montan acá, en el mismo lugar donde estaban (así el orden de Express no cambia).
app.use(rutasLaboratorio);
app.use(rutasLaboratorioExtras); // 29/10/2026: lotes de fotos extra

// → Movido a servidor/panel/pedidos.ts (división de server.ts, etapa 4): 1 ruta
// Sus rutas se montan acá, en el mismo lugar donde estaban (así el orden de Express no cambia).
app.use(rutasOrganizarPedido);

// → Movido a servidor/panel/saludErrores.ts (división de server.ts, etapa 4): 4 rutas y recortarJson, avisosErrorEnviados
// Sus rutas se montan acá, en el mismo lugar donde estaban (así el orden de Express no cambia).
app.use(rutasSaludErrores);

// → Movido a servidor/panel/pedidos.ts (división de server.ts, etapa 4): 1 ruta y motivoPedidoProtegidoParaBorrar
// Sus rutas se montan acá, en el mismo lugar donde estaban (así el orden de Express no cambia).
app.use(rutasBorrarPedido);

// → Movido a servidor/panel/fotos.ts (división de server.ts, etapa 4): 15 rutas y COLUMNAS_FOTO_PANEL, UUID_FOTO_RE, responderUrlFirmadaOriginal, rutaEnBucketDesdeUrl, pedidosQueUsanFoto, descartarFotosYaRegistradas, …
// Sus rutas se montan acá, en el mismo lugar donde estaban (así el orden de Express no cambia).
app.use(rutasAvisosFotos); // 14/10: aviso «ya están tus fotos» por curso (antes que /api/admin/fotos/:id)
app.use(rutasFotosPanel);
app.use(rutasPrepararLupa); // 25/10: copias de la lupa preparadas de antemano (servidor/panel/prepararLupa.ts)
app.use(rutasEncuesta); // 25/10: encuesta de satisfacción a las familias (servidor/familias/encuesta.ts)
app.use(rutasEmailsFamilias); // 26/10: panel «Emails» a las familias (servidor/panel/emailsFamilias.ts)
app.use(rutasNovedadesIa); // 25/10: «Lo que la IA tiene que saber» (servidor/familias/novedadesIa.ts)

// → Movido a servidor/nucleo/utilidades.ts (división de server.ts, etapa 1): enLotes
// → Movido a servidor/panel/cierreTemporada.ts (división de server.ts, etapa 4): 2 rutas y idsDeColegioParaCierre, COLUMNAS_PEDIDO_CIERRE, PedidoParaCierre, analizarPedidosParaCierre, describirPedidosCierre, idsPedidoFotosDe, …
// Sus rutas se montan acá, en el mismo lugar donde estaban (así el orden de Express no cambia).
app.use(rutasCierreTemporada);

// → Movido a servidor/familias/galeria.ts (división de server.ts, etapa 5): 2 rutas y accesoLupaGaleria, MS_ACCESO_LUPA, accesoLupaFoto
// Sus rutas se montan acá, en el mismo lugar donde estaban (así el orden de Express no cambia).
app.use(rutasGaleria);

// → Movido a servidor/nucleo/colegios.ts (división de server.ts, etapa 3): buscarColegioReal, ERROR_COLEGIO_NO_VALIDO
// → Movido a servidor/panel/colegios.ts (división de server.ts, etapa 4): 7 rutas y GRADOS_POR_DEFECTO_COLEGIO, DIVISIONES_POR_DEFECTO_COLEGIO, TURNOS_POR_DEFECTO_COLEGIO, generarSlugColegio, mapearColegioSupabase
// Sus rutas se montan acá, en el mismo lugar donde estaban (así el orden de Express no cambia).
app.use(rutasColegios);

// → Movido a servidor/nucleo/codigosCurso.ts (división de server.ts, etapa 3): determinarCodigoCursoServidor
// → Movido a servidor/nucleo/codigosCurso.ts (división de server.ts, etapa 3): normalizarCodigoSeccion, cacheCodigosSeccion, invalidarCacheCodigosSeccion, traerTodosLosCodigosSeccion
// → Movido a servidor/nucleo/codigosCurso.ts (división de server.ts, etapa 3): buscarSeccionPorCodigoSecreto
// → Movido a servidor/familias/inscripciones.ts (división de server.ts, etapa 5): 18 rutas y normalizarTelefonoServidor, normalizarDniServidor, formatearFechaHoraArgentina, sanitizarParaMinilabServidor, ultimoNumeroLista, obtenerNumeroListaSecuencial, …
// Sus rutas se montan acá, en el mismo lugar donde estaban (así el orden de Express no cambia).
app.use(rutasInscripciones);
app.use(rutasInscripcionesAdmin); // 14/10: enviar-email, rechazar y whatsapp-enviado (salieron de inscripciones.ts)
app.use(rutasSumarHijo); // 27/10: «Sumar hijo» desde Inscriptos (antes se hacía con SQL)
app.use(rutasCursosNomina);

// → Movido a servidor/familias/padron.ts (división de server.ts, etapa 5): 4 rutas y validarTokenPadronInstitucion, resolverColegioPorCodigoPadron, procesarCargaPadron
// Sus rutas se montan acá, en el mismo lugar donde estaban (así el orden de Express no cambia).
app.use(rutasPadron);

// → Movido a servidor/familias/fotoHermanos.ts (división de server.ts, etapa 5): 5 rutas y tokenFotoHermanos, linkFotoHermanos, inscripcionDeLlaveFotoHermanos, nombrePropioFotoHermanos, chicosDeInscripcionFotoHermanos, unirNombresFotoHermanos, …
// Sus rutas se montan acá, en el mismo lugar donde estaban (así el orden de Express no cambia).
app.use(rutasFotoHermanos);
app.use(rutasSolicitudesFaltantes); // 22/10: «Faltantes solicitadas» (servidor/familias/solicitudesFaltantes.ts)
app.use(rutasConvocatoriaFaltantes); // 25/10: convocar a sacar la foto faltante (servidor/familias/convocatoriaFaltantes.ts)
app.use(rutasBuscadorRostro); // 24/10: buscador por reconocimiento facial (servidor/familias/buscadorRostro.ts)
app.use(rutasDescuentos); // 22/10: códigos de descuento (servidor/pagos/descuentos.ts)

// → Movido a servidor/convenioLiquidacion.ts (división de server.ts, etapa 2): 7 rutas y VERSION_CONVENIO_SERVIDOR, CAMPOS_PRECIOS_LABORATORIO, preciosLaboratorioParaConvenio, formatearPorcentaje, resolverColegioPorCodigoConvenio, COSTOS_LIQUIDACION_DEFECTO, …
// Sus rutas se montan acá, en el mismo lugar donde estaban (así el orden de Express no cambia).
app.use(rutasConvenioLiquidacion);

// → Movido a servidor/familias/consultas.ts (división de server.ts, etapa 5): 10 rutas y ChequeoFicha, FichaFamilia, escaparIlike, armarFichaFamilia, DecisionIA, redactarRespuestaConsulta, …
// Sus rutas se montan acá, en el mismo lugar donde estaban (así el orden de Express no cambia).
app.use(rutasConsultas);
app.use(rutasConsultasAdmin); // 14/10: estado, «Responder» e «Iniciar» con clave de envío (salieron de consultas.ts)
app.use(rutasFichaCliente); // 19/10: «Ficha del cliente» desde Consultas (inscripciones, hijos, pedidos, pagos)

// → Movido a servidor/familias/solicitudesCodigo.ts (división de server.ts, etapa 5): 5 rutas y ultimoReenvioCodigoPorInscripcion, RESPUESTA_SOLICITUD_CODIGO
// Sus rutas se montan acá, en el mismo lugar donde estaban (así el orden de Express no cambia).
app.use(rutasSolicitudesCodigo);

// → Movido a servidor/nucleo/utilidades.ts (división de server.ts, etapa 1): escapeHtml
// → Movido a servidor/entrega/correos.ts (división de server.ts, etapa 3): SeccionFotosDisponible, mismoDatoSeccion, avisarFotosDisponiblesASeccion, DatosCorreoFotosHD, TipoActualizacionPedido, …
// → Movido a servidor/nucleo/accesoPedidos.ts (división de server.ts, etapa 3): tokenAccesoPedido
// → Movido a servidor/nucleo/accesoPedidos.ts (división de server.ts, etapa 3): llaveRecibida, tokenAccesoValido
// → Movido a servidor/nucleo/accesoPedidos.ts (división de server.ts, etapa 5): pedidoHabilitaDescarga
// → Movido a servidor/entrega/zipHD.ts (división de server.ts, etapa 3): nombreZipHDPedido
// → Movido a servidor/entrega/correos.ts (división de server.ts, etapa 3): enviarCorreoMejoraImpresoConfirmada
// → Movido a servidor/entrega/pedidosPagados.ts (división de server.ts, etapa 3): MAX_FOTOS_ZIP_EN_WEBHOOK, PRESUPUESTO_ZIP_WEBHOOK_MS
// → Movido a servidor/entrega/zipHD.ts (división de server.ts, etapa 3): armarZipHDConTurno
// → Movido a servidor/entrega/pedidosPagados.ts (división de server.ts, etapa 3): procesarPedidosRecienPagados, procesarUnPedidoRecienPagado, registrarComisionesDeFilas
// → Movido a servidor/nucleo/alertas.ts (división de server.ts, etapa 5): registrarAlertaPago
// → Movido a servidor/nucleo/pedidos.ts (división de server.ts, etapa 3): ESTADOS_COBRABLES
// → Movido a servidor/nucleo/limites.ts (división de server.ts, etapa 1): tocaTurnoDistribuido
// → Movido a servidor/nucleo/utilidades.ts (división de server.ts, etapa 3): mapConLimite
// → Movido a servidor/nucleo/clientes.ts (división de server.ts, etapa 1): fetchNave
// → Movido a servidor/comisionesCobro.ts (división de server.ts, etapa 2): DetalleCobro, primerNumero, detalleCobroMercadoPago, detalleCobroNave, registrarComisionDePago, leerMontoNave
// → Movido a servidor/entrega/zipHD.ts (división de server.ts, etapa 3): TAMANO_MAX_ZIP_HD, avisarAdminEntregaHD, generarYSubirZipHDParaPedido
// → Movido a servidor/pagos/cobros.ts (división de server.ts, etapa 6): copiasExtrasServidor, obtenerPedidosPendientesParaCobro, estadoPagoNave, intencionNaveRevertida, hashClaveCheckout, claveCheckoutValida, …
// → Movido a servidor/tareasProgramadas.ts (división de server.ts, etapa 6): reintentarPedidosConHDPendiente
// → Movido a servidor/nucleo/auth.ts (división de server.ts, etapa 3): autorizarTareaProgramada
// → Movido a servidor/pagos/comprobantes.ts (división de server.ts, etapa 6): 4 rutas y COMPROBANTE_TIPOS, COMPROBANTE_MAX_BYTES, filasDelPagoPorReferencia, PLAZO_TRANSFERENCIA_HORAS, MENSAJE_TRANSFERENCIA_VENCIDA, venceTransferenciaDe, …
// Sus rutas se montan acá, en el mismo lugar donde estaban (así el orden de Express no cambia).
app.use(rutasComprobantes);
// → Movido a servidor/tareasProgramadas.ts (división de server.ts, etapa 6): 3 rutas y RECORDATORIO_PAGO_HORAS, RECORDATORIO_PAGO_MAX_DIAS, RECORDATORIO_PAGO_MAX_POR_CORRIDA, urlPedidoPendiente, htmlRecordatorioPago, cancelarTransferenciasVencidas
// Sus rutas se montan acá, en el mismo lugar donde estaban (así el orden de Express no cambia).
app.use(rutasTareasProgramadas);
// → Movido a servidor/entrega/correos.ts (división de server.ts, etapa 3): urlDescargaSeguida
// → Movido a servidor/entrega/descargas.ts (división de server.ts, etapa 6): 1 ruta y USER_AGENT_ROBOT, paginaDescarga
// Sus rutas se montan acá, en el mismo lugar donde estaban (así el orden de Express no cambia).
app.use(rutasDescargas);
// → Movido a servidor/tareasProgramadas.ts (división de server.ts, etapa 6): 2 rutas
// Sus rutas se montan acá, en el mismo lugar donde estaban (así el orden de Express no cambia).
app.use(rutasTareasProgramadasHD);
// → Movido a servidor/entrega/descargas.ts (división de server.ts, etapa 6): refirmarLinkDescargaHDSiExiste

// → Movido a servidor/familias/accesoFamilias.ts (división de server.ts, etapa 5): DatosCorreoCodigoAcceso, tokenConfirmacionAcceso, linkConfirmacionAcceso, dniParcialServidor, inscripcionSinConfirmar, …

// → Movido a servidor/entrega/rutasResend.ts (división de server.ts, etapa 5): 4 rutas
// Sus rutas se montan acá, en el mismo lugar donde estaban (así el orden de Express no cambia).
app.use(rutasResend);
app.use(rutasCambiarFotosPedido); // 25/10: «Cambiar fotos» de un pedido antes del laboratorio (servidor/panel/cambiarFotosPedido.ts)

// → Movido a servidor/nucleo/precios.ts (división de server.ts, etapa 1): PRECIOS_KITS, PRECIO_CARPETA_EXTRA
// → Movido a servidor/nucleo/precios.ts (división de server.ts, etapa 1): PRECIO_FOTO_EVENTO, aplicarPrecios, preciosActuales, precioMejoraAImpreso
// → Movido a servidor/pagos/totales.ts (división de server.ts, etapa 6): 2 rutas y MAX_CARPETAS_EXTRA, MAX_FOTOS_SUELTAS, carpetasExtrasValidas, calcularTotalPedido
// Sus rutas se montan acá, en el mismo lugar donde estaban (así el orden de Express no cambia).
app.use(rutasPrecios);
app.use(rutasConfiguracion);
// → Movido a servidor/pagos/mercadoPago.ts (división de server.ts, etapa 6): 2 rutas
// Sus rutas se montan acá, en el mismo lugar donde estaban (así el orden de Express no cambia).
app.use(rutasMercadoPagoPreferencias);
// → Movido a servidor/nucleo/pedidos.ts (división de server.ts, etapa 3): tipoChoqueUnicoPedido
// → Movido a servidor/nucleo/nombres.ts (división de server.ts, etapa 5): puntajeNombres, nombresCompatibles, etiquetasDelAlumno
// → Movido a servidor/nucleo/pedidos.ts (división de server.ts, etapa 3): esCategoriaTerceraFoto
// → Movido a servidor/pagos/crearPedido.ts (división de server.ts, etapa 6): KITS_COMPRABLES_PORTAL, insertarPedidosConReintento, asegurarFriendlyIdUnico, cancelarReservasSinPagarDe, reservaEsDeLaFamilia, hijosQueSonElAlumno, …
// → Movido a servidor/nucleo/legal.ts (división de server.ts, etapa 5): VERSION_TERMINOS_SERVIDOR
// → Movido a servidor/nucleo/utilidades.ts (división de server.ts, etapa 2): ipDelCliente
// → Movido a servidor/pagos/arrepentimiento.ts (división de server.ts, etapa 6): 3 rutas y ERROR_TERMINOS_NO_ACEPTADOS, aceptacionDeTerminos
// Sus rutas se montan acá, en el mismo lugar donde estaban (así el orden de Express no cambia).
app.use(rutasArrepentimiento);
// → Movido a servidor/pagos/crearPedido.ts (división de server.ts, etapa 6): 2 rutas
// Sus rutas se montan acá, en el mismo lugar donde estaban (así el orden de Express no cambia).
app.use(rutasCrearPedido);
// → Movido a servidor/entrega/correos.ts (división de server.ts, etapa 3): enviarCorreoReservaConfirmada
// → Movido a servidor/pagos/crearPedido.ts (división de server.ts, etapa 6): 3 rutas y NOMBRES_KITS_RESERVA, cursoTieneFotosDelPack
// Sus rutas se montan acá, en el mismo lugar donde estaban (así el orden de Express no cambia).
app.use(rutasReservas);
// → Movido a servidor/pagos/mercadoPago.ts (división de server.ts, etapa 6): 1 ruta
// Sus rutas se montan acá, en el mismo lugar donde estaban (así el orden de Express no cambia).
app.use(rutasMercadoPagoWebhook);
// → Movido a servidor/pagos/nave.ts (división de server.ts, etapa 6): 3 rutas
// Sus rutas se montan acá, en el mismo lugar donde estaban (así el orden de Express no cambia).
app.use(rutasNave);

// → Movido a servidor/campanaZoho.ts (división de server.ts, etapa 2): 7 rutas y ZOHO_CAMPANA_MAX_POR_LLAMADA, ZOHO_CAMPANA_PAUSA_MS, ZOHO_CAMPANA_MAX_POR_HORA, ZOHO_CAMPANA_MAX_POR_DIA, cupoCampanaZoho
// Sus rutas se montan acá, en el mismo lugar donde estaban (así el orden de Express no cambia).
app.use(rutasCampanaZoho);
// → Movido a servidor/pagos/conciliacion.ts (división de server.ts, etapa 6): ultimaConsultaPasarela, guardarIntencionNave, conciliarPagoPendiente
// → Movido a servidor/pagos/estadoPedido.ts (división de server.ts, etapa 6): 2 rutas y aplicarMetodoPagoPendiente
// Sus rutas se montan acá, en el mismo lugar donde estaban (así el orden de Express no cambia).
app.use(rutasEstadoPedido);
// → Movido a servidor/pagos/mejoraImpreso.ts (división de server.ts, etapa 6): 1 ruta y pedidoPuedeMejorarAImpreso
// Sus rutas se montan acá, en el mismo lugar donde estaban (así el orden de Express no cambia).
app.use(rutasMejoraImpreso);
// 29/10/2026: fotos extra (pedido aparte de copias impresas sobre un kit pagado).
app.use(rutasFotosExtra);
// → Movido a servidor/pagos/buscadorPedidos.ts (división de server.ts, etapa 6): 3 rutas y FORMATO_PEDIDO_FRIENDLY_ID, nombreAbreviado, ultimoReenvioLink
// Sus rutas se montan acá, en el mismo lugar donde estaban (así el orden de Express no cambia).
app.use(rutasBuscadorPedidos);

// 10/10/2026: panel propio del colegio (/api/colegio/* con su PIN y /api/admin/colegios/:id/panel* para
// Pablo). Rutas nuevas, al final: no cambian el orden de las anteriores.
app.use(rutasPanelColegio);

// ==============================================================================
// 8. MIDDLEWARE VITE Y SERVIDO DE ARCHIVOS
// ==============================================================================

async function start() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Servidor Retrato Escolar corriendo en http://0.0.0.0:${PORT}`);
  });
}

export default app;

if (!process.env.VERCEL) {
  start();
}
