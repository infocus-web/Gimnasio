// GENERADO desde src/utils/lupaMuestra.ts por scripts/generar-lupa-eventos.mjs: no editar a mano.
var LupaMuestra = (() => {
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

  // src/utils/lupaMuestra.ts
  var lupaMuestra_exports = {};
  __export(lupaMuestra_exports, {
    montarLupa: () => montarLupa
  });
  var BORDE = 3;
  var VERSION_RECORTES = 3;
  var ESPERA_TOQUE_MS = 220;
  var MAX_RECORTES = 24;
  var TAM_MAXIMO = 0.75;
  var redondear = (v) => Math.round(v * 1e4) / 1e4;
  function montarLupa(contenedor, img, opciones) {
    var _a, _b, _c;
    const diametroCompu = (_a = opciones.diametroCompu) != null ? _a : 360;
    const diametroCelular = (_b = opciones.diametroCelular) != null ? _b : 255;
    const fraccionCelular = (_c = opciones.fraccionCelular) != null ? _c : 0.45;
    const puedeHover = typeof window.matchMedia === "function" && window.matchMedia("(hover: hover) and (pointer: fine)").matches;
    if (getComputedStyle(contenedor).position === "static") contenedor.style.position = "relative";
    const lente = document.createElement("div");
    lente.setAttribute("aria-hidden", "true");
    lente.className = "lupa-lente";
    Object.assign(lente.style, {
      position: "absolute",
      display: "none",
      boxSizing: "border-box",
      borderRadius: "50%",
      border: `${BORDE}px solid rgba(255,255,255,0.92)`,
      boxShadow: "0 6px 24px rgba(0,0,0,0.45)",
      overflow: "hidden",
      pointerEvents: "none",
      zIndex: "40",
      background: "rgba(255,255,255,0.06)"
    });
    const recorteImg = document.createElement("img");
    recorteImg.alt = "";
    recorteImg.draggable = false;
    Object.assign(recorteImg.style, {
      position: "absolute",
      maxWidth: "none",
      maxHeight: "none",
      pointerEvents: "none",
      userSelect: "none",
      display: "none"
    });
    lente.appendChild(recorteImg);
    contenedor.appendChild(lente);
    let pista = null;
    if (opciones.pista !== false) {
      pista = document.createElement("div");
      pista.className = "lupa-pista";
      pista.setAttribute("aria-hidden", "true");
      pista.textContent = puedeHover ? "Pasá el mouse por la foto para verla nítida" : "Mantené el dedo apretado sobre la foto para verla nítida";
      Object.assign(pista.style, {
        position: "absolute",
        left: "50%",
        bottom: "10px",
        transform: "translateX(-50%)",
        background: "rgba(15,23,42,0.72)",
        color: "#fff",
        font: "600 12px/1.3 system-ui, -apple-system, Segoe UI, Roboto, sans-serif",
        padding: "5px 12px",
        borderRadius: "999px",
        pointerEvents: "none",
        whiteSpace: "nowrap",
        maxWidth: "92%",
        overflow: "hidden",
        textOverflow: "ellipsis",
        zIndex: "39",
        transition: "opacity .15s"
      });
      contenedor.appendChild(pista);
    }
    const recortes = /* @__PURE__ */ new Map();
    const fallidos = /* @__PURE__ */ new Set();
    let enVuelo = null;
    let errores = 0;
    let generacion = 0;
    let ultimo = null;
    let ultimoUsoTactil = 0;
    let mostrado = null;
    function rectFoto() {
      const nw = img.naturalWidth;
      const nh = img.naturalHeight;
      if (!nw || !nh) return null;
      const rc = contenedor.getBoundingClientRect();
      const ri = img.getBoundingClientRect();
      if (!ri.width || !ri.height) return null;
      const escala = Math.min(ri.width / nw, ri.height / nh);
      const w = nw * escala;
      const h = nh * escala;
      return {
        x: ri.left - rc.left - contenedor.clientLeft + (ri.width - w) / 2,
        y: ri.top - rc.top - contenedor.clientTop + (ri.height - h) / 2,
        w,
        h
      };
    }
    function ocultar() {
      lente.style.display = "none";
      ultimo = null;
      if (pista) pista.style.opacity = "1";
    }
    function pintar(cx, cy, d, r) {
      lente.style.width = `${d}px`;
      lente.style.height = `${d}px`;
      lente.style.left = `${cx - d / 2}px`;
      lente.style.top = `${cy - d / 2}px`;
      lente.style.display = "block";
      if (pista) pista.style.opacity = "0";
      ultimo = { cx, cy, d };
      const zona = {
        x0: Math.max(0, (cx - d / 2 - r.x) / r.w),
        x1: Math.min(1, (cx + d / 2 - r.x) / r.w),
        y0: Math.max(0, (cy - d / 2 - r.y) / r.h),
        y1: Math.min(1, (cy + d / 2 - r.y) / r.h)
      };
      let elegido = null;
      let mejor = 0;
      let cubre = false;
      for (const rec of recortes.values()) {
        const ix = Math.max(0, Math.min(zona.x1, rec.x + rec.w) - Math.max(zona.x0, rec.x));
        const iy = Math.max(0, Math.min(zona.y1, rec.y + rec.h) - Math.max(zona.y0, rec.y));
        const area = ix * iy;
        const completo = rec.x <= zona.x0 + 1e-3 && rec.x + rec.w >= zona.x1 - 1e-3 && rec.y <= zona.y0 + 1e-3 && rec.y + rec.h >= zona.y1 - 1e-3;
        if (completo && (!cubre || area >= mejor)) {
          elegido = rec;
          mejor = area;
          cubre = true;
        } else if (!cubre && area > mejor) {
          elegido = rec;
          mejor = area;
        }
      }
      if (elegido) {
        if (mostrado !== elegido) {
          if (mostrado && !Array.from(recortes.values()).includes(mostrado)) URL.revokeObjectURL(mostrado.url);
          recorteImg.src = elegido.url;
          mostrado = elegido;
        }
        recorteImg.style.display = "block";
        recorteImg.style.left = `${r.x + elegido.x * r.w - (cx - d / 2 + BORDE)}px`;
        recorteImg.style.top = `${r.y + elegido.y * r.h - (cy - d / 2 + BORDE)}px`;
        recorteImg.style.width = `${elegido.w * r.w}px`;
        recorteImg.style.height = `${elegido.h * r.h}px`;
      } else {
        recorteImg.style.display = "none";
      }
      if (!cubre) pedir(cx, cy, d, r);
    }
    function pedir(cx, cy, d, r) {
      if (enVuelo || errores >= 4) return;
      let s = Math.min(TAM_MAXIMO, Math.max(0.1, 1.6 * d / r.w));
      s = Math.round(s * 20) / 20;
      const paso = s / 6;
      const pasoV = paso * r.w / r.h;
      const u = Math.min(1, Math.max(0, Math.round((cx - r.x) / r.w / paso) * paso));
      const v = Math.min(1, Math.max(0, Math.round((cy - r.y) / r.h / pasoV) * pasoV));
      const clave = `${redondear(u)}|${redondear(v)}|${s}`;
      if (recortes.has(clave) || fallidos.has(clave)) return;
      const base = opciones.urlRecorte(redondear(u), redondear(v), s);
      if (!base) return;
      const url = `${base}${base.includes("?") ? "&" : "?"}v=${VERSION_RECORTES}`;
      const ctrl = new AbortController();
      enVuelo = ctrl;
      const miGeneracion = generacion;
      fetch(url, { credentials: "same-origin", signal: ctrl.signal }).then(async (resp) => {
        if (!resp.ok) throw new Error(String(resp.status));
        const region = String(resp.headers.get("X-Lupa-Region") || "").split(",").map(Number);
        if (region.length !== 6 || region.some((n) => !Number.isFinite(n)) || !region[4] || !region[5]) throw new Error("sin región");
        const blob = await resp.blob();
        if (miGeneracion !== generacion) return;
        const [left, top, ancho, alto, W, H] = region;
        recortes.set(clave, { url: URL.createObjectURL(blob), x: left / W, y: top / H, w: ancho / W, h: alto / H });
        errores = 0;
        while (recortes.size > MAX_RECORTES) {
          const viejo = recortes.keys().next().value;
          if (viejo === void 0) break;
          const rec = recortes.get(viejo);
          recortes.delete(viejo);
          if (rec && rec !== mostrado) URL.revokeObjectURL(rec.url);
        }
      }).catch((e) => {
        if (e && e.name === "AbortError") return;
        fallidos.add(clave);
        errores++;
      }).finally(() => {
        if (enVuelo === ctrl) enVuelo = null;
        if (miGeneracion !== generacion) return;
        const r2 = rectFoto();
        if (ultimo && r2) pintar(ultimo.cx, ultimo.cy, ultimo.d, r2);
      });
    }
    function diametro(r, tactil) {
      if (tactil) return Math.round(Math.min(diametroCelular, r.w * fraccionCelular));
      return Math.round(Math.min(diametroCompu, Math.min(r.w, r.h) * 0.8));
    }
    function mostrarEn(clientX, clientY, tactil) {
      const r = rectFoto();
      if (!r) {
        ocultar();
        return false;
      }
      const rc = contenedor.getBoundingClientRect();
      const px = clientX - rc.left - contenedor.clientLeft;
      const py = clientY - rc.top - contenedor.clientTop;
      if (px < r.x || py < r.y || px > r.x + r.w || py > r.y + r.h) {
        ocultar();
        return false;
      }
      const d = diametro(r, tactil);
      let cx = px;
      let cy = py;
      if (tactil) {
        cy = Math.max(r.y, py - d / 2 - 24);
        cx = Math.min(Math.max(px, r.x), r.x + r.w);
      }
      pintar(cx, cy, d, r);
      return true;
    }
    const alMover = (e) => {
      mostrarEn(e.clientX, e.clientY, false);
    };
    const alSalir = () => ocultar();
    if (puedeHover) {
      contenedor.addEventListener("mousemove", alMover);
      contenedor.addEventListener("mouseleave", alSalir);
    }
    let temporizador;
    let inicio = null;
    let activa = false;
    const alTocar = (e) => {
      if (e.touches.length !== 1) {
        cancelar();
        return;
      }
      const t = e.touches[0];
      inicio = { x: t.clientX, y: t.clientY };
      activa = false;
      clearTimeout(temporizador);
      temporizador = setTimeout(() => {
        var _a2;
        if (inicio && mostrarEn(inicio.x, inicio.y, true)) {
          activa = true;
          ultimoUsoTactil = Date.now();
          try {
            (_a2 = navigator.vibrate) == null ? void 0 : _a2.call(navigator, 10);
          } catch (e2) {
          }
        }
      }, ESPERA_TOQUE_MS);
    };
    const alArrastrar = (e) => {
      const t = e.touches[0];
      if (!inicio || !t) return;
      if (activa) {
        e.preventDefault();
        ultimoUsoTactil = Date.now();
        mostrarEn(t.clientX, t.clientY, true);
        return;
      }
      if (Math.abs(t.clientX - inicio.x) > 8 || Math.abs(t.clientY - inicio.y) > 8) {
        clearTimeout(temporizador);
        inicio = null;
      }
    };
    const alSoltar = (e) => {
      clearTimeout(temporizador);
      if (activa) {
        if (e.cancelable) e.preventDefault();
        ultimoUsoTactil = Date.now();
        ocultar();
      }
      activa = false;
      inicio = null;
    };
    function cancelar() {
      clearTimeout(temporizador);
      if (activa) ultimoUsoTactil = Date.now();
      activa = false;
      inicio = null;
      ocultar();
    }
    const sinMenu = (e) => e.preventDefault();
    contenedor.addEventListener("touchstart", alTocar, { passive: true });
    contenedor.addEventListener("touchmove", alArrastrar, { passive: false });
    contenedor.addEventListener("touchend", alSoltar, { passive: false });
    contenedor.addEventListener("touchcancel", cancelar);
    contenedor.addEventListener("contextmenu", sinMenu);
    window.addEventListener("resize", ocultar);
    function olvidarRecortes() {
      generacion++;
      enVuelo == null ? void 0 : enVuelo.abort();
      enVuelo = null;
      for (const rec of recortes.values()) URL.revokeObjectURL(rec.url);
      if (mostrado && !Array.from(recortes.values()).includes(mostrado)) URL.revokeObjectURL(mostrado.url);
      recortes.clear();
      fallidos.clear();
      errores = 0;
      mostrado = null;
      recorteImg.removeAttribute("src");
      recorteImg.style.display = "none";
    }
    function precalentar() {
      const hacer = () => {
        const r = rectFoto();
        if (!r || ultimo) return;
        const d = diametro(r, !puedeHover);
        pedir(r.x + r.w / 2, r.y + r.h / 2, d, r);
      };
      if (img.complete && img.naturalWidth) hacer();
      else img.addEventListener("load", hacer, { once: true });
    }
    precalentar();
    return {
      destruir() {
        cancelar();
        olvidarRecortes();
        contenedor.removeEventListener("mousemove", alMover);
        contenedor.removeEventListener("mouseleave", alSalir);
        contenedor.removeEventListener("touchstart", alTocar);
        contenedor.removeEventListener("touchmove", alArrastrar);
        contenedor.removeEventListener("touchend", alSoltar);
        contenedor.removeEventListener("touchcancel", cancelar);
        contenedor.removeEventListener("contextmenu", sinMenu);
        window.removeEventListener("resize", ocultar);
        lente.remove();
        pista == null ? void 0 : pista.remove();
      },
      ocultar,
      reiniciar() {
        cancelar();
        olvidarRecortes();
        precalentar();
      },
      usadaRecien(ms = 400) {
        return activa || Date.now() - ultimoUsoTactil < ms;
      }
    };
  }
  return __toCommonJS(lupaMuestra_exports);
})();
