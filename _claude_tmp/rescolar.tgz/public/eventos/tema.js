// Modo noche / día del panel de eventos. Usa la MISMA preferencia que el panel de administrador
// (localStorage "modo_noche_panel": "on" / "off"); si nunca se eligió, sigue al sistema.
// Se carga en el <head> (sin defer) para que la página no "parpadee" en blanco.
(function () {
  'use strict';
  var CLAVE = 'modo_noche_panel';
  function preferencia() {
    try {
      var g = localStorage.getItem(CLAVE);
      if (g === 'on') return true;
      if (g === 'off') return false;
    } catch (e) { /* sin almacenamiento */ }
    try { return window.matchMedia('(prefers-color-scheme: dark)').matches; } catch (e) { return false; }
  }
  function aplicar(noche) {
    document.documentElement.setAttribute('data-tema', noche ? 'noche' : 'dia');
    var b = document.getElementById('btn-tema');
    if (b) {
      b.textContent = noche ? '☀' : '☾';
      b.title = noche ? 'Pasar a modo día' : 'Pasar a modo noche';
      b.setAttribute('aria-label', b.title);
    }
  }
  aplicar(preferencia());
  document.addEventListener('DOMContentLoaded', function () {
    aplicar(preferencia());
    var b = document.getElementById('btn-tema');
    if (b) b.addEventListener('click', function () {
      var nuevo = document.documentElement.getAttribute('data-tema') !== 'noche';
      try { localStorage.setItem(CLAVE, nuevo ? 'on' : 'off'); } catch (e) { /* nada */ }
      aplicar(nuevo);
    });
  });
  try {
    window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', function () {
      try { if (localStorage.getItem(CLAVE)) return; } catch (e) { /* nada */ }
      aplicar(preferencia());
    });
  } catch (e) { /* navegador viejo */ }
})();
