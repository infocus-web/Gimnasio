// Panel de eventos: importar los originales desde Google Drive (17/10/2026, pedido de Pablo).
// Pablo sube los originales sólo a Drive; acá pega el link de la carpeta del evento y la web arma las
// muestras, miniaturas y la copia de la lupa. El original queda en Drive y se copia a la web recién
// cuando alguien paga (eventos/originalesDrive.ts). Usa lo que expone admin.js en window.panelEventos.
(function () {
  'use strict';
  var $ = function (id) { return document.getElementById(id); };
  var importando = false;

  function panel() { return window.panelEventos; }

  // Al abrir un evento, el campo muestra la carpeta que ya tenía elegida.
  var ultimoEvento = null;
  setInterval(function () {
    var p = panel();
    var ev = p && p.estado.evento;
    if (!ev || ev.id === ultimoEvento) return;
    ultimoEvento = ev.id;
    $('drive-carpeta').value = ev.drive_carpeta_id ? 'https://drive.google.com/drive/folders/' + ev.drive_carpeta_id : '';
  }, 500);

  function mostrar(texto, hechas, total) {
    $('progreso').hidden = false;
    $('barra-relleno').style.width = (total ? Math.round((hechas / total) * 100) : 100) + '%';
    $('texto-progreso').textContent = texto;
  }

  $('btn-importar-drive').addEventListener('click', function () {
    var p = panel();
    if (!p || !p.estado.evento || importando) return;
    if (p.estado.subiendo) { p.aviso('Esperá a que termine la subida de fotos.', true); return; }
    var carpeta = $('drive-carpeta').value.trim();
    if (!carpeta) { p.aviso('Pegá el link de la carpeta de Drive del evento.', true); return; }
    var eventoId = p.estado.evento.id;
    var hechas = 0;
    var total = 0;
    var errores = [];
    var vueltasSinAvance = 0;
    importando = true;
    $('btn-importar-drive').disabled = true;
    mostrar('Buscando las fotos en Drive…', 0, 1);

    function vuelta() {
      return p.conReintentos(function () {
        return p.api('POST', '/api/eventos/admin/eventos/' + eventoId + '/importar-drive', { carpeta: carpeta }, 58000);
      }, [3000, 8000]).then(function (d) {
        hechas += d.importadas;
        if (!total) total = d.restantes + hechas;
        (d.errores || []).forEach(function (n) { if (errores.indexOf(n) < 0) errores.push(n); });
        vueltasSinAvance = d.importadas ? 0 : vueltasSinAvance + 1;
        if (d.importadas) p.recargarFotos();
        if (d.restantes > 0 && vueltasSinAvance < 2) {
          mostrar('Importando desde Drive: ' + hechas + ' de ' + total + ' — no cierres esta pestaña.', hechas, total);
          return vuelta();
        }
        if (!total && !hechas) {
          mostrar(d.enDrive ? 'Todas las fotos de esa carpeta ya estaban importadas (' + d.enDrive + ').' : 'No encontramos fotos JPG en esa carpeta de Drive.', 1, 1);
          return;
        }
        mostrar(errores.length
          ? 'Se importaron ' + hechas + ' foto(s). No se pudieron importar: ' + errores.slice(0, 8).join(', ') + (errores.length > 8 ? '…' : '') + '. Tocá «Importar desde Drive» de nuevo para reintentarlas.'
          : 'Listo: se importaron ' + hechas + ' foto(s) desde Drive.', hechas, total || hechas);
        if (hechas) p.avisarAnotados(eventoId);
      });
    }
    vuelta().catch(function (e) {
      mostrar('Se cortó la importación (' + e.message + '). Tocá «Importar desde Drive» para seguir: retoma donde quedó.', hechas, total || 1);
    }).then(function () {
      importando = false;
      $('btn-importar-drive').disabled = false;
      p.recargarFotos();
    });
  });
})();
