// Panel de EVENTOS — ayudas que eventos-admin.html carga ANTES de admin.js.
// 1) Ventas en la tarjeta de cada evento (11/10/2026, pedido de Pablo: «ver si hay compras
// nuevas desde la miniatura de cada evento, y el importe recaudado hasta la fecha»).
// El servidor manda `ev.ventas` = { pagados, recaudado, nuevas, por_revisar } (ver eventos/resumenVentas.ts).
// «Nuevas» = pagadas después de la última vez que se abrieron los pedidos del evento.
(function () {
  'use strict';
  function plural(n, uno, varios) { return n + ' ' + (n === 1 ? uno : varios); }
  function bloque(ev, el, pesos) {
    var v = ev.ventas || { pagados: 0, recaudado: 0, nuevas: 0, por_revisar: 0 };
    var caja = el('div', 'ventas-evento');
    var avisos = el('div', 'ventas-avisos');
    if (v.nuevas) avisos.appendChild(el('span', 'chip chip-nueva', '● ' + plural(v.nuevas, 'compra nueva', 'compras nuevas')));
    if (v.por_revisar) avisos.appendChild(el('span', 'chip chip-pend', plural(v.por_revisar, 'comprobante para revisar', 'comprobantes para revisar')));
    if (avisos.childNodes.length) caja.appendChild(avisos);
    var linea = el('p', 'ventas-total');
    if (v.pagados) {
      linea.appendChild(el('strong', '', pesos(v.recaudado)));
      linea.appendChild(document.createTextNode(' recaudado · ' + plural(v.pagados, 'pedido pagado', 'pedidos pagados')));
    } else {
      linea.textContent = 'Sin ventas todavía';
      linea.classList.add('sutil');
    }
    caja.appendChild(linea);
    return caja;
  }
  window.VentasEvento = { bloque: bloque };
})();

// 2) Muestras con marca de agua (y desenfoque «con lupa») que el navegador arma al subir fotos. 14/10/2026: se
// pasaron tal cual desde admin.js (techo de líneas). Misma receta que lupa/muestra.ts en el servidor.
(function () {
  'use strict';
  // Marca de agua quemada en los píxeles (mismo estilo que las muestras de los kits).
  // 03/10: se volvió al diseño original a pedido de Pablo (la versión "reforzada" tapaba demasiado).
  // 04/10: el texto invita a usar la lupa (la foto nítida se ve sólo dentro de la lupa). Misma receta
  // que lupa/muestra.ts en el servidor: si se cambia acá, cambiarla allá también.
  function dibujarMarcaDeAgua(ctx, ancho, alto, lupa) {
    var texto = lupa ? 'PASÁ LA LUPA POR LA IMAGEN' : 'MUESTRA · RETRATO ESCOLAR';
    var tam = Math.max(12, Math.round(ancho * 0.032));
    ctx.save();
    ctx.font = 'bold ' + tam + 'px sans-serif';
    ctx.fillStyle = 'rgba(255, 255, 255, 0.6)';
    ctx.shadowColor = 'rgba(0, 0, 0, 0.65)';
    ctx.shadowBlur = 4;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    var pasoX = ctx.measureText(texto).width * 1.25;
    var pasoY = alto * 0.26;
    ctx.translate(ancho / 2, alto / 2);
    ctx.rotate((-25 * Math.PI) / 180);
    var fila = 0;
    for (var y = -alto * 1.1; y < alto * 1.1; y += pasoY) {
      var desfase = fila % 2 === 0 ? 0 : pasoX / 2;
      for (var x = -ancho * 1.1 + desfase; x < ancho * 1.1; x += pasoX) ctx.fillText(texto, x, y);
      fila++;
    }
    ctx.restore();
  }

  // 04/10: desenfoque de la muestra con lupa: sigma 1,35 px en una muestra de 800 px (Pablo pidió un 50%
  // más que el "muy suave" de 0,9). Igual que SIGMA_DESENFOQUE_800 en lupa/muestra.ts.
  function sigmaDesenfoque(lado) {
    return Math.max(0.3, 1.35 * (lado / 800));
  }
  function dibujarDesenfocada(ctx, bitmap, ancho, alto) {
    var sigma = sigmaDesenfoque(Math.max(ancho, alto));
    if (typeof ctx.filter === 'string') {
      ctx.filter = 'blur(' + sigma.toFixed(2) + 'px)';
      ctx.drawImage(bitmap, 0, 0, ancho, alto);
      ctx.filter = 'none';
      return;
    }
    // Navegadores sin filtros en canvas (Safari): se achica y se vuelve a agrandar, que suaviza parecido.
    var chico = document.createElement('canvas');
    chico.width = Math.max(1, Math.round(ancho / (1 + sigma)));
    chico.height = Math.max(1, Math.round(alto / (1 + sigma)));
    chico.getContext('2d').drawImage(bitmap, 0, 0, chico.width, chico.height);
    ctx.imageSmoothingQuality = 'high';
    ctx.drawImage(chico, 0, 0, ancho, alto);
    chico.width = chico.height = 0;
  }

  // lupa = true: desenfoque suave + «PASÁ LA LUPA»; false: la muestra clásica de siempre.
  function copiaReducida(bitmap, maximo, calidad, lupa) {
    var escala = Math.min(1, maximo / Math.max(bitmap.width, bitmap.height));
    var c = document.createElement('canvas');
    c.width = Math.round(bitmap.width * escala);
    c.height = Math.round(bitmap.height * escala);
    var ctx = c.getContext('2d');
    if (lupa) dibujarDesenfocada(ctx, bitmap, c.width, c.height);
    else ctx.drawImage(bitmap, 0, 0, c.width, c.height);
    dibujarMarcaDeAgua(ctx, c.width, c.height, lupa);
    return new Promise(function (ok, mal) {
      c.toBlob(function (b) { b ? ok(b) : mal(new Error('No se pudo generar la muestra')); }, 'image/jpeg', calidad);
    });
  }
  window.MuestrasEvento = { copiaReducida: copiaReducida };
})();
