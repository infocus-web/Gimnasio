// Página de familias de EVENTOS — retratoescolar.com.ar/eventos/CÓDIGO
// Galería con marca de agua → elegir digital / 15x21 / 20x30 por foto → datos → pago.
// Con ?pedido=…&t=… muestra el estado del pedido (comprobante, descargas).
(function () {
  'use strict';

  const $ = (id) => document.getElementById(id);
  const NOMBRES = { digital: 'Digital', '15x21': 'Impresa 15x21', '20x30': 'Impresa 20x30' };
  const IMPRESAS = ['15x21', '20x30'];
  const estado = { codigo: '', evento: null, fotos: [], carrito: {}, visorIndice: -1 };

  // ---------------- utilidades ----------------
  const pesos = (n) => '$' + Math.round(Number(n) || 0).toLocaleString('es-AR');
  function el(tag, clase, texto) {
    const e = document.createElement(tag);
    if (clase) e.className = clase;
    if (texto !== undefined) e.textContent = texto;
    return e;
  }
  let timerAviso;
  function aviso(texto, esError) {
    const a = $('aviso');
    a.textContent = texto;
    a.className = 'aviso' + (esError ? ' error-aviso' : '');
    a.hidden = false;
    clearTimeout(timerAviso);
    timerAviso = setTimeout(() => { a.hidden = true; }, esError ? 6000 : 3000);
  }
  function mostrar(pantalla) {
    ['codigo', 'cargando', 'pronto', 'galeria', 'carrito', 'pedido'].forEach((p) => { $('p-' + p).hidden = p !== pantalla; });
    actualizarBarra();
    window.scrollTo(0, 0);
  }
  async function pedirJson(url, opciones) {
    let r;
    try {
      r = await fetch(url, opciones);
    } catch (e) {
      // Sin señal o se cortó la conexión: mensaje claro (antes salía "Failed to fetch" en inglés).
      const err = new Error('No pudimos conectarnos. Revisá tu conexión y probá de nuevo.');
      err.status = 0;
      throw err;
    }
    let d;
    try { d = await r.json(); } catch (e) { d = { success: false, error: 'No pudimos conectarnos. Probá de nuevo.' }; }
    if (!r.ok || !d.success) {
      const err = Object.assign(new Error(d.error || 'Error ' + r.status), { status: r.status, datos: d });
      throw err;
    }
    return d;
  }
  function fechaLarga(iso) {
    if (!iso) return '';
    const [a, m, d] = iso.split('-').map(Number);
    return new Date(a, m - 1, d).toLocaleDateString('es-AR', { day: 'numeric', month: 'long', year: 'numeric' });
  }
  // 11/10/2026: dos envíos al laboratorio (mitad del plazo y cierre); fecha_primer_envio viene calculada del servidor.
  function textoPlazoImpresas(ev) {
    const hoy = new Date(Date.now() - 3 * 3600 * 1000).toISOString().slice(0, 10), cierre = ev.fecha_limite ? fechaLarga(ev.fecha_limite) : '';
    if (cierre && ev.fecha_primer_envio && hoy <= ev.fecha_primer_envio) return 'Las impresas van al laboratorio en dos envíos: si pagás hasta el ' + fechaLarga(ev.fecha_primer_envio) + ', entran en el primero y se entregan dentro de los 10 días hábiles siguientes; si pagás después, entran en el segundo (al cierre de pedidos, el ' + cierre + ') y se entregan dentro de los 10 días hábiles siguientes a esa fecha.';
    if (cierre && hoy <= ev.fecha_limite) return 'Las impresas entran en el envío al laboratorio del cierre de pedidos (el ' + cierre + ') y se entregan dentro de los 10 días hábiles siguientes.';
    return 'Las impresas se entregan dentro de los 10 días hábiles posteriores al pago.';
  }
  function fechaHora(iso) {
    return new Date(iso).toLocaleString('es-AR', { timeZone: 'America/Argentina/Buenos_Aires', weekday: 'long', day: 'numeric', month: 'numeric', hour: '2-digit', minute: '2-digit', hourCycle: 'h23' }) + ' h';
  }
  function bloquearCopia(img) {
    img.draggable = false;
    img.addEventListener('contextmenu', (e) => e.preventDefault());
  }

  // ---------------- carrito ----------------
  const claveCarrito = () => 'ev-carrito-' + estado.codigo;
  function guardarCarrito() {
    try { localStorage.setItem(claveCarrito(), JSON.stringify(estado.carrito)); } catch (e) { /* sin almacenamiento */ }
  }
  function leerCarrito() {
    try {
      const c = JSON.parse(localStorage.getItem(claveCarrito()) || '{}');
      const validas = new Set(estado.fotos.map((f) => f.id));
      estado.carrito = {};
      Object.keys(c).forEach((id) => {
        if (!validas.has(id) || !c[id]) return;
        // Si el evento dejó de ofrecer un formato (precio 0), esa parte de la selección se descarta.
        const sel = { digital: !!c[id].digital && disponible('digital'), '15x21': 0, '20x30': 0 };
        IMPRESAS.forEach((f) => { if (disponible(f)) sel[f] = Math.max(0, Math.min(50, Math.round(Number(c[id][f]) || 0))); });
        if (sel.digital || tieneImpresa(sel)) estado.carrito[id] = sel;
      });
      guardarCarrito();
    } catch (e) { estado.carrito = {}; }
  }
  function vaciarCarrito() {
    estado.carrito = {};
    try { localStorage.removeItem(claveCarrito()); } catch (e) { /* nada */ }
  }
  const precio = (formato) => {
    const ev = estado.evento;
    return formato === 'digital' ? ev.precio_digital : formato === '15x21' ? ev.precio_15x21 : ev.precio_20x30;
  };
  const disponible = (formato) => precio(formato) > 0;
  const tieneImpresa = (sel) => IMPRESAS.some((f) => (sel[f] || 0) > 0);
  // 05/10: la impresa sólo incluye la digital si el evento vende digitales (precio > 0), igual que el servidor.
  function digitalIncluido(sel) { return Boolean(estado.evento.impresa_incluye_digital) && disponible('digital') && tieneImpresa(sel); }
  function seleccion(fotoId) { return estado.carrito[fotoId] || { digital: false, '15x21': 0, '20x30': 0 }; }
  function fijar(fotoId, sel) {
    const vacia = !sel.digital && !tieneImpresa(sel);
    if (vacia) delete estado.carrito[fotoId];
    else estado.carrito[fotoId] = sel;
    guardarCarrito();
  }
  function lineas() {
    const salida = [];
    estado.fotos.forEach((foto) => {
      const sel = estado.carrito[foto.id];
      if (!sel) return;
      if (sel.digital && !digitalIncluido(sel) && disponible('digital')) salida.push({ foto, formato: 'digital', cantidad: 1, subtotal: precio('digital') });
      IMPRESAS.forEach((f) => {
        if ((sel[f] || 0) > 0 && disponible(f)) salida.push({ foto, formato: f, cantidad: sel[f], subtotal: precio(f) * sel[f] });
      });
    });
    return salida;
  }
  const total = () => lineas().reduce((a, l) => a + l.subtotal, 0);
  const D = window.DescuentoEvento.iniciar({ $, el, pesos, pedirJson, lineas, codigoEvento: () => estado.codigo, repintar: () => pintarLineas() }), totalAPagar = () => total() - D.monto(); // 27/10: código de descuento (descuento.js)
  function actualizarBarra() {
    const cantFotos = Object.keys(estado.carrito).length;
    const visible = cantFotos > 0 && !$('p-galeria').hidden;
    $('barra-carrito').hidden = !visible;
    if (visible) {
      $('bc-cantidad').textContent = cantFotos + (cantFotos === 1 ? ' foto elegida' : ' fotos elegidas');
      $('bc-total').textContent = 'Total ' + pesos(total());
    }
  }

  // ---------------- código ----------------
  $('form-codigo').addEventListener('submit', (e) => {
    e.preventDefault();
    const codigo = $('input-codigo').value.trim().toUpperCase().replace(/\s+/g, '');
    if (codigo) location.href = '/eventos/' + encodeURIComponent(codigo);
  });


  // ---------------- pedidos ya hechos desde este celular ----------------
  // Se guardan en el navegador (sin datos personales: número, nombre del nene, total y estado) para
  // avisar en la galería "ya tenés un pedido" y no hacer uno nuevo sin querer.
  const clavePedidos = (codigo) => 'ev-pedidos-' + String(codigo || '').toUpperCase();
  function leerPedidosGuardados(codigo) {
    try {
      const l = JSON.parse(localStorage.getItem(clavePedidos(codigo)) || '[]');
      return Array.isArray(l) ? l.filter((x) => x && x.id && x.llave) : [];
    } catch (e) { return []; }
  }
  function guardarPedidos(codigo, lista) {
    try { localStorage.setItem(clavePedidos(codigo), JSON.stringify(lista.slice(0, 10))); } catch (e) { /* sin almacenamiento */ }
  }
  function recordarPedido(codigo, datos) {
    if (!codigo || !datos.id || !datos.llave) return;
    const lista = leerPedidosGuardados(codigo);
    const previo = lista.find((x) => x.id === datos.id) || {};
    guardarPedidos(codigo, [Object.assign({}, previo, datos)].concat(lista.filter((x) => x.id !== datos.id)));
  }
  const urlPedido = (codigo, x) => '/eventos/' + encodeURIComponent(codigo) + '?pedido=' + encodeURIComponent(x.id) + '&t=' + encodeURIComponent(x.llave);
  const sinTerminar = (x) => x.estado === 'pendiente';
  function textoEstadoGuardado(x) {
    if (x.estado === 'pagado') return ['Pagado ✓', 'ok'];
    if (x.medio === 'mercadopago') return ['Pago con Mercado Pago sin completar', 'falta'];
    if (x.comprobante) return ['Comprobante enviado: lo estamos verificando', 'espera'];
    return ['Falta subir el comprobante de la transferencia', 'falta'];
  }
  function pintarMisPedidos() {
    const cont = $('mis-pedidos');
    const lista = leerPedidosGuardados(estado.codigo).filter((x) => x.estado === 'pendiente' || x.estado === 'pagado');
    cont.textContent = '';
    cont.hidden = !lista.length;
    if (!lista.length) return;
    const pendientes = lista.filter(sinTerminar);
    cont.className = 'mis-pedidos' + (pendientes.length ? ' con-pendiente' : '');
    cont.appendChild(el('h2', '', pendientes.length
      ? (pendientes.length === 1 ? 'Ya tenés un pedido sin terminar' : 'Ya tenés ' + pendientes.length + ' pedidos sin terminar')
      : (lista.length === 1 ? 'Ya hiciste un pedido de este evento' : 'Ya hiciste ' + lista.length + ' pedidos de este evento')));
    lista.forEach((x) => {
      const fila = el('a', 'mi-pedido');
      fila.href = urlPedido(estado.codigo, x);
      const info = el('div', 'info');
      info.appendChild(el('strong', '', 'Pedido ' + (x.numero || '') + (x.nino ? ' · para ' + x.nino : '')));
      const est = textoEstadoGuardado(x);
      info.appendChild(el('span', 'mi-estado ' + est[1], est[0] + (x.total ? ' · ' + pesos(x.total) : '')));
      fila.appendChild(info);
      fila.appendChild(el('span', 'mi-ir', est[1] !== 'falta' ? 'Ver →' : x.medio === 'mercadopago' ? 'Completar el pago →' : 'Subir comprobante →'));
      cont.appendChild(fila);
    });
    if (pendientes.length) cont.appendChild(el('p', 'sutil', 'Si querés sumar más fotos, podés elegirlas abajo: se hace un pedido nuevo, aparte.'));
  }
  // Trae el estado actual de cada pedido guardado (pudo haberse pagado, vencido o cancelado).
  async function refrescarMisPedidos() {
    const codigo = estado.codigo;
    const lista = leerPedidosGuardados(codigo);
    if (!lista.length) return;
    const nuevos = await Promise.all(lista.map(async (x, i) => {
      if (i >= 6 || x.estado === 'cancelado') return x; // los vencidos se consultan: se pueden pagar tarde
      try {
        const p = (await pedirJson('/api/eventos/pedido/' + encodeURIComponent(x.id) + '?t=' + encodeURIComponent(x.llave))).pedido;
        return Object.assign({}, x, { numero: p.numero, nino: p.ninoNombre, total: p.total, estado: p.estado, medio: p.medioPago, comprobante: !!p.comprobanteSubidoEn });
      } catch (e) {
        return e.status === 403 || e.status === 404 ? null : x;
      }
    }));
    if (codigo !== estado.codigo) return;
    guardarPedidos(codigo, nuevos.filter(Boolean));
    pintarMisPedidos();
  }
  function pintarAvisoOtroPedido() {
    const cont = $('aviso-otro-pedido');
    const pendientes = leerPedidosGuardados(estado.codigo).filter(sinTerminar);
    cont.textContent = '';
    cont.hidden = !pendientes.length;
    if (!pendientes.length) return;
    const x = pendientes[0];
    cont.appendChild(el('strong', '', 'Ojo: ya tenés el pedido ' + (x.numero || '') + (x.nino ? ' para ' + x.nino : '') + ' sin terminar' + (x.total ? ' (' + pesos(x.total) + ')' : '') + '.'));
    cont.appendChild(el('p', '', 'Lo que confirmes acá es un pedido nuevo, aparte, y se paga por separado. Si querías completar el anterior, andá a ese pedido.'));
    const a = el('a', 'btn', 'Ir al pedido ' + (x.numero || 'anterior'));
    a.href = urlPedido(estado.codigo, x);
    cont.appendChild(a);
  }

  // ---------------- galería ----------------
  async function cargarGaleria() {
    mostrar('cargando');
    try {
      const d = await pedirJson('/api/eventos/publico/' + encodeURIComponent(estado.codigo));
      if (d.proximamente) { mostrarPronto(d.evento); return; }
      if (d.evento.codigo && d.evento.codigo !== estado.codigo) { estado.codigo = d.evento.codigo; history.replaceState(null, '', '/eventos/' + encodeURIComponent(estado.codigo) + location.search); } // 14/10/2026: QR con un código anterior → se pasa al actual
      estado.evento = d.evento;
      estado.fotos = d.fotos;
      leerCarrito();
      pintarEncabezado();
      pintarGrilla();
      pintarMisPedidos();
      mostrar('galeria');
      refrescarMisPedidos();
    } catch (e) {
      $('input-codigo').value = estado.codigo;
      $('codigo-error').textContent = e.message;
      $('codigo-error').hidden = false;
      mostrar('codigo');
    }
  }
  // El evento existe pero todavía no tiene las fotos online: mensaje + "avisame por email".
  // Auditoría 03/10 noche: el servidor ya no manda nombre ni datos del evento en este caso (la misma
  // respuesta exista o no el código): se muestra el código que se escribió.
  function mostrarPronto(ev) {
    const codigo = (ev && ev.codigo) || estado.codigo;
    document.title = (ev && ev.nombre ? ev.nombre : 'Fotos del evento') + ' — Retrato Escolar';
    $('pronto-evento').textContent = ev && ev.nombre ? ev.nombre : 'Código ' + codigo;
    mostrar('pronto');
  }
  $('form-avisame').addEventListener('submit', async (e) => {
    e.preventDefault();
    const email = $('input-avisame').value.trim();
    const boton = e.target.querySelector('button');
    $('avisame-error').hidden = true;
    boton.disabled = true;
    try {
      await pedirJson('/api/eventos/publico/' + encodeURIComponent(estado.codigo) + '/avisame', {
        method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email }),
      });
      $('avisame-email').textContent = email;
      $('avisame-ok').hidden = false;
      e.target.hidden = true;
    } catch (err) {
      $('avisame-error').textContent = err.message;
      $('avisame-error').hidden = false;
      boton.disabled = false;
    }
  });

  function pintarEncabezado() {
    const ev = estado.evento;
    document.title = ev.nombre + ' — Retrato Escolar';
    $('ev-nombre').textContent = ev.nombre;
    $('ev-detalle').textContent = [ev.lugar, fechaLarga(ev.fecha_evento)].filter(Boolean).join(' · ');
    const chips = $('ev-precios');
    chips.textContent = '';
    ['digital', '15x21', '20x30'].forEach((f) => {
      if (disponible(f)) chips.appendChild(el('span', 'chip', NOMBRES[f] + ' ' + pesos(precio(f))));
    });
    let texto = 'Tocá una foto para verla grande y elegir cómo la querés.';
    if (ev.impresa_incluye_digital && disponible('digital')) texto += ' Las impresas incluyen la foto digital.';
    if (ev.cerrado) texto = 'El plazo para hacer pedidos de este evento ya terminó.';
    else if (ev.fecha_limite) texto += ' Pedidos hasta el ' + fechaLarga(ev.fecha_limite) + '.';
    if (!ev.cerrado && (disponible('15x21') || disponible('20x30'))) texto += ' ' + textoPlazoImpresas(ev);
    if ($('plazo-impresas')) $('plazo-impresas').textContent = textoPlazoImpresas(ev) + ' Te avisamos por mail cuando estén listas para retirar.';
    $('ev-aviso').textContent = texto;
  }
  function pintarGrilla() {
    const g = $('grilla');
    g.textContent = '';
    $('galeria-vacia').hidden = estado.fotos.length > 0;
    estado.fotos.forEach((foto, i) => {
      const b = el('button', 'miniatura');
      b.type = 'button';
      b.dataset.id = foto.id;
      const img = el('img');
      img.loading = 'lazy';
      img.src = foto.thumb;
      img.alt = 'Foto ' + (i + 1);
      bloquearCopia(img);
      b.appendChild(img);
      b.addEventListener('click', () => abrirVisor(i));
      g.appendChild(b);
    });
    marcarElegidas();
  }
  function marcarElegidas() {
    document.querySelectorAll('.miniatura').forEach((b) => {
      const sel = estado.carrito[b.dataset.id];
      b.classList.toggle('elegida', !!sel);
      let marca = b.querySelector('.marca-elegida');
      if (sel) {
        if (!marca) { marca = el('span', 'marca-elegida'); b.appendChild(marca); }
        const partes = [];
        if (sel.digital && !digitalIncluido(sel)) partes.push('Digital');
        IMPRESAS.forEach((f) => { if (sel[f] > 0) partes.push(sel[f] + '×' + f); });
        marca.textContent = '✓ ' + partes.join(' ');
      } else if (marca) marca.remove();
    });
    actualizarBarra();
  }

  // ---------------- visor ----------------
  // 04/10 (pedido de Pablo): lupa que muestra la foto NÍTIDA en la zona por donde se pasa el mouse (o el
  // dedo, manteniéndolo apretado). El servidor manda sólo ese pedacito, con sellos "MUESTRA · código".
  // La lupa está en /eventos/lupa.js (generado desde src/utils/lupaMuestra.ts, la misma de los colegios).
  let lupa = null;
  function abrirVisor(i) {
    estado.visorIndice = i;
    // Atrás (botón del celular) cierra el visor en vez de salir de la página.
    if ($('visor').hidden && !(history.state && history.state.visor)) history.pushState({ visor: true, carrito: !!(history.state && history.state.carrito) }, '');
    if ($('visor').hidden) estado.focoPrevio = document.activeElement;
    $('visor').hidden = false;
    document.body.style.overflow = 'hidden';
    pintarVisor();
    $('visor-cerrar').focus();
  }
  let cerrandoVisor = false;
  function cerrarVisor(desdeAtras) {
    if ($('visor').hidden) return;
    if (desdeAtras !== true && history.state && history.state.visor) {
      if (cerrandoVisor) return; // doble Esc / doble ✕: una sola vuelta atrás
      cerrandoVisor = true;
      history.back(); // el popstate lo cierra
      return;
    }
    $('visor').hidden = true;
    if (lupa) lupa.ocultar();
    document.body.style.overflow = '';
    estado.visorIndice = -1;
    marcarElegidas();
    if (estado.focoPrevio && document.contains(estado.focoPrevio)) estado.focoPrevio.focus();
    estado.focoPrevio = null;
  }
  function moverVisor(delta) {
    const n = estado.fotos.length;
    if (!n) return;
    estado.visorIndice = (estado.visorIndice + delta + n) % n;
    pintarVisor();
  }
  // 03/10: al pasar de foto tardaba un par de segundos porque la muestra se pedía recién al tocar la
  // flecha. Ahora se muestra al instante la miniatura (ya está en caché por la grilla), se cambia por la
  // muestra apenas llega y se precargan las fotos de al lado para que el próximo paso sea inmediato.
  const muestrasPrecargadas = new Map();
  function precargarMuestra(url) {
    if (!url || muestrasPrecargadas.has(url)) return muestrasPrecargadas.get(url);
    const im = new Image();
    im.decoding = 'async';
    const lista = new Promise((ok) => { im.onload = () => ok(true); im.onerror = () => ok(false); });
    im.src = url;
    const entrada = { im, lista };
    muestrasPrecargadas.set(url, entrada);
    if (muestrasPrecargadas.size > 40) muestrasPrecargadas.delete(muestrasPrecargadas.keys().next().value);
    return entrada;
  }
  function pintarVisor() {
    asegurarLupa();
    if (lupa) lupa.reiniciar(); // olvida los pedacitos de la foto anterior
    const indice = estado.visorIndice;
    const foto = estado.fotos[indice];
    const img = $('visor-img');
    const entrada = precargarMuestra(foto.muestra);
    if (entrada && entrada.im.complete && entrada.im.naturalWidth) {
      img.src = foto.muestra;
      img.classList.remove('cargando');
    } else {
      img.src = foto.thumb || foto.muestra;
      img.classList.add('cargando');
      if (entrada) entrada.lista.then(() => {
        if (estado.visorIndice !== indice || $('visor').hidden) return; // ya pasó a otra foto
        img.src = foto.muestra;
        img.classList.remove('cargando');
      });
    }
    const n = estado.fotos.length;
    [1, -1, 2].forEach((d) => { const otra = estado.fotos[(indice + d + n) % n]; if (otra) precargarMuestra(otra.muestra); });
    bloquearCopia(img);
    $('visor-nombre').textContent = 'Foto ' + (estado.visorIndice + 1) + ' de ' + estado.fotos.length;
    pintarOpciones(foto);
  }
  function pintarOpciones(foto) {
    const cont = $('visor-opciones');
    cont.textContent = '';
    if (estado.evento.cerrado) {
      cont.appendChild(el('p', 'sutil', 'El plazo para pedir fotos de este evento terminó.'));
      return;
    }
    const sel = Object.assign({}, seleccion(foto.id));
    if (disponible('digital')) {
      const fila = el('div', 'opcion-formato');
      const txt = el('div');
      txt.appendChild(el('strong', '', 'Digital'));
      txt.appendChild(el('small', '', pesos(precio('digital')) + ' · alta resolución, por mail'));
      fila.appendChild(txt);
      if (digitalIncluido(sel)) {
        fila.appendChild(el('span', 'incluido', '✓ Incluida'));
      } else {
        const b = el('button', 'btn toggle' + (sel.digital ? ' activo' : ''), sel.digital ? '✓ Elegida' : 'Elegir');
        b.type = 'button';
        b.addEventListener('click', () => { sel.digital = !sel.digital; fijar(foto.id, sel); pintarOpciones(foto); });
        fila.appendChild(b);
      }
      cont.appendChild(fila);
    }
    IMPRESAS.forEach((f) => {
      if (!disponible(f)) return;
      const fila = el('div', 'opcion-formato');
      const txt = el('div');
      txt.appendChild(el('strong', '', NOMBRES[f]));
      txt.appendChild(el('small', '', pesos(precio(f)) + ' c/u' + (estado.evento.impresa_incluye_digital && disponible('digital') ? ' · incluye la digital' : '')));
      fila.appendChild(txt);
      const c = el('div', 'contador');
      const menos = el('button', '', '−');
      const mas = el('button', '', '+');
      menos.type = mas.type = 'button';
      menos.setAttribute('aria-label', 'Quitar copia ' + f);
      mas.setAttribute('aria-label', 'Agregar copia ' + f);
      menos.addEventListener('click', () => { sel[f] = Math.max(0, (sel[f] || 0) - 1); fijar(foto.id, sel); pintarOpciones(foto); });
      mas.addEventListener('click', () => { sel[f] = Math.min(50, (sel[f] || 0) + 1); fijar(foto.id, sel); pintarOpciones(foto); });
      c.appendChild(menos);
      c.appendChild(el('span', '', String(sel[f] || 0)));
      c.appendChild(mas);
      fila.appendChild(c);
      cont.appendChild(fila);
    });
    const pie = el('div', 'visor-pie');
    const n = Object.keys(estado.carrito).length;
    pie.appendChild(el('span', 'sutil', n ? n + (n === 1 ? ' foto' : ' fotos') + ' · ' + pesos(total()) : 'Todavía no elegiste fotos'));
    const listo = el('button', 'btn btn-primario', n ? 'Ver pedido →' : 'Cerrar');
    listo.type = 'button';
    listo.addEventListener('click', () => {
      if (!n) { cerrarVisor(); return; }
      if (history.state && history.state.visor && history.state.carrito) { cerrarVisor(); return; } // vuelve al carrito (se repinta en popstate)
      cerrarVisor(true);
      irACarrito(true); // reemplaza el paso del visor en el historial
    });
    pie.appendChild(listo);
    cont.appendChild(pie);
  }
  $('visor-cerrar').addEventListener('click', () => cerrarVisor());
  $('visor-ant').addEventListener('click', () => moverVisor(-1));
  $('visor-sig').addEventListener('click', () => moverVisor(1));
  document.addEventListener('keydown', (e) => {
    if ($('visor').hidden) return;
    if (e.key === 'Escape') cerrarVisor();
    if (e.key === 'Tab') {
      // El foco queda dentro del visor (no recorre la galería de atrás).
      const enfocables = Array.from($('visor').querySelectorAll('button, [href], input'));
      if (!enfocables.length) return;
      const primero = enfocables[0];
      const ultimo = enfocables[enfocables.length - 1];
      if (e.shiftKey && document.activeElement === primero) { e.preventDefault(); ultimo.focus(); }
      else if (!e.shiftKey && document.activeElement === ultimo) { e.preventDefault(); primero.focus(); }
    }
    if (e.key === 'ArrowLeft') moverVisor(-1);
    if (e.key === 'ArrowRight') moverVisor(1);
  });
  let toqueX = null;
  const zonaFoto = document.querySelector('.visor-foto');
  // Sólo si el evento tiene prendido «Muestras con lupa» (se monta la primera vez que se abre el visor).
  function asegurarLupa() {
    if (lupa || !window.LupaMuestra || !estado.evento || !estado.evento.muestras_lupa) return;
    lupa = window.LupaMuestra.montarLupa(zonaFoto, $('visor-img'), {
      urlRecorte: (cx, cy, s) => {
        const foto = estado.fotos[estado.visorIndice];
        if (!foto || !estado.codigo) return null;
        return '/api/eventos/publico/' + encodeURIComponent(estado.codigo) + '/lupa/' + encodeURIComponent(foto.id) +
          '?cx=' + cx + '&cy=' + cy + '&s=' + s;
      }
    });
  }
  zonaFoto.addEventListener('touchstart', (e) => { toqueX = e.touches[0].clientX; }, { passive: true });
  zonaFoto.addEventListener('touchend', (e) => {
    if (lupa && lupa.usadaRecien()) { toqueX = null; return; } // arrastrar la lupa no pasa de foto
    if (toqueX === null) return;
    const dx = e.changedTouches[0].clientX - toqueX;
    toqueX = null;
    if (Math.abs(dx) > 50) moverVisor(dx < 0 ? 1 : -1);
  });

  // ---------------- carrito / compra ----------------
  document.querySelectorAll('[data-ir]').forEach((b) => b.addEventListener('click', () => {
    if (b.dataset.ir === 'carrito') irACarrito();
    else if (history.state && history.state.carrito && !history.state.visor) history.back();
    else { mostrar('galeria'); marcarElegidas(); }
  }));
  function irACarrito(reemplazar) {
    if (!Object.keys(estado.carrito).length) return;
    if ($('compra-ok')) $('compra-ok').hidden = true; // Auditoría 03/10 noche: aviso de "pedido ya registrado"
    pintarAvisoOtroPedido();
    pintarLineas();
    mostrar('carrito');
    if (reemplazar === true && history.state && history.state.visor) history.replaceState({ carrito: true }, '');
    else if (!(history.state && history.state.carrito)) history.pushState({ carrito: true }, '');
  }
  window.addEventListener('popstate', (e) => {
    cerrandoVisor = false;
    const s = e.state || {};
    // La URL cambió entre la página de un pedido y la galería: se muestra lo que dice la URL.
    const qp = new URLSearchParams(location.search);
    if (!$('p-pedido').hidden && !qp.get('pedido')) { location.reload(); return; }
    if ($('p-pedido').hidden && qp.get('pedido') && qp.get('t')) { cargarPedido(qp.get('pedido'), qp.get('t')); return; }
    if (!s.visor && !$('visor').hidden) cerrarVisor(true);
    if (!s.carrito && !$('p-carrito').hidden) { mostrar('galeria'); marcarElegidas(); }
    else if (s.carrito && !$('p-carrito').hidden) pintarLineas(); // volvió del visor: refleja lo que cambió
  });
  // Volver con "Atrás" desde Mercado Pago: el navegador puede mostrar la página congelada (botón en
  // "Procesando…"). Se recarga para mostrar el estado real del pedido.
  window.addEventListener('pageshow', (e) => { if (e.persisted) location.reload(); });
  document.addEventListener('change', (e) => {
    if (e.target && e.target.name === 'acepta' && e.target.checked) $('compra-error').hidden = true;
  });
  function pintarLineas() {
    const cont = $('lineas');
    cont.textContent = '';
    const ls = lineas();
    if (!ls.length) {
      cont.appendChild(el('p', 'sutil', 'No elegiste fotos todavía.'));
      $('btn-pagar').disabled = true;
      return;
    }
    $('btn-pagar').disabled = false;
    const porFoto = new Map();
    ls.forEach((l) => { if (!porFoto.has(l.foto.id)) porFoto.set(l.foto.id, []); porFoto.get(l.foto.id).push(l); });
    porFoto.forEach((items, fotoId) => {
      const foto = items[0].foto;
      const sel = seleccion(fotoId);
      const fila = el('div', 'linea');
      const img = el('img');
      img.src = foto.thumb;
      img.alt = '';
      bloquearCopia(img);
      fila.appendChild(img);
      const info = el('div', 'info');
      items.forEach((l) => {
        const t = el('div');
        t.textContent = NOMBRES[l.formato] + (l.formato === 'digital' ? '' : ' × ' + l.cantidad) + ' — ' + pesos(l.subtotal);
        info.appendChild(t);
      });
      if (digitalIncluido(sel) && disponible('digital')) info.appendChild(el('div', 'incluido', '+ digital incluida'));
      const acc = el('div', 'acciones-linea');
      const editar = el('button', 'btn btn-texto', 'Cambiar');
      editar.type = 'button';
      editar.addEventListener('click', () => abrirVisor(estado.fotos.indexOf(foto))); // el visor se abre encima del carrito
      const quitar = el('button', 'btn btn-texto', 'Quitar');
      quitar.type = 'button';
      quitar.addEventListener('click', () => { delete estado.carrito[fotoId]; guardarCarrito(); pintarLineas(); });
      acc.appendChild(editar);
      acc.appendChild(quitar);
      info.appendChild(acc);
      fila.appendChild(info);
      cont.appendChild(fila);
    });
    D.fila(cont); const t = el('div', 'total');
    t.appendChild(el('strong', '', 'Total'));
    t.appendChild(el('strong', '', pesos(totalAPagar())));
    cont.appendChild(t);
    const medio = (new FormData($('form-compra'))).get('medioPago'), gratis = $('bloque-pago').hidden = D.sinCargo(totalAPagar());
    $('btn-pagar').textContent = gratis ? 'Confirmar pedido sin cargo' : medio === 'transferencia' ? 'Confirmar pedido (' + pesos(totalAPagar()) + ')' : 'Pagar ' + pesos(totalAPagar()) + ' con Mercado Pago';
  }
  $('form-compra').addEventListener('change', (e) => { if (e.target.name === 'medioPago') pintarLineas(); });

  $('form-compra').addEventListener('submit', async (e) => {
    e.preventDefault();
    const f = e.target;
    const datos = new FormData(f);
    const errorEl = $('compra-error');
    errorEl.hidden = true;
    if ($('compra-ok')) $('compra-ok').hidden = true;
    if (!f.elements.acepta.checked) {
      errorEl.textContent = 'Para seguir, aceptá las condiciones de compra.';
      errorEl.hidden = false;
      return;
    }
    const items = [];
    lineas().forEach((l) => items.push({ fotoId: l.foto.id, formato: l.formato, cantidad: l.cantidad }));
    const cuerpo = {
      comprador: { nombre: datos.get('compradorNombre'), whatsapp: datos.get('compradorWhatsapp'), email: datos.get('compradorEmail') },
      nino: { nombre: datos.get('ninoNombre'), curso: datos.get('ninoCurso') },
      medioPago: $('bloque-pago').hidden ? '' : datos.get('medioPago'),
      aceptaCondiciones: true, codigoDescuento: D.codigo(),
      aceptaNovedades: f.elements.novedades ? f.elements.novedades.checked : false,
      items,
    };
    const boton = $('btn-pagar');
    const textoPrevio = boton.textContent;
    boton.disabled = true;
    boton.textContent = 'Procesando…';
    try {
      const d = await pedirJson('/api/eventos/publico/' + encodeURIComponent(estado.codigo) + '/pedidos', {
        method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(cuerpo),
      });
      // Auditoría 03/10 noche: si el pedido ya estaba hecho (se cortó la respuesta y se reintentó), el
      // servidor no devuelve la llave: reenvía el link al email del pedido. Se avisa y no se sigue.
      if (d.sinLlave) {
        vaciarCarrito();
        const ok = $('compra-ok');
        const texto = (d.mensaje || 'Ya registramos este pedido: te reenviamos el link por email.') + ' Entrá desde el link del correo para pagar o ver el pedido (revisá también correo no deseado).';
        if (ok) { ok.textContent = texto; ok.hidden = false; } else aviso(texto);
        boton.textContent = 'Revisá tu email';
        return;
      }
      recordarPedido(estado.codigo, {
        id: d.pedidoId, llave: d.llave, numero: d.numero, nino: cuerpo.nino.nombre, total: d.total,
        estado: d.bonificado ? 'pagado' : 'pendiente', medio: d.bonificado ? 'bonificado' : cuerpo.medioPago, comprobante: false,
      });
      vaciarCarrito();
      // La URL pasa a ser la del pedido ANTES de ir a Mercado Pago: si vuelven con "Atrás", caen en
      // el pedido (con la opción de reintentar o pasar a transferencia), no en un carrito trabado.
      history.replaceState(null, '', '/eventos/' + encodeURIComponent(estado.codigo) + '?pedido=' + d.pedidoId + '&t=' + encodeURIComponent(d.llave));
      if (d.initPoint) { location.href = d.initPoint; return; }
      // 05/10: Mercado Pago no respondió al crear el link, pero el pedido quedó hecho: se muestra la
      // pantalla del pedido (con «Intentar de nuevo con Mercado Pago» y «Pagar por transferencia»).
      await cargarPedido(d.pedidoId, d.llave);
      if (d.mpNoDisponible) aviso(d.mensaje || 'Mercado Pago no respondió; podés reintentar desde acá o pagar por transferencia.', true);
    } catch (err) {
      if (err.datos && err.datos.codigoInvalido) D.quitar(err.message); errorEl.textContent = err.message + (err.status === 0 ? ' Antes de reintentar, revisá tu mail: si te llegó el correo del pedido, ya está hecho (entrá desde el link del correo). Si reintentás con los mismos datos, no se duplica.' : '');
      errorEl.hidden = false;
      boton.disabled = false;
      boton.textContent = textoPrevio;
      refrescarMisPedidos();
    }
  });

  // ---------------- estado del pedido ----------------
  let reintentosEspera = 0;
  let cambiandoMedio = false;
  let consultaPedido = 0; // número de la última consulta: una respuesta vieja nunca pisa una nueva
  let timerEspera = null;
  let fallosRed = 0;
  // Volviendo de Mercado Pago con el pago aprobado (antes de que llegue el aviso al servidor).
  const vueltaAprobada = /^(approved|accredited)$/.test(new URLSearchParams(location.search).get('collection_status') || new URLSearchParams(location.search).get('status') || '');
  // 03/10: con la pestaña oculta no se consulta: se reconsulta apenas la familia vuelve a mirarla.
  let consultaAlVolver = null;
  function programarConsulta(pedidoId, llave, ms) {
    clearTimeout(timerEspera);
    timerEspera = setTimeout(() => {
      if (cambiandoMedio) return;
      if (document.hidden) { consultaAlVolver = { pedidoId, llave }; return; }
      cargarPedido(pedidoId, llave);
    }, ms);
  }
  document.addEventListener('visibilitychange', () => {
    if (document.hidden || !consultaAlVolver || cambiandoMedio) return;
    const c = consultaAlVolver;
    consultaAlVolver = null;
    cargarPedido(c.pedidoId, c.llave);
  });
  async function cargarPedido(pedidoId, llave) {
    const miConsulta = ++consultaPedido;
    const yaVisible = !$('p-pedido').hidden;
    if (!yaVisible) mostrar('cargando');
    let p;
    try {
      p = (await pedirJson('/api/eventos/pedido/' + encodeURIComponent(pedidoId) + '?t=' + encodeURIComponent(llave))).pedido;
    } catch (e) {
      if (miConsulta !== consultaPedido) return;
      if (e.status === 403 || e.status === 404) {
        $('codigo-error').textContent = e.message;
        $('codigo-error').hidden = false;
        mostrar('codigo');
        return;
      }
      // Corte de red o error momentáneo: NO se saca a la familia del pedido; se reintenta solo.
      fallosRed++;
      if (yaVisible) aviso(e.message, true);
      else document.querySelector('#p-cargando p').textContent = e.message + ' Reintentando…';
      if (fallosRed <= 20) programarConsulta(pedidoId, llave, Math.min(30000, 3000 * fallosRed));
      else if (yaVisible) programarConsulta(pedidoId, llave, 60000); // sigue probando cada minuto, sin rendirse
      else {
        const p0 = document.querySelector('#p-cargando p');
        p0.textContent = 'No pudimos conectarnos. ';
        const reintentar = el('button', 'btn', 'Reintentar');
        reintentar.type = 'button';
        reintentar.addEventListener('click', () => { fallosRed = 0; p0.textContent = 'Cargando…'; cargarPedido(pedidoId, llave); });
        p0.appendChild(reintentar);
      }
      return;
    }
    if (miConsulta !== consultaPedido) return;
    fallosRed = 0;
    document.querySelector('#p-cargando p').textContent = 'Cargando…';
    pintarPedido(p, pedidoId, llave);
    mostrar('pedido');
    // Volviendo de Mercado Pago el aviso del pago puede tardar: se reconsulta (5 s × 12 y luego cada 30 s × 10).
    if (p.estado === 'pendiente' && p.medioPago === 'mercadopago' && !p.comprobanteSubidoEn) {
      if (reintentosEspera < 22) {
        reintentosEspera++;
        programarConsulta(pedidoId, llave, reintentosEspera <= 12 ? 5000 : 30000);
      }
    } else if (p.estado === 'pendiente' && p.comprobanteSubidoEn) {
      // 03/10: comprobante en revisión: se reconsulta cada 20 s para que, cuando Pablo apruebe el pago,
      // la página pase sola a "Pagado" con las descargas (antes había que recargarla a mano).
      programarConsulta(pedidoId, llave, 20000);
    }
  }
  function pintarPedido(p, pedidoId, llave) {
    document.title = 'Pedido ' + p.numero + ' — Retrato Escolar';
    recordarPedido((p.evento && p.evento.codigo) || estado.codigo, {
      id: pedidoId, llave, numero: p.numero, nino: p.ninoNombre, total: p.total,
      estado: p.estado, medio: p.medioPago, comprobante: !!p.comprobanteSubidoEn,
    });
    $('pd-evento').textContent = p.evento.nombre;
    $('pd-titulo').textContent = 'Pedido ' + p.numero;
    const est = $('pd-estado');
    const etiquetas = { pagado: 'Pagado', pendiente: 'Pendiente de pago', vencido: 'Vencido', cancelado: 'Cancelado' };
    const verificando = p.estado === 'pendiente' && !!p.comprobanteSubidoEn;
    est.textContent = verificando ? '✓ Comprobante recibido · lo estamos verificando' : (etiquetas[p.estado] || p.estado);
    est.className = 'estado ' + (verificando ? 'verificando' : p.estado);
    const msj = $('pd-mensaje');
    msj.textContent = '';
    const parrafo = (t) => msj.appendChild(el('p', '', t));
    const hayImpresas = p.items.some((it) => it.formato !== 'digital');
    if (p.estado === 'pagado') {
      parrafo('¡Gracias! Te mandamos la confirmación a ' + p.compradorEmail + '.');
      if (hayImpresas) {
        const entrega = { en_laboratorio: 'Tus copias impresas están en el laboratorio.', listo_retiro: '¡Tus copias impresas están listas para retirar!', entregado: 'Las copias impresas ya fueron entregadas.' };
        parrafo(entrega[p.estadoEntrega] || 'Las copias impresas pasan al laboratorio. Te avisamos por mail cuando estén listas para retirar.');
      }
    } else if (p.estado === 'pendiente' && p.medioPago === 'mercadopago') {
      if (vueltaAprobada && reintentosEspera < 22) {
        parrafo('Mercado Pago aprobó tu pago. Lo estamos confirmando: esto se actualiza solo en unos segundos. No vuelvas a pagar.');
      } else if (reintentosEspera < 22) {
        parrafo('Estamos esperando la confirmación de Mercado Pago. Si ya pagaste, esto se actualiza solo.');
      } else {
        parrafo('Todavía no nos llegó la confirmación de Mercado Pago. Si ya pagaste, puede demorar: tocá «Actualizar» en un rato o revisá tu mail.');
        const act = el('button', 'btn', 'Actualizar');
        act.type = 'button';
        act.addEventListener('click', () => { reintentosEspera = 12; cargarPedido(pedidoId, llave); });
        msj.appendChild(act);
      }
    } else if (p.estado === 'vencido' && p.medioPago === 'mercadopago') {
      parrafo('El pedido venció porque no se completó el pago con Mercado Pago. Si pagaste, respondé el mail del pedido; si no, podés hacer un pedido nuevo desde la galería.');
    } else if (p.estado === 'pendiente') {
      parrafo(p.comprobanteSubidoEn
        ? 'Recibimos tu comprobante. Lo verificamos y te avisamos por mail cuando el pago esté confirmado.'
        : 'Hacé la transferencia y subí el comprobante acá abajo. Te mandamos estos datos también por mail.');
    } else if (p.estado === 'vencido') {
      parrafo('El pedido venció porque no recibimos el comprobante a tiempo. Si ya transferiste, respondé el mail del pedido con el comprobante; si no, podés hacer un pedido nuevo desde la galería.');
    } else {
      parrafo('Este pedido fue cancelado. Si creés que es un error, respondé el mail del pedido.');
    }
    pintarCambioDePago(p, pedidoId, llave);
    // Transferencia
    const tr = $('pd-transferencia');
    tr.hidden = !p.transferencia;
    if (p.transferencia) {
      $('tr-monto').textContent = pesos(p.total);
      $('tr-alias').textContent = p.transferencia.alias;
      $('tr-cbu').textContent = p.transferencia.cbu;
      $('tr-titular').textContent = p.transferencia.titular;
      $('tr-banco').textContent = p.transferencia.banco;
      $('tr-vence').textContent = p.comprobanteSubidoEn || !p.venceEn ? '' : 'Subí el comprobante antes del ' + fechaHora(p.venceEn) + '; si no, el pedido se cancela solo.';
      $('tr-estado').textContent = '';
      // Comprobante ya subido: cartel verde bien visible y la zona de subida queda chica, para reemplazarlo.
      const recibido = !!p.comprobanteSubidoEn;
      $('tr-recibido').hidden = !recibido;
      if (recibido) $('tr-recibido-fecha').textContent = 'El ' + fechaHora(p.comprobanteSubidoEn) + '.';
      $('zona-comprobante').className = 'zona-archivo' + (recibido ? ' zona-chica' : '');
      $('zona-titulo').textContent = recibido ? '¿Te equivocaste de archivo? Subí otro' : 'Subir el comprobante';
      $('zona-detalle').hidden = recibido;
      const input = $('input-comprobante');
      input.onchange = () => subirComprobante(input.files[0], pedidoId, llave);
    }
    // Descargas
    const dl = $('pd-descargas');
    dl.hidden = !p.descargables.length;
    const lista = $('lista-descargas');
    lista.textContent = '';
    // La descarga no cambia de página (el archivo va a la carpeta Descargas): se avisa en la tarjeta.
    const marcarDescargada = (a) => {
      a.classList.add('descargada');
      a.querySelector('span').textContent = '✓ Descargada';
    };
    p.descargables.forEach((f) => {
      const a = el('a', 'descarga');
      a.href = '/api/eventos/pedido/' + encodeURIComponent(pedidoId) + '/descargar/' + encodeURIComponent(f.fotoId) + '?t=' + encodeURIComponent(llave);
      a.rel = 'noopener';
      a.setAttribute('download', '');
      if (f.thumb) { const img = el('img'); img.src = f.thumb; img.alt = ''; a.appendChild(img); }
      a.appendChild(el('span', '', '⬇ Descargar'));
      a.addEventListener('click', (e) => {
        if (!e.isTrusted) return; // el "descargar todas" no marca: el navegador puede bloquear alguna
        marcarDescargada(a);
        aviso('Descargando la foto en alta resolución… Buscala en la carpeta Descargas (o en Archivos del celular).');
      });
      lista.appendChild(a);
    });
    const todas = $('btn-descargar-todas');
    // iPhone/iPad bloquean varias descargas seguidas: ahí se descargan de a una.
    const esIos = /iP(hone|ad|od)/.test(navigator.userAgent) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
    todas.hidden = p.descargables.length < 2 || esIos;
    todas.textContent = '⬇ Descargar las ' + p.descargables.length + ' fotos';
    todas.onclick = () => {
      const enlaces = Array.from(lista.querySelectorAll('a.descarga'));
      aviso('Descargando ' + enlaces.length + ' fotos… Si el navegador pregunta, tocá «Permitir». Si falta alguna, tocala para bajarla.');
      enlaces.forEach((a, i) => setTimeout(() => { a.click(); }, i * 1200));
    };
    // Detalle
    const det = $('pd-items');
    det.textContent = '';
    p.items.forEach((it) => {
      const fila = el('div', 'linea');
      if (it.thumb) { const img = el('img'); img.src = it.thumb; img.alt = ''; bloquearCopia(img); fila.appendChild(img); }
      const info = el('div', 'info');
      info.appendChild(el('div', '', NOMBRES[it.formato] + (it.formato === 'digital' ? '' : ' × ' + it.cantidad)));
      if (it.formato !== 'digital' && it.incluyeDigital) info.appendChild(el('div', 'incluido', '+ digital incluida'));
      info.appendChild(el('div', 'sutil', pesos(it.subtotal)));
      fila.appendChild(info);
      det.appendChild(fila);
    });
    D.filaPedido(det, p.descuento); const t = el('div', 'total');
    t.appendChild(el('strong', '', 'Total'));
    t.appendChild(el('strong', '', pesos(p.total)));
    det.appendChild(t);
    det.appendChild(el('p', 'sutil', 'Para: ' + p.ninoNombre + (p.ninoCurso ? ' (' + p.ninoCurso + ')' : '')));
    $('pd-volver').href = '/eventos/' + encodeURIComponent(p.evento.codigo);
    // 04/10 (pedido de Pablo): botón de contacto con el número de pedido, el chico y el evento ya cargados.
    const asuntoAyuda = 'Consulta por mi pedido ' + p.numero + ' (' + (p.evento.nombre || 'evento') + ')';
    const cuerpoAyuda = 'Hola, tengo una consulta sobre mi pedido ' + p.numero + (p.ninoNombre ? ' de ' + p.ninoNombre : '') + ' (' + (p.evento.nombre || 'evento') + ').\n\nContanos qué pasó:\n\n';
    $('pd-ayuda').href = 'mailto:contacto@retratoescolar.com.ar?subject=' + encodeURIComponent(asuntoAyuda) + '&body=' + encodeURIComponent(cuerpoAyuda);
    $('pd-ayuda-numero').textContent = p.numero;
  }

  // Si Mercado Pago no salió (o se arrepintió de la transferencia): reintentar o cambiar el medio.
  function pintarCambioDePago(p, pedidoId, llave) {
    const caja = $('pd-cambiar-pago');
    caja.textContent = '';
    // Recién vuelto de Mercado Pago con el pago aprobado: no se invita a pagar de nuevo mientras se confirma.
    const confirmando = vueltaAprobada && p.medioPago === 'mercadopago' && reintentosEspera < 22;
    caja.hidden = !(p.estado === 'pendiente' && !p.comprobanteSubidoEn) || confirmando;
    if (caja.hidden) return;
    const boton = (texto, clase, medio) => {
      const b = el('button', 'btn ' + clase, texto);
      b.type = 'button';
      b.disabled = cambiandoMedio;
      b.addEventListener('click', () => cambiarMedioDePago(medio, pedidoId, llave));
      return b;
    };
    if (p.medioPago === 'mercadopago') {
      caja.className = 'tarjeta cambiar-pago destacada';
      caja.appendChild(el('h2', '', '¿No pudiste pagar?'));
      caja.appendChild(el('p', 'sutil', 'Si el pago no salió o volviste atrás, podés intentar de nuevo o pagar por transferencia. Tu pedido y las fotos que elegiste se mantienen.'));
      const fila = el('div', 'botones-pago');
      fila.appendChild(boton('Intentar de nuevo con Mercado Pago', 'btn-primario', 'mercadopago'));
      fila.appendChild(boton('Pagar por transferencia', '', 'transferencia'));
      caja.appendChild(fila);
    } else {
      caja.className = 'tarjeta cambiar-pago';
      caja.appendChild(el('p', 'sutil', '¿Preferís pagar con tarjeta o con dinero en Mercado Pago?'));
      caja.appendChild(boton('Pagar con Mercado Pago', '', 'mercadopago'));
    }
  }
  async function cambiarMedioDePago(medio, pedidoId, llave) {
    if (cambiandoMedio) return;
    cambiandoMedio = true;
    document.querySelectorAll('#pd-cambiar-pago button').forEach((b) => { b.disabled = true; });
    try {
      const d = await pedirJson('/api/eventos/pedido/' + encodeURIComponent(pedidoId) + '/medio-pago?t=' + encodeURIComponent(llave), {
        method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ medioPago: medio }),
      });
      if (d.initPoint) {
        // Se queda la URL limpia del pedido (sin el "collection_status" de una vuelta anterior).
        history.replaceState(null, '', location.pathname + '?pedido=' + encodeURIComponent(pedidoId) + '&t=' + encodeURIComponent(llave));
        location.href = d.initPoint;
        return;
      }
      if (d.estado === 'pagado') aviso('¡Tu pago ya estaba acreditado!');
      else aviso('Listo: ahora pagás por transferencia. También te mandamos los datos por mail.');
      reintentosEspera = 99; // ya no hace falta esperar a Mercado Pago
      cambiandoMedio = false;
      await cargarPedido(pedidoId, llave);
      if (d.estado !== 'pagado' && !$('pd-transferencia').hidden) $('pd-transferencia').scrollIntoView({ behavior: 'smooth', block: 'start' });
    } catch (e) {
      cambiandoMedio = false;
      aviso(e.message, true);
      document.querySelectorAll('#pd-cambiar-pago button').forEach((b) => { b.disabled = false; });
      cargarPedido(pedidoId, llave); // retoma la actualización automática
    }
  }

  function leerComoDataUrl(archivo) {
    return new Promise((ok, mal) => {
      const lector = new FileReader();
      lector.onload = () => ok(lector.result);
      lector.onerror = () => mal(new Error('No se pudo leer el archivo'));
      lector.readAsDataURL(archivo);
    });
  }
  // Las fotos del celular suelen pesar más de 2,5 MB: se achican antes de subirlas.
  function decodificarImagen(archivo) {
    if (typeof createImageBitmap === 'function') return createImageBitmap(archivo);
    return new Promise((ok, mal) => { // iPhone viejos (sin createImageBitmap)
      const url = URL.createObjectURL(archivo);
      const img = new Image();
      img.onload = () => { URL.revokeObjectURL(url); ok(img); };
      img.onerror = () => { URL.revokeObjectURL(url); mal(new Error('no se pudo abrir')); };
      img.src = url;
    });
  }
  async function prepararComprobante(archivo) {
    const esPdf = archivo.type === 'application/pdf' || /\.pdf$/i.test(archivo.name);
    const esHeic = /^image\/hei[cf]$/i.test(archivo.type) || /\.hei[cf]$/i.test(archivo.name);
    const limite = 2.4 * 1024 * 1024;
    if (esPdf) {
      if (archivo.size > limite) throw new Error('El PDF es muy grande (máximo 2,5 MB). Mandá una captura de pantalla del comprobante.');
      return (await leerComoDataUrl(archivo)).replace(/^data:[^;]*;/, 'data:application/pdf;');
    }
    if (archivo.size <= limite && /^image\/(jpeg|png|webp)$/i.test(archivo.type)) return leerComoDataUrl(archivo);
    // Cualquier otra imagen (pesada, HEIC, sin tipo): se intenta pasar a JPG achicado.
    try {
      const imagen = await decodificarImagen(archivo);
      const ancho = imagen.width || imagen.naturalWidth;
      const alto = imagen.height || imagen.naturalHeight;
      const escala = Math.min(1, 1800 / Math.max(ancho, alto));
      const c = document.createElement('canvas');
      c.width = Math.round(ancho * escala);
      c.height = Math.round(alto * escala);
      c.getContext('2d').drawImage(imagen, 0, 0, c.width, c.height);
      if (imagen.close) imagen.close();
      return c.toDataURL('image/jpeg', 0.85);
    } catch (e) {
      if (esHeic && archivo.size <= limite) return (await leerComoDataUrl(archivo)).replace(/^data:[^;]*;/, 'data:image/heic;');
      throw new Error('No pudimos leer ese archivo. Mandá una captura de pantalla (JPG o PNG) o un PDF del comprobante.');
    }
  }
  let subiendoComprobante = false;
  async function subirComprobante(archivo, pedidoId, llave) {
    if (!archivo || subiendoComprobante) return;
    subiendoComprobante = true;
    $('input-comprobante').disabled = true;
    $('zona-comprobante').classList.add('subiendo');
    $('tr-estado').textContent = 'Subiendo comprobante…';
    $('zona-titulo').textContent = 'Subiendo comprobante…';
    try {
      const dataUrl = await prepararComprobante(archivo);
      await pedirJson('/api/eventos/pedido/' + encodeURIComponent(pedidoId) + '/comprobante?t=' + encodeURIComponent(llave), {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ archivo: dataUrl }),
      });
      aviso('¡Listo! Recibimos tu comprobante.');
      await cargarPedido(pedidoId, llave);
    } catch (e) {
      $('tr-estado').textContent = '';
      $('zona-titulo').textContent = $('tr-recibido').hidden ? 'Subir el comprobante' : '¿Te equivocaste de archivo? Subí otro';
      aviso(e.message, true);
    } finally {
      subiendoComprobante = false;
      $('input-comprobante').disabled = false;
      $('zona-comprobante').classList.remove('subiendo');
      $('input-comprobante').value = '';
    }
  }
  // La zona del comprobante se puede usar con teclado (Enter o Espacio).
  $('zona-comprobante').addEventListener('keydown', (e) => {
    if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); if (!subiendoComprobante) $('input-comprobante').click(); }
  });
  document.querySelectorAll('[data-copiar]').forEach((b) => b.addEventListener('click', async () => {
    const texto = $(b.dataset.copiar).textContent;
    try { await navigator.clipboard.writeText(texto); aviso('Copiado: ' + texto); } catch (e) { aviso(texto); }
  }));

  // ---------------- arranque ----------------
  // Al recargar, un estado viejo del visor o del carrito en el historial ya no corresponde.
  if (history.state && (history.state.visor || history.state.carrito)) history.replaceState(null, '');
  const partes = location.pathname.replace(/\/+$/, '').split('/');
  estado.codigo = partes[1] === 'eventos' && partes[2] ? decodeURIComponent(partes[2]).toUpperCase() : '';
  const params = new URLSearchParams(location.search);
  if (params.get('pedido') && params.get('t')) cargarPedido(params.get('pedido'), params.get('t'));
  else if (estado.codigo) cargarGaleria();
  else mostrar('codigo');
})();
