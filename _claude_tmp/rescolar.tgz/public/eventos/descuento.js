// Código de descuento en el pedido de un evento (27/10/2026, Pablo: «agreguemos una función de código de descuento al
// momento de hacer el pedido»). Lo usa familias.js (window.DescuentoEvento.iniciar). Es sólo para MOSTRAR el total:
// el monto final lo vuelve a calcular el servidor con la misma regla (eventos/descuentos.ts): digitales hasta 100%;
// copias impresas hasta 70%, salvo códigos «sin tope en el impreso».
(function () {
  'use strict';
  var TOPE_IMPRESO = 70;

  function iniciar(op) {
    var $ = op.$, el = op.el, pesos = op.pesos;
    var actual = null; // { codigo, porcentaje, sinTopeImpreso }
    var input = $('codigo-descuento'), boton = $('btn-codigo'), estadoEl = $('codigo-estado');

    function monto() {
      if (!actual) return 0;
      var ls = op.lineas();
      var total = ls.reduce(function (a, l) { return a + l.subtotal; }, 0);
      var m = ls.reduce(function (a, l) {
        var tope = l.formato === 'digital' || actual.sinTopeImpreso ? 100 : TOPE_IMPRESO;
        return a + Math.round((l.subtotal * Math.min(tope, actual.porcentaje)) / 100);
      }, 0);
      return Math.min(total, m);
    }
    function mostrar(texto, clase) {
      estadoEl.textContent = texto || '';
      estadoEl.className = clase || 'sutil';
      estadoEl.hidden = !texto;
    }
    function quitar(texto) {
      actual = null;
      input.disabled = false;
      boton.textContent = 'Aplicar';
      mostrar(texto, texto ? 'error' : '');
      op.repintar();
    }
    function filaDescuento(cont, codigo, valor) {
      var fila = el('div', 'linea-descuento');
      fila.appendChild(el('span', '', 'Descuento' + (codigo ? ' (código ' + codigo + ')' : '')));
      fila.appendChild(el('span', '', '−' + pesos(valor)));
      cont.appendChild(fila);
    }
    async function aplicar() {
      if (actual) { input.value = ''; quitar(''); return; }
      var valor = input.value.trim().toUpperCase().replace(/\s+/g, '');
      if (!valor) { mostrar('Escribí el código.', 'error'); return; }
      boton.disabled = true;
      mostrar('Revisando el código…');
      try {
        var d = await op.pedirJson('/api/eventos/publico/' + encodeURIComponent(op.codigoEvento()) + '/descuento', {
          method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ codigo: valor }),
        });
        actual = { codigo: d.codigo, porcentaje: Number(d.porcentaje), sinTopeImpreso: d.sinTopeImpreso === true };
        input.value = d.codigo;
        input.disabled = true;
        boton.textContent = 'Quitar';
        var tope = actual.porcentaje > TOPE_IMPRESO && !actual.sinTopeImpreso ? ' (en las copias impresas, hasta ' + TOPE_IMPRESO + '%)' : '';
        mostrar('Código aplicado: ' + actual.porcentaje + '% de descuento' + tope + '.', 'ok-aviso');
        op.repintar();
      } catch (err) {
        mostrar(err.status === 404 ? 'Ese código no es válido o ya no está disponible.' : err.message, 'error');
      } finally {
        boton.disabled = false;
      }
    }
    boton.addEventListener('click', aplicar);
    input.addEventListener('keydown', function (e) { if (e.key === 'Enter') { e.preventDefault(); aplicar(); } });

    return {
      monto: monto,
      codigo: function () { return actual ? actual.codigo : undefined; },
      /** El pedido queda en $0 por el código (no hace falta elegir medio de pago). */
      sinCargo: function (totalAPagar) { return Boolean(actual) && op.lineas().length > 0 && totalAPagar === 0; },
      quitar: quitar,
      /** Fila «Descuento» en el carrito (antes del total). */
      fila: function (cont) { var m = monto(); if (m > 0) filaDescuento(cont, actual.codigo, m); },
      /** Fila «Descuento» en el detalle de un pedido ya hecho (lo que manda el servidor). */
      filaPedido: function (cont, descuento) { if (descuento && descuento.monto > 0) filaDescuento(cont, descuento.codigo, descuento.monto); },
    };
  }

  window.DescuentoEvento = { iniciar: iniciar };
})();
