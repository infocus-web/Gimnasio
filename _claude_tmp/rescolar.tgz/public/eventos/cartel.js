// Cartel A4 con el QR del evento (retratoescolar.com.ar/eventos-cartel?id=…). Usa la sesión del panel.
(function () {
  'use strict';
  var $ = function (id) { return document.getElementById(id); };
  var CLAVE = 'infocus_admin_session_token';
  function token() { try { return sessionStorage.getItem(CLAVE) || localStorage.getItem(CLAVE) || ''; } catch (e) { return ''; } }
  function error(texto) { $('estado').textContent = texto; }
  var id = new URLSearchParams(location.search).get('id');
  if (!id) { error('Falta el evento. Abrí el cartel desde el panel de eventos.'); return; }
  var cabecera = { Authorization: 'Bearer ' + token() };
  fetch('/api/eventos/admin/eventos', { headers: cabecera })
    .then(function (r) { return r.json(); })
    .then(function (d) {
      if (!d.success) throw new Error(d.error || 'No se pudo leer el evento. Entrá al panel con el PIN y volvé a abrir el cartel.');
      var ev = d.eventos.filter(function (e) { return e.id === id; })[0];
      if (!ev) throw new Error('No se encontró el evento.');
      $('titulo').textContent = ev.nombre;
      $('input-titulo').value = ev.nombre;
      $('codigo').textContent = ev.codigo;
      var partes = [];
      if (ev.lugar) partes.push(ev.lugar);
      if (ev.fecha_evento) { var f = ev.fecha_evento.split('-'); partes.push(f[2] + '/' + f[1] + '/' + f[0]); }
      $('subtitulo').textContent = partes.join(' · ');
      if (!ev.publicado) error('⚠️ El evento todavía NO está publicado: si escanean ahora, no van a ver las fotos.');
      return fetch('/api/eventos/admin/eventos/' + encodeURIComponent(id) + '/qr', { headers: cabecera });
    })
    .then(function (r) {
      if (!r.ok) throw new Error('No se pudo generar el QR.');
      var url = r.headers.get('X-Url-Qr') || '';
      $('url').textContent = url.replace(/^https?:\/\/(www\.)?/, '');
      return r.blob();
    })
    .then(function (blob) {
      $('qr').src = URL.createObjectURL(blob);
      if ($('estado').textContent.indexOf('⚠️') !== 0) error('Listo. Revisá el título y tocá Imprimir (o "Guardar como PDF").');
      $('btn-imprimir').disabled = false;
    })
    .catch(function (e) { error(e.message); });
  $('input-titulo').addEventListener('input', function (e) { $('titulo').textContent = e.target.value; });
  $('btn-imprimir').addEventListener('click', function () { window.print(); });
})();
