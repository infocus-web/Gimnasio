// Laboratorio de EVENTOS — retratoescolar.com.ar/laboratorio-eventos
// Ingresa con el mismo PIN del laboratorio (/api/lab/login). También sirve la sesión de admin.
(function () {
  'use strict';
  var CLAVE_LAB = 'ev_lab_token';
  var CLAVE_ADMIN = 'infocus_admin_session_token';
  var $ = function (id) { return document.getElementById(id); };
  var descargando = false;
  var planActivo = null; // 14/10/2026: lote bajándose en partes, con partes pendientes
  var sesionVencida = false; // tras un 401 no se reusan las sesiones viejas (lab o admin) hasta ingresar

  function leer(clave) {
    try { return sessionStorage.getItem(clave) || localStorage.getItem(clave); } catch (e) { return null; }
  }
  // También sirve la sesión del panel del laboratorio de siempre (/laboratorio).
  function token() { return sesionVencida ? leer(CLAVE_LAB) : leer(CLAVE_LAB) || leer('lab_token_v1') || leer(CLAVE_ADMIN); }
  function guardar(t) {
    sesionVencida = false;
    try { sessionStorage.setItem(CLAVE_LAB, t); } catch (e) { /* nada */ }
    try { localStorage.setItem(CLAVE_LAB, t); } catch (e) { /* nada */ }
  }
  function salir() {
    sesionVencida = true;
    [CLAVE_LAB, 'lab_token_v1'].forEach(function (c) {
      try { sessionStorage.removeItem(c); } catch (e) { /* nada */ }
      try { localStorage.removeItem(c); } catch (e) { /* nada */ }
    });
    mostrar('login');
  }
  function mostrar(v) {
    $('vista-login').hidden = v !== 'login';
    $('vista-lotes').hidden = v !== 'lotes';
    $('btn-salir').hidden = v === 'login';
  }
  var t;
  function aviso(texto, error) {
    var a = $('aviso');
    a.textContent = texto;
    a.className = 'aviso' + (error ? ' error-aviso' : '');
    a.hidden = false;
    clearTimeout(t);
    t = setTimeout(function () { a.hidden = true; }, error ? 7000 : 3500);
  }
  function el(tag, clase, texto) {
    var e = document.createElement(tag);
    if (clase) e.className = clase;
    if (texto !== undefined) e.textContent = texto;
    return e;
  }
  function fecha(iso) {
    return iso ? new Date(iso).toLocaleString('es-AR', { timeZone: 'America/Argentina/Buenos_Aires', day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' }) : '';
  }
  function api(metodo, ruta, cuerpo) {
    var op = { method: metodo, headers: { Authorization: 'Bearer ' + (token() || '') } };
    if (cuerpo) { op.headers['Content-Type'] = 'application/json'; op.body = JSON.stringify(cuerpo); }
    return fetch(ruta, op).then(function (r) {
      if (r.status === 401) { salir(); throw new Error('La sesión venció. Ingresá de nuevo.'); }
      return r.json().catch(function () { return { success: false, error: 'Error ' + r.status }; }).then(function (d) {
        if (!r.ok || !d.success) throw new Error(d.error || 'Error ' + r.status);
        return d;
      });
    });
  }
  function guardarBlob(blob, nombre) {
    var a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = nombre;
    document.body.appendChild(a);
    a.click();
    setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 5000);
  }

  $('form-login').addEventListener('submit', function (e) {
    e.preventDefault();
    $('login-error').hidden = true;
    fetch('/api/lab/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ pin: $('pin').value }) })
      .then(function (r) { return r.json(); })
      .then(function (d) {
        if (!d.success) throw new Error(d.error || 'PIN incorrecto');
        guardar(d.token);
        $('pin').value = '';
        cargar();
      })
      .catch(function (err) { $('login-error').textContent = err.message; $('login-error').hidden = false; });
  });
  $('btn-salir').addEventListener('click', salir);
  $('btn-actualizar').addEventListener('click', function () { cargar(); });

  var ESTADOS = { armado: ['Nuevo', 'chip-pend'], en_laboratorio: ['Descargado', 'chip-lab'], terminado: ['Terminado', 'chip-ok'] };
  function cargar() {
    return api('GET', '/api/eventos/lab/lotes').then(function (d) {
      mostrar('lotes');
      var lista = $('lista');
      lista.textContent = '';
      $('vacio').hidden = d.lotes.length > 0;
      d.lotes.forEach(function (l) {
        var fila = el('div', 'tarjeta lote');
        var info = el('div', 'info');
        info.appendChild(el('strong', '', (l.evento ? l.evento.nombre : 'Evento') + ' — Lote ' + l.numero + ' '));
        var est = ESTADOS[l.estado] || [l.estado, 'chip-off'];
        info.appendChild(el('span', 'chip ' + est[1], est[0]));
        info.appendChild(el('div', 'sutil', 'Armado ' + fecha(l.creado_en) + ' · ' + l.pedidos + ' pedido(s) · 15x21: ' + l.copias15x21 + ' copias · 20x30: ' + l.copias20x30 + ' copias' +
          (l.fecha_terminado ? ' · terminado ' + fecha(l.fecha_terminado) : '')));
        // 14/10/2026: pedidos del lote anulados después de armarlo (devolución): ya no vienen en el ZIP nuevo,
        // pero si el lote se bajó antes hay que separarlos.
        if (l.anulados) {
          info.appendChild(el('div', 'error', '⚠ Anulado: no imprimir — ' + (l.anuladosDetalle && l.anuladosDetalle.length ? l.anuladosDetalle.join(', ') : l.anulados + ' pedido(s) de este lote') +
            '. Si ya lo bajaron, separen esas copias.'));
        }
        fila.appendChild(info);
        var bZip = el('button', 'btn btn-primario btn-chico', 'Descargar ZIP');
        bZip.addEventListener('click', function () { descargarZip(l, bZip); });
        fila.appendChild(bZip);
        var bXls = el('button', 'btn btn-chico', 'Excel');
        bXls.addEventListener('click', function () {
          bXls.disabled = true;
          fetch('/api/eventos/lab/lotes/' + l.id + '/excel', { headers: { Authorization: 'Bearer ' + (token() || '') } })
            .then(function (r) { if (!r.ok) throw new Error('No se pudo descargar el Excel'); return r.blob(); })
            .then(function (b) { guardarBlob(b, 'lote-' + (l.evento ? l.evento.codigo : 'evento') + '-' + l.numero + '.xlsx'); })
            .catch(function (e) { aviso(e.message, true); })
            .then(function () { bXls.disabled = false; });
        });
        fila.appendChild(bXls);
        if (l.estado === 'en_laboratorio') {
          var bFin = el('button', 'btn btn-chico', 'Marcar terminado');
          bFin.addEventListener('click', function () {
            if (!confirm('¿Terminaste de imprimir el lote ' + l.numero + '? Le avisamos a Retrato Escolar.')) return;
            bFin.disabled = true;
            api('POST', '/api/eventos/lab/lotes/' + l.id + '/estado', { paso: 'terminado' })
              .then(function () { aviso('Lote marcado como terminado.'); return cargar(); })
              .catch(function (e) { aviso(e.message, true); bFin.disabled = false; });
          });
          fila.appendChild(bFin);
        }
        lista.appendChild(fila);
      });
    }).catch(function (e) {
      if (sesionVencida) { mostrar('login'); aviso(e.message, true); return; }
      if (token()) { aviso(e.message, true); mostrar('lotes'); }
    });
  }

  function progreso(hechos, total, texto) {
    $('progreso').hidden = false;
    $('barra-relleno').style.width = (total ? Math.round(hechos / total * 100) : 0) + '%';
    $('texto-progreso').textContent = texto;
  }

  // Baja cada original una sola vez (aunque tenga varias copias) y arma el ZIP en el navegador.
  // Lotes grandes: partes de hasta 80 archivos, cada una con su botón (el navegador no bloquea
  // descargas automáticas en silencio). "Descargado" sólo cuando se bajó todo sin faltantes.
  function armarParte(plan, nro) {
    var zip = new JSZip();
    var urls = plan.partes[nro];
    var faltan = nro === plan.partes.length - 1 ? plan.sinOriginal.slice() : [];
    var i = 0;
    var hechos = 0;
    var etiqueta = plan.partes.length > 1 ? ' (parte ' + (nro + 1) + ' de ' + plan.partes.length + ')' : '';
    function siguiente() {
      if (i >= urls.length) return Promise.resolve();
      var url = urls[i++];
      return fetch(url).then(function (r) {
        if (!r.ok) throw new Error('HTTP ' + r.status);
        return r.arrayBuffer();
      }).then(function (datos) {
        plan.porUrl[url].forEach(function (a) { zip.file(a.carpeta + '/' + a.nombre, datos, { binary: true }); });
      }).catch(function (e) {
        plan.porUrl[url].forEach(function (a) { faltan.push(a.nombre + ' (' + e.message + ')'); });
      }).then(function () {
        hechos++;
        progreso(hechos, urls.length, 'Descargando originales: ' + hechos + ' de ' + urls.length + '…' + etiqueta);
        return siguiente();
      });
    }
    return Promise.all([siguiente(), siguiente(), siguiente(), siguiente()]).then(function () {
      if (faltan.length) zip.file('FALTAN_ARCHIVOS.txt', 'No se pudieron incluir:\r\n' + faltan.join('\r\n'));
      return zip.generateAsync({ type: 'blob', compression: 'STORE' }, function (m) {
        progreso(m.percent, 100, 'Armando el ZIP' + etiqueta + '… ' + Math.round(m.percent) + '%');
      });
    }).then(function (blob) {
      guardarBlob(blob, 'Lote-' + plan.numero + '-' + plan.codigo + (plan.partes.length > 1 ? '-parte-' + (nro + 1) + '-de-' + plan.partes.length : '') + '.zip');
      plan.hechas[nro] = faltan;
      // 14/10/2026: se anota en el lote qué partes ya se bajaron (si se recarga la página, se retoma desde ahí).
      if (plan.partes.length > 1) {
        api('POST', '/api/eventos/lab/lotes/' + plan.loteId + '/partes', { total: plan.total, partes: plan.partes.length, parte: nro, faltan: faltan.length })
          .catch(function () { /* no es crítico: sólo se pierde el retomar */ });
      }
    });
  }
  // 14/10/2026: los links firmados duran 2 h; si el lote se baja de a partes durante más tiempo, antes de cada
  // parte se piden links nuevos (con el mismo reparto en partes).
  var VIDA_LINKS_MS = 100 * 60 * 1000;
  function linksFrescos(plan) {
    if (Date.now() - plan.creado < VIDA_LINKS_MS) return Promise.resolve();
    progreso(0, 1, 'Renovando los links de descarga…');
    return api('GET', '/api/eventos/lab/lotes/' + plan.loteId + '/manifiesto').then(function (d) {
      var nuevo = armarPlan(plan.loteId, d);
      if (nuevo.total !== plan.total || nuevo.partes.length !== plan.partes.length) throw new Error('El lote cambió mientras lo bajaban: tocá «Descargar ZIP» de nuevo.');
      plan.partes = nuevo.partes;
      plan.porUrl = nuevo.porUrl;
      plan.creado = nuevo.creado;
    });
  }
  function bajarParte(plan, nro) {
    return linksFrescos(plan).then(function () { return armarParte(plan, nro); });
  }
  function cajaPartes() {
    var caja = $('partes-zip');
    if (!caja) {
      caja = el('div', 'partes-zip');
      caja.id = 'partes-zip';
      $('progreso').parentNode.insertBefore(caja, $('progreso').nextSibling);
    }
    return caja;
  }
  function pintarPartes(plan, boton) {
    var caja = cajaPartes();
    caja.textContent = '';
    if (!plan) return;
    caja.appendChild(el('p', '', 'Lote ' + plan.numero + ': es grande, se baja en ' + plan.partes.length + ' partes. Tocá cada una:'));
    plan.partes.forEach(function (_, n) {
      var hecha = plan.hechas[n] !== undefined;
      var b = el('button', 'btn btn-chico' + (hecha ? '' : ' btn-primario'), hecha ? '✓ Parte ' + (n + 1) + ' (bajar otra vez)' : 'Bajar parte ' + (n + 1) + ' de ' + plan.partes.length);
      b.type = 'button';
      b.addEventListener('click', function () {
        if (descargando) return;
        descargando = true;
        bajarParte(plan, n).then(function () { return terminarSiCorresponde(plan, boton); })
          .catch(function (e) { aviso(e.message, true); })
          .then(function () { descargando = false; });
      });
      caja.appendChild(b);
    });
  }
  function terminarSiCorresponde(plan, boton) {
    var hechas = Object.keys(plan.hechas).length;
    if (hechas < plan.partes.length) {
      planActivo = plan; // 14/10/2026: entre parte y parte sigue el aviso al cerrar la pestaña
      pintarPartes(plan, boton);
      progreso(1, 1, '✓ Parte bajada. Faltan ' + (plan.partes.length - hechas) + ' parte(s): tocá los botones de abajo.');
      return Promise.resolve();
    }
    planActivo = null;
    var faltan = [];
    Object.keys(plan.hechas).forEach(function (k) { faltan = faltan.concat(plan.hechas[k]); });
    if (faltan.length) {
      pintarPartes(null);
      progreso(1, 1, '⚠️ Faltaron ' + faltan.length + ' archivo(s): mirá FALTAN_ARCHIVOS.txt adentro del ZIP y volvé a descargar. El lote NO se marcó como descargado.');
      return cargar();
    }
    // Los botones de las partes se sacan recién cuando el servidor confirmó (si falla, se puede reintentar).
    return api('POST', '/api/eventos/lab/lotes/' + plan.loteId + '/estado', { paso: 'descargado' }).then(function () {
      pintarPartes(null);
      progreso(1, 1, '✓ Lote descargado completo (' + plan.total + ' archivos' + (plan.partes.length > 1 ? ' en ' + plan.partes.length + ' partes' : '') + ').');
      return cargar();
    });
  }

  function descargarZip(lote, boton) {
    if (descargando) return;
    if (typeof JSZip === 'undefined') { aviso('No cargó el armador de ZIP. Recargá la página.', true); return; }
    descargando = true;
    boton.disabled = true;
    planActivo = null;
    pintarPartes(null);
    progreso(0, 1, 'Preparando la lista de archivos…');
    api('GET', '/api/eventos/lab/lotes/' + lote.id + '/manifiesto').then(function (d) {
      if (!d.archivos.length) throw new Error('Este lote no tiene copias para imprimir.');
      var plan = armarPlan(lote.id, d);
      if (plan.partes.length === 1) return armarParte(plan, 0).then(function () { return terminarSiCorresponde(plan, boton); });
      // 14/10/2026: lote en partes: se retoma lo que ya estaba bajado (partes sin faltantes, mismo reparto).
      return api('GET', '/api/eventos/lab/lotes/' + lote.id + '/partes').catch(function () { return {}; }).then(function (r) {
        var previo = r && r.progreso;
        if (previo && previo.total === plan.total && previo.partes === plan.partes.length && previo.hechas) {
          Object.keys(previo.hechas).forEach(function (k) { if (previo.hechas[k] === 0 && plan.partes[k]) plan.hechas[k] = []; });
        }
        var ya = Object.keys(plan.hechas).length;
        if (!ya) return armarParte(plan, 0).then(function () { return terminarSiCorresponde(plan, boton); });
        return terminarSiCorresponde(plan, boton).then(function () {
          if (ya < plan.partes.length) progreso(1, 1, 'Este lote ya tenía ' + ya + ' de ' + plan.partes.length + ' partes bajadas: tocá las que faltan.');
        });
      });
    }).catch(function (e) {
      aviso(e.message, true);
      $('progreso').hidden = true;
    }).then(function () {
      descargando = false;
      boton.disabled = false;
    });
  }

  // Reparte los archivos del manifiesto en partes de hasta 80 (siempre igual para el mismo lote).
  function armarPlan(loteId, d) {
    var porUrl = {};
    d.archivos.forEach(function (a) {
      if (!a.url) return;
      (porUrl[a.url] = porUrl[a.url] || []).push(a);
    });
    var partes = [];
    var actual = [];
    var enActual = 0;
    Object.keys(porUrl).forEach(function (url) {
      var n = porUrl[url].length;
      if (actual.length && enActual + n > 80) { partes.push(actual); actual = []; enActual = 0; }
      actual.push(url);
      enActual += n;
    });
    if (actual.length || !partes.length) partes.push(actual);
    return {
      loteId: loteId,
      creado: Date.now(),
      numero: d.lote.numero,
      codigo: d.lote.evento ? d.lote.evento.codigo : 'evento',
      partes: partes,
      porUrl: porUrl,
      total: d.archivos.length,
      sinOriginal: d.archivos.filter(function (a) { return !a.url; }).map(function (a) { return a.nombre + ' (sin original en el servidor)'; }),
      hechas: {}
    };
  }

  window.addEventListener('beforeunload', function (e) { if (descargando || planActivo) { e.preventDefault(); e.returnValue = ''; } });
  if (token()) cargar(); else mostrar('login');
})();
