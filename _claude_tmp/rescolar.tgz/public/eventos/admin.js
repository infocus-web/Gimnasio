// Panel de EVENTOS (comuniones, actos) — retratoescolar.com.ar/eventos-admin
// Página aparte del panel de kits: habla sólo con /api/eventos/... (más el login de admin
// existente, /api/admin/login, para usar el mismo PIN y la misma sesión).
(function () {
  'use strict';

  var CLAVE_TOKEN = 'infocus_admin_session_token'; // misma sesión que el panel principal
  var SUBIDAS_EN_PARALELO = 3;
  var TANDA = 20;

  var $ = function (id) { return document.getElementById(id); };
  var estado = { eventos: [], evento: null, fotos: [], subiendo: false }; window.panelEventos = { estado: estado, api: function (m, r, c, t) { return api(m, r, c, t); }, conReintentos: conReintentos, aviso: aviso, recargarFotos: function () { return cargarFotos(); }, avisarAnotados: function (id) { seguirAvisando(id, 0); } }; // 17/10: lo usa eventos/drive.js

  // ---------------- Sesión ----------------
  function leerToken() {
    try { return sessionStorage.getItem(CLAVE_TOKEN) || localStorage.getItem(CLAVE_TOKEN); } catch (e) { return null; }
  }
  function guardarToken(t) {
    try { sessionStorage.setItem(CLAVE_TOKEN, t); } catch (e) { /* sin almacenamiento */ }
    try { localStorage.setItem(CLAVE_TOKEN, t); } catch (e) { /* sin almacenamiento */ }
  }
  function borrarToken() {
    try { sessionStorage.removeItem(CLAVE_TOKEN); } catch (e) { /* nada */ }
    try { localStorage.removeItem(CLAVE_TOKEN); } catch (e) { /* nada */ }
  }

  function api(metodo, ruta, cuerpo, tiempoMaxMs) {
    var opciones = { method: metodo, headers: { Authorization: 'Bearer ' + (leerToken() || '') } };
    if (cuerpo !== undefined) {
      opciones.headers['Content-Type'] = 'application/json';
      opciones.body = JSON.stringify(cuerpo);
    }
    // 03/10: tiempo máximo opcional, para que un pedido colgado no deje la subida esperando para siempre.
    var corte = null;
    if (tiempoMaxMs && typeof AbortController === 'function') {
      var ctrl = new AbortController();
      opciones.signal = ctrl.signal;
      corte = setTimeout(function () { ctrl.abort(); }, tiempoMaxMs);
    }
    return fetch(ruta, opciones).then(function (r) {
      if (corte) clearTimeout(corte);
      return r.json().catch(function () { return { success: false, error: 'Respuesta inválida del servidor (' + r.status + ')' }; })
        .then(function (datos) {
          if (r.status === 401) { borrarToken(); mostrarVista('login'); }
          if (!r.ok || !datos.success) { var err = new Error(datos.error || ('Error ' + r.status)); err.datos = datos; err.status = r.status; throw err; }
          return datos;
        });
    }, function (e) {
      if (corte) clearTimeout(corte);
      var err = new Error(e && e.name === 'AbortError' ? 'El servidor tardó demasiado en responder' : 'Sin conexión con el servidor');
      err.status = 0;
      throw err;
    });
  }

  // 03/10: reintenta errores pasajeros (sin conexión, demora, 429 o 5xx) con espera creciente.
  function esperar(ms) { return new Promise(function (ok) { setTimeout(ok, ms); }); }
  function conReintentos(fn, esperas) {
    var intento = 0;
    function probar() {
      return fn().catch(function (e) {
        var pasajero = !e.status || e.status === 429 || e.status >= 500;
        if (!pasajero || intento >= esperas.length) throw e;
        return esperar(esperas[intento++]).then(probar);
      });
    }
    return probar();
  }

  // ---------------- Utilidades de UI ----------------
  var temporizadorAviso;
  function aviso(texto, esError) {
    var el = $('aviso');
    el.textContent = texto;
    el.className = 'aviso' + (esError ? ' error-aviso' : '');
    el.hidden = false;
    clearTimeout(temporizadorAviso);
    temporizadorAviso = setTimeout(function () { el.hidden = true; }, esError ? 7000 : 3500);
  }
  function mostrarVista(nombre) {
    ['login', 'lista', 'evento'].forEach(function (v) { $('vista-' + v).hidden = v !== nombre; });
    $('btn-salir').hidden = nombre === 'login';
    window.scrollTo(0, 0);
  }
  function pesos(n) { return '$' + Number(n || 0).toLocaleString('es-AR'); }
  function fechaCorta(iso) {
    if (!iso) return '';
    var p = iso.split('-');
    return p[2] + '/' + p[1] + '/' + p[0];
  }
  function el(tag, clase, texto) {
    var e = document.createElement(tag);
    if (clase) e.className = clase;
    if (texto !== undefined) e.textContent = texto;
    return e;
  }

  // ---------------- Login ----------------
  $('form-login').addEventListener('submit', function (ev) {
    ev.preventDefault();
    $('login-error').hidden = true;
    fetch('/api/admin/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ pin: $('pin').value })
    }).then(function (r) { return r.json(); }).then(function (d) {
      if (!d.success) throw new Error(d.error || 'PIN incorrecto');
      guardarToken(d.token);
      $('pin').value = '';
      cargarLista();
    }).catch(function (e) {
      $('login-error').textContent = e.message;
      $('login-error').hidden = false;
    });
  });
  $('btn-salir').addEventListener('click', function () { borrarToken(); mostrarVista('login'); });

  // ---------------- Lista ----------------
  function cargarLista() {
    return api('GET', '/api/eventos/admin/eventos').then(function (d) {
      estado.eventos = d.eventos;
      pintarLista();
      cargarSuscriptores();
      mostrarVista('lista');
    }).catch(function (e) {
      if (!leerToken()) return; // 401: ya se mostró el login
      aviso(e.message, true);
      mostrarVista('lista');
    });
  }
  function cargarSuscriptores() {
    api('GET', '/api/eventos/admin/suscriptores').then(function (d) {
      $('bloque-suscriptores').hidden = false;
      $('cant-suscriptores').textContent = '(' + d.activos + (d.bajas ? ' · ' + d.bajas + ' de baja' : '') + ')';
      $('btn-suscriptores').disabled = !d.activos;
    }).catch(function () { /* no es crítico */ });
  }
  $('btn-suscriptores').addEventListener('click', function () {
    var b = this;
    b.disabled = true;
    descargarArchivo('/api/eventos/admin/suscriptores.xlsx', 'suscriptores-retrato-escolar.xlsx')
      .catch(function (e) { aviso(e.message, true); }).then(function () { b.disabled = false; });
  });
  function pintarLista() {
    var cont = $('lista-eventos'); cont.textContent = '';
    $('lista-vacia').hidden = estado.eventos.length > 0;
    estado.eventos.forEach(function (ev) {
      var card = el('div', 'tarjeta evento-card');
      card.appendChild(el('h3', '', ev.nombre));
      var chips = el('div');
      chips.appendChild(el('span', 'chip chip-codigo', ev.codigo));
      chips.appendChild(el('span', 'chip ' + (ev.publicado ? 'chip-ok' : 'chip-off'), ev.publicado ? 'Publicado' : 'Sin publicar'));
      if (ev.muestras_lupa) chips.appendChild(el('span', 'chip chip-ok', 'Con lupa'));
      card.appendChild(chips);
      if (window.VentasEvento) card.appendChild(window.VentasEvento.bloque(ev, el, pesos)); // 11/10: compras nuevas y recaudado (ventas.js)
      var detalle = ev.fecha_evento ? [fechaCorta(ev.fecha_evento)] : [];
      var n = ev.cantidad_fotos || 0; detalle.push(n + ' foto' + (n === 1 ? '' : 's'));
      if (ev.fecha_limite) detalle.push('pedidos hasta ' + fechaCorta(ev.fecha_limite) + (ev.primer_envio_efectivo ? ' (1.º envío al lab ' + fechaCorta(ev.primer_envio_efectivo) + ')' : ''));
      if (ev.avisos_pendientes) detalle.push(ev.avisos_pendientes + ' esperando aviso por mail');
      card.appendChild(el('p', 'sutil', detalle.join(' · ')));
      card.appendChild(el('p', 'sutil', 'Digital ' + pesos(ev.precio_digital) + ' · 15x21 ' + pesos(ev.precio_15x21) + ' · 20x30 ' + pesos(ev.precio_20x30)));
      card.addEventListener('click', function () { abrirEvento(ev); });
      cont.appendChild(card);
    });
  }
  $('btn-nuevo').addEventListener('click', function () { abrirEvento(null); });
  $('btn-volver').addEventListener('click', function () {
    var seguir = estado.subiendo
      ? confirmar({ titulo: 'Hay una subida en curso', texto: 'Las fotos que ya terminaron de subir quedan cargadas; las que faltan no se suben.', ok: 'Salir igual', peligro: true })
      : Promise.resolve(true);
    seguir.then(function (si) {
      if (!si) return;
      if (estado.subiendo) estado.cancelarSubida = true; // la subida termina lo que está en curso y no sigue
      estado.evento = null; cargarLista(); // auditoría 11/10: nada queda apuntando al evento anterior
    });
  });

  // ---------------- Evento ----------------
  var CAMPOS = ['nombre', 'codigo', 'lugar', 'fecha_evento', 'fecha_limite', 'fecha_primer_envio', 'precio_digital', 'precio_15x21', 'precio_20x30', 'lugar_retiro'];
  function abrirEvento(ev) {
    estado.evento = ev;
    estado.fotos = [];
    estado.verFotos = false;
    llenarFormulario(ev, ev ? !(ev.publicado || ev.cantidad_fotos > 0) : true);
    $('evento-error').hidden = true;
    $('titulo-evento').textContent = ev ? ev.nombre : 'Nuevo evento';
    $('resumen-evento').hidden = !ev;
    if (ev) pintarResumenEvento();
    plegarFormulario(!!ev); // evento existente: plegado; nuevo: abierto para completarlo
    $('btn-borrar-evento').hidden = !ev;
    $('bloque-fotos').hidden = !ev;
    $('bloque-pedidos').hidden = !ev;
    $('bloque-lotes').hidden = !ev;
    $('lista-lotes').textContent = '';
    lotesPorId = {};
    seleccion.clear();
    abiertos.clear();
    filtroPedidos = null;
    busquedaPedidos = '';
    $('buscar-pedido').value = '';
    pedidosActuales = [];
    $('lista-pedidos').textContent = '';
    $('tablero-pedidos').textContent = '';
    $('pedidos-actualizado').textContent = '';
    $('grilla-fotos').textContent = '';
    $('progreso').hidden = true;
    if (ev) {
      actualizarLinkFamilias();
      refrescarEvento();
      cargarFotos();
      cargarPedidos();
      cargarLotes();
    }
    mostrarVista('evento');
  }
  // 14/10/2026: el formulario se llena con lo último del servidor (la lista puede estar vieja y pisaba precios o
  // `publicado`). Con el evento publicado o con fotos/pedidos el código queda bloqueado (rompería el QR impreso).
  var NOTA_CODIGO = 'El código no se puede cambiar: el evento ya está publicado o tiene fotos/pedidos, y cambiarlo rompería el QR impreso y los links.';
  function llenarFormulario(ev, codigoEditable) {
    var f = $('form-evento');
    CAMPOS.forEach(function (c) { f.elements[c].value = ev && ev[c] != null ? ev[c] : ''; });
    f.elements.impresa_incluye_digital.checked = ev ? !!ev.impresa_incluye_digital : true;
    f.elements.publicado.checked = ev ? !!ev.publicado : false;
    f.elements.muestras_lupa.checked = ev ? !!ev.muestras_lupa : false;
    var nota = f.elements.codigo.parentNode.querySelector('small');
    if (nota && !nota.dataset.original) nota.dataset.original = nota.textContent;
    f.elements.codigo.readOnly = !codigoEditable;
    if (nota) nota.textContent = codigoEditable ? nota.dataset.original : NOTA_CODIGO;
  }
  function refrescarEvento() {
    if (!estado.evento) return Promise.resolve();
    var id = estado.evento.id;
    return api('GET', '/api/eventos/admin/eventos/' + id).then(function (d) {
      if (!estado.evento || estado.evento.id !== id) return;
      estado.evento = Object.assign({}, estado.evento, d.evento);
      llenarFormulario(estado.evento, d.codigoEditable);
      $('titulo-evento').textContent = estado.evento.nombre;
      pintarResumenEvento();
    }).catch(function (e) { aviso(e.message, true); });
  }

  // ---------------- Datos del evento plegables ----------------
  function pintarResumenEvento() {
    var ev = estado.evento;
    var chips = $('resumen-chips');
    chips.textContent = '';
    chips.appendChild(el('span', 'chip chip-codigo', ev.codigo));
    chips.appendChild(el('span', 'chip ' + (ev.publicado ? 'chip-ok' : 'chip-off'), ev.publicado ? 'Publicado' : 'Sin publicar'));
    if (ev.muestras_lupa) chips.appendChild(el('span', 'chip chip-ok', 'Con lupa'));
    var detalle = [];
    if (ev.lugar) detalle.push(ev.lugar);
    if (ev.fecha_evento) detalle.push('Evento ' + fechaCorta(ev.fecha_evento));
    if (ev.fecha_limite) detalle.push('Pedidos hasta ' + fechaCorta(ev.fecha_limite) + (ev.primer_envio_efectivo ? ' · 1.º envío al lab ' + fechaCorta(ev.primer_envio_efectivo) + (ev.fecha_primer_envio ? '' : ' (automático)') + ', 2.º al cierre' : ''));
    if (ev.lugar_retiro) detalle.push('Retiro: ' + ev.lugar_retiro);
    $('resumen-detalle').textContent = detalle.join(' · ');
    var precios = [];
    if (Number(ev.precio_digital) > 0) precios.push('Digital ' + pesos(ev.precio_digital));
    if (Number(ev.precio_15x21) > 0) precios.push('15x21 ' + pesos(ev.precio_15x21));
    if (Number(ev.precio_20x30) > 0) precios.push('20x30 ' + pesos(ev.precio_20x30));
    $('resumen-precios').textContent = precios.join(' · ') + (ev.impresa_incluye_digital ? ' · las impresas incluyen la digital' : '');
    pintarSiguientePaso();
  }

  // 03/10: siempre se muestra qué falta hacer con el evento (subir fotos → publicar → compartir el link).
  function pintarSiguientePaso() {
    var ev = estado.evento;
    if (!ev) return;
    var cantidad = Math.max(estado.fotos ? estado.fotos.length : 0, Number(ev.cantidad_fotos) || 0);
    var caja = $('resumen-siguiente');
    var btn = $('btn-publicar');
    caja.classList.remove('listo');
    if (ev.publicado) {
      caja.textContent = cantidad
        ? '✓ Publicado: las familias entran con el link o el QR de abajo. Compartilo con el colegio.'
        : 'Publicado, pero todavía sin fotos: las familias ven la galería vacía. Subí las fotos abajo.';
      caja.classList.toggle('listo', cantidad > 0);
      btn.hidden = true;
    } else if (cantidad) {
      caja.textContent = fotosSinMarcaNueva()
        ? 'Siguiente paso: tocá «Actualizar muestras» (en «Fotos», abajo) y después publicá el evento. Todavía NO está publicado: las familias no pueden verlo.'
        : 'Siguiente paso: las ' + cantidad + ' fotos ya están cargadas, pero el evento NO está publicado y las familias todavía no pueden verlo. Tocá «Publicar para las familias».';
      btn.hidden = false;
    } else {
      caja.textContent = 'Siguiente paso: subí las fotos abajo. Después vas a poder publicar el evento.';
      btn.hidden = true;
    }
    caja.hidden = false;
  }

  // ---------------- Muestras según el evento (04/10: interruptor «Muestras con lupa») ----------------
  // Clásica (apagado): sufijo -m4. Con lupa (prendido): sufijo -m6 (-m5 = primera versión, menos desenfocada). Ver eventos/marcaAgua.ts.
  function conLupa() {
    return !!(estado.evento && estado.evento.muestras_lupa);
  }
  function fotosSinMarcaNueva() {
    var sufijo = conLupa() ? /-m6\.jpg$/i : /-m4\.jpg$/i;
    return (estado.fotos || []).filter(function (f) { return !sufijo.test(f.preview_path || ''); }).length;
  }
  function pintarAvisoMarca() {
    var n = fotosSinMarcaNueva();
    $('aviso-marca').hidden = n === 0 || !!estado.reforzando;
    if (n) $('texto-marca').textContent = n + ' foto(s) no tienen la muestra ' + (conLupa() ? 'con lupa' : 'clásica') +
      ' que eligió este evento. Tocá «Actualizar muestras» para rehacerlas (no hay que volver a subir nada).';
  }
  $('btn-reforzar-marca').addEventListener('click', function () {
    if (!estado.evento || estado.reforzando) return;
    if (estado.subiendo) { aviso('Esperá a que termine la subida de fotos.', true); return; }
    var eventoId = estado.evento.id;
    var total = fotosSinMarcaNueva();
    var hechas = 0;
    var vueltasSinAvance = 0;
    estado.reforzando = true;
    pintarAvisoMarca();
    $('progreso').hidden = false;
    function mostrar(texto) {
      if (!estado.evento || estado.evento.id !== eventoId) return;
      $('barra-relleno').style.width = (total ? Math.round((hechas / total) * 100) : 100) + '%';
      $('texto-progreso').textContent = texto;
    }
    mostrar('Actualizando muestras: 0 de ' + total + ' — no cierres esta pestaña.');
    function vuelta() {
      return conReintentos(function () {
        return api('POST', '/api/eventos/admin/eventos/' + eventoId + '/reforzar-marca', {}, 58000);
      }, [3000, 8000]).then(function (d) {
        hechas += d.procesadas;
        vueltasSinAvance = d.procesadas ? 0 : vueltasSinAvance + 1;
        if (d.restantes > 0 && vueltasSinAvance < 2) {
          mostrar('Actualizando muestras: ' + hechas + ' de ' + total + ' — no cierres esta pestaña.');
          return vuelta();
        }
        mostrar(d.restantes > 0
          ? 'Quedaron ' + d.restantes + ' foto(s) sin actualizar (no se pudo leer el original). Tocá «Actualizar muestras» de nuevo; si sigue, borralas y volvé a subirlas.'
          : 'Listo: se actualizaron las muestras de ' + hechas + ' foto(s).');
      });
    }
    vuelta().catch(function (e) {
      mostrar('Se cortó la actualización (' + e.message + '). Tocá «Actualizar muestras» para seguir: retoma donde quedó.');
    }).then(function () {
      estado.reforzando = false;
      if (estado.evento && estado.evento.id === eventoId) return cargarFotos();
    });
  });

  $('btn-publicar').addEventListener('click', function (e) {
    e.stopPropagation();
    var ev = estado.evento;
    if (!ev) return;
    confirmar({
      titulo: 'Publicar «' + ev.nombre + '»',
      texto: 'Las familias van a poder ver la galería y hacer pedidos con el link o el QR. Si hay familias anotadas esperando las fotos, les llega un mail avisando.',
      ok: 'Sí, publicar',
    }).then(function (si) {
      if (!si) return;
      var f = $('form-evento');
      f.elements.publicado.checked = true;
      // Si a algún dato le falta algo, se abre el formulario para que se vea qué corregir.
      if (!f.checkValidity()) plegarFormulario(false);
      if (typeof f.requestSubmit === 'function') f.requestSubmit();
      else f.dispatchEvent(new Event('submit', { cancelable: true }));
    });
  });
  function plegarFormulario(plegado) {
    $('form-evento').hidden = plegado;
    $('resumen-evento').classList.toggle('abierto', !plegado);
    $('btn-editar-evento').textContent = plegado ? '✎ Editar datos ▾' : 'Cerrar ▴';
    $('btn-editar-evento').setAttribute('aria-expanded', String(!plegado));
  }
  $('btn-editar-evento').addEventListener('click', function (e) {
    e.stopPropagation();
    if ($('form-evento').hidden) refrescarEvento(); // 14/10/2026: se abre con lo último del servidor
    plegarFormulario(!$('form-evento').hidden);
  });
  $('resumen-evento').addEventListener('click', function () {
    if ($('form-evento').hidden) { refrescarEvento(); plegarFormulario(false); }
  });

  // Auditoría 03/10 noche: los avisos de "ya están las fotos" salen en tandas (~20 s cada una) para no
  // pasar el tiempo máximo del servidor. Se sigue mientras queden y cada tanda avance.
  var avisandoEvento = null;
  function seguirAvisando(eventoId, yaAvisados) {
    if (avisandoEvento === eventoId) return;
    avisandoEvento = eventoId;
    var total = yaAvisados || 0;
    var vueltas = 0;
    function vuelta() {
      return api('POST', '/api/eventos/admin/eventos/' + eventoId + '/avisar-anotados', undefined, 58000).then(function (r) {
        total += r.avisados || 0;
        vueltas++;
        if (r.avisosRestantes > 0 && r.avisados > 0 && vueltas < 30) {
          aviso('Avisando por mail a las familias anotadas: ' + total + ' enviados, faltan ' + r.avisosRestantes + '…');
          return vuelta();
        }
        if (r.avisosRestantes > 0) aviso('Se avisó por mail a ' + total + ' familia(s). Quedaron ' + r.avisosRestantes + ' aviso(s) sin mandar: se reintentan al volver a guardar el evento.', true);
        else if (total) aviso('Se avisó por mail a ' + total + ' familia(s) que esperaban las fotos.');
      });
    }
    vuelta().catch(function () { /* se reintenta al guardar el evento */ }).then(function () { avisandoEvento = null; });
  }

  function actualizarLinkFamilias() {
    var url = location.origin + '/eventos/' + estado.evento.codigo;
    $('link-familias').textContent = url;
    $('link-familias').href = url;
    $('btn-cartel').href = '/eventos-cartel?id=' + encodeURIComponent(estado.evento.id);
  }

  var guardandoEvento = false; // 14/10/2026: un doble clic en «Guardar» creaba dos eventos
  $('form-evento').addEventListener('submit', function (e) {
    e.preventDefault();
    if (guardandoEvento) return;
    var f = e.target;
    var datos = {};
    CAMPOS.forEach(function (c) { datos[c] = f.elements[c].value.trim(); });
    datos.codigo = datos.codigo.toUpperCase();
    datos.impresa_incluye_digital = f.elements.impresa_incluye_digital.checked;
    datos.publicado = f.elements.publicado.checked;
    datos.muestras_lupa = f.elements.muestras_lupa.checked;
    if (estado.evento) datos.actualizado_en = estado.evento.actualizado_en; // 14/10/2026: el servidor no pisa cambios de otro dispositivo
    $('evento-error').hidden = true;
    guardandoEvento = true;
    var boton = f.querySelector('button[type="submit"]');
    if (boton) boton.disabled = true;
    var peticion = estado.evento
      ? api('PUT', '/api/eventos/admin/eventos/' + estado.evento.id, datos)
      : api('POST', '/api/eventos/admin/eventos', datos);
    peticion.then(function (d) {
      var eraNuevo = !estado.evento;
      d.evento.cantidad_fotos = estado.evento ? estado.evento.cantidad_fotos : 0;
      // Auditoría 03/10 noche: al crear, el servidor le agrega al código un sufijo al azar: se muestra el final.
      aviso(eraNuevo ? 'Evento creado con el código ' + d.evento.codigo + ' (es el que va en el link y el QR). Ahora podés subir las fotos.' : 'Cambios guardados.' + (d.avisados ? ' Se avisó por mail a ' + d.avisados + ' familia(s) que esperaban las fotos.' : ''));
      if (!eraNuevo && d.avisosRestantes > 0) seguirAvisando(d.evento.id, d.avisados || 0);
      if (eraNuevo) abrirEvento(d.evento);
      else {
        estado.evento = d.evento;
        $('titulo-evento').textContent = d.evento.nombre;
        actualizarLinkFamilias();
        pintarResumenEvento();
        pintarAvisoMarca(); // si cambió «Muestras con lupa», avisa que hay que actualizar las muestras
        plegarFormulario(true);
      }
    }).catch(function (err) {
      // 14/10/2026: otro dispositivo guardó antes: se recargan los datos para revisarlos y volver a guardar.
      if (err.datos && err.datos.conflicto) refrescarEvento();
      $('evento-error').textContent = err.message + (err.datos && err.datos.conflicto ? ' Ya cargamos los datos nuevos: revisalos y volvé a guardar.' : '');
      $('evento-error').hidden = false;
      if (estado.evento) plegarFormulario(false); // si se guardó desde «Publicar», el error queda a la vista
    }).then(function () {
      guardandoEvento = false;
      if (boton) boton.disabled = false;
    });
  });

  $('btn-borrar-evento').addEventListener('click', function () {
    if (!estado.evento) return;
    var ev = estado.evento;
    var ruta = '/api/eventos/admin/eventos/' + ev.id;
    function listo(d) {
      aviso('Evento borrado' + (d.pedidosBorrados ? ' (con ' + d.pedidosBorrados + ' pedido(s))' : '') + '.');
      cargarLista();
    }
    confirmar({
      titulo: 'Borrar el evento',
      texto: '«' + ev.nombre + '», sus fotos y sus pedidos sin pagar se borran. No se puede deshacer.',
      ok: 'Sí, borrar', peligro: true,
    }).then(function (si) {
      if (!si) return;
      return api('DELETE', ruta).then(listo, function (e) {
        if (!e.datos || !e.datos.requiereConfirmacion) throw e;
        // Tiene pedidos pagados: sólo si se escribe el código (pensado para eventos de prueba).
        var escrito = window.prompt(e.datos.error + '\n\nEscribí ' + e.datos.codigo + ' para borrar todo:');
        if (escrito === null) return;
        if (escrito.trim().toUpperCase() !== e.datos.codigo) { aviso('El código no coincide: no se borró nada.', true); return; }
        return api('DELETE', ruta + '?confirmar=' + encodeURIComponent(e.datos.codigo)).then(listo);
      });
    }).catch(function (e) { aviso(e.message, true); });
  });

  // ---------------- Fotos ----------------
  function cargarFotos() {
    if (!estado.evento) return Promise.resolve();
    var eventoId = estado.evento.id;
    return api('GET', '/api/eventos/admin/eventos/' + eventoId + '/fotos').then(function (d) {
      if (!estado.evento || estado.evento.id !== eventoId) return; // llegó tarde: ya se abrió otro evento
      estado.fotos = d.fotos;
      estado.evento.cantidad_fotos = d.fotos.length;
      pintarFotos();
      pintarSiguientePaso();
      pintarAvisoMarca();
    }).catch(function (e) { aviso(e.message, true); });
  }
  // 03/10: la grilla de fotos (cientos) se pliega para que no tape los pedidos; se abre con un botón.
  function pintarBotonVerFotos() {
    var n = estado.fotos.length;
    var btn = $('btn-ver-fotos');
    btn.hidden = n === 0;
    $('grilla-fotos').hidden = n === 0 || !estado.verFotos;
    btn.textContent = estado.verFotos ? 'Ocultar las fotos ▴' : 'Ver las ' + n + ' fotos ▾';
    btn.setAttribute('aria-expanded', String(!!estado.verFotos));
  }
  $('btn-ver-fotos').addEventListener('click', function () {
    estado.verFotos = !estado.verFotos;
    pintarBotonVerFotos();
  });
  function pintarFotos() {
    var cont = $('grilla-fotos');
    cont.textContent = '';
    $('cantidad-fotos').textContent = '(' + estado.fotos.length + ')';
    pintarBotonVerFotos();
    estado.fotos.forEach(function (foto) {
      var caja = el('div', 'foto');
      var img = el('img');
      img.loading = 'lazy';
      img.src = foto.thumb_url;
      img.alt = foto.nombre_archivo;
      caja.appendChild(img);
      caja.appendChild(el('span', 'nombre', foto.nombre_archivo));
      var borrar = el('button', 'borrar', '×');
      borrar.title = 'Borrar foto';
      borrar.addEventListener('click', function () {
        confirmar({ titulo: 'Borrar ' + foto.nombre_archivo, texto: 'La foto deja de verse en la galería.', ok: 'Sí, borrar', peligro: true }).then(function (si) {
          if (!si) return;
          return api('DELETE', '/api/eventos/admin/fotos/' + foto.id).then(function () {
            estado.fotos = estado.fotos.filter(function (x) { return x.id !== foto.id; });
            estado.evento.cantidad_fotos = estado.fotos.length;
            pintarSiguientePaso();
            pintarFotos();
          });
        }).catch(function (e) { aviso(e.message, true); });
      });
      caja.appendChild(borrar);
      cont.appendChild(caja);
    });
  }

  // Marca de agua y desenfoque de las muestras (misma receta que lupa/muestra.ts): están en ventas.js
  // (window.MuestrasEvento). 14/10/2026: se pasaron tal cual para hacer lugar a los arreglos (techo de líneas).

  function subirAFirmada(urlFirmada, blob) {
    // Mismo formato que supabase-js (uploadToSignedUrl): PUT multipart con el archivo.
    // 03/10: tiempo máximo de 3 min por archivo y reintentos ante cortes o errores 5xx de Storage.
    // Si un reintento choca con que el archivo ya quedó subido (409/400 "already exists"), cuenta como subido.
    var yaIntento = false;
    return conReintentos(function () {
      var cuerpo = new FormData();
      cuerpo.append('cacheControl', '31536000');
      cuerpo.append('', blob);
      var opciones = { method: 'PUT', body: cuerpo, headers: { 'x-upsert': 'false' } };
      var corte = null;
      if (typeof AbortController === 'function') {
        var ctrl = new AbortController();
        opciones.signal = ctrl.signal;
        corte = setTimeout(function () { ctrl.abort(); }, 180000);
      }
      var reintento = yaIntento;
      yaIntento = true;
      return fetch(urlFirmada, opciones).then(function (r) {
        if (corte) clearTimeout(corte);
        if (r.ok) return;
        return r.text().then(function (t) {
          if (reintento && (r.status === 409 || r.status === 400) && /exist|duplicate/i.test(t)) return;
          var err = new Error('Falló la subida (' + r.status + '): ' + t.slice(0, 160));
          err.status = r.status;
          throw err;
        });
      }, function (e) {
        if (corte) clearTimeout(corte);
        var err = new Error(e && e.name === 'AbortError' ? 'La subida tardó demasiado' : 'Se cortó la conexión');
        err.status = 0;
        throw err;
      });
    }, [2000, 6000]);
  }

  function procesarArchivo(archivo, subida) {
    return createImageBitmap(archivo).then(function (bitmap) {
      // 03/10: muestras más chicas (800 px / 400 px): alcanzan para elegir en pantalla, no para imprimir.
      // 04/10: el estilo lo decide el servidor según el evento (subida.conLupa), igual que el nombre del archivo.
      var lupa = !!subida.conLupa;
      var copiaReducida = window.MuestrasEvento.copiaReducida;
      return Promise.all([copiaReducida(bitmap, 800, 0.72, lupa), copiaReducida(bitmap, 400, 0.7, lupa)]).then(function (copias) {
        var dims = { ancho: bitmap.width, alto: bitmap.height };
        if (bitmap.close) bitmap.close();
        return Promise.all([
          subirAFirmada(subida.urls.hd, archivo),
          subirAFirmada(subida.urls.preview, copias[0]),
          subirAFirmada(subida.urls.thumb, copias[1])
        ]).then(function () {
          return {
            nombreArchivo: archivo.name,
            rutaHd: subida.rutas.hd,
            rutaPreview: subida.rutas.preview,
            rutaThumb: subida.rutas.thumb,
            ancho: dims.ancho,
            alto: dims.alto
          };
        });
      });
    });
  }

  function progreso(eventoId, hechas, total, errores) {
    if (!estado.evento || estado.evento.id !== eventoId) return; // la subida es de otro evento
    $('progreso').hidden = false;
    $('barra-relleno').style.width = (total ? Math.round((hechas / total) * 100) : 0) + '%';
    $('texto-progreso').textContent = 'Subidas ' + hechas + ' de ' + total + (errores ? ' · ' + errores + ' con error' : '') +
      (hechas < total ? ' — no cierres esta pestaña.' : '');
  }

  // Nombre único dentro de la selección: dos IMG_0001.jpg de carpetas distintas de la cámara pasan a
  // "IMG_0001.jpg" e "IMG_0001 (2).jpg" (antes fallaba la tanda entera). Es determinístico: si se vuelve
  // a elegir la misma selección, los nombres coinciden y las ya cargadas se saltean.
  function nombresUnicos(archivos) {
    var usados = {};
    return archivos.map(function (archivo) {
      var nombre = archivo.name;
      var n = 2;
      while (usados[nombre.toLowerCase()]) {
        nombre = archivo.name.replace(/(\.[^.]+)?$/, ' (' + n + ')$1');
        n++;
      }
      usados[nombre.toLowerCase()] = true;
      return { archivo: archivo, nombre: nombre };
    });
  }

  // Registra las fotos de una tanda; si la tanda entera choca (alguna ya estaba), se registran de a una.
  // 14/10/2026: con reintentos, y «ya registrada» (409) cuenta como registrada: si se perdió la respuesta de un
  // intento que sí guardó, el reintento choca y antes se informaba como error una foto que estaba bien.
  function registrarFotos(eventoId, listas) {
    function registrar(fotos) { return conReintentos(function () { return api('POST', '/api/eventos/admin/eventos/' + eventoId + '/fotos', { fotos: fotos }); }, [3000, 8000]); }
    return registrar(listas).then(function () {
      return { ok: listas.length, fallidas: [] };
    }, function (e) {
      if (e.status === 401) throw e; // sesión vencida: lo maneja la subida
      var ok = 0;
      var fallidas = [];
      return listas.reduce(function (cadena, foto) {
        return cadena.then(function () {
          return registrar([foto]).then(function () { ok++; }, function (e) {
            if (e.status === 409) ok++; else fallidas.push(foto.nombreArchivo + ': ' + e.message);
          });
        });
      }, Promise.resolve()).then(function () { return { ok: ok, fallidas: fallidas }; });
    });
  }

  function subirArchivos(lista) {
    if (!estado.evento) return;
    if (estado.subiendo) {
      aviso('Esperá a que termine la subida anterior (está terminando las fotos que ya había empezado).', true);
      $('input-fotos').value = '';
      return;
    }
    var eventoId = estado.evento.id; // fijo: aunque Pablo abra otro evento, esta subida es de este
    var yaCargadas = {};
    estado.fotos.forEach(function (f) { yaCargadas[f.nombre_archivo.toLowerCase()] = true; });
    var jpg = Array.prototype.filter.call(lista, function (a) { return /^image\/jpe?g$/i.test(a.type) || /\.jpe?g$/i.test(a.name); })
      .sort(function (a, b) { return a.name.localeCompare(b.name, 'es', { numeric: true }) || a.size - b.size || a.lastModified - b.lastModified; });
    var noJpg = lista.length - jpg.length;
    var conNombre = nombresUnicos(jpg);
    var archivos = conNombre.filter(function (x) { return !yaCargadas[x.nombre.toLowerCase()]; });
    var repetidas = conNombre.length - archivos.length;
    var renombradas = conNombre.filter(function (x) { return x.nombre !== x.archivo.name; }).length;
    if (!archivos.length) {
      aviso(repetidas ? 'Nada para subir: esas fotos ya estaban cargadas.' : noJpg ? 'Nada para subir: sólo se aceptan fotos JPG.' : 'No se eligieron fotos.', true);
      $('input-fotos').value = '';
      return;
    }
    estado.subiendo = true;
    estado.cancelarSubida = false;
    var hechas = 0;
    var errores = [];
    var registradas = 0;
    var ordenBase = estado.fotos.length;
    progreso(eventoId, 0, archivos.length, 0);

    var tandas = [];
    for (var i = 0; i < archivos.length; i += TANDA) tandas.push(archivos.slice(i, i + TANDA));

    var cadena = Promise.resolve();
    tandas.forEach(function (tanda, nroTanda) {
      cadena = cadena.then(function () {
        if (estado.cancelarSubida) return;
        // 03/10: antes, si este pedido fallaba una vez (p. ej. 504 de Vercel), se cortaba TODA la subida y la
        // barra quedaba congelada. Ahora se reintenta y, si sigue fallando, sólo esta tanda queda con error.
        return conReintentos(function () {
          return api('POST', '/api/eventos/admin/eventos/' + eventoId + '/subidas', { cantidad: tanda.length }, 45000);
        }, [3000, 8000, 15000]).then(function (d) {
          var listas = [];
          var indice = 0;
          function siguiente() {
            if (indice >= tanda.length || estado.cancelarSubida) return Promise.resolve();
            var pos = indice++;
            var item = tanda[pos];
            return procesarArchivo(item.archivo, d.subidas[pos]).then(function (foto) {
              foto.nombreArchivo = item.nombre;
              foto.orden = ordenBase + nroTanda * TANDA + pos + 1;
              listas.push(foto);
            }).catch(function (e) {
              errores.push(item.nombre + ': ' + e.message);
            }).then(function () {
              hechas++;
              progreso(eventoId, hechas, archivos.length, errores.length);
              return siguiente();
            });
          }
          var trabajadores = [];
          for (var w = 0; w < SUBIDAS_EN_PARALELO; w++) trabajadores.push(siguiente());
          return Promise.all(trabajadores).then(function () {
            if (!listas.length) return;
            // Se registran SIEMPRE las que ya subieron (aunque se haya cancelado): no quedan archivos sueltos.
            return registrarFotos(eventoId, listas).then(function (r) {
              registradas += r.ok;
              errores.push.apply(errores, r.fallidas);
            });
          });
        }).catch(function (e) {
          // 14/10/2026: sesión vencida (24 h) en medio de la subida: se corta todo ya, con un mensaje claro,
          // en vez de fallar tanda por tanda hasta el final.
          if (e.status === 401) { estado.sesionVencida = true; estado.cancelarSubida = true; return; }
          tanda.forEach(function (item) { errores.push(item.nombre + ': ' + e.message); });
          hechas += tanda.length;
          progreso(eventoId, hechas, archivos.length, errores.length);
        });
      });
    });

    cadena.then(function () {
      var mismoEvento = estado.evento && estado.evento.id === eventoId;
      var extra = (repetidas ? ' ' + repetidas + ' ya estaban cargadas.' : '') + (renombradas ? ' ' + renombradas + ' tenían el nombre repetido y se renombraron con (2).' : '') + (noJpg ? ' ' + noJpg + ' no eran JPG.' : '');
      if (estado.sesionVencida) {
        estado.sesionVencida = false;
        confirmar({ titulo: 'Tu sesión venció', texto: 'Tu sesión venció: volvé a entrar y elegí las mismas fotos; las ya subidas se saltean (' + registradas + ' quedaron cargadas).', ok: 'Entendido' });
        return;
      } else if (errores.length) {
        console.error('Fotos con error:', errores);
        aviso(registradas + ' foto(s) subidas. ' + errores.length + ' no se pudieron subir: volvé a elegirlas (las ya cargadas se saltean).' + extra, true);
      } else if (estado.cancelarSubida) {
        aviso('Subida cortada: quedaron ' + registradas + ' foto(s) cargadas.' + extra, true);
      } else {
        aviso('Listo: ' + registradas + ' foto(s) subidas.' + extra);
      }
      // Recién al terminar TODA la subida se avisa a las familias anotadas (si el evento está publicado).
      if (registradas > 0) seguirAvisando(eventoId, 0);
      if (!mismoEvento) return;
      $('texto-progreso').textContent = errores.length
        ? 'Terminó con ' + registradas + ' subidas y ' + errores.length + ' con error. Volvé a elegir las mismas fotos: las ya cargadas se saltean.'
        : estado.cancelarSubida ? 'Subida cortada: ' + registradas + ' foto(s) cargadas.'
        : 'Listo: ' + registradas + ' foto(s) subidas.' + (estado.evento.publicado ? '' : ' Siguiente paso: tocá «Publicar para las familias» (arriba).');
    }).catch(function (e) {
      aviso('Se cortó la subida: ' + e.message, true);
      if (estado.evento && estado.evento.id === eventoId) {
        $('texto-progreso').textContent = 'Se cortó la subida (' + e.message + '). Volvé a elegir las mismas fotos: las ya cargadas se saltean.';
      }
    }).then(function () {
      estado.subiendo = false;
      estado.cancelarSubida = false;
      $('input-fotos').value = '';
      if (estado.evento && estado.evento.id === eventoId) return cargarFotos();
    });
  }

  // 14/10/2026: antes de una subida grande, si la sesión (24 h desde el ingreso) vence en menos de 2 h, se avisa.
  function subirConSesion(lista) {
    var desde = parseInt(String(leerToken() || '').split('.')[0], 10);
    var quedanMin = Math.round((desde + 24 * 3600000 - Date.now()) / 60000);
    if (lista.length < 50 || !(quedanMin < 120) || estado.subiendo) return subirArchivos(lista);
    confirmar({ titulo: 'Tu sesión vence pronto', texto: 'Tu sesión vence en ' + Math.max(quedanMin, 0) + ' minutos y la subida es grande: conviene tocar «Salir», volver a entrar con el PIN y recién ahí elegir las fotos.', ok: 'Subir igual' })
      .then(function (si) { if (si) subirArchivos(lista); else $('input-fotos').value = ''; });
  }
  $('input-fotos').addEventListener('change', function (e) { subirConSesion(Array.prototype.slice.call(e.target.files)); });
  var zona = $('zona-subida');
  zona.addEventListener('dragover', function (e) { e.preventDefault(); zona.classList.add('arrastrando'); });
  zona.addEventListener('dragleave', function () { zona.classList.remove('arrastrando'); });
  zona.addEventListener('drop', function (e) {
    e.preventDefault();
    zona.classList.remove('arrastrando');
    subirConSesion(Array.prototype.slice.call(e.dataTransfer.files));
  });
  window.addEventListener('beforeunload', function (e) {
    if (estado.subiendo) { e.preventDefault(); e.returnValue = ''; }
  });

  // ---------------- Diálogos propios (en lugar de los carteles del navegador) ----------------
  function abrirDialogo(dlg) {
    if (typeof dlg.showModal === 'function') { if (!dlg.open) dlg.showModal(); } else dlg.setAttribute('open', '');
  }
  function cerrarDialogo(dlg) {
    if (typeof dlg.close === 'function') { if (dlg.open) dlg.close(); } else dlg.removeAttribute('open');
  }
  function hayDialogoAbierto() {
    return $('dialogo').hasAttribute('open') || $('dialogo-comprobante').hasAttribute('open');
  }
  // op: { titulo, texto?, detalle?: string[], ok?, peligro? } → Promise<boolean>
  function confirmar(op) {
    return new Promise(function (resolver) {
      var dlg = $('dialogo');
      var ok = $('dialogo-ok');
      var no = $('dialogo-no');
      $('dialogo-titulo').textContent = op.titulo;
      $('dialogo-texto').textContent = op.texto || '';
      $('dialogo-texto').hidden = !op.texto;
      var lista = $('dialogo-detalle');
      lista.textContent = '';
      (op.detalle || []).forEach(function (t) { lista.appendChild(el('li', '', t)); });
      lista.hidden = !(op.detalle && op.detalle.length);
      ok.textContent = op.ok || 'Confirmar';
      ok.className = 'btn ' + (op.peligro ? 'btn-rojo' : 'btn-verde');
      function terminar(valor) {
        ok.onclick = null;
        no.onclick = null;
        dlg.oncancel = null;
        cerrarDialogo(dlg);
        resolver(valor);
      }
      ok.onclick = function () { terminar(true); };
      no.onclick = function () { terminar(false); };
      dlg.oncancel = function (e) { e.preventDefault(); terminar(false); };
      abrirDialogo(dlg);
      ok.focus();
    });
  }

  // ---------------- Pedidos ----------------
  function fechaHoraCorta(iso) {
    if (!iso) return '';
    return new Date(iso).toLocaleString('es-AR', { timeZone: 'America/Argentina/Buenos_Aires', day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit', hour12: false }) + ' h';
  }
  function resumenItems(items) {
    var cuenta = { digital: 0, '15x21': 0, '20x30': 0 };
    items.forEach(function (it) { cuenta[it.formato] += it.formato === 'digital' ? 1 : it.cantidad; });
    var partes = [];
    if (cuenta.digital) partes.push(cuenta.digital + ' digital' + (cuenta.digital === 1 ? '' : 'es'));
    if (cuenta['15x21']) partes.push(cuenta['15x21'] + '× 15x21');
    if (cuenta['20x30']) partes.push(cuenta['20x30'] + '× 20x30');
    return partes.join(' · ');
  }
  // variante: 'verde' | 'primario' | 'peligro' (true = peligro, por compatibilidad)
  function botonAccion(texto, alHacer, variante) {
    var clase = variante === true ? 'peligro' : variante;
    var b = el('button', 'btn btn-chico' + (clase ? ' btn-' + clase : ''), texto);
    b.type = 'button';
    b.addEventListener('click', function (e) {
      e.stopPropagation();
      b.disabled = true;
      Promise.resolve().then(alHacer).catch(function (err) { aviso(err.message, true); }).then(function () { b.disabled = false; });
    });
    return b;
  }
  function normalizar(s) {
    return String(s || '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase();
  }
  function primerNombre(s) { return String(s || '').trim().split(/\s+/)[0] || ''; }
  // Link de WhatsApp a partir de lo que escribió la familia (Argentina: 54 9 + área + número, sin 0 ni 15).
  function numeroWhatsApp(texto) {
    var d = String(texto || '').replace(/\D/g, '');
    if (d.indexOf('00') === 0) d = d.slice(2);
    if (d.indexOf('54') === 0) d = d.slice(2);
    if (d.indexOf('9') === 0 && d.length === 11) d = d.slice(1);
    if (d.indexOf('0') === 0) d = d.slice(1);
    if (d.length === 12) {
      for (var i = 2; i <= 4; i++) if (d.substr(i, 2) === '15') { d = d.slice(0, i) + d.slice(i + 2); break; }
    }
    if (d.length !== 10) return null;
    // "15 1234-5678" sin característica: no se puede saber el área (antes armaba un número equivocado).
    if (d.indexOf('15') === 0) return null;
    return '549' + d;
  }
  function linkWhatsApp(p, mensaje, texto) {
    var n = numeroWhatsApp(p.comprador_whatsapp);
    if (!n) return null;
    var a = el('a', '', texto);
    a.href = 'https://wa.me/' + n + '?text=' + encodeURIComponent(mensaje);
    a.target = '_blank';
    a.rel = 'noopener';
    a.addEventListener('click', function (e) { e.stopPropagation(); });
    return a;
  }

  var seleccion = new Set();
  var pedidosActuales = [];
  var filtroPedidos = null; // null = elegir solo (comprobantes para revisar si hay)
  var busquedaPedidos = '';
  var abiertos = new Set();
  var destacado = null; // pedido recién cambiado: se resalta un momento
  function marcarDestacado(id) {
    destacado = id;
    setTimeout(function () { if (destacado === id) destacado = null; }, 2500);
  }
  function tieneImpresas(p) { return p.items.some(function (it) { return it.formato !== 'digital'; }); }
  function seleccionable(p) { return p.estado === 'pagado' && tieneImpresas(p); }

  var ETAPAS = {
    revisar: { nombre: 'Comprobante para revisar', corto: 'Comprobantes para revisar', clase: 'e-revisar' },
    esperando: { nombre: 'Esperando el pago', corto: 'Esperando pago', clase: 'e-esperando' },
    mandar_lab: { nombre: 'Pagado · falta mandar al laboratorio', corto: 'Falta mandar al lab', clase: 'e-mandar' },
    en_lab: { nombre: 'En el laboratorio', corto: 'En laboratorio', clase: 'e-lab' },
    retiro: { nombre: 'Listo para retirar', corto: 'Para retirar', clase: 'e-retiro' },
    digital: { nombre: 'Sólo digital · enviado', corto: 'Sólo digitales', clase: 'e-digital' }, // 15/10: aparte de los impresos (pedido de Pablo)
    completo: { nombre: 'Entregado', corto: 'Impresos entregados', clase: 'e-completo' },
    cerrado: { nombre: 'Vencido o cancelado', corto: 'Vencidos / cancelados', clase: 'e-cerrado' }
  };
  var ORDEN_ETAPAS = ['revisar', 'esperando', 'mandar_lab', 'en_lab', 'retiro', 'completo', 'digital', 'cerrado'];
  function etapa(p) {
    if (p.estado === 'pendiente') return p.comprobante_subido_en ? 'revisar' : 'esperando';
    if (p.estado !== 'pagado') return 'cerrado';
    if (!tieneImpresas(p)) return 'digital'; // 15/10: sólo digitales, aparte
    if (p.estado_entrega === 'entregado') return 'completo';
    if (p.estado_entrega === 'listo_retiro') return 'retiro';
    if (p.lote_id) return 'en_lab'; // sin lote no llegó al laboratorio (aunque diga "en laboratorio")
    return 'mandar_lab';
  }
  function nombreEtapa(p, et) {
    if (et === 'cerrado') return p.estado === 'vencido' ? 'Vencido' : 'Cancelado';
    if (et === 'en_lab' && p.lote_id && lotesPorId[p.lote_id]) return 'En el laboratorio · lote ' + lotesPorId[p.lote_id].numero;
    return ETAPAS[et].nombre;
  }

  function actualizarBarraSeleccion() {
    $('barra-seleccion').hidden = seleccion.size === 0;
    $('sel-cantidad').textContent = seleccion.size === 1 ? '1 pedido elegido' : seleccion.size + ' pedidos elegidos';
    // Si en la vista actual no hay ninguno para elegir, el checkbox elige todos los del evento.
    var visibles = pedidosVisibles().filter(seleccionable);
    var posibles = visibles.length ? visibles : pedidosActuales.filter(seleccionable);
    $('sel-todos').checked = posibles.length > 0 && posibles.every(function (p) { return seleccion.has(p.id); });
    $('sel-todos-caja').hidden = pedidosActuales.filter(seleccionable).length === 0;
    $('sel-todos-texto').textContent = visibles.length
      ? 'Elegir todos los de esta lista que tienen impresas (' + visibles.length + ')'
      : 'Elegir todos los pagados con impresas (' + posibles.length + ')';
  }
  function cargarPedidos(silencioso) {
    if (!estado.evento) return;
    var eventoId = estado.evento.id;
    // 14/10/2026: sólo al abrirlos a propósito se marcan vistos (el refresco de cada minuto no borra «compras nuevas»).
    return api('GET', '/api/eventos/admin/eventos/' + eventoId + '/pedidos' + (silencioso ? '' : '?vistos=1')).then(function (d) {
      if (!estado.evento || estado.evento.id !== eventoId) return;
      pintarPedidos(d.pedidos);
      $('pedidos-actualizado').textContent = 'Actualizado ' + new Date().toLocaleTimeString('es-AR', { hour: '2-digit', minute: '2-digit', hour12: false }) + ' · se actualiza solo';
      var lotes = Object.keys(lotesPorId).map(function (k) { return lotesPorId[k]; }).sort(function (a, b) { return b.numero - a.numero; });
      if (lotes.length) pintarLotes(lotes);
    }).catch(function (e) { if (!silencioso) aviso(e.message, true); });
  }
  function pintarPedidos(pedidos) {
    pedidosActuales = pedidos;
    var vigentes = new Set(pedidos.filter(seleccionable).map(function (p) { return p.id; }));
    seleccion.forEach(function (id) { if (!vigentes.has(id)) seleccion.delete(id); });

    var conteo = {};
    ORDEN_ETAPAS.forEach(function (e) { conteo[e] = 0; });
    pedidos.forEach(function (p) { conteo[etapa(p)]++; });
    if (filtroPedidos === null) filtroPedidos = conteo.revisar ? 'revisar' : 'todos';

    $('lote-pendientes').textContent = conteo.mandar_lab ? conteo.mandar_lab + ' pedido(s) pagados con impresas esperando lote.' : 'No hay pedidos con impresas esperando lote.';
    $('btn-armar-lote').disabled = !conteo.mandar_lab;
    $('cantidad-pedidos').textContent = '(' + pedidos.length + ')';
    var pagados = pedidos.filter(function (p) { return p.estado === 'pagado'; });
    var recaudado = pagados.reduce(function (a, p) { return a + p.total; }, 0);
    $('resumen-pedidos').textContent = pagados.length ? pagados.length + ' pagado(s) · ' + pesos(recaudado) + ' cobrados' : '';
    $('filtros-pedidos').hidden = pedidos.length === 0;

    pintarTablero(conteo, pedidos.length);
    pintarListaPedidos();
  }

  function pintarTablero(conteo, total) {
    var cont = $('tablero-pedidos');
    cont.textContent = '';
    cont.hidden = total === 0;
    var fichas = [['todos', 'Todos', total]].concat(ORDEN_ETAPAS.map(function (e) { return [e, ETAPAS[e].corto, conteo[e]]; }));
    fichas.forEach(function (f) {
      if (f[0] === 'cerrado' && !f[2] && filtroPedidos !== 'cerrado') return;
      var clase = 'ficha ' + (f[0] === 'todos' ? 'e-todos' : ETAPAS[f[0]].clase);
      if (filtroPedidos === f[0]) clase += ' activa';
      if (!f[2]) clase += ' vacia';
      if (f[0] === 'revisar' && f[2]) clase += ' urgente';
      var b = el('button', clase);
      b.type = 'button';
      b.setAttribute('aria-pressed', String(filtroPedidos === f[0]));
      b.appendChild(el('span', 'ficha-numero', String(f[2])));
      b.appendChild(el('span', 'ficha-texto', f[1]));
      b.addEventListener('click', function () {
        if (filtroPedidos !== f[0]) seleccion.clear(); // lo elegido en otra vista no se arrastra
        filtroPedidos = f[0];
        pintarPedidos(pedidosActuales);
      });
      cont.appendChild(b);
    });
  }

  function pedidosVisibles() {
    var q = normalizar(busquedaPedidos.trim());
    var qDigitos = busquedaPedidos.replace(/\D/g, '');
    return pedidosActuales.filter(function (p) {
      if (filtroPedidos && filtroPedidos !== 'todos' && etapa(p) !== filtroPedidos) return false;
      if (!q) return true;
      var texto = normalizar([p.numero, p.nino_nombre, p.nino_curso, p.comprador_nombre, p.comprador_email, p.comprador_whatsapp].join(' '));
      if (texto.indexOf(q) !== -1) return true;
      return qDigitos.length >= 4 && String(p.comprador_whatsapp || '').replace(/\D/g, '').indexOf(qDigitos) !== -1;
    });
  }

  function pintarListaPedidos() {
    var cont = $('lista-pedidos');
    cont.textContent = '';
    var visibles = pedidosVisibles();
    var vacio = $('sin-pedidos');
    if (!pedidosActuales.length) vacio.textContent = 'Todavía no hay pedidos.';
    else if (busquedaPedidos.trim()) vacio.textContent = 'No hay pedidos que coincidan con «' + busquedaPedidos.trim() + '»' + (filtroPedidos !== 'todos' ? ' en «' + ETAPAS[filtroPedidos].corto + '». Probá en «Todos».' : '.');
    else if (filtroPedidos === 'revisar') vacio.textContent = 'No hay comprobantes para revisar. Todo al día.';
    else vacio.textContent = 'No hay pedidos en «' + (ETAPAS[filtroPedidos] ? ETAPAS[filtroPedidos].corto : 'Todos') + '».';
    vacio.hidden = visibles.length > 0;
    visibles.forEach(function (p) { cont.appendChild(tarjetaPedido(p)); });
    actualizarBarraSeleccion();
    if (destacado) {
      var tarjeta = cont.querySelector('[data-id="' + destacado + '"]');
      if (tarjeta) tarjeta.classList.add('recien');
    }
  }

  function tarjetaPedido(p) {
    var et = etapa(p);
    var art = el('article', 'pedido ' + ETAPAS[et].clase);
    art.dataset.id = p.id;
    var abierto = abiertos.has(p.id);
    if (abierto) art.classList.add('abierto');

    var cab = el('div', 'pedido-cab');
    if (seleccionable(p)) {
      var etiqueta = el('label', 'pedido-check');
      etiqueta.title = 'Elegir para cambiar varios a la vez';
      var caja = document.createElement('input');
      caja.type = 'checkbox';
      caja.checked = seleccion.has(p.id);
      caja.setAttribute('aria-label', 'Elegir el pedido de ' + p.nino_nombre);
      caja.addEventListener('change', function () {
        if (caja.checked) seleccion.add(p.id); else seleccion.delete(p.id);
        art.classList.toggle('elegido', caja.checked);
        actualizarBarraSeleccion();
      });
      etiqueta.appendChild(caja);
      cab.appendChild(etiqueta);
      if (caja.checked) art.classList.add('elegido');
    }
    var quien = el('div', 'pedido-quien');
    quien.appendChild(el('strong', 'pedido-nino', p.nino_nombre));
    var sub = [];
    if (p.nino_curso) sub.push(p.nino_curso);
    sub.push('compró ' + p.comprador_nombre);
    quien.appendChild(el('span', 'sutil', sub.join(' · ')));
    cab.appendChild(quien);
    var monto = el('div', 'pedido-monto');
    monto.appendChild(el('strong', '', pesos(p.total)));
    monto.appendChild(el('span', 'sutil', p.medio_pago === 'mercadopago' ? 'Mercado Pago' : p.medio_pago === 'bonificado' ? 'Sin cargo · código ' + (p.codigo_descuento || '') : 'Transferencia')); // 27/10: código de descuento
    cab.appendChild(monto);
    var flecha = el('button', 'pedido-flecha', '▾');
    flecha.type = 'button';
    flecha.setAttribute('aria-expanded', String(abierto));
    flecha.setAttribute('aria-label', 'Ver el detalle del pedido');
    cab.appendChild(flecha);
    art.appendChild(cab);

    var linea = el('div', 'pedido-linea');
    linea.appendChild(el('span', 'estado-pedido', nombreEtapa(p, et)));
    linea.appendChild(el('span', 'sutil', p.numero + ' · ' + fechaHoraCorta(p.creado_en) + ' · ' + resumenItems(p.items)));
    art.appendChild(linea);

    var paso = pasoSiguiente(p, et);
    if (paso) art.appendChild(paso);

    var det = detallePedido(p, et);
    det.hidden = !abierto;
    art.appendChild(det);

    function alternar() {
      var ahora = det.hidden;
      det.hidden = !ahora;
      art.classList.toggle('abierto', ahora);
      flecha.setAttribute('aria-expanded', String(ahora));
      if (ahora) abiertos.add(p.id); else abiertos.delete(p.id);
    }
    cab.addEventListener('click', function (e) {
      if (e.target.closest('label, input, a')) return;
      alternar();
    });
    linea.addEventListener('click', alternar);
    return art;
  }

  function pasoSiguiente(p, et) {
    var caja = el('div', 'pedido-paso');
    var texto = el('p', 'paso-texto');
    var botones = el('div', 'paso-botones');
    caja.appendChild(texto);
    caja.appendChild(botones);
    var wa;
    switch (et) {
      case 'revisar':
        texto.textContent = 'Subió el comprobante el ' + fechaHoraCorta(p.comprobante_subido_en) + '. Fijate que te hayan entrado ' + pesos(p.total) + '.';
        botones.appendChild(botonAccion('Revisar comprobante y aprobar', function () { return abrirComprobante(p); }, 'verde'));
        break;
      case 'esperando':
        if (p.medio_pago === 'mercadopago') {
          texto.textContent = 'Está pagando con Mercado Pago. Se aprueba solo cuando se acredita.';
        } else {
          texto.textContent = 'Todavía no subió el comprobante de la transferencia' + (p.vence_en ? '. Vence el ' + fechaHoraCorta(p.vence_en) : '') + '.';
          wa = linkWhatsApp(p, 'Hola ' + primerNombre(p.comprador_nombre) + ', te escribo por el pedido ' + p.numero + ' de las fotos de ' + p.nino_nombre + ' (' + pesos(p.total) + '). ¿Pudiste hacer la transferencia? Podés subir el comprobante desde el link del pedido que te llegó por mail.', 'Recordarle por WhatsApp');
          if (wa) { wa.className = 'btn btn-chico btn-wa'; botones.appendChild(wa); }
        }
        // Mercado Pago se aprueba solo: no se ofrece aprobar a mano (queda en el detalle, con aviso).
        if (p.medio_pago !== 'mercadopago') botones.appendChild(botonAccion('Ya me llegó la plata: aprobar', function () { return aprobarPedido(p); }));
        break;
      case 'mandar_lab':
        texto.textContent = 'Pagado. Las copias impresas todavía no se mandaron al laboratorio.';
        botones.appendChild(botonAccion('Ir a armar el lote ↓', function () {
          $('bloque-lotes').scrollIntoView({ behavior: 'smooth', block: 'start' });
        }, 'primario'));
        break;
      case 'en_lab':
        texto.textContent = 'Está en el laboratorio. Cuando tengas las copias, avisale que las puede retirar.';
        botones.appendChild(botonAccion('Ya está impreso: avisar que retire', function () { return cambiarEntrega([p.id], 'listo_retiro'); }, 'primario'));
        break;
      case 'retiro':
        texto.textContent = 'Ya le avisamos por mail que puede retirar las copias.';
        wa = linkWhatsApp(p, 'Hola ' + primerNombre(p.comprador_nombre) + ', las fotos impresas de ' + p.nino_nombre + ' (pedido ' + p.numero + ') ya están listas para retirar' + (estado.evento && estado.evento.lugar_retiro ? ': ' + estado.evento.lugar_retiro : '') + '.', 'Avisarle por WhatsApp');
        if (wa) { wa.className = 'btn btn-chico btn-wa'; botones.appendChild(wa); }
        botones.appendChild(botonAccion('Marcar entregado', function () { return cambiarEntrega([p.id], 'entregado'); }, 'verde'));
        break;
      case 'completo': case 'digital':
        caja.className = 'pedido-paso paso-ok';
        texto.textContent = tieneImpresas(p)
          ? '✓ Entregado' + (p.fecha_entregado ? ' el ' + fechaHoraCorta(p.fecha_entregado) : '') + '.'
          : '✓ Sólo digital: las fotos le llegaron por mail.';
        break;
      default: // cerrado
        caja.className = 'pedido-paso paso-cerrado';
        if (p.estado === 'vencido') {
          texto.textContent = p.medio_pago === 'mercadopago'
            ? 'Venció: no completó el pago con Mercado Pago.'
            : 'Venció sin comprobante. Si igual te transfirió, lo podés aprobar.';
          if (p.medio_pago !== 'mercadopago') botones.appendChild(botonAccion('Me llegó la plata: aprobar igual', function () { return aprobarPedido(p); }));
        } else {
          texto.textContent = 'Pedido cancelado.';
        }
    }
    return caja;
  }

  function detallePedido(p, et) {
    var det = el('div', 'pedido-detalle');

    var bFotos = el('div', 'det-bloque');
    bFotos.appendChild(el('h4', '', 'Fotos pedidas'));
    var ul = el('ul', 'det-items');
    p.items.slice().sort(function (a, b) { return String(a.nombre).localeCompare(String(b.nombre), 'es', { numeric: true }); }).forEach(function (it) {
      var li = el('li');
      li.appendChild(el('span', 'det-archivo', it.nombre || '?'));
      li.appendChild(el('span', 'chip ' + (it.formato === 'digital' ? 'chip-off' : 'chip-lab'), it.formato === 'digital' ? 'Digital' : it.cantidad + ' × ' + it.formato));
      li.appendChild(el('span', 'det-precio', pesos(it.subtotal)));
      ul.appendChild(li);
    });
    if (Number(p.descuento_monto) > 0) { var liD = el('li'); liD.appendChild(el('span', 'det-archivo', 'Descuento · código ' + (p.codigo_descuento || '') + ' (' + (p.descuento_pct || 0) + '%)')); liD.appendChild(el('span', 'det-precio', '−' + pesos(p.descuento_monto))); ul.appendChild(liD); } var liTotal = el('li', 'det-total'); // 27/10/2026: descuento por código
    liTotal.appendChild(el('span', 'det-archivo', 'Total'));
    liTotal.appendChild(el('span', 'det-precio', pesos(p.total)));
    ul.appendChild(liTotal);
    bFotos.appendChild(ul);
    det.appendChild(bFotos);

    var bContacto = el('div', 'det-bloque');
    bContacto.appendChild(el('h4', '', 'Contacto'));
    bContacto.appendChild(el('p', 'det-nombre', p.comprador_nombre));
    var mail = el('a', 'det-link', '✉ ' + p.comprador_email);
    mail.href = 'mailto:' + p.comprador_email + '?subject=' + encodeURIComponent('Pedido ' + p.numero + ' — Retrato Escolar');
    bContacto.appendChild(mail);
    var wa = linkWhatsApp(p, 'Hola ' + primerNombre(p.comprador_nombre) + ', te escribo por tu pedido ' + p.numero + ' de Retrato Escolar.', 'WhatsApp ' + p.comprador_whatsapp);
    if (wa) { wa.className = 'det-link'; bContacto.appendChild(wa); }
    else bContacto.appendChild(el('p', 'sutil', 'WhatsApp ' + (p.comprador_whatsapp || '—')));

    var historia = el('ol', 'det-historia');
    function hito(textoHito, fecha, hecho) {
      var li = el('li', hecho ? 'hecho' : '');
      li.appendChild(el('span', '', textoHito));
      if (fecha) li.appendChild(el('span', 'sutil', fechaHoraCorta(fecha)));
      historia.appendChild(li);
    }
    hito('Hizo el pedido', p.creado_en, true);
    if (p.medio_pago === 'transferencia') hito(p.comprobante_subido_en ? 'Subió el comprobante' : 'Falta el comprobante', p.comprobante_subido_en, !!p.comprobante_subido_en);
    if (p.estado === 'pagado') hito('Pago acreditado', p.fecha_pago, true);
    else if (p.estado === 'vencido') hito('Venció', p.vence_en, false);
    else if (p.estado === 'cancelado') hito('Cancelado', null, false);
    if (p.estado === 'pagado' && tieneImpresas(p)) {
      var orden = ['en_laboratorio', 'listo_retiro', 'entregado'];
      var paso = orden.indexOf(p.estado_entrega);
      if (p.lote_id && paso < 0) paso = 0;
      hito('En el laboratorio' + (p.lote_id && lotesPorId[p.lote_id] ? ' (lote ' + lotesPorId[p.lote_id].numero + ')' : ''), null, paso >= 0);
      hito('Avisado para retirar', null, paso >= 1);
      hito('Entregado', p.fecha_entregado, paso >= 2);
    }
    bContacto.appendChild(el('h4', '', 'Seguimiento'));
    bContacto.appendChild(historia);
    det.appendChild(bContacto);

    var acc = el('div', 'det-acciones');
    if (p.comprobante_path && et !== 'revisar') {
      acc.appendChild(botonAccion('Ver comprobante', function () { return abrirComprobante(p); }));
    }
    if (p.estado === 'pagado') {
      acc.appendChild(botonAccion('Reenviar el mail con las fotos', function () {
        return api('POST', '/api/eventos/admin/pedidos/' + p.id + '/reenviar-mail').then(function () { aviso('Mail reenviado a ' + p.comprador_email + '.'); });
      }));
    }
    if (et === 'retiro') {
      acc.appendChild(botonAccion('Reenviar el aviso de "listo para retirar"', function () { return cambiarEntrega([p.id], 'listo_retiro', { reenviar: true }); }));
    }
    if ((p.estado === 'pendiente' || p.estado === 'vencido') && p.medio_pago === 'mercadopago') {
      acc.appendChild(botonAccion('Me pagó por otro medio: aprobar', function () { return aprobarPedido(p, false, true); }));
    }
    if (p.estado === 'pendiente' || p.estado === 'vencido') {
      acc.appendChild(botonAccion('Cancelar pedido', function () { return cancelarPedido(p); }, 'peligro'));
    }
    // 03/10: borrar pedidos (sobre todo de prueba). Los pagados piden escribir el número del pedido.
    if (!p.lote_id) {
      acc.appendChild(botonAccion('Borrar pedido', function () { return borrarPedido(p); }, 'peligro'));
    }
    if (acc.childNodes.length) det.appendChild(acc);
    return det;
  }
  function borrarPedido(p) {
    var ruta = '/api/eventos/admin/pedidos/' + p.id;
    function listo() { aviso('Pedido ' + p.numero + ' borrado.'); return cargarPedidos(); }
    if (p.estado === 'pagado' || (p.estado === 'pendiente' && p.comprobante_subido_en)) { // 14/10/2026: con comprobante también
      var escrito = window.prompt('El pedido ' + p.numero + ' de ' + p.nino_nombre + (p.estado === 'pagado' ? ' está PAGADO (' : ' ya subió el comprobante de la transferencia (') + pesos(p.total) + ').\nBorrarlo NO devuelve la plata: usalo sólo para pedidos de prueba.\n\nEscribí ' + p.numero + ' para borrarlo:');
      if (escrito === null) return Promise.resolve();
      if (escrito.trim().toUpperCase() !== String(p.numero).toUpperCase()) { aviso('El número no coincide: no se borró nada.', true); return Promise.resolve(); }
      return api('DELETE', ruta + '?confirmar=' + encodeURIComponent(p.numero)).then(listo);
    }
    return confirmar({
      titulo: 'Borrar el pedido de ' + p.nino_nombre,
      texto: 'El pedido ' + p.numero + ' (' + pesos(p.total) + ') se borra del todo, con su comprobante si tenía. No se puede deshacer.',
      ok: 'Sí, borrar', peligro: true,
    }).then(function (si) {
      if (!si) return;
      return api('DELETE', ruta).then(listo);
    });
  }

  function aprobarPedido(p, sinPreguntar, porOtroMedio) {
    var pregunta = sinPreguntar ? Promise.resolve(true) : confirmar({
      titulo: 'Aprobar el pago de ' + p.nino_nombre,
      texto: porOtroMedio
        ? 'Este pedido es con Mercado Pago y NO figura ningún pago acreditado ahí. Aprobalo sólo si te pagó por otro medio (efectivo o transferencia) y ya tenés la plata.'
        : '¿Te entraron ' + pesos(p.total) + ' de ' + p.comprador_nombre + '?',
      detalle: ['Pedido ' + p.numero + ' · ' + pesos(p.total) + ' · ' + resumenItems(p.items), 'Le llega el mail con las fotos a ' + p.comprador_email + '.'],
      ok: porOtroMedio ? 'Sí, ya me pagó' : 'Sí, aprobar',
      peligro: !!porOtroMedio
    });
    return pregunta.then(function (si) {
      if (!si) return false;
      return api('POST', '/api/eventos/admin/pedidos/' + p.id + '/aprobar', porOtroMedio ? { pagoPorOtroMedio: true } : {}).then(function () {
        aviso('✓ Pago de ' + p.nino_nombre + ' aprobado. Le mandamos el mail a ' + p.comprador_email + '.');
        marcarDestacado(p.id);
        return cargarPedidos().then(function () { return true; });
      });
    });
  }
  function cancelarPedido(p) {
    return confirmar({
      titulo: 'Cancelar el pedido de ' + p.nino_nombre,
      texto: 'El pedido ' + p.numero + ' (' + pesos(p.total) + ') queda cancelado y ya no se puede pagar. A la familia no le llega ningún mail.',
      ok: 'Sí, cancelar',
      peligro: true
    }).then(function (si) {
      if (!si) return;
      return api('POST', '/api/eventos/admin/pedidos/' + p.id + '/cancelar').then(function () { aviso('Pedido ' + p.numero + ' cancelado.'); return cargarPedidos(); });
    });
  }

  // Comprobante: se ve dentro del panel (si es imagen) con el botón de aprobar al lado.
  var aperturaComprobante = 0;
  function abrirComprobante(p) {
    var miApertura = ++aperturaComprobante;
    var dlg = $('dialogo-comprobante');
    var vista = $('comp-vista');
    var abrir = $('comp-abrir');
    var aprobar = $('comp-aprobar');
    var cancelar = $('comp-cancelar');
    var sinPagar = p.estado === 'pendiente' || p.estado === 'vencido';
    $('comp-titulo').textContent = 'Comprobante de ' + p.comprador_nombre;
    $('comp-monto').textContent = pesos(p.total);
    $('comp-monto-texto').textContent = sinPagar ? 'Tiene que haberte entrado' : 'Total del pedido';
    $('comp-datos').textContent = 'Pedido ' + p.numero + ' · para ' + p.nino_nombre + (p.comprobante_subido_en ? ' · subido el ' + fechaHoraCorta(p.comprobante_subido_en) : '');
    vista.textContent = '';
    vista.appendChild(el('p', 'sutil', 'Cargando el comprobante…'));
    abrir.hidden = true;
    aprobar.hidden = !sinPagar;
    cancelar.hidden = !sinPagar;
    aprobar.disabled = false;
    aprobar.onclick = function () {
      aprobar.disabled = true;
      aprobarPedido(p, true).then(function () { cerrarDialogo(dlg); }, function (e) { vista.appendChild(el('p', 'error', e.message)); aprobar.disabled = false; });
    };
    cancelar.onclick = function () { cerrarDialogo(dlg); cancelarPedido(p).catch(function (e) { aviso(e.message, true); }); };
    $('comp-cerrar').onclick = function () { cerrarDialogo(dlg); };
    dlg.onclose = function () { if (miApertura === aperturaComprobante) vista.textContent = ''; };
    abrirDialogo(dlg);
    abrir.removeAttribute('href');
    return api('GET', '/api/eventos/admin/pedidos/' + p.id + '/comprobante').then(function (d) {
      // Si mientras tanto se abrió el comprobante de OTRO pedido, esta respuesta se descarta
      // (si no, se vería la imagen de un pedido con el monto y el botón "Aprobar" de otro).
      if (miApertura !== aperturaComprobante) return;
      abrir.href = d.url;
      abrir.hidden = false;
      vista.textContent = '';
      var ext = String(p.comprobante_path || '').split('.').pop().toLowerCase();
      if (['jpg', 'jpeg', 'png', 'webp', 'gif'].indexOf(ext) !== -1) {
        var img = el('img');
        img.alt = 'Comprobante de ' + p.comprador_nombre;
        img.onerror = function () {
          vista.textContent = '';
          vista.appendChild(el('p', 'comp-aviso', 'No se puede mostrar acá. Tocá «Abrir en otra pestaña» para verlo.'));
        };
        img.src = d.url;
        vista.appendChild(img);
      } else {
        vista.appendChild(el('p', 'comp-aviso', 'El comprobante es ' + (ext === 'pdf' ? 'un PDF' : 'un archivo ' + ext.toUpperCase()) + '. Tocá «Abrir en otra pestaña» para verlo.'));
      }
    }).catch(function (e) {
      if (miApertura !== aperturaComprobante) return;
      vista.textContent = '';
      vista.appendChild(el('p', 'error', e.message));
    });
  }

  $('btn-recargar-pedidos').addEventListener('click', function () { cargarPedidos(); cargarLotes(); });
  $('buscar-pedido').addEventListener('input', function (e) {
    busquedaPedidos = e.target.value;
    seleccion.clear();
    pintarListaPedidos();
  });
  $('sel-todos').addEventListener('change', function (e) {
    var posibles = pedidosVisibles().filter(seleccionable);
    if (!posibles.length) {
      // En esta vista no hay pedidos para elegir: se pasa a "Todos" y se eligen los pagados con impresas.
      posibles = pedidosActuales.filter(seleccionable);
      filtroPedidos = 'todos';
      busquedaPedidos = '';
      $('buscar-pedido').value = '';
    }
    posibles.forEach(function (p) {
      if (e.target.checked) seleccion.add(p.id); else seleccion.delete(p.id);
    });
    pintarPedidos(pedidosActuales);
  });
  $('sel-limpiar').addEventListener('click', function () {
    seleccion.clear();
    pintarListaPedidos();
  });
  // Se actualiza solo cada minuto (sin molestar si hay algo abierto): los pedidos del evento abierto y (11/10) las tarjetas de la lista.
  setInterval(function () {
    if (estado.subiendo || document.visibilityState !== 'visible' || hayDialogoAbierto()) return;
    if (!$('vista-lista').hidden) return void api('GET', '/api/eventos/admin/eventos').then(function (d) { if (!$('vista-lista').hidden) { estado.eventos = d.eventos; pintarLista(); } }).catch(function () { /* reintenta al minuto */ });
    if ($('vista-evento').hidden || !estado.evento) return;
    cargarPedidos(true);
  }, 60000);

  // Auditoría 03/10 noche: una selección grande se manda en tandas de 20 pedidos, una detrás de otra (un
  // solo pedido enorme con mails podía pasar los 60 s del servidor). `enBloque` evita que la última tanda
  // de un solo pedido se tome como "reenviar el aviso a uno". Si una tanda falla, se frena y se informa.
  var TANDA_ENTREGA = 20;
  // 05/10: `reenviar` (sólo el botón explícito «Reenviar el aviso») va en el PRIMER intento; los reintentos
  // automáticos no lo mandan, así el servidor no repite el mail si la primera llamada ya lo mandó.
  function mandarEntregaEnTandas(ids, estadoNuevo, reenviar) {
    var tandas = [];
    for (var i = 0; i < ids.length; i += TANDA_ENTREGA) tandas.push(ids.slice(i, i + TANDA_ENTREGA));
    var salida = { resultados: [], mailFallidos: [], cortado: null, faltan: 0 };
    var enBloque = ids.length > 1;
    var hechos = 0;
    return tandas.reduce(function (cadena, tanda) {
      return cadena.then(function () {
        if (salida.cortado) { salida.faltan += tanda.length; return; }
        if (tandas.length > 1) aviso('Procesando ' + hechos + ' de ' + ids.length + ' pedidos… no cierres esta pestaña.');
        var intentos = 0;
        return conReintentos(function () {
          var primero = intentos++ === 0;
          return api('POST', '/api/eventos/admin/pedidos/entrega', { ids: tanda, estado: estadoNuevo, enBloque: enBloque, reenviar: reenviar === true && primero }, 58000);
        }, [3000, 8000]).then(function (d) {
          salida.resultados = salida.resultados.concat(d.resultados || []);
          salida.mailFallidos = salida.mailFallidos.concat(d.mailFallidos || []);
          hechos += tanda.length;
        }, function (e) {
          if (!salida.resultados.length && tandas.length === 1) throw e; // nada procesado: error común
          salida.cortado = e.message;
          salida.faltan += tanda.length;
        });
      });
    }, Promise.resolve()).then(function () { return salida; });
  }

  function cambiarEntrega(ids, estadoNuevo, opciones) {
    if (!ids.length) return Promise.resolve();
    var reenviar = Boolean(opciones && opciones.reenviar); // 05/10: sólo desde «Reenviar el aviso»
    var pedidos = ids.map(function (id) { return pedidosActuales.filter(function (p) { return p.id === id; })[0]; }).filter(Boolean);
    var uno = pedidos.length === 1 ? pedidos[0] : null;
    var lugar = estado.evento && estado.evento.lugar_retiro;
    var textos = {
      listo_retiro: {
        titulo: uno ? 'Avisar a ' + uno.comprador_nombre + ' que retire' : 'Avisar a ' + ids.length + ' familias que retiren',
        texto: (uno ? (uno.estado_entrega === 'listo_retiro' ? 'Se le reenvía' : 'Le llega') : 'A cada familia le llega') + ' un mail diciendo que las copias impresas están listas' + (lugar ? ' para retirar en: ' + lugar + '.' : '. (No cargaste el lugar de retiro en los datos del evento.)') + (uno ? '' : ' A las que ya estaban avisadas no se les reenvía.'),
        ok: uno ? 'Sí, avisar' : 'Sí, avisar a ' + ids.length
      },
      entregado: {
        titulo: uno ? 'Marcar entregado el pedido de ' + uno.nino_nombre : 'Marcar ' + ids.length + ' pedidos como entregados',
        texto: 'Ya se llevaron las copias impresas.',
        ok: 'Sí, entregado'
      }
    };
    var t = textos[estadoNuevo];
    var detalle = uno ? [] : pedidos.slice(0, 8).map(function (p) { return p.nino_nombre + ' · ' + p.numero; });
    if (pedidos.length > 8) detalle.push('y ' + (pedidos.length - 8) + ' más');
    return confirmar({ titulo: t.titulo, texto: t.texto, detalle: detalle, ok: t.ok }).then(function (si) {
      if (!si) return;
      return mandarEntregaEnTandas(ids, estadoNuevo, reenviar).then(function (d) {
        // Auditoría 03/10 noche: los pedidos cuyo mail no salió quedan sin avisar (el servidor los deja como
        // estaban) y se listan con su número para volver a intentarlo.
        var ok = d.resultados.filter(function (r) { return r.ok && !r.omitido && r.mail !== false; });
        var omitidos = d.resultados.filter(function (r) { return r.ok && r.omitido; }).length;
        var recien = d.resultados.some(function (r) { return r.recienAvisado; }); // 05/10
        var mal = d.resultados.filter(function (r) { return !r.ok; });
        var sinMail = d.mailFallidos;
        var texto = (ok.length === 1 && uno ? '✓ Pedido de ' + uno.nino_nombre + ' actualizado.' : '✓ ' + ok.length + ' actualizado(s).') +
          (omitidos ? ' ' + omitidos + ' ya estaban así (no se repitió el mail).' : '') +
          (recien ? ' El aviso ya se mandó hace menos de 2 minutos: no se repitió. Si querés mandarlo igual, usá «Reenviar el aviso» en el pedido.' : '') +
          (sinMail.length ? ' ⚠ No salió el mail de ' + sinMail.join(', ') + ': quedaron sin avisar, volvé a tocar «Avisar».' : '') +
          (mal.length ? ' No se pudo: ' + mal.map(function (r) { return r.error; }).join(' · ') : '') +
          (d.cortado ? ' ⚠ Se cortó a mitad de camino (' + d.cortado + '): ' + d.faltan + ' pedido(s) no se procesaron, volvé a intentar.' : '');
        if (sinMail.length || d.cortado) {
          // Mensaje largo e importante: también queda en un diálogo para que no se pierda.
          confirmar({ titulo: 'Atención', texto: texto, ok: 'Entendido' });
        }
        aviso(texto, mal.length > 0 || sinMail.length > 0 || !!d.cortado);
        ids.forEach(function (id) { seleccion.delete(id); });
        if (uno) marcarDestacado(uno.id);
        return Promise.all([cargarPedidos(), cargarLotes()]);
      });
    });
  }
  document.querySelectorAll('[data-entrega]').forEach(function (b) {
    b.addEventListener('click', function () {
      // Sólo los elegidos que se están viendo (nunca pedidos ocultos por el filtro o la búsqueda).
      var visibles = {};
      pedidosVisibles().forEach(function (p) { visibles[p.id] = true; });
      var ids = Array.from(seleccion).filter(function (id) { return visibles[id]; });
      b.disabled = true;
      cambiarEntrega(ids, b.dataset.entrega).catch(function (e) { aviso(e.message, true); }).then(function () { b.disabled = false; });
    });
  });

  function descargarArchivo(ruta, nombre) {
    return fetch(ruta, { headers: { Authorization: 'Bearer ' + (leerToken() || '') } }).then(function (r) {
      if (r.status === 401) { borrarToken(); mostrarVista('login'); throw new Error('Sesión vencida'); }
      if (!r.ok) return r.json().catch(function () { return {}; }).then(function (d) { throw new Error(d.error || 'No se pudo descargar'); });
      return r.blob();
    }).then(function (blob) {
      var a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = nombre;
      document.body.appendChild(a);
      a.click();
      setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 2000);
    });
  }
  $('btn-qr').addEventListener('click', function () {
    var b = this;
    b.disabled = true;
    descargarArchivo('/api/eventos/admin/eventos/' + estado.evento.id + '/qr', 'QR-' + estado.evento.codigo + '.png')
      .catch(function (e) { aviso(e.message, true); }).then(function () { b.disabled = false; });
  });
  $('btn-planilla').addEventListener('click', function () {
    var b = this;
    b.disabled = true;
    descargarArchivo('/api/eventos/admin/eventos/' + estado.evento.id + '/planilla-entregas', 'entregas-' + estado.evento.codigo + '.xlsx')
      .catch(function (e) { aviso(e.message, true); }).then(function () { b.disabled = false; });
  });

  // ---------------- Lotes ----------------
  var lotesPorId = {};
  var ESTADO_LOTE = { armado: ['Armado — falta que el lab lo descargue', 'chip-pend'], en_laboratorio: ['El laboratorio lo descargó', 'chip-lab'], terminado: ['Terminado por el laboratorio', 'chip-ok'] };
  function cargarLotes() {
    if (!estado.evento) return;
    var eventoId = estado.evento.id;
    return api('GET', '/api/eventos/admin/eventos/' + eventoId + '/lotes').then(function (d) {
      if (!estado.evento || estado.evento.id !== eventoId) return; // llegó tarde: ya se abrió otro evento
      lotesPorId = {};
      d.lotes.forEach(function (l) { lotesPorId[l.id] = l; });
      pintarLotes(d.lotes);
      if (pedidosActuales.length) pintarPedidos(pedidosActuales);
    }).catch(function (e) { aviso(e.message, true); });
  }
  function pintarLotes(lotes) {
    var cont = $('lista-lotes');
    cont.textContent = '';
    if (!lotes.length) cont.appendChild(el('p', 'sutil', 'Todavía no armaste ningún lote.'));
    lotes.forEach(function (l) {
      var fila = el('div', 'lote');
      var info = el('div', 'info');
      info.appendChild(el('strong', '', 'Lote ' + l.numero));
      var est = ESTADO_LOTE[l.estado] || [l.estado, 'chip-off'];
      info.appendChild(el('span', 'chip ' + est[1], est[0]));
      info.appendChild(el('div', 'sutil', fechaHoraCorta(l.creado_en) + ' · ' + l.pedidos + ' pedido(s) · 15x21: ' + l.copias15x21 + ' · 20x30: ' + l.copias20x30 + ' · ' + l.listos + ' avisado(s)'));
      if (l.anulados) info.appendChild(el('div', 'error', '⚠ ' + l.anulados + ' pedido(s) de este lote se anularon (devolución): no hay que imprimirlos ni entregarlos.'));
      fila.appendChild(info);
      var abrir = el('a', 'btn btn-chico', 'Abrir (ZIP)');
      abrir.href = '/laboratorio-eventos';
      abrir.target = '_blank';
      abrir.rel = 'noopener';
      fila.appendChild(abrir);
      fila.appendChild(botonAccion('Excel del lote', function () {
        return descargarArchivo('/api/eventos/lab/lotes/' + l.id + '/excel', 'lote-' + estado.evento.codigo + '-' + l.numero + '.xlsx');
      }));
      var porAvisar = pedidosActuales.filter(function (p) { return p.lote_id === l.id && p.estado_entrega === 'en_laboratorio'; }).map(function (p) { return p.id; });
      if (porAvisar.length) {
        fila.appendChild(botonAccion('Avisar "listo para retirar" (' + porAvisar.length + ')', function () { return cambiarEntrega(porAvisar, 'listo_retiro'); }));
      }
      cont.appendChild(fila);
    });
  }
  $('btn-armar-lote').addEventListener('click', function () {
    var b = this;
    var pendientes = pedidosActuales.filter(function (p) { return etapa(p) === 'mandar_lab'; });
    b.disabled = true;
    confirmar({
      titulo: 'Armar un lote nuevo',
      texto: 'Entran todos los pedidos pagados con impresas que todavía no se mandaron. Pasan a «En laboratorio» y el laboratorio los ve en su panel.',
      detalle: pendientes.slice(0, 8).map(function (p) { return p.nino_nombre + ' · ' + resumenItems(p.items.filter(function (it) { return it.formato !== 'digital'; })); })
        .concat(pendientes.length > 8 ? ['y ' + (pendientes.length - 8) + ' más'] : []),
      ok: 'Sí, armar el lote'
    }).then(function (si) {
      if (!si) return;
      return api('POST', '/api/eventos/admin/eventos/' + estado.evento.id + '/lotes').then(function (d) {
        aviso('✓ Lote ' + d.lote.numero + ' armado con ' + d.pedidos + ' pedido(s).');
        return Promise.all([cargarPedidos(), cargarLotes()]);
      });
    }).catch(function (e) { aviso(e.message, true); }).then(function () { b.disabled = false; });
  });

  // ---------------- Arranque ----------------
  if (leerToken()) cargarLista(); else mostrarVista('login');
})();
