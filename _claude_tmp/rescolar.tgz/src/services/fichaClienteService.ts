import { fetchAdminAutenticado } from './adminAuthService';

/** Ficha del cliente (19/10/2026): todo lo que hay de una familia, por email, teléfono y/o número de pedido. */
export interface FichaInscripcion {
  id: string;
  tutor: string | null;
  dniTutor: string | null;
  email: string | null;
  telefono: string | null;
  colegio: string | null;
  estado: string;
  codigo: string | null;
  emailCodigoEnviado: boolean;
  accesoConfirmadoAt: string | null;
  fotoHermanos: boolean;
  fechaAprobacion: string | null;
  createdAt: string | null;
}

export interface FichaHijo {
  nombre: string;
  dni: string | null;
  colegio: string | null;
  inscripcionId: string;
  curso: { grado: string | null; division: string | null; turno: string | null };
  cursoNomina: { grado: string; division: string; turno: string | null } | null;
  enNomina: boolean;
  coincideConNomina: boolean;
  fotosPublicadas: number | null;
  pagado: boolean;
  pedidos: number;
}

export interface FichaPedido {
  id: string;
  numero: string | null;
  alumno: string | null;
  colegio: string | null;
  curso: string;
  kit: string | null;
  carpetasImpresas: number | null;
  copiasExtras: number;
  fotosElegidas: number;
  seleccionPendiente: boolean;
  total: number;
  estado: string;
  metodoPago: string | null;
  createdAt: string | null;
  pagadoAt: string | null;
  aprobadoManual: boolean;
  comprobante: boolean;
  transferenciaVencida: boolean;
  canceladoDefinitivo: boolean;
  estadoLab: string | null;
  entregadoAt: string | null;
  hdEnviado: boolean;
  hdEnviadoAt: string | null;
  descargasHd: number;
  archivado: boolean;
  enEspera: boolean;
  notaEspera: string | null;
  esMejora: boolean;
  soloPorNumero: boolean;
}

export interface FichaPedidoEvento {
  id: string;
  numero: string | null;
  evento: string | null;
  comprador: string | null;
  nino: string | null;
  curso: string | null;
  total: number;
  medioPago: string | null;
  estado: string;
  estadoEntrega: string | null;
  fechaPago: string | null;
  entregadoAt: string | null;
  digitalesEnviados: boolean;
  createdAt: string | null;
}

export interface FichaCliente {
  encontrado: boolean;
  buscado: { email: string | null; telefono: string | null; pedido: string | null };
  inscripciones: FichaInscripcion[];
  familias: { id: string; nombre: string | null; email: string | null; whatsapp: string | null }[];
  hijos: FichaHijo[];
  pedidos: FichaPedido[];
  pedidoMencionado: { numero: string; encontrado: boolean; deEstaFamilia: boolean } | null;
  pedidosEventos: FichaPedidoEvento[];
  observaciones: { id: string; alumno: string | null; curso: string; tipo: string; detalle: string | null; createdAt: string }[];
  consultas: { id: string; asunto: string; estado: string; origen: string | null; createdAt: string }[];
}

export async function obtenerFichaClienteAdmin(criterios: { email?: string | null; telefono?: string | null; pedido?: string | null }): Promise<FichaCliente> {
  const params = new URLSearchParams();
  if (criterios.email?.trim()) params.set('email', criterios.email.trim());
  if (criterios.telefono?.trim()) params.set('telefono', criterios.telefono.trim());
  if (criterios.pedido?.trim()) params.set('pedido', criterios.pedido.trim());
  const response = await fetchAdminAutenticado(`/api/admin/ficha-cliente?${params.toString()}`);
  const data = await response.json().catch(() => ({}));
  if (!response.ok || !data.success) throw new Error(data.error || 'No se pudo cargar la ficha del cliente.');
  return data.ficha as FichaCliente;
}
