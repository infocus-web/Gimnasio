/**
 * Servicio de envío automático de correos con enlaces HD y comprobantes vía Resend
 */
import { fetchAdminAutenticado } from './adminAuthService';
import { obtenerResumenPedidoEscaneo } from './escaneoPedidoService';
import { conProcesoEnCurso } from '../utils/procesoEnCurso';

export interface DatosEnvioFotosHD {
  to: string;
  tutorNombre?: string;
  alumnoNombre: string;
  colegioNombre: string;
  cursoCodigo: string;
  pedidoId: string;
  // Auditoría 2026-09-20 (bug real: el link HD nunca se grababa en Supabase después de un
  // reenvío manual): "pedidoId" de acá arriba es el ID legible (IFS-2026-XXXX) que se muestra
  // en el correo, no sirve para encontrar la fila. Este campo aparte manda el UUID real de
  // Supabase para que el servidor pueda guardar el resultado del envío contra el pedido correcto.
  pedidoSupabaseId?: string;
  kitNombre: string;
  total: number;
  linkDescargaHD: string;
  whatsappContacto?: string;
  esImpreso?: boolean;
  /** 14/10/2026: reenvío manual a propósito (sale aunque ya se haya mandado el link HD). */
  forzar?: boolean;
  /** 14/10/2026: reintento masivo: sin link HD no se manda el aviso «en breve» (cuenta como fallido). */
  soloConLink?: boolean;
}

// Alias para compatibilidad
export type EnviarFotosEmailParams = DatosEnvioFotosHD;

export interface RespuestaEnvioEmail {
  success: boolean;
  messageId?: string;
  from?: string;
  warning?: string;
  error?: string;
  simulated?: boolean;
  /** 14/10/2026: no se mandó porque no correspondía (ya tenía el link HD, reserva o mejora); `motivo` dice por qué. */
  omitido?: boolean;
  yaEnviado?: boolean;
  motivo?: string;
}

export interface EstadoResend {
  configured: boolean;
  fromEmail: string;
  maskedKey: string | null;
  domain: string;
}

export type TipoActualizacionPedido = 'en_produccion' | 'listo_retiro';

export interface DestinatarioActualizacionPedido {
  // Auditoría 2026-09-18 (reporte de Pablo): "pedidoId" tiene que seguir siendo el UUID real de
  // Supabase porque el servidor lo usa para encontrar la fila (.eq('id', pedidoId)) — pero ese
  // mismo valor se estaba mostrando tal cual en el email al cliente ("Pedido: ef97bafb-6f4b-..."),
  // en vez del número de pedido legible (IFS-2026-XXXX) que se usa en todos los demás correos.
  // Se agrega "pedidoFriendlyId" aparte, solo para mostrar, sin tocar el que usa la búsqueda.
  pedidoId: string;
  pedidoFriendlyId?: string;
  to: string;
  tutorNombre: string;
  alumnoNombre: string;
  colegioNombre: string;
}

export interface ResultadoActualizacionPedidos {
  success: boolean;
  enviados: number;
  fallidos: number;
  errores?: string[];
  error?: string;
  /** Avisos que no se mandaron por ser inválidos o estar bloqueados (en espera, sin pagar…). */
  omitidos?: number;
  /** Ids que quedaron sin procesar (corte por tiempo o por tope de vueltas). */
  restantes?: string[];
  /** 14/10/2026: pedidos que YA estaban en esa etapa y no se volvieron a avisar (sin `reenvio`). */
  yaAvisados?: number;
  // Auditoría 2026-09-20: estado real que quedó guardado en Supabase para cada pedido después
  // del envío (fecha de primer envío incluida) — permite actualizar el panel al instante, sin
  // esperar a la próxima recarga de la lista de pedidos.
  resultados?: {
    pedidoId: string;
    estadoLab: 'en_produccion' | 'listo_retiro';
    fechaEnvioProduccion?: string | null;
    fechaEnvioListoRetiro?: string | null;
  }[];
}

/**
 * Auditoría 03/10 (alto 18): el servidor procesa con un presupuesto de tiempo y devuelve en
 * `restantes` los ids que no alcanzó a avisar (antes cortaba en 100 en silencio). Acá se le
 * vuelve a mandar sólo eso hasta que no quede nada (con tope de vueltas) y se suma el total.
 */
// 14/10/2026 (auditoría: avisos duplicados tras un corte o con dos pestañas): `reenvio` sólo va en true desde
// el botón «Reenviar …»; sin eso el servidor saltea los pedidos que ya están en esa etapa (`yaAvisados`).
export function enviarActualizacionPedidos(
  tipo: TipoActualizacionPedido,
  destinatarios: DestinatarioActualizacionPedido[],
  onProgreso?: (avance: { enviados: number; pendientes: number; total: number }) => void,
  opciones: { reenvio?: boolean } = {}
): Promise<ResultadoActualizacionPedidos> {
  // 14/10/2026: queda anotado como proceso en curso (pregunta antes de cerrar la pestaña; no se recarga solo).
  return conProcesoEnCurso('Avisos de etapa del laboratorio', () => enviarActualizacionPedidosEnVueltas(tipo, destinatarios, onProgreso, opciones));
}

async function enviarActualizacionPedidosEnVueltas(
  tipo: TipoActualizacionPedido,
  destinatarios: DestinatarioActualizacionPedido[],
  onProgreso: ((avance: { enviados: number; pendientes: number; total: number }) => void) | undefined,
  opciones: { reenvio?: boolean }
): Promise<ResultadoActualizacionPedidos> {
  const total: ResultadoActualizacionPedidos & { omitidos: number; restantes: string[]; yaAvisados: number } = {
    success: true,
    enviados: 0,
    fallidos: 0,
    omitidos: 0,
    errores: [],
    resultados: [],
    restantes: [],
    yaAvisados: 0,
  };
  let pendientes = destinatarios;
  const MAX_VUELTAS = 40;
  for (let vuelta = 1; vuelta <= MAX_VUELTAS && pendientes.length > 0; vuelta++) {
    let data: any;
    try {
      const res = await fetchAdminAutenticado('/api/admin/pedidos/notificar-estado', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ tipo, destinatarios: pendientes, ...(opciones.reenvio ? { reenvio: true } : {}) }),
      });
      data = await res.json().catch(() => ({}));
      if (!res.ok && !(Array.isArray(data?.restantes) && data.restantes.length > 0)) {
        // Auditoría 03/10 (2ª vuelta): se copian `errores` y `omitidos` del servidor, así el panel
        // muestra el motivo de cada pedido (p. ej. "todavía no está en un lote del laboratorio").
        const omitidosRespuesta = Math.min(Number(data?.omitidos) || 0, pendientes.length);
        const erroresRespuesta: string[] = Array.isArray(data?.errores) ? data.errores.map(String) : [];
        return {
          ...total,
          success: false,
          omitidos: total.omitidos + omitidosRespuesta,
          errores: [...(total.errores || []), ...erroresRespuesta],
          fallidos: total.fallidos + (pendientes.length - omitidosRespuesta),
          // Los omitidos por una regla no se reintentan solos (volverían a frenarse igual).
          restantes: omitidosRespuesta >= pendientes.length ? [] : pendientes.map((d) => d.pedidoId),
          error: `${data?.error || 'No se pudieron enviar los emails.'}${total.enviados > 0 ? ` (antes del corte se enviaron ${total.enviados})` : ''}`,
        };
      }
    } catch (error: any) {
      // 14/10/2026: se perdió la respuesta, pero el servidor pudo haber avisado igual. Se releen esos pedidos y
      // los que ya quedaron en esta etapa no se dejan tildados (volver a tocar el botón los duplicaría).
      const sinConfirmar: string[] = [];
      for (const d of pendientes) {
        const r = await obtenerResumenPedidoEscaneo(d.pedidoId);
        if (r.success && r.pedido?.estadoLab === tipo) {
          total.yaAvisados += 1;
          total.resultados!.push({ pedidoId: d.pedidoId, estadoLab: tipo, fechaEnvioProduccion: r.pedido.fechaEnvioProduccion, fechaEnvioListoRetiro: r.pedido.fechaEnvioListoRetiro });
        } else sinConfirmar.push(d.pedidoId);
      }
      return {
        ...total,
        success: false,
        fallidos: total.fallidos + sinConfirmar.length,
        restantes: sinConfirmar,
        error: `${error?.message || 'Error de red al enviar los emails.'}${total.enviados > 0 ? ` (antes del corte se enviaron ${total.enviados})` : ''}`,
      };
    }
    total.enviados += Number(data?.enviados) || 0;
    total.fallidos += Number(data?.fallidos) || 0;
    total.omitidos += Number(data?.omitidos) || 0;
    total.yaAvisados += Number(data?.yaAvisados) || 0;
    if (Array.isArray(data?.errores)) total.errores!.push(...data.errores);
    if (Array.isArray(data?.resultados)) total.resultados!.push(...data.resultados);
    if (data?.success === false) total.success = false;
    // Servidor anterior (sin `restantes`): una sola vuelta, como antes.
    const restantes = new Set<string>(Array.isArray(data?.restantes) ? data.restantes.map(String) : []);
    const siguientes = pendientes.filter((d) => restantes.has(String(d.pedidoId)));
    // Si el servidor no avanzó nada en esta vuelta, se corta para no quedar en un bucle.
    if (siguientes.length >= pendientes.length && (Number(data?.enviados) || 0) === 0 && (Number(data?.omitidos) || 0) === 0 && (Number(data?.yaAvisados) || 0) === 0) {
      pendientes = siguientes;
      break;
    }
    pendientes = siguientes;
    onProgreso?.({ enviados: total.enviados, pendientes: pendientes.length, total: destinatarios.length });
  }
  if (pendientes.length > 0) {
    total.success = false;
    total.restantes = pendientes.map((d) => d.pedidoId);
    total.error = `Quedaron ${pendientes.length} aviso(s) sin mandar (el servidor no llegó a tiempo). Volvé a tocar el botón para esos pedidos.`;
  }
  return total;
}

/**
 * Consulta el estado de configuración de Resend en el servidor. Requiere sesión de
 * administrador desde la auditoría 2026-09-09 (revisión a fondo): esta ruta devolvía un
 * fragmento real de la clave de Resend a cualquier visitante, sin pedir ningún login.
 */
export async function consultarEstadoResend(): Promise<EstadoResend> {
  try {
    const res = await fetchAdminAutenticado('/api/resend/status');
    if (!res.ok) {
      throw new Error(`HTTP ${res.status}`);
    }
    return await res.json();
  } catch {
    return {
      configured: false,
      fromEmail: 'Retrato Escolar <fotos@retratoescolar.com.ar>',
      maskedKey: null,
      domain: 'retratoescolar.com.ar'
    };
  }
}

/**
 * Envía automáticamente las fotografías en HD y el comprobante por correo a la familia
 */
export async function enviarFotosPorEmail(datos: DatosEnvioFotosHD): Promise<RespuestaEnvioEmail> {
  try {
    if (!datos.to || !datos.to.includes('@')) {
      return { success: false, error: 'Email inválido o vacío' };
    }

    // Requiere sesión de administrador desde este momento (ver server.ts): esta ruta solo la
    // usa el panel admin para reenviar el correo de fotos HD manualmente.
    const res = await fetchAdminAutenticado('/api/enviar-fotos-hd', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(datos)
    });

    const data = await res.json();
    return data;
  } catch (error: any) {
    console.warn('Fallo al contactar el servicio de email:', error);
    return {
      success: false,
      error: error?.message || 'Error de red al intentar enviar el correo'
    };
  }
}

/**
 * Envía un correo de prueba a una casilla para verificar que el dominio retratoescolar.com.ar funcione
 */
export async function enviarEmailPruebaResend(emailDestino: string): Promise<RespuestaEnvioEmail> {
  try {
    // Requiere sesión de administrador desde este momento (ver server.ts): es una herramienta
    // de diagnóstico del panel, no algo que deba poder disparar cualquier visitante.
    const res = await fetchAdminAutenticado('/api/resend/test', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ to: emailDestino })
    });

    const data = await res.json();
    return data;
  } catch (error: any) {
    return {
      success: false,
      error: error?.message || 'Error al conectar con el servidor de pruebas'
    };
  }
}

/**
 * 14/10/2026 (auditoría, «Reintentar los N» HD): antes del bucle se releen los pedidos en el servidor. Los que
 * ya tienen el link HD enviado (otra pestaña, o un intento cuya respuesta se perdió) se sacan de la lista; a
 * los demás se les pasa el link que ya tenga guardado el servidor (así no se vuelve a armar el .zip).
 */
export async function releerPedidosHDPendientes<T extends { id: string; supabaseId?: string; linkDescargaHD?: string }>(
  pedidos: T[]
): Promise<{ pendientes: T[]; yaEnviados: string[] }> {
  const pendientes: T[] = [];
  const yaEnviados: string[] = [];
  for (const pedido of pedidos) {
    const r = pedido.supabaseId ? await obtenerResumenPedidoEscaneo(pedido.supabaseId) : null;
    if (r?.success && r.pedido?.emailEnviado && r.pedido.linkDescargaHD) yaEnviados.push(pedido.id);
    else pendientes.push(r?.success && r.pedido?.linkDescargaHD ? { ...pedido, linkDescargaHD: r.pedido.linkDescargaHD } : pedido);
  }
  return { pendientes, yaEnviados };
}
