/**
 * Panel propio del colegio (10/10/2026, pedido de Pablo; plan en el proyecto: claude/panel-colegio-plan.md).
 * Página retratoescolar.com.ar/colegio?c=<codigo>: la secretaría entra con el PIN de 6 números que le da
 * Pablo. La sesión dura 7 días en ese dispositivo. Acá también están las llamadas del panel de Pablo para
 * generar el PIN, prender/apagar el acceso y cargar las fechas de la campaña.
 */
import { fetchConTimeout } from '../utils/fetchConTimeout';
import { fetchAdminAutenticado } from './adminAuthService';

const CLAVE_SESION = 'colegio_sesion_v1';
const CLAVE_VISTA_PREVIA = 'colegio_vista_previa_v1';

export interface SesionColegio {
  token: string;
  codigo: string;
  colegioNombre: string;
  venceAt: number;
  /** Vista previa de Pablo (desde su panel): sólo lectura, sin PIN ni convenio, dura 2 horas. */
  vistaPrevia?: boolean;
}

export class SesionColegioVencida extends Error {
  /** Si el colegio todavía no firmó el convenio: link para firmarlo (el panel se habilita al firmar). */
  linkConvenio: string | null;
  constructor(mensaje = 'La sesión venció. Volvé a entrar con el PIN.', linkConvenio: string | null = null) {
    super(mensaje);
    this.name = 'SesionColegioVencida';
    this.linkConvenio = linkConvenio;
  }
}

export interface FechasCampana {
  tomaFotos: string | null;
  cierrePedidos: string | null;
  entregaKits: string | null;
}

/** Lo que llega al entrar: sólo la comisión del colegio (pedido de Pablo, 10/10). */
export interface ComisionColegio {
  periodo: { desde: string; hasta: string };
  participacion: number;
}

/** El detalle del cálculo: sólo si el colegio lo pide (menú «⋯» de la tarjeta de la comisión). */
export interface DetalleComisionColegio extends ComisionColegio {
  porcentaje: number;
  pedidos: number;
  venta: number;
  costoLaboratorio: number;
  comisionesCobro: number;
  impuestos: number;
  /** Gastos de operación de la plataforma (convenio 2026-10-30, OCTAVA BIS iv); 0 si no corresponde. */
  gastosPlataforma: number;
  gananciaNeta: number;
  pedidosConFotosPendientes: number;
  detalle: { pedido: string; curso: string; pagado: string | null; venta: number; gananciaNeta: number }[];
}

export interface AvanceCursoColegio {
  clave: string;
  grado: string;
  division: string;
  turno: string;
  etiqueta: string;
  nomina: number;
  inscriptos: number;
  compraron: number;
  impresos: number;
}

export interface ResumenColegio {
  colegio: { nombre: string; eventoActual: string };
  fechas: FechasCampana;
  convenio: { firmado: boolean; fecha: string | null; porcentaje: number };
  comision: ComisionColegio | null;
  cursos: AvanceCursoColegio[];
  difusion: { urlSitio: string; urlInscripcion: string };
}

export type EstadoEntregaColegio = 'falta_elegir_fotos' | 'en_espera' | 'pagado' | 'en_laboratorio' | 'listo' | 'entregado';

export interface EntregaColegio {
  pedido: string;
  alumno: string;
  numeroLista: number | null;
  codigoSobre: string;
  curso: string;
  cursoEtiqueta: string;
  grado: string;
  division: string;
  turno: string;
  kit: string;
  carpetas: number;
  estado: EstadoEntregaColegio;
  entregadoAt: string | null;
  entregadoPor: 'colegio' | 'fotografo' | null;
}

export const TEXTO_ESTADO_ENTREGA: Record<EstadoEntregaColegio, string> = {
  falta_elegir_fotos: 'Falta que la familia elija las fotos',
  en_espera: 'En espera (consultá con el fotógrafo)',
  pagado: 'Pagado, todavía no se imprimió',
  en_laboratorio: 'En el laboratorio',
  listo: 'Listo para entregar',
  entregado: 'Entregado',
};

// ---------------------------------------------------------------------------------------------
// Sesión (localStorage: puede no estar disponible; sin él la sesión dura mientras la pestaña esté abierta)
// ---------------------------------------------------------------------------------------------
let sesionEnMemoria: SesionColegio | null = null;

export function leerSesionColegio(codigo: string): SesionColegio | null {
  let sesion = sesionEnMemoria;
  try {
    const guardada = localStorage.getItem(CLAVE_SESION);
    if (guardada) sesion = JSON.parse(guardada) as SesionColegio;
  } catch {
    /* sin localStorage */
  }
  if (!sesion || sesion.codigo !== codigo || !sesion.token || Date.now() > sesion.venceAt) return null;
  return sesion;
}

function guardarSesionColegio(sesion: SesionColegio) {
  sesionEnMemoria = sesion;
  try {
    localStorage.setItem(CLAVE_SESION, JSON.stringify(sesion));
  } catch {
    /* sin localStorage */
  }
}

export function cerrarSesionColegio() {
  sesionEnMemoria = null;
  try {
    localStorage.removeItem(CLAVE_SESION);
  } catch {
    /* sin localStorage */
  }
}

// Vista previa: el panel de Pablo la guarda acá y abre /colegio?vista=1 en otra pestaña (misma web, así
// que comparten localStorage). Sin localStorage no hay vista previa.
export function leerVistaPreviaColegio(): SesionColegio | null {
  try {
    const guardada = localStorage.getItem(CLAVE_VISTA_PREVIA);
    const sesion = guardada ? (JSON.parse(guardada) as SesionColegio) : null;
    if (!sesion || !sesion.token || Date.now() > sesion.venceAt) return null;
    return { ...sesion, vistaPrevia: true };
  } catch {
    return null;
  }
}

export function cerrarVistaPreviaColegio() {
  try {
    localStorage.removeItem(CLAVE_VISTA_PREVIA);
  } catch {
    /* sin localStorage */
  }
}

async function leerJson(res: Response): Promise<any> {
  try {
    return await res.json();
  } catch {
    return {};
  }
}

export async function ingresarColegio(
  codigo: string,
  pin: string
): Promise<{ success: boolean; sesion?: SesionColegio; error?: string; linkConvenio?: string | null }> {
  try {
    const res = await fetchConTimeout('/api/colegio/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ codigo, pin }),
    });
    const data = await leerJson(res);
    if (!res.ok || !data.success || !data.token) {
      return { success: false, error: data.error || 'No se pudo entrar. Probá de nuevo.', linkConvenio: data.codigo === 'CONVENIO_SIN_FIRMAR' ? data.linkConvenio || null : null };
    }
    const sesion: SesionColegio = {
      token: data.token,
      codigo,
      colegioNombre: data.colegio?.nombre || '',
      venceAt: Date.now() + (Number(data.expiraEn) || 0) * 1000,
    };
    guardarSesionColegio(sesion);
    return { success: true, sesion };
  } catch (err: any) {
    return { success: false, error: err?.message || 'No se pudo conectar con el servidor.' };
  }
}

async function pedirColegio(sesion: SesionColegio, url: string, opciones: RequestInit = {}): Promise<any> {
  const headers = new Headers(opciones.headers || {});
  headers.set('Authorization', `Bearer ${sesion.token}`);
  const res = await fetchConTimeout(url, { ...opciones, headers });
  const data = await leerJson(res);
  if (res.status === 401) {
    if (sesion.vistaPrevia) {
      cerrarVistaPreviaColegio();
      throw new SesionColegioVencida('La vista previa venció. Abrila de nuevo desde tu panel.');
    }
    cerrarSesionColegio();
    throw new SesionColegioVencida(data.error);
  }
  if (res.status === 403 && data.codigo === 'CONVENIO_SIN_FIRMAR') {
    cerrarSesionColegio();
    throw new SesionColegioVencida(data.error, data.linkConvenio || null);
  }
  if (!res.ok || !data.success) throw new Error(data.error || 'No se pudieron cargar los datos.');
  return data;
}

export async function obtenerResumenColegio(sesion: SesionColegio): Promise<ResumenColegio> {
  const data = await pedirColegio(sesion, '/api/colegio/resumen');
  return data as ResumenColegio;
}

export async function obtenerDetalleComisionColegio(sesion: SesionColegio): Promise<DetalleComisionColegio | null> {
  const data = await pedirColegio(sesion, '/api/colegio/comision/detalle');
  return (data.comision || null) as DetalleComisionColegio | null;
}

/** 26/10: familias de la foto de hermanos con el día (AAAA-MM-DD) y el horario asignados (sin datos de contacto). */
export interface FamiliaHermanosColegio { tutor: string; chicos: string[]; dia: string | null; hora: string | null }

export async function obtenerFotoHermanosColegio(sesion: SesionColegio): Promise<FamiliaHermanosColegio[]> {
  const data = await pedirColegio(sesion, '/api/colegio/foto-hermanos');
  return (data.familias || []) as FamiliaHermanosColegio[];
}

export async function obtenerEntregasColegio(sesion: SesionColegio): Promise<EntregaColegio[]> {
  const data = await pedirColegio(sesion, '/api/colegio/entregas');
  return (data.entregas || []) as EntregaColegio[];
}

export async function marcarEntregadoColegio(sesion: SesionColegio, pedido: string): Promise<{ entregadoAt: string | null }> {
  const data = await pedirColegio(sesion, `/api/colegio/entregas/${encodeURIComponent(pedido)}/entregado`, { method: 'POST' });
  return { entregadoAt: data.entregadoAt || null };
}

// ---------------------------------------------------------------------------------------------
// Panel de Pablo → Colegios → Panel del colegio
// ---------------------------------------------------------------------------------------------
export interface PanelColegioAdmin {
  /** El colegio entra al panel recién cuando firma el convenio. */
  convenio: { firmado: boolean; fecha: string | null; link: string | null };
  activo: boolean;
  link: string | null;
  tienePin: boolean;
  pinActualizadoAt: string | null;
  fechas: FechasCampana;
}

async function pedirAdmin(url: string, opciones: RequestInit = {}): Promise<any> {
  const res = await fetchAdminAutenticado(url, opciones);
  const data = await leerJson(res);
  if (!res.ok || !data.success) throw new Error(data.error || 'No se pudo completar la operación.');
  return data;
}

export async function obtenerPanelColegioAdmin(colegioId: string): Promise<PanelColegioAdmin> {
  const data = await pedirAdmin(`/api/admin/colegios/${encodeURIComponent(colegioId)}/panel`);
  return data.panel as PanelColegioAdmin;
}

export async function generarPinColegioAdmin(colegioId: string): Promise<{ pin: string; panel: PanelColegioAdmin }> {
  const data = await pedirAdmin(`/api/admin/colegios/${encodeURIComponent(colegioId)}/panel/pin`, { method: 'POST' });
  return { pin: String(data.pin), panel: data.panel as PanelColegioAdmin };
}

/** Abre la vista previa del panel del colegio (para Pablo): guarda la sesión de sólo lectura. */
export async function abrirVistaPreviaColegioAdmin(colegioId: string): Promise<SesionColegio> {
  const data = await pedirAdmin(`/api/admin/colegios/${encodeURIComponent(colegioId)}/panel/vista-previa`, { method: 'POST' });
  const sesion: SesionColegio = {
    token: String(data.token),
    codigo: '',
    colegioNombre: data.colegio?.nombre || '',
    venceAt: Date.now() + (Number(data.expiraEn) || 0) * 1000,
    vistaPrevia: true,
  };
  try {
    localStorage.setItem(CLAVE_VISTA_PREVIA, JSON.stringify(sesion));
  } catch {
    throw new Error('Este navegador no deja guardar la vista previa (¿modo incógnito?).');
  }
  return sesion;
}

export async function guardarPanelColegioAdmin(
  colegioId: string,
  cambios: { activo?: boolean; fechas?: Partial<FechasCampana> }
): Promise<PanelColegioAdmin> {
  const data = await pedirAdmin(`/api/admin/colegios/${encodeURIComponent(colegioId)}/panel`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(cambios),
  });
  return data.panel as PanelColegioAdmin;
}
