import { fetchAdminAutenticado } from './adminAuthService';
import { ErrorTiempoAgotado, esStatusTransitorio, fetchConTimeout, MENSAJE_DEMASIADOS_INTENTOS } from '../utils/fetchConTimeout';
import { VERSION_TERMINOS, type IdConsentimiento } from '../legal/textosLegales';

export type EstadoInscripcion = 'pendiente' | 'aceptado' | 'rechazado';

export interface AlumnoHermano {
  id: string;
  alumnoNombre: string;
  alumnoApellido: string;
  alumnoDni: string;
  grado: string;
  division: string;
  turno: string;
  colegioId?: string;
  colegioNombre?: string;
  codigoCurso?: string;
}

export interface InscripcionFamilia {
  id: string;
  padreNombre: string;       // Nombre y apellido del padre o madre / tutor
  // Auditoría 2026-09-22 (pedido de Pablo: identificar a la familia exacta dentro de un código
  // de curso compartido por todo el grado/turno/división, pidiendo nombre + DNI del tutor junto
  // al código en cada ingreso — ver `/api/inscripciones/buscar` en server.ts): DNI del padre,
  // madre o tutor. Puede venir vacío para familias aprobadas antes de este cambio; se completa
  // solo en su primer ingreso posterior.
  padreDni?: string;
  telefonoWhatsApp: string;  // Número de teléfono de WhatsApp
  email: string;             // Correo electrónico
  alumnoNombre: string;      // Nombre del primer alumno/hijo
  alumnoApellido: string;    // Apellido del primer alumno/hijo
  alumnoDni: string;         // DNI del primer alumno/hijo (para distinguir homónimos)
  turno: string;             // Turno (Mañana, Tarde, Jornada Completa)
  grado: string;             // Grado o Sala
  division: string;          // División
  colegioId: string;
  colegioNombre: string;
  fechaInscripcion: string;
  estado: EstadoInscripcion;
  codigoAsignado?: string;   // Código de acceso único asignado (curso o padrón)
  codigoFamiliar: string;    // Alias del código de acceso (compatibilidad con vistas existentes)
  solicitaFotoHermanos?: boolean; // Si los padres desean toma conjunta de hermanos
  /** 08/10: cuándo la familia eligió de verdad la foto de hermanos (null = quedó marcada por defecto, sin confirmar). */
  fotoHermanosConfirmadaAt?: string | null;
  hermanos?: AlumnoHermano[]; // Lista de hermanos adicionales
  fechaAprobacion?: string;
  notificacionWhatsAppEnviada?: boolean;
  notificacionEmailEnviada?: boolean;
  /** Llave de la galería de esta familia (28/9): el servidor sólo le muestra las fotos individuales de sus hijos con ella. */
  accesoGaleria?: string;
}

/** Fila del padrón de padres autorizados (cargado por el colegio vía Excel/CSV) */
export interface FilaPadron {
  id: string;
  colegioId: string;
  nombre: string;
  telefono?: string | null;
  email?: string | null;
  alumnoNombre?: string | null;
  grado?: string | null;
  division?: string | null;
  turno?: string | null;
  codigoAsignado?: string | null;
  usado: boolean;
  createdAt?: string;
}

const STORAGE_KEY_ACTIVO = 'infocus_familia_activa_v1';

/**
 * Determines the recommended course code based on the student's sala/grado/año, turno, and division.
 * Se usa solo como referencia visual (el servidor calcula el código real de forma independiente,
 * en `determinarCodigoCursoServidor` dentro de server.ts — mantener ambas en sincro).
 */
export function determinarCodigoParaInscripcion(datos: { grado: string; turno: string; division: string }): string {
  const g = (datos.grado || '').toLowerCase();
  const t = (datos.turno || '').toLowerCase();
  const d = (datos.division || '').toLowerCase();
  const esJornadaExtendida = t.includes('jornada') || t.includes('extendida') || d.includes('jornada') || d.includes('extendida');

  const turnoAbrev = esJornadaExtendida ? 'JE' : (t.includes('tarde') ? 'TT' : 'TM');

  // Abreviatura de la división (ej: "División C" -> "C", "Jornada Extendida" -> "JO"),
  // para diferenciar divisiones dentro del mismo grado y turno.
  const divisionAbrev = d
    .replace(/divisi[oó]n/g, '')
    .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9]/g, '')
    .toUpperCase()
    .slice(0, 2) || 'X';

  // Nivel inicial (jardín): "Sala 3/4/5 años". Auditoría 2026-09-24 (bug real, una familia
  // pagó por fotos que no eran de su curso): antes las salas usaban códigos fijos (SALA-5B,
  // SALA-4JE...) que juntaban secciones distintas — Sala 5 tarde "A" y "B" compartían
  // "SALA-5B", y las dos divisiones de Jornada Extendida compartían "SALA-5JE" —, así que una
  // familia veía (y podía comprar) fotos de otra sección. Ahora, igual que en primaria, cada
  // sala + división + turno tiene su propio código.
  const matchSala = g.match(/sala\s*(\d+)/);
  if (matchSala) {
    return `SALA${matchSala[1]}-${divisionAbrev}${turnoAbrev}`;
  }

  // Primaria: "1° grado" a "7° grado" (o variantes equivalentes que digan "grado").
  const matchGrado = g.match(/(\d+)\s*°?\s*grado/);
  if (matchGrado) {
    return `GRADO${matchGrado[1]}-${divisionAbrev}${turnoAbrev}`;
  }

  // Secundaria: "1° año" a "6° año".
  const matchAnio = g.match(/(\d+)\s*°?\s*a[ñn]o/);
  if (matchAnio) {
    return `ANIO${matchAnio[1]}-${divisionAbrev}${turnoAbrev}`;
  }

  // Cualquier otro texto de grado no contemplado arriba: código determinístico a partir
  // del texto real (antes acá se devolvía siempre 'SALA-3TM' de memoria).
  const gradoSlug = g
    .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .toUpperCase()
    .slice(0, 12) || 'CURSO';
  return `${gradoSlug}-${divisionAbrev}${turnoAbrev}`;
}

/** Convierte una fila snake_case de Supabase (tabla `inscripciones`) al tipo usado en el frontend */
function mapearFilaSupabaseAInscripcion(row: any): InscripcionFamilia {
  return {
    id: row.id,
    padreNombre: row.padre_nombre || '',
    padreDni: row.padre_dni || undefined,
    telefonoWhatsApp: row.telefono_whatsapp || '',
    email: row.email || '',
    alumnoNombre: row.alumno_nombre || '',
    alumnoApellido: row.alumno_apellido || '',
    alumnoDni: row.alumno_dni || '',
    turno: row.turno || '',
    grado: row.grado || '',
    division: row.division || '',
    colegioId: row.colegio_id || '',
    colegioNombre: row.colegio_nombre || '',
    fechaInscripcion: row.fecha_inscripcion || '',
    estado: (row.estado as EstadoInscripcion) || 'pendiente',
    codigoAsignado: row.codigo_asignado || undefined,
    codigoFamiliar: row.codigo_familiar || row.codigo_asignado || '',
    solicitaFotoHermanos: Boolean(row.solicita_foto_hermanos),
    fotoHermanosConfirmadaAt: row.foto_hermanos_confirmada_at ?? null,
    hermanos: row.hermanos || [],
    fechaAprobacion: row.fecha_aprobacion || undefined,
    notificacionWhatsAppEnviada: Boolean(row.notificacion_whatsapp_enviada),
    notificacionEmailEnviada: Boolean(row.notificacion_email_enviada),
    accesoGaleria: row.acceso_galeria || undefined
  };
}

/** Convierte una fila snake_case de Supabase (tabla `padres_autorizados`) al tipo usado en el frontend */
function mapearFilaPadron(row: any): FilaPadron {
  return {
    id: row.id,
    colegioId: row.colegio_id,
    nombre: row.nombre,
    telefono: row.telefono ?? null,
    email: row.email ?? null,
    alumnoNombre: row.alumno_nombre ?? null,
    grado: row.grado ?? null,
    division: row.division ?? null,
    turno: row.turno ?? null,
    codigoAsignado: row.codigo_asignado ?? null,
    usado: Boolean(row.usado),
    createdAt: row.created_at
  };
}

/**
 * Envía la inscripción al servidor. El servidor valida contra el padrón de padres autorizados
 * (cargado por el colegio) y sólo genera un código de acceso automático si el teléfono o el
 * email coinciden con un padre autorizado; en caso contrario, la inscripción queda "pendiente"
 * para revisión manual del fotógrafo.
 */
export interface ResultadoValidarInscripcion {
  success: boolean;
  estado?: EstadoInscripcion;
  /**
   * Auditoría 2026-09-09: el código de acceso real ya NO viaja acá (ver server.ts). Cuando la
   * inscripción se aprueba automáticamente (o se reenvía a una familia ya aprobada), el código
   * se manda sólo por correo al email ya validado contra el padrón — nunca en esta respuesta.
   */
  emailEnviado?: boolean;
  emailDestino?: string | null;
  inscripcion?: InscripcionFamilia;
  error?: string;
  /** 14/10/2026: la inscripción ya estaba aprobada y el servidor no cambió nada (no se sumó ningún hermano). */
  congelada?: boolean;
}

export async function validarEInscribirFamilia(datos: {
  colegioId: string;
  colegioNombre: string;
  padreNombre: string;
  padreDni: string;
  telefonoWhatsApp: string;
  email: string;
  alumnoNombre: string;
  alumnoApellido: string;
  alumnoDni: string;
  grado: string;
  division: string;
  turno: string;
  solicitaFotoHermanos?: boolean;
  hermanos?: AlumnoHermano[];
  /** Marco legal (27/9): autorizaciones de imagen y datos (ver CONSENTIMIENTOS_INSCRIPCION). */
  consentimientos: Record<IdConsentimiento, boolean>;
}): Promise<ResultadoValidarInscripcion> {
  try {
    const res = await fetchConTimeout('/api/inscripciones/validar', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ...datos, versionTerminos: VERSION_TERMINOS })
    });
    const data = await res.json().catch(() => ({}));
    if (res.status === 429) return { success: false, error: MENSAJE_DEMASIADOS_INTENTOS };
    if (!res.ok || !data.success) {
      return { success: false, error: data.error || 'No pudimos registrar la inscripción. Intentá nuevamente.' };
    }
    const inscripcion = mapearFilaSupabaseAInscripcion(data.inscripcion);
    guardarFamiliaActiva(inscripcion);
    return { success: true, estado: data.estado, emailEnviado: data.emailEnviado, emailDestino: data.emailDestino, inscripcion, congelada: data.congelada === true };
  } catch (err: any) {
    console.error('Error al validar/inscribir familia:', err);
    if (err instanceof ErrorTiempoAgotado) return { success: false, error: err.message };
    return { success: false, error: 'Error al conectar con el servidor. Verificá tu conexión e intentá de nuevo.' };
  }
}

/**
 * Resultado de buscar la propia inscripción por código, teléfono o email (endpoint público).
 *
 * Auditoría 2026-09-09 (revisión a fondo, hallazgo reportado por Pablo): antes, buscar por
 * teléfono o email de una familia ya aprobada devolvía directo su código de acceso real — el
 * teléfono de un padre empadronado no es secreto, así que cualquiera que lo supiera podía
 * "entrar" con él. Ahora, sólo escribir el código real (que sólo se entrega por email)
 * devuelve la familia completa (`encontrada: true`). Si se buscó por teléfono/email y esa familia
 * YA tiene un código asignado, esta ruta nunca lo devuelve: como mucho reenvía el código al
 * correo de confianza ya guardado (`yaRegistrado` + `emailReenviado` + `emailDestino` parcial).
 *
 * Auditoría 2026-09-22 (pedido de Pablo: "que cada vez que vayan a ingresar, lo hagan con
 * nombre y apellido del padre/tutor/encargado, el DNI del padre/tutor/encargado, y el código...
 * con eso solucionamos el problema de que con un solo código por curso no se crucen los datos
 * de los alumnos al momento de ingresar"): el código de curso lo comparte toda la sección a
 * propósito, así que ya no alcanza con acertarlo — ahora se manda siempre `tutorNombre` + `dni`
 * junto al código. Si el servidor no puede identificar a la familia exacta todavía (falta el
 * DNI, o no coincide con ninguna), responde `requiereDatosTutor` (+ `cursoInfo` sólo con el
 * curso, sin datos de ninguna familia) en vez de `inscripcion`.
 */
export interface ResultadoBuscarInscripcion {
  encontrada: boolean;
  inscripcion?: InscripcionFamilia;
  requiereDatosTutor?: boolean;
  datosNoCoinciden?: boolean;
  cursoInfo?: { colegioNombre?: string; grado?: string; division?: string; turno?: string };
  yaRegistrado?: boolean;
  emailReenviado?: boolean;
  emailDestino?: string | null;
  /**
   * Auditoría 03/10 (alto 22): antes un 429 (límite de intentos) o una falla del servidor/red
   * volvían como `encontrada: false` y el portal decía "código no encontrado". Ahora se distinguen.
   */
  limiteAlcanzado?: boolean;
  errorConexion?: string;
  /**
   * Auditoría 03/10 noche (contrato 2, C1): la familia todavía no confirmó su email. El servidor
   * responde 200 `{ success: false, requiereConfirmacion: true, error }`; `avisoConfirmacion` es ese
   * texto, que se muestra como aviso (no como "datos incorrectos") y no se reintenta solo.
   */
  requiereConfirmacion?: boolean;
  avisoConfirmacion?: string;
  /**
   * Auditoría 03/10 noche (contrato 4): la búsqueda por teléfono/email de una inscripción pendiente o
   * rechazada ahora trae SÓLO `{ estado, colegio_nombre }` (sin nombres, curso ni hermanos). En ese
   * caso viene `estadoInscripcion` y NO `inscripcion` (no hay una familia para guardar como sesión).
   */
  estadoInscripcion?: { estado: EstadoInscripcion; colegioNombre: string };
}

/** Auditoría 03/10 noche (contrato 4): "Tu inscripción en <colegio> está <pendiente de revisión/…>". */
export function textoEstadoInscripcion(estado: EstadoInscripcion | string | undefined, colegioNombre?: string): string {
  const enColegio = colegioNombre ? ` en ${colegioNombre}` : '';
  if (estado === 'rechazado') return `Tu inscripción${enColegio} está rechazada. Si creés que es un error, escribinos desde Consultas.`;
  if (estado === 'aceptado') return `Tu inscripción${enColegio} está aprobada. Te mandamos el código de acceso por email.`;
  return `Tu inscripción${enColegio} está pendiente de revisión. Te avisamos por email apenas tengas tu código de acceso.`;
}

export async function buscarMiInscripcion(
  query: string,
  tutorNombre?: string,
  dni?: string
): Promise<ResultadoBuscarInscripcion> {
  try {
    if (!query || query.trim().length < 3) return { encontrada: false };
    const res = await fetchConTimeout('/api/inscripciones/buscar', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ query: query.trim(), tutorNombre: (tutorNombre || '').trim(), dni: dni || '' })
    });
    if (res.status === 429) return { encontrada: false, limiteAlcanzado: true, errorConexion: MENSAJE_DEMASIADOS_INTENTOS };
    if (esStatusTransitorio(res.status)) {
      return { encontrada: false, errorConexion: 'El servidor no pudo validar el código en este momento. Probá de nuevo en unos segundos.' };
    }
    const data = await res.json().catch(() => ({}));
    if (!res.ok) return { encontrada: false };
    // Auditoría 03/10 noche (contrato 2): email sin confirmar — aviso, no error de datos.
    if (!data.success && data.requiereConfirmacion) {
      return {
        encontrada: false,
        requiereConfirmacion: true,
        avisoConfirmacion: typeof data.error === 'string' && data.error ? data.error : 'Antes de ingresar, confirmá tu email con el botón del correo que te mandamos.',
      };
    }
    if (data.success && data.requiereDatosTutor) {
      return {
        encontrada: false,
        requiereDatosTutor: true,
        datosNoCoinciden: Boolean(data.datosNoCoinciden),
        cursoInfo: data.inscripcion
          ? {
              colegioNombre: data.inscripcion.colegio_nombre,
              grado: data.inscripcion.grado,
              division: data.inscripcion.division,
              turno: data.inscripcion.turno
            }
          : undefined
      };
    }
    // Auditoría 03/10 noche (contrato 4): respuesta "sólo estado" (pendiente/rechazada por teléfono o
    // email): no trae id ni nombres — no se arma una familia vacía.
    if (data.success && data.inscripcion && !data.inscripcion.id && !data.inscripcion.codigo_asignado) {
      return {
        encontrada: false,
        estadoInscripcion: {
          estado: (data.inscripcion.estado as EstadoInscripcion) || 'pendiente',
          colegioNombre: String(data.inscripcion.colegio_nombre || ''),
        },
      };
    }
    if (data.success && data.inscripcion) {
      const inscripcion = mapearFilaSupabaseAInscripcion(data.inscripcion);
      // Una inscripción pendiente vuelve sin email ni teléfono (auditoría 30/9: no se devuelven a
      // quien escriba un contacto ajeno). Se completa con lo que escribió la familia, para que
      // "Verificar estado" pueda volver a consultarla.
      if (!inscripcion.email && !inscripcion.telefonoWhatsApp) {
        const q = query.trim();
        if (q.includes('@')) inscripcion.email = q;
        else inscripcion.telefonoWhatsApp = q;
      }
      return { encontrada: true, inscripcion };
    }
    if (data.yaRegistrado) {
      return {
        encontrada: false,
        yaRegistrado: true,
        emailReenviado: Boolean(data.emailReenviado),
        emailDestino: data.emailDestino || null
      };
    }
    return { encontrada: false };
  } catch (err) {
    console.error('Error al buscar inscripción:', err);
    return {
      encontrada: false,
      errorConexion: err instanceof ErrorTiempoAgotado ? err.message : 'No pudimos conectarnos con el servidor. Revisá tu conexión e intentá de nuevo.',
    };
  }
}

/** Panel admin: lista completa de inscripciones (requiere sesión de administrador) */
export async function obtenerInscripcionesAdmin(): Promise<InscripcionFamilia[]> {
  try {
    const res = await fetchAdminAutenticado('/api/admin/inscripciones');
    const data = await res.json();
    if (!res.ok || !data.success) return [];
    return (data.inscripciones || []).map(mapearFilaSupabaseAInscripcion);
  } catch (err) {
    console.error('Error al obtener inscripciones (admin):', err);
    return [];
  }
}

export interface ResultadoAprobarInscripcion {
  success: boolean;
  familia?: InscripcionFamilia;
  codigo?: string;
  error?: string;
}

/** Panel admin: aprueba una inscripción pendiente y le asigna (o confirma) el código de acceso */
export async function aprobarInscripcionAdmin(
  id: string,
  codigoPersonalizado?: string
): Promise<ResultadoAprobarInscripcion> {
  try {
    const res = await fetchAdminAutenticado(`/api/admin/inscripciones/${encodeURIComponent(id)}/aprobar`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ codigo: codigoPersonalizado })
    });
    const data = await res.json();
    if (!res.ok || !data.success) {
      return { success: false, error: data.error || 'Error al aprobar la inscripción' };
    }
    return { success: true, familia: mapearFilaSupabaseAInscripcion(data.inscripcion), codigo: data.codigo };
  } catch (err: any) {
    return { success: false, error: err?.message || 'Error de red al aprobar la inscripción' };
  }
}

export interface ResultadoEnviarEmailAprobacion {
  success: boolean;
  error?: string;
  /** 14/10/2026: el servidor no mandó nada porque ya figuraba enviado (no es un envío de ahora). */
  yaEnviado?: boolean;
}

/** Panel admin: envía de verdad (vía Resend) el email con el Código de Acceso a una familia ya aprobada */
// 14/10/2026: `reenviar` sólo desde el botón manual (sale aunque ya figure enviado); sin eso el servidor no
// repite un email que ya salió (dos pestañas o un reintento del envío masivo).
export async function enviarEmailAprobacionAdmin(id: string, opciones: { reenviar?: boolean } = {}): Promise<ResultadoEnviarEmailAprobacion> {
  try {
    const res = await fetchAdminAutenticado(`/api/admin/inscripciones/${encodeURIComponent(id)}/enviar-email`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(opciones.reenviar ? { reenviar: true } : {}),
    });
    const data = await res.json();
    if (!res.ok || !data.success) {
      return { success: false, error: data.error || 'No se pudo enviar el email' };
    }
    return data.yaEnviado ? { success: true, yaEnviado: true } : { success: true };
  } catch (err: any) {
    return { success: false, error: err?.message || 'Error de red al enviar el email' };
  }
}

export interface ResultadoRechazarInscripcion {
  success: boolean;
  familia?: InscripcionFamilia;
  error?: string;
  /** 14/10/2026: ya no estaba pendiente (la lista estaba vieja): hay que recargar. */
  conflicto?: boolean;
}

/** Panel admin: rechaza una inscripción */
export async function rechazarInscripcionAdmin(
  id: string
): Promise<ResultadoRechazarInscripcion> {
  try {
    const res = await fetchAdminAutenticado(`/api/admin/inscripciones/${encodeURIComponent(id)}/rechazar`, {
      method: 'POST'
    });
    const data = await res.json();
    if (!res.ok || !data.success) {
      return { success: false, conflicto: res.status === 409, error: data.error || 'Error al rechazar la inscripción' };
    }
    return { success: true, familia: mapearFilaSupabaseAInscripcion(data.inscripcion) };
  } catch (err: any) {
    return { success: false, error: err?.message || 'Error de red al rechazar la inscripción' };
  }
}

/** 14/10/2026: anota que se abrió el chat de WhatsApp con la familia (antes nunca quedaba «Enviado»). */
export async function marcarWhatsAppEnviadoAdmin(id: string): Promise<boolean> {
  try {
    const res = await fetchAdminAutenticado(`/api/admin/inscripciones/${encodeURIComponent(id)}/whatsapp-enviado`, { method: 'POST' });
    return res.ok;
  } catch {
    return false;
  }
}

/**
 * Panel admin: borra el DNI del tutor guardado en el primer ingreso (si lo cargó otra persona o
 * la familia se equivocó). El próximo ingreso lo vuelve a registrar.
 */
export async function borrarDniTutorAdmin(id: string): Promise<{ success: boolean; error?: string }> {
  try {
    const res = await fetchAdminAutenticado(`/api/admin/inscripciones/${encodeURIComponent(id)}/borrar-dni`, {
      method: 'POST'
    });
    const data = await res.json();
    if (!res.ok || !data.success) return { success: false, error: data.error || 'Error al borrar el DNI' };
    return { success: true };
  } catch (err: any) {
    return { success: false, error: err?.message || 'Error de red al borrar el DNI' };
  }
}

/**
 * Panel admin: elimina por completo una inscripción del listado (pendiente, rechazada o ya
 * aprobada). Auditoría 2026-09-22 (pedido de Pablo). No borra pedidos, fotos ni el acceso que la
 * familia ya haya generado con su Código Familiar — eso vive en otras tablas, no en ésta.
 */
export async function eliminarInscripcionAdmin(id: string): Promise<{ success: boolean; error?: string }> {
  try {
    const res = await fetchAdminAutenticado(`/api/admin/inscripciones/${encodeURIComponent(id)}`, {
      method: 'DELETE'
    });
    const data = await res.json();
    if (!res.ok || !data.success) {
      return { success: false, error: data.error || 'Error al eliminar la inscripción' };
    }
    return { success: true };
  } catch (err: any) {
    return { success: false, error: err?.message || 'Error de red al eliminar la inscripción' };
  }
}

/** Panel admin: lista el padrón de padres autorizados, opcionalmente filtrado por colegio */
export async function obtenerPadronAdmin(colegioId?: string): Promise<FilaPadron[]> {
  try {
    const url = colegioId
      ? `/api/admin/padron?colegioId=${encodeURIComponent(colegioId)}`
      : '/api/admin/padron';
    const res = await fetchAdminAutenticado(url);
    const data = await res.json();
    if (!res.ok || !data.success) return [];
    return (data.padron || []).map(mapearFilaPadron);
  } catch (err) {
    console.error('Error al obtener el padrón:', err);
    return [];
  }
}

/** Panel admin: importa filas ya parseadas (desde un Excel/CSV leído en el navegador) al padrón */
export async function importarPadronAdmin(
  filas: Array<{
    colegioId: string;
    nombre: string;
    telefono?: string;
    email?: string;
    alumnoNombre?: string;
    grado?: string;
    division?: string;
    turno?: string;
    codigoAsignado?: string;
  }>,
  colegioId: string
): Promise<{ success: boolean; importados?: number; descartados?: number; repetidos?: number; error?: string }> {
  try {
    const res = await fetchAdminAutenticado('/api/admin/padron/importar', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ filas, colegioId })
    });
    const data = await res.json();
    if (!res.ok || !data.success) {
      return { success: false, error: data.error || 'Error al importar el padrón' };
    }
    return { success: true, importados: data.importados, descartados: data.descartados, repetidos: data.repetidos || 0 }; // 14/10: ya estaban
  } catch (err: any) {
    return { success: false, error: err?.message || 'Error de red al importar el padrón' };
  }
}

/** Panel admin: elimina una fila del padrón */
export async function eliminarPadronAdmin(id: string): Promise<{ success: boolean; error?: string }> {
  try {
    const res = await fetchAdminAutenticado(`/api/admin/padron/${encodeURIComponent(id)}`, {
      method: 'DELETE'
    });
    return await res.json();
  } catch (err: any) {
    return { success: false, error: err?.message || 'Error de red al eliminar del padrón' };
  }
}

/**
 * Formats official WhatsApp approval text with the family's single access code and siblings
 */
export function generarMensajeWhatsAppAprobacion(familia: InscripcionFamilia, codigo: string): string {
  const hijosNombres = [
    `${familia.alumnoNombre} (${familia.grado} ${familia.division} - Turno ${familia.turno})`,
    ...(familia.hermanos || []).map(
      (h) => `${h.alumnoNombre} (${h.grado} ${h.division} - Turno ${h.turno})`
    )
  ].join(', ');

  const fotoHermanosNota = familia.solicitaFotoHermanos
    ? `\n📸 *Foto de hermanos:* Solicitada. Tiene un costo aparte (no está incluida en el kit). Te avisamos el día y el lugar.`
    : '';

  // Auditoría 2026-09-22 (pedido de Pablo): este código es el mismo para todo el curso, así que
  // al entrar también va a pedir el nombre y DNI de quien se inscribió — se avisa acá para que no
  // se sorprendan al llegar al sitio.
  return `¡Hola ${familia.padreNombre}! Tu inscripción familiar en el portal de fotos escolares para *${hijosNombres}* (${familia.colegioNombre}) ha sido APROBADA con éxito por el equipo fotográfico.\n\n🔑 Tu *CÓDIGO DE ACCESO* es: *${codigo}*${fotoHermanosNota}\n\nCon este único código podrás ingresar al portal, ver las galerías protegidas de todos tus hijos en un solo lugar y armar tu pedido o combos con un solo pago.\n\n⚠️ Este código es el mismo para todo el curso: al entrar, además del código, te va a pedir tu *nombre y apellido* y tu *DNI* (los de quien se inscribió) para reconocer a tus hijos.\n\nAccedé directamente aquí: https://retratoescolar.com.ar`;
}

/**
 * Builds WhatsApp link to send the family access code to the parent
 */
export function generarEnlaceWhatsAppAprobacion(familia: InscripcionFamilia, codigo: string): string {
  const cleanPhone = familia.telefonoWhatsApp.replace(/[^\d]/g, '');
  const mensaje = generarMensajeWhatsAppAprobacion(familia, codigo);
  return `https://wa.me/${cleanPhone}?text=${encodeURIComponent(mensaje)}`;
}

/**
 * Prepara el contenido y asunto formal del correo de aprobación con el código de acceso asignado
 */
export function prepararEmailAprobacion(familia: InscripcionFamilia, codigo: string) {
  const now = new Date();
  const fechaStr = `${String(now.getDate()).padStart(2, '0')}/${String(now.getMonth() + 1).padStart(2, '0')}/${now.getFullYear()} ${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;

  const listaHijos = [
    `• ${familia.alumnoNombre} ${familia.alumnoApellido} (${familia.grado} "${familia.division}", Turno ${familia.turno})`,
    ...(familia.hermanos || []).map(
      (h) => `• ${h.alumnoNombre} ${h.alumnoApellido} (${h.grado} "${h.division}", Turno ${h.turno})`
    )
  ].join('\n');

  const asunto = `Retrato Escolar: Tu Código de Acceso (${codigo}) - ${familia.colegioNombre}`;
  // Auditoría 2026-09-22 (pedido de Pablo): este código es el mismo para todo el curso, así que
  // el ingreso también pide nombre y DNI de quien se inscribió — se aclara acá.
  const contenido = `Estimado/a ${familia.padreNombre},\n\nLe confirmamos que su registro familiar para el ciclo escolar 2026 en ${familia.colegioNombre} ha sido validado con éxito.\n\nAlumnos vinculados a su cuenta familiar:\n${listaHijos}\n${familia.solicitaFotoHermanos ? '✓ Foto de hermanos juntos: Solicitada y programada\n' : ''}\n=========================================\nSU CÓDIGO DE ACCESO: ${codigo}\n=========================================\n\nCon este único código podrá:\n1. Ingresar a retratoescolar.com.ar con su nombre y apellido, su DNI y este código.\n2. Ver las galerías individuales y grupales de todos sus hijos sin tener que usar códigos diferentes.\n3. Seleccionar las fotos favoritas y armar un pedido consolidado en un solo pago.\n\nImportante: este código es el mismo para todo el curso. Al ingresar, además del código, va a tener que completar el nombre y apellido y el DNI de quien se inscribió, para que el sistema reconozca a sus hijos.\n\nPara cualquier consulta, nuestro equipo fotográfico está a su entera disposición.\n\nAtentamente,\nEquipo de Fotografía Escolar · Retrato Escolar (retratoescolar.com.ar)`;

  return {
    asunto,
    destinatario: familia.email,
    telefono: familia.telefonoWhatsApp,
    contenido,
    timestamp: fechaStr
  };
}

// Alias para compatibilidad
export const simularEnvioEmailAprobacion = prepararEmailAprobacion;

/** Sesión activa de familia en este navegador (caché local, no reemplaza la base de datos) */
export function obtenerFamiliaActiva(): InscripcionFamilia | null {
  if (typeof window === 'undefined') return null;
  try {
    const raw = localStorage.getItem(STORAGE_KEY_ACTIVO);
    const familia: InscripcionFamilia | null = raw ? JSON.parse(raw) : null;
    // Auditoría 2026-09-23 (origen del "no sé quién es Juan Perez" / "¡Hola, !"): desde el 22/9
    // el código de acceso es compartido por todo el curso y la familia se identifica con nombre
    // + DNI del tutor. Una sesión guardada ANTES de ese cambio (con código pero sin DNI) no
    // alcanza para saber de qué familia se trata — el servidor ya no le devuelve los hijos — y
    // restaurarla mostraba datos cacheados que podían ser de otra familia. Se descarta para que
    // la familia vuelva a ingresar con sus datos.
    if (familia && (familia.codigoAsignado || familia.codigoFamiliar) && !familia.padreDni) {
      localStorage.removeItem(STORAGE_KEY_ACTIVO);
      return null;
    }
    return familia;
  } catch {
    return null;
  }
}

export function guardarFamiliaActiva(familia: InscripcionFamilia | null): void {
  if (typeof window === 'undefined') return;
  try {
    if (familia) {
      // Auditoría 30/9: el DNI de los chicos no se guarda en el navegador (en una PC compartida lo
      // vería el que la use después). No hace falta para nada del portal.
      const sinDniChicos = {
        ...familia,
        alumnoDni: '',
        hermanos: Array.isArray(familia.hermanos) ? familia.hermanos.map((h: any) => ({ ...h, alumnoDni: '' })) : familia.hermanos,
      };
      localStorage.setItem(STORAGE_KEY_ACTIVO, JSON.stringify(sinDniChicos));
    } else {
      localStorage.removeItem(STORAGE_KEY_ACTIVO);
    }
    // Notifica a otros componentes en la misma pestaña (ej. Hero) que la sesión de familia activa cambió
    window.dispatchEvent(new CustomEvent('infocus_familia_activa_actualizada', { detail: familia }));
  } catch (err) {
    console.error('Error al guardar familia activa:', err);
  }
}

export function cerrarSesionFamilia(): void {
  guardarFamiliaActiva(null);
}

/**
 * Auditoría 2026-09-16 (el Código Familiar prometía "ver a todos tus hijos y alternar entre
 * ellos con un solo toque" incluso en secciones distintas, pero nunca se resolvía un código real
 * para la sección de cada hermano): dado el Código Familiar ya validado, trae el hijo principal +
 * cada hermano con SU PROPIO código real de sección (ver `/api/familia/hijos` en el servidor).
 * El portal de familias usa esto para poder cambiar de galería al elegir otro hijo.
 */
export interface HijoConCodigoSeccion {
  id: string;
  nombreCompleto: string;
  colegioNombre?: string;
  grado?: string;
  turno?: string;
  division?: string;
  codigoSeccion: string;
}

// Auditoría 2026-09-22: `codigoFamiliar` puede estar compartido por toda la sección (ver
// `/api/inscripciones/buscar`), así que se manda también el DNI del tutor ya identificado (si
// se tiene) para que el servidor pueda elegir la fila de la familia correcta y no la primera que
// encuentre con ese código.
// Auditoría 30/9: el servidor identifica a la familia con su llave de galería (id + acceso), no con
// el DNI suelto. Sin llave devuelve 403 y el portal pide volver a ingresar.
export async function obtenerHijosDeFamilia(codigoFamiliar: string, familiaId?: string, accesoGaleria?: string): Promise<HijoConCodigoSeccion[]> {
  return (await obtenerHijosDeFamiliaConEstado(codigoFamiliar, familiaId, accesoGaleria)).hijos;
}

export interface ResultadoHijosDeFamilia {
  hijos: HijoConCodigoSeccion[];
  /** true = falló por red, tiempo, 429 o 5xx: la lista vacía NO significa "hijo único". */
  falloTransitorio?: boolean;
  /** 14/10/2026: 404 = el código guardado ya no es el de la inscripción (se le corrigió el curso): hay que volver a ingresar. */
  codigoVencido?: boolean;
  error?: string;
}

/**
 * Auditoría 03/10 noche (R12): igual que obtenerHijosDeFamilia, pero distingue una falla pasajera
 * (429/5xx/red) de "no hay hijos". Antes cualquier falla devolvía [] y el portal seguía como si la
 * familia tuviera un solo hijo: los hermanos desaparecían sin aviso (y se podía pagar sin ellos).
 */
export async function obtenerHijosDeFamiliaConEstado(codigoFamiliar: string, familiaId?: string, accesoGaleria?: string): Promise<ResultadoHijosDeFamilia> {
  const codigo = (codigoFamiliar || '').trim();
  if (!codigo || !familiaId || !accesoGaleria) return { hijos: [] };
  try {
    const params = new URLSearchParams({ codigo, familia: familiaId, acceso: accesoGaleria });
    const res = await fetchConTimeout(`/api/familia/hijos?${params.toString()}`);
    if (esStatusTransitorio(res.status)) {
      return {
        hijos: [],
        falloTransitorio: true,
        error: res.status === 429 ? MENSAJE_DEMASIADOS_INTENTOS : 'No pudimos cargar a tus otros hijos.',
      };
    }
    const data = await res.json().catch(() => ({}));
    if (!res.ok || !data.success) return res.status === 404 ? { hijos: [], codigoVencido: true } : { hijos: [] };
    return { hijos: Array.isArray(data.hijos) ? data.hijos : [] };
  } catch (err) {
    console.error('Error al obtener los hijos de la familia:', err);
    return {
      hijos: [],
      falloTransitorio: true,
      error: err instanceof ErrorTiempoAgotado ? err.message : 'No pudimos cargar a tus otros hijos (sin conexión).',
    };
  }
}

/**
 * Auditoría 03/10 noche (contrato 3, revisado): link del email del código
 * `/?confirmar-acceso=<id>.<token>`. Además del token, el servidor exige el DNI de la persona que
 * hizo la inscripción (`{ id, token, dni }`): 400 `requiereDni` si falta o es corto, 409
 * `dniNoCoincide` si no coincide (se muestra el `error` tal cual y se deja reintentar).
 * Con éxito devuelve el código del curso para precargarlo en el ingreso.
 */
export interface ResultadoConfirmarAcceso {
  success: boolean;
  codigo?: string;
  error?: string;
  requiereDni?: boolean;
  dniNoCoincide?: boolean;
}

export async function confirmarAccesoInscripcion(valorParametro: string, dni: string): Promise<ResultadoConfirmarAcceso> {
  const valor = String(valorParametro || '').trim();
  const punto = valor.indexOf('.');
  const id = punto > 0 ? valor.slice(0, punto) : '';
  const token = punto > 0 ? valor.slice(punto + 1) : '';
  if (!id || !token) return { success: false, error: 'El link de confirmación está incompleto. Abrilo de nuevo desde el email.' };
  const dniLimpio = String(dni || '').replace(/\D/g, '');
  if (dniLimpio.length < 6) return { success: false, requiereDni: true, error: 'Escribí el DNI de la persona que hizo la inscripción para confirmar.' };
  try {
    const res = await fetchConTimeout('/api/inscripciones/confirmar-acceso', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id, token, dni: dniLimpio }),
    });
    if (res.status === 429) return { success: false, error: MENSAJE_DEMASIADOS_INTENTOS };
    const data = await res.json().catch(() => ({}));
    if (res.ok && data?.success) return { success: true, codigo: typeof data.codigo === 'string' ? data.codigo : undefined };
    return {
      success: false,
      requiereDni: Boolean(data?.requiereDni),
      dniNoCoincide: Boolean(data?.dniNoCoincide),
      error: (typeof data?.error === 'string' && data.error) || 'No pudimos confirmar tu email. Probá abrir el link de nuevo.',
    };
  } catch (err) {
    return {
      success: false,
      error: err instanceof ErrorTiempoAgotado ? err.message : 'No pudimos conectarnos con el servidor. Revisá tu conexión y abrí el link de nuevo.',
    };
  }
}

/**
 * 14/10/2026 (pedido de Pablo): la familia ya identificada se anota (o se baja) de la foto de hermanos desde el
 * portal, en cualquier momento. Se paga después, al elegirla publicada (como las fotos de un evento).
 */
export async function guardarFotoHermanosFamilia(datos: {
  familiaId: string;
  acceso: string;
  quiere: boolean;
  email?: string;
  whatsapp?: string;
}): Promise<{ success: boolean; error?: string; fotoHermanosConfirmadaAt?: string; requiereDatosTutor?: boolean }> {
  try {
    const res = await fetchConTimeout('/api/familia/foto-hermanos', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ familia: datos.familiaId, acceso: datos.acceso, quiere: datos.quiere, email: datos.email || '', whatsapp: datos.whatsapp || '' }),
    });
    if (res.status === 429) return { success: false, error: MENSAJE_DEMASIADOS_INTENTOS };
    const data = await res.json().catch(() => ({}));
    if (!res.ok || !data.success) {
      return { success: false, error: data.error || 'No pudimos guardar tu respuesta. Probá de nuevo en un rato.', requiereDatosTutor: data.requiereDatosTutor === true };
    }
    return { success: true, fotoHermanosConfirmadaAt: data.fotoHermanosConfirmadaAt };
  } catch (err) {
    return { success: false, error: err instanceof ErrorTiempoAgotado ? err.message : 'Error de conexión. Revisá tu internet e intentá de nuevo.' };
  }
}
