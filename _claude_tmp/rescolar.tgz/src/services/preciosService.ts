import { useSyncExternalStore } from 'react';
import { KITS_DISPONIBLES } from '../data/colegiosData';
import { KITS_RESERVA } from './reservasService';
import { fetchAdminAutenticado } from './adminAuthService';
import { fetchConTimeout } from '../utils/fetchConTimeout';

/**
 * Precios del sitio en un solo lugar (auditoría 28/9). La fuente de verdad es el servidor
 * (GET /api/precios, que los lee de Supabase → configuracion 'precios_kits'); se editan desde el
 * panel (Configuración → Precios). Estos valores por defecto sólo se ven hasta que responde el
 * servidor. El monto que se cobra lo calcula SIEMPRE el servidor.
 */
export interface PreciosSitio {
  kitClasico: number;
  kitDigital: number;
  carpetaExtra: number;
  fotoEvento: number;
  /** 29/10/2026: fotos extra (pedido aparte sobre un kit pagado). Un servidor viejo no las manda: quedan las de abajo. */
  extra15x21: number;
  extra20x30: number;
}

export const PRECIOS: PreciosSitio = { kitClasico: 30000, kitDigital: 15000, carpetaExtra: 15000, fotoEvento: 5000, extra15x21: 5000, extra20x30: 8000 };

let version = 0;
const oyentes = new Set<() => void>();

function aplicar(p: PreciosSitio) {
  Object.assign(PRECIOS, p, { extra15x21: p.extra15x21 > 0 ? p.extra15x21 : PRECIOS.extra15x21, extra20x30: p.extra20x30 > 0 ? p.extra20x30 : PRECIOS.extra20x30 });
  // Los catálogos que usan las pantallas llevan el precio adentro: se actualizan en el lugar.
  for (const kit of KITS_DISPONIBLES) {
    if (kit.id === 'kit-clasico') kit.precio = p.kitClasico;
    if (kit.id === 'kit-digital') kit.precio = p.kitDigital;
    if (kit.id === 'kit-evento-suelto') kit.precio = p.fotoEvento;
  }
  for (const kit of KITS_RESERVA) kit.precio = kit.id === 'kit-clasico' ? p.kitClasico : p.kitDigital;
  version += 1;
  oyentes.forEach((fn) => fn());
}

function esValido(p: any): p is PreciosSitio {
  return Boolean(p) && ['kitClasico', 'kitDigital', 'carpetaExtra', 'fotoEvento'].every((k) => Number.isFinite(p[k]) && p[k] > 0);
}

/**
 * Auditoría 03/10 noche (M7): antes se pedía UNA sola vez y, si fallaba, quedaban los valores por
 * defecto para siempre (sin reintentar ni avisar). En el panel eso era grave: "Guardar" mandaba
 * los 4 precios, así que cambiar uno pisaba los otros 3 con los valores por defecto. Ahora:
 *  - cada carga hace hasta 3 intentos (con tiempo máximo) y, si igual falla, la próxima llamada
 *    vuelve a intentar (no queda guardado el fracaso);
 *  - `preciosVienenDelServidor()` dice si los precios en pantalla son los reales del servidor.
 */
let delServidor = false;
export function preciosVienenDelServidor(): boolean {
  return delServidor;
}

const ESPERAS_REINTENTO_MS = [1000, 3000];
const esperarMs = (ms: number) => new Promise<void>((r) => setTimeout(r, ms));

async function pedirPreciosAlServidor(): Promise<boolean> {
  for (let intento = 0; intento <= ESPERAS_REINTENTO_MS.length; intento++) {
    try {
      const r = await fetchConTimeout('/api/precios');
      const data = r.ok ? await r.json().catch(() => null) : null;
      if (esValido(data?.precios)) {
        delServidor = true;
        aplicar(data.precios);
        return true;
      }
    } catch {
      // Sin conexión o tiempo agotado: se reintenta.
    }
    if (intento < ESPERAS_REINTENTO_MS.length) await esperarMs(ESPERAS_REINTENTO_MS[intento]);
  }
  return false;
}

let cargando: Promise<boolean> | null = null;
/** Carga los precios del servidor. Devuelve true si quedaron los del servidor. */
export function cargarPreciosDelServidor(opciones: { forzar?: boolean } = {}): Promise<boolean> {
  if (delServidor && !opciones.forzar) return Promise.resolve(true);
  if (!cargando) {
    cargando = pedirPreciosAlServidor().then((ok) => {
      // Terminada (bien o mal) se olvida: si falló, la próxima llamada vuelve a intentar; si salió
      // bien, `delServidor` ya evita pedirlos de nuevo (salvo que se fuerce una relectura).
      cargando = null;
      return ok;
    });
  }
  return cargando;
}

export function cargarPrecios(): Promise<void> {
  return cargarPreciosDelServidor().then(() => undefined);
}

/** Re-renderiza el componente cuando llegan (o cambian) los precios del servidor. */
export function usePrecios(): PreciosSitio {
  useSyncExternalStore(
    (fn) => {
      oyentes.add(fn);
      return () => oyentes.delete(fn);
    },
    () => version,
    () => version
  );
  return PRECIOS;
}

export const formatoPrecio = (n: number) => `$${Math.round(n).toLocaleString('es-AR')}`;

export async function guardarPreciosAdmin(nuevos: PreciosSitio): Promise<{ success: boolean; error?: string }> {
  try {
    const res = await fetchAdminAutenticado('/api/admin/precios', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ precios: nuevos }),
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok || !data?.success) return { success: false, error: data?.error || 'No se pudieron guardar los precios.' };
    // Auditoría 03/10 noche: sólo se aplican si vinieron completos (antes se aplicaba cualquier cosa).
    if (esValido(data.precios)) {
      delServidor = true;
      aplicar(data.precios);
    }
    return { success: true };
  } catch (e: any) {
    return { success: false, error: e?.message || 'Error de conexión.' };
  }
}
