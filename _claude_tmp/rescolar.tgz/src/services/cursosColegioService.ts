/**
 * Cursos reales (grado + división + turno) de un colegio, según su nómina (GET /api/colegios/:id/cursos,
 * 12/10/2026). Los usa el formulario de inscripción para no ofrecer cursos que no existen. Si falla, el
 * formulario sigue funcionando con la lista general del colegio.
 */
import { useEffect, useState } from 'react';
import { fetchConTimeout } from '../utils/fetchConTimeout';
import type { CursoColegio } from '../utils/cursosColegio';

const cache = new Map<string, Promise<CursoColegio[] | null>>();

export function obtenerCursosColegio(colegioId: string): Promise<CursoColegio[] | null> {
  if (!cache.has(colegioId)) {
    const pedido = fetchConTimeout(`/api/colegios/${encodeURIComponent(colegioId)}/cursos`)
      .then(async (res) => {
        const data = await res.json().catch(() => ({}));
        return res.ok && data?.success && Array.isArray(data.cursos) ? (data.cursos as CursoColegio[]) : null;
      })
      .catch(() => null)
      .then((cursos) => {
        if (!cursos) cache.delete(colegioId); // se reintenta la próxima vez
        return cursos;
      });
    cache.set(colegioId, pedido);
  }
  return cache.get(colegioId) as Promise<CursoColegio[] | null>;
}

/** null mientras carga, si el colegio no es real (el de relleno) o si falló. */
export function useCursosColegio(colegioId: string | undefined): CursoColegio[] | null {
  const [cursos, setCursos] = useState<CursoColegio[] | null>(null);
  useEffect(() => {
    let vivo = true;
    setCursos(null);
    if (!colegioId || !/^[0-9a-f-]{36}$/i.test(colegioId)) return;
    void obtenerCursosColegio(colegioId).then((lista) => {
      if (vivo) setCursos(lista);
    });
    return () => {
      vivo = false;
    };
  }, [colegioId]);
  return cursos;
}
