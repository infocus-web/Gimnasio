/**
 * Servicio para las solicitudes de "no encuentro mi código de curso" que dejan las familias
 * desde el portal. La recuperación y las consultas se gestionan exclusivamente por email.
 */
import { fetchAdminAutenticado } from './adminAuthService';
import { ErrorTiempoAgotado, fetchConTimeout } from '../utils/fetchConTimeout';

export interface SolicitudCodigo {
  id: string;
  nombreSolicitante: string;
  contacto: string; // Email registrado por la familia
  alumnoNombre?: string;
  colegioId?: string;
  colegioNombre?: string;
  grado?: string;
  division?: string;
  turno?: string;
  mensaje?: string;
  estado: 'pendiente' | 'atendido';
  /** 25/10: el email HOY coincide con una inscripción aprobada (p. ej. se corrigió después del pedido). */
  inscripcionAprobada?: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface DatosSolicitudCodigo {
  nombreSolicitante: string;
  contacto: string;
  alumnoNombre?: string;
  colegioId?: string;
  colegioNombre?: string;
  grado?: string;
  division?: string;
  turno?: string;
  mensaje?: string;
}

function mapearFilaSupabaseASolicitud(row: any): SolicitudCodigo {
  return {
    id: row.id,
    nombreSolicitante: row.nombre_solicitante || '',
    contacto: row.contacto || '',
    alumnoNombre: row.alumno_nombre || undefined,
    colegioId: row.colegio_id || undefined,
    colegioNombre: row.colegio_nombre || undefined,
    grado: row.grado || undefined,
    division: row.division || undefined,
    turno: row.turno || undefined,
    mensaje: row.mensaje || undefined,
    estado: (row.estado as SolicitudCodigo['estado']) || 'pendiente',
    inscripcionAprobada: row.inscripcion_aprobada === true,
    createdAt: row.created_at || '',
    updatedAt: row.updated_at || '',
  };
}

/** Portal público: la familia deja sus datos para que el fotógrafo le facilite el código */
export async function enviarSolicitudCodigo(
  datos: DatosSolicitudCodigo
): Promise<{ success: boolean; mensaje?: string; envioAutomatico?: boolean; bloqueado?: boolean; motivo?: 'pendiente' | 'sin_inscripcion'; error?: string }> {
  try {
    const res = await fetchConTimeout('/api/solicitudes-codigo', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(datos),
    });
    const data = await res.json();
    if (!res.ok || !data.success) {
      return { success: false, error: data.error || 'No se pudo enviar la solicitud.' };
    }
    return {
      success: true,
      mensaje: data.mensaje,
      envioAutomatico: Boolean(data.envioAutomatico),
      bloqueado: Boolean(data.bloqueado),
      motivo: data.motivo === 'pendiente' || data.motivo === 'sin_inscripcion' ? data.motivo : undefined,
    };
  } catch (err: any) {
    console.error('Error al enviar solicitud de código:', err);
    return { success: false, error: err instanceof ErrorTiempoAgotado ? err.message : 'Error de conexión con el servidor.' };
  }
}

/** Panel admin: lista las solicitudes (por defecto solo las pendientes) */
export async function obtenerSolicitudesCodigoAdmin(
  estado: 'pendiente' | 'todas' = 'pendiente'
): Promise<SolicitudCodigo[]> {
  try {
    const res = await fetchAdminAutenticado(`/api/admin/solicitudes-codigo?estado=${encodeURIComponent(estado)}`);
    const data = await res.json();
    if (!res.ok || !data.success) return [];
    return (data.solicitudes || []).map(mapearFilaSupabaseASolicitud);
  } catch (err) {
    console.error('Error al obtener solicitudes de código (admin):', err);
    return [];
  }
}

/** Panel admin: marca una solicitud como ya atendida */
export async function marcarSolicitudCodigoAtendidaAdmin(
  id: string
): Promise<{ success: boolean; error?: string }> {
  try {
    const res = await fetchAdminAutenticado(`/api/admin/solicitudes-codigo/${encodeURIComponent(id)}/atender`, {
      method: 'POST',
    });
    const data = await res.json();
    return data;
  } catch (err: any) {
    return { success: false, error: err?.message || 'Error de red' };
  }
}

/** Panel admin: elimina una solicitud de la lista */
export async function eliminarSolicitudCodigoAdmin(id: string): Promise<{ success: boolean; error?: string }> {
  try {
    const res = await fetchAdminAutenticado(`/api/admin/solicitudes-codigo/${encodeURIComponent(id)}`, {
      method: 'DELETE',
    });
    const data = await res.json();
    return data;
  } catch (err: any) {
    return { success: false, error: err?.message || 'Error de red' };
  }
}

/**
 * Panel admin: responde una solicitud por email desde el sistema (mismo remitente oficial que
 * usa el resto de la plataforma), en vez de tener que escribirle a mano desde el correo personal
 * del fotógrafo. Al enviarse con éxito, el servidor marca la solicitud como atendida.
 *
 * `codigo` es opcional: cuando el panel pudo ubicar solo el Código de Acceso real de la sección
 * (ver `AdminSolicitudesCodigoTab.tsx`, usa `asegurarCodigoSeccionAdmin` con el colegio/grado/
 * turno/división que haya dejado la familia), se lo pasa acá y el email sale con el código
 * destacado en vez de depender de que Pablo lo escriba a mano; `mensaje` queda como una
 * aclaración opcional en ese caso.
 */
export async function responderSolicitudCodigoAdmin(
  id: string,
  mensaje: string,
  codigo?: string,
  clave?: string // 14/10/2026: un reintento del mismo texto no se manda dos veces (utils/claveEnvio.ts)
): Promise<{ success: boolean; error?: string }> {
  try {
    const res = await fetchAdminAutenticado(`/api/admin/solicitudes-codigo/${encodeURIComponent(id)}/responder`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ mensaje, codigo: codigo || undefined, clave: clave || undefined }),
    });
    const data = await res.json();
    return data;
  } catch (err: any) {
    return { success: false, error: err?.message || 'Error de red' };
  }
}

/**
 * 28/10/2026: el email de la solicitud ya tiene una inscripción aprobada → el servidor le reenvía el mismo
 * email de «Reenviar Email» de Inscriptos y marca atendidas esta solicitud y sus repetidas (`atendidas`).
 */
export async function reenviarCodigoSolicitudAdmin(
  id: string
): Promise<{ success: boolean; atendidas?: string[]; email?: string; error?: string }> {
  try {
    const res = await fetchAdminAutenticado(`/api/admin/solicitudes-codigo/${encodeURIComponent(id)}/reenviar-codigo`, {
      method: 'POST',
    });
    const data = await res.json();
    if (!res.ok || !data.success) return { success: false, error: data.error || 'No se pudo reenviar el código.' };
    return { success: true, atendidas: Array.isArray(data.atendidas) ? data.atendidas : [id], email: data.email };
  } catch (err: any) {
    return { success: false, error: err?.message || 'Error de red' };
  }
}
