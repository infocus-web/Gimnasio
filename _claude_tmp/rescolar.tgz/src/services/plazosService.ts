import { fetchAdminAutenticado } from './adminAuthService';
import { aplicarPlazos, type PlazosTemporada } from '../utils/plazosTemporada';

/** Panel → Configuración (30/10/2026): guarda las fechas límite de la temporada (POST /api/admin/plazos). */
export async function guardarPlazosAdmin(nuevos: PlazosTemporada): Promise<{ success: boolean; error?: string }> {
  try {
    const res = await fetchAdminAutenticado('/api/admin/plazos', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ plazos: nuevos }),
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok || !data?.success) return { success: false, error: data?.error || 'No se pudieron guardar las fechas.' };
    aplicarPlazos(data.plazos);
    return { success: true };
  } catch (e: any) {
    return { success: false, error: e?.message || 'Error de conexión.' };
  }
}
