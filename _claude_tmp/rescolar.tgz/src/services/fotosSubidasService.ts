import { Foto, CategoriaFoto } from '../types';
import { ErrorTiempoAgotado, fetchConTimeout, MENSAJE_DEMASIADOS_INTENTOS } from '../utils/fetchConTimeout';
import { fetchAdminAutenticado } from './adminAuthService';
import { conProcesoEnCurso } from '../utils/procesoEnCurso';

/**
 * Catálogo de fotos activas: vive en Supabase (tabla `fotos`), compartido por todo el sitio.
 * Antes se guardaba en el almacenamiento local del navegador del fotógrafo, por lo que las
 * familias nunca veían las fotos reales desde su propio dispositivo — esto ya no ocurre.
 */
export interface FotoRegistrada {
  id: string;
  colegioId?: string | null;
  codigoCurso?: string | null;
  grado?: string | null;
  division?: string | null;
  turno?: string | null;
  categoria: 'individual' | 'grupal' | 'docente' | 'familia' | 'patio';
  alumnoNombre?: string | null;
  urlWeb: string;
  pathStorageWeb?: string | null;
  pathStorageHD?: string | null;
  createdAt?: string;
  /** 06/10: false = subida pero SIN PUBLICAR (las familias todavía no la ven). */
  publicada: boolean;
  /** 14/10: nombre y tamaño del archivo original (para no subirlo dos veces). */
  nombreOriginal?: string | null;
  bytesOriginal?: number | null;
}

function mapearFilaFoto(row: any): FotoRegistrada {
  return {
    id: row.id,
    colegioId: row.colegio_id,
    codigoCurso: row.codigo_curso,
    grado: row.grado,
    division: row.division,
    turno: row.turno,
    categoria: row.categoria,
    alumnoNombre: row.alumno_nombre,
    urlWeb: row.preview_path || row.thumb_path || '',
    pathStorageWeb: row.thumb_path || row.preview_path,
    pathStorageHD: row.storage_path,
    createdAt: row.created_at,
    // Un servidor anterior al botón «Publicar» no manda la columna: todas estaban publicadas.
    publicada: row.publicada_at !== null,
    nombreOriginal: row.nombre_original ?? null,
    bytesOriginal: row.bytes_original == null ? null : Number(row.bytes_original),
  };
}

export interface DatosFotoParaRegistrar {
  colegioId: string;
  categoria: 'individual' | 'grupal' | 'docente' | 'familia' | 'patio';
  grado: string;
  turno: string;
  division: string;
  storagePathHD: string;
  storagePathWeb: string;
  /** Miniatura chica y sin marca de agua, usada en la grilla de la galería */
  storagePathThumb?: string;
  alumnoNombre?: string;
  /** 14/10: nombre y tamaño del archivo original (el panel saltea los que ya están en el curso). */
  nombreOriginal?: string;
  bytesOriginal?: number;
}

export interface ResultadoRegistrarFotos {
  success: boolean;
  registradas?: number;
  emailsEnviados?: number;
  warning?: string;
  error?: string;
  /** Marca (hora de la base) del comienzo de la subida: mandarla en las tandas siguientes. */
  marcaSubida?: string;
}

/**
 * Auditoría 03/10 (2ª vuelta): opciones para registrar por tandas. `avisar: false` = no mandar el
 * aviso "ya están tus fotos" (tanda intermedia); `subidaDesde` = la `marcaSubida` devuelta por la
 * primera tanda de la misma subida (así el servidor sabe si el curso estaba vacío antes de empezar).
 */
export interface OpcionesRegistrarFotos {
  avisar?: boolean;
  subidaDesde?: string | null;
}

// El servidor acepta hasta 500 fotos por llamada (ver POST /api/admin/fotos en server.ts).
const FOTOS_POR_LOTE_REGISTRO = 200;

/** Panel admin: registra en Supabase las fotos ya subidas a Storage (quedan SIN PUBLICAR hasta «Publicar», 06/10) */
export async function registrarFotosAdmin(fotos: DatosFotoParaRegistrar[], opciones: OpcionesRegistrarFotos = {}): Promise<ResultadoRegistrarFotos> {
  // Auditoría 2026-09-23 (bug real): todo el lote viajaba en UNA sola llamada. Con más de 500
  // fotos el servidor lo rechazaba entero, y con bastantes menos ya superaba el tamaño máximo del
  // body — en ambos casos las fotos quedaban subidas a Storage pero sin registrar en el catálogo
  // (no aparecían en la galería). Ahora se registran en lotes.
  let registradas = 0;
  let emailsEnviados = 0;
  let warning: string | undefined;
  let marcaSubida: string | undefined = opciones.subidaDesde || undefined;
  for (let i = 0; i < fotos.length; i += FOTOS_POR_LOTE_REGISTRO) {
    const lote = fotos.slice(i, i + FOTOS_POR_LOTE_REGISTRO);
    const esUltimoLote = i + FOTOS_POR_LOTE_REGISTRO >= fotos.length;
    try {
      const res = await fetchAdminAutenticado('/api/admin/fotos', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        // El aviso sale sólo con el último lote (y si quien llama no lo apagó).
        body: JSON.stringify({ fotos: lote, avisar: opciones.avisar !== false && esUltimoLote, ...(marcaSubida ? { subidaDesde: marcaSubida } : {}) }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok || !data.success) {
        const error = data.error || 'No se pudieron registrar las fotos.';
        return {
          success: false,
          registradas,
          emailsEnviados,
          marcaSubida,
          error: registradas > 0 ? `Se registraron ${registradas} de ${fotos.length} fotos. El resto falló: ${error}` : error,
        };
      }
      if (!marcaSubida && typeof data.marcaSubida === 'string') marcaSubida = data.marcaSubida;
      registradas += data.registradas || 0;
      emailsEnviados += data.emailsEnviados || 0;
      warning = warning || data.warning;
    } catch (err: any) {
      const error = err?.message || 'Error de red al registrar las fotos.';
      return {
        success: false,
        registradas,
        emailsEnviados,
        marcaSubida,
        error: registradas > 0 ? `Se registraron ${registradas} de ${fotos.length} fotos. El resto falló: ${error}` : error,
      };
    }
  }
  return { success: true, registradas, emailsEnviados, warning, marcaSubida };
}

/**
 * Panel admin: lista las fotos activas de un curso puntual (grado+turno+división) para
 * mostrarlas/borrarlas. Auditoría 2026-09-22 (pedido de Pablo: listado de qué cursos ya tienen
 * fotos subidas): `grado`/`turno` pasan a ser opcionales — si se omiten (dejando sólo
 * `colegioId`), el servidor devuelve TODAS las fotos del colegio sin filtrar por curso (ver
 * `/api/admin/fotos` en server.ts, que ya soportaba esto), y quien llama las agrupa por curso.
 */
export async function obtenerFotosActivasAdmin(params: {
  colegioId?: string;
  grado?: string;
  turno?: string;
  division?: string;
}): Promise<FotoRegistrada[]> {
  const r = await listarFotosActivasAdmin(params);
  return r.success ? r.fotos : [];
}

/**
 * Auditoría 03/10 noche (R10): antes cualquier error (sesión vencida, respuesta demasiado grande,
 * sin red, tiempo agotado) devolvía una lista VACÍA, y el panel decía "no hay fotos subidas" — Pablo
 * las volvía a subir. Ahora se distingue: `success: false` con el motivo = no se sabe qué hay.
 */
export interface ResultadoListaFotos {
  success: boolean;
  fotos: FotoRegistrada[];
  /** Sólo cuando success = false: por qué no se pudo leer (la lista vacía NO quiere decir "no hay fotos"). */
  error?: string;
}

export async function listarFotosActivasAdmin(params: {
  colegioId?: string;
  grado?: string;
  turno?: string;
  division?: string;
}): Promise<ResultadoListaFotos> {
  try {
    const query = new URLSearchParams();
    if (params.colegioId) query.set('colegioId', params.colegioId);
    if (params.grado) query.set('grado', params.grado);
    if (params.turno) query.set('turno', params.turno);
    if (params.division) query.set('division', params.division);

    const res = await fetchAdminAutenticado(`/api/admin/fotos?${query.toString()}`);
    if (res.status === 401) return { success: false, fotos: [], error: 'Tu sesión del panel venció: volvé a entrar.' };
    const data = await res.json().catch(() => null);
    if (!res.ok || !data?.success || !Array.isArray(data.fotos)) {
      const motivo = data?.error || (res.status === 413 || res.status >= 500 ? `el servidor respondió con un error (HTTP ${res.status}); puede ser que la lista sea demasiado grande` : `HTTP ${res.status}`);
      return { success: false, fotos: [], error: `No se pudo leer la lista de fotos: ${motivo}.` };
    }
    return { success: true, fotos: data.fotos.map(mapearFilaFoto) };
  } catch (err) {
    console.error('Error al obtener las fotos activas:', err);
    const detalle = err instanceof Error && err.message ? err.message : 'sin conexión con el servidor';
    return { success: false, fotos: [], error: `No se pudo leer la lista de fotos: ${detalle}` };
  }
}

/**
 * Panel admin: elimina una foto (fila en Supabase + sus tres archivos reales en Storage).
 * Auditoría 2026-09-26 (M8/M9): el borrado de archivos lo hace ahora el SERVIDOR (original HD,
 * muestra con marca de agua y miniatura) — antes el navegador borraba sólo la miniatura y el HD y
 * la muestra quedaba publicada. Si la foto está en un pedido ya pagado, el servidor responde 409
 * (`enUso`) y el panel pide confirmación antes de reintentar con `forzar`.
 */
export async function eliminarFotoActivaAdmin(
  foto: FotoRegistrada,
  opciones: { forzar?: boolean } = {}
): Promise<{ success: boolean; error?: string; enUso?: boolean }> {
  try {
    const res = await fetchAdminAutenticado(`/api/admin/fotos/${encodeURIComponent(foto.id)}${opciones.forzar ? '?forzar=1' : ''}`, {
      method: 'DELETE',
    });
    const data = await res.json().catch(() => null);
    if (!res.ok || !data?.success) {
      return { success: false, error: data?.error || 'No se pudo eliminar la foto.', enUso: Boolean(data?.enUso) };
    }
    if (data.advertencia) return { success: true, error: data.advertencia };
    return { success: true };
  } catch (err: any) {
    return { success: false, error: err?.message || 'Error de red al eliminar la foto.' };
  }
}

export interface ResultadoBorradoFotos {
  borradas: number;
  /** `enUso`: la foto está en pedidos ya pagados (se puede reintentar con `forzar`). */
  errores: { id: string; error: string; enUso?: boolean }[];
}

// Auditoría 03/10: el servidor ahora marca `enUso: true`; el texto queda sólo como respaldo para
// un servidor anterior que no mande el campo.
const TEXTO_FOTO_EN_USO = /pedido\(s\) ya pagado|confirm[aá] el borrado forzado/i;
function esErrorEnUso(e: any): boolean {
  if (typeof e?.enUso === 'boolean') return e.enUso;
  return TEXTO_FOTO_EN_USO.test(String(e?.error || ''));
}

const FOTOS_POR_BORRADO = 200;

/**
 * Auditoría 03/10 (bajo: "borrados de fotos de a una"): borra varias fotos con
 * `POST /api/admin/fotos/borrar` en tandas de 200, en vez de una llamada por foto. Si el
 * servidor todavía no tiene esa ruta (404), cae al borrado de a una de siempre.
 */
export async function eliminarFotosEnLoteAdmin(
  ids: string[],
  opciones: { forzar?: boolean; onProgreso?: (hechas: number, total: number) => void } = {}
): Promise<ResultadoBorradoFotos> {
  const resultado: ResultadoBorradoFotos = { borradas: 0, errores: [] };
  const unicos = [...new Set(ids)];
  for (let i = 0; i < unicos.length; i += FOTOS_POR_BORRADO) {
    const tanda = unicos.slice(i, i + FOTOS_POR_BORRADO);
    try {
      const res = await fetchAdminAutenticado('/api/admin/fotos/borrar', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ids: tanda, forzar: Boolean(opciones.forzar) }),
      });
      if (res.status === 404 && i === 0) {
        // Servidor anterior: de a una.
        for (const [n, id] of unicos.entries()) {
          const r = await eliminarFotoActivaAdmin({ id } as FotoRegistrada, { forzar: opciones.forzar });
          if (r.success) resultado.borradas++;
          else resultado.errores.push({ id, error: r.error || 'No se pudo eliminar la foto.', enUso: Boolean(r.enUso) });
          opciones.onProgreso?.(n + 1, unicos.length);
        }
        return resultado;
      }
      const data = await res.json().catch(() => null);
      if (!res.ok || !data?.success) {
        const error = data?.error || 'No se pudieron eliminar las fotos.';
        resultado.errores.push(...tanda.map((id) => ({ id, error })));
      } else {
        resultado.borradas += Number(data.borradas) || 0;
        if (Array.isArray(data.errores)) {
          resultado.errores.push(...data.errores.map((e: any) => ({ id: String(e?.id || ''), error: String(e?.error || 'No se pudo eliminar.'), enUso: esErrorEnUso(e) })));
        }
      }
    } catch (err: any) {
      const error = err?.message || 'Error de red al eliminar las fotos.';
      resultado.errores.push(...tanda.map((id) => ({ id, error })));
    }
    opciones.onProgreso?.(Math.min(i + tanda.length, unicos.length), unicos.length);
  }
  return resultado;
}

export interface ResultadoPublicarFotos {
  success: boolean;
  publicadas: number;
  emailsEnviados: number;
  warning?: string;
  error?: string;
}

/**
 * 06/10/2026 (pedido de Pablo): botón «Publicar». Publica las fotos sin publicar de un curso
 * (`colegioId` + `codigoCurso`) o las elegidas (`ids`, de a 2000). Si el curso no tenía ninguna
 * publicada, el servidor manda el aviso «ya están tus fotos» a las familias.
 */
export function publicarFotosAdmin(
  destino: { ids: string[] } | { colegioId: string; codigoCurso: string }
): Promise<ResultadoPublicarFotos> {
  // 14/10/2026: proceso en curso (pregunta antes de cerrar la pestaña; la recarga por versión nueva espera).
  return conProcesoEnCurso('Publicar fotos', () => publicarEnTandas(destino));
}

async function publicarEnTandas(
  destino: { ids: string[] } | { colegioId: string; codigoCurso: string }
): Promise<ResultadoPublicarFotos> {
  const tandas: Array<Record<string, unknown>> = [];
  if ('ids' in destino) {
    const unicos = [...new Set(destino.ids)];
    for (let i = 0; i < unicos.length; i += 2000) tandas.push({ ids: unicos.slice(i, i + 2000) });
  } else {
    tandas.push({ colegioId: destino.colegioId, codigoCurso: destino.codigoCurso });
  }
  const resultado: ResultadoPublicarFotos = { success: true, publicadas: 0, emailsEnviados: 0 };
  for (const cuerpo of tandas) {
    let error = '';
    try {
      const res = await fetchAdminAutenticado('/api/admin/fotos/publicar', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(cuerpo),
      });
      const data = await res.json().catch(() => ({}));
      if (res.ok && data.success) {
        resultado.publicadas += Number(data.publicadas) || 0;
        resultado.emailsEnviados += Number(data.emailsEnviados) || 0;
        resultado.warning = resultado.warning || data.warning;
        continue;
      }
      error = data.error || 'No se pudieron publicar las fotos.';
    } catch (err: any) {
      error = err?.message || 'Error de red al publicar las fotos.';
    }
    // 14/10/2026 (auditoría): si se perdió la respuesta, el servidor pudo haberlas publicado igual. Antes de
    // decir «no se pudieron publicar», se vuelven a leer esas fotos.
    const ids = Array.isArray(cuerpo.ids) ? (cuerpo.ids as string[]) : [];
    const yaPublicadas = ids.length > 0 ? await contarPublicadas(ids) : null;
    if (yaPublicadas !== null && yaPublicadas === ids.length) {
      resultado.publicadas += ids.length;
      resultado.warning = 'Se cortó la respuesta del servidor, pero las fotos quedaron publicadas. Si las familias no recibieron el email, usá «Reenviar aviso a las familias».';
      continue;
    }
    return { ...resultado, publicadas: resultado.publicadas + (yaPublicadas || 0), success: false, error };
  }
  return resultado;
}

/** Cuántas de esas fotos ya están publicadas según el servidor (null si tampoco se pudo leer). */
async function contarPublicadas(ids: string[]): Promise<number | null> {
  try {
    let publicadas = 0;
    for (let i = 0; i < ids.length; i += 1000) {
      const res = await fetchAdminAutenticado('/api/admin/fotos/por-ids', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ids: ids.slice(i, i + 1000) }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok || !data.success || !Array.isArray(data.fotos)) return null;
      publicadas += data.fotos.filter((f: any) => Boolean(f?.publicada_at)).length;
    }
    return publicadas;
  } catch {
    return null;
  }
}

/** 14/10/2026: vuelve a mandar el aviso «ya están tus fotos» a las familias de un curso. */
export async function reenviarAvisoFotosAdmin(colegioId: string, codigoCurso: string): Promise<{ success: boolean; emailsEnviados?: number; warning?: string; error?: string }> {
  try {
    const res = await fetchAdminAutenticado('/api/admin/fotos/reenviar-aviso', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ colegioId, codigoCurso }),
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok || !data.success) return { success: false, error: data.error || 'No se pudo reenviar el aviso.' };
    return { success: true, emailsEnviados: Number(data.emailsEnviados) || 0, warning: data.warning };
  } catch (err: any) {
    return { success: false, error: err?.message || 'Error de red al reenviar el aviso. Revisá antes de volver a tocar.' };
  }
}

/**
 * Panel admin: vacía por completo el catálogo de fotos (usado junto con "Limpiar Supabase").
 * Auditoría 2026-09-19: el servidor ahora exige la frase exacta "BORRAR TODAS LAS FOTOS" (mismo
 * criterio que "Cerrar año") antes de ejecutar el borrado — evita que un solo click accidental
 * (o un token de admin filtrado) borre todo el catálogo sin posibilidad de deshacer.
 */
export async function limpiarTodasLasFotosAdmin(confirmacion: string): Promise<{ success: boolean; error?: string }> {
  try {
    const res = await fetchAdminAutenticado('/api/admin/fotos', {
      method: 'DELETE',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ confirmacion }),
    });
    const data = await res.json();
    if (!res.ok || !data.success) {
      return { success: false, error: data.error || 'No se pudo limpiar el catálogo de fotos.' };
    }
    return { success: true };
  } catch (err: any) {
    return { success: false, error: err?.message || 'Error de red al limpiar el catálogo de fotos.' };
  }
}

export interface ResultadoRegenerarMiniaturas {
  success: boolean;
  procesadas?: number;
  fallidas?: number;
  restantes?: number;
  error?: string;
}

/**
 * Panel admin: migración de fotos ya subidas ANTES de tener miniatura propia — genera,
 * a partir del original guardado en el bucket privado, una miniatura chica y sin marca de
 * agua para cada una. Procesa de a un lote chico por llamada (el servidor la corta sola
 * para no exceder el tiempo máximo de una función serverless), por eso se llama en un
 * bucle hasta que "restantes" llega a 0.
 */
export async function regenerarMiniaturasAdmin(limite = 12): Promise<ResultadoRegenerarMiniaturas> {
  try {
    const res = await fetchAdminAutenticado('/api/admin/fotos/regenerar-miniaturas', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ limite }),
    });
    const data = await res.json();
    if (!res.ok || !data.success) {
      return { success: false, error: data.error || 'No se pudieron regenerar las miniaturas.' };
    }
    return { success: true, procesadas: data.procesadas || 0, fallidas: data.fallidas || 0, restantes: data.restantes || 0 };
  } catch (err: any) {
    return { success: false, error: err?.message || 'Error de red al regenerar las miniaturas.' };
  }
}

export interface ResultadoRegenerarMarcaAgua {
  success: boolean;
  procesadas?: number;
  fallidas?: number;
  restantes?: number;
  siguienteOffset?: number;
  error?: string;
}

/**
 * Panel admin: re-genera la copia ampliada (con marca de agua quemada) de TODAS las fotos
 * ya subidas, usando la nueva versión más liviana y espaciada de la marca de agua — a partir
 * del original guardado, sin volver a subir nada. Se procesa de a un lote chico por llamada,
 * avanzando con `offset` hasta que "restantes" llega a 0.
 */
export async function regenerarMarcaAguaAdmin(limite = 8, offset = 0): Promise<ResultadoRegenerarMarcaAgua> {
  try {
    const res = await fetchAdminAutenticado('/api/admin/fotos/regenerar-marca-agua', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ limite, offset }),
    });
    const data = await res.json();
    if (!res.ok || !data.success) {
      return { success: false, error: data.error || 'No se pudo regenerar la marca de agua.' };
    }
    return {
      success: true,
      procesadas: data.procesadas || 0,
      fallidas: data.fallidas || 0,
      restantes: data.restantes || 0,
      siguienteOffset: data.siguienteOffset || 0,
    };
  } catch (err: any) {
    return { success: false, error: err?.message || 'Error de red al regenerar la marca de agua.' };
  }
}

export interface SeccionGaleria {
  colegioId: string;
  grado: string;
  turno: string;
  division: string;
}

export interface ResultadoGaleriaPublica {
  fotos: Foto[];
  /** Sección real confirmada por el servidor a partir del código. */
  seccion: SeccionGaleria | null;
  /**
   * Auditoría 03/10 (alto 23): antes cualquier falla volvía como "galería vacía" y el portal decía
   * "tus fotos todavía no fueron ingresadas" aunque el problema fuera la red o un código vencido.
   * - 'ok': hay fotos · 'vacia': el código es válido pero el curso todavía no tiene fotos
   * - 'codigo_invalido': el servidor rechazó el código (401/403: incorrecto o vencido)
   * - 'error': red, tiempo agotado, 429 o 5xx (vale la pena reintentar)
   */
  estado: 'ok' | 'vacia' | 'codigo_invalido' | 'error';
  error?: string;
}

/**
 * Galería pública para el portal de familias: trae las fotos reales del curso al que
 * pertenece un código de acceso válido.
 *
 * IMPORTANTE — SEGURIDAD: antes esta función (y el endpoint `/api/fotos`) recibían
 * directamente grado/turno/división, que son datos públicos visibles en un combo del sitio.
 * Eso permitía ver las fotos reales de cualquier curso sin ningún código, con sólo elegir las
 * opciones del desplegable. Ahora la ÚNICA llave es el código secreto de la sección: el
 * servidor lo valida contra `codigos_seccion` y es quien decide a qué grado/turno/división
 * corresponde — nunca se confía en lo que mande el navegador. Sin un código válido, se
 * se devuelve una galería vacía. Nunca se mezclan fotos genéricas con las reales.
 */
export async function obtenerGaleriaPublica(params: { codigo?: string | null; familiaId?: string | null; acceso?: string | null }): Promise<ResultadoGaleriaPublica> {
  const codigo = (params.codigo || '').trim();
  if (!codigo) {
    return { fotos: [], seccion: null, estado: 'vacia' };
  }
  try {
    const query = new URLSearchParams();
    query.set('codigo', codigo);
    // Llave de la familia (28/9): sin ella el servidor no manda fotos individuales etiquetadas.
    if (params.familiaId && params.acceso) {
      query.set('familia', params.familiaId);
      query.set('acceso', params.acceso);
    }

    const res = await fetchConTimeout(`/api/fotos?${query.toString()}`);
    const data = await res.json().catch(() => ({}));
    if (res.status === 401 || res.status === 403) {
      return { fotos: [], seccion: null, estado: 'codigo_invalido', error: data?.error || 'Código de acceso incorrecto o vencido.' };
    }
    if (res.status === 429) {
      return { fotos: [], seccion: null, estado: 'error', error: MENSAJE_DEMASIADOS_INTENTOS };
    }
    if (!res.ok || !data.success) {
      return { fotos: [], seccion: null, estado: 'error', error: 'No pudimos cargar las fotos en este momento.' };
    }

    const seccion: SeccionGaleria | null = data.seccion
      ? {
          colegioId: data.seccion.colegioId,
          grado: data.seccion.grado,
          turno: data.seccion.turno,
          division: data.seccion.division,
        }
      : null;

    if (!Array.isArray(data.fotos) || data.fotos.length === 0) {
      return { fotos: [], seccion, estado: 'vacia' };
    }

    const fotos = data.fotos.map((row: any): Foto => {
      const categoria = row.categoria as CategoriaFoto;
      // La vista ampliada usa la copia con la marca de agua quemada en los píxeles
      // (preview_path). La miniatura de la grilla usa la copia chica y limpia (thumb_path)
      // cuando existe; si la foto se subió antes de tener miniatura propia, cae de nuevo
      // en la versión con marca de agua como respaldo.
      const url = row.preview_path || row.thumb_path || row.storage_path || '';
      const thumbnail = row.thumb_path || row.preview_path || row.storage_path || '';
      return {
        id: row.id,
        url,
        thumbnail,
        // 04/10: la lupa pide los pedacitos nítidos con las mismas llaves que la galería (sólo si el
        // colegio tiene prendido «Muestras con lupa»).
        lupaUrl: data.lupa === true ? `/api/fotos/${encodeURIComponent(row.id)}/lupa?${query.toString()}` : undefined,
        categoria,
        // 06/10: la de familia/amigos la ve todo el curso: nunca lleva el nombre de un chico en el título.
        titulo: categoria === 'familia'
          ? 'Foto con familia/amigos'
          : row.alumno_nombre
            ? `${row.alumno_nombre} (${categoria})`
            : `Foto ${categoria}`,
        descripcion: categoria === 'familia' ? 'Foto con familia y/o amigos del curso' : `Foto ${categoria} del curso`,
        alumnoNombre: row.alumno_nombre || undefined,
        grado: row.grado || undefined,
        division: row.division || undefined,
        numero: row.numero ? String(row.numero) : undefined,
      };
    });

    return { fotos, seccion, estado: 'ok' };
  } catch (err) {
    console.error('Error al obtener la galería de fotos:', err);
    return {
      fotos: [],
      seccion: null,
      estado: 'error',
      error: err instanceof ErrorTiempoAgotado ? err.message : 'No pudimos cargar las fotos (sin conexión).',
    };
  }
}

/**
 * Auditoría 2026-09-26 (M8): limpieza de archivos huérfanos del almacenamiento (fotos que ya no
 * están en el catálogo y .zip de pedidos no cobrados). Con `aplicar: false` sólo cuenta.
 */
export interface ResultadoLimpiezaHuerfanos {
  success: boolean;
  aplicado?: boolean;
  muestrasPublicasHuerfanas?: number;
  originalesHdHuerfanos?: number;
  zipsSinPedidoCobrado?: number;
  borrados?: number;
  error?: string;
}

export async function limpiarArchivosHuerfanosAdmin(aplicar: boolean): Promise<ResultadoLimpiezaHuerfanos> {
  try {
    const res = await fetchAdminAutenticado('/api/admin/storage/limpiar-huerfanos', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ aplicar }),
    });
    const data = await res.json().catch(() => null);
    if (!res.ok || !data?.success) return { success: false, error: data?.error || 'No se pudo revisar el almacenamiento.' };
    return data;
  } catch (err: any) {
    return { success: false, error: err?.message || 'Error de red al revisar el almacenamiento.' };
  }
}
