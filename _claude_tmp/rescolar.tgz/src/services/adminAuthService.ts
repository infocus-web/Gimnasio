/**
 * Servicio de autenticación segura del Panel de Administración contra el servidor
 */
import { TIMEOUT_FETCH_MS, fetchConTimeout } from '../utils/fetchConTimeout';

const ADMIN_TOKEN_KEY = 'infocus_admin_session_token';

/**
 * Auditoría 03/10 noche: tiempo máximo de los pedidos del panel. Las lecturas (GET) cortan a los
 * 15 s. Las escrituras (POST/DELETE…) pueden tardar de verdad (armar el ZIP HD, mandar emails en
 * tanda, regenerar miniaturas, cerrar el año): se les da 65 s, un poco más que el límite de 60 s
 * de la función de Vercel (pasado ese tiempo el servidor ya no puede contestar), así nunca se corta
 * una respuesta que iba a llegar. Quien necesite otro tope lo pasa como tercer parámetro.
 */
export const TIMEOUT_ESCRITURA_ADMIN_MS = 65_000;

export function tiempoMaximoPorMetodo(options: RequestInit = {}): number {
  const metodo = String(options.method || 'GET').toUpperCase();
  return metodo === 'GET' || metodo === 'HEAD' ? TIMEOUT_FETCH_MS : TIMEOUT_ESCRITURA_ADMIN_MS;
}

/**
 * Auditoría 03/10 noche: el panel guarda la lista completa de familias/pedidos en este navegador
 * (con nombres, emails y teléfonos). Se borra al cerrar la sesión del panel para que no quede en
 * una compu compartida.
 */
const CLAVES_DATOS_PANEL = ['infocus_pedidos_escolares_v1', 'infocus_pedidos_escolares_v1_sincronizado'];

export function borrarDatosLocalesDelPanel(): void {
  try {
    for (const clave of CLAVES_DATOS_PANEL) localStorage.removeItem(clave);
  } catch {
    // localStorage no disponible (modo privado estricto): no hay nada guardado que borrar.
  }
}

export interface LoginResult {
  success: boolean;
  token?: string;
  error?: string;
}

export async function loginAdminConServidor(pin: string): Promise<LoginResult> {
  try {
    // Auditoría 11/10: con tiempo máximo (antes el botón podía quedar esperando para siempre).
    const res = await fetchConTimeout('/api/admin/login', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ pin }),
    });

    const data = await res.json();
    if (res.ok && data.success && data.token) {
      if (typeof window !== 'undefined') {
        // Auditoría 11/10: con el almacenamiento bloqueado esto tiraba y se mostraba "Error al conectar".
        try {
          sessionStorage.setItem(ADMIN_TOKEN_KEY, data.token);
        } catch {
          // sin sessionStorage: se intenta localStorage abajo
        }
        // Auditoría 2026-09-21 (pedido de Pablo: escanear el QR del sobre con la cámara del
        // celular para avisar "Listo para retirar"). sessionStorage no alcanza para ese flujo:
        // cada vez que la app de cámara abre el link del QR en una pestaña NUEVA, esa pestaña
        // arranca con sessionStorage vacío (es por-pestaña, no se hereda), así que Pablo tendría
        // que volver a tipear el PIN en cada escaneo. Se guarda también en localStorage —
        // persiste entre pestañas y reinicios del navegador — para que loguearse una vez alcance
        // durante toda la validez real del token (24hs, ver verifyAdminToken en el servidor).
        try {
          localStorage.setItem(ADMIN_TOKEN_KEY, data.token);
        } catch {
          // localStorage puede fallar en modo privado estricto — no es crítico, sessionStorage
          // igual sigue funcionando para la pestaña actual.
        }
      }
      return { success: true, token: data.token };
    }

    return {
      success: false,
      error: data.error || 'PIN de fotógrafo incorrecto.',
    };
  } catch (err: any) {
    console.error('Error al autenticar admin en servidor:', err);
    return {
      success: false,
      error: 'Error al conectar con el servidor de autenticación.',
    };
  }
}

export function obtenerTokenAdmin(): string | null {
  if (typeof window === 'undefined') return null;
  // Se prioriza sessionStorage (comportamiento de siempre para el panel de escritorio), y si esta
  // pestaña no tiene nada ahí, se cae a localStorage — el caso real es una pestaña nueva abierta
  // por la app de cámara al escanear el QR de un sobre, que nace sin sessionStorage propio.
  // Auditoría 11/10: leer sessionStorage tira con el almacenamiento bloqueado (y tiraba abajo la home).
  try {
    const deSesion = sessionStorage.getItem(ADMIN_TOKEN_KEY);
    if (deSesion) return deSesion;
  } catch {
    // sin sessionStorage: se prueba localStorage
  }
  try {
    return localStorage.getItem(ADMIN_TOKEN_KEY);
  } catch {
    return null;
  }
}

export function cerrarSesionAdmin(): void {
  if (typeof window !== 'undefined') {
    try {
      sessionStorage.removeItem(ADMIN_TOKEN_KEY);
    } catch {
      // sin sessionStorage: no hay nada que borrar ahí
    }
    try {
      localStorage.removeItem(ADMIN_TOKEN_KEY);
    } catch {
      // Ídem arriba: si localStorage no está disponible, no hay nada que limpiar ahí.
    }
  }
}

/**
 * Auditoría 03/10 noche: "Cerrar sesión" del panel (lo toca Pablo a propósito). Además del token
 * borra la copia local de las familias. No se usa cuando el token vence solo (401), para no perder
 * la copia de respaldo en pleno trabajo.
 */
export function cerrarSesionAdminYBorrarDatos(): void {
  cerrarSesionAdmin();
  borrarDatosLocalesDelPanel();
}

export async function verificarSesionAdmin(): Promise<boolean> {
  const token = obtenerTokenAdmin();
  if (!token) return false;

  try {
    const res = await fetchConTimeout('/api/admin/verify', {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });
    if (!res.ok) {
      // Auditoría 2026-09-24: sólo un 401/403 significa que el token venció o es inválido. Un
      // error pasajero del servidor (500, 429, corte de red) antes borraba la sesión y obligaba
      // a reingresar el PIN en pleno reparto de sobres.
      if (res.status === 401 || res.status === 403) cerrarSesionAdmin();
      return false;
    }
    const data = await res.json();
    return Boolean(data.valid);
  } catch {
    return false;
  }
}

export async function fetchAdminAutenticado(url: string, options: RequestInit = {}, ms: number = tiempoMaximoPorMetodo(options)): Promise<Response> {
  const token = obtenerTokenAdmin();
  const headers = new Headers(options.headers || {});
  if (token) {
    headers.set('Authorization', `Bearer ${token}`);
  }
  // Auditoría 03/10 noche: con tiempo máximo (antes podía quedar esperando para siempre).
  return fetchConTimeout(url, {
    ...options,
    headers,
  }, ms);
}

/**
 * Actualiza el estado de un pedido en Supabase mediante el servidor Express con token admin
 */
export async function actualizarEstadoPedidoAdmin(
  pedidoId: string,
  updates: { estadoPago?: string; estadoEntrega?: string; reactivar?: boolean; estadoAnterior?: string }
): Promise<{
  success: boolean;
  error?: string;
  linkDescargaHD?: string;
  pedido?: any;
  // Auditoría 03/10: el servidor responde 409 con `codigo` cuando no puede aplicar el cambio:
  // 'CANCELADO_DEFINITIVO' (arrepentimiento/reembolso/cancelado a mano: sólo con reactivar:true)
  // o 'ESTADO_CAMBIO' (el pedido ya cambió de estado; hay que recargar la lista) o 'MEJORA_DUPLICADA'
  // (08/10: se quiso reactivar una mejora a Kit Impreso y el kit ya tiene otra activa).
  codigo?: 'CANCELADO_DEFINITIVO' | 'ESTADO_CAMBIO' | 'MEJORA_DUPLICADA' | 'SESION_VENCIDA' | string;
  estadoActual?: string;
  /** 14/10/2026: la respuesta se perdió, pero al releer el pedido ya figuraba pagado. */
  confirmadoAlReleer?: boolean;
}> {
  try {
    const res = await fetchAdminAutenticado(`/api/admin/pedidos/${encodeURIComponent(pedidoId)}/estado`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(updates),
    });
    // 14/10/2026 (auditoría): sesión vencida ≠ «no se pudo»: se avisa que hay que volver a ingresar.
    if (res.status === 401) return { success: false, codigo: 'SESION_VENCIDA', error: 'Tu sesión del panel venció: volvé a ingresar con el PIN y probá de nuevo. El pago NO quedó aprobado.' };
    const data = await res.json().catch(() => null);
    if (data) return data;
    return (await confirmarAprobacionReleyendo(pedidoId, updates)) || { success: false, error: `El servidor respondió ${res.status}.` };
  } catch (err: any) {
    return (await confirmarAprobacionReleyendo(pedidoId, updates)) || { success: false, error: err?.message || 'Error de red' };
  }
}

/**
 * 14/10/2026 (auditoría): si al aprobar un pago se cortó la conexión (o venció el tiempo), el servidor pudo
 * haberlo aprobado igual. Antes de revertir y decir «no se pudo», se relee el pedido: si ya figura pagado,
 * se toma como confirmado (con el link HD que haya guardado el servidor).
 */
async function confirmarAprobacionReleyendo(pedidoId: string, updates: { estadoPago?: string }) {
  if (updates.estadoPago !== 'aprobado' && updates.estadoPago !== 'pagado') return null;
  try {
    const res = await fetchAdminAutenticado(`/api/admin/pedidos/${encodeURIComponent(pedidoId)}/resumen`);
    const data = await res.json().catch(() => ({}));
    if (!res.ok || !data?.success || data.pedido?.estado !== 'pagado') return null;
    return { success: true, confirmadoAlReleer: true, linkDescargaHD: data.pedido.linkDescargaHD || undefined };
  } catch {
    return null;
  }
}

/**
 * Elimina un pedido mediante el servidor Express con token admin
 */
export async function eliminarPedidoAdmin(pedidoId: string): Promise<{ success: boolean; error?: string }> {
  try {
    const res = await fetchAdminAutenticado(`/api/admin/pedidos/${encodeURIComponent(pedidoId)}`, {
      method: 'DELETE',
    });
    const data = await res.json();
    return data;
  } catch (err: any) {
    return { success: false, error: err?.message || 'Error de red' };
  }
}

/**
 * Elimina una foto mediante el servidor Express con token admin
 */
export async function eliminarFotoAdmin(fotoId: string): Promise<{ success: boolean; error?: string }> {
  try {
    const res = await fetchAdminAutenticado(`/api/admin/fotos/${encodeURIComponent(fotoId)}`, {
      method: 'DELETE',
    });
    const data = await res.json();
    return data;
  } catch (err: any) {
    return { success: false, error: err?.message || 'Error de red' };
  }
}
