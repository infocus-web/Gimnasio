import { fetchAdminAutenticado } from './adminAuthService';
import { fetchConTimeout } from '../utils/fetchConTimeout';
import type { LugarPack, MotivoFaltante } from '../utils/fotosFaltantes';

// «Faltantes solicitadas» (22/10/2026): la familia pide que le saquen (o busquen) la foto que le falta al chico.
// Rutas en servidor/familias/solicitudesFaltantes.ts.

export interface SolicitudFaltanteFamilia {
  id: string;
  alumno_nombre: string;
  lugar: LugarPack;
  motivo: MotivoFaltante;
  estado: 'pendiente' | 'resuelta' | 'cancelada';
  created_at: string;
  /** 25/10: convocatoria para sacar la foto (día AAAA-MM-DD, hora y lugar), si ya se mandó. */
  convocatoria_dia?: string | null;
  convocatoria_hora?: string | null;
  convocatoria_lugar?: string | null;
}

export interface SolicitudFaltanteAdmin extends SolicitudFaltanteFamilia {
  colegio_id: string;
  codigo_curso: string;
  grado: string | null;
  division: string | null;
  turno: string | null;
  tutor_nombre: string | null;
  contacto_email: string | null;
  contacto_whatsapp: string | null;
  nomina_tiene_foto: boolean | null;
  resuelta_at: string | null;
  cancelada_at: string | null;
  cancelada_por: 'familia' | 'admin' | null;
  aviso_enviado_at: string | null;
  convocatoria_nota?: string | null;
  convocada_at?: string | null;
}

export interface AccesoFamiliaFaltantes {
  codigo: string;
  familia: string;
  acceso: string;
  alumnoNombre: string;
}

export const MOTIVOS_FALTANTE: { valor: MotivoFaltante; etiqueta: string; panel: string }[] = [
  { valor: 'ausente', etiqueta: 'No estuvo el día de la foto', panel: 'Ausente' },
  { valor: 'no_quiso', etiqueta: 'Estuvo, pero no quiso sacarse esa foto', panel: 'No quiso' },
  { valor: 'no_encontrada', etiqueta: 'Se la sacaron, pero no la encontramos en la galería', panel: 'Revisar subida' },
];

async function leerJson(res: Response): Promise<any> {
  return res.json().catch(() => ({}));
}

async function postFamilia(ruta: string, cuerpo: unknown): Promise<any> {
  try {
    const res = await fetchConTimeout(ruta, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(cuerpo) });
    const data = await leerJson(res);
    return res.ok && data.success ? data : { success: false, error: data?.error || 'No pudimos completar la operación. Probá de nuevo.' };
  } catch {
    return { success: false, error: 'Error de conexión. Probá de nuevo.' };
  }
}

export const estadoFaltantes = (acceso: AccesoFamiliaFaltantes): Promise<{ success: boolean; abierto?: boolean; solicitudes?: SolicitudFaltanteFamilia[]; error?: string }> =>
  postFamilia('/api/fotos-faltantes/estado', acceso);

export const solicitarFaltante = (
  acceso: AccesoFamiliaFaltantes,
  datos: { lugar: LugarPack; motivo: MotivoFaltante; email: string; whatsapp: string; tutorNombre: string; clave: string }
): Promise<{ success: boolean; solicitud?: SolicitudFaltanteFamilia; error?: string }> => postFamilia('/api/fotos-faltantes/solicitar', { ...acceso, ...datos });

export const cancelarFaltante = (acceso: AccesoFamiliaFaltantes, id: string): Promise<{ success: boolean; error?: string }> =>
  postFamilia(`/api/fotos-faltantes/${encodeURIComponent(id)}/cancelar`, acceso);

export async function obtenerFaltantesAdmin(colegioId: string): Promise<{ success: boolean; solicitudes: SolicitudFaltanteAdmin[]; error?: string }> {
  try {
    const res = await fetchAdminAutenticado(`/api/admin/fotos-faltantes?colegioId=${encodeURIComponent(colegioId)}`);
    const data = await leerJson(res);
    if (!res.ok || !data.success) return { success: false, solicitudes: [], error: data?.error || 'No se pudieron cargar las fotos faltantes.' };
    return { success: true, solicitudes: data.solicitudes || [] };
  } catch (err: any) {
    return { success: false, solicitudes: [], error: err?.message || 'Error de conexión.' };
  }
}

export async function accionFaltanteAdmin(id: string, accion: 'resolver' | 'descartar', opciones: { forzar?: boolean } = {}): Promise<{ success: boolean; solicitud?: SolicitudFaltanteAdmin; avisoEnviado?: boolean; error?: string; codigo?: string }> {
  try {
    const res = await fetchAdminAutenticado(`/api/admin/fotos-faltantes/${encodeURIComponent(id)}/${accion}`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(opciones.forzar ? { forzar: true } : {}) });
    const data = await leerJson(res);
    if (!res.ok || !data.success) return { success: false, error: data?.error || 'No se pudo completar la acción.', codigo: data?.codigo };
    return { success: true, solicitud: data.solicitud, avisoEnviado: data.avisoEnviado };
  } catch (err: any) {
    return { success: false, error: err?.message || 'Error de conexión.' };
  }
}

/** 25/10/2026: «Convocar» — mail a las familias con el día, la hora y el lugar para sacar la foto (no la grupal). */
export async function convocarFaltantesAdmin(
  ids: string[],
  datos: { dia: string; hora: string; lugar: string; nota: string }
): Promise<{ success: boolean; familiasConvocadas?: number; pedidosConvocados?: number; omitidos?: number; sinEmail?: string[]; fallidos?: string[]; error?: string }> {
  try {
    const res = await fetchAdminAutenticado('/api/admin/fotos-faltantes/convocar', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ ids, ...datos }) });
    const data = await leerJson(res);
    if (!res.ok || !data.success) return { success: false, error: data?.error || 'No se pudo mandar la convocatoria.' };
    return data;
  } catch (err: any) {
    return { success: false, error: err?.message || 'Error de conexión.' };
  }
}

/** «sábado 07/11» a partir de «2026-11-07». */
export function diaConvocatoria(dia: string | null | undefined): string {
  if (!dia) return '';
  const d = new Date(`${dia}T12:00:00-03:00`);
  return Number.isNaN(d.getTime()) ? dia : d.toLocaleDateString('es-AR', { weekday: 'long', day: '2-digit', month: '2-digit', timeZone: 'America/Argentina/Buenos_Aires' });
}
