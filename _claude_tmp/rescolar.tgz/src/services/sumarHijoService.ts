// 27/10/2026: «Sumar hijo» desde Inscriptos (ver servidor/familias/sumarHijo.ts).
import { fetchAdminAutenticado } from './adminAuthService';

export interface AlumnoNominaCandidato {
  id: string;
  nombre: string;
  grado: string;
  division: string;
  turno: string | null;
  yaIncluido: boolean;
}

export async function buscarHijosEnNomina(inscripcionId: string, q: string): Promise<{ success: boolean; alumnos?: AlumnoNominaCandidato[]; error?: string }> {
  try {
    const res = await fetchAdminAutenticado(`/api/admin/inscripciones/${encodeURIComponent(inscripcionId)}/nomina-hijos?q=${encodeURIComponent(q)}`);
    const data = await res.json().catch(() => null);
    if (!res.ok || !data?.success) return { success: false, error: data?.error || 'No se pudo buscar en la nómina.' };
    return { success: true, alumnos: data.alumnos || [] };
  } catch (err: any) {
    return { success: false, error: err?.message || 'Error de red al buscar en la nómina.' };
  }
}

export async function sumarHijoAInscripcion(inscripcionId: string, alumnoId: string): Promise<{ success: boolean; error?: string }> {
  try {
    const res = await fetchAdminAutenticado(`/api/admin/inscripciones/${encodeURIComponent(inscripcionId)}/hermanos`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ alumnoId }),
    });
    const data = await res.json().catch(() => null);
    if (!res.ok || !data?.success) return { success: false, error: data?.error || 'No se pudo sumar al alumno.' };
    return { success: true };
  } catch (err: any) {
    return { success: false, error: err?.message || 'Error de red al sumar al alumno.' };
  }
}
