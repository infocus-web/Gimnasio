import { fetchAdminAutenticado } from './adminAuthService';

// Observaciones de la toma de fotos (13/10/2026): lo que pasó con un alumno de la nómina el día de las fotos.
// Rutas en servidor/panel/observaciones.ts (sólo admin).

export type TipoObservacion = 'sin_foto_individual' | 'sin_foto_grupal' | 'ausente' | 'otra';

export const TIPOS_OBSERVACION: { valor: TipoObservacion; etiqueta: string }[] = [
  { valor: 'sin_foto_individual', etiqueta: 'No quiso foto individual' },
  { valor: 'sin_foto_grupal', etiqueta: 'No quiso foto grupal' },
  { valor: 'ausente', etiqueta: 'Ausente el día de la foto' },
  { valor: 'otra', etiqueta: 'Otra' },
];

export const etiquetaTipoObservacion = (tipo: string) =>
  TIPOS_OBSERVACION.find((t) => t.valor === tipo)?.etiqueta || tipo;

export interface ObservacionAlumno {
  id: string;
  colegio_id: string;
  alumno_id: string | null;
  alumno_nombre: string;
  grado: string | null;
  division: string | null;
  turno: string | null;
  tipo: TipoObservacion;
  detalle: string | null;
  created_at: string;
}

async function leerJson(res: Response): Promise<any> {
  return res.json().catch(() => ({}));
}

export async function obtenerObservacionesAdmin(colegioId: string): Promise<{ success: boolean; observaciones: ObservacionAlumno[]; error?: string }> {
  try {
    const res = await fetchAdminAutenticado(`/api/admin/observaciones?colegioId=${encodeURIComponent(colegioId)}`);
    const data = await leerJson(res);
    if (!res.ok || !data.success) return { success: false, observaciones: [], error: data?.error || 'No se pudieron cargar las observaciones.' };
    return { success: true, observaciones: data.observaciones || [] };
  } catch (err: any) {
    return { success: false, observaciones: [], error: err?.message || 'Error de conexión.' };
  }
}

export async function crearObservacionAdmin(
  alumnoId: string,
  tipo: TipoObservacion,
  detalle: string,
  clave?: string // 14/10/2026: con la misma clave, un reintento no anota la observación dos veces
): Promise<{ success: boolean; observacion?: ObservacionAlumno; error?: string }> {
  try {
    const res = await fetchAdminAutenticado('/api/admin/observaciones', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(clave ? { alumnoId, tipo, detalle, clave } : { alumnoId, tipo, detalle }),
    });
    const data = await leerJson(res);
    if (!res.ok || !data.success) return { success: false, error: data?.error || 'No se pudo guardar la observación.' };
    return { success: true, observacion: data.observacion };
  } catch (err: any) {
    return { success: false, error: err?.message || 'Error de conexión.' };
  }
}

export async function borrarObservacionAdmin(id: string): Promise<{ success: boolean; error?: string }> {
  try {
    const res = await fetchAdminAutenticado(`/api/admin/observaciones/${encodeURIComponent(id)}`, { method: 'DELETE' });
    const data = await leerJson(res);
    if (!res.ok || !data.success) return { success: false, error: data?.error || 'No se pudo borrar la observación.' };
    return { success: true };
  } catch (err: any) {
    return { success: false, error: err?.message || 'Error de conexión.' };
  }
}
