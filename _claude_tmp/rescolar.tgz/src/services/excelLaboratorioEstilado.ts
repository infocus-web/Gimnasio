import type { Workbook, Worksheet, Cell, Fill } from 'exceljs';
import { descargarBlobSeguro } from './excelDownloadHelper';
import type { LoteLab, ResumenFacturacion, PedidoLab } from './laboratorioService';
import { formatearCodigoCliente } from './pedidosLabService';

/**
 * Planillas del laboratorio con formato (28/9/2026, pedido de Pablo: "el excel no es muy
 * atractivo"). Usa exceljs (carga diferida, sólo cuando se descarga) para tener colores, bordes,
 * títulos y totales con fórmula. Los colores siguen al panel: ámbar, violeta, celeste y pizarra.
 */
const C = {
  oscuro: 'FF0F172A',
  oscuro2: 'FF1E293B',
  gris: 'FF64748B',
  grisClaro: 'FFF1F5F9',
  borde: 'FFE2E8F0',
  blanco: 'FFFFFFFF',
  ambar: 'FFFBBF24',
  ambarClaro: 'FFFEF3C7',
  ambarTexto: 'FF92400E',
  violeta: 'FF7C3AED',
  violetaClaro: 'FFEDE9FE',
  violetaTexto: 'FF5B21B6',
  celeste: 'FF0EA5E9',
  verdeClaro: 'FFD1FAE5',
  verdeTexto: 'FF065F46',
  rojoClaro: 'FFFEE2E2',
  rojoTexto: 'FF991B1B',
};

const relleno = (argb: string): Fill => ({ type: 'pattern', pattern: 'solid', fgColor: { argb } });
const bordeFino = { style: 'thin' as const, color: { argb: C.borde } };
const bordes = { top: bordeFino, left: bordeFino, bottom: bordeFino, right: bordeFino };

async function nuevoLibro(): Promise<Workbook> {
  const ExcelJS = (await import('exceljs')).default;
  const wb = new ExcelJS.Workbook();
  wb.creator = 'Retrato Escolar';
  wb.created = new Date();
  return wb;
}

async function descargar(wb: Workbook, nombre: string): Promise<boolean> {
  const buffer = await wb.xlsx.writeBuffer();
  const blob = new Blob([buffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
  return descargarBlobSeguro(blob, nombre);
}

/** Banda de título (fila 1) y subtítulo (fila 2) a lo ancho de `columnas`. */
function encabezado(ws: Worksheet, columnas: number, titulo: string, subtitulo: string) {
  ws.mergeCells(1, 1, 1, columnas);
  ws.mergeCells(2, 1, 2, columnas);
  const t = ws.getCell(1, 1);
  t.value = titulo;
  t.font = { name: 'Calibri', size: 16, bold: true, color: { argb: C.blanco } };
  t.alignment = { vertical: 'middle', indent: 1 };
  const s = ws.getCell(2, 1);
  s.value = subtitulo;
  s.font = { name: 'Calibri', size: 10, color: { argb: 'FFCBD5E1' } };
  s.alignment = { vertical: 'middle', indent: 1 };
  for (let c = 1; c <= columnas; c++) {
    ws.getCell(1, c).fill = relleno(C.oscuro);
    ws.getCell(2, c).fill = relleno(C.oscuro2);
  }
  ws.getRow(1).height = 30;
  ws.getRow(2).height = 20;
  // Línea ámbar debajo del título, como el panel.
  for (let c = 1; c <= columnas; c++) ws.getCell(3, c).fill = relleno(C.ambar);
  ws.getRow(3).height = 4;
}

/** Tarjetas de totales: etiqueta arriba, número grande abajo. */
function tarjetas(ws: Worksheet, fila: number, items: { etiqueta: string; valor: number; fondo: string; texto: string }[], anchoPorTarjeta = 1) {
  items.forEach((it, i) => {
    const col = 1 + i * anchoPorTarjeta;
    if (anchoPorTarjeta > 1) {
      ws.mergeCells(fila, col, fila, col + anchoPorTarjeta - 1);
      ws.mergeCells(fila + 1, col, fila + 1, col + anchoPorTarjeta - 1);
    }
    const e = ws.getCell(fila, col);
    e.value = it.etiqueta.toUpperCase();
    e.font = { size: 9, bold: true, color: { argb: it.texto } };
    e.alignment = { horizontal: 'left', vertical: 'bottom', indent: 1 };
    const v = ws.getCell(fila + 1, col);
    v.value = it.valor;
    v.font = { size: 22, bold: true, color: { argb: it.texto } };
    v.alignment = { horizontal: 'left', vertical: 'middle', indent: 1 };
    for (let c = col; c < col + anchoPorTarjeta; c++) {
      ws.getCell(fila, c).fill = relleno(it.fondo);
      ws.getCell(fila + 1, c).fill = relleno(it.fondo);
    }
  });
  ws.getRow(fila).height = 20;
  ws.getRow(fila + 1).height = 34;
}

function filaCabecera(ws: Worksheet, fila: number, titulos: string[]) {
  const r = ws.getRow(fila);
  titulos.forEach((t, i) => {
    const c = r.getCell(i + 1);
    c.value = t;
    c.font = { bold: true, size: 10, color: { argb: C.blanco } };
    c.fill = relleno(C.oscuro2);
    c.alignment = { horizontal: i === 0 ? 'left' : 'center', vertical: 'middle', wrapText: true, indent: i === 0 ? 1 : 0 };
    c.border = bordes;
  });
  r.height = 26;
}

function estiloCelda(c: Cell, zebra: boolean, centrar: boolean) {
  c.fill = relleno(zebra ? C.grisClaro : C.blanco);
  c.border = bordes;
  c.font = { size: 11, color: { argb: C.oscuro } };
  c.alignment = { horizontal: centrar ? 'center' : 'left', vertical: 'middle', wrapText: true, indent: centrar ? 0 : 1 };
}

function chip(c: Cell, fondo: string, texto: string) {
  c.fill = relleno(fondo);
  c.font = { bold: true, size: 10, color: { argb: texto } };
  c.alignment = { horizontal: 'center', vertical: 'middle' };
}

function configurarImpresion(ws: Worksheet, filaCab: number) {
  ws.views = [{ state: 'frozen', ySplit: filaCab, showGridLines: false }];
  ws.pageSetup = { orientation: 'landscape', fitToPage: true, fitToWidth: 1, fitToHeight: 0, paperSize: 9, margins: { left: 0.4, right: 0.4, top: 0.5, bottom: 0.5, header: 0.2, footer: 0.2 } };
  ws.pageSetup.printTitlesRow = `${filaCab}:${filaCab}`;
}

const fechaAR = (iso: string | null) => (iso ? new Date(iso).toLocaleDateString('es-AR', { day: '2-digit', month: '2-digit', year: 'numeric' }) : '—');
const fechaCorta = (yyyyMmDd: string) => yyyyMmDd.split('-').reverse().join('/');
const ahora = () => new Date().toLocaleString('es-AR', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' });

// ─────────────────────────────── Resumen para facturar ───────────────────────────────

export async function descargarExcelResumenEstilado(r: ResumenFacturacion): Promise<boolean> {
  const wb = await nuevoLibro();
  const ws = wb.addWorksheet('Resumen', { properties: { defaultRowHeight: 20 } });
  const COLS = 9;
  ws.columns = [{ width: 12 }, { width: 14 }, { width: 16 }, { width: 18 }, { width: 11 }, { width: 11 }, { width: 13 }, { width: 13 }, { width: 14 }];

  encabezado(ws, COLS, 'RETRATO ESCOLAR · Resumen de impresiones para facturar', `Período: ${fechaCorta(r.desde)} al ${fechaCorta(r.hasta)}   ·   Generado: ${ahora()}`);

  const t = r.totales;
  // Tarjetas: 3 columnas cada una para Carpetas, 20x30, 15x21 (9 columnas).
  tarjetas(ws, 5, [
    { etiqueta: 'Carpetas', valor: t.carpetas, fondo: C.ambar, texto: C.oscuro },
    { etiqueta: 'Fotos 20x30', valor: t.fotos20x30, fondo: C.violeta, texto: C.blanco },
    { etiqueta: 'Fotos 15x21', valor: t.fotos15x21, fondo: C.celeste, texto: C.blanco },
  ], 3);
  ws.mergeCells(7, 1, 7, COLS);
  const nota = ws.getCell(7, 1);
  nota.value = `${t.pedidos} pedido${t.pedidos === 1 ? '' : 's'} en ${t.lotes} lote${t.lotes === 1 ? '' : 's'} marcados "En producción" en el período${t.sueltas > 0 ? ` · de las fotos 15x21, ${t.sueltas} son fotos sueltas` : ''}.`;
  nota.font = { italic: true, size: 10, color: { argb: C.gris } };
  nota.alignment = { vertical: 'middle', indent: 1 };
  ws.getRow(7).height = 22;

  const CAB = 9;
  filaCabecera(ws, CAB, ['Lote', 'Descargado', 'En producción', 'Estado', 'Pedidos', 'Carpetas', 'Fotos 20x30', 'Fotos 15x21', 'Sueltas (15x21)']);
  let fila = CAB + 1;
  const primera = fila;
  r.lotes.forEach((l, i) => {
    const row = ws.getRow(fila);
    row.values = [`N° ${l.numero}`, fechaAR(l.created_at), fechaAR(l.en_produccion_at), 'En producción', l.cantidad, l.carpetas || 0, l.fotos_20x30 || 0, l.fotos_15x21 || 0, l.fotos_sueltas || 0];
    for (let c = 1; c <= COLS; c++) estiloCelda(row.getCell(c), i % 2 === 1, c > 1);
    row.getCell(1).font = { bold: true, size: 11, color: { argb: C.oscuro } };
    chip(row.getCell(4), C.violetaClaro, C.violetaTexto);
    row.height = 22;
    fila++;
  });
  if (r.lotes.length === 0) {
    ws.mergeCells(fila, 1, fila, COLS);
    const c = ws.getCell(fila, 1);
    c.value = 'No hay lotes marcados "En producción" en este período.';
    c.font = { italic: true, color: { argb: C.gris } };
    c.alignment = { horizontal: 'center', vertical: 'middle' };
    ws.getRow(fila).height = 26;
    fila++;
  }
  // Total con fórmula (si alguien corrige una celda, el total se recalcula).
  const ultima = fila - 1;
  const total = ws.getRow(fila);
  ws.mergeCells(fila, 1, fila, 4);
  total.getCell(1).value = 'TOTAL A FACTURAR';
  const letras = ['E', 'F', 'G', 'H', 'I'];
  const valores = [t.pedidos, t.carpetas, t.fotos20x30, t.fotos15x21, t.sueltas];
  letras.forEach((L, i) => {
    total.getCell(5 + i).value = r.lotes.length > 0 ? { formula: `SUM(${L}${primera}:${L}${ultima})`, result: valores[i] } : valores[i];
  });
  for (let c = 1; c <= COLS; c++) {
    const cell = total.getCell(c);
    cell.fill = relleno(C.ambar);
    cell.font = { bold: true, size: 12, color: { argb: C.oscuro } };
    cell.border = { top: { style: 'medium', color: { argb: C.oscuro } }, bottom: { style: 'medium', color: { argb: C.oscuro } } };
    cell.alignment = { horizontal: c === 1 ? 'left' : 'center', vertical: 'middle', indent: c === 1 ? 1 : 0 };
  }
  total.height = 28;
  fila += 2;

  if (r.pendientes.length > 0) {
    ws.mergeCells(fila, 1, fila, COLS);
    const p = ws.getCell(fila, 1);
    p.value = 'PENDIENTES DE CONFIRMAR · descargados, sin marcar "En producción" (no suman al total)';
    p.font = { bold: true, size: 10, color: { argb: C.ambarTexto } };
    p.fill = relleno(C.ambarClaro);
    p.alignment = { vertical: 'middle', indent: 1 };
    ws.getRow(fila).height = 22;
    fila++;
    r.pendientes.forEach((l: LoteLab, i) => {
      const row = ws.getRow(fila);
      row.values = [`N° ${l.numero}`, fechaAR(l.created_at), '—', 'Sin marcar', l.cantidad, l.carpetas || 0, l.fotos_20x30 || 0, l.fotos_15x21 || 0, l.fotos_sueltas || 0];
      for (let c = 1; c <= COLS; c++) estiloCelda(row.getCell(c), i % 2 === 1, c > 1);
      for (let c = 1; c <= COLS; c++) row.getCell(c).font = { size: 11, color: { argb: C.gris } };
      chip(row.getCell(4), C.ambarClaro, C.ambarTexto);
      fila++;
    });
  }

  // Reimpresiones (2/10): aparte del total de los lotes; sin cargo si fue una falla de impresión.
  const reimp = r.reimpresiones || [];
  if (reimp.length > 0) {
    fila += r.pendientes.length > 0 ? 1 : 0;
    ws.mergeCells(fila, 1, fila, COLS);
    const t1 = ws.getCell(fila, 1);
    t1.value = 'REIMPRESIONES · se facturan aparte (sin cargo si fue una falla de impresión)';
    t1.font = { bold: true, size: 10, color: { argb: C.oscuro } };
    t1.fill = relleno(C.grisClaro);
    t1.alignment = { vertical: 'middle', indent: 1 };
    ws.getRow(fila).height = 22;
    fila++;
    filaCabecera(ws, fila, ['Fecha', 'Pedido', 'Alumno', 'Motivo', 'Cargo', '', 'Fotos 20x30', 'Fotos 15x21', 'Detalle']);
    fila++;
    const textoMotivo: Record<string, string> = { falla_laboratorio: 'Falla de impresión', dano_o_perdida: 'Daño o pérdida', otro: 'Otro' };
    reimp.forEach((x, i) => {
      const row = ws.getRow(fila);
      row.values = [fechaAR(x.fecha), x.pedido, x.alumno, textoMotivo[x.motivo] || x.motivo, x.conCargo ? 'Con cargo' : 'Sin cargo', '', x.fotos20x30, x.fotos15x21, x.detalle || ''];
      for (let c = 1; c <= COLS; c++) estiloCelda(row.getCell(c), i % 2 === 1, c > 4 && c < 9);
      if (x.conCargo) chip(row.getCell(5), C.ambarClaro, C.ambarTexto);
      else chip(row.getCell(5), C.verdeClaro, C.verdeTexto);
      fila++;
    });
    const tc = r.totalesReimpresiones?.conCargo;
    if (tc && tc.cantidad > 0) {
      const row = ws.getRow(fila);
      ws.mergeCells(fila, 1, fila, 6);
      row.getCell(1).value = 'TOTAL REIMPRESIONES CON CARGO';
      row.getCell(7).value = tc.fotos20x30;
      row.getCell(8).value = tc.fotos15x21;
      for (let c = 1; c <= COLS; c++) {
        const cell = row.getCell(c);
        cell.font = { bold: true, size: 11, color: { argb: C.oscuro } };
        cell.alignment = { horizontal: c === 1 ? 'left' : 'center', vertical: 'middle', indent: c === 1 ? 1 : 0 };
      }
      row.height = 24;
      fila++;
    }
  }

  configurarImpresion(ws, CAB);
  return descargar(wb, `RESUMEN_IMPRESIONES_${r.desde}_a_${r.hasta}.xlsx`);
}

// ─────────────────────────────── Planilla de un lote ───────────────────────────────

const etapaDe = (p: PedidoLab) =>
  p.estadoLab === 'en_produccion' ? 'En producción' : p.estadoLab === 'listo_retiro' ? 'Listo para retirar' : p.estadoLab === 'entregado' ? 'Entregado' : 'Nuevo';

export async function descargarExcelLoteEstilado(pedidos: PedidoLab[], etiqueta: string, nombreArchivo: string): Promise<boolean> {
  const wb = await nuevoLibro();
  const ws = wb.addWorksheet('Pedidos');
  const COLS = 10;
  ws.columns = [{ width: 6 }, { width: 16 }, { width: 28 }, { width: 18 }, { width: 26 }, { width: 46 }, { width: 10 }, { width: 9 }, { width: 9 }, { width: 16 }];

  const colegios = [...new Set(pedidos.map((p) => p.colegioNombre))].join(' · ');
  encabezado(ws, COLS, `RETRATO ESCOLAR · ${etiqueta.replace(/_/g, ' ')}`, `${colegios}   ·   Generado: ${ahora()}`);

  const archivos = pedidos.flatMap((p) => p.archivosParaLaboratorio);
  const tot = {
    carpetas: pedidos.reduce((a, p) => a + p.carpetas, 0),
    c20: archivos.filter((a) => a.tamanoImpresion === '20x30').length,
    c15: archivos.filter((a) => a.tamanoImpresion !== '20x30').length,
  };
  // 10 columnas: pedidos(2) carpetas(3) 20x30(2) 15x21(3) → usamos anchos parejos con merges.
  const bloques: [string, number, string, string, number, number][] = [
    ['Pedidos', pedidos.length, C.grisClaro, C.oscuro, 1, 2],
    ['Carpetas', tot.carpetas, C.ambar, C.oscuro, 3, 5],
    ['Fotos 20x30', tot.c20, C.violeta, C.blanco, 6, 7],
    ['Fotos 15x21', tot.c15, C.celeste, C.blanco, 8, 10],
  ];
  for (const [etq, val, fondo, texto, desde, hasta] of bloques) {
    ws.mergeCells(5, desde, 5, hasta);
    ws.mergeCells(6, desde, 6, hasta);
    const e = ws.getCell(5, desde);
    e.value = etq.toUpperCase();
    e.font = { size: 9, bold: true, color: { argb: texto } };
    e.alignment = { horizontal: 'left', vertical: 'bottom', indent: 1 };
    const v = ws.getCell(6, desde);
    v.value = val;
    v.font = { size: 22, bold: true, color: { argb: texto } };
    v.alignment = { horizontal: 'left', vertical: 'middle', indent: 1 };
    for (let c = desde; c <= hasta; c++) {
      ws.getCell(5, c).fill = relleno(fondo);
      ws.getCell(6, c).fill = relleno(fondo);
    }
  }
  ws.getRow(5).height = 20;
  ws.getRow(6).height = 34;

  const CAB = 8;
  filaCabecera(ws, CAB, ['N°', 'Pedido', 'Colegio', 'Curso', 'Alumno/a', 'Código (nombre de archivo)', 'Carpetas', '20x30', '15x21', 'Etapa']);
  let fila = CAB + 1;
  pedidos.forEach((p, i) => {
    // El mismo código con el que empiezan los archivos del ZIP (2/10: antes se mostraba el código de
    // alumno del padrón, que no coincidía con los nombres de archivo).
    const codigo = formatearCodigoCliente(p.cursoCodigo, p.alumnoNombre);
    const c20 = p.archivosParaLaboratorio.filter((a) => a.tamanoImpresion === '20x30').length;
    const c15 = p.archivosParaLaboratorio.length - c20;
    const row = ws.getRow(fila);
    row.values = [i + 1, p.id, p.colegioNombre, `${p.grado} "${p.division}"`, p.alumnoNombre, codigo, p.carpetas, c20, c15, etapaDe(p)];
    for (let c = 1; c <= COLS; c++) estiloCelda(row.getCell(c), i % 2 === 1, [1, 4, 7, 8, 9, 10].includes(c));
    row.getCell(5).font = { bold: true, size: 11, color: { argb: C.oscuro } };
    row.getCell(6).font = { name: 'Consolas', size: 10, color: { argb: C.oscuro2 } };
    const etapa = etapaDe(p);
    if (etapa === 'En producción') chip(row.getCell(10), C.violetaClaro, C.violetaTexto);
    else if (etapa === 'Nuevo') chip(row.getCell(10), C.ambarClaro, C.ambarTexto);
    else chip(row.getCell(10), C.verdeClaro, C.verdeTexto);
    if (p.carpetas > 1) chip(row.getCell(7), C.ambarClaro, C.ambarTexto);
    row.height = 26;
    fila++;

    // Detalle de archivos (2/10, "no se entiende nada"): una fila por foto a imprimir, con qué foto
    // es, el nombre exacto del archivo en el ZIP y en qué tamaño va, en vez de una línea larga.
    const queEs = (a: PedidoLab['archivosParaLaboratorio'][number]) => {
      const base = a.nombreArchivoOriginal === 'OTRAS_HD.jpg' ? 'Foto suelta' : a.tipo === 'grupal' ? 'Foto grupal' : a.tipo === 'docente' ? (a.nombreArchivoOriginal === 'FAMILIA_HD.jpg' ? 'Foto con familia/amigos' : 'Foto con la seño') : 'Foto individual';
      return a.esCopiaExtra ? `${base} · copia ${a.numeroCopia || 2}` : base;
    };
    p.archivosParaLaboratorio.forEach((a) => {
      const det = ws.getRow(fila);
      ws.mergeCells(fila, 2, fila, 5);
      det.getCell(2).value = `↳ ${queEs(a)}`;
      det.getCell(6).value = a.nombreArchivoLab;
      det.getCell(8).value = a.tamanoImpresion === '20x30' ? 1 : null;
      det.getCell(9).value = a.tamanoImpresion === '20x30' ? null : 1;
      det.getCell(10).value = a.sinFotoReal ? 'FALTA LA FOTO' : '';
      for (let c = 1; c <= COLS; c++) {
        const cell = det.getCell(c);
        cell.fill = relleno(a.sinFotoReal ? C.rojoClaro : i % 2 === 1 ? C.grisClaro : C.blanco);
        cell.font = { size: 9, color: { argb: a.sinFotoReal ? C.rojoTexto : C.gris }, bold: Boolean(a.sinFotoReal) };
        cell.alignment = { vertical: 'middle', horizontal: [8, 9, 10].includes(c) ? 'center' : 'left', indent: c === 2 ? 2 : 0 };
        cell.border = { left: c === 1 ? bordeFino : undefined, right: c === COLS ? bordeFino : undefined };
      }
      det.getCell(6).font = { name: 'Consolas', size: 9, color: { argb: a.sinFotoReal ? C.rojoTexto : C.oscuro2 } };
      det.height = 16;
      fila++;
    });
    // Línea de cierre del alumno.
    for (let c = 1; c <= COLS; c++) ws.getCell(fila - 1, c).border = { ...ws.getCell(fila - 1, c).border, bottom: bordeFino };
  });

  configurarImpresion(ws, CAB);

  // Hoja de totales (lo que se factura por este lote).
  const wt = wb.addWorksheet('Totales');
  wt.columns = [{ width: 22 }, { width: 14 }];
  encabezado(wt, 2, 'Totales del lote', etiqueta.replace(/_/g, ' '));
  filaCabecera(wt, 5, ['Concepto', 'Cantidad']);
  [
    ['Pedidos', pedidos.length],
    ['Carpetas', tot.carpetas],
    ['Fotos 20x30', tot.c20],
    ['Fotos 15x21', tot.c15],
  ].forEach(([k, v], i) => {
    const row = wt.getRow(6 + i);
    row.values = [k, v];
    estiloCelda(row.getCell(1), i % 2 === 1, false);
    estiloCelda(row.getCell(2), i % 2 === 1, true);
    row.getCell(2).font = { bold: true, size: 12, color: { argb: C.oscuro } };
    row.height = 24;
  });
  wt.views = [{ showGridLines: false }];

  return descargar(wb, nombreArchivo);
}

// ─────────────────────────────── Lista de foto de hermanos ───────────────────────────────

export interface FamiliaFotoHermanosExcel {
  tutor: string;
  chicos: string[];
  email: string;
  whatsapp: string;
  contactoDeLaConsulta: boolean;
  colegio: string;
  confirmo: string | null;
  /** 26/10: día (AAAA-MM-DD) y horario de la última citación repartida, si la familia fue citada. */
  cita?: { dia: string; hora: string } | null;
}

/** «2026-10-27» → «martes 27/10». */
function diaCita(dia: string): string {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(dia)) return '';
  const nombre = new Date(`${dia}T12:00:00-03:00`).toLocaleDateString('es-AR', { weekday: 'long', timeZone: 'America/Argentina/Buenos_Aires' });
  return `${nombre} ${dia.slice(8, 10)}/${dia.slice(5, 7)}`;
}

/**
 * WhatsApp argentino → número para wa.me (549 + característica + número), o null si no se puede
 * armar con seguridad (le faltan dígitos o tiene un formato raro): en ese caso se marca «Revisar».
 */
function waArgentina(valor: string): string | null {
  let d = String(valor || '').replace(/\D/g, '');
  if (d.startsWith('00')) d = d.slice(2);
  if (d.startsWith('54')) d = d.slice(2);
  if (d.startsWith('9')) d = d.slice(1);
  if (d.startsWith('0')) d = d.slice(1);
  // 11 15 1234 5678 → 11 1234 5678 (el 15 de celular sobra en el formato internacional).
  if (d.length === 12 && d.slice(2, 4) === '15') d = d.slice(0, 2) + d.slice(4);
  return d.length === 10 ? `549${d}` : null;
}

/** Muestra el número legible: +54 9 11 5692-6110 (si no se puede, tal como lo escribieron). */
function whatsappLegible(valor: string): string {
  const n = waArgentina(valor);
  if (!n) return String(valor || '').trim();
  const local = n.slice(3);
  const ar = local.slice(0, local.startsWith('11') ? 2 : 3); // AMBA 11; resto, característica de 3 cifras.
  const num = local.slice(ar.length);
  return `+54 9 ${ar} ${num.slice(0, num.length - 4)}-${num.slice(-4)}`;
}

/**
 * Lista de las familias que quieren la foto de hermanos (21/10, «se bajó y no se entiende»: el CSV
 * salía sin anchos, con los chicos en una sola celda y los WhatsApp en notación científica).
 * Una fila por familia, cada chico en su renglón, WhatsApp como texto con link para escribirles.
 */
export async function descargarExcelFotoHermanos(familias: FamiliaFotoHermanosExcel[], nombreArchivo: string): Promise<boolean> {
  const wb = await nuevoLibro();
  const ws = wb.addWorksheet('Foto de hermanos');
  const colegios = [...new Set(familias.map((f) => f.colegio).filter(Boolean))];
  const conColegio = colegios.length > 1;
  // 26/10: con citación repartida, ordenadas por día y horario (como las va a recibir el colegio) y con 2 columnas más.
  const conCitas = familias.some((f) => f.cita?.dia);
  if (conCitas) familias = [...familias].sort((a, b) => `${a.cita?.dia || '9'} ${a.cita?.hora || ''}`.localeCompare(`${b.cita?.dia || '9'} ${b.cita?.hora || ''}`) || a.tutor.localeCompare(b.tutor, 'es'));
  const anchos = [5, 30, 46, 34, 22, 14, 12, ...(conCitas ? [18, 18] : []), ...(conColegio ? [28] : [])];
  const COLS = anchos.length;
  ws.columns = anchos.map((width) => ({ width }));

  encabezado(ws, COLS, 'RETRATO ESCOLAR · Foto de hermanos', `${colegios.join(' · ') || 'Todos los colegios'}   ·   Familias que confirmaron que la quieren   ·   Generado: ${ahora()}`);

  const aRevisar = familias.filter((f) => !waArgentina(f.whatsapp)).length;
  const chicos = familias.reduce((a, f) => a + f.chicos.length, 0);
  tarjetas(ws, 5, [
    { etiqueta: 'Familias', valor: familias.length, fondo: C.ambar, texto: C.oscuro },
    { etiqueta: 'Chicos', valor: chicos, fondo: C.violetaClaro, texto: C.violetaTexto },
    { etiqueta: 'WhatsApp a revisar', valor: aRevisar, fondo: aRevisar ? C.rojoClaro : C.verdeClaro, texto: aRevisar ? C.rojoTexto : C.verdeTexto },
  ], 2);

  const CAB = 8;
  filaCabecera(ws, CAB, ['N°', 'Tutor/a', 'Alumnos (curso)', 'Email para el aviso', 'WhatsApp', 'Dato de', 'Confirmó', ...(conCitas ? ['Día', 'Horario'] : []), ...(conColegio ? ['Colegio'] : [])]);
  familias.forEach((f, i) => {
    const row = ws.getRow(CAB + 1 + i);
    const n = waArgentina(f.whatsapp);
    row.values = [
      i + 1,
      f.tutor || '—',
      f.chicos.join('\n'),
      f.email || '—',
      whatsappLegible(f.whatsapp) || '—',
      f.contactoDeLaConsulta ? 'Consulta' : 'Inscripción',
      fechaAR(f.confirmo),
      ...(conCitas ? [diaCita(f.cita?.dia || '') || 'Sin citar', f.cita?.hora || '—'] : []),
      ...(conColegio ? [f.colegio] : []),
    ];
    for (let c = 1; c <= COLS; c++) estiloCelda(row.getCell(c), i % 2 === 1, [1, 6, 7, ...(conCitas ? [8, 9] : [])].includes(c));
    if (conCitas) {
      row.getCell(8).font = { bold: true, size: 11, color: { argb: C.oscuro } };
      if (!f.cita?.dia) chip(row.getCell(8), C.rojoClaro, C.rojoTexto);
    }
    row.getCell(2).font = { bold: true, size: 11, color: { argb: C.oscuro } };
    const wa = row.getCell(5);
    wa.numFmt = '@';
    if (n) {
      wa.value = { text: whatsappLegible(f.whatsapp), hyperlink: `https://wa.me/${n}` };
      wa.font = { size: 11, color: { argb: 'FF047857' }, underline: true };
    } else if (f.whatsapp) {
      wa.value = `${f.whatsapp}  (revisar)`;
      chip(wa, C.rojoClaro, C.rojoTexto);
    }
    if (f.email) {
      row.getCell(4).value = { text: f.email, hyperlink: `mailto:${f.email}` };
      row.getCell(4).font = { size: 11, color: { argb: C.oscuro2 } };
    }
    chip(row.getCell(6), f.contactoDeLaConsulta ? C.verdeClaro : C.grisClaro, f.contactoDeLaConsulta ? C.verdeTexto : C.gris);
    row.height = Math.max(24, 16 * f.chicos.length + 8);
  });
  configurarImpresion(ws, CAB);
  ws.autoFilter = { from: { row: CAB, column: 1 }, to: { row: CAB + familias.length, column: COLS } };

  return descargar(wb, nombreArchivo.endsWith('.xlsx') ? nombreArchivo : `${nombreArchivo}.xlsx`);
}
