import { fetchAdminAutenticado } from './adminAuthService';

/** 26/10/2026: panel «Emails» a las familias (servidor/panel/emailsFamilias.ts). */
export type TipoEnvio = 'mensaje' | 'citacion' | 'promocion' | 'encuesta';
export type GrupoDestinatarios = 'todas' | 'compraron' | 'no_compraron' | 'foto_hermanos' | 'faltantes' | 'pagados_sin_fotos' | 'familia';
export interface FiltroDestinatarios { grupo: GrupoDestinatarios; cursos: string[]; email: string }
export type FranjaCita = 'ambos' | 'manana' | 'tarde' | 'completa';
export type FranjasCita = Record<FranjaCita, string>;
export interface CitaFamilia { dia: string; hora: string; franja: FranjaCita | 'general' }
/** reparto: la citación se reparte en varios días (dias) con una franja según el turno de los hijos (franjas). */
export interface ContenidoEnvio { asunto: string; texto: string; boton: boolean; dia: string; hora: string; lugar: string; codigo: string; vence: string; reparto: boolean; dias: string[]; franjas: FranjasCita }
export interface RepartoCita { dias: string[]; franjas: FranjasCita; hora: string }
export interface CursoDestino { codigo: string; etiqueta: string; familias: number }
export interface DestinatarioVista { email: string; tutor: string; alumnos: string[]; cita?: CitaFamilia }
export interface EnvioHistorial { id: string; tipo: TipoEnvio; asunto: string; descripcion_destinatarios: string | null; total: number; creado_at: string; terminado_at: string | null; estados: Record<string, number> }
export interface DestinatarioEnvio { email: string; tutor: string | null; alumnos: string | null; estado: 'pendiente' | 'enviado' | 'fallido' | 'rebotado'; error: string | null; enviado_at: string | null; cita?: CitaFamilia }
export interface Rebote { email: string; motivo: string; asunto: string; fecha: string; tutor: string; alumnos: string[]; whatsapp: string; corregido: boolean }

async function llamar<T = any>(url: string, cuerpo?: unknown, ms?: number): Promise<T> {
  const res = await fetchAdminAutenticado(url, cuerpo === undefined ? {} : { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(cuerpo) }, ms);
  const data = await res.json().catch(() => ({}));
  if (!res.ok || !data.success) throw new Error(data.error || 'No se pudo completar la operación.');
  return data as T;
}

export const obtenerCursosDestino = async () => (await llamar<{ cursos: CursoDestino[] }>('/api/admin/emails/cursos')).cursos;
export const buscarFamiliaDestino = async (q: string) =>
  (await llamar<{ familias: { email: string; tutor: string; alumnos: string[] }[] }>(`/api/admin/emails/buscar-familia?q=${encodeURIComponent(q)}`)).familias;
export const calcularDestinatariosEnvio = async (filtro: FiltroDestinatarios, reparto?: RepartoCita) =>
  llamar<{ total: number; destinatarios: DestinatarioVista[] }>('/api/admin/emails/destinatarios', reparto ? { ...filtro, reparto } : filtro);
export const vistaPreviaEnvio = async (tipo: TipoEnvio, c: ContenidoEnvio) => llamar<{ asunto: string; html: string }>('/api/admin/emails/vista-previa', { tipo, ...c });
export const redactarEnvioConIA = async (tipo: TipoEnvio, grupo: GrupoDestinatarios, idea: string, reparto = false) =>
  llamar<{ asunto: string; texto: string }>('/api/admin/emails/redactar', { tipo, grupo, idea, reparto }, 60_000);
export const mandarPruebaEnvio = async (tipo: TipoEnvio, c: ContenidoEnvio, email: string) => llamar('/api/admin/emails/prueba', { tipo, ...c, email });
export const crearEnvio = async (tipo: TipoEnvio, c: ContenidoEnvio, filtro: FiltroDestinatarios) =>
  llamar<{ id: string; total: number }>('/api/admin/emails/envios', { tipo, ...c, filtro });
export const enviarTandaEnvio = async (id: string) =>
  llamar<{ enviados: number; fallidos: number; pendientes: number }>(`/api/admin/emails/envios/${encodeURIComponent(id)}/enviar`, {}, 60_000);
export const obtenerHistorialEnvios = async () => (await llamar<{ envios: EnvioHistorial[] }>('/api/admin/emails/envios')).envios;
export const obtenerDestinatariosEnvio = async (id: string) =>
  (await llamar<{ destinatarios: DestinatarioEnvio[] }>(`/api/admin/emails/envios/${encodeURIComponent(id)}`)).destinatarios;
export const obtenerRebotes = async () => (await llamar<{ rebotes: Rebote[] }>('/api/admin/emails/rebotes')).rebotes;
export const corregirEmailFamilia = async (viejo: string, nuevo: string) => llamar<{ inscripciones: number }>('/api/admin/emails/corregir-email', { viejo, nuevo });
