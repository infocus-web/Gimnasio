import { useState, useEffect } from 'react';
import { getSupabase } from './supabaseClient';
import { fetchAdminAutenticado } from './adminAuthService';

export interface ConfiguracionWhatsApp {
  whatsappSolicitudCodigo: string;
  whatsappFlotante?: string; // Número de WhatsApp de contacto que se muestra en el widget flotante
  nombreContacto: string;
  mensajePredeterminado: string;
  ultimaActualizacion?: string;
  guardadoEnSupabase?: boolean;
}

const STORAGE_KEY = 'infocus_config_whatsapp_v1';
export const WHATSAPP_DEFECTO = ''; // Antes tenia el celular personal de Pablo hardcodeado; ahora sin config explicita no se muestra ningun numero.
export const NOMBRE_CONTACTO_DEFECTO = 'Institución Educativa / Atención de Códigos';

/**
 * Normaliza y sanea cualquier formato de teléfono ingresado (espacios, guiones, paréntesis, prefijos)
 * para convertirlo en el formato internacional numérico que requiere wa.me.
 */
export function sanitizarNumeroWhatsApp(numero: string): string {
  if (!numero) return '';
  // Remover todo excepto números
  let limpio = numero.replace(/\D/g, '');

  // Si ingresan con formato local de Argentina (ej: 1112345678 o 1512345678)
  if (limpio.startsWith('15') && limpio.length === 10) {
    limpio = '54911' + limpio.slice(2);
  } else if (limpio.startsWith('11') && limpio.length === 10) {
    limpio = '549' + limpio;
  } else if (limpio.startsWith('911') && limpio.length === 11) {
    limpio = '54' + limpio;
  }

  return limpio;
}

/**
 * Formatea el número visualmente para que sea legible (ej: +54 9 11 1234-5678)
 */
export function formatearNumeroVisual(numero: string): string {
  const limpio = sanitizarNumeroWhatsApp(numero);
  if (!limpio) return 'No configurado';
  if (limpio.startsWith('549') && limpio.length >= 12) {
    const area = limpio.slice(3, 5);
    const parte1 = limpio.slice(5, 9);
    const parte2 = limpio.slice(9);
    return `+54 9 ${area} ${parte1}-${parte2}`;
  }
  return `+${limpio}`;
}

export function obtenerConfiguracionWhatsApp(): ConfiguracionWhatsApp {
  if (typeof window === 'undefined') {
    return {
      whatsappSolicitudCodigo: WHATSAPP_DEFECTO,
      whatsappFlotante: WHATSAPP_DEFECTO,
      nombreContacto: NOMBRE_CONTACTO_DEFECTO,
      mensajePredeterminado: 'Hola, quisiera solicitar el código de curso para ver las fotos.',
      guardadoEnSupabase: false,
    };
  }

  try {
    const guardado = localStorage.getItem(STORAGE_KEY);
    if (guardado) {
      const parsed = JSON.parse(guardado);
      return {
        whatsappSolicitudCodigo: sanitizarNumeroWhatsApp(parsed.whatsappSolicitudCodigo) || WHATSAPP_DEFECTO,
        whatsappFlotante: parsed.whatsappFlotante ? sanitizarNumeroWhatsApp(parsed.whatsappFlotante) : (sanitizarNumeroWhatsApp(parsed.whatsappSolicitudCodigo) || WHATSAPP_DEFECTO),
        nombreContacto: parsed.nombreContacto || NOMBRE_CONTACTO_DEFECTO,
        mensajePredeterminado: parsed.mensajePredeterminado || 'Hola, quisiera solicitar el código de curso para ver las fotos.',
        ultimaActualizacion: parsed.ultimaActualizacion,
        guardadoEnSupabase: !!parsed.guardadoEnSupabase,
      };
    }
  } catch (err) {
    console.error('Error al leer configuración de WhatsApp:', err);
  }

  return {
    whatsappSolicitudCodigo: WHATSAPP_DEFECTO,
    whatsappFlotante: WHATSAPP_DEFECTO,
    nombreContacto: NOMBRE_CONTACTO_DEFECTO,
    mensajePredeterminado: 'Hola, quisiera solicitar el código de curso para ver las fotos.',
    guardadoEnSupabase: false,
  };
}

/**
 * Devuelve el número efectivo para el widget flotante
 */
export function obtenerNumeroWhatsAppFlotante(config?: ConfiguracionWhatsApp): string {
  const c = config || obtenerConfiguracionWhatsApp();
  return c.whatsappFlotante || c.whatsappSolicitudCodigo || WHATSAPP_DEFECTO;
}

/**
 * Guarda el nuevo número en localStorage y sincroniza con Supabase si está disponible.
 */
export async function guardarConfiguracionWhatsApp(
  nuevaConfig: Partial<ConfiguracionWhatsApp>
): Promise<{
  localOk: boolean;
  supabaseOk: boolean;
  numeroSanitizado: string;
  errorSupabase?: string;
}> {
  // Lo recordado por la sincronización compartida queda viejo con este cambio.
  sincronizacionCompartida = null;
  const actual = obtenerConfiguracionWhatsApp();
  const numeroSanitizado = sanitizarNumeroWhatsApp(nuevaConfig.whatsappSolicitudCodigo ?? actual.whatsappSolicitudCodigo);
  const numeroFlotanteSanitizado = nuevaConfig.whatsappFlotante !== undefined
    ? (sanitizarNumeroWhatsApp(nuevaConfig.whatsappFlotante) || numeroSanitizado)
    : (actual.whatsappFlotante ? sanitizarNumeroWhatsApp(actual.whatsappFlotante) : numeroSanitizado);

  const actualizada: ConfiguracionWhatsApp = {
    ...actual,
    ...nuevaConfig,
    whatsappSolicitudCodigo: numeroSanitizado,
    whatsappFlotante: numeroFlotanteSanitizado,
    ultimaActualizacion: new Date().toISOString(),
  };

  // 1. Guardar localmente
  if (typeof window !== 'undefined') {
    // Auditoría 11/10: sin try, con el almacenamiento lleno o bloqueado se cortaba el guardado en el servidor.
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(actualizada));
    } catch {
      // sin caché local
    }
    window.dispatchEvent(new CustomEvent('whatsapp_config_actualizada', { detail: actualizada }));
  }

  // 2. Guardar en Supabase pasando por el servidor con sesión de admin.
  // Antes esto escribía directo desde el navegador a la tabla 'configuracion' usando la clave
  // anónima (pública), protegido solo por una política de RLS que en los hechos permitía
  // escribir a cualquiera sin login (ver auditoría 2026-09-09). Ahora pasa por
  // POST /api/admin/configuracion, que exige sesión de admin, y la tabla se cerró en Supabase
  // para escritura pública.
  let supabaseOk = false;
  let errorSupabase: string | undefined;

  try {
    const datosExtraFlotante = {
      nombreContacto: actualizada.nombreContacto,
      mensajePredeterminado: actualizada.mensajePredeterminado,
    };
    const datosExtraSolicitud = {
      nombreContacto: actualizada.nombreContacto,
      mensajePredeterminado: actualizada.mensajePredeterminado,
      whatsappFlotante: actualizada.whatsappFlotante,
    };

    const res = await fetchAdminAutenticado('/api/admin/configuracion', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        registros: [
          {
            clave: 'whatsapp_flotante',
            valor: actualizada.whatsappFlotante || numeroSanitizado,
            datos_extra: datosExtraFlotante,
          },
          {
            clave: 'whatsapp_solicitud_codigo',
            valor: numeroSanitizado,
            datos_extra: datosExtraSolicitud,
          },
        ],
      }),
    });
    const data = await res.json();

    if (data?.success) {
      supabaseOk = true;
      actualizada.guardadoEnSupabase = true;
      if (typeof window !== 'undefined') {
        try {
          localStorage.setItem(STORAGE_KEY, JSON.stringify(actualizada));
        } catch {
          // sin caché local
        }
      }
    } else {
      errorSupabase = data?.error || 'No se pudo guardar en el servidor.';
      actualizada.guardadoEnSupabase = false;
    }
  } catch (err: any) {
    errorSupabase = err?.message || 'Error de conexión con el servidor.';
  }

  return {
    localOk: true,
    supabaseOk,
    numeroSanitizado: actualizada.whatsappFlotante || numeroSanitizado,
    errorSupabase,
  };
}

/**
 * Guarda específicamente el número del widget flotante de WhatsApp y lo persiste en Supabase.
 */
export async function guardarNumeroWhatsAppFlotante(
  numeroConCodigoPais: string
): Promise<{
  localOk: boolean;
  supabaseOk: boolean;
  numeroSanitizado: string;
  errorSupabase?: string;
}> {
  return guardarConfiguracionWhatsApp({
    whatsappFlotante: numeroConCodigoPais,
  });
}

/**
 * Intenta sincronizar la configuración desde Supabase al iniciar
 */
export async function sincronizarDesdeSupabase(): Promise<ConfiguracionWhatsApp | null> {
  try {
    const supabase = getSupabase();
    if (!supabase) return null;

    // Leer de la tabla 'configuracion' (única tabla real de configuración en Supabase).
    const { data, error } = await supabase
      .from('configuracion')
      .select('clave, valor, datos_extra, updated_at')
      .in('clave', ['whatsapp_flotante', 'whatsapp_solicitud_codigo', 'whatsapp'])
      // Auditoría 11/10: con tiempo máximo (AbortSignal.timeout no existe en Safari < 16: sin él, sin tope).
      .abortSignal(typeof AbortSignal.timeout === 'function' ? AbortSignal.timeout(8000) : new AbortController().signal);

    if (error || !data || data.length === 0) return null;

    const rowFlotante = data.find((d: any) => d.clave === 'whatsapp_flotante' || d.clave === 'whatsapp');
    const rowSolicitud = data.find((d: any) => d.clave === 'whatsapp_solicitud_codigo');

    const numFlotante = rowFlotante?.valor
      ? sanitizarNumeroWhatsApp(rowFlotante.valor)
      : (rowSolicitud?.datos_extra?.whatsappFlotante
          ? sanitizarNumeroWhatsApp(rowSolicitud.datos_extra.whatsappFlotante)
          : undefined);

    const numSolicitud = rowSolicitud?.valor
      ? sanitizarNumeroWhatsApp(rowSolicitud.valor)
      : (numFlotante || WHATSAPP_DEFECTO);

    const config: ConfiguracionWhatsApp = {
      whatsappSolicitudCodigo: numSolicitud || WHATSAPP_DEFECTO,
      whatsappFlotante: numFlotante || numSolicitud || WHATSAPP_DEFECTO,
      nombreContacto: rowFlotante?.datos_extra?.nombreContacto || rowSolicitud?.datos_extra?.nombreContacto || NOMBRE_CONTACTO_DEFECTO,
      mensajePredeterminado: rowFlotante?.datos_extra?.mensajePredeterminado || rowSolicitud?.datos_extra?.mensajePredeterminado || 'Hola, quisiera solicitar el código de curso para ver las fotos.',
      ultimaActualizacion: rowFlotante?.updated_at || rowSolicitud?.updated_at,
      guardadoEnSupabase: true,
    };

    if (typeof window !== 'undefined') {
      // El caché local es opcional: si el almacenamiento falla (modo privado, cuota llena), igual
      // se avisa a la página del número real — antes el error cortaba acá y quedaba el de defecto.
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(config));
      } catch {
        // sin caché local
      }
      window.dispatchEvent(new CustomEvent('whatsapp_config_actualizada', { detail: config }));
    }

    return config;
  } catch (err) {
    // Si la tabla no existe, no interrumpe el flujo
    return null;
  }
}

/**
 * Genera el script SQL para crear la tabla de configuración en el SQL Editor de Supabase
 */
export function getScriptSqlSupabase(): string {
  return `-- Script para crear la tabla de configuración en Supabase
create table if not exists public.configuracion (
  clave text primary key,
  valor text not null,
  datos_extra jsonb default '{}'::jsonb,
  updated_at timestamp with time zone default now()
);

-- Habilitar Row-Level Security (RLS)
alter table public.configuracion enable row level security;

-- Permitir lectura pública (para que el portal de familias lea el número actualizado)
create policy "Lectura publica de configuracion"
  on public.configuracion for select
  using (true);

-- OJO (auditoría 2026-09-09): NO agregar acá una política de escritura pública
-- ("for all using (true) with check (true)") — eso permite a cualquier visitante
-- reescribir esta tabla sin login, ya que la clave anónima es siempre visible en
-- el código del sitio. El guardado desde el panel de admin pasa por el servidor
-- (POST /api/admin/configuracion, con sesión de admin), que usa la Service Role
-- Key y no necesita ninguna política de escritura en RLS para funcionar.
`;
}

// Promesa compartida (y recordada CACHE_CONFIG_MS) de la sincronización al montar el hook.
const CACHE_CONFIG_MS = 5 * 60 * 1000;
let sincronizacionCompartida: { promesa: Promise<ConfiguracionWhatsApp | null>; momento: number } | null = null;

function sincronizarCompartido(): Promise<ConfiguracionWhatsApp | null> {
  if (sincronizacionCompartida && Date.now() - sincronizacionCompartida.momento < CACHE_CONFIG_MS) {
    return sincronizacionCompartida.promesa;
  }
  const promesa = sincronizarDesdeSupabase().then((remota) => {
    // Si falló, no se recuerda: el próximo componente que monte vuelve a intentar.
    if (!remota && sincronizacionCompartida?.promesa === promesa) sincronizacionCompartida = null;
    return remota;
  });
  sincronizacionCompartida = { promesa, momento: Date.now() };
  return promesa;
}

/**
 * Hook de React para consumir y reaccionar en tiempo real a los cambios de WhatsApp
 */
export function useWhatsAppConfig() {
  const [config, setConfig] = useState<ConfiguracionWhatsApp>(() => obtenerConfiguracionWhatsApp());
  const [cargando, setCargando] = useState(false);
  const [estadoGuardado, setEstadoGuardado] = useState<{
    guardado: boolean;
    enSupabase: boolean;
    errorSupabase?: string;
  } | null>(null);

  const recargar = () => {
    setConfig(obtenerConfiguracionWhatsApp());
  };

  useEffect(() => {
    // Sincronizar desde Supabase en background al montar. Auditoría 03/10 (medio): una sola
    // consulta compartida por todos los componentes que usan este hook (antes cada uno — Hero,
    // portal, inscripción, botón flotante — pedía lo mismo al cargar la home).
    let vivo = true;
    sincronizarCompartido().then((remota) => {
      if (vivo && remota) setConfig(remota);
    });

    const handleActualizacion = (e: any) => {
      if (e.detail) {
        setConfig(e.detail);
      } else {
        recargar();
      }
    };

    window.addEventListener('whatsapp_config_actualizada', handleActualizacion);
    window.addEventListener('storage', handleActualizacion);

    return () => {
      vivo = false;
      window.removeEventListener('whatsapp_config_actualizada', handleActualizacion);
      window.removeEventListener('storage', handleActualizacion);
    };
  }, []);

  const actualizarConfig = async (nueva: Partial<ConfiguracionWhatsApp>) => {
    setCargando(true);
    try {
      const resultado = await guardarConfiguracionWhatsApp(nueva);
      recargar();
      setEstadoGuardado({
        guardado: resultado.localOk,
        enSupabase: resultado.supabaseOk,
        errorSupabase: resultado.errorSupabase,
      });
      return resultado;
    } finally {
      setCargando(false);
    }
  };

  return {
    config,
    actualizarConfig,
    recargar,
    cargando,
    estadoGuardado,
    limpiarEstadoGuardado: () => setEstadoGuardado(null),
  };
}
