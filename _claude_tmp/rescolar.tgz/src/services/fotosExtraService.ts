import { guardarLlavePedido, obtenerLlavePedido } from '../utils/accesoPedido';
import { fetchConTimeout } from '../utils/fetchConTimeout';
import type { ItemFotoExtra } from '../utils/fotosExtra';

/**
 * Fotos extra (29/10/2026): crea (o reutiliza, si es el mismo pedido sin pagar) el pedido aparte de copias
 * impresas sobre un kit pagado. Se cobra con Mercado Pago, igual que la mejora a Kit Impreso.
 * POST /api/pedidos/:id/fotos-extra (servidor/pagos/fotosExtra.ts).
 */
export async function prepararFotosExtra(
  kitPedidoUuid: string,
  codigo: string,
  items: ItemFotoExtra[],
  credenciales?: { familia?: string | null; acceso?: string | null },
  /** 29/10/2026: mismos medios que el kit. */
  metodoPago: 'mercadopago' | 'nave' | 'transferencia' = 'mercadopago'
): Promise<{ success: boolean; pedidoId?: string; pedidoFriendlyId?: string; total?: number; accesoToken?: string | null; error?: string; codigo?: string }> {
  try {
    const llavePedido = obtenerLlavePedido(kitPedidoUuid);
    const res = await fetchConTimeout(`/api/pedidos/${encodeURIComponent(kitPedidoUuid)}/fotos-extra`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        codigo,
        items,
        metodoPago,
        ...(credenciales?.familia && credenciales?.acceso ? { familia: credenciales.familia, acceso: credenciales.acceso } : {}),
        ...(llavePedido ? { t: llavePedido } : {}),
      }),
    });
    const data = await res.json().catch(() => null);
    if (!res.ok || !data?.success) return { success: false, error: data?.error || 'No pudimos preparar tu pedido de fotos extra.', codigo: data?.codigo };
    guardarLlavePedido([data.pedidoId], data.accesoToken);
    return data;
  } catch (err: any) {
    return { success: false, error: err?.message || 'Error de red.' };
  }
}
