import { describe, expect, it, vi } from 'vitest';
import JSZip from 'jszip';
import { armarParteZipLaboratorio, planificarZipLaboratorio, seImprimeEnLaboratorio } from '../zipLaboratorio';
import type { PedidoEscolarCompleto } from '../pedidosLabService';

// Auditoría 03/10 (crítico 3): una foto que falla nunca va "gris" en silencio.
const pedido = (
  id: string,
  alumno: string,
  fotos: { id: string; tamano: string; nombre: string; sinFoto?: boolean }[],
  kitId = 'kit-clasico',
  kitNombre = 'Kit'
): PedidoEscolarCompleto =>
  ({
    id,
    colegioNombre: 'Instituto',
    cursoCodigo: 'GRADO1-ATM',
    alumnoNombre: alumno,
    alumnoNumeroLista: 1,
    kitId,
    kitNombre,
    estadoPago: 'aprobado',
    archivosParaLaboratorio: fotos.map((f) => ({
      id: f.id,
      tipo: 'individual',
      nombreArchivoOriginal: 'INDIVIDUAL_HD.jpg',
      nombreArchivoLab: f.nombre,
      tamanoImpresion: f.tamano,
      urlMuestra: '',
      urlOriginalHD: f.sinFoto ? undefined : `/api/lab/fotos/${f.id}/original`,
      sinFotoReal: f.sinFoto,
    })),
  }) as unknown as PedidoEscolarCompleto;

const respuestaUrlFirmada = (id: string) =>
  ({ ok: true, status: 200, headers: new Headers({ 'content-type': 'application/json' }), json: async () => ({ success: true, url: `https://storage/firmada/${id}` }) }) as unknown as Response;

describe('zipLaboratorio', () => {
  it('reparte en partes de 150 fotos', () => {
    const muchos = Array.from({ length: 160 }, (_, i) => pedido(`P-${i}`, `Alumno ${i}`, [{ id: `f${i}`, tamano: '15x21', nombre: `A_${i}.jpg` }]));
    const plan = planificarZipLaboratorio(muchos, { nombreColegio: 'Instituto', incluirPlanillaEnsobrado: false });
    expect(plan.partes.map((p) => p.length)).toEqual([150, 10]);
    expect(plan.totalFotos).toBe(160);
  });

  it('baja por URL firmada y marca en rojo (FALTA_) las que fallan, con la lista', async () => {
    const plan = planificarZipLaboratorio(
      [
        pedido('IFS-1', 'Ana', [{ id: 'ok', tamano: '15x21', nombre: 'ANA.jpg' }]),
        pedido('IFS-2', 'Beto', [{ id: 'roto', tamano: '20x30', nombre: 'BETO.jpg' }, { id: 'x', tamano: '15x21', nombre: 'BETO_IND.jpg', sinFoto: true }]),
      ],
      { nombreColegio: 'Instituto', incluirPlanillaEnsobrado: false }
    );
    const fetchFoto = vi.fn(async (url: string) => {
      if (url === '/api/lab/fotos/ok/original?modo=url') return respuestaUrlFirmada('ok');
      return { ok: false, status: 404, headers: new Headers(), json: async () => ({}) } as unknown as Response;
    });
    const fetchOriginal = globalThis.fetch;
    globalThis.fetch = vi.fn(async () => ({ ok: true, status: 200, blob: async () => new Blob(['jpg-real']) })) as unknown as typeof fetch;
    try {
      const r = await armarParteZipLaboratorio(plan, 0, { fetchFoto });
      expect(r.fallas.map((f) => f.archivo).sort()).toEqual(['15x21/BETO_IND.jpg', '20x30/BETO.jpg']);
      // Auditoría 03/10 noche: la bajada directa de Storage va con tiempo máximo (señal de corte).
      expect(globalThis.fetch).toHaveBeenCalledWith('https://storage/firmada/ok', expect.objectContaining({ signal: expect.anything() }));
      const zip = await JSZip.loadAsync(await r.blob.arrayBuffer());
      const nombres = Object.keys(zip.files);
      expect(nombres).toContain('15x21/ANA.jpg');
      expect(nombres).toContain('20x30/FALTA_BETO.jpg');
      expect(nombres).not.toContain('20x30/BETO.jpg');
      expect(nombres).toContain('FALTAN_FOTOS.txt');
    } finally {
      globalThis.fetch = fetchOriginal;
    }
  });

  // Auditoría 03/10 noche (A4): sólo se imprime el Kit Impreso.
  it('un Solo Digital no entra al ZIP del laboratorio (ni a la planilla)', () => {
    const plan = planificarZipLaboratorio(
      [
        pedido('IFS-1', 'Ana', [{ id: 'a1', tamano: '15x21', nombre: 'ANA.jpg' }, { id: 'a2', tamano: '20x30', nombre: 'ANA_G.jpg' }]),
        pedido('IFS-2', 'Beto', [{ id: 'b1', tamano: '15x21', nombre: 'BETO.jpg' }, { id: 'b2', tamano: '20x30', nombre: 'BETO_G.jpg' }], 'kit-digital', 'Solo Digital HD'),
      ],
      { nombreColegio: 'Instituto' }
    );
    expect(plan.totalFotos).toBe(2);
    expect(plan.partes.flat().map((e) => e.pedido)).toEqual(['IFS-1', 'IFS-1']);
    expect(plan.pedidosIncluidos.map((p) => p.id)).toEqual(['IFS-1']);
    expect(plan.pedidosExcluidos.map((p) => p.id)).toEqual(['IFS-2']);
    const planilla = plan.textos.find((t) => t.nombre.startsWith('00_PLANILLA'))?.contenido || '';
    expect(planilla).toContain('Ana');
    expect(planilla).not.toContain('Beto');
    expect(seImprimeEnLaboratorio({ kitId: 'kit-digital' })).toBe(false);
    expect(seImprimeEnLaboratorio({ kitId: 'kit-clasico' })).toBe(true);
  });

  it('la mejora a impreso sale UNA sola vez (el digital original no se imprime)', () => {
    const fotos = [
      { id: 'i1', tamano: '15x21', nombre: 'GRADO1-ATM_CARLA.jpg' },
      { id: 'g1', tamano: '20x30', nombre: 'GRADO1-ATM_CARLA.jpg' },
    ];
    // Mismo alumno y mismas fotos: el pedido digital original y el pedido de la mejora (kit-clasico).
    const original = pedido('IFS-10', 'Carla', fotos, 'kit-digital', 'Solo Digital HD');
    const mejora = pedido('IFS-11', 'Carla', fotos, 'kit-clasico', 'Kit Impreso (mejora de IFS-10)');
    const plan = planificarZipLaboratorio([original, mejora], { nombreColegio: 'Instituto', incluirPlanillaEnsobrado: false });
    const rutas = plan.partes.flat().map((e) => e.ruta).sort();
    expect(rutas).toEqual(['15x21/GRADO1-ATM_CARLA.jpg', '20x30/GRADO1-ATM_CARLA.jpg']);
    expect(plan.partes.flat().every((e) => e.pedido === 'IFS-11')).toBe(true);
    expect(rutas.some((r) => /_2\.jpg$|_INDIVIDUAL|_GRUPAL/i.test(r))).toBe(false);
  });

  it('una foto que vence el tiempo va como FALTA (el ZIP no queda colgado)', async () => {
    const plan = planificarZipLaboratorio(
      [pedido('IFS-1', 'Ana', [{ id: 'ok', tamano: '15x21', nombre: 'ANA.jpg' }, { id: 'colgada', tamano: '20x30', nombre: 'ANA_G.jpg' }])],
      { nombreColegio: 'Instituto', incluirPlanillaEnsobrado: false }
    );
    const fetchFoto = vi.fn(async (url: string) => respuestaUrlFirmada(url.includes('/colgada/') ? 'colgada' : 'ok'));
    const fetchOriginal = globalThis.fetch;
    globalThis.fetch = vi.fn((url: RequestInfo | URL, init?: RequestInit) => {
      if (String(url).endsWith('/ok')) return Promise.resolve({ ok: true, status: 200, blob: async () => new Blob(['jpg']) } as unknown as Response);
      // Nunca contesta: sólo se corta cuando se aborta la señal.
      return new Promise<Response>((_, rechazar) => {
        init?.signal?.addEventListener('abort', () => rechazar(new DOMException('abortado', 'AbortError')));
      });
    }) as unknown as typeof fetch;
    try {
      const progreso: number[] = [];
      const r = await armarParteZipLaboratorio(plan, 0, { fetchFoto, timeoutFotoMs: 50, onProgreso: (hechas) => progreso.push(hechas) });
      expect(r.fallas).toHaveLength(1);
      expect(r.fallas[0].archivo).toBe('20x30/ANA_G.jpg');
      expect(r.fallas[0].motivo).toMatch(/tardó/i);
      expect(Math.max(...progreso)).toBe(2);
      const zip = await JSZip.loadAsync(await r.blob.arrayBuffer());
      expect(Object.keys(zip.files)).toContain('20x30/FALTA_ANA_G.jpg');
      expect(Object.keys(zip.files)).toContain('15x21/ANA.jpg');
    } finally {
      globalThis.fetch = fetchOriginal;
    }
  });
});
