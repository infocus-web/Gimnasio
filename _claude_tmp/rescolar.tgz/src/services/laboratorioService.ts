import type { Foto } from '../types';
import { type PedidoEscolarCompleto, construirPedidoCompletoDesdeFila } from './pedidosLabService';
import {
  type FallaZipLab,
  type OpcionesArmadoZipLab,
  type PlanZipLab,
  descargarBlobComoArchivo,
  descargarLoteLaboratorioZip,
  planificarZipLaboratorio,
  resumenFallas,
} from './zipLaboratorio';
import { desambiguarNombresArchivos, repetirMientrasHayaRestantes } from '../utils/descargasLote';
import { descargarExcelLoteEstilado, descargarExcelResumenEstilado } from './excelLaboratorioEstilado';
import { TIMEOUT_FETCH_MS, fetchConTimeout } from '../utils/fetchConTimeout';

/**
 * Panel del laboratorio (27/9/2026). Sesión propia con el PIN del laboratorio (LAB_PIN en el
 * servidor): sólo ve pedidos cobrados con impresión, sin datos de contacto de las familias.
 */
const CLAVE_TOKEN = 'lab_token_v1';

export interface LoteLab {
  id: string;
  numero: number;
  created_at: string;
  cantidad: number;
  en_produccion_at: string | null;
  carpetas?: number;
  fotos_20x30?: number;
  fotos_15x21?: number;
  fotos_sueltas?: number;
  /** Auditoría 05/10: pedidos del lote que se anularon después de armarlo (no imprimirlos). */
  anulados?: { friendlyId: string; alumno: string }[];
}

export interface TotalesImpresion {
  lotes: number;
  pedidos: number;
  carpetas: number;
  fotos20x30: number;
  fotos15x21: number;
  sueltas: number;
}

export interface ReimpresionLab {
  id: string;
  fecha: string;
  motivo: MotivoReimpresion;
  detalle: string | null;
  conCargo: boolean;
  fotos20x30: number;
  fotos15x21: number;
  pedido: string;
  alumno: string;
  curso: string;
}

export interface TotalesReimpresion {
  cantidad: number;
  fotos20x30: number;
  fotos15x21: number;
}

export interface ResumenFacturacion {
  desde: string;
  hasta: string;
  lotes: LoteLab[];
  totales: TotalesImpresion;
  pendientes: LoteLab[];
  totalesPendientes: TotalesImpresion;
  reimpresiones?: ReimpresionLab[];
  totalesReimpresiones?: { conCargo: TotalesReimpresion; sinCargo: TotalesReimpresion };
}

export type MotivoReimpresion = 'falla_laboratorio' | 'dano_o_perdida' | 'otro';
export const MOTIVOS_REIMPRESION: { valor: MotivoReimpresion; texto: string; detalle: string }[] = [
  { valor: 'falla_laboratorio', texto: 'Salió mal la impresión', detalle: 'Color, corte, papel o máquina. Va sin cargo.' },
  { valor: 'dano_o_perdida', texto: 'Se dañó o se perdió después', detalle: 'En el armado, la entrega o el traslado. Va con cargo.' },
  { valor: 'otro', texto: 'Otro motivo', detalle: 'Explicalo abajo. Va con cargo.' },
];

/** Resumen para facturar. `fetcher` permite usarlo desde el panel del fotógrafo (sesión de admin). */
export async function obtenerResumenFacturacion(
  desde: string,
  hasta: string,
  fetcher: (url: string) => Promise<Response> = (u) => fetchLab(u)
): Promise<ResumenFacturacion> {
  const res = await fetcher(`/api/lab/resumen?desde=${encodeURIComponent(desde)}&hasta=${encodeURIComponent(hasta)}`);
  const data = await res.json().catch(() => null);
  if (!res.ok || !data?.success) throw new Error(data?.error || 'No se pudo armar el resumen.');
  return data as ResumenFacturacion;
}

/** Planilla del resumen con formato (colores, tarjetas de totales, total con fórmula). */
export function descargarExcelResumen(r: ResumenFacturacion): Promise<boolean> {
  return descargarExcelResumenEstilado(r);
}

export interface PedidoLab extends PedidoEscolarCompleto {
  loteLabId: string | null;
  carpetas: number;
}

function leerToken(): string | null {
  try {
    return localStorage.getItem(CLAVE_TOKEN);
  } catch {
    return null;
  }
}

export function haySesionLab(): boolean {
  return Boolean(leerToken());
}

export function cerrarSesionLab() {
  try {
    localStorage.removeItem(CLAVE_TOKEN);
  } catch {
    /* nada */
  }
}

export async function ingresarLab(pin: string): Promise<{ success: boolean; error?: string }> {
  try {
    const res = await fetch('/api/lab/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ pin }),
    });
    const data = await res.json().catch(() => null);
    if (!res.ok || !data?.success || !data.token) return { success: false, error: data?.error || 'No se pudo ingresar.' };
    try {
      localStorage.setItem(CLAVE_TOKEN, data.token);
    } catch {
      /* nada */
    }
    return { success: true };
  } catch {
    return { success: false, error: 'Sin conexión. Probá de nuevo.' };
  }
}

export class SesionLabVencida extends Error {}

/** Auditoría 03/10 noche: 15 s las lecturas; 65 s las escrituras (más que el límite de 60 s de Vercel). */
const TIMEOUT_ESCRITURA_LAB_MS = 65_000;
function tiempoMaximoPorMetodo(init: RequestInit = {}): number {
  const metodo = String(init.method || 'GET').toUpperCase();
  return metodo === 'GET' || metodo === 'HEAD' ? TIMEOUT_FETCH_MS : TIMEOUT_ESCRITURA_LAB_MS;
}

export async function fetchLab(url: string, init: RequestInit = {}, ms: number = tiempoMaximoPorMetodo(init)): Promise<Response> {
  const token = leerToken();
  // Auditoría 03/10 noche: con tiempo máximo (15 s las lecturas, 65 s las escrituras como armar
  // un lote; ver tiempoMaximoPorMetodo). Antes podía quedar "Cargando…" para siempre.
  const res = await fetchConTimeout(url, {
    ...init,
    headers: { ...(init.headers || {}), Authorization: `Bearer ${token || ''}` },
  }, ms);
  if (res.status === 401) {
    cerrarSesionLab();
    throw new SesionLabVencida('Sesión vencida');
  }
  return res;
}

export async function obtenerDatosLab(): Promise<{ pedidos: PedidoLab[]; lotes: LoteLab[] }> {
  const res = await fetchLab('/api/lab/pedidos');
  const data = await res.json();
  if (!res.ok || !data?.success) throw new Error(data?.error || 'No se pudieron cargar los pedidos.');
  return { pedidos: filasAPedidosLab(data), lotes: data.lotes || [] };
}

export async function crearLoteLab(): Promise<{ success: boolean; lote?: LoteLab; pedidoIds?: string[]; error?: string }> {
  const res = await fetchLab('/api/lab/lotes', { method: 'POST' });
  const data = await res.json().catch(() => null);
  if (!res.ok || !data?.success) return { success: false, error: data?.error || 'No se pudo armar el lote.' };
  return data;
}

/**
 * Auditoría 03/10 (alto 18): con lotes grandes el servidor corta antes de los 60 s y devuelve
 * `restantes` (cuántos pedidos le faltaron). Se lo vuelve a llamar hasta terminar (con tope de
 * vueltas), sumando los avisados y mostrando el avance.
 */
export async function marcarLoteEnProduccion(
  loteId: string,
  onProgreso?: (avisados: number, restantes: number, vuelta: number) => void
): Promise<{ success: boolean; avisados?: number; restantes?: number; errores?: string[]; error?: string }> {
  let avisados = 0;
  const errores: string[] = [];
  try {
    const r = await repetirMientrasHayaRestantes<number, { success: boolean; avisados?: number; restantes?: number; errores?: string[]; error?: string }>(
      0,
      async () => {
        const res = await fetchLab(`/api/lab/lotes/${encodeURIComponent(loteId)}/en-produccion`, { method: 'POST' });
        const data = await res.json().catch(() => null);
        if (!res.ok || !data?.success) throw new Error(data?.error || 'No se pudo marcar el lote.');
        avisados += Number(data.avisados) || 0;
        if (Array.isArray(data.errores)) errores.push(...data.errores);
        return data;
      },
      {
        maxVueltas: 25,
        hayMas: (restantes) => Number(restantes) > 0,
        alAvanzar: (data, vuelta) => onProgreso?.(avisados, Number(data.restantes) || 0, vuelta),
      }
    );
    const restantes = Number(r.restantes) || 0;
    if (restantes > 0) {
      return { success: false, avisados, restantes, errores, error: `Se avisó a ${avisados} familia(s) pero quedaron ${restantes} pedido(s) sin marcar. Tocá "Marcar en producción" de nuevo para terminar.` };
    }
    return { success: true, avisados, restantes: 0, errores };
  } catch (e) {
    if (e instanceof SesionLabVencida) throw e;
    const msg = e instanceof Error ? e.message : 'No se pudo marcar el lote.';
    return { success: false, avisados, errores, error: avisados > 0 ? `${msg} (ya se había avisado a ${avisados} familia(s); tocá de nuevo para seguir)` : msg };
  }
}

export async function reportarProblemaLab(pedidoSupabaseId: string, motivo: string): Promise<{ success: boolean; error?: string }> {
  const res = await fetchLab(`/api/lab/pedidos/${encodeURIComponent(pedidoSupabaseId)}/problema`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ motivo }),
  });
  const data = await res.json().catch(() => null);
  if (!res.ok || !data?.success) return { success: false, error: data?.error || 'No se pudo enviar el reporte.' };
  return { success: true };
}

function filasAPedidosLab(data: any): PedidoLab[] {
  const fotos: Foto[] = (data.fotos || []).map((f: any) => ({
    id: f.id,
    url: `/api/lab/fotos/${encodeURIComponent(f.id)}/original`,
    thumbnail: f.thumb_path || f.preview_path || '',
    categoria: f.categoria,
    titulo: f.alumno_nombre || `Foto ${f.categoria}`,
  }));
  return (data.pedidos || []).map((fila: any) => ({
    ...construirPedidoCompletoDesdeFila(fila, fotos),
    loteLabId: fila.lote_lab_id || null,
    carpetas: Math.max(1, Number(fila.carpetas_impresas) || 1),
  }));
}

/** Busca un pedido para reimprimir: por número de pedido, código o nombre del alumno. */
export async function buscarPedidoParaReimprimir(texto: string): Promise<{ pedidos: PedidoLab[]; reimpresiones: { pedido_id: string; created_at: string; motivo: MotivoReimpresion }[] }> {
  const res = await fetchLab(`/api/lab/buscar?q=${encodeURIComponent(texto)}`);
  const data = await res.json().catch(() => null);
  if (!res.ok || !data?.success) throw new Error(data?.error || 'No se pudo buscar el pedido.');
  return { pedidos: filasAPedidosLab(data), reimpresiones: data.reimpresiones || [] };
}

/** Registra la reimpresión (avisa a Pablo) y baja un ZIP sólo con las fotos elegidas. */
export async function reimprimirPedidoLab(
  pedido: PedidoLab,
  archivos: PedidoLab['archivosParaLaboratorio'],
  motivo: MotivoReimpresion,
  detalle: string,
  estructura: 'solo_2_carpetas_tamano' | 'por_alumno',
  yaRegistrada = false,
  alRegistrar?: () => void
): Promise<void> {
  // Si el ZIP falló y se reintenta, no se vuelve a registrar (no se cobra ni se avisa dos veces).
  if (!yaRegistrada) {
    const res = await fetchLab(`/api/lab/pedidos/${encodeURIComponent(pedido.supabaseId || '')}/reimpresion`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ motivo, detalle, archivos: archivos.map((a) => ({ nombre: a.nombreArchivoLab, tamano: a.tamanoImpresion })) }),
    });
    const data = await res.json().catch(() => null);
    if (!res.ok || !data?.success) throw new Error(data?.error || 'No se pudo registrar la reimpresión.');
    alRegistrar?.();
  }
  await descargarZipLab([{ ...pedido, archivosParaLaboratorio: archivos }], `REIMPRESION_${pedido.id}`, estructura);
}

export function nombreBase(pedidos: PedidoLab[], etiqueta: string) {
  const colegios = [...new Set(pedidos.map((p) => p.colegioNombre))];
  const colegio = colegios.length === 1 ? colegios[0] : 'VARIOS_COLEGIOS';
  return `${etiqueta}_${colegio}`.replace(/[^A-Za-z0-9_-]+/g, '_');
}

/** Errores que cortan el ZIP entero (la sesión venció: no tiene sentido seguir pidiendo fotos). */
export const opcionesArmadoLab: OpcionesArmadoZipLab = {
  fetchFoto: (url) => fetchLab(url),
  esErrorFatal: (e) => e instanceof SesionLabVencida,
};

/**
 * Auditoría 03/10 (medio): los nombres de archivo chocaban entre colegios (mismo curso y mismo
 * nombre de alumno). Se desambiguan con el número de pedido ANTES de armar ZIP y Excel, así los
 * dos siguen nombrando los mismos archivos.
 */
export function prepararPedidosParaLab<P extends PedidoLab>(pedidos: P[]): P[] {
  return desambiguarNombresArchivos(pedidos);
}

/** Plan del ZIP (partes de 150 fotos) para bajarlo con el panel de partes. */
export function planificarZipLab(pedidos: PedidoLab[], estructura: 'solo_2_carpetas_tamano' | 'por_alumno'): PlanZipLab {
  const colegios = [...new Set(pedidos.map((p) => p.colegioNombre))];
  return planificarZipLaboratorio(prepararPedidosParaLab(pedidos), {
    nombreColegio: colegios.join(', '),
    estructuraCarpetas: estructura,
    incluirPlanillaEnsobrado: false,
  });
}

/**
 * ZIP de una sola vez (reimpresiones: pocas fotos). Si faltó alguna foto, el ZIP igual se baja
 * (con la tarjeta roja y FALTAN_FOTOS.txt) y después se avisa con un error que lista cuáles.
 */
export async function descargarZipLab(
  pedidos: PedidoLab[],
  etiqueta: string,
  estructura: 'solo_2_carpetas_tamano' | 'por_alumno'
): Promise<FallaZipLab[]> {
  const colegios = [...new Set(pedidos.map((p) => p.colegioNombre))];
  const { blob, fallas } = await descargarLoteLaboratorioZip(prepararPedidosParaLab(pedidos), {
    nombreColegio: colegios.join(', '),
    estructuraCarpetas: estructura,
    incluirPlanillaEnsobrado: false,
    ...opcionesArmadoLab,
  });
  descargarBlobComoArchivo(blob, `${nombreBase(pedidos, etiqueta)}.zip`);
  if (fallas.length > 0) {
    throw new Error(`Se bajó el ZIP, pero faltan ${fallas.length} foto(s) (van como tarjeta roja FALTA_…, no imprimir): ${resumenFallas(fallas)}. Probá de nuevo o avisá al fotógrafo.`);
  }
  return fallas;
}

/** Planilla para el laboratorio: sin datos de contacto ni importes (con formato, ver excelLaboratorioEstilado). */
export function descargarExcelLab(pedidos: PedidoLab[], etiqueta: string): Promise<boolean> {
  return descargarExcelLoteEstilado(prepararPedidosParaLab(pedidos), etiqueta, `${nombreBase(pedidos, etiqueta)}.xlsx`);
}

/**
 * 14/10/2026 (auditoría): avance del ZIP por partes de un lote, guardado en el servidor (si el laboratorio
 * recarga la página a mitad de un lote grande, ve qué partes ya bajó). Nunca tira error: es una ayuda.
 */
export async function leerZipPartesLote(loteId: string): Promise<{ total: number; hechas: number[] } | null> {
  try {
    const res = await fetchLab(`/api/lab/lotes/${encodeURIComponent(loteId)}/zip-partes`);
    const data = await res.json().catch(() => null);
    const z = data?.zipPartes;
    return z && Number.isInteger(z.total) && Array.isArray(z.hechas) ? { total: z.total, hechas: z.hechas.map(Number) } : null;
  } catch {
    return null;
  }
}

export async function guardarZipPartesLote(loteId: string, datos: { total: number; hechas: number[]; nombre: string }): Promise<void> {
  try {
    await fetchLab(`/api/lab/lotes/${encodeURIComponent(loteId)}/zip-partes`, { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(datos) });
  } catch {
    // sin conexión: sólo no queda recordado
  }
}
