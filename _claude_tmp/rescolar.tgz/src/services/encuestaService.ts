import { fetchConTimeout } from '../utils/fetchConTimeout';
import { fetchAdminAutenticado } from './adminAuthService';

/** 25/10/2026: encuesta de satisfacción a las familias (servidor/familias/encuesta.ts). */
export type Recomendaria = 'si' | 'tal_vez' | 'no';

export interface RespuestaEncuesta {
  fotos: number | null;
  web: number | null;
  atencion: number | null;
  recomendaria: Recomendaria | null;
  sugerencias: string;
  quiereContacto: boolean;
}

export interface RespuestaEncuestaAdmin {
  id: string;
  email: string | null;
  tutor_nombre: string | null;
  fotos: number | null;
  web: number | null;
  atencion: number | null;
  recomendaria: Recomendaria | null;
  sugerencias: string | null;
  quiere_contacto: boolean;
  created_at: string;
  updated_at: string;
}

export async function abrirEncuesta(t: string): Promise<{ ok: true; prueba: boolean; tutor: string; previa: RespuestaEncuesta | null } | { ok: false; error: string }> {
  try {
    const res = await fetchConTimeout(`/api/encuesta?t=${encodeURIComponent(t)}`);
    const data = await res.json().catch(() => ({}));
    if (!res.ok || !data.success) return { ok: false, error: data.error || 'No pudimos abrir la encuesta.' };
    const r = data.respuesta;
    return {
      ok: true,
      prueba: data.prueba === true,
      tutor: data.tutor || '',
      previa: r ? { fotos: r.fotos, web: r.web, atencion: r.atencion, recomendaria: r.recomendaria, sugerencias: r.sugerencias || '', quiereContacto: r.quiere_contacto === true } : null,
    };
  } catch {
    return { ok: false, error: 'No pudimos conectarnos. Probá de nuevo en un rato.' };
  }
}

export async function enviarEncuesta(t: string, respuesta: RespuestaEncuesta): Promise<{ ok: true } | { ok: false; error: string }> {
  try {
    const res = await fetchConTimeout('/api/encuesta', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ t, ...respuesta }) });
    const data = await res.json().catch(() => ({}));
    return res.ok && data.success ? { ok: true } : { ok: false, error: data.error || 'No pudimos guardar tu respuesta.' };
  } catch {
    return { ok: false, error: 'No pudimos conectarnos. Probá de nuevo en un rato.' };
  }
}

export async function obtenerEncuestaAdmin(): Promise<{ destinatarios: number; pendientesDeEnvio: number; respuestas: RespuestaEncuestaAdmin[] }> {
  const res = await fetchAdminAutenticado('/api/admin/encuesta');
  const data = await res.json().catch(() => ({}));
  if (!res.ok || !data.success) throw new Error(data.error || 'No se pudo leer la encuesta.');
  return { destinatarios: data.destinatarios || 0, pendientesDeEnvio: data.pendientesDeEnvio || 0, respuestas: data.respuestas || [] };
}
