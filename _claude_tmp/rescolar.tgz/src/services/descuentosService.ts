import { fetchAdminAutenticado } from './adminAuthService';
import { fetchConTimeout } from '../utils/fetchConTimeout';

// Códigos de descuento (22/10/2026). El portal sólo valida el código para mostrar el total; el monto que se cobra lo
// vuelve a calcular el servidor al crear el pedido (servidor/pagos/descuentos.ts).

export interface CodigoDescuentoAplicado {
  codigo: string;
  porcentaje: number;
  usosLibres?: number | null; // 24/10: cuántos kits puede descontar (null = sin límite)
  sinTopeImpreso?: boolean; // 27/10: el kit impreso también acepta hasta 100%
}

/** 27/10/2026: 'kit' = kit del colegio (como siempre); 'eventos' = pedidos de eventos (ej. foto de hermanos). */
export type AmbitoDescuento = 'kit' | 'eventos';

export interface CodigoDescuentoAdmin extends CodigoDescuentoAplicado {
  id: string;
  created_at: string;
  usos_max: number | null;
  vence_at: string | null;
  activo: boolean;
  nota: string | null;
  sin_tope_impreso?: boolean;
  ambito?: AmbitoDescuento; // 27/10: dónde vale el código
  usos: number; // usos gastados (se gasta al registrar la compra)
}

async function leerJson(res: Response): Promise<any> {
  return res.json().catch(() => ({}));
}

/** Igual que el servidor (porcentajeParaKit): el kit digital hasta 100%; los impresos, hasta 70% (Pablo, 22/10),
 * salvo los códigos marcados «sin tope en el impreso» (27/10). */
export const TOPE_DESCUENTO_IMPRESO = 70;
export const porcentajeParaKit = (kitId: string, porcentaje: number, sinTopeImpreso = false) => Math.max(0, Math.min(kitId === 'kit-digital' || sinTopeImpreso ? 100 : TOPE_DESCUENTO_IMPRESO, porcentaje));
/** Descuento de UN kit con ese porcentaje, redondeado a pesos (igual que descuentoDeKit del servidor). */
export const descuentoDeKit = (precioKit: number, porcentaje: number, kitId: string, sinTopeImpreso = false) => Math.round((precioKit * porcentajeParaKit(kitId, porcentaje, sinTopeImpreso)) / 100);
/** 24/10: igual que kitsConDescuento del servidor: un uso por kit, primero los de mayor descuento. */
export const descuentoDelCarrito = (montosPorKit: number[], usosLibres?: number | null) =>
  [...montosPorKit].sort((a, b) => b - a).slice(0, usosLibres == null ? montosPorKit.length : Math.max(0, usosLibres)).reduce((acc, m) => acc + m, 0);

export async function validarCodigoDescuento(codigo: string): Promise<{ success: boolean; descuento?: CodigoDescuentoAplicado; error?: string }> {
  try {
    const res = await fetchConTimeout('/api/descuentos/validar', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ codigo }) });
    const data = await leerJson(res);
    if (res.status === 429) return { success: false, error: 'Demasiados intentos. Esperá unos minutos y volvé a probar.' };
    if (!res.ok || !data.success) return { success: false, error: data?.error || 'El código de descuento no es válido.' };
    return { success: true, descuento: { codigo: data.codigo, porcentaje: Number(data.porcentaje), usosLibres: data.usosLibres == null ? null : Number(data.usosLibres), sinTopeImpreso: data.sinTopeImpreso === true } };
  } catch {
    return { success: false, error: 'Error de conexión. Probá de nuevo.' };
  }
}

export async function obtenerCodigosDescuentoAdmin(): Promise<{ success: boolean; codigos: CodigoDescuentoAdmin[]; error?: string }> {
  try {
    const res = await fetchAdminAutenticado('/api/admin/descuentos');
    const data = await leerJson(res);
    if (!res.ok || !data.success) return { success: false, codigos: [], error: data?.error || 'No se pudieron cargar los códigos.' };
    return { success: true, codigos: data.codigos || [] };
  } catch (err: any) {
    return { success: false, codigos: [], error: err?.message || 'Error de conexión.' };
  }
}

export async function crearCodigoDescuentoAdmin(datos: { codigo?: string; porcentaje: number; usosMax: number | null; vence: string; nota: string; sinTopeImpreso?: boolean; ambito?: AmbitoDescuento }): Promise<{ success: boolean; codigo?: CodigoDescuentoAdmin; error?: string }> {
  try {
    const res = await fetchAdminAutenticado('/api/admin/descuentos', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(datos) });
    const data = await leerJson(res);
    if (!res.ok || !data.success) return { success: false, error: data?.error || 'No se pudo crear el código.' };
    return { success: true, codigo: data.codigo };
  } catch (err: any) {
    return { success: false, error: err?.message || 'Error de conexión.' };
  }
}

/** 28/10: un código al azar por persona del listado (el nombre queda en la nota). */
export async function crearLoteCodigosDescuentoAdmin(datos: { nombres: string[]; porcentaje: number; usosMax: number | null; vence: string; sinTopeImpreso?: boolean; ambito?: AmbitoDescuento }): Promise<{ success: boolean; codigos?: CodigoDescuentoAdmin[]; error?: string }> {
  try {
    const res = await fetchAdminAutenticado('/api/admin/descuentos/lote', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(datos) });
    const data = await leerJson(res);
    if (!res.ok || !data.success) return { success: false, error: data?.error || 'No se pudieron crear los códigos.' };
    return { success: true, codigos: data.codigos || [] };
  } catch (err: any) {
    return { success: false, error: err?.message || 'Error de conexión.' };
  }
}

export async function activarCodigoDescuentoAdmin(id: string, activo: boolean): Promise<{ success: boolean; codigo?: CodigoDescuentoAdmin; error?: string }> {
  try {
    const res = await fetchAdminAutenticado(`/api/admin/descuentos/${encodeURIComponent(id)}/activo`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ activo }) });
    const data = await leerJson(res);
    if (!res.ok || !data.success) return { success: false, error: data?.error || 'No se pudo actualizar el código.' };
    return { success: true, codigo: data.codigo };
  } catch (err: any) {
    return { success: false, error: err?.message || 'Error de conexión.' };
  }
}
