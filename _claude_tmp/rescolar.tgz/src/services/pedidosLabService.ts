import { FOTOS_MUESTRA, KITS_DISPONIBLES } from '../data/colegiosData';
import { archivosLabDeFotosExtra } from '../utils/fotosExtra';
import { PRECIOS } from './preciosService';
import { enviarFotosPorEmail } from './emailService';
import { fetchAdminAutenticado } from './adminAuthService';
import { guardarLlavePedido, obtenerLlavePedido } from '../utils/accesoPedido';
import { datosAceptacion } from '../legal/aceptacion';
import { ErrorTiempoAgotado, fetchConTimeout } from '../utils/fetchConTimeout';
import { Foto } from '../types';
import { categoriaValeEnLugar, lugaresSinFoto, type LugarPack } from '../utils/fotosFaltantes';

export interface ArchivoFotoLab {
  id: string;
  tipo: 'individual' | 'grupal' | 'docente' | 'stickers' | 'portarretrato';
  nombreArchivoOriginal: string;
  nombreArchivoLab: string; // Ej: 3ATT_FABRICIO_PEREZ.jpg o 3ATT_FABRICIO_PEREZ_COPIA2.jpg
  tamanoImpresion: string; // '15x21' | '20x30' | '10x15'
  urlMuestra: string;
  urlOriginalHD?: string;
  esCopiaExtra?: boolean;
  numeroCopia?: number; // 1 = original, 2 = copia extra, etc.
  /**
   * true cuando no se pudo encontrar la foto real que eligió la familia dentro de la galería
   * real del curso (auditoría 2026-09-15, pedido de Pablo: "eliminemos todas las fotos de
   * muestra" — que nunca se use una foto de stock como reemplazo silencioso de la real).
   * En ese caso `urlMuestra`/`urlOriginalHD` quedan vacíos a propósito: mejor marcarlo para que
   * el fotógrafo lo revise a mano que imprimir o enviar por error la foto de otro alumno.
   */
  sinFotoReal?: boolean;
}

export interface CopiasExtrasConfig {
  carpetasExtras?: number;
  individual15x21?: number;
  grupal20x30?: number;
  docente15x21?: number;
  otras15x21?: number;
}

export interface PedidoEscolarCompleto {
  id: string; // Ej: IFS-2026-8812 (Identificador amigable para la familia)
  supabaseId?: string; // UUID estricto de la fila en Supabase (para webhooks y Mercado Pago)
  // Auditoría 2026-09-23 (Pablo: "¿por qué se generaron 2 pedidos si es uno solo?"): un carrito
  // multi-hijo (mellizos, por ejemplo) crea un pedido por hermano pero los cobra juntos en un
  // solo pago — todas las filas de ese pago comparten este id (ver grupo_pago_id en
  // /api/pedidos/crear-multiple). Se expone acá para que el panel pueda encontrar y aprobar
  // juntos los pedidos de un mismo pago combinado (ver handleAprobarPago en AdminModal.tsx).
  grupoPagoId?: string;
  fecha: string;
  colegioId: string;
  colegioNombre: string;
  cursoCodigo: string; // Ej: SALA-3TM
  grado: string;
  division: string;
  turno: string;
  alumnoId?: string;
  alumnoNumeroLista: number;
  alumnoNombre: string;
  codigoAlumno: string; // Ej: SALA-3TM_01_PEREZ_JUAN
  tutorNombre: string;
  tutorTelefono: string;
  tutorEmail: string;
  kitId: string;
  kitNombre: string;
  total: number;
  metodoPago: 'mercadopago' | 'transferencia' | 'efectivo' | 'nave' | 'bonificado'; // 22/10: bonificado = $0 con código de descuento
  estadoPago: 'aprobado' | 'pendiente' | 'rechazado';
  estadoEntrega: 'en_espera' | 'en_laboratorio' | 'laboratorio_listo' | 'listo_retiro' | 'listo_descarga' | 'entregado';
  /** Pago anticipado: el kit está pagado pero la familia todavía no eligió las fotos. */
  seleccionPendiente?: boolean;
  /** Auditoría 05/10: mejora de Solo Digital a Kit Impreso (id del pedido original). No lleva .zip HD propio. */
  mejoraDePedidoId?: string | null;
  /** Archivado: fuera de las listas del panel y del laboratorio, pero no borrado. */
  archivado?: boolean;
  /** En espera (standby): visible con etiqueta, pero no pasa a producción. */
  enEspera?: boolean;
  notaEspera?: string;
  /** Transferencia: cuándo subió la familia el comprobante (null = todavía no). */
  comprobanteSubidoAt?: string | null;
  /** Cuándo se le mandó a la familia el recordatorio automático de pago pendiente (48 hs). */
  recordatorioPagoAt?: string | null;
  /** Transferencia: desde cuándo corre el plazo de 48 h para subir el comprobante. */
  transferenciaDesde?: string | null;
  /** 10/10: se canceló solo porque no llegó el comprobante a tiempo (se puede recuperar desde el panel). */
  transferenciaVencidaAt?: string | null;
  /** 10/10: cuándo salió el último aviso antes de que venza el plazo (a la familia y a Pablo). */
  avisoVencimientoAt?: string | null;
  /** Cancelado por Pablo, un arrepentimiento o un reembolso: no se reactiva solo. */
  canceladoDefinitivo?: boolean;
  /** Primera vez que la familia tocó el botón de descarga HD (null = nunca). */
  descargaHdAt?: string | null;
  /** Cuántas veces tocó el botón de descarga HD. */
  descargasHd?: number;
  fotosSeleccionadas: {
    individualId: string;
    grupalId: string;
    docenteId?: string; sinFoto?: string[];
    otrasIds?: string[];
  };
  copiasExtras?: CopiasExtrasConfig;
  archivosParaLaboratorio: ArchivoFotoLab[];
  linkDescargaHD: string;
  /**
   * 05/10 (bug 8): `GET /api/pedidos/:id/status` devuelve `esMejora: true` cuando el pedido es la
   * mejora de Solo Digital a Kit Impreso (`mejora_de_pedido_id`): no genera un .zip HD propio — la
   * descarga digital es la del pedido original. Opcional: el servidor lo está agregando.
   */
  esMejora?: boolean; esFotosExtra?: boolean; // 29/10: pedido de fotos extra (copias impresas, sin .zip)
  emailEnviado: boolean;
  fechaEnvioEmail?: string;
  // Auditoría 2026-09-20 (pedido de Pablo): estado real de los avisos de laboratorio ("En
  // producción" / "Listo para retirar" del panel de Laboratorio) — antes esto no se exponía acá,
  // así que el panel no tenía forma de saber si un pedido ya había recibido el aviso y el botón
  // volvía a mostrarse como si nunca se hubiera enviado. Las fechas son SIEMPRE la del primer
  // envío (no se pisan en reenvíos — ver /api/admin/pedidos/notificar-estado).
  // Auditoría 2026-09-20 (revisión completa de estados): se suma 'entregado' como tercera etapa
  // del mismo pipeline — antes el retiro físico no tenía ninguna forma de registrarse (ver
  // POST /api/admin/pedidos/:id/marcar-retirado). Es la ÚNICA fuente de verdad del pipeline
  // físico del pedido; "estadoEntrega" de abajo es sólo una vista derivada de este campo para las
  // pantallas que ya existían antes de esta auditoría.
  estadoLab?: 'en_produccion' | 'listo_retiro' | 'entregado' | null;
  fechaEnvioProduccion?: string;
  fechaEnvioListoRetiro?: string;
  fechaEntregado?: string;
}

// Helper to sanitize strings for photo lab minilab machines (Noritsu / Fuji Frontier / Klick)
export function sanitizarParaMinilab(texto: string): string {
  return texto
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '') // remove accents
    .toUpperCase()
    .replace(/[^A-Z0-9_]/g, '_')
    .replace(/_+/g, '_')
    .replace(/^_|_$/g, '');
}

/**
 * Genera el código de cliente normalizado para el minilab del laboratorio fotográfico.
 * Formato especificado: curso '3ATT', alumno 'Pérez, Fabricio' o 'Fabricio Pérez' -> '3ATT_FABRICIO_PEREZ'
 */
export function formatearCodigoCliente(cursoCodigo: string, alumnoNombre: string): string {
  const cleanCurso = sanitizarParaMinilab(cursoCodigo);
  let cleanNombre = '';

  if (alumnoNombre.includes(',')) {
    const parts = alumnoNombre.split(',').map(s => s.trim());
    const apellido = parts[0] || '';
    const nombre = parts[1] || '';
    if (nombre) {
      cleanNombre = `${sanitizarParaMinilab(nombre)}_${sanitizarParaMinilab(apellido)}`;
    } else {
      cleanNombre = sanitizarParaMinilab(apellido);
    }
  } else {
    cleanNombre = sanitizarParaMinilab(alumnoNombre);
  }

  return `${cleanCurso}_${cleanNombre}`;
}

/**
 * Genera el nombre del archivo para el minilab fotográfico.
 * Por defecto usa el código de cliente exacto (ej: 3ATT_FABRICIO_PEREZ.jpg)
 */
export function generarNombreArchivoLab(
  cursoCodigo: string,
  _numeroLista: number,
  alumnoNombre: string,
  tipoFoto?: 'INDIVIDUAL' | 'GRUPAL' | 'DOCENTE' | 'FAMILIA' | 'OTRAS' | 'STICKERS',
  _tamano?: '15x21' | '20x30' | '10x15',
  esCopiaExtra?: boolean,
  numeroCopia?: number
): string {
  const codigoCliente = formatearCodigoCliente(cursoCodigo, alumnoNombre);
  // 2/10 (bug real): las fotos sueltas son fotos DISTINTAS, no copias. Antes la 1ª y la 2ª salían
  // las dos como "_OTRAS_COPIA2" (mismo nombre) y en el ZIP una pisaba a la otra. Ahora van
  // numeradas: _SUELTA1, _SUELTA2…
  if (tipoFoto === 'OTRAS') {
    return `${codigoCliente}_SUELTA${numeroCopia && numeroCopia > 0 ? numeroCopia : 1}.jpg`;
  }
  if (esCopiaExtra) {
    const sufijoCopia = numeroCopia && numeroCopia > 1 ? `_COPIA${numeroCopia}` : '_COPIA2';
    if (tipoFoto === 'DOCENTE' || tipoFoto === 'FAMILIA') {
      return `${codigoCliente}_${tipoFoto}${sufijoCopia}.jpg`;
    }
    return `${codigoCliente}${sufijoCopia}.jpg`;
  }
  // 06/10: la 3ª foto con familia/amigos (secundaria) sale como _FAMILIA para no confundirla con la docente.
  if (tipoFoto === 'DOCENTE' || tipoFoto === 'FAMILIA') {
    return `${codigoCliente}_${tipoFoto}.jpg`;
  }
  return `${codigoCliente}.jpg`;
}

// Pedidos iniciales registrados en el sistema (vacío para entorno de producción real)
const PEDIDOS_INICIALES: PedidoEscolarCompleto[] = [];

const LOCAL_STORAGE_PEDIDOS_KEY = 'infocus_pedidos_escolares_v1';

export function obtenerPedidosGuardados(): PedidoEscolarCompleto[] {
  if (typeof window === 'undefined') return [];
  try {
    const raw = localStorage.getItem(LOCAL_STORAGE_PEDIDOS_KEY);
    if (!raw) {
      return [];
    }
    const parsedCrudo: PedidoEscolarCompleto[] = JSON.parse(raw);
    if (!Array.isArray(parsedCrudo)) return [];
    // Auditoría 2026-09-23: datos guardados por versiones anteriores del sitio pueden venir sin
    // `archivosParaLaboratorio` — el panel de Laboratorio y el portal hacen .map/.filter sobre ese
    // campo y la pantalla entera se caía. Se normaliza al leer.
    const parsed = parsedCrudo
      .filter((p) => p && typeof p === 'object')
      .map((p) => (Array.isArray(p.archivosParaLaboratorio) ? p : { ...p, archivosParaLaboratorio: [] }));

    // Saca los pedidos de demo viejos por número (11/10, FRO-13: ya no por nombre de alumno; borraba pedidos reales y publicaba nombres).
    const cleaned = parsed.filter(
      (p) => !['IFS-2026-9001', 'IFS-2026-8812', 'IFS-2026-8809', 'IFS-2026-8795', 'RE-2026-8812', 'RE-2026-8809', 'RE-2026-8795'].includes(p.id)
    );
    if (cleaned.length !== parsed.length) {
      localStorage.setItem(LOCAL_STORAGE_PEDIDOS_KEY, JSON.stringify(cleaned));
    }
    return cleaned;
  } catch {
    return [];
  }
}

// Auditoría 03/10 (bajo): el localStorage de pedidos crecía sin tope y guardaba todo el pedido
// (incluida la lista de archivos para el laboratorio, que el navegador de la familia casi no usa).
// Con muchos pedidos se llenaba la cuota y dejaba de guardarse el último — justo el que hace
// falta al volver de Mercado Pago. En el PORTAL de familias sólo se guardan los últimos
// MAX_PEDIDOS_LOCALES y, si igual no entra, se reintenta con menos.
// 2ª vuelta: (a) el pedido más reciente (y los hermanos de su mismo pago) conserva la lista de
// archivos — la confirmación al volver de Mercado Pago muestra "Tus fotos elegidas" con ella;
// (b) el recorte es SÓLO del portal: el panel admin usa la misma clave como respaldo sin conexión
// (lista completa y ZIPs del laboratorio) y guarda todo (ver guardarPedidosEnStorage).
export const MAX_PEDIDOS_LOCALES = 20;

export function recortarPedidosParaStorage(pedidos: PedidoEscolarCompleto[], max = MAX_PEDIDOS_LOCALES): PedidoEscolarCompleto[] {
  const masReciente = pedidos[0];
  const conservaArchivos = (p: PedidoEscolarCompleto, indice: number) =>
    indice === 0 || Boolean(masReciente?.grupoPagoId && p.grupoPagoId === masReciente.grupoPagoId);
  return pedidos.slice(0, max).map((p, i) => (conservaArchivos(p, i) ? p : { ...p, archivosParaLaboratorio: [] }));
}

/** Panel admin: guarda la lista completa (sin recorte). Si no entra en la cuota, se avisa en consola. */
export function guardarPedidosEnStorage(pedidos: PedidoEscolarCompleto[]): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(LOCAL_STORAGE_PEDIDOS_KEY, JSON.stringify(pedidos));
  } catch (err) {
    console.warn('No se pudo guardar la copia local de los pedidos (cuota del navegador llena):', err);
  }
}

/** Portal de familias: guarda sólo los últimos pedidos (ver recortarPedidosParaStorage). */
export function guardarPedidosEnStorageDelPortal(pedidos: PedidoEscolarCompleto[]): void {
  if (typeof window === 'undefined') return;
  const recortados = recortarPedidosParaStorage(pedidos);
  try {
    localStorage.setItem(LOCAL_STORAGE_PEDIDOS_KEY, JSON.stringify(recortados));
  } catch (err) {
    try {
      localStorage.setItem(LOCAL_STORAGE_PEDIDOS_KEY, JSON.stringify(recortados.slice(0, Math.ceil(MAX_PEDIDOS_LOCALES / 4))));
    } catch {
      console.error('Error guardando pedidos:', err);
    }
  }
}

/**
 * Auditoría 03/10 noche (M11/R5): "Cerrar sesión" del portal borra la copia local de pedidos (con
 * nombres del alumno, del tutor, teléfono y email). Es la MISMA clave que usa el panel admin como
 * respaldo sin conexión: el panel la vuelve a llenar desde el servidor apenas se abre, así que
 * borrarla acá no le hace perder nada real (permitido en el reparto de archivos del 03/10 noche).
 */
export function borrarPedidosLocalesDelPortal(): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.removeItem(LOCAL_STORAGE_PEDIDOS_KEY);
  } catch {
    /* sin almacenamiento disponible: no hay nada que borrar */
  }
}

/**
 * Auditoría 03/10 noche (M7/H6): el total que se muestra/guarda es SIEMPRE el que devuelve el
 * servidor (que lo calcula desde la base). Devuelve null si la respuesta no trae un número válido.
 */
export function totalDelServidor(valor: unknown): number | null {
  if (valor === null || valor === undefined || valor === '') return null;
  const numero = Number(valor);
  return Number.isFinite(numero) && numero >= 0 ? numero : null;
}

/** Respuesta 409 del servidor cuando el alumno ya tiene un kit pagado (auditoría 03/10, alto 8). */
export const CODIGO_KIT_YA_PAGADO = 'KIT_YA_PAGADO';

/** Los nombres de alumnos que manda el servidor con KIT_YA_PAGADO, en texto (acepta strings u objetos). */
export function nombresAlumnosDeRespuesta(alumnos: unknown): string[] {
  if (!Array.isArray(alumnos)) return [];
  return alumnos
    .map((a) => (typeof a === 'string' ? a : a && typeof a === 'object' ? String((a as any).alumnoNombre || (a as any).nombre || (a as any).alumno || '') : ''))
    .map((n) => n.trim())
    .filter(Boolean);
}

/** UUID compatible con PostgreSQL (crypto.randomUUID o respaldo para navegadores viejos). */
export function nuevoUuidPedido(): string {
  return typeof crypto !== 'undefined' && crypto.randomUUID
    ? crypto.randomUUID()
    : 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
        const r = (Math.random() * 16) | 0;
        const v = c === 'x' ? r : (r & 0x3) | 0x8;
        return v.toString(16);
      });
}

export function nuevoNumeroPedido(): string {
  return `IFS-2026-${Math.floor(1000 + Math.random() * 9000)}`;
}

/**
 * Resultado de registrar un pedido: incluye si la sincronización con Supabase
 * (POST /api/pedidos/crear) fue confirmada por el servidor antes de proceder al pago.
 */
export interface ResultadoRegistroPedido {
  pedido: PedidoEscolarCompleto;
  sincronizado: boolean;
  errorSincronizacion?: string;
  /** Código de error del servidor (p. ej. 'KIT_YA_PAGADO', alto 8 de la auditoría 03/10). */
  codigo?: string;
  /** Con KIT_YA_PAGADO: los alumnos que ya tienen un kit pagado. */
  alumnos?: string[];
}

/**
 * Genera los archivos para el laboratorio (incluidas las copias extra) a partir de la
 * configuración de un pedido. Es una función pura, sin efectos secundarios, para poder
 * reutilizarla tanto al crear un pedido nuevo (registrarPedidoDesdePortal) como al reconstruir
 * un pedido ya existente a partir de los datos guardados en Supabase (ver
 * construirPedidoCompletoDesdeFila más abajo) — evita mantener esta lógica duplicada en dos
 * lugares que podrían desincronizarse.
 */
export function generarArchivosParaLaboratorio(
  cursoCodigo: string,
  numLista: number,
  alumnoNombre: string,
  fotosSeleccionadas: { individualId: string; grupalId: string; docenteId?: string; otrasIds?: string[]; sinFoto?: string[] },
  copiasExtras?: CopiasExtrasConfig,
  fotosDisponibles: Foto[] = FOTOS_MUESTRA
): ArchivoFotoLab[] {
  // 22/10: un lugar «no tiene esta foto» (sinFoto) acepta otra foto del curso o queda sin archivo (fotosFaltantes.ts).
  const sinFoto = lugaresSinFoto(fotosSeleccionadas);
  const fotoDelLugar = (lugar: LugarPack): Foto | undefined => {
    const id = fotosSeleccionadas[`${lugar}Id`];
    return id ? fotosDisponibles.find((foto) => foto.id === id && categoriaValeEnLugar(foto.categoria, lugar, sinFoto)) : undefined;
  };
  // Auditoría 15/09: sólo la galería real del curso, nunca FOTOS_MUESTRA; si la foto no aparece, el archivo
  // queda con `sinFotoReal: true` para que el fotógrafo lo resuelva a mano (no se sustituye en silencio).
  const datosFoto = (foto: Foto | undefined): Pick<ArchivoFotoLab, 'urlMuestra' | 'urlOriginalHD' | 'sinFotoReal'> =>
    foto ? { urlMuestra: foto.thumbnail, urlOriginalHD: foto.url } : { urlMuestra: '', sinFotoReal: true };

  const individualFoto = fotoDelLugar('individual');
  const grupalFoto = fotoDelLugar('grupal');
  const seEligioDocente = Boolean(fotosSeleccionadas.docenteId);
  // 06/10: la 3ª foto (lugar `docenteId`) puede ser con la seño o con familia/amigos (utils/terceraFoto.ts).
  const docenteFoto = seEligioDocente ? fotoDelLugar('docente') : undefined;
  const terceraEsFamilia = docenteFoto?.categoria === 'familia';
  const tipoTercera = terceraEsFamilia ? 'FAMILIA' : 'DOCENTE';
  const originalTercera = terceraEsFamilia ? 'FAMILIA_HD.jpg' : 'DOCENTE_HD.jpg';

  const archivosLab: ArchivoFotoLab[] = [
    {
      id: `arch-${Date.now()}-1`,
      tipo: 'individual',
      nombreArchivoOriginal: 'INDIVIDUAL_HD.jpg',
      nombreArchivoLab: generarNombreArchivoLab(cursoCodigo, numLista, alumnoNombre, 'INDIVIDUAL', '15x21'),
      tamanoImpresion: '15x21',
      ...datosFoto(individualFoto),
      numeroCopia: 1
    },
    {
      id: `arch-${Date.now()}-2`,
      tipo: 'grupal',
      nombreArchivoOriginal: 'GRUPAL_HD.jpg',
      nombreArchivoLab: generarNombreArchivoLab(cursoCodigo, numLista, alumnoNombre, 'GRUPAL', '20x30'),
      tamanoImpresion: '20x30',
      ...datosFoto(grupalFoto),
      numeroCopia: 1
    }
  ];

  if (seEligioDocente) {
    archivosLab.push({
      id: `arch-${Date.now()}-3`,
      tipo: 'docente',
      nombreArchivoOriginal: originalTercera,
      nombreArchivoLab: generarNombreArchivoLab(cursoCodigo, numLista, alumnoNombre, tipoTercera, '15x21'),
      tamanoImpresion: '15x21',
      ...datosFoto(docenteFoto),
      numeroCopia: 1
    });
  }

  // Generación automática de archivos duplicados para el laboratorio por Copia Extra de Carpeta
  if (copiasExtras?.carpetasExtras && copiasExtras.carpetasExtras > 0) {
    for (let c = 1; c <= copiasExtras.carpetasExtras; c++) {
      const numCopia = c + 1;
      // 1. Copia extra de foto individual 15x21
      archivosLab.push({
        id: `arch-${Date.now()}-extra-carp-ind-${c}`,
        tipo: 'individual',
        nombreArchivoOriginal: 'INDIVIDUAL_HD.jpg',
        nombreArchivoLab: generarNombreArchivoLab(
          cursoCodigo,
          numLista,
          alumnoNombre,
          'INDIVIDUAL',
          '15x21',
          true,
          numCopia
        ),
        tamanoImpresion: '15x21',
        ...datosFoto(individualFoto),
        esCopiaExtra: true,
        numeroCopia: numCopia
      });

      // 2. Copia extra de foto grupal 20x30
      archivosLab.push({
        id: `arch-${Date.now()}-extra-carp-grup-${c}`,
        tipo: 'grupal',
        nombreArchivoOriginal: 'GRUPAL_HD.jpg',
        nombreArchivoLab: generarNombreArchivoLab(
          cursoCodigo,
          numLista,
          alumnoNombre,
          'GRUPAL',
          '20x30',
          true,
          numCopia
        ),
        tamanoImpresion: '20x30',
        ...datosFoto(grupalFoto),
        esCopiaExtra: true,
        numeroCopia: numCopia
      });

      // 3. Copia extra de foto docente 15x21 (si la familia eligió foto de docente)
      if (seEligioDocente) {
        archivosLab.push({
          id: `arch-${Date.now()}-extra-carp-doc-${c}`,
          tipo: 'docente',
          nombreArchivoOriginal: originalTercera,
          nombreArchivoLab: generarNombreArchivoLab(
            cursoCodigo,
            numLista,
            alumnoNombre,
            tipoTercera,
            '15x21',
            true,
            numCopia
          ),
          tamanoImpresion: '15x21',
          ...datosFoto(docenteFoto),
          esCopiaExtra: true,
          numeroCopia: numCopia
        });
      }
    }
  }

  // Generación automática de archivos duplicados para el laboratorio (Copia Extra 15x21 suelta)
  // Bug real (27/9, al preparar el control de impresiones para facturar): el portal guarda la carpeta
  // extra como carpetasExtras: N y ADEMÁS individual15x21/grupal20x30/docente15x21: N (el detalle de
  // esa misma carpeta). Se sumaban las dos cosas y cada carpeta extra salía con el doble de copias en el
  // ZIP. Ahora las copias sueltas por tamaño sólo cuentan lo que excede a las carpetas extra.
  const carpetasExtra = Math.max(0, Number(copiasExtras?.carpetasExtras) || 0);
  const soloExcedente = (valor: unknown) => Math.max(0, (Number(valor) || 0) - carpetasExtra);
  const extraIndividual = soloExcedente(copiasExtras?.individual15x21);
  const extraGrupal = soloExcedente(copiasExtras?.grupal20x30);
  const extraDocente = soloExcedente(copiasExtras?.docente15x21);

  if (extraIndividual > 0) {
    for (let c = 1; c <= extraIndividual; c++) {
      const numCopia = carpetasExtra + c + 1;
      archivosLab.push({
        id: `arch-${Date.now()}-extra-ind-${c}`,
        tipo: 'individual',
        nombreArchivoOriginal: 'INDIVIDUAL_HD.jpg',
        nombreArchivoLab: generarNombreArchivoLab(
          cursoCodigo,
          numLista,
          alumnoNombre,
          'INDIVIDUAL',
          '15x21',
          true,
          numCopia
        ),
        tamanoImpresion: '15x21',
        ...datosFoto(individualFoto),
        esCopiaExtra: true,
        numeroCopia: numCopia
      });
    }
  }

  // Generación automática de archivos duplicados para el laboratorio (Copia Extra 20x30)
  if (extraGrupal > 0) {
    for (let c = 1; c <= extraGrupal; c++) {
      const numCopia = carpetasExtra + c + 1;
      archivosLab.push({
        id: `arch-${Date.now()}-extra-grup-${c}`,
        tipo: 'grupal',
        nombreArchivoOriginal: 'GRUPAL_HD.jpg',
        nombreArchivoLab: generarNombreArchivoLab(
          cursoCodigo,
          numLista,
          alumnoNombre,
          'GRUPAL',
          '20x30',
          true,
          numCopia
        ),
        tamanoImpresion: '20x30',
        ...datosFoto(grupalFoto),
        esCopiaExtra: true,
        numeroCopia: numCopia
      });
    }
  }

  // Generación automática de archivos duplicados para el laboratorio (Copia Extra 15x21 Con Docente)
  if (extraDocente > 0 && seEligioDocente) {
    for (let c = 1; c <= extraDocente; c++) {
      const numCopia = carpetasExtra + c + 1;
      archivosLab.push({
        id: `arch-${Date.now()}-extra-doc-${c}`,
        tipo: 'docente',
        nombreArchivoOriginal: originalTercera,
        nombreArchivoLab: generarNombreArchivoLab(
          cursoCodigo,
          numLista,
          alumnoNombre,
          tipoTercera,
          '15x21',
          true,
          numCopia
        ),
        tamanoImpresion: '15x21',
        ...datosFoto(docenteFoto),
        esCopiaExtra: true,
        numeroCopia: numCopia
      });
    }
  }

  // Fotos digitales sueltas de eventos elegidas expresamente por la familia. Antes, si la foto
  // no aparecía en la galería real, esta copia extra pagada se perdía en silencio (el `if
  // (fotoEvento)` la salteaba sin dejar rastro); ahora siempre se genera el archivo — marcado
  // `sinFotoReal` si no se encontró — para que quede visible que hay una copia pendiente.
  for (const [indice, fotoId] of (fotosSeleccionadas.otrasIds || []).entries()) {
    const fotoEvento = fotosDisponibles.find((foto) => foto.id === fotoId && foto.categoria === 'patio');
    archivosLab.push({
      id: `arch-${Date.now()}-evento-${indice + 1}`,
      tipo: 'individual',
      nombreArchivoOriginal: 'OTRAS_HD.jpg',
      nombreArchivoLab: generarNombreArchivoLab(
        cursoCodigo,
        numLista,
        alumnoNombre,
        'OTRAS',
        '15x21',
        true,
        indice + 1
      ),
      tamanoImpresion: '15x21',
      ...datosFoto(fotoEvento),
      esCopiaExtra: false,
      numeroCopia: indice + 1
    });
  }

  // 22/10: el lugar que la familia marcó «no tiene esta foto» y no reemplazó no va al laboratorio.
  const lugaresVacios = new Set<string>(sinFoto.filter((lugar) => !fotosSeleccionadas[`${lugar}Id`]));
  return archivosLab.filter((archivo) => archivo.nombreArchivoOriginal === 'OTRAS_HD.jpg' || !lugaresVacios.has(archivo.tipo));
}

/**
 * Registers a new order created by a parent in the portal
 */
export async function registrarPedidoDesdePortal(params: {
  colegioId: string;
  colegioNombre: string;
  cursoCodigo: string;
  grado: string;
  division: string;
  turno: string;
  alumnoNombre: string;
  alumnoNumeroLista?: number;
  tutorNombre: string;
  tutorTelefono: string;
  tutorEmail: string;
  kitId: string;
  kitNombre: string;
  total: number;
  metodoPago: 'mercadopago' | 'transferencia' | 'efectivo' | 'nave';
  fotosSeleccionadas: {
    individualId: string;
    grupalId: string;
    docenteId?: string; sinFoto?: string[];
    otrasIds?: string[];
  };
  copiasExtras?: CopiasExtrasConfig;
  fotosDisponibles?: Foto[];
  /**
   * Auditoría 03/10 (crítico 2): UUID del pedido ESTABLE por checkout — lo genera el portal una
   * vez y lo reusa en cada reintento, así el servidor (idempotente por este id) no crea un
   * pedido nuevo si el primer intento sí llegó pero la respuesta se perdió.
   */
  pedidoId?: string;
  pedidoFriendlyId?: string;
  /** La familia confirmó que quiere un segundo kit aunque ya haya uno pagado (409 KIT_YA_PAGADO). */
  confirmarOtroKit?: boolean;
  /** Auditoría 03/10 noche (A1): secreto del checkout (ver checkoutEstable.ts), igual en cada reintento. */
  claveCheckout?: string;
  codigoDescuento?: string; // 22/10: código de descuento (servidor/pagos/descuentos.ts)
}): Promise<ResultadoRegistroPedido> {
  const currentPedidos = obtenerPedidosGuardados();
  const numPedido = params.pedidoFriendlyId || nuevoNumeroPedido();
  const numLista = params.alumnoNumeroLista || currentPedidos.length + 1;
  const codigoAlumno = `${sanitizarParaMinilab(params.cursoCodigo)}_${String(numLista).padStart(2, '0')}_${sanitizarParaMinilab(params.alumnoNombre)}`;

  const archivosLab = generarArchivosParaLaboratorio(
    params.cursoCodigo,
    numLista,
    params.alumnoNombre,
    params.fotosSeleccionadas,
    params.copiasExtras,
    params.fotosDisponibles
  );

  const now = new Date();
  const fechaStr = `${String(now.getDate()).padStart(2, '0')}/${String(now.getMonth() + 1).padStart(2, '0')}/${now.getFullYear()} ${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;

  // UUID estricto compatible con PostgreSQL UUID para la clave primaria de Supabase. Auditoría
  // 03/10 (crítico 2): si el portal ya tiene uno para este checkout, se reusa (reintento).
  const supabaseId = params.pedidoId || nuevoUuidPedido();

  const nuevoPedido: PedidoEscolarCompleto = {
    id: numPedido,
    supabaseId,
    fecha: fechaStr,
    colegioId: params.colegioId,
    colegioNombre: params.colegioNombre,
    cursoCodigo: params.cursoCodigo.toUpperCase(),
    grado: params.grado,
    division: params.division,
    turno: params.turno,
    alumnoNumeroLista: numLista,
    alumnoNombre: params.alumnoNombre,
    codigoAlumno,
    tutorNombre: params.tutorNombre,
    tutorTelefono: params.tutorTelefono,
    tutorEmail: params.tutorEmail,
    kitId: params.kitId,
    kitNombre: params.kitNombre,
    total: params.total,
    metodoPago: params.metodoPago,
    estadoPago: 'pendiente',
    estadoEntrega: 'en_espera',
    fotosSeleccionadas: params.fotosSeleccionadas,
    copiasExtras: params.copiasExtras,
    archivosParaLaboratorio: archivosLab,
    // Auditoría 2026-09-15: antes acá se fabricaba un link a un .zip que en la práctica nunca se
    // genera ni se sube a Storage — no existe (todavía) ningún proceso, manual ni automático,
    // que arme ese archivo por pedido. El resultado era un enlace roto (404 "Bucket not found")
    // que igual se guardaba en la base y se mostraba en el portal de familias y en los emails.
    // Se deja vacío hasta que exista un proceso real de generación de ZIP por pedido; tanto el
    // portal (PortalFamiliasModal) como el email de fotos HD (server.ts, enviarCorreoFotosHD) ya
    // están preparados para ocultar el botón de descarga cuando el link viene vacío.
    linkDescargaHD: '',
    emailEnviado: false,
    fechaEnvioEmail: undefined
  };

  // Auditoría 03/10: el pedido se guarda en este navegador recién cuando el servidor lo confirma
  // (más abajo). Antes se guardaba antes de mandarlo, y cada reintento fallido dejaba un pedido
  // "fantasma" en el localStorage (y en el seguimiento sin conexión).
  const otrosPedidos = currentPedidos.filter((p) => p.supabaseId !== supabaseId);

  // Sincronización con Supabase, esperada por quien llama antes de avanzar al pago (auditoría 09/09: antes iba al
  // servidor sin esperar y un fallo dejaba el pedido sólo en localStorage, con riesgo de pagar algo no registrado).
  let sincronizado = false;
  let errorSincronizacion: string | undefined;
  try {
    const resSync = await fetchConTimeout('/api/pedidos/crear', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        pedidoId: nuevoPedido.supabaseId,
        kitId: nuevoPedido.kitId,
        carpetasExtras: nuevoPedido.copiasExtras?.carpetasExtras || 0,
        tutorNombre: nuevoPedido.tutorNombre,
        tutorTelefono: nuevoPedido.tutorTelefono,
        metodoPago: nuevoPedido.metodoPago,
        // Auditoría 2026-09-09 (revisión a fondo): se manda además todo lo necesario para poder
        // cumplir el pedido sin depender de este navegador — ver migración de esa fecha.
        pedidoFriendlyId: nuevoPedido.id,
        tutorEmail: nuevoPedido.tutorEmail,
        colegioId: nuevoPedido.colegioId,
        colegioNombre: nuevoPedido.colegioNombre,
        cursoCodigo: nuevoPedido.cursoCodigo,
        grado: nuevoPedido.grado,
        division: nuevoPedido.division,
        turno: nuevoPedido.turno,
        alumnoNombre: nuevoPedido.alumnoNombre,
        alumnoNumeroLista: nuevoPedido.alumnoNumeroLista,
        codigoAlumno: nuevoPedido.codigoAlumno,
        kitNombre: nuevoPedido.kitNombre,
        fotosSeleccionadas: nuevoPedido.fotosSeleccionadas,
        copiasExtras: nuevoPedido.copiasExtras,
        linkDescargaHD: nuevoPedido.linkDescargaHD,
        // Marco legal (27/9): el servidor rechaza la compra sin la aceptación de los términos.
        ...datosAceptacion(),
        ...(params.confirmarOtroKit ? { confirmarOtroKit: true } : {}),
        // Auditoría 03/10 noche (A1): sin la clave del checkout el servidor no acepta el reintento.
        ...(params.claveCheckout ? { claveCheckout: params.claveCheckout } : {}),
        ...(params.codigoDescuento ? { codigoDescuento: params.codigoDescuento } : {}),
      }),
    });
    const dataSync = await resSync.json().catch(() => null);
    if (resSync.status === 409 && dataSync?.codigo === CODIGO_KIT_YA_PAGADO) {
      return {
        pedido: nuevoPedido,
        sincronizado: false,
        errorSincronizacion: dataSync.error || 'Ya hay un kit pagado para este alumno/a.',
        codigo: CODIGO_KIT_YA_PAGADO,
        alumnos: nombresAlumnosDeRespuesta(dataSync.alumnos),
      };
    }
    if (resSync.ok && dataSync?.success) {
      sincronizado = true;
      // Llave de acceso del pedido (ver src/utils/accesoPedido.ts): sin ella el servidor no
      // devuelve el link de descarga HD en la consulta de estado.
      guardarLlavePedido([dataSync.pedidoId, nuevoPedido.supabaseId], dataSync.accesoToken);
      // Auditoría 2026-09-23: el servidor garantiza que el número de pedido (IFS-2026-XXXX) no se
      // repita — si el que se propuso acá ya existía, devuelve otro. Se adopta el definitivo en
      // el pedido y en el localStorage para que la familia vea el mismo número que le llega por
      // correo y que figura en el panel.
      if (dataSync.pedidoFriendlyId && dataSync.pedidoFriendlyId !== nuevoPedido.id) {
        nuevoPedido.id = dataSync.pedidoFriendlyId;
      }
      // Auditoría 03/10 noche (M7/H6): el pedido registrado guarda y muestra el total que calculó el
      // servidor (el que se cobra), no el que se sumó en el navegador.
      const totalServidor = totalDelServidor(dataSync.total);
      if (totalServidor !== null) nuevoPedido.total = totalServidor;
      if (dataSync.bonificado) Object.assign(nuevoPedido, { estadoPago: 'aprobado', metodoPago: 'bonificado' }); // 22/10: sin cargo, ya pagado
      guardarPedidosEnStorageDelPortal([nuevoPedido, ...otrosPedidos]);
      // El email de confirmación y fotos HD se despacha una vez aprobado el pago (vía webhook de Mercado Pago o confirmación admin)
    } else {
      errorSincronizacion = dataSync?.error || `El servidor respondió con un error (HTTP ${resSync.status}).`;
      console.warn('No se pudo confirmar el pedido en Supabase:', errorSincronizacion);
    }
  } catch (e: any) {
    errorSincronizacion = e?.message || 'Error de conexión al registrar el pedido en el servidor.';
    console.warn('Sincronización con Supabase no completada:', e);
  }

  return { pedido: nuevoPedido, sincronizado, errorSincronizacion };
}

/** Un hijo del carrito multi-hijo, listo para registrarse como su propio pedido. */
export interface ItemCarritoHijo {
  colegioId: string;
  colegioNombre: string;
  cursoCodigo: string;
  grado: string;
  division: string;
  turno: string;
  alumnoNombre: string;
  alumnoNumeroLista?: number;
  kitId: string;
  kitNombre: string;
  metodoPago: 'mercadopago' | 'transferencia' | 'efectivo' | 'nave';
  fotosSeleccionadas: {
    individualId: string;
    grupalId: string;
    docenteId?: string; sinFoto?: string[];
    otrasIds?: string[];
  };
  copiasExtras?: CopiasExtrasConfig;
}

export interface ResultadoRegistroCarrito {
  grupoPagoId: string;
  pedidoIds: string[];
  // 17/09 (Pablo): un «IFS-2026-XXXX» por hijo, igual que registrarPedidoDesdePortal.
  pedidoFriendlyIds: string[];
  total: number;
  sincronizado: boolean;
  bonificado?: boolean; // 22/10: carrito en $0 con código de descuento (ya quedó pagado)
  errorSincronizacion?: string;
  codigo?: string;
  alumnos?: string[];
}

// Mismos precios que PRECIOS_KITS/PRECIO_CARPETA_EXTRA/PRECIO_FOTO_EVENTO en server.ts (y que las
// constantes locales del mismo nombre en PortalFamiliasModal.tsx) — el servidor es SIEMPRE quien
// calcula el monto que realmente se cobra (ver calcularTotalPedido en server.ts, usado por
// /api/pedidos/crear-multiple y por la creación de la preferencia de pago). Este cálculo acá es
// sólo para reconstruir, para esta pantalla, el mismo total que la familia ya vio y confirmó
// antes de pagar — nunca se manda a ningún endpoint de cobro.
function calcularTotalItemLocal(item: { kitId: string; copiasExtras?: CopiasExtrasConfig }): number {
  const precioBase = KITS_DISPONIBLES.find((k) => k.id === item.kitId)?.precio || 0;
  const carpetasExtras = Math.max(0, Math.floor(Number(item.copiasExtras?.carpetasExtras) || 0));
  const fotosSueltas = Math.max(0, Math.floor(Number(item.copiasExtras?.otras15x21) || 0));
  return precioBase + carpetasExtras * PRECIOS.carpetaExtra + fotosSueltas * PRECIOS.fotoEvento;
}

/**
 * Auditoría 2026-09-16 (pedido de Pablo: "el cliente debe poder hacer multiple pedido en una
 * sola sesion, un solo pago"): equivalente a registrarPedidoDesdePortal, pero para el carrito
 * de familias con más de un hijo (Código Familiar). Registra en un solo llamado al servidor
 * (/api/pedidos/crear-multiple) UN pedido por cada hijo del carrito, todos agrupados bajo un
 * mismo "grupoPagoId" — esa referencia es la que después se usa para generar UNA sola
 * preferencia de Mercado Pago / intención de Nave que cobra el total combinado (ver
 * mercadoPagoService.ts / naveService.ts), y la que el webhook de pago usa para marcar todos
 * los pedidos del grupo como pagados con una sola confirmación. No reemplaza a
 * registrarPedidoDesdePortal: una familia con un solo hijo sigue usando ese camino, sin ningún
 * cambio de comportamiento.
 */
export async function registrarCarritoMultipleDesdePortal(params: {
  tutorNombre: string;
  tutorTelefono: string;
  tutorEmail: string;
  items: ItemCarritoHijo[];
  /**
   * Auditoría 03/10 (crítico 2): UUID estable por hijo para este checkout (mismo orden que
   * `items`). El servidor ya acepta `items[].pedidoId` y es idempotente por ese id.
   */
  pedidoIds?: string[];
  pedidoFriendlyIds?: string[];
  /** Segundo kit confirmado por la familia tras un 409 KIT_YA_PAGADO. */
  confirmarOtroKit?: boolean;
  /** Auditoría 03/10 noche (A1): secreto del checkout (ver checkoutEstable.ts), igual en cada reintento. */
  claveCheckout?: string;
  /** 14/10/2026: después se suman reservas al grupo (el email de transferencia sale con ellas, con el total final). */
  sumaReservas?: boolean;
  codigoDescuento?: string; // 22/10: código de descuento (servidor/pagos/descuentos.ts)
}): Promise<ResultadoRegistroCarrito> {
  // Un "IFS-2026-XXXX" por cada hijo (mismo formato que registrarPedidoDesdePortal), que el servidor guarda.
  let pedidoFriendlyIds = params.items.map((_, idx) => params.pedidoFriendlyIds?.[idx] || nuevoNumeroPedido());
  try {
    const res = await fetchConTimeout('/api/pedidos/crear-multiple', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        tutorNombre: params.tutorNombre,
        tutorTelefono: params.tutorTelefono,
        tutorEmail: params.tutorEmail,
        ...datosAceptacion(),
        ...(params.confirmarOtroKit ? { confirmarOtroKit: true } : {}),
        // Auditoría 03/10 noche (A1): a nivel raíz del body.
        ...(params.claveCheckout ? { claveCheckout: params.claveCheckout } : {}),
        ...(params.sumaReservas ? { sumaReservas: true } : {}),
        ...(params.codigoDescuento ? { codigoDescuento: params.codigoDescuento } : {}),
        items: params.items.map((item, idx) => ({
          ...(params.pedidoIds?.[idx] ? { pedidoId: params.pedidoIds[idx] } : {}),
          colegioId: item.colegioId,
          colegioNombre: item.colegioNombre,
          cursoCodigo: item.cursoCodigo,
          grado: item.grado,
          division: item.division,
          turno: item.turno,
          alumnoNombre: item.alumnoNombre,
          alumnoNumeroLista: item.alumnoNumeroLista,
          kitId: item.kitId,
          kitNombre: item.kitNombre,
          metodoPago: item.metodoPago,
          fotosSeleccionadas: item.fotosSeleccionadas,
          copiasExtras: item.copiasExtras,
          pedidoFriendlyId: pedidoFriendlyIds[idx],
          // El servidor calcula el total de cada ítem a partir de kitId + carpetasExtras (mismo
          // criterio que /api/pedidos/crear) — nunca de un total mandado por el navegador.
          carpetasExtras: item.copiasExtras?.carpetasExtras || 0,
        })),
      }),
    });
    const data = await res.json().catch(() => null);
    if (res.status === 409 && data?.codigo === CODIGO_KIT_YA_PAGADO) {
      return {
        grupoPagoId: '',
        pedidoIds: [],
        pedidoFriendlyIds,
        total: 0,
        sincronizado: false,
        errorSincronizacion: data.error || 'Ya hay un kit pagado para uno de tus hijos/as.',
        codigo: CODIGO_KIT_YA_PAGADO,
        alumnos: nombresAlumnosDeRespuesta(data.alumnos),
      };
    }
    if (res.ok && data?.success) {
      guardarLlavePedido([data.grupoPagoId, ...(Array.isArray(data.pedidoIds) ? data.pedidoIds : [])], data.accesoToken);
      // Auditoría 2026-09-23: números de pedido definitivos (únicos) según el servidor.
      if (Array.isArray(data.pedidoFriendlyIds) && data.pedidoFriendlyIds.length === pedidoFriendlyIds.length) {
        pedidoFriendlyIds = data.pedidoFriendlyIds.map((fid: unknown, idx: number) => (typeof fid === 'string' && fid) || pedidoFriendlyIds[idx]);
      }
      // Auditoría 2026-09-22 (bug real, ALTA): a diferencia de registrarPedidoDesdePortal (que
      // guarda el pedido en localStorage antes de redirigir a pagar), esta función nunca lo
      // hacía. Mercado Pago y Nave fuerzan una recarga completa de la página (window.location.href
      // al checkout externo), así que al volver, el único rastro que le queda a este navegador de
      // lo que se acababa de pagar es lo que haya en localStorage — y para un carrito multi-hijo
      // eso siempre estaba vacío. Resultado: la pantalla de confirmación mostraba "Alumno" / "Kit
      // Retrato Escolar" / $0 en vez de los hijos y el total reales, justo para las familias que
      // usan el caso insignia de esta función (varios hijos, un solo pago). Se guardan acá los N
      // pedidos del carrito (uno por hijo, todos con el mismo grupoPagoId) igual que hace
      // registrarPedidoDesdePortal para el camino de un solo hijo — no se manda nada nuevo a
      // Supabase, sólo se cachea localmente lo que el servidor ya confirmó.
      const pedidosGuardadosPrevios = obtenerPedidosGuardados();
      const nuevosPedidos: PedidoEscolarCompleto[] = params.items.map((item, idx) => {
        const totalItem = calcularTotalItemLocal(item);
        const numLista = item.alumnoNumeroLista || pedidosGuardadosPrevios.length + idx + 1;
        const codigoAlumno = `${sanitizarParaMinilab(item.cursoCodigo)}_${String(numLista).padStart(2, '0')}_${sanitizarParaMinilab(item.alumnoNombre)}`;
        return {
          id: pedidoFriendlyIds[idx],
          supabaseId: data.pedidoIds?.[idx],
          grupoPagoId: data.grupoPagoId,
          fecha: new Date().toLocaleString('es-AR'),
          colegioId: item.colegioId,
          colegioNombre: item.colegioNombre,
          cursoCodigo: item.cursoCodigo.toUpperCase(),
          grado: item.grado,
          division: item.division,
          turno: item.turno,
          alumnoNumeroLista: numLista,
          alumnoNombre: item.alumnoNombre,
          codigoAlumno,
          tutorNombre: params.tutorNombre,
          tutorTelefono: params.tutorTelefono,
          tutorEmail: params.tutorEmail,
          kitId: item.kitId,
          kitNombre: item.kitNombre,
          total: totalItem,
          metodoPago: data.bonificado ? 'bonificado' : item.metodoPago,
          estadoPago: data.bonificado ? 'aprobado' : 'pendiente',
          estadoEntrega: 'en_espera',
          fotosSeleccionadas: item.fotosSeleccionadas,
          copiasExtras: item.copiasExtras,
          archivosParaLaboratorio: [],
          linkDescargaHD: '',
          emailEnviado: false,
          fechaEnvioEmail: undefined,
        };
      });
      const idsNuevos = new Set(nuevosPedidos.map((p) => p.supabaseId).filter(Boolean));
      guardarPedidosEnStorageDelPortal([...nuevosPedidos, ...pedidosGuardadosPrevios.filter((p) => !idsNuevos.has(p.supabaseId))]);

      return {
        grupoPagoId: data.grupoPagoId,
        pedidoIds: data.pedidoIds || [],
        pedidoFriendlyIds,
        total: data.total || 0,
        sincronizado: true,
        bonificado: Boolean(data.bonificado),
      };
    }
    return {
      grupoPagoId: '',
      pedidoIds: [],
      pedidoFriendlyIds,
      total: 0,
      sincronizado: false,
      errorSincronizacion: data?.error || `El servidor respondió con un error (HTTP ${res.status}).`,
    };
  } catch (e: any) {
    return {
      grupoPagoId: '',
      pedidoIds: [],
      pedidoFriendlyIds,
      total: 0,
      sincronizado: false,
      errorSincronizacion: e?.message || 'Error de conexión al registrar el carrito en el servidor.',
    };
  }
}

/**
 * Reconstruye un PedidoEscolarCompleto (la forma que usa toda la UI del panel) a partir de una
 * fila real de la tabla "pedidos" de Supabase (tal como la devuelve GET /api/admin/pedidos, con
 * su join a "familias"). Es la contraparte de registrarPedidoDesdePortal: mientras esa función
 * arma el pedido a partir de lo que completa la familia en el navegador, esta lo arma a partir
 * de lo que realmente quedó guardado en la base — así el panel de administración puede mostrar
 * pedidos reales aunque se abra desde un navegador o dispositivo distinto al de la familia que
 * compró (auditoría 2026-09-09, revisión a fondo).
 */
export function construirPedidoCompletoDesdeFila(fila: any, fotosDisponibles: Foto[] = FOTOS_MUESTRA): PedidoEscolarCompleto {
  const fotosSeleccionadas = (fila.fotos_seleccionadas && typeof fila.fotos_seleccionadas === 'object') ? fila.fotos_seleccionadas : { individualId: '', grupalId: '' };
  const copiasExtras: CopiasExtrasConfig = (fila.copias_extras && typeof fila.copias_extras === 'object')
    ? fila.copias_extras
    : {};
  const numLista = fila.alumno_numero_lista || 1;
  const cursoCodigo = fila.curso_codigo || '';
  const alumnoNombre = fila.alumno_nombre || 'Alumno';

  // 29/10/2026: un pedido de fotos extra muestra las copias que pidió la familia (no las 3 del kit).
  const archivosLab = fila.tipo_kit === 'fotos_extra' ? archivosLabDeFotosExtra(fila, fotosDisponibles) : generarArchivosParaLaboratorio(cursoCodigo, numLista, alumnoNombre, fotosSeleccionadas, copiasExtras, fotosDisponibles);

  // "estado" (columna real, sólo de PAGO): pendiente_pago | pagado | entregado (legado) |
  // cancelado. "estado_lab" (columna real, todo el pipeline FÍSICO): null | en_produccion |
  // listo_retiro | entregado — ver ETAPAS_LAB en server.ts.
  // Auditoría 2026-09-20 (revisión completa de estados): antes "entregado" existía como valor de
  // "estado" (mezclando "se cobró" con "se retiró"), pero nada en el panel llegó a escribirlo
  // nunca — era una etapa sin forma de alcanzarse. Ahora el retiro físico vive en estado_lab
  // (POST /api/admin/pedidos/:id/marcar-retirado) y "fila.estado === 'entregado'" queda sólo
  // como lectura de compatibilidad por si alguna fila vieja lo tuviera (hoy ninguna la tiene).
  // "estadoEntrega" es una vista derivada de estado_lab para las pantallas que ya existían antes
  // de esta auditoría (portal de familias, seguimiento) — estado_lab es la fuente de verdad.
  // "cancelado" se muestra como tal (antes caía en "Pendiente" y el panel ofrecía "Aprobar Pago"
  // sobre intentos de pago abandonados — caso real 25/9, 9 de 13 pedidos de prueba).
  let estadoPago: 'aprobado' | 'pendiente' | 'rechazado' = fila.estado === 'cancelado' ? 'rechazado' : 'pendiente';
  let estadoEntrega: PedidoEscolarCompleto['estadoEntrega'] = 'en_espera';
  // El pago lo define sólo `estado` (un pedido retirado sin pagar no se muestra como "Aprobado").
  if (fila.estado === 'entregado' || (fila.estado_lab === 'entregado' && fila.estado === 'pagado')) {
    estadoPago = 'aprobado';
    estadoEntrega = 'entregado';
  } else if (fila.estado === 'pagado') {
    estadoPago = 'aprobado';
    // Un kit pagado por adelantado no va al laboratorio hasta que la familia elija sus fotos.
    estadoEntrega = fila.seleccion_pendiente ? 'en_espera' : fila.estado_lab === 'listo_retiro' ? 'listo_retiro' : 'en_laboratorio';
  }

  const fecha = fila.created_at ? new Date(fila.created_at) : new Date();
  const fechaStr = `${String(fecha.getDate()).padStart(2, '0')}/${String(fecha.getMonth() + 1).padStart(2, '0')}/${fecha.getFullYear()} ${String(fecha.getHours()).padStart(2, '0')}:${String(fecha.getMinutes()).padStart(2, '0')}`;

  return {
    id: fila.pedido_friendly_id || fila.id,
    supabaseId: fila.id,
    grupoPagoId: fila.grupo_pago_id || undefined,
    fecha: fechaStr,
    colegioId: fila.colegio_id || '',
    colegioNombre: fila.colegio_nombre || 'Colegio',
    cursoCodigo: cursoCodigo,
    grado: fila.grado || '',
    division: fila.division || '',
    turno: fila.turno || '',
    alumnoNumeroLista: numLista,
    alumnoNombre,
    codigoAlumno: fila.codigo_alumno || '',
    tutorNombre: fila.familias?.nombre || '',
    tutorTelefono: fila.familias?.whatsapp || '',
    tutorEmail: fila.familias?.email || '',
    kitId: fila.tipo_kit === 'solo_digital' ? 'kit-digital' : fila.tipo_kit === 'fotos_extra' ? 'fotos-extra' : 'kit-clasico', // 29/10: las fotos extra no son un kit (no entran al ZIP de kits)
    kitNombre: fila.kit_nombre || (fila.tipo_kit === 'solo_digital' ? 'Kit Digital' : fila.tipo_kit === 'fotos_extra' ? 'Fotos extra' : 'Kit Clásico'),
    total: Number(fila.total) || 0,
    metodoPago: fila.metodo_pago || 'mercadopago',
    estadoPago,
    estadoEntrega,
    seleccionPendiente: Boolean(fila.seleccion_pendiente),
    mejoraDePedidoId: fila.mejora_de_pedido_id || null,
    archivado: Boolean(fila.archivado),
    enEspera: Boolean(fila.en_espera),
    notaEspera: fila.nota_espera || '',
    comprobanteSubidoAt: fila.comprobante_subido_at || null,
    recordatorioPagoAt: fila.recordatorio_pago_at || null,
    transferenciaDesde: fila.transferencia_desde || null,
    transferenciaVencidaAt: fila.transferencia_vencida_at || null,
    avisoVencimientoAt: fila.aviso_vencimiento_at || null,
    canceladoDefinitivo: Boolean(fila.cancelado_definitivo),
    descargaHdAt: fila.descarga_hd_at || null,
    descargasHd: Number(fila.descargas_hd) || 0,
    fotosSeleccionadas,
    copiasExtras,
    archivosParaLaboratorio: archivosLab,
    linkDescargaHD: fila.link_descarga_hd || '',
    emailEnviado: Boolean(fila.email_enviado),
    fechaEnvioEmail: fila.fecha_envio_email || undefined,
    estadoLab: fila.estado_lab || null,
    fechaEnvioProduccion: fila.fecha_envio_produccion || undefined,
    fechaEnvioListoRetiro: fila.fecha_envio_listo_retiro || undefined,
    fechaEntregado: fila.fecha_entregado || undefined,
  };
}

/** Pedido del panel con el lote del laboratorio en el que ya salió (si salió en alguno). */
export type PedidoConLoteLab = PedidoEscolarCompleto & { loteLabId?: string | null };

const CLAVE_FECHA_SINCRONIZACION = 'infocus_pedidos_escolares_v1_sincronizado';

/** Fecha (ISO) de la última vez que el panel trajo los pedidos del servidor en este navegador. */
export function obtenerFechaUltimaSincronizacion(): string | null {
  try {
    return localStorage.getItem(CLAVE_FECHA_SINCRONIZACION);
  } catch {
    return null;
  }
}

const IDS_FOTOS_POR_LLAMADA = 1000;

/** Ids de todas las fotos que usa un pedido (las tres elegidas más las sueltas). */
function idsFotosDeFila(fila: any): string[] {
  const s = fila?.fotos_seleccionadas && typeof fila.fotos_seleccionadas === 'object' ? fila.fotos_seleccionadas : {};
  return [s.individualId, s.grupalId, s.docenteId, ...(Array.isArray(s.otrasIds) ? s.otrasIds : [])].filter(
    (id): id is string => typeof id === 'string' && id.length > 0
  );
}

/**
 * Auditoría 03/10 (alto 16): antes se bajaba el catálogo ENTERO de fotos (`GET /api/admin/fotos`)
 * para cruzarlo con los pedidos — con miles de fotos la respuesta pasa los 4,5 MB de Vercel y el
 * panel caía, en silencio, a la copia vieja de localStorage. Ahora se piden sólo las fotos que
 * usan los pedidos (`POST /api/admin/fotos/por-ids`, de a 1000) y se cruzan con un Map por id.
 * Si el servidor todavía no tiene esa ruta (404), se usa la lista completa como antes.
 */
async function traerFotosDePedidos(filas: any[]): Promise<any[] | null> {
  const ids = [...new Set(filas.flatMap(idsFotosDeFila))];
  if (ids.length === 0) return [];
  const fotos: any[] = [];
  for (let i = 0; i < ids.length; i += IDS_FOTOS_POR_LLAMADA) {
    const res = await fetchAdminAutenticado('/api/admin/fotos/por-ids', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ids: ids.slice(i, i + IDS_FOTOS_POR_LLAMADA) }),
    });
    if (res.status === 404 && i === 0) {
      const viejo = await fetchAdminAutenticado('/api/admin/fotos');
      if (!viejo.ok) return null;
      const data = await viejo.json().catch(() => null);
      return data?.success && Array.isArray(data.fotos) ? data.fotos : null;
    }
    if (!res.ok) return null;
    const data = await res.json().catch(() => null);
    if (!data?.success || !Array.isArray(data.fotos)) return null;
    fotos.push(...data.fotos);
  }
  return fotos;
}

/**
 * Trae los pedidos reales desde Supabase (vía el servidor, con sesión de administrador) para el
 * panel. Devuelve null ante cualquier falla de red/servidor en vez de tirar, para que el panel
 * pueda seguir mostrando lo que tenga en localStorage como respaldo (con aviso visible).
 */
/** Auditoría 11/10 (ADM-3): el servidor respondió 401 (sesión vencida), que no es "sin conexión". */
export const SESION_ADMIN_VENCIDA = 'sesion_vencida' as const;
export async function obtenerPedidosAdminDesdeSupabase(): Promise<PedidoConLoteLab[] | null | typeof SESION_ADMIN_VENCIDA> {
  try {
    const resPedidos = await fetchAdminAutenticado('/api/admin/pedidos');
    if (resPedidos.status === 401) return SESION_ADMIN_VENCIDA;
    if (!resPedidos.ok) return null;
    const dataPedidos = await resPedidos.json();
    if (!dataPedidos?.success || !Array.isArray(dataPedidos.pedidos)) return null;
    const filasFotos = await traerFotosDePedidos(dataPedidos.pedidos);
    if (!filasFotos) return null;

    const fotosPorId = new Map<string, Foto>();
    for (const foto of filasFotos) {
      fotosPorId.set(foto.id, {
        id: foto.id,
        url: `/api/admin/fotos/${encodeURIComponent(foto.id)}/original`,
        thumbnail: foto.thumb_path || foto.preview_path || '',
        categoria: foto.categoria,
        titulo: foto.alumno_nombre || `Foto ${foto.categoria}`,
      });
    }

    const pedidos = dataPedidos.pedidos.map((fila: any) => ({
      // A cada pedido se le pasan sólo SUS fotos (búsqueda por Map, no un .find sobre miles).
      ...construirPedidoCompletoDesdeFila(fila, idsFotosDeFila(fila).map((id) => fotosPorId.get(id)).filter((f): f is Foto => Boolean(f))),
      loteLabId: fila.lote_lab_id || null,
    }));
    try {
      localStorage.setItem(CLAVE_FECHA_SINCRONIZACION, new Date().toISOString());
    } catch {
      /* nada */
    }
    return pedidos;
  } catch (e) {
    console.warn('No se pudieron obtener los pedidos reales de Supabase:', e);
    // null (y no []): así quien llama distingue "no pude consultar" de "no hay pedidos".
    return null;
  }
}

/**
 * Auditoría 2026-09-18 (pedido de Pablo: automatizar el .zip de descarga HD): esto ya se intenta
 * solo apenas se confirma el pago (en los webhooks del servidor). Esta función es el reintento
 * manual desde el panel — para cuando esa generación automática falló (por ejemplo, si en ese
 * momento todavía no estaban cargadas las fotos del curso) — usada por "Reenviar Email HD".
 */
export async function generarZipHDAdmin(pedidoSupabaseId: string): Promise<{ success: boolean; linkDescargaHD?: string; error?: string }> {
  try {
    const res = await fetchAdminAutenticado(`/api/admin/pedidos/${encodeURIComponent(pedidoSupabaseId)}/generar-zip-hd`, {
      method: 'POST',
    });
    const data = await res.json();
    if (!res.ok || !data.success) {
      return { success: false, error: data.error || 'No se pudo generar el .zip HD.' };
    }
    return { success: true, linkDescargaHD: data.linkDescargaHD };
  } catch (err: any) {
    return { success: false, error: err?.message || 'Error de red al generar el .zip HD.' };
  }
}

/**
 * Auditoría 05/10: borrado de pedido desde el panel con el freno del servidor. Si el pedido está
 * pagado/entregado (o en un lote del laboratorio) el servidor responde 409 con `codigo:
 * 'PEDIDO_PAGADO'`; el panel muestra una confirmación específica y recién ahí reintenta con `forzar`.
 */
export async function eliminarPedidoAdminConControl(
  pedidoSupabaseId: string,
  forzar = false,
): Promise<{ success: boolean; codigo?: string; pedidoFriendlyId?: string | null; error?: string }> {
  try {
    const res = await fetchAdminAutenticado(`/api/admin/pedidos/${encodeURIComponent(pedidoSupabaseId)}${forzar ? '?forzar=1' : ''}`, {
      method: 'DELETE',
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok || !data.success) {
      return { success: false, codigo: data.codigo, pedidoFriendlyId: data.pedidoFriendlyId, error: data.error || 'No se pudo eliminar el pedido.' };
    }
    return { success: true };
  } catch (err: any) {
    return { success: false, error: err?.message || 'Error de red al eliminar el pedido.' };
  }
}

/**
 * Auditoría 2026-09-20 (revisión completa de estados, pedido de Pablo): cierra el pipeline físico
 * del pedido registrando que la familia ya vino y se llevó sus fotos. El servidor exige que el
 * pedido ya esté en "listo_retiro" (ver POST /api/admin/pedidos/:id/marcar-retirado en server.ts)
 * — no se puede marcar como retirado algo que nunca avisamos que estaba listo.
 */
export async function marcarPedidoRetirado(pedidoSupabaseId: string): Promise<{ success: boolean; estadoLab?: string; fechaEntregado?: string; error?: string }> {
  try {
    const res = await fetchAdminAutenticado(`/api/admin/pedidos/${encodeURIComponent(pedidoSupabaseId)}/marcar-retirado`, {
      method: 'POST',
    });
    const data = await res.json();
    if (!res.ok || !data.success) {
      return { success: false, error: data.error || 'No se pudo marcar el pedido como retirado.' };
    }
    return { success: true, estadoLab: data.estadoLab, fechaEntregado: data.fechaEntregado };
  } catch (err: any) {
    return { success: false, error: err?.message || 'Error de red al marcar el pedido como retirado.' };
  }
}

/**
 * Auditoría 2026-09-21: la familia cambia el medio de pago de un pedido que sigue "Pendiente de Pago" (ver
 * POST /api/pedidos/:id/cambiar-metodo-pago). 14/10/2026: `confirmarIgual` = pasar a tarjeta aunque ya subió el
 * comprobante de una transferencia (si no, el servidor responde 409 `codigo: COMPROBANTE_YA_SUBIDO`).
 */
export async function cambiarMetodoPagoPedido(
  pedidoSupabaseId: string,
  metodoPago: 'mercadopago' | 'nave' | 'transferencia',
  referenciaLlave?: string,
  confirmarIgual?: boolean
): Promise<{ success: boolean; error?: string; codigo?: string }> {
  try {
    // Auditoría 30/9: el servidor exige la llave del pedido (o de su grupo de pago).
    const t = obtenerLlavePedido(referenciaLlave || pedidoSupabaseId) || obtenerLlavePedido(pedidoSupabaseId);
    const res = await fetchConTimeout(`/api/pedidos/${encodeURIComponent(pedidoSupabaseId)}/cambiar-metodo-pago`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ metodoPago, t, ...(confirmarIgual ? { confirmarIgual: true } : {}) }),
    });
    const data = await res.json().catch(() => ({}));
    if (res.status === 429) return { success: false, error: 'Demasiados intentos, esperá unos minutos y volvé a probar.' };
    if (!res.ok || !data.success) {
      return { success: false, error: data.error || 'No se pudo cambiar el método de pago.', codigo: data.codigo };
    }
    return { success: true };
  } catch (err: any) {
    return { success: false, error: err?.message || 'Error de red al cambiar el método de pago.' };
  }
}

/**
 * Combina los pedidos reales de Supabase con cualquier pedido que sólo exista en el
 * localStorage de este navegador (por ejemplo, uno creado hace un instante cuya sincronización
 * con el servidor todavía no se refleja en una lectura posterior). Supabase es la fuente de la
 * verdad: si un pedido está en ambos lados, se usa siempre la versión del servidor.
 */
export function combinarPedidosConLocal(pedidosServidor: PedidoEscolarCompleto[] | null, pedidosLocales: PedidoEscolarCompleto[]): PedidoEscolarCompleto[] {
  // Sin respuesta del servidor (sin conexión, sesión vencida): se muestra lo guardado localmente.
  if (pedidosServidor === null) return pedidosLocales;
  const idsServidor = new Set(pedidosServidor.map((p) => p.supabaseId).filter(Boolean));
  // Auditoría 2026-09-24 (bug real): antes se conservaban también los pedidos locales que SÍ
  // tenían id de Supabase pero ya no existen en el servidor (borrados desde otra computadora o con
  // "Cerrar año") — quedaban como fantasmas en el panel para siempre. Si el servidor respondió,
  // sólo se suman los locales que nunca llegaron a registrarse (sin supabaseId).
  const localesSinServidor = pedidosLocales.filter((p) => !p.supabaseId);
  return [...pedidosServidor, ...localesSinServidor.filter((p) => !idsServidor.has(p.id))];
}

export interface PedidoSeguimiento {
  id: string;
  colegio: string;
  alumno: string;
  grado: string;
  division: string;
  tutor: string;
  telefono: string;
  kit: string;
  total: number;
  fecha: string;
  estado: 'pendiente_pago' | 'pagado' | 'entregado' | 'cancelado';
  linkDescargaHD?: string;
  /** Pago anticipado: kit pagado (o por pagar) que todavía espera que la familia elija las fotos. */
  reservaPendiente?: boolean;
  /** El pedido está cobrado y tiene descarga HD: se puede pedir que se reenvíe el link por email. */
  puedeReenviarLink?: boolean;
}

/**
 * Auditoría 2026-09-26 (A2): el buscador ya no devuelve el link HD (el número de pedido se puede
 * adivinar). En su lugar, el servidor reenvía el link al email de la familia que hizo el pedido.
 */
export async function reenviarLinkDescargaPorEmail(numero: string): Promise<{ success: boolean; mensaje?: string; emailDestino?: string; error?: string }> {
  try {
    const res = await fetchConTimeout('/api/pedidos/reenviar-link', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ numero }),
    });
    const data = await res.json().catch(() => null);
    if (!res.ok || !data?.success) return { success: false, error: data?.error || 'No pudimos reenviar el link. Probá de nuevo en unos minutos.' };
    return data;
  } catch (err) {
    return { success: false, error: err instanceof ErrorTiempoAgotado ? err.message : 'Error de conexión. Revisá tu internet e intentá de nuevo.' };
  }
}

/**
 * Busca un pedido por número de pedido o teléfono contra el servidor (Supabase), para que el
 * seguimiento de pedidos de una familia funcione aunque esté en un dispositivo o navegador
 * distinto al que usó para comprar. Devuelve null si no hay coincidencia o si falla la consulta
 * (auditoría 2026-09-09, revisión a fondo — antes esta búsqueda sólo miraba el localStorage).
 */
export class ErrorLimiteBusqueda extends Error {}

export async function buscarPedidoPorSeguimiento(query: string): Promise<PedidoSeguimiento | null> {
  try {
    const res = await fetchConTimeout(`/api/pedidos/buscar?query=${encodeURIComponent(query)}`);
    const data = await res.json().catch(() => null);
    // Límite de búsquedas alcanzado: se avisa tal cual (antes se informaba "no encontramos tu
    // pedido", y la familia creía que su pedido no existía).
    if (res.status === 429) throw new ErrorLimiteBusqueda(data?.error || 'Demasiadas búsquedas seguidas. Probá de nuevo en unos minutos.');
    if (!res.ok || !data?.success || !data.pedido) return null;
    return data.pedido as PedidoSeguimiento;
  } catch (e) {
    if (e instanceof ErrorLimiteBusqueda) throw e;
    // Auditoría 03/10: si el servidor no respondió a tiempo no es "no encontramos tu pedido": se
    // muestra el aviso de tiempo agotado tal cual (mismo camino que el límite de búsquedas).
    if (e instanceof ErrorTiempoAgotado) throw new ErrorLimiteBusqueda(e.message);
    console.warn('Error al buscar el pedido por seguimiento:', e);
    return null;
  }
}

/** Resumen mínimo de un pedido ya existente, para el cartel de confirmación antes de comprar de nuevo. */
export interface PedidoExistenteResumen {
  id: string;
  kit: string;
  total: number;
  estado: 'pendiente_pago' | 'pagado' | 'entregado' | 'cancelado';
  fecha: string;
  /** Kit pagado por adelantado que todavía espera que la familia elija sus fotos. */
  reservaPendiente?: boolean;
  /** Auditoría 05/10: sólo viene con la llave de la familia (o del pedido); si no, `requiereLlave`. */
  pedidoUuid?: string | null;
  requiereLlave?: boolean;
  metodoPago?: string | null;
  /** Kit Solo Digital ya pago con fotos elegidas: se puede pasar a Kit Impreso pagando la diferencia. */
  puedeMejorarAImpreso?: boolean;
  mejoraAImpresoPagada?: boolean;
  precioMejoraAImpreso?: number;
  /** 14/10/2026: para pagar/cambiar el medio desde otro dispositivo (sólo a la familia identificada y pendiente). */
  grupoPagoId?: string | null; accesoToken?: string | null;
  comprobanteSubido?: boolean; // 14/10/2026: transferencia con el comprobante ya subido (en revisión)
  puedeComprarFotosExtra?: boolean; fotosExtraPagadas?: number; preciosFotosExtra?: { extra15x21: number; extra20x30: number }; // 29/10/2026: fotos extra
}

/** Kit Solo Digital ya pago → Kit Impreso pagando la diferencia (27/9/2026): crea o reutiliza la mejora (se cobra con Mercado Pago). */
export async function prepararMejoraAImpreso(
  pedidoUuid: string,
  codigo: string,
  /** Auditoría 05/10: el servidor exige la llave de la familia (galería) o la del pedido original. */
  credenciales?: { familia?: string | null; acceso?: string | null; metodoPago?: 'mercadopago' | 'nave' | 'transferencia' } // 29/10: + medio de pago (los 3, como el kit)
): Promise<{ success: boolean; pedidoId?: string; pedidoFriendlyId?: string; total?: number; accesoToken?: string | null; error?: string }> {
  try {
    const llavePedido = obtenerLlavePedido(pedidoUuid);
    const res = await fetch(`/api/pedidos/${encodeURIComponent(pedidoUuid)}/mejorar-a-impreso`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        codigo, metodoPago: credenciales?.metodoPago || 'mercadopago',
        ...(credenciales?.familia && credenciales?.acceso ? { familia: credenciales.familia, acceso: credenciales.acceso } : {}),
        ...(llavePedido ? { t: llavePedido } : {}),
      }),
    });
    const data = await res.json().catch(() => null);
    if (!res.ok || !data?.success) return { success: false, error: data?.error || 'No pudimos preparar el cambio a Kit Impreso.' };
    guardarLlavePedido([data.pedidoId], data.accesoToken);
    return data;
  } catch (err: any) {
    return { success: false, error: err?.message || 'Error de red.' };
  }
}

/**
 * Auditoría 2026-09-22 (pedido de Pablo: "por qué me deja volver a comprar si ya tengo un
 * pedido hecho? debería mostrarme el pedido que ya realicé y preguntarme si deseo hacer otro").
 * Se llama justo antes de abrir la galería de un alumno/a puntual, para avisar si ese mismo
 * alumno ya tiene un pedido registrado en ese curso. Devuelve `null` tanto si no hay ningún
 * pedido como si falla la consulta — el chequeo nunca debe bloquear a la familia de comprar,
 * sólo avisarle cuando puede hacerlo con conocimiento de causa.
 */
// Auditoría 2026-09-23: antes recibía el código SECRETO de la sección y el servidor lo comparaba
// contra `pedidos.curso_codigo` (el código determinístico de curso) — nunca coincidían y el aviso
// no aparecía jamás. Ahora se mandan colegio/grado/turno/división y el servidor recalcula el
// código de curso con la misma fórmula con la que guarda los pedidos.
// Auditoría 2026-09-26 (C2): el servidor ahora exige el código secreto de la sección (el mismo que
// abre la galería) y deduce colegio y curso de ese código.
export async function verificarPedidoExistente(datos: {
  codigo?: string | null;
  alumnoNombre?: string;
}): Promise<PedidoExistenteResumen | null> {
  const { codigo, alumnoNombre } = datos;
  if (!codigo || !alumnoNombre) return null;
  try {
    const params = new URLSearchParams({ codigo, alumnoNombre });
    const res = await fetch(`/api/pedidos/existente?${params.toString()}`);
    const data = await res.json().catch(() => null);
    if (!res.ok || !data?.success || !data.existe || !data.pedido) return null;
    return data.pedido as PedidoExistenteResumen;
  } catch (e) {
    console.warn('Error al verificar si ya existe un pedido para este alumno:', e);
    return null;
  }
}

/**
 * Archivar/desarchivar un pedido o ponerlo/sacarlo "en espera" (con una nota) sin borrarlo.
 * Ver POST /api/admin/pedidos/:id/organizar en server.ts.
 */
export async function organizarPedidoAdmin(
  pedidoSupabaseId: string,
  cambios: { archivado?: boolean; enEspera?: boolean; notaEspera?: string }
): Promise<{ success: boolean; archivado?: boolean; enEspera?: boolean; notaEspera?: string; error?: string }> {
  try {
    const res = await fetchAdminAutenticado(`/api/admin/pedidos/${encodeURIComponent(pedidoSupabaseId)}/organizar`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(cambios),
    });
    const data = await res.json();
    if (!res.ok || !data.success) return { success: false, error: data.error || 'No se pudo actualizar el pedido.' };
    return data;
  } catch (err: any) {
    return { success: false, error: err?.message || 'Error de red al actualizar el pedido.' };
  }
}

/** Link temporal (10 min) para ver el comprobante de transferencia de un pedido. */
export async function obtenerLinkComprobanteAdmin(pedidoId: string): Promise<{ success: boolean; url?: string; error?: string }> {
  try {
    const res = await fetchAdminAutenticado(`/api/admin/pedidos/${encodeURIComponent(pedidoId)}/comprobante`);
    const data = await res.json();
    if (!res.ok || !data.success) return { success: false, error: data.error || 'No se pudo abrir el comprobante.' };
    return { success: true, url: data.url };
  } catch (err: any) {
    return { success: false, error: err?.message || 'Error de conexión.' };
  }
}

/**
 * Pedido de Pablo (28/9): pedido ya entregado a la familia, que sale del listado principal y va a
 * la lista "Entregados" del panel. Es entregado:
 *  - un kit Solo Digital pagado, con las fotos elegidas y el correo con el link HD ya enviado;
 *  - un kit impreso que el laboratorio ya marcó como retirado.
 */
export function pedidoEstaEntregado(p: Pick<PedidoEscolarCompleto, 'estadoPago' | 'kitId' | 'emailEnviado' | 'seleccionPendiente' | 'estadoEntrega'>): boolean {
  if (p.estadoPago !== 'aprobado') return false;
  if (p.estadoEntrega === 'entregado') return true;
  return p.kitId === 'kit-digital' && Boolean(p.emailEnviado) && !p.seleccionPendiente;
}
