import { useState, useEffect, useCallback } from 'react';
import { Colegio } from '../types';
import { fetchAdminAutenticado, obtenerTokenAdmin } from './adminAuthService';
import { fetchConTimeout } from '../utils/fetchConTimeout';

/**
 * Perfil de cada colegio: se guarda en Supabase (tabla `colegios`) y es compartido por
 * todos los visitantes del sitio. Este valor por defecto solo se usa como respaldo mientras
 * se carga la lista real desde el servidor, o si la conexión falla.
 */
export const COLEGIO_POR_DEFECTO: Colegio = {
  id: 'col-divino-pastor-2026',
  slug: 'instituto-madre-del-divino-pastor',
  nombre: 'Instituto Madre del Divino Pastor',
  localidad: 'Buenos Aires',
  zona: 'Zona Norte',
  eventoActual: 'Temporada Oficial Retratos y Fotos Escolares 2026',
  codigoAcceso: 'IMDP2026',
  grados: [
    'Sala 3 años',
    'Sala 4 años',
    'Sala 5 años',
    '1° grado',
    '2° grado',
    '3° grado',
    '4° grado',
    '5° grado',
    '6° grado',
    '7° grado',
    '1° año',
    '2° año',
    '3° año',
    '4° año',
    '5° año',
    '6° año',
  ],
  divisiones: ['A', 'B', 'C', 'Jornada Extendida'],
  turnos: ['Mañana', 'Tarde', 'Jornada Extendida / Completa'],
};

export interface DatosColegio {
  nombre: string;
  localidad?: string;
  zona?: 'CABA' | 'Zona Norte' | 'Zona Sur' | 'Zona Oeste';
  codigoAcceso: string;
  whatsappContacto?: string;
  grados?: string[];
  divisiones?: string[];
  turnos?: string[];
  eventoActual?: string;
  /** 04/10: interruptor «Muestras con lupa». */
  muestrasLupa?: boolean;
}

export interface ResultadoColegio {
  success: boolean;
  colegio?: Colegio;
  error?: string;
}

export interface ResultadoEliminarColegio {
  success: boolean;
  error?: string;
}

/** Trae la lista pública de colegios desde el servidor (Supabase). Sin autenticación: la necesitan
 *  el buscador del sitio y el formulario de inscripción antes de que la familia se identifique. */
// Auditoría 03/10 (medio): la home pedía /api/colegios 3 veces al cargar (Hero, portal e
// inscripción usan este hook, aunque el portal ni se abra) y cada alta/edición en el panel volvía
// a disparar una consulta por cada componente montado. Ahora hay una sola promesa compartida por
// "modo" (público o admin con colegios ocultos) y la lista queda en memoria CACHE_COLEGIOS_MS. Una
// alta/edición/baja invalida la caché antes de avisar al resto de la página.
const CACHE_COLEGIOS_MS = 5 * 60 * 1000;
const cacheColegios = new Map<string, { lista: Colegio[]; momento: number; exitosa: boolean }>();
const colegiosEnCurso = new Map<string, Promise<Colegio[]>>();

function claveCacheColegios(): string {
  return obtenerTokenAdmin() ? 'admin' : 'publico';
}

/** La lista ya cargada (si hay y no venció), para arrancar el hook sin parpadeo. */
function colegiosEnCache(): Colegio[] | null {
  const entrada = cacheColegios.get(claveCacheColegios());
  if (!entrada || !entrada.exitosa || Date.now() - entrada.momento > CACHE_COLEGIOS_MS) return null;
  return entrada.lista;
}

export function invalidarCacheColegios(): void {
  cacheColegios.clear();
  colegiosEnCurso.clear();
}

/** Lista de colegios con una sola llamada compartida y caché en memoria (ver arriba). */
export function obtenerColegiosCompartido(forzar = false): Promise<Colegio[]> {
  const clave = claveCacheColegios();
  if (!forzar) {
    const enCache = colegiosEnCache();
    if (enCache) return Promise.resolve(enCache);
    const enCurso = colegiosEnCurso.get(clave);
    if (enCurso) return enCurso;
  }
  const promesa = obtenerColegiosRemotoConEstado()
    .then(({ lista, exitosa }) => {
      // Una respuesta fallida (lista de respaldo) no se guarda como buena: el próximo pide de nuevo.
      cacheColegios.set(clave, { lista, momento: Date.now(), exitosa });
      return lista;
    })
    .finally(() => {
      if (colegiosEnCurso.get(clave) === promesa) colegiosEnCurso.delete(clave);
    });
  colegiosEnCurso.set(clave, promesa);
  return promesa;
}

export async function obtenerColegiosRemoto(): Promise<Colegio[]> {
  return (await obtenerColegiosRemotoConEstado()).lista;
}

async function obtenerColegiosRemotoConEstado(): Promise<{ lista: Colegio[]; exitosa: boolean }> {
  try {
    // Con la sesión del fotógrafo abierta se traen también los colegios ocultos (el de prueba).
    const token = obtenerTokenAdmin();
    const res = token
      ? await fetchConTimeout('/api/colegios?todos=1', { headers: { Authorization: `Bearer ${token}` } })
      : await fetchConTimeout('/api/colegios');
    const data = await res.json().catch(() => ({}));
    if (!res.ok || !data.success || !Array.isArray(data.colegios)) {
      return { lista: [COLEGIO_POR_DEFECTO], exitosa: false };
    }
    return { lista: data.colegios.length > 0 ? data.colegios : [COLEGIO_POR_DEFECTO], exitosa: true };
  } catch (err) {
    console.error('Error al obtener la lista de colegios:', err);
    return { lista: [COLEGIO_POR_DEFECTO], exitosa: false };
  }
}

/** Panel admin: da de alta un nuevo colegio en Supabase (visible al instante para todo el sitio) */
export async function crearColegioAdmin(datos: DatosColegio): Promise<ResultadoColegio> {
  try {
    const res = await fetchAdminAutenticado('/api/admin/colegios', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(datos),
    });
    const data = await res.json();
    if (!res.ok || !data.success || !data.colegio) {
      return { success: false, error: data.error || 'No se pudo crear el colegio.' };
    }
    return { success: true, colegio: data.colegio };
  } catch (err: any) {
    return { success: false, error: err?.message || 'Error de red al crear el colegio.' };
  }
}

/** Panel admin: actualiza nombre, localidad, código, WhatsApp, grados/divisiones/turnos de un colegio existente */
export async function actualizarColegioAdmin(
  id: string,
  cambios: Partial<DatosColegio>
): Promise<ResultadoColegio> {
  try {
    const res = await fetchAdminAutenticado(`/api/admin/colegios/${encodeURIComponent(id)}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(cambios),
    });
    const data = await res.json();
    if (!res.ok || !data.success || !data.colegio) {
      return { success: false, error: data.error || 'No se pudo actualizar el colegio.' };
    }
    return { success: true, colegio: data.colegio };
  } catch (err: any) {
    return { success: false, error: err?.message || 'Error de red al actualizar el colegio.' };
  }
}

/** Atajo para actualizar solo el WhatsApp de contacto propio de un colegio */
export async function actualizarWhatsappColegio(colegioId: string, whatsapp: string): Promise<ResultadoColegio> {
  return actualizarColegioAdmin(colegioId, { whatsappContacto: whatsapp });
}

/** Panel admin: elimina un colegio (falla si todavía tiene familias/pedidos asociados) */
export async function eliminarColegioAdmin(id: string): Promise<ResultadoEliminarColegio> {
  try {
    const res = await fetchAdminAutenticado(`/api/admin/colegios/${encodeURIComponent(id)}`, {
      method: 'DELETE',
    });
    const data = await res.json();
    if (!res.ok || !data.success) {
      return { success: false, error: data.error || 'No se pudo eliminar el colegio.' };
    }
    return { success: true };
  } catch (err: any) {
    return { success: false, error: err?.message || 'Error de red al eliminar el colegio.' };
  }
}

/**
 * Panel admin: trae el token secreto de carga de padrón de cada colegio (nunca viaja por la lista
 * pública de colegios). Con esto se arma el link que el fotógrafo comparte con la secretaría.
 */
export async function obtenerTokensPadronAdmin(): Promise<Record<string, string>> {
  try {
    const res = await fetchAdminAutenticado('/api/admin/colegios/padron-links');
    const data = await res.json();
    if (!res.ok || !data.success) return {};
    return data.tokens || {};
  } catch (err) {
    console.error('Error al obtener los links de padrón:', err);
    return {};
  }
}

export interface LinkConvenioColegio {
  codigo: string;
  firmadoAt: string | null;
  firmante: string | null;
}

/** Panel admin: link del convenio de cada colegio (/convenio.html?c=CODIGO) y si ya lo firmó. */
export async function obtenerLinksConvenioAdmin(): Promise<Record<string, LinkConvenioColegio>> {
  try {
    const res = await fetchAdminAutenticado('/api/admin/colegios/convenio-links');
    const data = await res.json();
    if (!res.ok || !data.success) return {};
    return data.links || {};
  } catch (err) {
    console.error('Error al obtener los links del convenio:', err);
    return {};
  }
}

/** Panel admin: regenera el token secreto de un colegio (invalida el link anterior) */
export async function regenerarTokenPadronAdmin(colegioId: string): Promise<{ success: boolean; codigoPadron?: string; error?: string }> {
  try {
    const res = await fetchAdminAutenticado(`/api/admin/colegios/${encodeURIComponent(colegioId)}/regenerar-padron`, {
      method: 'POST',
    });
    const data = await res.json();
    if (!res.ok || !data.success) {
      return { success: false, error: data.error || 'No se pudo regenerar el link.' };
    }
    return { success: true, codigoPadron: data.codigoPadron };
  } catch (err: any) {
    return { success: false, error: err?.message || 'Error de red al regenerar el link.' };
  }
}

export interface AlumnoNominaReal {
  id: string;
  nombre: string;
  grado: string;
  division: string;
  turno: string | null;
  colegio_id: string | null;
  numero_lista: number | null;
  dni: string | null;
  origen: string | null;
  /** 13/10/2026: cuándo se marcó como fotografiado en la Nómina (null = sin marcar). */
  fotografiado_at?: string | null;
  /** 14/10/2026: foto grupal sacada (se puede sacar otro día que la individual). */
  foto_grupal_at?: string | null;
  /** 21/10/2026: foto con la seño sacada (desde ese día `fotografiado_at` es sólo la individual). */
  foto_seno_at?: string | null;
}

/**
 * Panel admin: trae la nómina REAL de alumnos (tabla 'alumnos' de Supabase, cargada por el
 * importador de padrón), no la lista vieja hardcodeada de src/data/alumnosData.ts. Opcionalmente
 * se puede filtrar por colegioId.
 */
export async function obtenerAlumnosNominaAdmin(colegioId?: string): Promise<AlumnoNominaReal[]> {
  try {
    const query = colegioId ? `?colegioId=${encodeURIComponent(colegioId)}` : '';
    const res = await fetchAdminAutenticado(`/api/admin/alumnos${query}`);
    const data = await res.json();
    if (!res.ok || !data.success) return [];
    return data.alumnos || [];
  } catch (err) {
    console.error('Error al obtener la nómina de alumnos:', err);
    return [];
  }
}

export interface FilaAlumnoAImportar {
  nombre: string;
  grado: string;
  division: string;
  turno?: string | null;
  numeroLista?: number | null;
  dni?: string | null;
}

export interface ResultadoImportarAlumnos {
  success: boolean;
  importados: number;
  descartados: number;
  /** 14/10/2026: filas que ya estaban en la nómina (no se volvieron a cargar). */
  repetidos?: number;
  error?: string;
}

/**
 * Carga en lote una lista de alumnos (tabla 'alumnos') para un colegio puntual — pensado para
 * pegar el rango que sale de copiar dos columnas de Excel (número de lista + nombre) y cargar
 * así una sección (grado/turno/división) por vez.
 */
export async function importarAlumnosAdmin(
  colegioId: string,
  filas: FilaAlumnoAImportar[]
): Promise<ResultadoImportarAlumnos> {
  try {
    const res = await fetchAdminAutenticado('/api/admin/alumnos/importar', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ colegioId, filas }),
    });
    const data = await res.json();
    if (!res.ok || !data.success) {
      return { success: false, importados: 0, descartados: filas.length, error: data?.error || 'No se pudo importar la lista.' };
    }
    return { success: true, importados: data.importados || 0, descartados: data.descartados || 0, repetidos: data.repetidos || 0 };
  } catch (err: any) {
    return { success: false, importados: 0, descartados: filas.length, error: err?.message || 'Error de conexión al importar.' };
  }
}

export async function eliminarAlumnoAdmin(id: string): Promise<{ success: boolean; error?: string }> {
  try {
    const res = await fetchAdminAutenticado(`/api/admin/alumnos/${encodeURIComponent(id)}`, { method: 'DELETE' });
    const data = await res.json();
    if (!res.ok || !data.success) {
      return { success: false, error: data?.error || 'No se pudo eliminar el alumno.' };
    }
    return { success: true };
  } catch (err: any) {
    return { success: false, error: err?.message || 'Error de conexión al eliminar.' };
  }
}

/**
 * Hook de React para consumir la lista de colegios y reaccionar automáticamente a altas/bajas/ediciones.
 * La lista vive en Supabase: es la misma para todos los visitantes del sitio.
 */
export function useColegiosLista(): {
  colegios: Colegio[];
  cargando: boolean;
  agregarColegio: (datos: DatosColegio) => Promise<ResultadoColegio>;
  editarColegio: (id: string, cambios: Partial<DatosColegio>) => Promise<ResultadoColegio>;
  borrarColegio: (id: string) => Promise<ResultadoEliminarColegio>;
  recargarColegios: () => void;
} {
  const [colegios, setColegios] = useState<Colegio[]>(() => colegiosEnCache() || [COLEGIO_POR_DEFECTO]);
  const [cargando, setCargando] = useState(() => !colegiosEnCache());

  const recargar = useCallback(() => {
    let vivo = true;
    setCargando(true);
    obtenerColegiosCompartido()
      .then((lista) => {
        if (vivo) setColegios(lista);
      })
      .finally(() => {
        if (vivo) setCargando(false);
      });
    return () => {
      vivo = false;
    };
  }, []);

  useEffect(() => {
    const cancelar = recargar();

    // Otro componente cambió la lista: ya invalidó la caché, así que todos los hooks montados
    // comparten UNA consulta nueva.
    const handleActualizacion = () => recargar();
    window.addEventListener('colegios_actualizados', handleActualizacion);
    return () => {
      cancelar();
      window.removeEventListener('colegios_actualizados', handleActualizacion);
    };
  }, [recargar]);

  const agregarColegio = async (datos: DatosColegio): Promise<ResultadoColegio> => {
    const resultado = await crearColegioAdmin(datos);
    if (resultado.success) {
      invalidarCacheColegios();
      recargar();
      if (typeof window !== 'undefined') {
        window.dispatchEvent(new CustomEvent('colegios_actualizados'));
      }
    }
    return resultado;
  };

  const editarColegio = async (id: string, cambios: Partial<DatosColegio>): Promise<ResultadoColegio> => {
    const resultado = await actualizarColegioAdmin(id, cambios);
    if (resultado.success) {
      invalidarCacheColegios();
      recargar();
      if (typeof window !== 'undefined') {
        window.dispatchEvent(new CustomEvent('colegios_actualizados'));
      }
    }
    return resultado;
  };

  const borrarColegio = async (id: string): Promise<ResultadoEliminarColegio> => {
    const resultado = await eliminarColegioAdmin(id);
    if (resultado.success) {
      invalidarCacheColegios();
      recargar();
      if (typeof window !== 'undefined') {
        window.dispatchEvent(new CustomEvent('colegios_actualizados'));
      }
    }
    return resultado;
  };

  return {
    colegios,
    cargando,
    agregarColegio,
    editarColegio,
    borrarColegio,
    // Recarga pedida a mano (p. ej. después de editar un colegio): siempre trae la lista nueva.
    recargarColegios: () => {
      invalidarCacheColegios();
      recargar();
    },
  };
}

// ==============================================================================
// Liquidación al colegio (1/10): % de la ganancia neta (cláusula OCTAVA BIS del convenio).
// ==============================================================================
export interface CostosLiquidacion {
  costo_carpeta: number;
  costo_foto_20x30: number;
  costo_foto_15x21: number;
  comision_mercadopago_pct: number;
  comision_nave_pct: number;
  impuestos_pct: number;
}

export interface FilaLiquidacion {
  pedido: string;
  fecha: string;
  /** Fecha de cobro (define a qué período de liquidación pertenece). */
  pagado: string | null;
  comisionOrigen: 'real' | 'estimada' | 'sin_comision';
  retencionesInformadas: number;
  porActualizar: boolean;
  alumno: string;
  curso: string;
  kit: string;
  medio: string;
  venta: number;
  carpetas: number;
  fotos20x30: number;
  fotos15x21: number;
  costoLaboratorio: number;
  comision: number;
  impuestos: number;
  ganancia: number;
  fotosPendientes: boolean;
}

export interface Liquidacion {
  colegio: { id: string; nombre: string };
  porcentaje: number;
  porcentajeDelConvenio: boolean;
  convenioFirmado: { fecha: string; razonSocial: string } | null;
  costos: CostosLiquidacion;
  topesAnexoIV: { costo_carpeta: number; costo_foto_20x30: number; costo_foto_15x21: number } | null;
  periodo: { desde: string; hasta: string };
  filas: FilaLiquidacion[];
  /** gastosPlataforma: punto (iv) del convenio 2026-10-30 (0 si el convenio no lo prevé). ganancia ya lo tiene descontado. */
  totales: { pedidos: number; venta: number; costoLaboratorio: number; comision: number; impuestos: number; gastosPlataforma: number; ganancia: number };
  /** null = el convenio firmado no prevé descontar gastos de plataforma. */
  gastosPlataforma: GastosPlataformaLiquidacion | null;
  resumenPorMedio: { medio: string; pedidos: number; cobrado: number; comision: number; retencionesInformadas: number; comisionesEstimadas: number }[];
  participacion: number;
  pedidosConFotosPendientes: number;
  comisionesEstimadas: number;
  comisionesPorActualizar: number;
}

export interface GastosPlataformaLiquidacion {
  gastosPeriodo: number;
  ventasPlataforma: number;
  proporcion: number;
  prorrateado: number;
  topePct: number;
  tope: number;
  asignado: number;
  topeAplicado: boolean;
}

export interface GastoPlataforma {
  id: string;
  fecha: string;
  concepto: string;
  monto: number;
  moneda_original: 'ARS' | 'USD' | null;
  monto_original: number | null;
  comprobante: string | null;
}

/** Gastos de operación de la plataforma cargados en el período (convenio 2026-10-30, OCTAVA BIS iv). */
export async function obtenerGastosPlataforma(desde: string, hasta: string): Promise<{ success: boolean; gastos?: GastoPlataforma[]; error?: string }> {
  try {
    const res = await fetchAdminAutenticado(`/api/admin/liquidacion/gastos-plataforma?desde=${encodeURIComponent(desde)}&hasta=${encodeURIComponent(hasta)}`);
    const data = await res.json();
    return res.ok && data.success ? { success: true, gastos: data.gastos } : { success: false, error: data.error || 'No se pudieron leer los gastos.' };
  } catch {
    return { success: false, error: 'Error de conexión.' };
  }
}

export async function agregarGastoPlataforma(gasto: { fecha: string; concepto: string; monto: string; monedaOriginal: string; montoOriginal: string; comprobante: string }): Promise<{ success: boolean; error?: string }> {
  try {
    const res = await fetchAdminAutenticado('/api/admin/liquidacion/gastos-plataforma', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(gasto),
    });
    const data = await res.json();
    return res.ok && data.success ? { success: true } : { success: false, error: data.error || 'No se pudo guardar el gasto.' };
  } catch {
    return { success: false, error: 'Error de conexión.' };
  }
}

export async function borrarGastoPlataforma(id: string): Promise<{ success: boolean; error?: string }> {
  try {
    const res = await fetchAdminAutenticado(`/api/admin/liquidacion/gastos-plataforma/${encodeURIComponent(id)}`, { method: 'DELETE' });
    const data = await res.json();
    return res.ok && data.success ? { success: true } : { success: false, error: data.error || 'No se pudo borrar el gasto.' };
  } catch {
    return { success: false, error: 'Error de conexión.' };
  }
}

export async function obtenerCostosLiquidacion(): Promise<CostosLiquidacion | null> {
  try {
    const res = await fetchAdminAutenticado('/api/admin/liquidacion/costos');
    const data = await res.json();
    return res.ok && data.success ? data.costos : null;
  } catch {
    return null;
  }
}

export async function guardarCostosLiquidacion(costos: Record<string, string | number>): Promise<{ success: boolean; costos?: CostosLiquidacion; error?: string }> {
  try {
    const res = await fetchAdminAutenticado('/api/admin/liquidacion/costos', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(costos),
    });
    const data = await res.json();
    return res.ok && data.success ? { success: true, costos: data.costos } : { success: false, error: data.error || 'No se pudieron guardar los costos.' };
  } catch {
    return { success: false, error: 'Error de conexión.' };
  }
}

export async function guardarPorcentajeColegio(colegioId: string, porcentaje: string | number): Promise<{ success: boolean; error?: string }> {
  try {
    const res = await fetchAdminAutenticado(`/api/admin/colegios/${encodeURIComponent(colegioId)}/porcentaje`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ porcentaje }),
    });
    const data = await res.json();
    return res.ok && data.success ? { success: true } : { success: false, error: data.error || 'No se pudo guardar el porcentaje.' };
  } catch {
    return { success: false, error: 'Error de conexión.' };
  }
}

export async function obtenerLiquidacionColegio(colegioId: string, desde?: string, hasta?: string): Promise<{ success: boolean; liquidacion?: Liquidacion; error?: string }> {
  try {
    const periodo = desde && hasta ? `&desde=${encodeURIComponent(desde)}&hasta=${encodeURIComponent(hasta)}` : '';
    const res = await fetchAdminAutenticado(`/api/admin/liquidacion?colegioId=${encodeURIComponent(colegioId)}${periodo}`);
    const data = await res.json();
    if (!res.ok || !data.success) return { success: false, error: data.error || 'No se pudo calcular la liquidación.' };
    const { success: _ok, ...liquidacion } = data;
    return { success: true, liquidacion: liquidacion as Liquidacion };
  } catch {
    return { success: false, error: 'Error de conexión.' };
  }
}

/** Trae de Mercado Pago / Nave la comisión real de los pagos del período (una tanda por llamada). */
export async function actualizarComisionesReales(colegioId: string, desde: string, hasta: string): Promise<{ success: boolean; real?: number; sinDato?: number; errores?: number; pendientes?: number; error?: string }> {
  try {
    const res = await fetchAdminAutenticado('/api/admin/liquidacion/actualizar-comisiones', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ colegioId, desde, hasta }),
    });
    const data = await res.json();
    return res.ok && data.success ? data : { success: false, error: data.error || 'No se pudieron actualizar las comisiones.' };
  } catch {
    return { success: false, error: 'Error de conexión.' };
  }
}

/** 14/10/2026: inscripción de la familia que el servidor movió junto con el alumno. */
export interface InscripcionMovidaNomina {
  id: string;
  padre: string;
  email: string;
  esHermano: boolean;
  /** Código del curso nuevo (sólo si es el hijo principal: la familia tiene que recibirlo). */
  codigoNuevo: string | null;
}

export interface ResultadoCambioCursoAlumno {
  success: boolean;
  alumno?: AlumnoNominaReal;
  error?: string;
  inscripciones?: InscripcionMovidaNomina[];
  /** El curso nuevo todavía no tiene código: la inscripción del hijo principal no se movió. */
  cursoSinCodigo?: boolean;
  errorInscripciones?: string;
}

export interface CursoDestinoNomina {
  grado: string;
  division: string;
  turno: string | null;
}

/**
 * Panel admin: pasa a un alumno de la nómina a otro curso que ya existe en la nómina del mismo
 * colegio (13/10). El servidor lo pone último en la lista del curso nuevo y devuelve la fila.
 */
/** Panel admin: marca o desmarca como fotografiados a uno o varios alumnos de la nómina (13/10). */
export async function marcarFotografiadosAdmin(
  ids: string[],
  fotografiado: boolean,
  foto: 'fotografiado' | 'seno' | 'grupal' = 'fotografiado'
): Promise<{ success: boolean; alumnos?: { id: string; fotografiado_at: string | null; foto_seno_at?: string | null; foto_grupal_at?: string | null }[]; error?: string }> {
  try {
    const res = await fetchAdminAutenticado('/api/admin/alumnos/fotografiados', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(foto === 'fotografiado' ? { ids, fotografiado } : { ids, fotografiado, foto }),
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok || !data.success) return { success: false, error: data?.error || 'No se pudo guardar la marca de fotografiado.' };
    return { success: true, alumnos: data.alumnos || [] };
  } catch (err: any) {
    return { success: false, error: err?.message || 'Error de conexión al guardar la marca de fotografiado.' };
  }
}

export async function cambiarCursoAlumnoAdmin(
  id: string,
  destino: CursoDestinoNomina
): Promise<ResultadoCambioCursoAlumno> {
  try {
    const res = await fetchAdminAutenticado(`/api/admin/alumnos/${encodeURIComponent(id)}/curso`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(destino),
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok || !data.success) {
      return { success: false, error: data?.error || 'No se pudo cambiar de curso al alumno.' };
    }
    return {
      success: true,
      alumno: data.alumno,
      inscripciones: Array.isArray(data.inscripciones) ? data.inscripciones : [],
      cursoSinCodigo: data.cursoSinCodigo === true,
      errorInscripciones: data.errorInscripciones,
    };
  } catch (err: any) {
    return { success: false, error: err?.message || 'Error de conexión al cambiar de curso.' };
  }
}
