import { fetchAdminAutenticado } from './adminAuthService';
import { fetchConTimeout, TIMEOUT_SUBIDA_MS } from '../utils/fetchConTimeout';

// Buscador por reconocimiento facial (24/10/2026). Rutas en servidor/familias/buscadorRostro.ts.

export interface AccesoBuscadorRostro {
  codigo: string;
  familia: string;
  acceso: string;
  alumnoNombre: string;
}

export interface ResultadoBusquedaRostro {
  success: boolean;
  nuevas?: number;
  yaEnGaleria?: number;
  sinResultados?: boolean;
  /** 25/10: ids de las fotos encontradas que ya están en la galería de la familia (para mostrárselas). */
  fotos?: string[];
  error?: string;
}

export interface BusquedaRostroAdmin {
  id: string;
  created_at: string;
  codigo_curso: string;
  inscripcion_id: string;
  alumno_nombre: string;
  caras_coincidentes: number;
  fotos_nuevas: number;
  fotos_ya_en_galeria: number;
  resultado: 'ok' | 'sin_resultados' | 'sin_cara' | 'error';
  /** De qué curso y archivo vino cada foto copiada (para auditar y deshacer desde el panel). */
  copias?: { nombre: string; cursoOrigen: string | null; copiaId: string | null }[];
}

/** Achica la foto en el navegador (lado máx. 1280 px, JPEG) y la devuelve en base64, sin el prefijo data:. */
export async function prepararImagenRostro(archivo: File, lado = 1280): Promise<string> {
  const url = URL.createObjectURL(archivo);
  try {
    const img = await new Promise<HTMLImageElement>((resolve, reject) => {
      const i = new Image();
      i.onload = () => resolve(i);
      i.onerror = () => reject(new Error('No pudimos abrir la foto. Probá con otra (JPG o PNG).'));
      i.src = url;
    });
    const escala = Math.min(1, lado / Math.max(img.naturalWidth || 1, img.naturalHeight || 1));
    const canvas = document.createElement('canvas');
    canvas.width = Math.max(1, Math.round(img.naturalWidth * escala));
    canvas.height = Math.max(1, Math.round(img.naturalHeight * escala));
    const ctx = canvas.getContext('2d');
    if (!ctx) throw new Error('Tu navegador no pudo preparar la foto. Probá desde otro navegador.');
    ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
    return canvas.toDataURL('image/jpeg', 0.85).replace(/^data:image\/jpeg;base64,/, '');
  } finally {
    URL.revokeObjectURL(url);
  }
}

/** ¿El colegio de este código tiene el buscador? (caras cargadas + AWS configurado). Ante cualquier error, no. */
export async function buscadorRostroDisponible(codigo: string): Promise<boolean> {
  try {
    const res = await fetchConTimeout(`/api/fotos/buscador-rostro?codigo=${encodeURIComponent(codigo)}`);
    const data = await res.json().catch(() => ({}));
    return res.ok && data?.disponible === true;
  } catch {
    return false;
  }
}

export async function buscarPorRostro(acceso: AccesoBuscadorRostro, imagen: string): Promise<ResultadoBusquedaRostro> {
  try {
    const res = await fetchConTimeout('/api/fotos/buscar-rostro', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ...acceso, imagen, consentimiento: true }),
    }, TIMEOUT_SUBIDA_MS);
    const data = await res.json().catch(() => ({}));
    if (!res.ok || !data?.success) return { success: false, error: data?.error || 'No pudimos hacer la búsqueda. Probá de nuevo en un rato.' };
    return data;
  } catch (err: any) {
    return { success: false, error: err?.message || 'No pudimos hacer la búsqueda. Revisá tu conexión.' };
  }
}

export async function listarBusquedasRostro(colegioId: string): Promise<{ success: boolean; busquedas?: BusquedaRostroAdmin[]; configurado?: boolean; error?: string }> {
  try {
    const res = await fetchAdminAutenticado(`/api/admin/rostros/busquedas?colegioId=${encodeURIComponent(colegioId)}`);
    const data = await res.json().catch(() => ({}));
    if (!res.ok || !data?.success) return { success: false, error: data?.error || 'No pudimos traer las búsquedas.' };
    return data;
  } catch (err: any) {
    return { success: false, error: err?.message || 'No pudimos traer las búsquedas.' };
  }
}
