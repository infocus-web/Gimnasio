import { fetchAdminAutenticado } from './adminAuthService';

export type EstadoConsultaFamilia = 'nueva' | 'en_proceso' | 'resuelta' | 'archivada';

export interface ConsultaFamilia {
  id: string;
  nombre: string;
  email: string;
  telefono?: string;
  colegio?: string;
  numeroPedido?: string;
  asunto: string;
  mensaje: string;
  estado: EstadoConsultaFamilia;
  origen: 'web' | 'email' | 'panel';
  createdAt: string;
  updatedAt: string;
  mensajes: MensajeConsultaFamilia[];
  /** Respuesta redactada por la IA que quedó sin enviar (para revisar y mandar desde el panel). */
  borradorIa?: string;
  /** Resultado de la revisión automática de los datos de la familia. */
  verificacionIa?: VerificacionIa;
  /** Cuándo se hizo esa revisión (13/10: para ver si quedó vieja). */
  procesadaIaAt?: string;
  /** 25/10: marcada por Pablo como «Atención especial» (pestaña propia; la IA no la responde sola). */
  atencionEspecial?: boolean;
}

export interface VerificacionIa {
  encontrada: boolean;
  todoOk: boolean;
  chequeos: { ok: boolean; texto: string }[];
  datos: string[];
  tema: string;
  motivo?: string;
  motivoNoEnvio?: string | null;
  enviadaAutomaticamente: boolean;
  /** 26/10: análisis de la respuesta (qué entendió la IA, dudas, decisiones y lo que marcó el control). */
  entendido?: string;
  ambiguedades?: string[];
  decisiones?: { pregunta: string; opciones: string[] }[];
  alertas?: { frase: string; motivo: string }[];
  verificado?: boolean;
  /** 26/10: cómo se armó («Investigada por Claude Opus con 4 consultas a la base»). */
  nota?: string;
}

/** 26/10: lo mismo, como lo devuelve «Pedir respuesta a la IA». */
export type AnalisisRespuestaIA = Pick<VerificacionIa, 'entendido' | 'ambiguedades' | 'decisiones' | 'alertas' | 'verificado' | 'nota'>;

export interface MensajeConsultaFamilia {
  id: string;
  direccion: 'saliente' | 'entrante';
  remitente: string;
  destinatario: string;
  asunto?: string;
  contenido: string;
  createdAt: string;
  automatica?: boolean;
}

export interface NuevaConsultaFamilia {
  nombre: string;
  email: string;
  telefono?: string;
  colegio?: string;
  numeroPedido?: string;
  asunto: string;
  mensaje: string;
  sitioWeb?: string;
}

function mapearConsulta(row: any): ConsultaFamilia {
  return {
    id: row.id,
    nombre: row.nombre,
    email: row.email,
    telefono: row.telefono || undefined,
    colegio: row.colegio || undefined,
    numeroPedido: row.numero_pedido || undefined,
    asunto: row.asunto,
    mensaje: row.mensaje,
    estado: row.estado,
    origen: row.origen,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
    borradorIa: row.borrador_ia || undefined,
    atencionEspecial: row.atencion_especial === true,
    verificacionIa: row.verificacion_ia && typeof row.verificacion_ia === 'object' ? row.verificacion_ia : undefined,
    procesadaIaAt: row.procesada_ia_at || undefined,
    mensajes: (row.consultas_familias_mensajes || [])
      .map((mensaje: any) => ({
        id: mensaje.id,
        direccion: mensaje.direccion,
        remitente: mensaje.remitente,
        destinatario: mensaje.destinatario,
        asunto: mensaje.asunto || undefined,
        contenido: mensaje.contenido,
        createdAt: mensaje.created_at,
        automatica: Boolean(mensaje.automatica),
      }))
      .sort((a: MensajeConsultaFamilia, b: MensajeConsultaFamilia) => a.createdAt.localeCompare(b.createdAt)),
  };
}

export async function enviarConsultaFamilia(datos: NuevaConsultaFamilia) {
  try {
    const response = await fetch('/api/consultas-familias', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(datos),
    });
    const data = await response.json();
    return response.ok && data.success
      ? { success: true as const }
      : { success: false as const, error: data.error || 'No se pudo enviar la consulta.' };
  } catch {
    return { success: false as const, error: 'No pudimos conectarnos. Intentá nuevamente.' };
  }
}

export async function obtenerConsultasFamiliasAdmin(estado: EstadoConsultaFamilia | 'todas' | 'especial') {
  const response = await fetchAdminAutenticado(`/api/admin/consultas-familias?estado=${encodeURIComponent(estado)}`);
  const data = await response.json();
  if (!response.ok || !data.success) throw new Error(data.error || 'No se pudieron cargar las consultas.');
  return (data.consultas || []).map(mapearConsulta) as ConsultaFamilia[];
}

/** 25/10/2026: marca o desmarca «Atención especial». */
export async function marcarAtencionEspecialAdmin(id: string, valor: boolean) {
  const response = await fetchAdminAutenticado(`/api/admin/consultas-familias/${encodeURIComponent(id)}/especial`, {
    method: 'PATCH',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ valor }),
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok || !data.success) throw new Error(data.error || 'No se pudo marcar la consulta.');
}

/**
 * 27/10/2026: «Pedirle a Claude». Con la rutina configurada devuelve `url` (sesión ya abierta); sin ella (28/10: la
 * cuenta no tiene el disparador por API) devuelve `texto`: el caso para copiar y pegar en Claude.
 */
export async function pedirAClaudeAdmin(id: string, nota?: string): Promise<{ url?: string; texto?: string }> {
  const response = await fetchAdminAutenticado(`/api/admin/consultas-familias/${encodeURIComponent(id)}/pedir-a-claude`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ nota: nota || '' }),
  });
  const data = await response.json().catch(() => ({}));
  if (response.ok && data.success && typeof data.texto === 'string' && data.texto) return { texto: data.texto };
  if (!response.ok || !data.success || typeof data.url !== 'string') throw new Error(data.error || 'No pudimos pedirle el caso a Claude.');
  return { url: data.url };
}

/** 14/10/2026: la consulta cambió mientras tanto (p. ej. la familia escribió de nuevo): hay que recargar. */
export class ConsultaCambiadaError extends Error {}

// 14/10/2026: `estadoAnterior` = el estado que se ve en la lista; si la consulta ya no está así (la familia
// respondió y volvió a «nueva»), el servidor no la cambia y contesta 409.
export async function actualizarEstadoConsultaFamiliaAdmin(id: string, estado: EstadoConsultaFamilia, estadoAnterior?: EstadoConsultaFamilia) {
  const response = await fetchAdminAutenticado(`/api/admin/consultas-familias/${encodeURIComponent(id)}/estado`, {
    method: 'PATCH',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(estadoAnterior ? { estado, estadoAnterior } : { estado }),
  });
  const data = await response.json();
  if (response.status === 409) throw new ConsultaCambiadaError(data.error || 'La consulta cambió mientras tanto. Recargá la lista.');
  if (!response.ok || !data.success) throw new Error(data.error || 'No se pudo actualizar la consulta.');
}

export async function eliminarConsultaFamiliaAdmin(id: string) {
  const response = await fetchAdminAutenticado(`/api/admin/consultas-familias/${encodeURIComponent(id)}`, {
    method: 'DELETE',
  });
  const data = await response.json();
  if (!response.ok || !data.success) throw new Error(data.error || 'No se pudo borrar la consulta.');
}

// 14/10/2026: `clave` (ver utils/claveEnvio.ts): un reintento del mismo texto no se manda dos veces.
export async function responderConsultaFamiliaAdmin(id: string, mensaje: string, clave?: string) {
  const response = await fetchAdminAutenticado(`/api/admin/consultas-familias/${encodeURIComponent(id)}/responder`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(clave ? { mensaje, clave } : { mensaje }),
  });
  const data = await response.json();
  if (!response.ok || !data.success) throw new Error(data.error || 'No se pudo enviar la respuesta.');
}

// Solo redacta un borrador con IA — nunca envía nada. El fotógrafo lo revisa (y edita si
// hace falta) en el textarea de respuesta antes de mandarlo con responderConsultaFamiliaAdmin.
// 26/10: `idea` (opcional) = lo que Pablo quiere decir; la IA redacta la respuesta a partir de eso.
export async function sugerirRespuestaConsultaFamiliaAdmin(id: string, idea?: string): Promise<{ sugerencia: string; aviso?: string; analisis?: AnalisisRespuestaIA }> {
  const ideaLimpia = (idea || '').trim();
  // 26/10: la responde un agente que investiga (Claude Opus): puede tardar hasta ~1 minuto y medio (el servidor corta a los 120 s).
  const response = await fetchAdminAutenticado(`/api/admin/consultas-familias/${encodeURIComponent(id)}/sugerir-respuesta`, {
    method: 'POST',
    ...(ideaLimpia ? { headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ idea: ideaLimpia }) } : {}),
  }, 125_000);
  const data = await response.json();
  if (!response.ok || !data.success) throw new Error(data.error || 'No se pudo generar una sugerencia.');
  return { sugerencia: String(data.sugerencia || ''), aviso: data.aviso ? String(data.aviso) : undefined, analisis: data.analisis && typeof data.analisis === 'object' ? data.analisis : undefined };
}

// "Escribir a esta familia": el fotógrafo inicia la conversación desde el panel. Se envía el email
// y queda como conversación en Consultas, así lo que conteste la familia vuelve al mismo hilo.
export async function iniciarConversacionFamiliaAdmin(datos: {
  nombre: string;
  email: string;
  telefono?: string;
  colegio?: string;
  numeroPedido?: string;
  asunto: string;
  mensaje: string;
  /** 14/10/2026: clave de envío (un reintento reusa la conversación y no duplica el email). */
  clave?: string;
}): Promise<void> {
  const response = await fetchAdminAutenticado('/api/admin/consultas-familias/iniciar', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(datos),
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok || !data.success) throw new Error(data.error || 'No se pudo enviar el email.');
}

// Borrador con IA para un mensaje nuevo a la familia — nunca envía nada.
export async function sugerirMensajeFamiliaAdmin(datos: { nombre: string; email: string; alumno?: string; numeroPedido?: string; motivo: string }): Promise<string> {
  const response = await fetchAdminAutenticado('/api/admin/consultas-familias/sugerir-mensaje', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(datos),
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok || !data.success) throw new Error(data.error || 'No se pudo generar un borrador.');
  return String(data.sugerencia || '');
}
