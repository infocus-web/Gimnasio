import { guardarLlavePedido, obtenerLlavePedido } from '../utils/accesoPedido';
import { datosAceptacion } from '../legal/aceptacion';
import { VERSION_TERMINOS } from '../legal/textosLegales';
import { ErrorTiempoAgotado, esStatusTransitorio, fetchConTimeout, MENSAJE_DEMASIADOS_INTENTOS, TIMEOUT_SUBIDA_MS } from '../utils/fetchConTimeout';
import { CODIGO_KIT_YA_PAGADO, nombresAlumnosDeRespuesta } from './pedidosLabService';
/**
 * Pago anticipado: la familia paga el kit antes de que estén las fotos de su curso y las elige
 * después, sin volver a pagar. Ver "PAGO ANTICIPADO" en server.ts.
 */

export type KitReserva = 'kit-clasico' | 'kit-digital';

export const KITS_RESERVA: { id: KitReserva; nombre: string; precio: number; detalle: string }[] = [
  { id: 'kit-clasico', nombre: 'Kit Impreso + Digital', precio: 30000, detalle: 'Carpeta con las 3 fotos impresas + las 3 en digital HD' },
  { id: 'kit-digital', nombre: 'Solo Digital HD', precio: 15000, detalle: 'Las 3 fotos en digital HD, sin impresión' },
];

export interface ReservaPendiente {
  /** Auditoría 05/10: una reserva PAGADA consultada sin la llave de la familia viene sin id. */
  id: string | null;
  /** La reserva está pagada pero hay que reingresar con los datos de la familia para elegir las fotos. */
  requiereLlave?: boolean;
  /** Grupo de pago de la reserva: con él se encuentra la llave guardada al reservar en este navegador. */
  grupoPagoId?: string | null;
  pedidoFriendlyId: string;
  kitNombre: string;
  total: number;
  pagada: boolean;
  metodoPago?: string;
}

export async function crearReserva(datos: {
  tutorNombre: string;
  tutorEmail: string;
  tutorTelefono?: string;
  metodoPago: 'mercadopago' | 'nave' | 'transferencia';
  /**
   * `reservaId` (Auditoría 03/10): UUID estable por intento (ver utils/checkoutEstable.ts). El servidor
   * lo usa como id de la fila y es idempotente por él: un reintento de la misma familia devuelve la
   * reserva ya registrada en vez de anularla y crear otra.
   */
  items: { codigoSeccion: string; alumnoNombre: string; kitId: KitReserva; carpetasExtras?: number; reservaId?: string }[];
  /** Sumar la reserva a una compra ya registrada (mismo pago), en vez de crear un pago aparte. */
  grupoPagoId?: string;
  /**
   * Auditoría 03/10 (2ª vuelta): el servidor responde 409 `KIT_YA_PAGADO` si algún chico ya tiene un
   * kit pagado (igual que /api/pedidos/crear). Si la familia confirma, se reintenta con los MISMOS
   * reservaId y `confirmarOtroKit: true`.
   */
  confirmarOtroKit?: boolean;
  /**
   * Auditoría 03/10 noche (A1): secreto del checkout (ver utils/checkoutEstable.ts), a nivel raíz del
   * body. Igual en cada reintento del mismo checkout; el servidor sólo acepta el reintento con ella.
   */
  claveCheckout?: string;
}): Promise<{
  success: boolean;
  grupoPagoId?: string;
  total?: number;
  pedidoFriendlyIds?: string[];
  error?: string;
  codigo?: string;
  alumnos?: string[];
  /** 05/10 (bug 2b): true = falló por red, tiempo, 429 o 5xx (vale reintentar); false = el servidor la rechazó (4xx). */
  transitorio?: boolean;
}> {
  try {
    const res = await fetchConTimeout('/api/reservas/crear', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      // Marco legal (27/9): el servidor rechaza la reserva sin la aceptación de los términos.
      // Auditoría 03/10 noche (M1): sumar la reserva a una compra existente exige la llave de esa compra.
      body: JSON.stringify({ ...datos, ...datosAceptacion(), ...(datos.grupoPagoId ? { t: obtenerLlavePedido(datos.grupoPagoId) || undefined } : {}) }),
    });
    const data = await res.json().catch(() => ({}));
    if (res.status === 429) return { success: false, error: MENSAJE_DEMASIADOS_INTENTOS, transitorio: true };
    if (res.status === 409 && data?.codigo === CODIGO_KIT_YA_PAGADO) {
      return { success: false, codigo: CODIGO_KIT_YA_PAGADO, alumnos: nombresAlumnosDeRespuesta(data.alumnos), error: data.error || 'Este alumno ya tiene un kit pagado.' };
    }
    // 05/10 (bug 2b): se informa si la falla es pasajera (5xx) o definitiva (4xx: sin llave, curso con fotos, etc.).
    if (!res.ok || !data.success) return { success: false, error: data.error || 'No se pudo registrar la reserva.', transitorio: esStatusTransitorio(res.status) };
    guardarLlavePedido([data.grupoPagoId], data.accesoToken);
    return data;
  } catch (err) {
    return { success: false, error: err instanceof ErrorTiempoAgotado ? err.message : 'Error de conexión. Revisá tu internet e intentá de nuevo.', transitorio: true };
  }
}

/** Reserva del alumno (si hay) y si su curso ya tiene fotos online (entonces no se puede reservar). */
export async function obtenerEstadoReserva(
  codigoSeccion: string,
  alumnoNombre: string,
  /**
   * Auditoría 03/10 noche (contrato 5): la llave de galería de la familia (los mismos
   * `familiaActiva.id` / `familiaActiva.accesoGaleria` que usa /api/fotos). Sin ella el servidor sólo
   * devuelve las reservas PAGADAS (las de elegir fotos siguen igual); con ella también las reservas
   * sin pagar y `tienePedidoPendiente`.
   */
  credenciales?: { familia?: string | null; acceso?: string | null }
): Promise<EstadoReserva> {
  if (!codigoSeccion || !alumnoNombre) return { ok: false, reserva: null, fotosDisponibles: false, tienePedidoPagado: false };
  try {
    const params = new URLSearchParams({ codigo: codigoSeccion, alumnoNombre });
    const conLlave = Boolean(credenciales?.familia && credenciales?.acceso);
    if (conLlave) {
      params.set('familia', String(credenciales!.familia));
      params.set('acceso', String(credenciales!.acceso));
    }
    const res = await fetchConTimeout(`/api/reservas/pendiente?${params.toString()}`);
    // Auditoría 03/10 noche (contrato 5): si el servidor rechaza la llave (400/401/403, por ejemplo
    // una sesión vieja), se vuelve a consultar SIN ella: las reservas PAGADAS tienen que seguir
    // apareciendo para que la familia elija sus fotos (hay reservas pagadas reales esperando).
    if (conLlave && [400, 401, 403].includes(res.status)) return obtenerEstadoReserva(codigoSeccion, alumnoNombre);
    const data = await res.json().catch(() => ({}));
    // Auditoría 03/10 (alto 6): un 429/5xx/corte de red NO es "no hay reserva ni pedido pagado":
    // se avisa como falla pasajera para que el portal frene la compra y ofrezca reintentar.
    if (esStatusTransitorio(res.status)) {
      return {
        ok: false,
        reserva: null,
        fotosDisponibles: false,
        tienePedidoPagado: false,
        falloTransitorio: true,
        error: res.status === 429 ? MENSAJE_DEMASIADOS_INTENTOS : 'No pudimos verificar si ya tenés un kit pagado.',
      };
    }
    if (!res.ok || !data.success) return { ok: false, reserva: null, fotosDisponibles: false, tienePedidoPagado: false };
    return {
      ok: true,
      reserva: (data.reserva as ReservaPendiente) || null,
      fotosDisponibles: Boolean(data.fotosDisponibles),
      tienePedidoPagado: Boolean(data.tienePedidoPagado),
      // Auditoría 03/10 noche (M8a/R3): el chico ya tiene un pedido normal esperando el pago.
      tienePedidoPendiente: Boolean(data.tienePedidoPendiente),
    };
  } catch (err) {
    return {
      ok: false,
      reserva: null,
      fotosDisponibles: false,
      tienePedidoPagado: false,
      falloTransitorio: true,
      error: err instanceof ErrorTiempoAgotado ? err.message : 'No pudimos verificar si ya tenés un kit pagado (sin conexión).',
    };
  }
}

export interface EstadoReserva {
  ok: boolean;
  reserva: ReservaPendiente | null;
  fotosDisponibles: boolean;
  tienePedidoPagado: boolean;
  /**
   * Auditoría 03/10 noche (M8a/R3): ya tiene un pedido normal esperando el pago (transferencia sin
   * aprobar, Mercado Pago sin terminar, etc.). Sólo viene con la llave de la familia.
   */
  tienePedidoPendiente?: boolean;
  /** true = la consulta falló por red, tiempo, 429 o 5xx: el resultado NO es confiable. */
  falloTransitorio?: boolean;
  error?: string;
}

export async function obtenerReservaPendiente(codigoSeccion: string, alumnoNombre: string): Promise<ReservaPendiente | null> {
  return (await obtenerEstadoReserva(codigoSeccion, alumnoNombre)).reserva;
}

export async function elegirFotosDeReserva(
  reservaId: string,
  codigoSeccion: string,
  fotos: { grupalId: string; individualId: string; docenteId: string; sinFoto?: string[] },
  /** Confirmación expresa de que el kit se personaliza y se envía el digital (CCyC art. 1116). */
  confirmaPersonalizacion: boolean,
  /**
   * Auditoría 03/10 noche (revisión): llave de galería de la familia (`familiaActiva.id` /
   * `familiaActiva.accesoGaleria`). El servidor la usa para validar que la foto individual sea del
   * hijo de la inscripción. Si no está, se manda igual que siempre (reservas pagadas viejas).
   */
  credenciales?: { familia?: string | null; acceso?: string | null; grupoPagoId?: string | null }
): Promise<{ success: boolean; pedidoFriendlyId?: string; error?: string }> {
  const llavePedido = obtenerLlavePedido(reservaId) || (credenciales?.grupoPagoId ? obtenerLlavePedido(credenciales.grupoPagoId) : null);
  const enviar = () =>
    fetchConTimeout(
      `/api/reservas/${encodeURIComponent(reservaId)}/elegir-fotos`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          codigo: codigoSeccion,
          fotos,
          confirmaPersonalizacion,
          versionTerminos: VERSION_TERMINOS,
          ...(credenciales?.familia && credenciales?.acceso ? { familia: credenciales.familia, acceso: credenciales.acceso } : {}),
          // Auditoría 05/10: el servidor exige la llave de la familia o la del pedido (la guardada al reservar).
          ...(llavePedido ? { t: llavePedido } : {}),
        }),
      },
      // 14/10/2026: el servidor arma el .zip HD antes de responder (hasta ~8 s); con el tope de 15 s una
      // conexión lenta mostraba «Error de conexión» con las fotos ya guardadas.
      TIMEOUT_SUBIDA_MS
    );
  try {
    let res: Response;
    try {
      res = await enviar();
    } catch {
      // 14/10/2026: si se cortó, se vuelve a mandar UNA vez: si la primera ya se guardó, el servidor responde
      // «ya fueron elegidas» (el portal lo toma como éxito y muestra las fotos confirmadas); si no, se guarda ahora.
      res = await enviar();
    }
    const data = await res.json().catch(() => ({}));
    if (res.status === 429) return { success: false, error: MENSAJE_DEMASIADOS_INTENTOS };
    if (!res.ok || !data.success) return { success: false, error: data.error || 'No se pudo guardar tu elección.' };
    return data;
  } catch {
    return { success: false, error: 'Error de conexión. Revisá tu internet e intentá de nuevo.' };
  }
}

/** Kit reservado que se suma a la compra de un hermano con fotos (se paga todo junto). */
export interface ReservaParaSumar {
  hijoId: string;
  nombreCompleto: string;
  codigoSeccion: string;
  kitId: KitReserva;
  kitNombre: string;
  /** Precio total de la reserva, con las copias extra de la carpeta incluidas. */
  precio: number;
  /** Copias extra de la carpeta (sólo Kit Impreso), $15.000 c/u. */
  carpetasExtras?: number;
}
