import { obtenerFamiliaActiva } from './inscripcionesService';
import { obtenerTokenAdmin } from './adminAuthService';
import { fetchConTimeout } from '../utils/fetchConTimeout';

/**
 * Reporte de errores "con un solo botón" (pedido de Pablo 25/9, después de que las compras Solo
 * Digital fallaran en silencio desde el 24/9): la web va anotando sola las últimas llamadas al
 * servidor que fallaron (con su respuesta), los errores de JavaScript y en qué pantalla/paso está
 * la persona. Cuando el servidor responde con un error 5xx aparece un aviso con el botón
 * "Avisar al equipo técnico", que manda todo eso a /api/errores/reportar (se guarda en la base y
 * llega por email). Así el reporte trae lo necesario para arreglarlo sin tener que preguntar.
 */

export interface EventoRegistrado {
  t: string;
  tipo: 'api' | 'red' | 'js';
  resumen: string;
}

export interface PedidoDeReporte {
  titulo?: string;
  mensaje: string;
  detalle?: Record<string, unknown>;
  /** Si el reporte ya se mandó solo (2/10), el código del aviso: el cartel sólo informa. */
  codigoAutomatico?: Promise<string | null>;
}

const EVENTO_MOSTRAR = 'retrato:error-para-reportar';
const MAX_EVENTOS = 25;
const eventos: EventoRegistrado[] = [];
const contextoActual: Record<string, unknown> = {};
let instalado = false;

function registrarEvento(tipo: EventoRegistrado['tipo'], resumen: string) {
  eventos.push({ t: new Date().toISOString(), tipo, resumen: resumen.slice(0, 800) });
  if (eventos.length > MAX_EVENTOS) eventos.splice(0, eventos.length - MAX_EVENTOS);
}

/** Cada pantalla deja acá en qué está (paso, kit, pedido…) para que viaje con el reporte. */
export function registrarContextoDeError(clave: string, valor: unknown) {
  if (valor === undefined || valor === null || valor === '') delete contextoActual[clave];
  else contextoActual[clave] = valor;
}

/** Muestra el aviso con el botón "Avisar al equipo técnico". */
export function pedirReporteDeError(pedido: PedidoDeReporte) {
  try {
    window.dispatchEvent(new CustomEvent<PedidoDeReporte>(EVENTO_MOSTRAR, { detail: pedido }));
  } catch {
    /* navegadores muy viejos sin CustomEvent: no se muestra el aviso */
  }
}

export function escucharPedidosDeReporte(callback: (pedido: PedidoDeReporte) => void): () => void {
  const manejador = (e: Event) => callback((e as CustomEvent<PedidoDeReporte>).detail);
  window.addEventListener(EVENTO_MOSTRAR, manejador);
  return () => window.removeEventListener(EVENTO_MOSTRAR, manejador);
}

// Auditoría 11/10: llaves y códigos que nunca viajan en un reporte (quedan en la base y en el email).
const PARAMETROS_SECRETOS = ['t', 'acceso', 'confirmar-acceso', 'familia', 'token', 'c'];

/** La URL sin los parámetros secretos (la llave HD `t` del pedido, la de galería, etc.). */
export function sinSecretos(cruda: string): string {
  try {
    const url = new URL(cruda, window.location.origin);
    PARAMETROS_SECRETOS.forEach((p) => url.searchParams.delete(p));
    return url.origin === window.location.origin ? url.pathname + url.search + url.hash : url.href;
  } catch {
    return String(cruda).split('?')[0];
  }
}

function rutaDe(input: RequestInfo | URL): string {
  try {
    const cruda = typeof input === 'string' ? input : input instanceof URL ? input.href : input.url;
    return sinSecretos(cruda);
  } catch {
    return String(input);
  }
}

// Endpoints que no deben abrir el aviso: el propio reporte y la fila de estado del panel (que se
// consulta sola cada minuto; si falla ya se ve ahí).
const SIN_AVISO = ['/api/errores/reportar', '/api/admin/salud'];

// ==============================================================================
// REPORTE AUTOMÁTICO (pedido de Pablo 2/10): todo error que la web detecta se manda solo, sin
// que la persona toque nada: fallas del servidor (5xx), errores de JavaScript, promesas
// rechazadas y pantallas caídas. Para no llenar la casilla: el mismo error se manda una sola vez
// por visita, como mucho 5 reportes automáticos por visita, y se ignora el "ruido" (extensiones
// del navegador, cortes de conexión, avisos benignos del navegador).
// ==============================================================================
const MAX_AUTOMATICOS_POR_VISITA = 5;
const firmasReportadas = new Map<string, Promise<string | null>>();
let automaticosEnviados = 0;

/** Firma del error sin números ni ids, para no mandar diez veces "el mismo" error. */
function firmaDe(tipo: string, mensaje: string): string {
  return `${tipo}|${mensaje.replace(/[0-9a-f]{8}-[0-9a-f-]{27,}/gi, '#').replace(/\d+/g, '#').slice(0, 200)}`;
}

const RUIDO_JS = [
  /ResizeObserver loop/i,
  /^Script error\.?$/i,
  /Non-Error promise rejection captured/i,
  /AbortError|The user aborted|signal is aborted/i,
  /Failed to fetch$|Load failed$|NetworkError when attempting|Network request failed/i,
  // Auditoría 03/10: corte por tiempo de fetchConTimeout (señal mala, no un error nuestro).
  /ErrorTiempoAgotado|tardó demasiado en responder/i,
  /chrome-extension:|moz-extension:|safari-extension:/i,
];

export function esRuidoDeNavegador(texto: string): boolean {
  // 13/10 (ERR-OQ85S, ERR-SCHZ4): el aviso de error arma «mensaje + espacio + archivo»; con el archivo vacío
  // quedaba «Script error. » (con espacio al final) y el filtro de «Script error.» no lo reconocía. Ese error
  // lo da el navegador cuando falla un script AJENO (traductor, extensión, navegador de una app): no tiene
  // archivo, línea ni detalle y no es de la web.
  const limpio = texto.trim();
  return RUIDO_JS.some((r) => r.test(limpio));
}

/**
 * Manda un reporte automático (deduplicado). Devuelve una promesa con el código del aviso, o null
 * si no se mandó (repetido, tope alcanzado, sin conexión o error al enviar).
 */
export function reportarAutomaticamente(tipo: string, mensaje: string, detalle: Record<string, unknown> = {}): Promise<string | null> {
  try {
    const firma = firmaDe(tipo, mensaje);
    const previa = firmasReportadas.get(firma);
    if (previa) return previa;
    if (automaticosEnviados >= MAX_AUTOMATICOS_POR_VISITA) return Promise.resolve(null);
    if (typeof navigator !== 'undefined' && navigator.onLine === false) return Promise.resolve(null);
    automaticosEnviados++;
    const envio = enviarReporteDeError({
      mensaje: `[Automático] ${mensaje}`.slice(0, 950),
      detalle: { ...detalle, automatico: true, tipoError: tipo },
    }).then((r) => (r.success ? r.codigo || 'enviado' : null));
    firmasReportadas.set(firma, envio);
    return envio;
  } catch {
    return Promise.resolve(null);
  }
}

/** Sólo para los tests. */
export function reiniciarReportesAutomaticos() {
  firmasReportadas.clear();
  automaticosEnviados = 0;
  fallasDePagoYaRegistradas.clear();
}

/** Se llama una vez al arrancar la app. */
export function instalarCapturaDeErrores() {
  if (instalado || typeof window === 'undefined' || typeof window.fetch !== 'function') return;
  instalado = true;

  const fetchOriginal = window.fetch.bind(window);
  window.fetch = async (input: RequestInfo | URL, init?: RequestInit) => {
    const ruta = rutaDe(input);
    const metodo = (init?.method || (typeof input === 'object' && 'method' in input ? (input as Request).method : 'GET')).toUpperCase();
    let respuesta: Response;
    try {
      respuesta = await fetchOriginal(input as any, init);
    } catch (err: any) {
      if (ruta.startsWith('/api/')) registrarEvento('red', `${metodo} ${ruta} → sin respuesta (${err?.message || 'error de red'})`);
      throw err;
    }
    if (respuesta.status >= 400 && ruta.startsWith('/api/')) {
      let cuerpo = '';
      try {
        cuerpo = (await respuesta.clone().text()).slice(0, 500);
      } catch {
        /* cuerpo ilegible */
      }
      registrarEvento('api', `${metodo} ${ruta} → ${respuesta.status} ${cuerpo}`);
      // Auditoría 03/10 (medio): con Supabase o Vercel caídos, cada pantalla abierta mandaba su
      // propio reporte automático por cada consulta en segundo plano que fallaba — el reporte
      // amplificaba la carga justo cuando el servidor estaba saturado. Ahora no se reportan solos
      // los GET (consultas que se repiten y ya muestran su error en pantalla) ni los 502/503/504
      // (caída o saturación pasajera de la plataforma, no un bug a corregir).
      const esCaidaPasajera = respuesta.status === 502 || respuesta.status === 503 || respuesta.status === 504;
      if (respuesta.status >= 500 && !SIN_AVISO.some((r) => ruta.startsWith(r))) {
        let mensaje = '';
        try {
          mensaje = JSON.parse(cuerpo)?.error || '';
        } catch {
          /* no era JSON */
        }
        const textoError = mensaje || `El servidor no pudo completar la operación (${respuesta.status}).`;
        const detalle = { disparador: `${metodo} ${ruta.split('?')[0]}`, status: respuesta.status };
        // Las fallas del servidor en ACCIONES se reportan solas (2/10; sin GET ni 502/503/504 desde el 3/10)…
        const codigoAutomatico =
          metodo === 'GET' || esCaidaPasajera
            ? undefined
            : reportarAutomaticamente('servidor', `${metodo} ${ruta.split('?')[0]} → ${respuesta.status}: ${textoError}`, detalle);
        // …y si falló una ACCIÓN (crear pedido, pagar, enviar…), además se le avisa a la persona.
        // Las consultas en segundo plano (GET) no abren el cartel.
        if (metodo !== 'GET') pedirReporteDeError({ mensaje: textoError, detalle, codigoAutomatico });
      }
    }
    return respuesta;
  };

  window.addEventListener('error', (e) => {
    const texto = `${e.message || 'error'} @ ${e.filename || ''}:${e.lineno || ''}`;
    registrarEvento('js', texto);
    // Sólo errores de nuestro propio código (no de extensiones ni de scripts de otros sitios).
    const propio = !e.filename || e.filename.startsWith(window.location.origin);
    if (propio && !esRuidoDeNavegador(`${e.message || ''} ${e.filename || ''}`)) {
      void reportarAutomaticamente('javascript', e.message || 'Error de JavaScript', {
        archivo: e.filename || '',
        linea: e.lineno || null,
        columna: e.colno || null,
        pila: String((e.error as any)?.stack || '').slice(0, 3000),
      });
    }
  });
  window.addEventListener('unhandledrejection', (e) => {
    const razon: any = (e as PromiseRejectionEvent).reason;
    const texto = razon?.message || String(razon);
    registrarEvento('js', `Promesa rechazada: ${texto}`);
    if (!esRuidoDeNavegador(`${razon?.name || ''} ${texto} ${String(razon?.stack || '')}`)) {
      void reportarAutomaticamente('promesa', `Promesa rechazada: ${texto}`, { pila: String(razon?.stack || '').slice(0, 3000) });
    }
  });
}

/** Con el panel admin abierto el aviso muestra el detalle técnico; a las familias, no. */
export function esPanelAdminAbierto(): boolean {
  return Boolean(contextoActual.panelAdmin);
}

export function emailConocidoParaReporte(): string {
  try {
    return obtenerFamiliaActiva()?.email || '';
  } catch {
    return '';
  }
}

export async function enviarReporteDeError(params: {
  mensaje: string;
  detalle?: Record<string, unknown>;
  email?: string;
}): Promise<{ success: boolean; codigo?: string; error?: string }> {
  const familia = (() => {
    try {
      return obtenerFamiliaActiva();
    } catch {
      return null;
    }
  })();
  const origen = window.location.search.includes('zoho=1') || contextoActual.panelAdmin ? 'admin' : 'familia';
  const cuerpo = {
    mensaje: params.mensaje,
    origen,
    // Auditoría 11/10: sin el email del tutor salvo que la persona lo escriba, y sin llaves en la URL.
    email: params.email || '',
    url: window.location.origin + sinSecretos(window.location.href),
    detalle: {
      ...params.detalle,
      contexto: { ...contextoActual },
      familia: familia
        ? {
            alumno: `${familia.alumnoNombre || ''} ${familia.alumnoApellido || ''}`.trim(),
            grado: familia.grado,
            division: familia.division,
            turno: familia.turno,
          }
        : null,
      pantalla: { ancho: window.innerWidth, alto: window.innerHeight },
      idioma: navigator.language,
      momento: new Date().toISOString(),
      eventos: eventos.slice(),
    },
  };
  // Contrato 8 (auditoría 03/10 noche): el servidor sólo acepta `origen: 'admin'` con el token del
  // panel; sin token lo guarda como 'familia'. Se manda sólo en los reportes del panel.
  const headers: Record<string, string> = { 'Content-Type': 'application/json' };
  if (origen === 'admin') {
    try {
      const token = obtenerTokenAdmin();
      if (token) headers.Authorization = `Bearer ${token}`;
    } catch {
      /* sin almacenamiento disponible: va sin token (el servidor lo guarda como 'familia') */
    }
  }
  try {
    // Auditoría 11/10: con tiempo máximo.
    const res = await fetchConTimeout('/api/errores/reportar', {
      method: 'POST',
      headers,
      body: JSON.stringify(cuerpo),
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok || !data.success) return { success: false, error: data.error || 'No se pudo enviar el reporte.' };
    return { success: true, codigo: data.codigo };
  } catch (err: any) {
    return { success: false, error: err?.message || 'Sin conexión.' };
  }
}

/**
 * Pedido de Pablo (28/9, caso de una familia que "no llegaba a la página de pago" y no quedó
 * rastro): cada vez que se le muestra a una familia un error en el paso de pago, se registra solo,
 * sin que tenga que tocar nada. Queda en el panel (Estado del sistema → Errores reportados) y llega
 * por email. El mismo mensaje en el mismo paso se registra una sola vez por visita.
 */
const fallasDePagoYaRegistradas = new Set<string>();
// Auditoría 03/10 (medio): no tenía tope — un pedido que fallaba en cada reintento (o un mensaje
// con números distintos cada vez) mandaba un email por intento. Ahora: una vez por pedido + motivo
// (sin números ni ids) por visita, y como mucho MAX_FALLAS_PAGO_POR_VISITA en total.
const MAX_FALLAS_PAGO_POR_VISITA = 5;

export function registrarFallaDePago(paso: string, error: string, extra: Record<string, unknown> = {}): void {
  const texto = String(error || '').trim();
  if (!texto) return;
  const pedido = String(extra.pedido || extra.pedidoId || extra.grupoPagoId || '');
  const clave = `${pedido}|${firmaDe(paso, texto)}`;
  if (fallasDePagoYaRegistradas.has(clave)) return;
  if (fallasDePagoYaRegistradas.size >= MAX_FALLAS_PAGO_POR_VISITA) return;
  fallasDePagoYaRegistradas.add(clave);
  // Auditoría 11/10: el email va sólo como contacto, no repetido dentro del detalle.
  const { email: emailExtra, ...resto } = extra;
  const email = typeof emailExtra === 'string' ? emailExtra : undefined;
  void enviarReporteDeError({
    mensaje: `Falla al pagar (${paso}): ${texto}`.slice(0, 900),
    email,
    detalle: { tipo: 'pago_fallido', paso, ...resto },
  });
}
