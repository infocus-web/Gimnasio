import {
  type ArchivoFotoLab,
  type PedidoEscolarCompleto,
  formatearCodigoCliente,
  sanitizarParaMinilab,
} from './pedidosLabService';
import { fetchAdminAutenticado } from './adminAuthService';
import { ErrorSinReintento, conReintentos, dividirEnPartes, ejecutarConConcurrencia } from '../utils/descargasLote';
import { ErrorTiempoAgotado, TIMEOUT_FETCH_MS, fetchConTimeout } from '../utils/fetchConTimeout';

/**
 * ZIP para el laboratorio (panel del fotógrafo y panel del laboratorio).
 *
 * Auditoría 03/10 (crítico 3): antes una foto que no se podía bajar se reemplazaba por una tarjeta
 * GRIS con el código del alumno, sin avisar a nadie (el laboratorio la imprimía como si fuera la
 * foto). Además cada original pasaba entero por la función del servidor (más de 4,5 MB = falla
 * siempre) y todo el lote se armaba en memoria en un solo ZIP. Ahora:
 *  - el original se baja directo de Storage con una URL firmada (`?modo=url`), con 4 descargas a
 *    la vez y reintentos;
 *  - una foto que falla va como tarjeta ROJA "FALTA – <nombre>" (archivo FALTA_<nombre>.jpg), más
 *    un FALTAN_FOTOS.txt dentro del ZIP, y quien llama recibe la lista para mostrarla;
 *  - los lotes grandes se arman por partes (150 fotos o ~500 MB por parte), una por vez.
 */

export const FOTOS_POR_PARTE_ZIP = 150;
// Auditoría 03/10 (2ª vuelta): 500 MB (antes 1,5 GB): el ZIP se arma entero en la memoria del
// navegador y con 1,5 GB las compus/celulares con poca RAM se colgaban o cerraban la pestaña.
export const BYTES_MAX_PARTE_ZIP = 500 * 1024 * 1024;

/**
 * Auditoría 03/10 (2ª vuelta): la sesión del panel venció (401) mientras se armaba el ZIP. Corta todo
 * (antes cada foto quedaba como tarjeta FALTA y el ZIP salía lleno de faltantes falsos).
 */
export class SesionAdminVencida extends ErrorSinReintento {
  constructor() {
    super('Tu sesión venció, volvé a entrar.');
    this.name = 'SesionAdminVencida';
  }
}
const DESCARGAS_SIMULTANEAS = 4;

/**
 * Auditoría 03/10 noche: tiempo máximo para bajar UNA foto (pedido + contenido). Antes la bajada
 * directa de Storage no tenía tope y una foto colgada dejaba el ZIP en "149 de 150" para siempre.
 * Una foto que vence el tiempo va como tarjeta roja FALTA (igual que las que fallan) y no se
 * reintenta: con la conexión lenta volvería a tardar lo mismo.
 */
export const TIMEOUT_FOTO_MS = 60_000;

export class FotoTardoDemasiado extends Error {
  readonly sinReintento = true;
  constructor(ms: number) {
    super(`La foto tardó más de ${Math.round(ms / 1000)} s en bajar`);
    this.name = 'FotoTardoDemasiado';
  }
}

/** Baja un archivo con un tope de tiempo que cubre también la lectura del contenido (no sólo la respuesta). */
async function bajarArchivoConTiempo(url: string, ms: number, alFallar: (status: number) => Error): Promise<Blob> {
  const controlador = typeof AbortController !== 'undefined' ? new AbortController() : null;
  let vencido = false;
  const temporizador = setTimeout(() => {
    vencido = true;
    controlador?.abort();
  }, ms);
  try {
    const archivo = await fetchConTimeout(url, controlador ? { signal: controlador.signal } : {}, ms);
    if (!archivo.ok) throw alFallar(archivo.status);
    return await archivo.blob();
  } catch (err) {
    if (vencido || err instanceof ErrorTiempoAgotado) throw new FotoTardoDemasiado(ms);
    throw err;
  } finally {
    clearTimeout(temporizador);
  }
}

/** Red de seguridad: corta la espera aunque el pedido de abajo no se pueda abortar (ej. servidor viejo que manda el archivo). */
function conTiempoMaximo<T>(promesa: Promise<T>, ms: number): Promise<T> {
  let temporizador: ReturnType<typeof setTimeout> | undefined;
  const tope = new Promise<never>((_, rechazar) => {
    temporizador = setTimeout(() => rechazar(new FotoTardoDemasiado(ms)), ms);
  });
  return Promise.race([promesa, tope]).finally(() => clearTimeout(temporizador));
}

export type EstructuraZipLab = 'solo_2_carpetas_tamano' | 'por_alumno';

export interface FallaZipLab {
  archivo: string;
  alumno: string;
  pedido: string;
  motivo: string;
}

export interface EntradaZipLab {
  /** Ruta dentro del ZIP (carpeta/nombre.jpg). */
  ruta: string;
  foto: ArchivoFotoLab;
  alumno: string;
  pedido: string;
}

export interface PlanZipLab {
  partes: EntradaZipLab[][];
  /** Textos que van en cada parte (planilla de ensobrado y LEEME). */
  textos: { nombre: string; contenido: string }[];
  pedidosIncluidos: PedidoEscolarCompleto[];
  /** Pedidos recibidos que NO entran al ZIP (sin pagar, en espera, archivados, sin fotos elegidas, Solo Digital). */
  pedidosExcluidos: PedidoEscolarCompleto[];
  totalFotos: number;
}

export interface OpcionesZipLab {
  nombreColegio: string;
  filtroCurso?: string;
  estructuraCarpetas?: EstructuraZipLab;
  organizarEnSubcarpetasPorAlumno?: boolean;
  /** false = ZIP para el laboratorio: sin planilla de ensobrado (el ensobrado lo hace el estudio). */
  incluirPlanillaEnsobrado?: boolean;
  /** Fotos por parte (por defecto 150). Infinity = todo en un solo ZIP. */
  fotosPorParte?: number;
}

export interface OpcionesArmadoZipLab {
  /** Cómo pedir cada foto al servidor (el panel del laboratorio usa su propia sesión). */
  fetchFoto?: (url: string) => Promise<Response>;
  /** Errores que cortan todo el ZIP en vez de anotarse como falla (ej. sesión vencida). */
  esErrorFatal?: (e: unknown) => boolean;
  onProgreso?: (hechas: number, total: number) => void;
  /** Tope de bytes de la parte; lo que no entra vuelve en `sobrantes`. */
  bytesMax?: number;
  /** Tiempo máximo para bajar una foto (por defecto TIMEOUT_FOTO_MS; los tests usan menos). */
  timeoutFotoMs?: number;
}

/**
 * Auditoría 03/10 noche (A4): sólo se imprime el Kit Impreso (`kit-clasico`). Antes el ZIP "para
 * el laboratorio" del panel metía también los Solo Digital (a todos los pedidos se les arman
 * archivos de impresión) y la mejora a impreso salía dos veces: una por el pedido digital original
 * y otra por el pedido de la mejora (que es un `kit-clasico` con las mismas fotos). Los digitales
 * nunca entran a un lote del laboratorio, así que el filtro "ya está en lote" no los sacaba.
 */
export function seImprimeEnLaboratorio(p: Pick<PedidoEscolarCompleto, 'kitId'>): boolean {
  return p.kitId === 'kit-clasico';
}

/** Arma la lista de archivos (con nombres ya definitivos) y la reparte en partes. No baja nada. */
export function planificarZipLaboratorio(pedidos: PedidoEscolarCompleto[], opciones: OpcionesZipLab): PlanZipLab {
  const estructura: EstructuraZipLab =
    opciones.estructuraCarpetas || (opciones.organizarEnSubcarpetasPorAlumno ? 'por_alumno' : 'solo_2_carpetas_tamano');

  const delCurso = pedidos.filter((p) => !opciones.filtroCurso || opciones.filtroCurso === 'todos' || p.cursoCodigo === opciones.filtroCurso);
  // Kits pagados por adelantado sin fotos elegidas, pedidos en espera y archivados no se imprimen.
  // Auditoría 03/10 noche (A4): los Solo Digital tampoco (ver seImprimeEnLaboratorio).
  const imprimible = (p: PedidoEscolarCompleto) =>
    seImprimeEnLaboratorio(p) && p.estadoPago === 'aprobado' && !p.seleccionPendiente && !p.enEspera && !p.archivado;
  const incluidos = delCurso.filter(imprimible);
  const excluidos = delCurso.filter((p) => !imprimible(p));

  let planilla = `===========================================================\n`;
  planilla += `RETRATO ESCOLAR - PLANILLA DE LABORATORIO Y ENSOBRADO\n`;
  planilla += `Institución: ${opciones.nombreColegio}\n`;
  planilla += `Fecha de Generación: ${new Date().toLocaleString('es-AR')}\n`;
  planilla += `Total de Pedidos Aprobados: ${incluidos.length}\n`;
  planilla += `Estructura: ${estructura === 'solo_2_carpetas_tamano' ? '2 Carpetas por Tamaño (15x21 y 20x30)' : 'Carpetas individuales por alumno'}\n`;
  planilla += `===========================================================\n\n`;
  planilla += `ORDEN | CURSO | ALUMNO | CÓDIGO CLIENTE (ARCHIVO) | KIT | IMPRESIONES\n`;
  planilla += `----------------------------------------------------------------------------------------------------\n`;

  const entradas: EntradaZipLab[] = [];
  const usados = new Set<string>();
  const reservar = (carpeta: string, nombre: string, alternativo: () => string): string => {
    let final = nombre;
    if (usados.has(`${carpeta}/${final}`.toUpperCase())) final = alternativo();
    if (usados.has(`${carpeta}/${final}`.toUpperCase())) {
      const base = final.replace(/\.jpg$/i, '');
      let seq = 2;
      while (usados.has(`${carpeta}/${base}_${seq}.jpg`.toUpperCase())) seq++;
      final = `${base}_${seq}.jpg`;
    }
    usados.add(`${carpeta}/${final}`.toUpperCase());
    return final;
  };

  for (const p of incluidos) {
    const codigoCliente = formatearCodigoCliente(p.cursoCodigo, p.alumnoNombre);
    const listaArchivos: string[] = [];
    for (const foto of p.archivosParaLaboratorio) {
      let carpeta: string;
      let nombre: string;
      if (estructura === 'solo_2_carpetas_tamano') {
        carpeta = foto.tamanoImpresion === '20x30' ? '20x30' : '15x21';
        // 2/10: el ZIP usa exactamente el nombre que figura en el Excel (nombreArchivoLab).
        nombre = reservar(carpeta, foto.nombreArchivoLab || `${codigoCliente}.jpg`, () => `${codigoCliente}_${sanitizarParaMinilab(foto.tipo)}.jpg`);
      } else {
        carpeta = `${p.cursoCodigo}/${String(p.alumnoNumeroLista).padStart(2, '0')}_${sanitizarParaMinilab(p.alumnoNombre)}`;
        // Bug crítico (15/9): el nombre tiene que distinguir el TIPO (la docente también es 15x21).
        const sufijoTipo = foto.tipo === 'docente' ? (foto.nombreArchivoOriginal === 'FAMILIA_HD.jpg' ? '_FAMILIA' : '_DOCENTE') : foto.nombreArchivoOriginal === 'OTRAS_HD.jpg' ? `_SUELTA${foto.numeroCopia || 1}` : '';
        const sufijoExtra = foto.esCopiaExtra ? `_COPIA${foto.numeroCopia || 2}` : '';
        const n = `${codigoCliente}_${foto.tamanoImpresion}${sufijoTipo}${sufijoExtra}.jpg`;
        nombre = reservar(carpeta, n, () => n);
      }
      entradas.push({ ruta: `${carpeta}/${nombre}`, foto, alumno: p.alumnoNombre, pedido: p.id });
      listaArchivos.push(`${foto.tamanoImpresion}/${nombre}${foto.esCopiaExtra ? ' [COPIA EXTRA]' : ''}${foto.sinFotoReal ? ' [⚠ FALTA FOTO]' : ''}`);
    }
    const tieneCopiasExtras = p.archivosParaLaboratorio.some((a) => a.esCopiaExtra) || (p.copiasExtras && ((p.copiasExtras.individual15x21 || 0) > 0 || (p.copiasExtras.grupal20x30 || 0) > 0));
    const tieneFaltantes = p.archivosParaLaboratorio.some((a) => a.sinFotoReal);
    const cantExtras = p.archivosParaLaboratorio.filter((a) => a.esCopiaExtra).length || 1;
    const alertaExtra = tieneCopiasExtras ? ` ⚠️ [LLEVA ${cantExtras} COPIA${cantExtras === 1 ? '' : 'S'} EXTRA (_COPIA2...) - VAN EN EL MISMO SOBRE]` : '';
    const alertaFaltante = tieneFaltantes ? ' 🛑 [FALTA UNA FOTO REAL - REVISAR ANTES DE ENSOBRAR]' : '';
    planilla += `#${String(p.alumnoNumeroLista).padStart(2, '0')} | ${p.cursoCodigo} | ${p.alumnoNombre} | ${codigoCliente} | ${p.kitNombre}${alertaExtra}${alertaFaltante}${estructura === 'solo_2_carpetas_tamano' ? ` | ${listaArchivos.join(' + ')}` : ''}\n`;
  }

  const textos: { nombre: string; contenido: string }[] = [];
  if (opciones.incluirPlanillaEnsobrado !== false) {
    textos.push({ nombre: `00_PLANILLA_CONTROL_ENSOBRADO_${sanitizarParaMinilab(opciones.filtroCurso || 'TODOS')}.txt`, contenido: planilla });
  }
  textos.push({
    nombre: '00_LEAME_OPERADOR_LABORATORIO.txt',
    contenido: opciones.incluirPlanillaEnsobrado === false ? leameSoloImpresion(estructura) : LEAME_COMPLETO,
  });

  const porParte = opciones.fotosPorParte ?? FOTOS_POR_PARTE_ZIP;
  const partes = Number.isFinite(porParte) ? dividirEnPartes(entradas, porParte) : entradas.length ? [entradas] : [];
  return { partes: partes.length ? partes : [[]], textos, pedidosIncluidos: incluidos, pedidosExcluidos: excluidos, totalFotos: entradas.length };
}

/**
 * Baja el original HD. Primero pide la URL firmada de Storage (`?modo=url`) y baja de ahí, sin
 * pasar el archivo por la función del servidor. Si el servidor todavía es el anterior (ignora
 * `modo` y manda el archivo, o no conoce la ruta), cae al comportamiento de siempre.
 */
async function bajarOriginalHD(urlFoto: string, fetchFoto: (u: string) => Promise<Response>, timeoutFotoMs = TIMEOUT_FOTO_MS): Promise<Blob> {
  const errorHttp = (status: number, origen: string) =>
    [401, 403, 404, 410].includes(status) ? new ErrorSinReintento(`${origen} respondió ${status}`) : new Error(`${origen} respondió ${status}`);
  const validar = (b: Blob) => {
    if (!b || b.size === 0) throw new Error('El archivo llegó vacío');
    return b;
  };
  if (/^\/api\/(lab|admin)\/fotos\/[^/?]+\/original$/.test(urlFoto)) {
    const res = await fetchFoto(`${urlFoto}?modo=url`);
    const tipo = res.headers?.get?.('content-type') || '';
    if (res.ok && tipo.includes('json')) {
      const data = await res.json().catch(() => null);
      if (!data?.success || !data.url) throw new Error(data?.error || 'El servidor no devolvió el enlace de la foto.');
      // Auditoría 03/10 noche: con tiempo máximo (antes `fetch` sin tope: una foto colgada trababa el ZIP).
      return validar(await bajarArchivoConTiempo(data.url, timeoutFotoMs, (status) => errorHttp(status, 'Storage')));
    }
    if (res.ok) return validar(await res.blob()); // servidor anterior: mandó el archivo directo
    if (res.status !== 400 && res.status !== 404) throw errorHttp(res.status, 'El servidor');
  }
  const res = await fetchFoto(urlFoto);
  if (!res.ok) throw errorHttp(res.status, 'El servidor');
  return validar(await res.blob());
}

async function fetchPorDefecto(url: string): Promise<Response> {
  // Auditoría 03/10 noche: también con tiempo máximo (fetchAdminAutenticado ya lo tiene).
  if (!url.startsWith('/api/admin/')) return fetchConTimeout(url);
  const res = await fetchAdminAutenticado(url);
  if (res.status === 401) throw new SesionAdminVencida();
  return res;
}

/** Arma UNA parte del plan. Las fotos que fallan van como tarjeta roja y se devuelven en `fallas`. */
export async function armarParteZipLaboratorio(
  plan: PlanZipLab,
  indiceParte: number,
  opciones: OpcionesArmadoZipLab = {}
): Promise<{ blob: Blob; fallas: FallaZipLab[]; sobrantes: EntradaZipLab[] }> {
  const { default: JSZip } = await import('jszip');
  const zip = new JSZip();
  const entradas = plan.partes[indiceParte] || [];
  const fetchFoto = opciones.fetchFoto || fetchPorDefecto;
  const esErrorFatal = (e: unknown) => e instanceof SesionAdminVencida || Boolean(opciones.esErrorFatal?.(e));
  const bytesMax = opciones.bytesMax ?? BYTES_MAX_PARTE_ZIP;
  const fallas: FallaZipLab[] = [];
  let bytes = 0;

  const agregarFalta = async (e: EntradaZipLab, motivo: string) => {
    const nombre = e.ruta.split('/').pop() || e.ruta;
    const carpeta = e.ruta.slice(0, e.ruta.length - nombre.length);
    fallas.push({ archivo: e.ruta, alumno: e.alumno, pedido: e.pedido, motivo });
    zip.file(`${carpeta}FALTA_${nombre}`, await generarTarjetaFalta(nombre, e.foto.tamanoImpresion, e.foto.tipo, motivo));
  };

  const resultados = await ejecutarConConcurrencia(
    entradas,
    DESCARGAS_SIMULTANEAS,
    async (e) => {
      if (e.foto.sinFotoReal || !(e.foto.urlOriginalHD || e.foto.urlMuestra)) {
        await agregarFalta(e, 'No se encontró la foto que eligió la familia');
        return true;
      }
      try {
        // Auditoría 03/10 noche: tope total por intento (pedir el enlace + bajar la foto). Si vence,
        // la foto va como FALTA en vez de dejar el ZIP colgado.
        const timeoutFotoMs = opciones.timeoutFotoMs ?? TIMEOUT_FOTO_MS;
        const topeIntento = TIMEOUT_FETCH_MS + timeoutFotoMs + 5_000;
        const blob = await conReintentos(() => conTiempoMaximo(bajarOriginalHD(e.foto.urlOriginalHD || e.foto.urlMuestra, fetchFoto, timeoutFotoMs), topeIntento), {
          intentos: 3,
          esFatal: esErrorFatal,
        });
        bytes += blob.size;
        zip.file(e.ruta, blob);
      } catch (err) {
        if (esErrorFatal(err)) throw err;
        await agregarFalta(e, err instanceof Error ? err.message : 'No se pudo bajar');
      }
      return true;
    },
    { debeParar: () => bytes >= bytesMax, alTerminarUno: opciones.onProgreso }
  );
  const sobrantes = entradas.filter((_, i) => resultados[i] === undefined);

  const total = plan.partes.length + (sobrantes.length ? 1 : 0);
  for (const t of plan.textos) zip.file(t.nombre, t.contenido);
  if (total > 1) {
    zip.file('00_PARTE.txt', `Este ZIP es la parte ${indiceParte + 1} de ${total} del lote. Bajen y descompriman todas las partes en la misma carpeta.\n`);
  }
  if (fallas.length > 0) zip.file('FALTAN_FOTOS.txt', textoFaltantes(fallas));
  const blob = await zip.generateAsync({ type: 'blob' });
  return { blob, fallas, sobrantes };
}

/** Todo en un solo ZIP (reimpresiones, un alumno, lotes chicos). */
export async function descargarLoteLaboratorioZip(
  pedidos: PedidoEscolarCompleto[],
  opciones: OpcionesZipLab & OpcionesArmadoZipLab
): Promise<{ blob: Blob; fallas: FallaZipLab[]; plan: PlanZipLab }> {
  const plan = planificarZipLaboratorio(pedidos, { ...opciones, fotosPorParte: Infinity });
  const { blob, fallas } = await armarParteZipLaboratorio(plan, 0, { ...opciones, bytesMax: Infinity });
  return { blob, fallas, plan };
}

export function textoFaltantes(fallas: FallaZipLab[]): string {
  return (
    `FOTOS QUE FALTAN EN ESTE ZIP (${fallas.length})\n` +
    `En su lugar va una tarjeta roja FALTA_<nombre>.jpg: NO IMPRIMIRLA. Avisar al fotógrafo.\n\n` +
    fallas.map((f) => `- ${f.archivo} · ${f.alumno} · pedido ${f.pedido} · ${f.motivo}`).join('\n') +
    '\n'
  );
}

/** Resumen corto para mostrar en pantalla. */
export function resumenFallas(fallas: FallaZipLab[], max = 8): string {
  const lista = fallas.slice(0, max).map((f) => `${f.alumno} (${f.archivo.split('/').pop()})`).join(', ');
  return `${lista}${fallas.length > max ? ` y ${fallas.length - max} más` : ''}`;
}

export function descargarBlobComoArchivo(blob: Blob, nombre: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = nombre;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 30_000);
}

/** Tarjeta roja que reemplaza una foto que falta (nunca gris: el laboratorio no la tiene que imprimir). */
async function generarTarjetaFalta(nombre: string, tamano: string, tipo: string, motivo: string): Promise<Blob> {
  const texto = `FALTA – ${nombre}\n${motivo}`;
  if (typeof document === 'undefined') return new Blob([texto], { type: 'image/jpeg' });
  const canvas = document.createElement('canvas');
  const es20x30 = tamano === '20x30';
  canvas.width = es20x30 ? 1200 : 840;
  canvas.height = es20x30 ? 800 : 1180;
  const ctx = canvas.getContext('2d');
  if (!ctx) return new Blob([texto], { type: 'image/jpeg' });
  ctx.fillStyle = '#fee2e2';
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  ctx.strokeStyle = '#dc2626';
  ctx.lineWidth = 26;
  ctx.strokeRect(18, 18, canvas.width - 36, canvas.height - 36);
  ctx.textAlign = 'center';
  ctx.fillStyle = '#b91c1c';
  ctx.fillRect(60, 90, canvas.width - 120, 70);
  ctx.fillStyle = '#ffffff';
  ctx.font = 'bold 40px sans-serif';
  ctx.fillText('FALTA – NO IMPRIMIR', canvas.width / 2, 140);
  ctx.fillStyle = '#7f1d1d';
  ctx.font = 'bold 30px monospace';
  // Nombres largos: se cortan en renglones para que se lean enteros.
  const renglones = nombre.match(/.{1,34}/g) || [nombre];
  renglones.forEach((r, i) => ctx.fillText(r, canvas.width / 2, canvas.height / 2 - 40 + i * 40));
  ctx.fillStyle = '#991b1b';
  ctx.font = 'bold 22px sans-serif';
  ctx.fillText(`CARPETA: ${tamano} · TOMA: ${String(tipo).toUpperCase()}`, canvas.width / 2, canvas.height / 2 + 40 + renglones.length * 40);
  ctx.font = '20px sans-serif';
  ctx.fillText(motivo.slice(0, 70), canvas.width / 2, canvas.height - 90);
  return new Promise<Blob>((resolve) => {
    canvas.toBlob((b) => resolve(b || new Blob([texto], { type: 'image/jpeg' })), 'image/jpeg', 0.9);
  });
}

const LEAME_COMPLETO = `INSTRUCCIONES PARA EL OPERADOR DE LABORATORIO / MINILAB:
1. Este archivo ZIP contiene exactamente 2 carpetas organizadas por tamaño de papel:
   - "15x21": Contiene las fotos individuales y ampliaciones 15x21 sueltas.
   - "20x30": Contiene las fotos grupales 20x30 sueltas.
2. Cada archivo JPG tiene como nombre el CÓDIGO DE CLIENTE del alumno (ej: 3ATT_FABRICIO_PEREZ.jpg).
3. ATENCIÓN A COPIAS EXTRAS DUPLICADAS:
   Los archivos con sufijo "_COPIA2.jpg", "_COPIA3.jpg" corresponden a fotos duplicadas solicitadas y abonadas por los padres.
   El minilab imprimirá ambos archivos automáticamente. Ambos ejemplares deben guardarse juntos dentro del mismo sobre del alumno para evitar omisiones.
4. Por favor asegurar que la máquina (Noritsu / Fuji Frontier / Klick) tenga activada la opción:
   "IMPRIMIR NOMBRE DE ARCHIVO EN EL DORSO DEL PAPEL (Backprint)".
5. De este modo, tanto la copia original como la copia extra tendrán estampado en el reverso:
   "3ATT_FABRICIO_PEREZ" y "3ATT_FABRICIO_PEREZ_COPIA2"
6. En la mesa de ensobrado, basta con hacer coincidir ambos dorsos para colocarlos en el sobre del alumno.
7. Los archivos FALTA_*.jpg (tarjeta roja) son fotos que no se pudieron bajar: NO se imprimen. Ver FALTAN_FOTOS.txt.
Muchas gracias. Retrato Escolar.`;

function leameSoloImpresion(estructura: EstructuraZipLab) {
  return `INSTRUCCIONES PARA EL LABORATORIO:
1. Carpetas del ZIP: ${estructura === 'solo_2_carpetas_tamano' ? '"15x21" (individuales y fotos sueltas) y "20x30" (grupales).' : 'una carpeta por alumno; el tamaño está en la foto.'}
2. Cada archivo se llama con el código del alumno (ej: 3ATT_FABRICIO_PEREZ.jpg).
3. Los archivos terminados en _COPIA2, _COPIA3... son copias extra pagadas: se imprimen todas.
4. Activar en la máquina la impresión del nombre de archivo en el dorso (Backprint).
5. El ensobrado lo hace el estudio: no hace falta separar por alumno.
6. Las cantidades para facturar están en la hoja "Totales" del Excel.
7. Los archivos FALTA_*.jpg (tarjeta roja) son fotos que no se pudieron bajar: NO se imprimen. Ver FALTAN_FOTOS.txt y avisen con "Hay un problema".
Muchas gracias. Retrato Escolar.`;
}
