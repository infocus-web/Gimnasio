import type { PedidoExistenteResumen } from './pedidosLabService';
import { guardarLlavePedido } from '../utils/accesoPedido';
import { ErrorTiempoAgotado, esStatusTransitorio, fetchConTimeout, MENSAJE_DEMASIADOS_INTENTOS } from '../utils/fetchConTimeout';

/**
 * Auditoría 03/10 (alto 6): `verificarPedidoExistente` devuelve `null` tanto si NO hay pedido
 * como si la consulta FALLÓ (429 del límite por IP, 5xx, corte de red). El portal lo tomaba como
 * "no hay pedido" y dejaba comprar de nuevo: con el servidor saturado (día de publicación de un
 * colegio) salían kits pagados dos veces. Esta versión distingue las tres cosas para que el portal
 * frene el avance y ofrezca reintentar cuando no se pudo verificar.
 *
 * Un 4xx que no sea 429 (código inválido, faltan datos) no es pasajero: se trata como "no hay".
 */
export type ResultadoPedidoExistente =
  | { ok: true; pedido: PedidoExistenteResumen | null }
  | { ok: false; error: string };

export async function consultarPedidoExistente(datos: {
  codigo?: string | null;
  alumnoNombre?: string;
  /** Auditoría 05/10: llave de galería de la familia; sin ella el servidor no devuelve el UUID del pedido. */
  familia?: string | null;
  acceso?: string | null;
}): Promise<ResultadoPedidoExistente> {
  const { codigo, alumnoNombre } = datos;
  if (!codigo || !alumnoNombre) return { ok: true, pedido: null };
  try {
    const params = new URLSearchParams({ codigo, alumnoNombre });
    if (datos.familia && datos.acceso) {
      params.set('familia', datos.familia);
      params.set('acceso', datos.acceso);
    }
    const res = await fetchConTimeout(`/api/pedidos/existente?${params.toString()}`);
    if (esStatusTransitorio(res.status)) {
      return {
        ok: false,
        error: res.status === 429 ? MENSAJE_DEMASIADOS_INTENTOS : 'No pudimos verificar si ya tenés un pedido hecho (el servidor no respondió bien).',
      };
    }
    const data = await res.json().catch(() => null);
    if (!res.ok || !data?.success || !data.existe || !data.pedido) return { ok: true, pedido: null };
    // 14/10/2026: a la familia identificada el servidor le da la llave de su pedido pendiente (sólo vivía
    // en el navegador que lo creó): se guarda acá para poder pagarlo o cambiarle el medio desde este dispositivo.
    const pedido = data.pedido as PedidoExistenteResumen;
    if (pedido.accesoToken) guardarLlavePedido([pedido.pedidoUuid, pedido.grupoPagoId], pedido.accesoToken);
    return { ok: true, pedido };
  } catch (err) {
    return {
      ok: false,
      error: err instanceof ErrorTiempoAgotado ? err.message : 'No pudimos verificar si ya tenés un pedido hecho (sin conexión).',
    };
  }
}
