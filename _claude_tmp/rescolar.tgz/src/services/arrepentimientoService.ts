import { fetchConTimeout } from '../utils/fetchConTimeout';

/** Botón de arrepentimiento (Disposición 954/2025). Ver /api/arrepentimiento en server.ts. */
export async function enviarSolicitudArrepentimiento(datos: {
  pedido: string;
  nombre: string;
  email: string;
  motivo?: string;
}): Promise<{
  success: boolean;
  codigo?: string;
  pedidoEncontrado?: boolean;
  // Auditoría 03/10: el servidor avisa si de verdad salió el email con el código (sólo sale si el
  // email coincide con el del pedido y no se pasó el tope diario). Si es false, la pantalla no
  // puede decir "te lo mandamos por email".
  emailEnviado?: boolean;
  error?: string;
}> {
  try {
    // Auditoría 11/10: con tiempo máximo.
    const res = await fetchConTimeout('/api/arrepentimiento', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(datos),
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok || !data.success) {
      return { success: false, error: data.error || 'No pudimos registrar tu solicitud. Escribinos a contacto@retratoescolar.com.ar con tu número de pedido.' };
    }
    return { ...data, emailEnviado: data.emailEnviado === true };
  } catch {
    return { success: false, error: 'Error de conexión. Revisá tu internet e intentá de nuevo, o escribinos a contacto@retratoescolar.com.ar.' };
  }
}
