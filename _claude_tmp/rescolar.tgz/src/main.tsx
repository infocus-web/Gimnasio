import {StrictMode, Suspense, lazy} from 'react';
import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import ErrorBoundary from './components/ErrorBoundary';
import './index.css';
import './modoNoche.css';
import { instalarCapturaDeErrores } from './services/reporteErrores';
import { cargarPrecios } from './services/preciosService';
import { importarConRecarga, recargarPorVersionNueva } from './utils/recargaTrasDeploy';

// Panel del laboratorio (retratoescolar.com.ar/laboratorio): pantalla aparte, se carga sólo ahí.
const PanelLaboratorio = lazy(importarConRecarga(() => import('./components/PanelLaboratorio')));
const esPanelLaboratorio = window.location.pathname.replace(/\/+$/, '') === '/laboratorio';
// 10/10/2026: panel propio del colegio (retratoescolar.com.ar/colegio?c=<codigo>), también aparte.
const PanelColegio = lazy(importarConRecarga(() => import('./components/PanelColegio')));
const esPanelColegio = window.location.pathname.replace(/\/+$/, '') === '/colegio';

// Antes del primer render: así también quedan anotadas las primeras llamadas al servidor.
instalarCapturaDeErrores();
// Precios vigentes (se editan desde el panel): se piden apenas abre la página.
void cargarPrecios();

// Versión nueva publicada con la pestaña abierta: Vite avisa que no encontró un archivo; se recarga.
// OJO: no se llama a `preventDefault()`. Si se previene, Vite hace que el `import()` resuelva con
// `undefined` en vez de fallar, y React.lazy rompe con "Cannot read properties of undefined
// (reading 'default')" (caso real 5/10). Dejándolo fallar, el error llega al `catch` de
// `importarConRecarga`, que deja el import en espera mientras la página se recarga.
window.addEventListener('vite:preloadError', () => {
  recargarPorVersionNueva();
});

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <ErrorBoundary variante="pagina">
      {esPanelLaboratorio ? (
        <Suspense fallback={null}>
          <PanelLaboratorio />
        </Suspense>
      ) : esPanelColegio ? (
        <Suspense fallback={null}>
          <PanelColegio />
        </Suspense>
      ) : (
        <App />
      )}
    </ErrorBoundary>
  </StrictMode>,
);
