import { useCallback, useEffect, useState } from 'react';
import { Copy, Download, Loader2, Percent, Plus } from 'lucide-react';
import { TOPE_DESCUENTO_IMPRESO, activarCodigoDescuentoAdmin, crearCodigoDescuentoAdmin, crearLoteCodigosDescuentoAdmin, obtenerCodigosDescuentoAdmin, type AmbitoDescuento, type CodigoDescuentoAdmin } from '../services/descuentosService';

/**
 * Pestaña «Descuentos» del panel (22/10/2026, Pablo: «un código de descuento que yo desde el panel pueda generar y
 * elegir qué porcentaje ofrecer»). Hasta 100% (sin cargo); sólo sobre el kit; usos y vencimiento opcionales.
 * Servidor: servidor/pagos/descuentos.ts.
 */
// 27/10/2026: `ambito` = dónde vale el código (kit del colegio o pedidos de eventos, ver eventos/descuentos.ts).
const FORM = { codigo: '', porcentaje: '100', usos: '1', vence: '', nota: '', sinTopeImpreso: false, ambito: 'kit' as AmbitoDescuento };
const fecha = (iso: string | null) => (iso ? new Date(iso).toLocaleDateString('es-AR') : '');
/** 28/10: el listado pegado (de Excel o a mano): una persona por línea; si viene con columnas, se juntan con un espacio. */
const nombresDelListado = (texto: string) => texto.split(/\r?\n/).map((l) => l.split('\t').map((x) => x.trim()).filter(Boolean).join(' ')).filter(Boolean);
/** CSV con «;» y BOM para que Excel en castellano lo abra bien en columnas y con tildes. */
function descargarCsv(codigos: CodigoDescuentoAdmin[]) {
  const celda = (v: unknown) => `"${String(v ?? '').replace(/"/g, '""')}"`;
  const filas = [['Nombre', 'Código', 'Porcentaje', 'Usos', 'Vence'], ...codigos.map((c) => [c.nota, c.codigo, `${c.porcentaje}%`, c.usos_max ?? 'sin límite', fecha(c.vence_at)])];
  const blob = new Blob(['\ufeff' + filas.map((f) => f.map(celda).join(';')).join('\r\n')], { type: 'text/csv;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `codigos-descuento-${new Date().toISOString().slice(0, 10)}.csv`;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

export default function AdminDescuentosTab() {
  const [codigos, setCodigos] = useState<CodigoDescuentoAdmin[]>([]);
  const [cargando, setCargando] = useState(false);
  const [form, setForm] = useState(FORM);
  const [guardando, setGuardando] = useState(false);
  const [trabajando, setTrabajando] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [aviso, setAviso] = useState<string | null>(null);
  const [porLote, setPorLote] = useState(false); // 28/10: un código por persona del listado
  const [listado, setListado] = useState('');
  const [ultimoLote, setUltimoLote] = useState<CodigoDescuentoAdmin[]>([]);
  const nombresLote = nombresDelListado(listado);

  const cargar = useCallback(async () => {
    setCargando(true);
    const r = await obtenerCodigosDescuentoAdmin();
    if (r.success) setCodigos(r.codigos);
    else setError(r.error || 'No se pudieron cargar los códigos.');
    setCargando(false);
  }, []);
  useEffect(() => {
    void cargar();
  }, [cargar]);

  const crear = async () => {
    setError(null);
    setAviso(null);
    const porcentaje = Number(form.porcentaje);
    if (!(porcentaje >= 1 && porcentaje <= 100)) return setError('El porcentaje tiene que ser entre 1 y 100.');
    setGuardando(true);
    if (porLote) {
      if (nombresLote.length === 0) return (setGuardando(false), setError('Pegá el listado: una persona por línea.'));
      const l = await crearLoteCodigosDescuentoAdmin({ nombres: nombresLote, porcentaje, usosMax: form.usos.trim() ? Number(form.usos) : null, vence: form.vence, sinTopeImpreso: form.sinTopeImpreso, ambito: form.ambito });
      setGuardando(false);
      if (!l.success || !l.codigos) return setError(l.error || 'No se pudieron crear los códigos.');
      setCodigos((prev) => [...l.codigos!, ...prev]);
      setUltimoLote(l.codigos);
      setListado('');
      setAviso(`${l.codigos.length} códigos creados. Descargá el listado para repartirlos.`);
      return;
    }
    const r = await crearCodigoDescuentoAdmin({ codigo: form.codigo.trim() || undefined, porcentaje, usosMax: form.usos.trim() ? Number(form.usos) : null, vence: form.vence, nota: form.nota.trim(), sinTopeImpreso: form.sinTopeImpreso, ambito: form.ambito });
    setGuardando(false);
    if (!r.success || !r.codigo) return setError(r.error || 'No se pudo crear el código.');
    setCodigos((prev) => [r.codigo!, ...prev]);
    setForm(FORM);
    setAviso(`Código ${r.codigo.codigo} creado (${r.codigo.porcentaje}% ${r.codigo.ambito === 'eventos' ? 'en los eventos' : 'en el kit'}${r.codigo.sin_tope_impreso ? ', también en el impreso' : ''}).`);
  };

  const cambiarActivo = async (c: CodigoDescuentoAdmin) => {
    if (c.activo && !window.confirm(`¿Desactivar el código ${c.codigo}? Ya no se va a poder usar.`)) return;
    setTrabajando(c.id);
    const r = await activarCodigoDescuentoAdmin(c.id, !c.activo);
    setTrabajando(null);
    if (!r.success || !r.codigo) return setError(r.error || 'No se pudo actualizar el código.');
    setCodigos((prev) => prev.map((x) => (x.id === c.id ? { ...x, ...r.codigo! } : x)));
  };

  const copiar = (codigo: string) => {
    void navigator.clipboard?.writeText(codigo).then(() => setAviso(`Código ${codigo} copiado.`)).catch(() => undefined);
  };

  const input = 'mt-1 block w-full rounded-xl border border-slate-300 px-3 py-2 text-sm font-normal bg-white';
  return (
    <div className="space-y-4 text-left text-slate-900">
      <div className="flex items-start gap-3">
        <Percent className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" aria-hidden="true" />
        <div>
          <h2 className="text-base font-bold">Códigos de descuento</h2>
          <p className="text-xs text-slate-600">
            La familia (o el docente) lo pone en el pago. El descuento es sólo sobre el kit: las carpetas extra y las fotos sueltas se
            cobran completas. En los kits impresos el descuento llega como máximo al {TOPE_DESCUENTO_IMPRESO}% (la impresión no se regala), salvo que marques
            «Sin tope en el kit impreso»; el kit digital acepta hasta 100%. Con 100% y sin extras, el pedido queda pagado sin cargo («Bonificado») y no suma ni resta en la liquidación del colegio.
            Un uso se gasta al registrar la compra (aunque después no la paguen). Para códigos al 100%, mejor dejá que se generen al azar.
          </p>
          <p className="mt-1 text-xs text-slate-600">
            Cada código vale para una sola cosa: el <strong>kit del colegio</strong> o los <strong>eventos</strong> (por ejemplo, la foto de hermanos). En los eventos
            se descuenta del pedido entero (digitales hasta 100%; copias impresas hasta {TOPE_DESCUENTO_IMPRESO}% salvo «sin tope»), un uso por pedido.
          </p>
        </div>
      </div>

      <section className="rounded-2xl border border-slate-200 bg-white p-4 space-y-3" aria-labelledby="titulo-nuevo-codigo">
        <h3 id="titulo-nuevo-codigo" className="text-sm font-bold">Nuevo código</h3>
        <div className="inline-flex rounded-xl border border-slate-300 p-0.5 text-xs font-semibold" role="group" aria-label="Cantidad de códigos">
          {([
            [false, 'Un código'],
            [true, 'Por lote (uno por persona)'],
          ] as Array<[boolean, string]>).map(([valor, texto]) => (
            <button key={texto} type="button" aria-pressed={porLote === valor} onClick={() => setPorLote(valor)} className={`rounded-lg px-3 py-1.5 cursor-pointer ${porLote === valor ? 'bg-amber-500 text-white' : 'text-slate-700 hover:bg-slate-100'}`}>
              {texto}
            </button>
          ))}
        </div>
        <fieldset className="flex flex-wrap gap-2">
          <legend className="mb-1 text-xs font-semibold text-slate-700">Vale para</legend>
          {([
            ['kit', 'Kit del colegio'],
            ['eventos', 'Eventos (ej. foto de hermanos)'],
          ] as Array<[AmbitoDescuento, string]>).map(([valor, texto]) => (
            <label key={valor} className={`inline-flex items-center gap-2 rounded-xl border px-3 py-2 text-xs font-semibold cursor-pointer ${form.ambito === valor ? 'border-amber-500 bg-amber-50 text-amber-900' : 'border-slate-300 bg-white text-slate-700'}`}>
              <input type="radio" name="ambito-descuento" value={valor} checked={form.ambito === valor} onChange={() => setForm({ ...form, ambito: valor })} className="h-4 w-4 accent-amber-500" />
              {texto}
            </label>
          ))}
        </fieldset>
        <div className={`grid gap-3 sm:grid-cols-2 ${porLote ? 'lg:grid-cols-3' : 'lg:grid-cols-5'}`}>
          <label className="text-xs font-semibold text-slate-700">
            Porcentaje
            <input type="number" min={1} max={100} value={form.porcentaje} onChange={(e) => setForm({ ...form, porcentaje: e.target.value })} className={input} />
          </label>
          <label className="text-xs font-semibold text-slate-700">
            Usos (vacío = sin límite)
            <input type="number" min={1} value={form.usos} onChange={(e) => setForm({ ...form, usos: e.target.value })} className={input} />
          </label>
          <label className="text-xs font-semibold text-slate-700">
            Vence (opcional)
            <input type="date" value={form.vence} onChange={(e) => setForm({ ...form, vence: e.target.value })} className={input} />
          </label>
          {!porLote && (<>
          <label className="text-xs font-semibold text-slate-700">
            Código (vacío = al azar)
            <input value={form.codigo} onChange={(e) => setForm({ ...form, codigo: e.target.value.toUpperCase() })} placeholder="Ej: DOCENTES2026" className={input} />
          </label>
          <label className="text-xs font-semibold text-slate-700">
            Nota (para vos)
            <input value={form.nota} maxLength={200} onChange={(e) => setForm({ ...form, nota: e.target.value })} placeholder="Ej: Seño Laura, 1° A" className={input} />
          </label>
          </>)}
        </div>
        {porLote && (
          <label className="block text-xs font-semibold text-slate-700">
            Listado (una persona por línea; podés pegar la columna de Excel)
            <textarea value={listado} onChange={(e) => setListado(e.target.value)} rows={8} placeholder={'Laura Gómez - docente 1° A\nMarcelo Pérez - secretaría'} className={`${input} font-mono`} />
            <span className="mt-1 block font-normal text-slate-500">
              {nombresLote.length > 0 ? `Se van a crear ${new Set(nombresLote.map((n) => n.toLowerCase())).size} códigos al azar, uno por persona (los nombres repetidos se cuentan una vez). El nombre queda en la nota.` : 'Cada persona recibe su propio código al azar con la configuración de arriba.'}
            </span>
          </label>
        )}
        <label className="flex items-start gap-2 text-xs font-semibold text-slate-700 cursor-pointer">
          <input type="checkbox" checked={form.sinTopeImpreso} onChange={(e) => setForm({ ...form, sinTopeImpreso: e.target.checked })} className="mt-0.5 h-4 w-4 accent-amber-500" />
          <span>
            {form.ambito === 'eventos' ? 'Sin tope en las copias impresas' : 'Sin tope en el kit impreso'}
            <span className="block font-normal text-slate-500">{form.ambito === 'eventos' ? 'Las copias impresas del evento' : 'El impreso'} también lleva el porcentaje completo (con 100% sale sin cargo y la impresión corre por tu cuenta).</span>
          </span>
        </label>
        <button type="button" onClick={() => void crear()} disabled={guardando} className="inline-flex items-center gap-1.5 rounded-xl bg-amber-500 px-4 py-2 text-xs font-bold text-white hover:bg-amber-600 disabled:opacity-50 cursor-pointer">
          {guardando ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Plus className="w-3.5 h-3.5" />} {porLote ? 'Crear códigos' : 'Crear código'}
        </button>
        {ultimoLote.length > 0 && (
          <button type="button" onClick={() => descargarCsv(ultimoLote)} className="ml-2 inline-flex items-center gap-1.5 rounded-xl border border-amber-500 px-4 py-2 text-xs font-bold text-amber-800 hover:bg-amber-50 cursor-pointer">
            <Download className="w-3.5 h-3.5" /> Descargar los {ultimoLote.length} códigos del lote (Excel)
          </button>
        )}
        {aviso && <p role="status" className="text-xs font-semibold text-emerald-700">{aviso}</p>}
        {error && <p role="alert" className="text-xs font-semibold text-rose-700">{error}</p>}
      </section>

      {cargando ? (
        <p className="text-xs text-slate-500">Cargando…</p>
      ) : codigos.length === 0 ? (
        <p className="text-xs text-slate-500">Todavía no creaste códigos.</p>
      ) : (
        <div className="overflow-x-auto rounded-2xl border border-slate-200 bg-white">
          <table className="w-full text-xs">
            <thead className="bg-slate-50 text-[11px] uppercase tracking-wide text-slate-500">
              <tr>
                <th className="py-2.5 px-3 text-left">Código</th>
                <th className="py-2.5 px-3 text-left">Vale para</th>
                <th className="py-2.5 px-3 text-left">Descuento</th>
                <th className="py-2.5 px-3 text-left">Usado</th>
                <th className="py-2.5 px-3 text-left">Vence</th>
                <th className="py-2.5 px-3 text-left">Nota</th>
                <th className="py-2.5 px-3 text-left">Estado</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {codigos.map((c) => (
                <tr key={c.id} className={c.activo ? '' : 'opacity-60'}>
                  <td className="py-2.5 px-3">
                    <button type="button" onClick={() => copiar(c.codigo)} title="Copiar" className="inline-flex items-center gap-1.5 font-mono text-sm font-bold text-slate-900 hover:text-amber-700 cursor-pointer">
                      {c.codigo} <Copy className="w-3 h-3" aria-hidden="true" />
                    </button>
                  </td>
                  <td className="py-2.5 px-3">{c.ambito === 'eventos' ? 'Eventos' : 'Kit'}</td>
                  <td className="py-2.5 px-3 font-semibold">{c.porcentaje}%{c.porcentaje > TOPE_DESCUENTO_IMPRESO ? (c.sin_tope_impreso ? ' (digital e impreso)' : ` (digital; impreso ${TOPE_DESCUENTO_IMPRESO}%)`) : ''}</td>
                  <td className="py-2.5 px-3">{c.usos}{c.usos_max ? ` de ${c.usos_max}` : ' (sin límite)'}</td>
                  <td className="py-2.5 px-3">{fecha(c.vence_at) || '—'}</td>
                  <td className="py-2.5 px-3 text-slate-600">{c.nota}</td>
                  <td className="py-2.5 px-3">
                    <button type="button" disabled={trabajando === c.id} onClick={() => void cambiarActivo(c)} className={`rounded-lg px-2.5 py-1 text-[11px] font-bold cursor-pointer disabled:opacity-50 ${c.activo ? 'bg-emerald-100 text-emerald-800 hover:bg-emerald-200' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'}`}>
                      {c.activo ? 'Activo · desactivar' : 'Inactivo · activar'}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
