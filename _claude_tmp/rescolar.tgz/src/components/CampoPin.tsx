import { useState, type InputHTMLAttributes } from 'react';
import { Eye, EyeOff } from 'lucide-react';

/**
 * Campo de PIN con botón de "ojito" para mostrar u ocultar lo que se escribe
 * (pedido de Pablo, 8/10/2026: con el campo tapado no podía ver qué PIN estaba poniendo).
 * Se usa en el panel del fotógrafo, en el escaneo de pedidos y en el panel del laboratorio.
 * Arranca oculto; el padding lateral se fuerza con `style` para que el ícono no tape
 * el texto y el PIN siga centrado.
 */
type Props = Omit<InputHTMLAttributes<HTMLInputElement>, 'type'> & {
  /** Clases del botón del ojito (color del ícono según el fondo del campo). */
  botonClassName?: string;
  /** Clases del contenedor (márgenes van acá, no en el input, para que el ojito quede centrado). */
  contenedorClassName?: string;
};

export default function CampoPin({
  botonClassName = 'text-slate-400 hover:text-slate-700',
  contenedorClassName = '',
  style,
  ...props
}: Props) {
  const [visible, setVisible] = useState(false);
  const etiqueta = visible ? 'Ocultar PIN' : 'Mostrar PIN';

  return (
    <div className={`relative w-full ${contenedorClassName}`}>
      <input
        {...props}
        type={visible ? 'text' : 'password'}
        autoComplete="off"
        style={{ ...style, paddingLeft: '3rem', paddingRight: '3rem' }}
      />
      <button
        type="button"
        onClick={() => setVisible(v => !v)}
        aria-label={etiqueta}
        aria-pressed={visible}
        title={etiqueta}
        className={`absolute inset-y-0 right-0 flex w-12 items-center justify-center rounded-r-xl transition-colors cursor-pointer ${botonClassName}`}
      >
        {visible ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
      </button>
    </div>
  );
}
