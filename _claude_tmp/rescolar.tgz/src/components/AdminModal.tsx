import React, { useState, useMemo, useEffect, useRef, useCallback } from 'react';
import * as XLSX from 'xlsx';
import {
  X, Lock, Camera, Upload, CheckCircle2, DollarSign, Package,
  School, RefreshCw, Eye, AlertCircle, ArrowRight, Users, Search, Square, Download,
  Key, Copy, Check, MessageSquare, Sparkles, Send, ExternalLink, Printer, HardDrive, FileCode, Mail,
  FileSpreadsheet, Scissors, FileText, UserCheck, Trash2, Phone, Save, Database, Globe,
  Pencil, Loader2, Link2, UploadCloud, Moon, Sun, LogOut, RotateCcw, Tag, Calculator, ClipboardList, CameraOff, Percent, Settings,
} from 'lucide-react';
import { useModoNoche } from '../utils/modoNoche';
import { useEtiquetasTablasMovil } from '../utils/tablasMovil';
import CampoPin from './CampoPin';
import { NombreConCambioCurso, useCambioCursoNomina } from './ModalCambiarCursoAlumno';
import { CeldaObservacionesNomina, ColumnasNomina, useObservacionesNomina } from './ObservacionesNomina';
import { compararAlumnosNomina, filtrarPorFoto, fotosQueLeFaltan, useFotografiadosNomina, type FiltroFoto } from './fotografiadosNomina';
import FiltroFotografiadoNomina, { BotonesChequeoNomina, EstadoFotoNomina } from './FiltroFotografiadoNomina';
import ResumenCursosNomina from './ResumenCursosNomina';
import {
  obtenerConfiguracionWhatsApp,
  guardarNumeroWhatsAppFlotante,
  sanitizarNumeroWhatsApp,
  sincronizarDesdeSupabase,
  formatearNumeroVisual,
  ConfiguracionWhatsApp
} from '../services/configuracionService';
import { useColegiosLista, obtenerTokensPadronAdmin, regenerarTokenPadronAdmin, obtenerAlumnosNominaAdmin, AlumnoNominaReal } from '../services/colegiosService';
import { SeccionEscolar } from '../data/alumnosData';
import {
  obtenerCodigosSeccionAdmin,
  asegurarCodigoSeccionAdmin,
  regenerarCodigoSeccionAdmin,
  actualizarCodigoSeccionAdmin
} from '../services/codigosSeccionService';
import {
  obtenerPedidosGuardados,
  guardarPedidosEnStorage,
  PedidoEscolarCompleto,
  obtenerPedidosAdminDesdeSupabase,
  SESION_ADMIN_VENCIDA,
  obtenerFechaUltimaSincronizacion,
  organizarPedidoAdmin,
  combinarPedidosConLocal,
  obtenerLinkComprobanteAdmin,
  pedidoEstaEntregado,
  eliminarPedidoAdminConControl
} from '../services/pedidosLabService';
import {
  obtenerInscripcionesAdmin,
  determinarCodigoParaInscripcion
} from '../services/inscripcionesService';
import { 
  descargarExcelLegibleColegio,
  descargarCSVEspañolCompatible,
  descargarGuiaWhatsAppTxt,
  generarGuiaWhatsAppColegioTexto,
  generarMensajeWhatsApp
} from '../services/difusionEscolarService';
import { descargarLibroExcel } from '../services/excelDownloadHelper';
import {
  obtenerResumenCierreAnio,
  ejecutarCierreAnio,
  ResumenCierreAnio,
  BloqueosCierreAnio
} from '../services/cierreAnioService';
import AdminLaboratorioTab from './AdminLaboratorioTab';
import AdminCampanaPagoAnticipado from './AdminCampanaPagoAnticipado';
import AdminEstadoSistema from './AdminEstadoSistema';
import { registrarContextoDeError } from '../services/reporteErrores';
import AdminLoteFotosTab from './AdminLoteFotosTab';
import {
  loginAdminConServidor,
  verificarSesionAdmin,
  cerrarSesionAdminYBorrarDatos,
  obtenerTokenAdmin,
  actualizarEstadoPedidoAdmin
} from '../services/adminAuthService';
import AdminInscriptosTab from './AdminInscriptosTab';
import AdminPadronTab from './AdminPadronTab';
import AdminLiquidacionColegios from './AdminLiquidacionColegios';
import AdminEstadoPagosTab from './AdminEstadoPagosTab';
import AdminBuscadorAlumnosTab from './AdminBuscadorAlumnosTab';
import AdminImportarAlumnosTab from './AdminImportarAlumnosTab';
import AdminSolicitudesCodigoTab from './AdminSolicitudesCodigoTab';
import AdminConsultasFamiliasTab from './AdminConsultasFamiliasTab';
import AdminZohoCampanaTab from './AdminZohoCampanaTab';
import { obtenerSolicitudesCodigoAdmin } from '../services/solicitudesCodigoService';
import AdminConfigWhatsAppTab from './AdminConfigWhatsAppTab';
import AdminCancelacionesTab from './AdminCancelacionesTab';
import AdminObservacionesTab from './AdminObservacionesTab';
import AdminFaltantesTab from './AdminFaltantesTab';
import AdminDescuentosTab from './AdminDescuentosTab';
import AdminEmailsTab from './AdminEmailsTab';
import AdminPreciosTab from './AdminPreciosTab'; import AdminConfiguracionTab from './AdminConfiguracionTab'; // 30/10: panel → Configuración
import AdminPanelColegioAcceso from './AdminPanelColegioAcceso';
import AdminResumenKitsSection from './AdminResumenKitsSection';
import { CircularImprimibleModal } from './CircularImprimibleModal';
import { enviarFotosPorEmail } from '../services/emailService';
import { Colegio } from '../types';
import { copiarAlPortapapeles } from '../utils/portapapeles';
import { AVISO_PREVIO_VENCIMIENTO_HORAS, pedidoVencidoRecuperable, venceTransferencia } from '../utils/plazoTransferencia';

// Filtros rápidos de la lista principal de pedidos (pedido de Pablo, 28/9).
type FiltroPedidos = 'todos' | 'pendientes' | 'aprobados' | 'faltaFotos';
const FILTROS_PEDIDOS: { id: FiltroPedidos; etiqueta: string; ayuda: string }[] = [
  { id: 'todos', etiqueta: 'Todos', ayuda: 'Todos los pedidos activos' },
  { id: 'pendientes', etiqueta: 'Pendientes de pago', ayuda: 'Todavía no se confirmó el pago' },
  { id: 'aprobados', etiqueta: 'Aprobados', ayuda: 'Pago confirmado' },
  { id: 'faltaFotos', etiqueta: 'Falta elegir fotos', ayuda: 'Pagaron por adelantado y todavía no eligieron las fotos' },
];
function pedidoCumpleFiltro(p: PedidoEscolarCompleto, filtro: FiltroPedidos): boolean {
  switch (filtro) {
    case 'pendientes': return p.estadoPago !== 'aprobado' && p.estadoPago !== 'rechazado';
    case 'aprobados': return p.estadoPago === 'aprobado';
    case 'faltaFotos': return p.estadoPago === 'aprobado' && Boolean(p.seleccionPendiente);
    default: return true;
  }
}

interface AdminModalProps {
  isOpen: boolean;
  onClose: () => void;
  onProbarCodigo?: (codigo: string) => void;
  // Pestaña con la que abre el panel — usado por App.tsx para saltar directo a "Campaña Zoho"
  // cuando se vuelve del flujo de conexión OAuth (ver "?zoho=conectado" / "?zoho=error").
  tabInicial?: string;
}

const OPCIONES_GRADOS_COLEGIO = [
  'Sala 3 años', 'Sala 4 años', 'Sala 5 años',
  '1° grado', '2° grado', '3° grado', '4° grado', '5° grado', '6° grado', '7° grado',
  '1° año', '2° año', '3° año', '4° año', '5° año', '6° año',
];
const OPCIONES_DIVISIONES_COLEGIO = ['A', 'B', 'C', 'D', 'Jornada Extendida'];
const OPCIONES_TURNOS_COLEGIO = ['Mañana', 'Tarde', 'Jornada Extendida', 'Jornada Completa'];

interface SelectorMultipleProps {
  value: string;
  onChange: (nuevoValor: string) => void;
  opciones: string[];
  placeholderOtro?: string;
}

/** "28/09" en hora de Argentina (marcas de HD enviado / descargado en el listado de pedidos). */
function formatearDiaMes(iso: string): string {
  const fecha = new Date(iso);
  return Number.isNaN(fecha.getTime()) ? '' : fecha.toLocaleDateString('es-AR', { day: '2-digit', month: '2-digit', timeZone: 'America/Argentina/Buenos_Aires' });
}

/** "11/10 13:50" en hora de Argentina (vencimiento del plazo de la transferencia). */
function formatearDiaHora(iso: string): string {
  const fecha = new Date(iso);
  if (Number.isNaN(fecha.getTime())) return '';
  const partes = new Intl.DateTimeFormat('es-AR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit', hourCycle: 'h23', timeZone: 'America/Argentina/Buenos_Aires' }).formatToParts(fecha);
  const p = (tipo: string) => partes.find((x) => x.type === tipo)?.value || '';
  return `${p('day')}/${p('month')} ${p('hour')}:${p('minute')}`;
}

// Checkboxes para las opciones habituales + campo "Agregar otro" para valores personalizados.
// Mantiene el mismo formato de string separado por comas que usaba el textarea/input original,
// así que no requiere tocar el resto de la lógica de guardado/edición de colegios.
function SelectorMultiple({ value, onChange, opciones, placeholderOtro }: SelectorMultipleProps) {
  const [otroTexto, setOtroTexto] = useState('');
  const seleccionados = value.split(',').map((v) => v.trim()).filter(Boolean);
  const extras = seleccionados.filter((v) => !opciones.includes(v));

  const toggle = (op: string) => {
    if (seleccionados.includes(op)) {
      onChange(seleccionados.filter((v) => v !== op).join(', '));
    } else {
      onChange([...seleccionados, op].join(', '));
    }
  };

  const quitarExtra = (op: string) => {
    onChange(seleccionados.filter((v) => v !== op).join(', '));
  };

  const agregarOtro = () => {
    const limpio = otroTexto.trim();
    setOtroTexto('');
    if (!limpio || seleccionados.includes(limpio)) return;
    onChange([...seleccionados, limpio].join(', '));
  };

  return (
    <div className="space-y-2">
      <div className="flex flex-wrap gap-1.5">
        {opciones.map((op) => {
          const activo = seleccionados.includes(op);
          return (
            <label
              key={op}
              className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border text-[11px] font-semibold cursor-pointer select-none transition-colors ${
                activo
                  ? 'bg-amber-100 border-amber-400 text-amber-800'
                  : 'bg-white border-slate-300 text-slate-600 hover:border-slate-400'
              }`}
            >
              <input
                type="checkbox"
                checked={activo}
                onChange={() => toggle(op)}
                className="w-3.5 h-3.5 accent-amber-500 cursor-pointer"
              />
              {op}
            </label>
          );
        })}
        {extras.map((op) => (
          <span
            key={op}
            className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg border border-blue-300 bg-blue-50 text-blue-800 text-[11px] font-semibold"
          >
            {op}
            <button
              type="button"
              onClick={() => quitarExtra(op)}
              className="text-blue-400 hover:text-blue-700 cursor-pointer leading-none"
              title="Quitar"
            >
              ×
            </button>
          </span>
        ))}
      </div>
      <div className="flex gap-1.5">
        <input
          type="text"
          value={otroTexto}
          onChange={(e) => setOtroTexto(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === 'Enter') {
              e.preventDefault();
              agregarOtro();
            }
          }}
          placeholder={placeholderOtro || 'Agregar otro...'}
          className="flex-1 px-3 py-1.5 rounded-lg border border-slate-300 text-xs bg-white"
        />
        <button
          type="button"
          onClick={agregarOtro}
          className="px-3 py-1.5 rounded-lg border border-slate-300 bg-slate-100 hover:bg-slate-200 text-xs font-bold text-slate-700 cursor-pointer"
        >
          + Agregar
        </button>
      </div>
    </div>
  );
}

export default function AdminModal({ isOpen, onClose, onProbarCodigo, tabInicial }: AdminModalProps) {
  const [modoNoche, alternarModoNoche] = useModoNoche();
  // 28/9 (Pablo: "la web para el celular no está optimizada"): en celular las tablas del panel
  // se ven como tarjetas, con el nombre de cada columna arriba del dato (ver tablasMovil.ts).
  useEtiquetasTablasMovil();
  const navSeccionesRef = useRef<HTMLElement>(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [adminPin, setAdminPin] = useState('');
  const [pinError, setPinError] = useState('');
  const [isLoggingIn, setIsLoggingIn] = useState(false);

  // Check existing authenticated session on mount
  useEffect(() => {
    if (isOpen) {
      verificarSesionAdmin().then((valido) => {
        if (valido) {
          setIsAuthenticated(true);
        }
      });
    }
  }, [isOpen]);

  // Admin tabs - Inscriptos & Laboratorio as primary tools for photographers
  const [activeTab, setActiveTab] = useState<'inscriptos' | 'buscar-alumno' | 'padron' | 'liquidacion' | 'laboratorio' | 'pedidos' | 'subir' | 'codigos' | 'alumnos' | 'colegios' | 'cerrar-anio' | 'whatsapp' | 'solicitudes' | 'consultas' | 'estado-pagos' | 'importar-alumnos' | 'zoho' | 'cancelaciones' | 'precios' | 'observaciones' | 'faltantes' | 'descuentos' | 'emails' | 'configuracion'>(
    (tabInicial as any) || 'inscriptos'
  );
  // 28/9 (celular): la pestaña activa siempre a la vista en la tira de secciones.
  useEffect(() => {
    const activo = navSeccionesRef.current?.querySelector<HTMLElement>('[aria-pressed="true"]');
    if (activo && typeof activo.scrollIntoView === 'function') activo.scrollIntoView({ block: 'nearest', inline: 'center' });
  }, [activeTab, isAuthenticated]);
  // Nombre de alumno con el que arrancar la búsqueda al entrar a Laboratorio desde
  // "Ver en Laboratorio" en Pedidos — así el fotógrafo cae directo en el pedido que
  // estaba viendo, en vez de tener que buscarlo a mano entre todos (15/9).
  const [busquedaInicialLaboratorio, setBusquedaInicialLaboratorio] = useState('');

  // Auditoría 2026-09 (pedido de Pablo): en la pestaña "Nómina 2026", además de la barra
  // superior fija (pestañas + métricas + resumen de kits), también deben quedar fijos el
  // título "Nómina Escolar 2026" con sus botones, la fila de filtros (buscador + 2
  // desplegables) y el encabezado de columnas de la tabla — de forma que sólo el listado de
  // nombres (las filas de alumnos) se desplace por detrás. Como la altura de la barra superior
  // fija puede variar (carga async de datos, botones que se acomodan en pantallas chicas), se
  // mide su altura real con ResizeObserver y se usa como offset "top" dinámico para la segunda
  // franja fija, en vez de un valor fijo a mano que se rompería con cualquier cambio de layout.
  //
  // IMPORTANTE (corrección 2026-09-09): la franja fija de "Nómina 2026" (título + filtros +
  // encabezado de columnas) se arma como UNA sola franja "sticky" (igual que la barra superior),
  // en vez de anidar una segunda franja fija dentro de otra. El encabezado de columnas de la
  // tabla ("Apellido y Nombre", "Grado", etc.) vive ahora en una tabla aparte SOLO con ese
  // encabezado, dentro de esta misma franja — y NO dentro del contenedor con scroll horizontal
  // de la tabla de filas, porque ese contenedor (overflow-x-auto) hace que el navegador rompa el
  // "sticky" del <thead> (al fijar overflow-x, el navegador fuerza overflow-y a comportarse
  // como "auto" también, y el <thead> termina pegándose contra ESE contenedor en vez de contra
  // el verdadero contenedor con scroll de la pantalla, apareciendo flotando en cualquier lugar
  // de la lista). La tabla con las filas de alumnos (tbody) usa las mismas columnas con ancho
  // fijo en porcentaje (colgroup + table-fixed) para que quede perfectamente alineada con el
  // encabezado de arriba, sin necesitar una tercera franja fija ni un tercer cálculo de offset.
    const observadorBarraSuperiorRef = useRef<ResizeObserver | null>(null);
    const [alturaBarraSuperior, setAlturaBarraSuperior] = useState(0);

    const barraSuperiorRef = useCallback((el: HTMLDivElement | null) => {
          if (observadorBarraSuperiorRef.current) {
                  observadorBarraSuperiorRef.current.disconnect();
                  observadorBarraSuperiorRef.current = null;
          }
          if (el) {
                  // Corrección 2026-09-15 (pedido de Pablo: "queda tapada información, botones y
                  // textos" en Nómina 2026): `entry.contentRect.height` mide sólo el content-box
                  // (SIN el padding ni el borde inferior de la barra), así que este offset
                  // quedaba unos px más chico que la altura real con la que la barra se renderiza
                  // — la segunda franja fija (título + filtros de Nómina) terminaba pegándose un
                  // poco más arriba de lo debido y su parte de arriba quedaba tapada detrás del
                  // borde inferior de la barra superior. `getBoundingClientRect().height` da la
                  // altura real renderizada (content + padding + borde), que es la que hace falta acá.
                  const observer = new ResizeObserver((entries) => {
                            for (const entry of entries) {
                                        setAlturaBarraSuperior(entry.target.getBoundingClientRect().height);
                            }
                  });
                  observer.observe(el);
                  observadorBarraSuperiorRef.current = observer;
          }
    }, []);

  // Real synced orders for photo lab and families
  const [pedidosCompletos, setPedidosCompletos] = useState<PedidoEscolarCompleto[]>(() => obtenerPedidosGuardados());
  // Id del pedido que se está eliminando (para deshabilitar el botón mientras se procesa)
  const [eliminandoPedidoId, setEliminandoPedidoId] = useState<string | null>(null);
  // Pedido de Pablo (25/9): los archivados no se muestran salvo que se pida verlos.
  const [verArchivados, setVerArchivados] = useState(false);
  // Pedidos cancelados (intentos de pago abandonados / reservas reemplazadas): ocultos por defecto.
  const [verCancelados, setVerCancelados] = useState(false);
  // 10/10 (pedido de Pablo): transferencias que se cancelaron solas porque el comprobante no llegó en
  // 48 h. No se pierden: van a esta lista aparte, para aprobarlas (si la plata entró) o reabrirles el plazo.
  const [verVencidos, setVerVencidos] = useState(false);
  const [reabriendoPedidoId, setReabriendoPedidoId] = useState<string | null>(null);
  // Pedido de Pablo (28/9): lista aparte para los pedidos ya entregados (ver pedidoEstaEntregado).
  const [verEntregados, setVerEntregados] = useState(false);
  // Pedido de Pablo (28/9): filtros rápidos sobre la lista principal (sin esconder los aprobados).
  const [filtroPedidos, setFiltroPedidos] = useState<FiltroPedidos>('todos');
  const [organizandoPedidoId, setOrganizandoPedidoId] = useState<string | null>(null);
  // Pedido 2026-09-21 de Pablo: "no tengo la opción de seleccionar varios pedidos para archivar o
  // eliminar" — antes sólo existía borrar de a uno. Estos dos estados habilitan selección múltiple
  // con checkboxes en la tabla de "Pedidos" y un botón para eliminarlos todos juntos, reusando el
  // mismo endpoint de borrado (uno por uno, en secuencia) porque el servidor no tiene un endpoint
  // de borrado masivo.
  // Con el panel abierto, un reporte de error se marca como del panel e incluye la pestaña.
  useEffect(() => {
    registrarContextoDeError('panelAdmin', { pestaña: activeTab });
    return () => registrarContextoDeError('panelAdmin', null);
  }, [activeTab]);
  const firmaPedidosResumen = useMemo(
    () => pedidosCompletos.map((p) => `${p.id}:${p.estadoPago}`).sort().join('|'),
    [pedidosCompletos]
  );
  const [pedidosSeleccionados, setPedidosSeleccionados] = useState<Set<string>>(new Set());
  const [eliminandoSeleccionados, setEliminandoSeleccionados] = useState(false);

  // Auditoría 2026-09-09 (revisión a fondo): antes esta lista salía únicamente del localStorage
  // del navegador — abrir el panel desde otra computadora mostraba "0 pedidos" aunque hubiera
  // pedidos reales y pagados en Supabase. Ahora se trae la lista real del servidor y se combina
  // con lo que haya en este navegador (por si algún pedido recién creado todavía no se refleja
  // en una lectura posterior); Supabase manda como fuente de la verdad.
  // Auditoría 03/10 (alto 16): si el servidor no responde, el panel muestra la copia guardada en
  // este navegador — antes en silencio; ahora con un aviso visible y la fecha de esa copia.
  const [avisoSinConexion, setAvisoSinConexion] = useState<string | null>(null);
  // Auditoría 11/10 (ADM-2): sólo se aplica la última recarga pedida (una vieja que llega tarde no pisa nada).
  const idSyncRef = useRef(0);
  const sincronizarPedidosDesdeSupabase = async () => {
    const mio = ++idSyncRef.current;
    const [pedidosServidor, pedidosLocales] = [await obtenerPedidosAdminDesdeSupabase(), obtenerPedidosGuardados()];
    if (mio !== idSyncRef.current) return;
    // Auditoría 11/10 (ADM-3): sesión vencida (401) no es "sin conexión": se vuelve al PIN.
    if (pedidosServidor === SESION_ADMIN_VENCIDA) {
      cerrarSesionAdminYBorrarDatos();
      setPedidosCompletos([]);
      setAvisoSinConexion(null);
      setIsAuthenticated(false);
      setPinError('Tu sesión venció: volvé a entrar con el PIN.');
      return;
    }
    if (pedidosServidor === null) {
      const fecha = obtenerFechaUltimaSincronizacion();
      const fechaTexto = fecha ? new Date(fecha).toLocaleString('es-AR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' }) : 'fecha desconocida';
      setAvisoSinConexion(`Sin conexión: mostrando datos guardados del ${fechaTexto}. Los pedidos pueden estar desactualizados.`);
    } else {
      setAvisoSinConexion(null);
    }
    // Auditoría 03/10 noche: si se cerró la sesión mientras se traían los pedidos, no se vuelve a
    // guardar la lista de familias en el navegador (cerrar sesión la borra a propósito).
    if (!obtenerTokenAdmin()) return;
    const combinados = combinarPedidosConLocal(pedidosServidor, pedidosLocales);
    setPedidosCompletos(combinados);
    guardarPedidosEnStorage(combinados);
  };

  // Aprueba UN pedido puntual (marca "pagado" en el servidor, genera el .zip HD y manda el email
  // con el link a la familia). Extraída del onClick de "Aprobar Pago" para poder reusarla también
  // sobre los hermanos de un mismo pago combinado (ver handleAprobarPago más abajo).
  const aprobarPagoPedido = async (pedido: PedidoEscolarCompleto) => {
    const fechaHora = `${new Date().toLocaleDateString('es-AR')} ${new Date().toLocaleTimeString('es-AR', { hour: '2-digit', minute: '2-digit' })}`;
    // 23/09 (ALTO): estadoPago/estadoEntrega se marcan optimistamente pero se REVIERTEN si el servidor no confirma;
    // emailEnviado/fecha/link sólo después de que el email devolvió success. 14/10: ante un corte, el servicio
    // relee el pedido antes de dar «no se pudo» (confirmadoAlReleer) y avisa aparte si venció la sesión.
    setPedidosCompletos((prev) => {
      const actualizados = prev.map(item =>
        item.id === pedido.id
          ? { ...item, estadoPago: 'aprobado' as const, estadoEntrega: 'laboratorio_listo' as const }
          : item
      );
      guardarPedidosEnStorage(actualizados);
      return actualizados;
    });

    // Sincronizar con el servidor y Supabase mediante token admin. Auditoría 2026-09-18 (reporte
    // de Pablo): esta llamada no se esperaba (fire-and-forget) y el email se mandaba enseguida
    // con "pedido.linkDescargaHD", que en un pedido recién aprobado a mano todavía está vacío —
    // el servidor ahora genera el .zip HD automáticamente al marcar "pagado" y devuelve el link
    // en la respuesta, así que hay que esperarla y usar ese link para el email.
    let linkDescargaHDGenerado: string | undefined;
    let estadoConfirmadoPorServidor = false;
    // Auditoría 03/10: el servidor ahora rechaza (409) aprobar un pedido cancelado definitivamente
    // o uno que ya cambió de estado. En esos casos el aviso es específico (no "revisá tu conexión").
    let avisoYaMostrado = false;
    let recargarLista = false;
    try {
      let resultadoEstado = await actualizarEstadoPedidoAdmin(pedido.supabaseId || pedido.id, {
        estadoPago: 'aprobado',
        estadoEntrega: 'laboratorio_listo',
      });
      if (!resultadoEstado.success && resultadoEstado.codigo === 'CANCELADO_DEFINITIVO') {
        const reactivar = window.confirm(
          `El pedido de ${pedido.alumnoNombre} fue cancelado definitivamente (arrepentimiento/reembolso). ¿Reactivarlo igual?`
        );
        if (reactivar) {
          resultadoEstado = await actualizarEstadoPedidoAdmin(pedido.supabaseId || pedido.id, {
            estadoPago: 'aprobado',
            estadoEntrega: 'laboratorio_listo',
            reactivar: true,
          });
        } else {
          avisoYaMostrado = true;
        }
      }
      // 08/10: reactivar una mejora a Kit Impreso cuando el kit ya tiene otra activa (la base no lo permite).
      if (!resultadoEstado.success && resultadoEstado.codigo === 'MEJORA_DUPLICADA') {
        window.alert(resultadoEstado.error || `El kit de ${pedido.alumnoNombre} ya tiene otra mejora a Kit Impreso activa.`);
        avisoYaMostrado = true;
        recargarLista = true;
      }
      if (!resultadoEstado.success && resultadoEstado.codigo === 'ESTADO_CAMBIO') {
        window.alert(resultadoEstado.error || `El pedido de ${pedido.alumnoNombre} ya cambió de estado. Se recarga la lista.`);
        avisoYaMostrado = true;
        recargarLista = true;
      }
      // Auditoría 2026-09-23: antes no se miraba `resultadoEstado.success` — un fallo del servidor
      // que responde sin tirar excepción (401 por token vencido, 500, etc.) pasaba desapercibido y
      // el flujo seguía como si el pedido sí se hubiera marcado "aprobado" del lado real.
      if (resultadoEstado.success) {
        estadoConfirmadoPorServidor = true;
        linkDescargaHDGenerado = resultadoEstado.linkDescargaHD;
        if (linkDescargaHDGenerado) {
          // Auditoría 2026-09-19 (encontrada en revisión de código): usar siempre la forma
          // funcional de setState (prev => ...) acá, nunca un array capturado por closure — al
          // aprobar varios hermanos en secuencia (ver handleAprobarPago), un array viejo pisaría
          // el "aprobado" que ya haya quedado puesto por una llamada anterior de este mismo bucle.
          setPedidosCompletos((prev) => {
            const conLink = prev.map(item =>
              item.id === pedido.id ? { ...item, linkDescargaHD: linkDescargaHDGenerado } : item
            );
            guardarPedidosEnStorage(conLink);
            return conLink;
          });
        }
      } else {
        console.warn('El servidor no confirmó la aprobación del pago:', resultadoEstado.error);
        if (resultadoEstado.codigo === 'SESION_VENCIDA') { window.alert(resultadoEstado.error); avisoYaMostrado = true; }
      }
    } catch (e) {
      console.warn('Error al sincronizar estado con backend:', e);
    }

    if (!estadoConfirmadoPorServidor) {
      // Revertir la marca optimista: el servidor nunca confirmó, así que no podemos dejar el
      // panel mostrando "Aprobado" — eso llevaría a Pablo a pensar que ya está cobrado/listo
      // cuando en Supabase sigue "pendiente".
      setPedidosCompletos((prev) => {
        const revertidos = prev.map(item =>
          item.id === pedido.id
            ? { ...item, estadoPago: pedido.estadoPago, estadoEntrega: pedido.estadoEntrega }
            : item
        );
        guardarPedidosEnStorage(revertidos);
        return revertidos;
      });
      if (!avisoYaMostrado) {
        window.alert(
          `No se pudo confirmar la aprobación del pago de ${pedido.alumnoNombre} en el servidor. No se envió ningún email. Revisá tu conexión o volvé a intentarlo.`
        );
      }
      if (recargarLista) await sincronizarPedidosDesdeSupabase();
      return;
    }

    // Kit pagado por adelantado (fotos todavía sin elegir): el servidor ya le mandó a la familia
    // la confirmación de la reserva; el correo de fotos HD sale recién cuando elija sus fotos.
    if (pedido.seleccionPendiente) return;

    if (pedido.tutorEmail && pedido.tutorEmail.includes('@')) {
      try {
        const resultadoEmail = await enviarFotosPorEmail({
          to: pedido.tutorEmail,
          tutorNombre: pedido.tutorNombre,
          alumnoNombre: pedido.alumnoNombre,
          colegioNombre: pedido.colegioNombre,
          cursoCodigo: pedido.cursoCodigo,
          pedidoId: pedido.id,
          // Auditoría 2026-09-20 (revisión completa de estados): este llamado (aprobar un pago en
          // efectivo/transferencia a mano) era el tercer lugar que mandaba el correo HD sin el
          // UUID real — sin esto, el servidor no podía grabar el resultado del envío para estos
          // pedidos tampoco.
          pedidoSupabaseId: pedido.supabaseId,
          kitNombre: pedido.kitNombre,
          total: pedido.total,
          linkDescargaHD: linkDescargaHDGenerado || pedido.linkDescargaHD,
          esImpreso: pedido.kitId === 'kit-clasico',
        });
        if (resultadoEmail.success) {
          setPedidosCompletos((prev) => {
            const conEmail = prev.map(item =>
              item.id === pedido.id ? { ...item, emailEnviado: true, fechaEnvioEmail: fechaHora } : item
            );
            guardarPedidosEnStorage(conEmail);
            return conEmail;
          });
        } else {
          console.warn('El envío del email al aprobar el pago no fue exitoso:', resultadoEmail.error);
          window.alert(
            `El pago de ${pedido.alumnoNombre} quedó aprobado, pero el email con las fotos no se pudo enviar (${resultadoEmail.error || 'error desconocido'}). Podés reintentarlo desde Laboratorio.`
          );
        }
      } catch (e) {
        console.error('Error enviando email al aprobar pago:', e);
        window.alert(
          `El pago de ${pedido.alumnoNombre} quedó aprobado, pero el email con las fotos no se pudo enviar. Podés reintentarlo desde Laboratorio.`
        );
      }
    }
  };

  // Auditoría 2026-09-23 (Pablo: "¿por qué se generaron 2 pedidos si es uno solo?"): un carrito
  // multi-hijo (mellizos, por ejemplo) genera un pedido por hermano pero los cobra juntos en un
  // solo pago (mismo grupoPagoId). El pago automático (Mercado Pago/Nave) ya aprueba a todo el
  // grupo de una sola vez — pero este botón, pensado sobre todo para efectivo/transferencia,
  // hasta ahora solo conocía la fila en la que se hacía click: si Pablo aprobaba un solo hermano
  // de un pago combinado, el otro quedaba "Pendiente" para siempre aunque ya se hubiera cobrado
  // junto con el primero. Ahora, al aprobar un pedido que comparte grupoPagoId con otros todavía
  // pendientes, se aprueban también en la misma acción — cada uno con su propio .zip HD y su
  // propio email (mismo criterio que ya usa el pago automático: "un carrito multi-hijo, cada hijo
  // recibe su propia confirmación con sus propios datos, aunque el pago haya sido uno solo").
  const handleVerComprobante = async (pedido: PedidoEscolarCompleto) => {
    // La pestaña se abre ANTES del await: si no, el navegador la bloquea como ventana emergente.
    const ventana = window.open('', '_blank');
    const res = await obtenerLinkComprobanteAdmin(pedido.supabaseId || pedido.id);
    if (res.success && res.url) {
      if (ventana) ventana.location.href = res.url;
      else window.location.href = res.url;
    } else {
      ventana?.close();
      window.alert(res.error || 'No se pudo abrir el comprobante.');
    }
  };

  const handleAprobarPago = async (pedido: PedidoEscolarCompleto) => {
    if (pedido.metodoPago === 'transferencia' && !pedido.comprobanteSubidoAt) {
      const seguir = window.confirm(
        'Esta familia todavía no subió el comprobante de la transferencia.\n\n¿Verificaste en el banco que el dinero está acreditado y querés aprobar el pago igual?'
      );
      if (!seguir) return;
    }
    const hermanosPendientes = pedido.grupoPagoId
      ? pedidosCompletos.filter(
          // "rechazado" también: un intento de pago con tarjeta que rebotó antes de pagar en efectivo.
          // Menos las reservas canceladas porque se reemplazaron por otra (nunca se cobran). 10/10: una
          // reserva que se canceló por vencer el plazo de la transferencia sí se aprueba con su grupo.
          (item) => item.grupoPagoId === pedido.grupoPagoId && item.id !== pedido.id && item.estadoPago !== 'aprobado'
            && !(item.estadoPago === 'rechazado' && item.seleccionPendiente && !item.transferenciaVencidaAt)
        )
      : [];
    await aprobarPagoPedido(pedido);
    for (const hermano of hermanosPendientes) {
      await aprobarPagoPedido(hermano);
    }
    // Auditoría 11/10 (ADM-2): recarga nueva al terminar; descarta cualquier recarga vieja en vuelo.
    await sincronizarPedidosDesdeSupabase();
  };

  // 10/10 (pedido de Pablo): un pedido vencido sin comprobante vuelve a "Pendiente de pago" con un plazo
  // nuevo de 48 h (y su último aviso antes de vencer), junto con los hermanos del mismo pago. Sirve
  // cuando la familia necesita más tiempo para transferir o para subir el comprobante.
  const handleReabrirPlazo = async (pedido: PedidoEscolarCompleto) => {
    const delPago = pedido.grupoPagoId
      ? pedidosCompletos.filter((item) => item.grupoPagoId === pedido.grupoPagoId && pedidoVencidoRecuperable(item))
      : [pedido];
    const nombres = delPago.map((item) => item.alumnoNombre).join(', ');
    const confirmado = window.confirm(
      `¿Reabrir el pedido de ${nombres}?\n\nVuelve a "Pendiente de pago" con un plazo nuevo de 48 h para subir el comprobante (antes de que venza le llega el último aviso). Avisale a la familia que ya lo puede subir desde el mismo link.`
    );
    if (!confirmado) return;
    setReabriendoPedidoId(pedido.id);
    const errores: string[] = [];
    try {
      for (const item of delPago) {
        const resultado = await actualizarEstadoPedidoAdmin(item.supabaseId || item.id, { estadoPago: 'pendiente', estadoAnterior: 'cancelado' });
        if (!resultado.success) errores.push(`${item.alumnoNombre}: ${resultado.error || 'no se pudo reabrir'}`);
      }
      await sincronizarPedidosDesdeSupabase();
    } finally {
      setReabriendoPedidoId(null);
    }
    if (errores.length > 0) window.alert(`No se pudo reabrir todo:\n\n${errores.join('\n')}`);
  };

  const handleEliminarPedido = async (pedido: PedidoEscolarCompleto) => {
    const confirmado = window.confirm(
      `¿Eliminar el pedido ${pedido.id} de ${pedido.alumnoNombre}?\n\nEsta acción no se puede deshacer.`
    );
    if (!confirmado) return;

    setEliminandoPedidoId(pedido.id);
    try {
      let resultado = await eliminarPedidoAdminConControl(pedido.supabaseId || pedido.id);
      // Auditoría 05/10: el servidor frena el borrado de un pedido pagado/entregado (409
      // PEDIDO_PAGADO). Recién con esta confirmación específica se reintenta con `forzar`.
      if (!resultado.success && resultado.codigo === 'PEDIDO_PAGADO') {
        const forzarBorrado = window.confirm(
          `Este pedido está PAGADO (${resultado.pedidoFriendlyId || pedido.id}).\n\nSi lo borrás, la familia pierde la descarga HD y el pedido desaparece del laboratorio y de la liquidación.\n\n¿Borrar igual?`
        );
        if (!forzarBorrado) return;
        resultado = await eliminarPedidoAdminConControl(pedido.supabaseId || pedido.id, true);
      }
      if (!resultado.success) {
        window.alert(resultado.error || 'No se pudo eliminar el pedido.');
        return;
      }
      // Auditoría 2026-09-22: antes filtraba sobre `pedidosCompletos` capturado por clausura al
      // momento del render, no sobre el estado más reciente. Si dos borrados (o un borrado y otra
      // actualización de `pedidosCompletos`, como aprobar un pago) se disparan casi al mismo
      // tiempo, el `setPedidosCompletos` que resuelve último podía pisar el resultado del otro y
      // "resucitar" en pantalla un pedido que ya se borró en el servidor. Se usa la forma
      // funcional de setState, igual que en el resto del archivo, para operar siempre sobre el
      // estado más reciente.
      setPedidosCompletos((prev) => {
        const actualizados = prev.filter((item) => item.id !== pedido.id);
        guardarPedidosEnStorage(actualizados);
        return actualizados;
      });
      setPedidosSeleccionados((prev) => {
        if (!prev.has(pedido.id)) return prev;
        const siguiente = new Set(prev);
        siguiente.delete(pedido.id);
        return siguiente;
      });
    } catch (e: any) {
      window.alert(e?.message || 'Error de red al eliminar el pedido.');
    } finally {
      setEliminandoPedidoId(null);
    }
  };

  const toggleSeleccionPedido = (id: string) => {
    setPedidosSeleccionados((prev) => {
      const siguiente = new Set(prev);
      if (siguiente.has(id)) {
        siguiente.delete(id);
      } else {
        siguiente.add(id);
      }
      return siguiente;
    });
  };

  const enListaPrincipal = !verCancelados && !verArchivados && !verEntregados && !verVencidos;
  const pedidosVisiblesTabla = useMemo(
    () => pedidosCompletos.filter((p) =>
      verVencidos
        ? pedidoVencidoRecuperable(p)
        : verCancelados
        ? p.estadoPago === 'rechazado' && !p.archivado && !pedidoVencidoRecuperable(p)
        : verArchivados
          ? Boolean(p.archivado) // 11/10 (ADM-4): también los cancelados/vencidos archivados (si no, no se veían en ninguna lista)
          : !p.archivado && p.estadoPago !== 'rechazado' && pedidoEstaEntregado(p) === verEntregados
            // Los filtros rápidos sólo se aplican a la lista principal.
            && (verEntregados || pedidoCumpleFiltro(p, filtroPedidos))
    ),
    [pedidosCompletos, verArchivados, verCancelados, verEntregados, verVencidos, filtroPedidos]
  );
  // Cantidades de cada filtro, siempre sobre la lista principal completa.
  const conteoFiltrosPedidos = useMemo(() => {
    const principal = pedidosCompletos.filter((p) => !p.archivado && p.estadoPago !== 'rechazado' && !pedidoEstaEntregado(p));
    return Object.fromEntries(
      FILTROS_PEDIDOS.map(({ id }) => [id, principal.filter((p) => pedidoCumpleFiltro(p, id)).length])
    ) as Record<FiltroPedidos, number>;
  }, [pedidosCompletos]);
  const cantidadEntregados = pedidosCompletos.filter((p) => !p.archivado && pedidoEstaEntregado(p)).length;
  const cantidadCancelados = pedidosCompletos.filter((p) => p.estadoPago === 'rechazado' && !p.archivado && !pedidoVencidoRecuperable(p)).length;
  const cantidadVencidos = pedidosCompletos.filter((p) => pedidoVencidoRecuperable(p)).length;
  const cantidadArchivados = pedidosCompletos.length - pedidosCompletos.filter((p) => !p.archivado).length;

  // Sólo se seleccionan los pedidos visibles: "Eliminar seleccionados" nunca debe alcanzar a los
  // archivados que están ocultos.
  const toggleSeleccionarTodosPedidos = () => {
    setPedidosSeleccionados((prev) =>
      prev.size === pedidosVisiblesTabla.length ? new Set<string>() : new Set(pedidosVisiblesTabla.map((p) => p.id))
    );
  };

  const handleOrganizarPedido = async (pedido: PedidoEscolarCompleto, cambios: { archivado?: boolean; enEspera?: boolean }) => {
    if (!pedido.supabaseId) return window.alert('Este pedido no está registrado en el servidor.');
    let notaEspera: string | undefined;
    if (cambios.enEspera === true) {
      const nota = window.prompt(`Poner en espera el pedido de ${pedido.alumnoNombre}.\n\nNota opcional (ej: "esperando comprobante", "reclamo de la familia"):`, pedido.notaEspera || '');
      if (nota === null) return;
      notaEspera = nota;
    }
    if (cambios.archivado === true && !window.confirm(`¿Archivar el pedido ${pedido.id} de ${pedido.alumnoNombre}?\n\nSale de las listas pero no se borra: lo encontrás en "Ver archivados".`)) return;
    setOrganizandoPedidoId(pedido.id);
    const resultado = await organizarPedidoAdmin(pedido.supabaseId, { ...cambios, notaEspera });
    setOrganizandoPedidoId(null);
    if (!resultado.success) return window.alert(resultado.error || 'No se pudo actualizar el pedido.');
    setPedidosCompletos((prev) => {
      const actualizados = prev.map((item) => item.id === pedido.id
        ? { ...item, archivado: Boolean(resultado.archivado), enEspera: Boolean(resultado.enEspera), notaEspera: resultado.notaEspera || '' }
        : item);
      guardarPedidosEnStorage(actualizados);
      return actualizados;
    });
    setPedidosSeleccionados((prev) => {
      if (!prev.has(pedido.id)) return prev;
      const siguiente = new Set(prev);
      siguiente.delete(pedido.id);
      return siguiente;
    });
  };

  const handleEliminarSeleccionados = async () => {
    const ids: string[] = Array.from(pedidosSeleccionados);
    if (ids.length === 0) return;

    // Auditoría 05/10: en bloque nunca se borran los pagados (el servidor también los frena con
    // PEDIDO_PAGADO); se los saltea y se avisa cuántos quedaron. Para borrar uno pagado hay que
    // hacerlo de a uno, con su confirmación específica.
    const pagadosSalteados = ids.filter((id) => pedidosCompletos.find((item) => item.id === id)?.estadoPago === 'aprobado');
    const idsABorrar = ids.filter((id) => !pagadosSalteados.includes(id));
    if (idsABorrar.length === 0) {
      window.alert(`Los ${ids.length} pedidos seleccionados están pagados: no se borran en bloque. Para borrar uno pagado, hacelo de a uno desde su fila.`);
      return;
    }
    const avisoPagados = pagadosSalteados.length > 0
      ? `\n\nSe van a saltear ${pagadosSalteados.length} pedido${pagadosSalteados.length === 1 ? '' : 's'} pagado${pagadosSalteados.length === 1 ? '' : 's'} (no se borran en bloque).`
      : '';
    const confirmado = window.confirm(
      `¿Eliminar ${idsABorrar.length} pedido${idsABorrar.length === 1 ? '' : 's'} seleccionado${idsABorrar.length === 1 ? '' : 's'}?${avisoPagados}\n\nEsta acción no se puede deshacer.`
    );
    if (!confirmado) return;

    setEliminandoSeleccionados(true);
    const idsBorrados: string[] = [];
    const idsConError: string[] = [];
    let salteadosPorServidor = 0;

    // Se borra de a uno, en secuencia (no en paralelo): el servidor no tiene un endpoint de
    // borrado masivo, y mandar todas las llamadas DELETE juntas podría saturar el token admin
    // o, si una falla a mitad de camino, dejar difícil de saber cuáles sí se borraron.
    for (const id of idsABorrar) {
      const pedido = pedidosCompletos.find((item) => item.id === id);
      if (!pedido) continue;
      try {
        const resultado = await eliminarPedidoAdminConControl(pedido.supabaseId || pedido.id);
        if (resultado.success) {
          idsBorrados.push(id);
        } else if (resultado.codigo === 'PEDIDO_PAGADO') {
          salteadosPorServidor += 1;
        } else {
          idsConError.push(id);
        }
      } catch {
        idsConError.push(id);
      }
    }

    if (idsBorrados.length > 0) {
      // Auditoría 2026-09-22: mismo fix que en handleEliminarPedido — usar la forma funcional de
      // setState para no pisar cambios concurrentes de `pedidosCompletos`.
      setPedidosCompletos((prev) => {
        const actualizados = prev.filter((item) => !idsBorrados.includes(item.id));
        guardarPedidosEnStorage(actualizados);
        return actualizados;
      });
    }
    setPedidosSeleccionados(new Set());
    setEliminandoSeleccionados(false);

    const totalSalteados = pagadosSalteados.length + salteadosPorServidor;
    if (idsConError.length > 0 || totalSalteados > 0) {
      const partes = [`Se eliminaron ${idsBorrados.length} de ${ids.length} pedidos.`];
      if (totalSalteados > 0) partes.push(`${totalSalteados} pagado${totalSalteados === 1 ? '' : 's'} se saltearon (no se borran en bloque).`);
      if (idsConError.length > 0) partes.push(`${idsConError.length} no se pudieron eliminar (probá de nuevo con esos).`);
      window.alert(partes.join(' '));
    }
  };

  // Pending inscriptions count
  const [pendientesInscripcionCount, setPendientesInscripcionCount] = useState<number>(0);
  // Pending "no encuentro mi código" requests count
  const [pendientesSolicitudesCodigoCount, setPendientesSolicitudesCodigoCount] = useState<number>(0);

  // Schools list state from dynamic persistent service (Supabase, compartido para todo el sitio)
  const { colegios: colegiosList, agregarColegio, editarColegio, borrarColegio } = useColegiosLista();

  useEffect(() => {
    if (isOpen && isAuthenticated) {
      setPedidosCompletos(obtenerPedidosGuardados());
      sincronizarPedidosDesdeSupabase();
      obtenerInscripcionesAdmin().then((inscriptos) => {
        setPendientesInscripcionCount(inscriptos.filter((i) => i.estado === 'pendiente').length);
      });
      obtenerSolicitudesCodigoAdmin('pendiente').then((solicitudes) => {
        setPendientesSolicitudesCodigoCount(solicitudes.length);
      });
    }
  }, [isOpen, isAuthenticated, activeTab]);

  // Links secretos de carga de padrón por colegio (solo se piden cuando hacen falta)
  const [padronTokens, setPadronTokens] = useState<Record<string, string>>({});
  const [copiadoPadronId, setCopiadoPadronId] = useState<string | null>(null);
  const [regenerandoPadronId, setRegenerandoPadronId] = useState<string | null>(null);

  useEffect(() => {
    if (isOpen && isAuthenticated && activeTab === 'colegios') {
      obtenerTokensPadronAdmin().then(setPadronTokens);
    }
  }, [isOpen, isAuthenticated, activeTab]);

  // WhatsApp configuration state (persistent in Supabase 'configuracion' & localStorage)
  // 14/10/2026: arranca vacío y se llena con el número del servidor; la copia de este navegador sólo si el servidor no responde.
  const [whatsappNumero, setWhatsappNumero] = useState<string>('');
  const [whatsappGuardando, setWhatsappGuardando] = useState(false);
  const [whatsappFeedback, setWhatsappFeedback] = useState<string | null>(null);
  const [whatsappError, setWhatsappError] = useState<string | null>(null);

  // Synchronize on mount and listen to global updates
  useEffect(() => {
    const handleConfigActualizada = (e: any) => {
      const cfg = e.detail as ConfiguracionWhatsApp;
      if (cfg?.whatsappFlotante) {
        setWhatsappNumero(cfg.whatsappFlotante);
      }
    };
    window.addEventListener('whatsapp_config_actualizada', handleConfigActualizada);
    void sincronizarDesdeSupabase().then((cfg) => { if (!cfg) { const local = obtenerConfiguracionWhatsApp(); setWhatsappNumero((n) => n || local.whatsappFlotante || local.whatsappSolicitudCodigo || ''); } }); // FRO-10
    return () => {
      window.removeEventListener('whatsapp_config_actualizada', handleConfigActualizada);
    };
  }, []);

  const handleGuardarWhatsApp = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setWhatsappGuardando(true);
    setWhatsappFeedback(null);
    setWhatsappError(null);

    const limpio = sanitizarNumeroWhatsApp(whatsappNumero);
    if (!limpio) {
      setWhatsappError('Por favor, ingresá un número de WhatsApp válido con código de país.');
      setWhatsappGuardando(false);
      return;
    }

    try {
      // Auditoría 2026-09-09: acá había un segundo camino que escribía directo a la tabla
      // 'configuracion' con la clave anónima del navegador (además del que ya hacía
      // guardarNumeroWhatsAppFlotante más abajo) — dependía de una política de RLS que en los
      // hechos permitía escribir a cualquiera sin login, que es justo el agujero que se cerró.
      // Se saca este camino duplicado: guardarNumeroWhatsAppFlotante ya guarda en Supabase de
      // forma correcta, pasando por el servidor con sesión de admin.
      const resultado = await guardarNumeroWhatsAppFlotante(limpio);
      setWhatsappNumero(limpio);
      // 14/10/2026 (auditoría): si el servidor no lo guardó, las familias no lo ven: es un error (como en AdminConfigWhatsAppTab).
      if (!resultado.supabaseOk) {
        setWhatsappError(`No se pudo guardar en el servidor: ${resultado.errorSupabase || 'error desconocido'}. Sólo quedó en este navegador; las familias no lo ven. Probá de nuevo.`);
        return;
      }
      setWhatsappFeedback(`¡Número ${formatearNumeroVisual(limpio)} guardado y persistido con éxito en Supabase!`);

      setTimeout(() => {
        setWhatsappFeedback(null);
      }, 5000);
    } catch (err: any) {
      setWhatsappError(`Error al guardar en Supabase: ${err?.message || 'Error inesperado'}`);
    } finally {
      setWhatsappGuardando(false);
    }
  };

  // Nómina real del padrón (tabla 'alumnos' de Supabase) — se carga temprano porque tanto la
  // pestaña de Nómina como la de Códigos & Difusión (más abajo) la necesitan.
  const [alumnosNominaReal, setAlumnosNominaReal] = useState<AlumnoNominaReal[]>([]);
  const [cargandoNominaReal, setCargandoNominaReal] = useState(false);
  const { abrirCambioCurso, modalCambioCurso } = useCambioCursoNomina(alumnosNominaReal, setAlumnosNominaReal); // 13/10: «Curso» en la Nómina
  const { observacionesDe, abrirObservaciones, modalObservaciones, errorObservaciones } = useObservacionesNomina(alumnosNominaReal); // 14/10: notas por alumno

  const cargarNominaReal = async () => {
    setCargandoNominaReal(true);
    try {
      const data = await obtenerAlumnosNominaAdmin();
      setAlumnosNominaReal(data);
    } finally {
      setCargandoNominaReal(false);
    }
  };

  useEffect(() => {
    if (isAuthenticated) {
      cargarNominaReal();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isAuthenticated]);

  // Códigos & Difusión WhatsApp — auditoría 2026-09-09: esta pestaña mostraba códigos
  // inventados y guardados solo en el navegador (localStorage, ver antiguo
  // src/data/codigosCursos.ts), sin ninguna relación con los códigos REALES que
  // /api/fotos exige para dejar entrar a una familia (tabla `codigos_seccion`). Un
  // colegio podía terminar recibiendo por WhatsApp un código que nunca iba a funcionar
  // en el sitio. Ahora esta pestaña lee y escribe directamente esos códigos reales
  // (ver services/codigosSeccionService.ts) y es específica por colegio, igual que la
  // pestaña de Nómina y la de Carga de Fotos.
  const [copiadoFeedback, setCopiadoFeedback] = useState<string | null>(null);
  const [filtroSalaCodigos, setFiltroSalaCodigos] = useState<string>('todas');
  const [colegioIdCodigos, setColegioIdCodigos] = useState<string>(() => colegiosList[0]?.id || '');
  const [codigosRealesMap, setCodigosRealesMap] = useState<Record<string, string>>({});
  const [cargandoCodigosReales, setCargandoCodigosReales] = useState(false);
  const [guardandoCodigoId, setGuardandoCodigoId] = useState<string | null>(null);
  const [errorCodigos, setErrorCodigos] = useState<string | null>(null);

  const handleCopiarTexto = (texto: string, label: string) => {
    void copiarAlPortapapeles(texto);
    setCopiadoFeedback(label);
    setTimeout(() => setCopiadoFeedback(null), 2500);
  };

  const [mostrarCircularModal, setMostrarCircularModal] = useState(false);
  const [seccionParaCircular, setSeccionParaCircular] = useState<string | undefined>(undefined);

  const colegioActualNombre = colegiosList[0]?.nombre || 'Instituto Madre del Divino Pastor';
  const colegioCodigosNombre = colegiosList.find((c) => c.id === colegioIdCodigos)?.nombre || colegioActualNombre;

  // Alumnos reales (tabla `alumnos`) del colegio elegido en esta pestaña.
  const alumnosColegioCodigos = useMemo(
    () => alumnosNominaReal.filter((a) => a.colegio_id === colegioIdCodigos),
    [alumnosNominaReal, colegioIdCodigos]
  );

  // "Secciones" derivadas de grado + turno + división de esos alumnos reales — igual que
  // en la pestaña de Nómina, no hay una tabla fija de secciones (cada colegio tiene las
  // suyas). Se les da la forma de SeccionEscolar para poder reusar tal cual el modal de
  // circulares imprimibles y todas las funciones de difusionEscolarService.ts.
  const seccionesCodigosReales: SeccionEscolar[] = useMemo(() => {
    const mapa = new Map<string, SeccionEscolar>();
    alumnosColegioCodigos.forEach((a) => {
      const grado = a.grado || 'Sin grado';
      const turno = a.turno || 'Sin turno';
      const division = a.division || '-';
      const id = `${grado}__${turno}__${division}`;
      const existente = mapa.get(id);
      if (existente) {
        existente.totalAlumnos += 1;
      } else {
        mapa.set(id, {
          id,
          sala: grado,
          turno: turno as SeccionEscolar['turno'],
          division,
          nombreCompleto: `${grado} "${division}" (${turno})`,
          totalAlumnos: 1,
        });
      }
    });
    return Array.from(mapa.values()).sort((a, b) => a.nombreCompleto.localeCompare(b.nombreCompleto, 'es'));
  }, [alumnosColegioCodigos]);

  const gradosDisponiblesCodigos = useMemo(() => {
    const set = new Set(seccionesCodigosReales.map((s) => s.sala));
    return Array.from(set).sort((a, b) => a.localeCompare(b, 'es'));
  }, [seccionesCodigosReales]);

  const cargarCodigosReales = async (colegioId: string) => {
    if (!colegioId) {
      setCodigosRealesMap({});
      return;
    }
    setCargandoCodigosReales(true);
    setErrorCodigos(null);
    try {
      const codigos = await obtenerCodigosSeccionAdmin(colegioId);
      const mapa: Record<string, string> = {};
      codigos.forEach((c) => {
        const id = `${c.grado || 'Sin grado'}__${c.turno || 'Sin turno'}__${c.division || '-'}`;
        mapa[id] = c.codigo_secreto;
      });
      setCodigosRealesMap(mapa);
    } finally {
      setCargandoCodigosReales(false);
    }
  };

  // 16/09 (Pablo: «acá no encuentro ningún código»): `colegioIdCodigos` quedaba pegado al colegio de relleno
  // (`col-divino-pastor-2026`) que devuelve `useColegiosLista()` mientras carga; al llegar la lista real se corrige
  // (mismo arreglo que AdminPadronTab.tsx).
  useEffect(() => {
    if (colegiosList.length > 0 && (!colegioIdCodigos || !colegiosList.some((c) => c.id === colegioIdCodigos))) {
      setColegioIdCodigos(colegiosList[0].id);
    }
  }, [colegiosList, colegioIdCodigos]);

  useEffect(() => {
    if (isAuthenticated && colegioIdCodigos) {
      cargarCodigosReales(colegioIdCodigos);
      setFiltroSalaCodigos('todas');
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isAuthenticated, colegioIdCodigos]);

  const handleAsegurarCodigo = async (sec: SeccionEscolar) => {
    setGuardandoCodigoId(sec.id);
    setErrorCodigos(null);
    const resultado = await asegurarCodigoSeccionAdmin(colegioIdCodigos, sec.sala, sec.turno, sec.division);
    setGuardandoCodigoId(null);
    if (!resultado.success || !resultado.codigo) {
      setErrorCodigos(resultado.error || 'No se pudo generar el código.');
      return;
    }
    setCodigosRealesMap((prev) => ({ ...prev, [sec.id]: resultado.codigo! }));
  };

  const handleRegenerarCodigo = async (sec: SeccionEscolar) => {
    if (!window.confirm(`¿Generar un código NUEVO para "${sec.nombreCompleto}"? El código anterior dejará de funcionar para las familias que ya lo tengan.`)) {
      return;
    }
    setGuardandoCodigoId(sec.id);
    setErrorCodigos(null);
    const resultado = await regenerarCodigoSeccionAdmin(colegioIdCodigos, sec.sala, sec.turno, sec.division);
    setGuardandoCodigoId(null);
    if (!resultado.success || !resultado.codigo) {
      setErrorCodigos(resultado.error || 'No se pudo regenerar el código.');
      return;
    }
    setCodigosRealesMap((prev) => ({ ...prev, [sec.id]: resultado.codigo! }));
    setCopiadoFeedback(`Código regenerado para ${sec.nombreCompleto}: ${resultado.codigo}`);
    setTimeout(() => setCopiadoFeedback(null), 3000);
  };

  const handleGuardarCodigoManual = async (sec: SeccionEscolar, nuevoCodigo: string, campo?: HTMLInputElement) => {
    const limpio = nuevoCodigo.trim();
    if (!limpio) return;
    // Auditoría 11/10 (ADM-11): cambiar el código deja afuera a las familias que tienen el anterior.
    if (!window.confirm(`¿Cambiar el código de "${sec.nombreCompleto}" a ${limpio}? El código anterior dejará de funcionar para las familias que ya lo tengan.`)) {
      if (campo) campo.value = codigosRealesMap[sec.id] || '';
      return;
    }
    setGuardandoCodigoId(sec.id);
    setErrorCodigos(null);
    const resultado = await actualizarCodigoSeccionAdmin(colegioIdCodigos, sec.sala, sec.turno, sec.division, limpio);
    setGuardandoCodigoId(null);
    if (!resultado.success || !resultado.codigo) {
      setErrorCodigos(resultado.error || 'No se pudo guardar el código (¿ya lo está usando otra sección?).');
      return;
    }
    setCodigosRealesMap((prev) => ({ ...prev, [sec.id]: resultado.codigo! }));
    setCopiadoFeedback(`Código guardado: ${resultado.codigo}`);
    setTimeout(() => setCopiadoFeedback(null), 2000);
  };

  const handleAsegurarTodosLosCodigos = async () => {
    const faltantes = seccionesCodigosReales.filter((sec) => !codigosRealesMap[sec.id]);
    if (faltantes.length === 0) {
      setCopiadoFeedback('Todas las secciones ya tienen un código asignado.');
      setTimeout(() => setCopiadoFeedback(null), 2500);
      return;
    }
    setCargandoCodigosReales(true);
    for (const sec of faltantes) {
      const resultado = await asegurarCodigoSeccionAdmin(colegioIdCodigos, sec.sala, sec.turno, sec.division);
      if (resultado.success && resultado.codigo) {
        setCodigosRealesMap((prev) => ({ ...prev, [sec.id]: resultado.codigo! }));
      }
    }
    setCargandoCodigosReales(false);
    setCopiadoFeedback(`¡Códigos generados para ${faltantes.length} sección(es) sin código!`);
    setTimeout(() => setCopiadoFeedback(null), 3000);
  };

  const handleDescargarExcelLegible = () => {
    try {
      const alumnosParaDifusion = alumnosColegioCodigos.map((a) => ({
        nombre: a.nombre,
        grado: a.grado,
        turno: a.turno,
        division: a.division,
      }));
      descargarExcelLegibleColegio(seccionesCodigosReales, codigosRealesMap, colegioCodigosNombre, undefined, alumnosParaDifusion);
      setCopiadoFeedback('¡Libro de Microsoft Excel (.XLSX) con 3 hojas descargado con éxito!');
      setTimeout(() => setCopiadoFeedback(null), 3500);
    } catch (err) {
      console.error('Error al descargar Excel legible:', err);
      setCopiadoFeedback('Hubo un inconveniente al generar el archivo Excel.');
      setTimeout(() => setCopiadoFeedback(null), 3500);
    }
  };

  const handleExportarNominaExcel = () => {
    try {
      const wb = XLSX.utils.book_new();
      const data = alumnosFiltradosAdmin.map((a, idx) => ({
        'N°': a.numero_lista ?? idx + 1,
        'Apellido y Nombre': a.nombre,
        'Curso / Grado': a.grado,
        'Turno': a.turno || '',
        'División': a.division,
        // Código de referencia visual (misma fórmula que usa el checkout real); ver
        // determinarCodigoParaInscripcion — no es el código secreto real de la sección
        // (ese vive en la tabla codigos_seccion), sólo sirve de guía para el fotógrafo.
        'Código de Referencia': determinarCodigoParaInscripcion({ grado: a.grado, turno: a.turno || '', division: a.division }),
        'DNI': a.dni || '', 'Le falta': fotosQueLeFaltan(a), // 21/10: qué foto le falta (individual, seño, grupal)
        'Fotos Incluidas en Paquete': '3 tomas (Retrato, Grupo y con la seño o con familia y/o amigos)'
      }));
      const ws = XLSX.utils.json_to_sheet(data);
      ws['!cols'] = [
        { wch: 6 },
        { wch: 30 },
        { wch: 26 },
        { wch: 12 },
        { wch: 10 },
        { wch: 20 },
        { wch: 14 }, { wch: 24 },
        { wch: 35 }
      ];
      XLSX.utils.book_append_sheet(wb, ws, 'Nómina Alumnos');

      const nombreArchivo = `NOMINA_ALUMNOS_${colegioActualNombre.replace(/\s+/g, '_')}_${filtroSeccionAlumnos}.xlsx`;
      const ok = descargarLibroExcel(wb, nombreArchivo);

      if (ok) {
        setCopiadoFeedback('¡Nómina de alumnos exportada a Excel (.XLSX) exitosamente!');
      } else {
        setCopiadoFeedback('No se pudo iniciar la descarga. Verifique los permisos de su navegador.');
      }
      setTimeout(() => setCopiadoFeedback(null), 3000);
    } catch (err) {
      console.error('Error al exportar nómina a Excel:', err);
      setCopiadoFeedback('Hubo un inconveniente al exportar la nómina a Excel.');
      setTimeout(() => setCopiadoFeedback(null), 3000);
    }
  };

  const handleExportarCSVEspañol = () => {
    descargarCSVEspañolCompatible(seccionesCodigosReales, codigosRealesMap, colegioCodigosNombre);
    setCopiadoFeedback('¡CSV descargado con codificación UTF-8 compatible con Excel en español!');
    setTimeout(() => setCopiadoFeedback(null), 3000);
  };

  const handleCopiarPackCompletoWhatsApp = () => {
    const guiaTexto = generarGuiaWhatsAppColegioTexto(seccionesCodigosReales, codigosRealesMap, colegioCodigosNombre);
    void copiarAlPortapapeles(guiaTexto);
    setCopiadoFeedback('¡Pack completo de WhatsApp copiado al portapapeles para enviar a la Dirección!');
    setTimeout(() => setCopiadoFeedback(null), 3500);
  };

  const handleDescargarGuiaTxt = () => {
    descargarGuiaWhatsAppTxt(seccionesCodigosReales, codigosRealesMap, colegioCodigosNombre);
    setCopiadoFeedback('¡Guía de mensajes en archivo de texto (.TXT) descargada!');
    setTimeout(() => setCopiadoFeedback(null), 3000);
  };

  // Nómina real (tabla 'alumnos', auditoría 09/09: antes era una lista escrita a mano en el código).
  const [filtroSeccionAlumnos, setFiltroSeccionAlumnos] = useState<string>('todas');
  const [busquedaAlumnos, setBusquedaAlumnos] = useState<string>('');
  // 13/10: la marca de «fotografiado» se guarda en el servidor (antes se perdía al recargar).
  const { marcados: checkedAlumnos, conSeno, conGrupal, alternarFotografiado: toggleCheckAlumno, alternarSeno, alternarGrupal, alternarVarios, alternarSenoVarios, alternarGrupalVarios, errorFotografiados } = useFotografiadosNomina(alumnosNominaReal, setAlumnosNominaReal);

  // "Sección" real derivada de grado + turno + división de cada alumno (no hay ninguna tabla
  // fija de secciones para esto — cada colegio que se cargue puede tener grados distintos).
  const seccionIdDeAlumno = (a: AlumnoNominaReal): string =>
    `${a.grado || '-'}__${a.turno || '-'}__${a.division || '-'}`;

  // Distingue Primaria/Inicial de Secundaria por el texto del grado: "1° año".."6° año" es
  // secundaria; "1° grado".."7° grado" y "Sala X años" son primaria/inicial. Se usa \b para que
  // "años" (plural, de "Sala 3 años") no matchee "año" (singular, de secundaria) por error.
  const esGradoDeSecundaria = (grado: string | null | undefined): boolean => /\baño\b/i.test(grado || '');

  const seccionesReales = useMemo(() => {
    const mapa = new Map<string, { id: string; nombreCompleto: string; totalAlumnos: number; esSecundaria: boolean }>();
    alumnosNominaReal.forEach((a) => {
      const id = seccionIdDeAlumno(a);
      const existente = mapa.get(id);
      if (existente) {
        existente.totalAlumnos += 1;
      } else {
        mapa.set(id, {
          id,
          nombreCompleto: `${a.grado || 'Sin grado'} "${a.division || '-'}" (${a.turno || 'Turno sin definir'})`,
          totalAlumnos: 1,
          esSecundaria: esGradoDeSecundaria(a.grado),
        });
      }
    });
    return Array.from(mapa.values()).sort((a, b) => a.nombreCompleto.localeCompare(b.nombreCompleto, 'es'));
  }, [alumnosNominaReal]);

  // Auditoría 2026-09 (pedido de Pablo): la nómina de Instituto Madre del Divino Pastor ya
  // junta Primaria/Inicial y Secundaria en una sola lista de 33 secciones — se separan acá para
  // poder mostrar dos desplegables independientes en vez de uno solo con todo mezclado.
  const seccionesPrimaria = useMemo(() => seccionesReales.filter((s) => !s.esSecundaria), [seccionesReales]);
  const seccionesSecundaria = useMemo(() => seccionesReales.filter((s) => s.esSecundaria), [seccionesReales]);
  const totalAlumnosPrimaria = useMemo(
    () => seccionesPrimaria.reduce((acc, s) => acc + s.totalAlumnos, 0),
    [seccionesPrimaria]
  );
  const totalAlumnosSecundaria = useMemo(
    () => seccionesSecundaria.reduce((acc, s) => acc + s.totalAlumnos, 0),
    [seccionesSecundaria]
  );
  const idsSeccionesPrimaria = useMemo(() => new Set(seccionesPrimaria.map((s) => s.id)), [seccionesPrimaria]);
  const idsSeccionesSecundaria = useMemo(() => new Set(seccionesSecundaria.map((s) => s.id)), [seccionesSecundaria]);

  const alumnosDeLaSeccion = useMemo(() => {
    return alumnosNominaReal.filter((alu) => {
      const matchSeccion =
        filtroSeccionAlumnos === 'todas' ||
        (filtroSeccionAlumnos === 'todas-primaria' && !esGradoDeSecundaria(alu.grado)) ||
        (filtroSeccionAlumnos === 'todas-secundaria' && esGradoDeSecundaria(alu.grado)) ||
        seccionIdDeAlumno(alu) === filtroSeccionAlumnos;
      const q = busquedaAlumnos.toLowerCase().trim();
      const matchSearch = !q ||
        alu.nombre.toLowerCase().includes(q) ||
        alu.grado.toLowerCase().includes(q);
      return matchSeccion && matchSearch;
    }).sort(compararAlumnosNomina); // 19/10: alfabético por apellido y nombre (el curso sólo desempata)
  }, [alumnosNominaReal, filtroSeccionAlumnos, busquedaAlumnos]);
  const [filtroFoto, setFiltroFoto] = useState<FiltroFoto>('todos'); // 14/10: «Sin fotografiar»
  const { visibles: alumnosFiltradosAdmin, ...cuentasFoto } = useMemo(() => filtrarPorFoto(alumnosDeLaSeccion, filtroFoto), [alumnosDeLaSeccion, filtroFoto]); const verListaNomina = !['todas', 'todas-primaria', 'todas-secundaria'].includes(filtroSeccionAlumnos) || busquedaAlumnos.trim() !== ''; // 21/10: + «Falta con la seño». 21/10 tarde (Pablo): sin curso elegido no se muestra la lista de alumnos

  // Cierre de año (borrado de temporada, ver services/cierreAnioService.ts)
  const [cierreAnioColegioId, setCierreAnioColegioId] = useState<string>(() => colegiosList[0]?.id || '');
  // Auditoría 2026-09-16: mismo arreglo que `colegioIdCodigos` más arriba — sin este efecto,
  // este selector queda pegado al id de relleno de `COLEGIO_POR_DEFECTO` y nunca encuentra la
  // nómina/pedidos reales del colegio para cerrar el año.
  useEffect(() => {
    if (colegiosList.length > 0 && (!cierreAnioColegioId || !colegiosList.some((c) => c.id === cierreAnioColegioId))) {
      setCierreAnioColegioId(colegiosList[0].id);
    }
  }, [colegiosList, cierreAnioColegioId]);
  const [cierreAnioResumen, setCierreAnioResumen] = useState<ResumenCierreAnio | null>(null);
  const [cierreAnioNombreConfirmado, setCierreAnioNombreConfirmado] = useState<string>('');
  const [cargandoResumenCierre, setCargandoResumenCierre] = useState(false);
  const [errorCierreAnio, setErrorCierreAnio] = useState<string | null>(null);
  const [textoConfirmacionCierre, setTextoConfirmacionCierre] = useState('');
  const [ejecutandoCierreAnio, setEjecutandoCierreAnio] = useState(false);
  const [resultadoCierreAnio, setResultadoCierreAnio] = useState<{ familias: number; alumnos: number; fotos: number; pedidos: number; pedidosPreservados?: number } | null>(null);
  // Auditoría 03/10 (alto 21): pedidos que frenan el cierre (pagados sin entregar / pendientes
  // recientes). `cierreRequiereForzar` = el servidor ya lo rechazó (409) y se ofrece "Cerrar igual".
  const [bloqueosCierreAnio, setBloqueosCierreAnio] = useState<BloqueosCierreAnio | null>(null);
  const [cierreRequiereForzar, setCierreRequiereForzar] = useState(false);

  // New / editing school state (el mismo formulario sirve para alta y edición)
  const [colegioEditandoId, setColegioEditandoId] = useState<string | null>(null);
  const [nuevoNombre, setNuevoNombre] = useState('');
  const [nuevaLocalidad, setNuevaLocalidad] = useState('');
  const [nuevaZona, setNuevaZona] = useState<'CABA' | 'Zona Norte' | 'Zona Sur' | 'Zona Oeste'>('CABA');
  const [nuevoCodigo, setNuevoCodigo] = useState('');
  const [nuevoWhatsapp, setNuevoWhatsapp] = useState('');
  const [nuevosGrados, setNuevosGrados] = useState('');
  const [nuevasDivisiones, setNuevasDivisiones] = useState('');
  const [nuevosTurnos, setNuevosTurnos] = useState('');
  // 04/10: interruptor «Muestras con lupa» del colegio (apagado = la muestra clásica de siempre).
  const [nuevaMuestrasLupa, setNuevaMuestrasLupa] = useState(false);
  const [guardandoColegio, setGuardandoColegio] = useState(false);
  const [errorColegio, setErrorColegio] = useState<string | null>(null);
  const [borrandoColegioId, setBorrandoColegioId] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    const clean = adminPin.trim();
    if (!clean) {
      setPinError('Ingresá el PIN de acceso.');
      return;
    }

    setIsLoggingIn(true);
    setPinError('');

    try {
      const res = await loginAdminConServidor(clean);
      if (res.success) {
        setIsAuthenticated(true);
        setPinError('');
        setAdminPin('');
      } else {
        setPinError(res.error || 'PIN incorrecto.');
      }
    } catch {
      setPinError('Error de conexión al autenticar contra el servidor.');
    } finally {
      setIsLoggingIn(false);
    }
  };

  const handleCerrarSesion = () => {
    // Auditoría 03/10 noche: además del token se borra la copia local de las familias
    // (infocus_pedidos_escolares_v1), que tiene nombres, emails y teléfonos.
    cerrarSesionAdminYBorrarDatos();
    setPedidosCompletos([]);
    setIsAuthenticated(false);
    setAdminPin('');
  };

  const parseListaColegio = (texto: string): string[] =>
    texto.split(',').map((v) => v.trim()).filter(Boolean);

  const limpiarFormularioColegio = () => {
    setColegioEditandoId(null);
    setNuevoNombre('');
    setNuevaLocalidad('');
    setNuevaZona('CABA');
    setNuevoCodigo('');
    setNuevoWhatsapp('');
    setNuevosGrados('');
    setNuevasDivisiones('');
    setNuevosTurnos('');
    setNuevaMuestrasLupa(false);
    setErrorColegio(null);
  };

  const handleEditarColegioClick = (c: Colegio) => {
    setColegioEditandoId(c.id);
    setNuevoNombre(c.nombre);
    setNuevaLocalidad(c.localidad);
    setNuevaZona(c.zona);
    setNuevoCodigo(c.codigoAcceso);
    setNuevoWhatsapp(c.whatsappContacto || '');
    setNuevosGrados((c.grados || []).join(', '));
    setNuevasDivisiones((c.divisiones || []).join(', '));
    setNuevosTurnos((c.turnos || []).join(', '));
    setNuevaMuestrasLupa(!!c.muestrasLupa);
    setErrorColegio(null);
  };

  const handleCrearColegio = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!nuevoNombre.trim() || !nuevoCodigo.trim()) return;

    setGuardandoColegio(true);
    setErrorColegio(null);

    const datos = {
      nombre: nuevoNombre.trim(),
      localidad: nuevaLocalidad.trim() || 'Buenos Aires',
      zona: nuevaZona,
      codigoAcceso: nuevoCodigo.toUpperCase().trim(),
      whatsappContacto: nuevoWhatsapp.trim() || undefined,
      grados: parseListaColegio(nuevosGrados),
      divisiones: parseListaColegio(nuevasDivisiones),
      turnos: parseListaColegio(nuevosTurnos),
      muestrasLupa: nuevaMuestrasLupa,
    };

    const resultado = colegioEditandoId
      ? await editarColegio(colegioEditandoId, datos)
      : await agregarColegio(datos);

    setGuardandoColegio(false);

    if (!resultado.success) {
      setErrorColegio(resultado.error || 'No se pudo guardar el colegio.');
      return;
    }

    limpiarFormularioColegio();
  };

  // Nombre exacto que hay que escribir para confirmar el cierre de año del colegio/ámbito
  // elegido actualmente (el servidor valida esto mismo del lado suyo, contra el nombre real).
  const fraseConfirmacionCierreAnio =
    cierreAnioColegioId === 'todos'
      ? 'CERRAR TODOS LOS COLEGIOS'
      : `CERRAR ${(colegiosList.find((c) => c.id === cierreAnioColegioId)?.nombre || '').toUpperCase()}`;

  const handleVerResumenCierreAnio = async () => {
    if (!cierreAnioColegioId) return;
    setCargandoResumenCierre(true);
    setErrorCierreAnio(null);
    setResultadoCierreAnio(null);
    setTextoConfirmacionCierre('');
    setBloqueosCierreAnio(null);
    setCierreRequiereForzar(false);
    const resultado = await obtenerResumenCierreAnio(cierreAnioColegioId);
    setCargandoResumenCierre(false);
    if (!resultado.success || !resultado.resumen) {
      setErrorCierreAnio(resultado.error || 'No se pudo armar el resumen.');
      setCierreAnioResumen(null);
      return;
    }
    setCierreAnioResumen(resultado.resumen);
    if (resultado.bloqueos && (resultado.bloqueos.pagadosSinEntregar > 0 || resultado.bloqueos.pendientesRecientes > 0)) {
      setBloqueosCierreAnio(resultado.bloqueos);
    }
    setCierreAnioNombreConfirmado(resultado.colegioNombre || '');
  };

  const handleEjecutarCierreAnio = async (forzar = false) => {
    if (!cierreAnioColegioId || !cierreAnioResumen) return;
    const totalAfectado =
      cierreAnioResumen.alumnos + cierreAnioResumen.familias + cierreAnioResumen.pedidos + cierreAnioResumen.fotos;
    const avisoForzado = forzar && bloqueosCierreAnio
      ? `\n\nOJO: vas a cerrar IGUAL aunque hay ${bloqueosCierreAnio.pagadosSinEntregar} pedido(s) pagado(s) sin entregar y ${bloqueosCierreAnio.pendientesRecientes} pendiente(s) de pago recientes.`
      : '';
    if (
      !window.confirm(
        `Esta acción borra ${totalAfectado} registros de temporada (alumnos, familias, pedidos, fotos y más) de forma DEFINITIVA. No se puede deshacer.${avisoForzado}\n\n¿Confirmás que querés continuar?`
      )
    ) {
      return;
    }
    setEjecutandoCierreAnio(true);
    setErrorCierreAnio(null);
    const resultado = await ejecutarCierreAnio(cierreAnioColegioId, textoConfirmacionCierre, forzar);
    setEjecutandoCierreAnio(false);
    if (!resultado.success) {
      setErrorCierreAnio(resultado.error || 'No se pudo cerrar el año.');
      // Auditoría 03/10: 409 con bloqueos → se muestran las cantidades y aparece "Cerrar igual".
      if (resultado.requiereForzar) {
        setBloqueosCierreAnio(resultado.bloqueos || { pagadosSinEntregar: 0, pendientesRecientes: 0 });
        setCierreRequiereForzar(true);
      }
      return;
    }
    setResultadoCierreAnio(resultado.borrados ? { ...resultado.borrados, pedidosPreservados: resultado.pedidosPreservados } : null);
    setCierreAnioResumen(null);
    setBloqueosCierreAnio(null);
    setCierreRequiereForzar(false);
    setTextoConfirmacionCierre('');
    // La nómina y la lista de colegios pudieron haber cambiado — se refrescan solas.
    cargarNominaReal();
  };

  const handleBorrarColegioClick = async (c: Colegio) => {
    if (!window.confirm(`¿Deseás eliminar "${c.nombre}"?`)) return;

    setBorrandoColegioId(c.id);
    const resultado = await borrarColegio(c.id);
    setBorrandoColegioId(null);

    if (!resultado.success) {
      setErrorColegio(resultado.error || 'No se pudo eliminar el colegio.');
      return;
    }

    if (colegioEditandoId === c.id) {
      limpiarFormularioColegio();
    }
  };

  const construirLinkPadron = (colegioId: string): string => {
    const token = padronTokens[colegioId];
    if (!token) return '';
    // Link corto: el código de padrón ya es único de por sí, no hace falta el UUID del colegio.
    return `${window.location.origin}/padron.html?c=${encodeURIComponent(token)}`;
  };

  const handleCopiarLinkPadron = async (colegioId: string) => {
    const link = construirLinkPadron(colegioId);
    if (!link) return;
    try {
      if (!(await copiarAlPortapapeles(link))) throw new Error('No se pudo copiar');
      setCopiadoPadronId(colegioId);
      setTimeout(() => setCopiadoPadronId((actual) => (actual === colegioId ? null : actual)), 2000);
    } catch {
      window.prompt('Copiá el link manualmente:', link);
    }
  };

  const handleRegenerarPadron = async (c: Colegio) => {
    if (!window.confirm(`¿Regenerar el link de carga de padrón de "${c.nombre}"? El link anterior dejará de funcionar.`)) return;

    setRegenerandoPadronId(c.id);
    const resultado = await regenerarTokenPadronAdmin(c.id);
    setRegenerandoPadronId(null);

    if (!resultado.success || !resultado.codigoPadron) {
      setErrorColegio(resultado.error || 'No se pudo regenerar el link de padrón.');
      return;
    }

    setPadronTokens((actual) => ({ ...actual, [c.id]: resultado.codigoPadron! }));
  };

  // 16/09 (Pablo): todas las secciones como botones arriba, en orden de importancia (una sola lista).
  const accesosRapidos = [
    { id: 'inscriptos', label: pendientesInscripcionCount > 0 ? `Inscriptos (${pendientesInscripcionCount})` : 'Inscriptos', icono: Users },
    { id: 'buscar-alumno', label: 'Buscar alumno', icono: Search },
    { id: 'pedidos', label: `Pedidos (${pedidosCompletos.length})`, icono: Package },
    { id: 'laboratorio', label: 'Laboratorio', icono: Printer },
    { id: 'subir', label: 'Cargar fotos', icono: Upload },
    { id: 'consultas', label: 'Consultas', icono: Mail },
    { id: 'emails', label: 'Emails', icono: Send }, // 26/10: mails a las familias (mensajes, citaciones, promociones, encuestas)
    { id: 'solicitudes', label: pendientesSolicitudesCodigoCount > 0 ? `Solicitudes (${pendientesSolicitudesCodigoCount})` : 'Solicitudes', icono: Key },
    { id: 'estado-pagos', label: 'Estado de pagos', icono: DollarSign },
    { id: 'cancelaciones', label: 'Cancelaciones', icono: RotateCcw },
    { id: 'observaciones', label: 'Observaciones', icono: ClipboardList },
    { id: 'faltantes', label: 'Faltantes', icono: CameraOff }, // 22/10: fotos faltantes que piden las familias
    { id: 'descuentos', label: 'Descuentos', icono: Percent }, // 22/10: códigos de descuento
    { id: 'precios', label: 'Precios', icono: Tag },
    { id: 'codigos', label: 'Códigos y difusión', icono: Send },
    { id: 'colegios', label: 'Colegios', icono: School },
    // 08/10 (pedido de Pablo): la liquidación al colegio tiene su propio botón (antes estaba dentro de Padrón).
    { id: 'liquidacion', label: 'Liquidación', icono: Calculator },
    { id: 'padron', label: 'Padrón', icono: UserCheck },
    { id: 'importar-alumnos', label: 'Importar alumnos', icono: UploadCloud },
    { id: 'alumnos', label: `Nómina (${alumnosNominaReal.length})`, icono: FileSpreadsheet },
    { id: 'whatsapp', label: 'WhatsApp', icono: MessageSquare },
    { id: 'cerrar-anio', label: 'Cerrar año', icono: RefreshCw },
    { id: 'zoho', label: 'Campaña colegios', icono: Globe }, { id: 'configuracion', label: 'Configuración', icono: Settings }, // 30/10: fechas límite
  ] as const;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm animate-in fade-in">
      <div className={`bg-white w-full h-full max-w-none max-h-none overflow-hidden flex flex-col shadow-2xl ${modoNoche ? 'modo-noche' : ''}`}>
        
        {/* Modal Header — auditoría 2026-09 (pedido de Pablo): a la mitad de alto que antes;
            2026-09-15 (pedido de Pablo: "se podría achicar un 30%"): un poco más bajo todavía */}
        <div className="px-3 py-1.5 sm:px-5 sm:py-2 border-b border-slate-200 bg-slate-900 text-white flex items-center justify-between gap-2">
          <div className="flex items-center gap-2 min-w-0">
            <div className="w-6 h-6 rounded-lg bg-amber-500 text-slate-950 flex items-center justify-center font-bold shrink-0">
              <Camera className="w-3 h-3" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                {/* 28/9 (Pablo: "en el celular el texto no se acomoda"): título corto en celular. */}
                <h2 className="text-sm font-bold font-['Outfit'] leading-tight whitespace-nowrap">
                  <span className="sm:hidden">Panel</span>
                  <span className="hidden sm:inline">Panel de Control para Fotógrafos</span>
                </h2>
                <span className="hidden sm:inline text-[9px] uppercase font-bold tracking-wider px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-400 border border-amber-500/30">
                  Interno
                </span>
              </div>
              <p className="text-[11px] text-slate-400 leading-tight hidden sm:block">
                Gestión de pedidos familiares, subida con marca de agua y colegios
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
            <button
              type="button"
              onClick={alternarModoNoche}
              className="p-2 sm:p-1.5 rounded-lg text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 transition-colors cursor-pointer"
              title={modoNoche ? 'Pasar a modo día' : 'Pasar a modo noche'}
              aria-label={modoNoche ? 'Pasar a modo día' : 'Pasar a modo noche'}
            >
              {modoNoche ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
            </button>
            {isAuthenticated && (
              // Pedido de Pablo (28/9): acceso directo a la casilla de Zoho, donde llegan todos los avisos.
              <a
                href="https://mail.zoho.com/zm/"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-1.5 p-2 sm:px-2.5 sm:py-1 rounded-lg bg-amber-500 hover:bg-amber-400 text-xs sm:text-[11px] font-bold text-slate-950 transition-colors"
                title="Abrir el correo de Zoho (avisos, consultas y adjuntos de las familias)"
                aria-label="Correo Zoho"
              >
                <Mail className="w-4 h-4 sm:w-3.5 sm:h-3.5" />
                <span className="hidden sm:inline">Correo Zoho</span>
              </a>
            )}
            {isAuthenticated && (
              <button
                onClick={handleCerrarSesion}
                className="flex items-center gap-1.5 p-2 sm:px-2.5 sm:py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs sm:text-[11px] font-bold text-slate-300 transition-colors cursor-pointer"
                title="Cerrar sesión de administrador"
                aria-label="Cerrar sesión"
              >
                <LogOut className="w-4 h-4 sm:hidden" />
                <span className="hidden sm:inline">Cerrar Sesión</span>
              </button>
            )}
            <button
              onClick={onClose}
              className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
              aria-label="Cerrar panel"
            >
              <X className="w-5 h-5 sm:w-5 sm:h-5" />
            </button>
          </div>
        </div>

        {/* Auth Gate */}
        {!isAuthenticated ? (
          <div className="p-8 sm:p-12 max-w-md mx-auto my-auto text-center space-y-5">
            <div className="w-14 h-14 rounded-2xl bg-amber-100 text-amber-900 flex items-center justify-center mx-auto">
              <Lock className="w-7 h-7" />
            </div>
            <div>
              <h3 className="text-xl font-bold text-slate-900 font-['Outfit']">Acceso Restringido</h3>
              <p className="text-xs text-slate-500 mt-1">
                Ingresá tu PIN de fotógrafo para acceder a la consola administrativa.
              </p>
            </div>

            <form onSubmit={handleLogin} className="space-y-3">
              <CampoPin
                value={adminPin}
                onChange={e => {
                  setAdminPin(e.target.value);
                  setPinError('');
                }}
                disabled={isLoggingIn}
                placeholder="Ingresá tu PIN de fotógrafo"
                className="w-full text-center px-4 py-3 rounded-xl border border-slate-300 text-sm font-bold tracking-widest focus:ring-2 focus:ring-amber-500 focus:outline-none disabled:opacity-50"
              />
              {pinError && <p className="text-xs text-rose-600 font-semibold">{pinError}</p>}

              <button
                type="submit"
                disabled={isLoggingIn}
                className="w-full py-3 rounded-xl bg-amber-500 hover:bg-amber-600 disabled:opacity-50 text-slate-950 font-bold text-sm shadow transition-all cursor-pointer flex items-center justify-center gap-2"
              >
                {isLoggingIn ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    <span>Validando PIN en el servidor...</span>
                  </>
                ) : (
                  <span>Ingresar al Panel</span>
                )}
              </button>
            </form>
          </div>
        ) : (
          /* Authenticated Admin Dashboard */
          <div className="tablas-apilables flex-1 overflow-y-auto px-3 sm:px-6 pb-4 sm:pb-6 space-y-3">

            {/* Barra superior fija (auditoría 2026-09, pedido de Pablo): pestañas + métricas
                quedan pegadas arriba al scrollear el contenido de la pestaña activa (por
                ejemplo, la lista larga de "Nómina 2026").
                2026-09-15 (pedido de Pablo: "hay un espacio en blanco que se podría eliminar"
                entre el header oscuro y esta barra): el padding superior bajó de pt-4/pt-6 a
                pt-2/pt-3.
                2026-09-16 (pedido de Pablo: "la barra fija está tapando filas con información
                importante" + "quiero que todas esas herramientas queden como botones arriba"):
                dos cambios distintos acá:
                (a) se sacó el <select> con las 14 secciones y la tarjeta "Sección activa"
                (quedaba redundante: el botón activo ya se resalta en ámbar) — ahora las 14
                secciones son botones directos, en una sola lista (`accesosRapidos`, ver arriba)
                ordenados por importancia y con salto de línea (flex-wrap) en vez de scroll
                horizontal.
                (b) el "tapando filas" era un bug real de layout, no solo percepción: este bloque
                usaba un margen superior NEGATIVO (`-mt-4`/`-mt-6`) para cancelar el padding
                superior del contenedor con scroll y así llegar "hasta el borde" antes de que
                `sticky top-0` lo prenda ahí. El problema es que ese margen negativo sólo se tiene
                en cuenta para calcular DÓNDE EMPIEZA el contenido que sigue (el resto de cada
                pestaña) — pero al estar "clavado" (sticky), el navegador lo termina pintando más
                abajo de esa posición (exactamente en el borde del padding original, no en el
                borde real del contenedor). Resultado: el contenido de la pestaña arrancaba
                calculado 12-24px más arriba de donde la barra realmente terminaba de pintarse, y
                esos primeros 12-24px de la pestaña quedaban tapados por la barra AUN SIN
                SCROLLEAR (reproducido y confirmado con Playwright antes de tocar nada). Se sacó
                el padding superior del contenedor con scroll (`p-4 sm:p-6` → `px-4 sm:px-6 pb-4
                sm:pb-6`, sin `pt-`) y el `-mt-4 sm:-mt-6` de esta barra — ya no hace falta
                cancelar un padding que no existe, así que la posición "de flujo" (para el
                contenido siguiente) y la posición pintada (sticky) coinciden. El padding superior
                interno de la barra (pt-1/pt-1.5) sigue siendo lo único que controla la distancia
                al header oscuro, ahora sin ese desfasaje. */}
            <div ref={barraSuperiorRef} className="sticky top-0 z-20 -mx-4 sm:-mx-6 px-4 sm:px-6 pt-1 sm:pt-1.5 pb-2 bg-white space-y-2 border-b border-slate-200">

            {/* Auditoría 2026-09-21 (pedido de Pablo: "el panel de administración completo se ve
                muy chiquito en el celular"). Los botones de sección eran del mismo tamaño chico
                (h-8, texto 11px) tanto en escritorio como en celular — abajo de los ~44px que
                recomienda Apple/Google como target táctil mínimo. Ahora arrancan grandes (h-11,
                texto sm, ícono 5x5) y sólo se achican a partir de "sm:" (~640px) al tamaño de
                siempre — en escritorio esto no cambia nada, en el celular cada botón es cómodo de
                tocar con el dedo sin achicar el panel completo de escritorio.
                Auditoría 2026-09-21 (bug real, reportado por Pablo con captura desde el celular
                tras el cambio de arriba): al agrandar cada botón para que sea cómodo de tocar,
                las 14 secciones con salto de línea (`flex-wrap`, decisión tomada el 16/9 para
                escritorio) pasan a ocupar 7 filas en un celular angosto — el usuario tenía que
                scrollear toda esa altura de botones antes de ver la barra de métricas o el
                contenido de la pestaña ("Pedidos") en sí. La decisión del 16/9 de evitar el
                scroll horizontal seguía siendo válida para escritorio (ahí las 14 entran en 1-2
                filas), así que acá se resuelve por breakpoint en vez de elegir una sola opción
                para los dos casos: en celular (`<sm`) la barra es una tira horizontal
                scrolleable de una sola fila (patrón estándar de tab-bar mobile); desde "sm" hacia
                arriba sigue siendo exactamente el `flex-wrap` de siempre, sin ningún cambio. */}
            <nav ref={navSeccionesRef} aria-label="Secciones del panel" className="flex flex-nowrap sm:flex-wrap items-center gap-2 sm:gap-1.5 overflow-x-auto sm:overflow-visible pb-1 sm:pb-0">
              {accesosRapidos.map(({ id, label, icono: Icono }) => {
                const activo = activeTab === id;
                return (
                  <button
                    key={id}
                    type="button"
                    onClick={() => setActiveTab(id)}
                    aria-pressed={activo}
                    className={`inline-flex h-9 sm:h-8 shrink-0 items-center gap-1.5 rounded-lg border px-3 text-[13px] sm:text-[11px] font-bold transition cursor-pointer ${activo
                      ? 'border-amber-400 bg-amber-400 text-slate-950 shadow-sm'
                      : 'border-slate-200 bg-white text-slate-700 hover:border-amber-300 hover:bg-amber-50'
                    }`}
                  >
                    <Icono className="h-4 w-4 sm:h-3.5 sm:w-3.5" />
                    {label}
                  </button>
                );
              })}
            </nav>

            </div>
            {/* fin barra superior fija — Auditoría 2026-09-22 (pedido de Pablo): la fila
                "Recaudación/Pedidos/Colegios" que estaba acá (visible en TODAS las pestañas) se
                eliminó y sus datos (Recaudación, Colegios) se mudaron a la fila de métricas de la
                pestaña Laboratorio (AdminLaboratorioTab.tsx), que es donde Pablo la señaló —
                Recaudación se recalcula ahí mismo a partir de `pedidos` (la lista completa que ya
                recibe por prop) y Colegios se le pasa como nueva prop `totalColegios`. Si en el
                futuro hace falta volver a mostrar estos datos en otras pestañas, `colegiosList`
                sigue disponible acá en AdminModal.tsx para recalcularlos. */}

            <AdminEstadoSistema onIrA={(tab) => setActiveTab(tab)} />

            {avisoSinConexion && (
              <div role="alert" className="flex flex-wrap items-center justify-between gap-2 rounded-2xl border border-amber-300 bg-amber-50 px-4 py-3 text-sm font-semibold text-amber-900">
                <span>⚠️ {avisoSinConexion}</span>
                <button
                  type="button"
                  onClick={() => void sincronizarPedidosDesdeSupabase()}
                  className="rounded-lg bg-amber-200 px-3 py-1 text-xs font-bold hover:bg-amber-300"
                >
                  Reintentar
                </button>
              </div>
            )}

            {/* TAB: INSCRIPTOS & GESTIÓN DE ACCESOS */}
            {activeTab === 'inscriptos' && (
              <>
                <AdminCampanaPagoAnticipado />
                <AdminInscriptosTab onProbarCodigo={onProbarCodigo} />
              </>
            )}

            {/* TAB: BUSCAR ALUMNO (pedido de Pablo 2026-09-16: nombre/DNI/código/teléfono → ¿pagó?) */}
            {activeTab === 'buscar-alumno' && (
              <AdminBuscadorAlumnosTab />
            )}

            {/* TAB: PADRÓN AUTORIZADO (Excel/CSV) */}
            {activeTab === 'padron' && (
              <AdminPadronTab />
            )}

            {/* TAB: LIQUIDACIÓN AL COLEGIO (% de la ganancia neta) — 08/10: separada de Padrón */}
            {activeTab === 'liquidacion' && (
              <div className="text-slate-900 text-left">
                <AdminLiquidacionColegios />
              </div>
            )}

            {/* TAB: SOLICITUDES DE CÓDIGO (reemplaza el botón que abría WhatsApp por cada familia) */}
            {activeTab === 'solicitudes' && (
              <AdminSolicitudesCodigoTab />
            )}
            {activeTab === 'consultas' && (
              <AdminConsultasFamiliasTab />
            )}

            {activeTab === 'zoho' && (
              <AdminZohoCampanaTab />
            )}

            {/* TAB: LABORATORIO & ENSOBRADO */}
            {activeTab === 'laboratorio' && (
              <AdminLaboratorioTab
                pedidos={pedidosCompletos}
                onActualizarPedidos={(actualizar) => {
                  // Forma funcional: la pestaña actualiza en bucle (ej. "Reintentar todos") y cada
                  // vuelta tiene que partir del estado más reciente, no de una lista vieja.
                  setPedidosCompletos((prev) => {
                    const actualizados = actualizar(prev);
                    guardarPedidosEnStorage(actualizados);
                    return actualizados;
                  });
                }}
                colegioNombre={colegiosList[0]?.nombre}
                busquedaInicial={busquedaInicialLaboratorio}
                totalColegios={colegiosList.length}
              />
            )}

            {/* TAB 1: PEDIDOS */}
            {activeTab === 'pedidos' && (
              <div className="space-y-4">
                <AdminResumenKitsSection firmaPedidos={firmaPedidosResumen} />
                <div className="flex items-center justify-between flex-wrap gap-2">
                  <div>
                    {/* Pedido de Pablo (25/9): que el título diga en qué lista se está parado. */}
                    <h3 className="text-base font-bold text-slate-900">
                      {verVencidos ? `Vencidos sin comprobante (${cantidadVencidos})` : verCancelados ? `Pedidos cancelados (${cantidadCancelados})` : verArchivados ? `Pedidos archivados (${cantidadArchivados})` : verEntregados ? `Pedidos entregados (${cantidadEntregados})` : 'Listado de Pedidos de Familias'}
                    </h3>
                    <span className="text-xs text-slate-500">
                      {verVencidos
                        ? 'Pedidos por transferencia que se cancelaron solos porque el comprobante no llegó en 48 h. No se borraron: si la plata entró, aprobalos; si la familia necesita más tiempo, reabrí el plazo.'
                        : verCancelados
                        ? 'Intentos de pago abandonados y reservas reemplazadas por una nueva. No se cobró nada.'
                        : verArchivados
                          ? 'Pedidos que sacaste de la lista sin borrarlos. Podés desarchivarlos cuando quieras.'
                          : verEntregados
                            ? 'Kits digitales con el email de fotos HD ya enviado y kits impresos ya retirados. "⬇ Descargado" indica que la familia tocó el botón de descarga.'
                            : 'Sincronizados en tiempo real con el portal de familias'}
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    {pedidosSeleccionados.size > 0 && (
                      <button
                        type="button"
                        onClick={handleEliminarSeleccionados}
                        disabled={eliminandoSeleccionados}
                        className="px-3 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-700 text-white font-bold text-[11px] shadow-xs transition-colors cursor-pointer disabled:opacity-50"
                      >
                        {eliminandoSeleccionados
                          ? 'Eliminando...'
                          : `Eliminar seleccionados (${pedidosSeleccionados.size})`}
                      </button>
                    )}
                    {!verCancelados && !verArchivados && !verVencidos && <button
                      type="button"
                      onClick={() => { setVerEntregados((v) => !v); setVerArchivados(false); setVerCancelados(false); setVerVencidos(false); setPedidosSeleccionados(new Set()); }}
                      className={`px-2.5 py-1 rounded-lg border font-bold text-[11px] whitespace-nowrap transition-colors cursor-pointer ${verEntregados ? 'bg-slate-700 text-white border-slate-700' : 'bg-white text-emerald-700 border-emerald-300 hover:bg-emerald-50'}`}
                      title="Kits digitales con el email HD enviado y kits impresos ya retirados"
                    >
                      {verEntregados ? '← Volver a los pedidos' : `Ver entregados (${cantidadEntregados})`}
                    </button>}
                    {!verCancelados && !verEntregados && !verVencidos && <button
                      type="button"
                      onClick={() => { setVerArchivados((v) => !v); setVerCancelados(false); setVerEntregados(false); setVerVencidos(false); setPedidosSeleccionados(new Set()); }}
                      className={`px-2.5 py-1 rounded-lg border font-bold text-[11px] whitespace-nowrap transition-colors cursor-pointer ${verArchivados ? 'bg-slate-700 text-white border-slate-700' : 'bg-white text-slate-600 border-slate-300 hover:bg-slate-50'}`}
                    >
                      {verArchivados ? '← Volver a los pedidos' : `Ver archivados (${cantidadArchivados})`}
                    </button>}
                    {!verArchivados && !verEntregados && !verCancelados && <button
                      type="button"
                      onClick={() => { setVerVencidos((v) => !v); setVerCancelados(false); setVerArchivados(false); setVerEntregados(false); setPedidosSeleccionados(new Set()); }}
                      className={`px-2.5 py-1 rounded-lg border font-bold text-[11px] whitespace-nowrap transition-colors cursor-pointer ${verVencidos ? 'bg-slate-700 text-white border-slate-700' : cantidadVencidos > 0 ? 'bg-amber-50 text-amber-800 border-amber-300 hover:bg-amber-100' : 'bg-white text-slate-600 border-slate-300 hover:bg-slate-50'}`}
                      title="Transferencias que se cancelaron solas porque no llegó el comprobante: se pueden aprobar o reabrir"
                    >
                      {verVencidos ? '← Volver a los pedidos' : `⌛ Vencidos sin comprobante (${cantidadVencidos})`}
                    </button>}
                    {!verArchivados && !verEntregados && !verVencidos && <button
                      type="button"
                      onClick={() => { setVerCancelados((v) => !v); setVerArchivados(false); setVerEntregados(false); setVerVencidos(false); setPedidosSeleccionados(new Set()); }}
                      className={`px-2.5 py-1 rounded-lg border font-bold text-[11px] whitespace-nowrap transition-colors cursor-pointer ${verCancelados ? 'bg-slate-700 text-white border-slate-700' : 'bg-white text-slate-600 border-slate-300 hover:bg-slate-50'}`}
                      title="Intentos de pago abandonados y reservas reemplazadas por una nueva"
                    >
                      {verCancelados ? '← Volver a los pedidos' : `Ver cancelados (${cantidadCancelados})`}
                    </button>}
                    <span className="text-xs font-semibold whitespace-nowrap text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-full border border-emerald-200">
                      {pedidosCompletos.filter(p => p.estadoPago === 'aprobado' && !p.seleccionPendiente && !p.enEspera && !p.archivado).length} para revelar
                    </span>
                  </div>
                </div>

                {enListaPrincipal && (
                  <div className="flex items-center gap-1.5 overflow-x-auto pb-0.5" role="group" aria-label="Filtrar pedidos">
                    {FILTROS_PEDIDOS.map(({ id, etiqueta, ayuda }) => {
                      const activo = filtroPedidos === id;
                      return (
                        <button
                          key={id}
                          type="button"
                          aria-pressed={activo}
                          title={ayuda}
                          onClick={() => { setFiltroPedidos(id); setPedidosSeleccionados(new Set()); }}
                          className={`px-2.5 py-1 rounded-full border font-bold text-[11px] whitespace-nowrap transition-colors cursor-pointer ${activo ? 'bg-slate-700 text-white border-slate-700' : 'bg-white text-slate-600 border-slate-300 hover:bg-slate-50'}`}
                        >
                          {etiqueta} ({conteoFiltrosPedidos[id]})
                        </button>
                      );
                    })}
                  </div>
                )}

                <div className="overflow-x-auto rounded-2xl border border-slate-200">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-slate-50 text-slate-500 uppercase font-semibold border-b border-slate-200 text-[10px] tracking-wider">
                      <tr>
                        <th className="py-3 px-4 w-8">
                          <input
                            type="checkbox"
                            aria-label="Seleccionar todos los pedidos"
                            checked={pedidosVisiblesTabla.length > 0 && pedidosSeleccionados.size === pedidosVisiblesTabla.length}
                            onChange={toggleSeleccionarTodosPedidos}
                            className="h-3.5 w-3.5 cursor-pointer accent-amber-500"
                          />
                        </th>
                        <th className="py-3 px-4">N° Pedido</th>
                        <th className="py-3 px-4">Colegio & Alumno</th>
                        <th className="py-3 px-4">Código Minilab</th>
                        <th className="py-3 px-4">Kit Seleccionado</th>
                        <th className="py-3 px-4">Total</th>
                        <th className="py-3 px-4">Pago</th>
                        <th className="py-3 px-4">Acción</th>
                        <th className="py-3 px-4"></th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {pedidosVisiblesTabla.length === 0 ? (
                        <tr>
                          <td colSpan={9} className="py-8 text-center text-slate-400 text-xs">
                            {verVencidos
                              ? 'No hay pedidos vencidos sin comprobante.'
                              : verArchivados
                              ? 'No hay pedidos archivados.'
                              : verCancelados
                                ? 'No hay pedidos cancelados.'
                                : verEntregados
                                  ? 'Todavía no hay pedidos entregados.'
                                  : filtroPedidos !== 'todos'
                                    ? 'No hay pedidos con este filtro.'
                                    : 'Aún no se han registrado pedidos de familias en el sistema.'}
                          </td>
                        </tr>
                      ) : (
                        pedidosVisiblesTabla.map(p => (
                        <tr key={p.id} className={`hover:bg-slate-50 transition-colors ${pedidosSeleccionados.has(p.id) ? 'bg-amber-50/60' : ''}`}>
                          <td className="py-3 px-4">
                            <input
                              type="checkbox"
                              aria-label={`Seleccionar pedido ${p.id}`}
                              checked={pedidosSeleccionados.has(p.id)}
                              onChange={() => toggleSeleccionPedido(p.id)}
                              className="h-3.5 w-3.5 cursor-pointer accent-amber-500"
                            />
                          </td>
                          <td className="py-3 px-4 font-mono font-bold text-slate-900">
                            {p.id}
                            <span className="block text-[10px] font-normal text-slate-400">{p.fecha}</span>
                          </td>
                          <td className="py-3 px-4">
                            <span className="font-bold text-slate-900">{p.alumnoNombre}</span>
                            <span className="block text-[11px] text-slate-500">{p.colegioNombre} · {p.grado} "{p.division}"</span>
                            {p.enEspera && (
                              <span className="mt-0.5 inline-block text-[10px] font-bold text-orange-800 bg-orange-100 border border-orange-200 px-1.5 py-0.5 rounded">
                                En espera{p.notaEspera ? ` · ${p.notaEspera}` : ''}
                              </span>
                            )}
                            {p.archivado && (
                              <span className="mt-0.5 ml-1 inline-block text-[10px] font-bold text-slate-700 bg-slate-200 px-1.5 py-0.5 rounded">Archivado</span>
                            )}
                          </td>
                          <td className="py-3 px-4">
                            <span className="font-mono text-[11px] font-bold text-amber-900 bg-amber-100 px-2 py-0.5 rounded border border-amber-300">
                              {p.codigoAlumno}
                            </span>
                          </td>
                          <td className="py-3 px-4 font-medium text-slate-800">
                            {p.kitNombre}
                            {p.seleccionPendiente ? (
                              <span className="mt-0.5 inline-block text-[10px] font-bold text-violet-800 bg-violet-100 border border-violet-200 px-1.5 py-0.5 rounded">
                                Pago anticipado · falta elegir fotos
                              </span>
                            ) : (
                              <span className="block text-[10px] text-slate-400">
                                {p.archivosParaLaboratorio.length} archivos para el laboratorio
                              </span>
                            )}
                          </td>
                          <td className="py-3 px-4 font-bold text-slate-900">
                            ${p.total.toLocaleString('es-AR')}
                            <span className="block text-[10px] text-slate-400 uppercase">{p.metodoPago}</span>
                          </td>
                          <td className="py-3 px-4">
                            <span className={`inline-block px-2 py-0.5 rounded-full text-[10px] font-bold ${
                              p.estadoPago === 'aprobado'
                                ? 'bg-emerald-100 text-emerald-800'
                                : pedidoVencidoRecuperable(p)
                                  ? 'bg-orange-100 text-orange-800'
                                  : p.estadoPago === 'rechazado'
                                  ? 'bg-slate-200 text-slate-600'
                                  : 'bg-amber-100 text-amber-800'
                            }`}>
                              {p.estadoPago === 'aprobado' ? '✓ Aprobado' : pedidoVencidoRecuperable(p) ? '⌛ Vencido sin comprobante' : p.estadoPago === 'rechazado' ? '✕ Cancelado' : '⏳ Pendiente'}
                            </span>
                            {pedidoVencidoRecuperable(p) && p.transferenciaVencidaAt && (
                              <span className="mt-1 block text-[10px] font-semibold text-slate-400">Se canceló {formatearDiaHora(p.transferenciaVencidaAt)}</span>
                            )}
                            {pedidoEstaEntregado(p) && (
                              <span className="mt-1 block w-fit rounded-full bg-sky-100 px-2 py-0.5 text-[10px] font-bold text-sky-800">
                                ✓ Entregado
                              </span>
                            )}
                            {p.estadoPago === 'aprobado' && p.emailEnviado && !p.seleccionPendiente && (
                              <span className="mt-1 block text-[10px] font-semibold text-slate-400">
                                📩 HD enviado{p.fechaEnvioEmail ? ` ${formatearDiaMes(p.fechaEnvioEmail)}` : ''}
                              </span>
                            )}
                            {p.estadoPago === 'aprobado' && p.emailEnviado && !p.seleccionPendiente && (
                              p.descargaHdAt ? (
                                <span className="block text-[10px] font-bold text-emerald-600" title={`La familia tocó el botón de descarga ${p.descargasHd || 1} ${(p.descargasHd || 1) === 1 ? 'vez' : 'veces'}.`}>
                                  ⬇ Descargado {formatearDiaMes(p.descargaHdAt)}
                                </span>
                              ) : (
                                <span className="block text-[10px] font-semibold text-slate-400" title="Todavía no tocó el botón de descarga (los emails enviados antes del 28/9 no se registran).">
                                  Sin descargar todavía
                                </span>
                              )
                            )}
                          </td>
                          <td className="py-3 px-4">
                            {p.estadoPago === 'pendiente' && p.metodoPago === 'transferencia' && (
                              p.comprobanteSubidoAt ? (
                                <button
                                  type="button"
                                  onClick={() => void handleVerComprobante(p)}
                                  className="mb-1 block px-2.5 py-1 rounded-lg border border-sky-300 bg-sky-50 hover:bg-sky-100 text-sky-800 font-bold text-[10px] cursor-pointer"
                                >
                                  🧾 Ver comprobante
                                </button>
                              ) : (
                                <span className="mb-1 block text-[10px] font-semibold text-slate-400">
                                  Sin comprobante todavía
                                  {(() => {
                                    // 10/10: cuándo se cancela solo si no llega el comprobante (en rojo en las últimas horas).
                                    const vence = venceTransferencia(p.transferenciaDesde);
                                    if (!vence || p.enEspera || p.archivado) return null;
                                    const porVencer = new Date(vence).getTime() - Date.now() <= AVISO_PREVIO_VENCIMIENTO_HORAS * 60 * 60 * 1000;
                                    return (
                                      <span
                                        className={`block ${porVencer ? 'text-rose-600' : 'text-slate-500'}`}
                                        title="Si no llega el comprobante, el pedido se cancela solo a esa hora y pasa a «Vencidos sin comprobante», desde donde lo podés recuperar."
                                      >
                                        ⏰ Vence {formatearDiaHora(vence)}
                                        {p.avisoVencimientoAt ? ' · último aviso enviado' : ''}
                                      </span>
                                    );
                                  })()}
                                </span>
                              )
                            )}
                            {p.estadoPago === 'pendiente' && p.recordatorioPagoAt && !p.comprobanteSubidoAt && (
                              <span
                                className="mb-1 block text-[10px] font-semibold text-amber-500"
                                title="A las 12 hs sin pago ni comprobante, el sistema le mandó a la familia un email automático recordándoselo."
                              >
                                📩 Recordatorio enviado {new Date(p.recordatorioPagoAt).toLocaleDateString('es-AR', { day: '2-digit', month: '2-digit', timeZone: 'America/Argentina/Buenos_Aires' })}
                              </span>
                            )}
                            {p.estadoPago === 'pendiente' ? (
                              <button
                                onClick={() => handleAprobarPago(p)}
                                className="px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-[10px] shadow-xs transition-colors cursor-pointer"
                              >
                                Aprobar Pago
                              </button>
                            ) : pedidoVencidoRecuperable(p) ? (
                              <div className="flex flex-col items-start gap-1">
                                <button
                                  onClick={() => handleAprobarPago(p)}
                                  title="La plata entró al banco: se aprueba y la familia recibe sus fotos, como cualquier pago aprobado a mano"
                                  className="px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-[10px] shadow-xs transition-colors cursor-pointer"
                                >
                                  Aprobar Pago
                                </button>
                                <button
                                  type="button"
                                  onClick={() => void handleReabrirPlazo(p)}
                                  disabled={reabriendoPedidoId === p.id}
                                  title="Vuelve a pendiente de pago con 48 h nuevas para subir el comprobante"
                                  className="px-2.5 py-1 rounded-lg border border-amber-300 bg-amber-50 hover:bg-amber-100 text-amber-800 font-bold text-[10px] cursor-pointer disabled:opacity-50 whitespace-nowrap"
                                >
                                  {reabriendoPedidoId === p.id ? 'Reabriendo...' : 'Reabrir plazo (48 h)'}
                                </button>
                              </div>
                            ) : p.estadoPago === 'rechazado' ? (
                              <span className="text-[10px] text-slate-400" title="Intento de pago abandonado o reserva reemplazada por una nueva. No se cobró nada.">
                                Sin cobrar
                              </span>
                            ) : (
                              <button
                                onClick={() => {
                                  setBusquedaInicialLaboratorio(p.alumnoNombre);
                                  setActiveTab('laboratorio');
                                }}
                                className="text-[11px] font-semibold text-amber-700 hover:text-amber-800 underline cursor-pointer"
                              >
                                Ver en Laboratorio
                              </button>
                            )}
                          </td>
                          <td className="py-3 px-4">
                            <div className="flex items-center gap-1.5">
                            {!p.archivado && (
                              <button
                                type="button"
                                onClick={() => void handleOrganizarPedido(p, { enEspera: !p.enEspera })}
                                disabled={organizandoPedidoId === p.id}
                                title={p.enEspera ? 'Sacar de espera' : 'Poner en espera: queda visible pero no pasa a producción'}
                                className="px-2.5 py-1 rounded-lg bg-orange-50 hover:bg-orange-100 border border-orange-200 text-orange-800 font-bold text-[10px] transition-colors cursor-pointer disabled:opacity-50 whitespace-nowrap"
                              >
                                {p.enEspera ? 'Reanudar' : 'En espera'}
                              </button>
                            )}
                            <button
                              type="button"
                              onClick={() => void handleOrganizarPedido(p, { archivado: !p.archivado })}
                              disabled={organizandoPedidoId === p.id}
                              title={p.archivado ? 'Desarchivar (vuelve a la lista)' : 'Archivar: sale de las listas sin borrarse'}
                              className="px-2.5 py-1 rounded-lg bg-slate-50 hover:bg-slate-100 border border-slate-300 text-slate-700 font-bold text-[10px] transition-colors cursor-pointer disabled:opacity-50"
                            >
                              {p.archivado ? 'Desarchivar' : 'Archivar'}
                            </button>
                            <button
                              type="button"
                              onClick={() => handleEliminarPedido(p)}
                              disabled={eliminandoPedidoId === p.id}
                              title="Eliminar pedido"
                              className="px-2.5 py-1 rounded-lg bg-rose-50 hover:bg-rose-100 border border-rose-200 text-rose-700 font-bold text-[10px] transition-colors cursor-pointer disabled:opacity-50"
                            >
                              {eliminandoPedidoId === p.id ? 'Eliminando...' : 'Eliminar'}
                            </button>
                            </div>
                          </td>
                        </tr>
                      )))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* TAB: GENERAR CÓDIGOS POR CURSO */}
            {activeTab === 'codigos' && (
              <div className="space-y-6 text-left">
                {/* Feedback toast */}
                {copiadoFeedback && (
                  <div className="p-3.5 bg-emerald-50 border border-emerald-300 text-emerald-950 rounded-2xl text-xs font-bold flex items-center justify-between gap-2 shadow-xs animate-in fade-in">
                    <div className="flex items-center gap-2">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                      <span>{copiadoFeedback}</span>
                    </div>
                    <button 
                      onClick={() => setCopiadoFeedback(null)} 
                      className="text-[11px] text-emerald-700 hover:text-emerald-900"
                    >
                      Entendido
                    </button>
                  </div>
                )}

                {/* Error banner */}
                {errorCodigos && (
                  <div className="p-3.5 bg-red-50 border border-red-300 text-red-900 rounded-2xl text-xs font-bold flex items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <AlertCircle className="w-4 h-4 text-red-600 shrink-0" />
                      <span>{errorCodigos}</span>
                    </div>
                    <button onClick={() => setErrorCodigos(null)} className="text-[11px] text-red-700 hover:text-red-900">
                      Cerrar
                    </button>
                  </div>
                )}

                {/* Header & Quick Action Buttons */}
                <div className="bg-gradient-to-br from-amber-50 via-amber-100/40 to-emerald-50/50 border border-amber-200 rounded-3xl p-5 sm:p-6 shadow-xs space-y-4">
                  <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                    <div className="space-y-1.5">
                      <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[10px] font-extrabold uppercase tracking-wider border border-emerald-200">
                        <Send className="w-3 h-3 text-emerald-600" />
                        <span>Kit de Difusión para Colegios & WhatsApp</span>
                      </div>
                      <h3 className="text-lg font-extrabold text-slate-900 flex items-center gap-2 font-['Outfit']">
                        <Key className="w-5 h-5 text-amber-600" />
                        <span>Códigos de Acceso & Difusión para Familias</span>
                      </h3>
                      <p className="text-xs text-slate-600 max-w-2xl leading-relaxed">
                        Estos son los códigos REALES que la familia tiene que escribir en el portal para entrar (los mismos que valida el sitio, guardados en el servidor — no una copia local). Generá los mensajes y notas oficiales para que la Dirección o maestras compartan en los <strong>grupos de WhatsApp</strong> o peguen en los <strong>cuadernos de comunicaciones</strong>.
                      </p>
                    </div>

                    {/* Primary Sharing and Export Suite */}
                    <div className="flex flex-wrap items-center gap-2 shrink-0">
                      <button
                        type="button"
                        onClick={handleDescargarExcelLegible}
                        className="px-3.5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-xl shadow-xs flex items-center gap-1.5 transition-all cursor-pointer active:scale-98"
                        title="Descarga el libro oficial de Microsoft Excel (.XLSX) con 3 pestañas: Códigos, Alumnos e Instrucciones"
                      >
                        <FileSpreadsheet className="w-4 h-4 text-emerald-200" />
                        <span>Descargar Planilla Excel (.XLSX)</span>
                      </button>

                      <button
                        type="button"
                        onClick={handleCopiarPackCompletoWhatsApp}
                        className="px-3.5 py-2.5 bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs rounded-xl shadow-xs flex items-center gap-1.5 transition-all cursor-pointer active:scale-98"
                        title="Copia los mensajes de todas las salas juntos para enviar a la Dirección de la escuela"
                      >
                        <Copy className="w-3.5 h-3.5 text-amber-400" />
                        <span>Copiar Pack WhatsApp Colegio</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => {
                          setSeccionParaCircular(undefined);
                          setMostrarCircularModal(true);
                        }}
                        className="px-3.5 py-2.5 bg-white hover:bg-slate-50 border border-slate-300 text-slate-800 font-bold text-xs rounded-xl shadow-xs flex items-center gap-1.5 transition-all cursor-pointer active:scale-98"
                        title="Genera notas para recortar y pegar en el cuaderno de comunicaciones de los alumnos"
                      >
                        <Scissors className="w-3.5 h-3.5 text-amber-600" />
                        <span>Notas Imprimibles (Cuaderno)</span>
                      </button>
                    </div>
                  </div>

                  {/* Colegio selector */}
                  <div className="flex flex-col sm:flex-row sm:items-center gap-2 pt-3 border-t border-amber-200/60">
                    <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider shrink-0">Colegio:</label>
                    <select
                      value={colegioIdCodigos}
                      onChange={(e) => setColegioIdCodigos(e.target.value)}
                      className="px-3 py-2 rounded-xl border border-slate-300 text-xs bg-white font-bold text-slate-900 max-w-xs"
                    >
                      {colegiosList.map((c) => (
                        <option key={c.id} value={c.id}>{c.nombre}</option>
                      ))}
                    </select>
                    <button
                      type="button"
                      onClick={handleAsegurarTodosLosCodigos}
                      disabled={cargandoCodigosReales || seccionesCodigosReales.length === 0}
                      className="px-3 py-2 bg-amber-500 hover:bg-amber-400 disabled:opacity-50 disabled:cursor-not-allowed text-slate-950 font-bold text-[11px] rounded-xl transition-colors cursor-pointer flex items-center gap-1.5"
                      title="Genera un código real para cada sección de este colegio que todavía no tenga uno"
                    >
                      <Key className="w-3.5 h-3.5" />
                      <span>Asegurar códigos para todas las secciones</span>
                    </button>
                  </div>

                  {/* Secondary Tools row */}
                  <div className="flex flex-wrap items-center justify-between gap-2 pt-3 border-t border-amber-200/60 text-xs">
                    <span className="text-[11px] text-slate-500">
                      Los códigos se generan y guardan en el servidor (tabla <code className="font-mono">codigos_seccion</code>) — no hay formato "nemotécnico" adivinable por seguridad.
                    </span>

                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={handleDescargarGuiaTxt}
                        className="text-[11px] text-slate-600 hover:text-slate-900 font-semibold underline cursor-pointer"
                      >
                        Descargar Guía en .TXT
                      </button>
                      <span className="text-slate-300">·</span>
                      <button
                        type="button"
                        onClick={handleExportarCSVEspañol}
                        className="text-[11px] text-slate-600 hover:text-slate-900 font-semibold underline cursor-pointer"
                        title="CSV con UTF-8 y delimitador punto y coma para Excel en español"
                      >
                        CSV para Excel (con ;)
                      </button>
                    </div>
                  </div>
                </div>

                {/* Filter Tabs by Grado/Sala (dinámico según el colegio elegido) */}
                <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                  <div className="flex flex-wrap gap-1.5 p-1 bg-slate-100 rounded-xl">
                    {['todas', ...gradosDisponiblesCodigos].map((tab) => (
                      <button
                        key={tab}
                        type="button"
                        onClick={() => setFiltroSalaCodigos(tab)}
                        className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                          filtroSalaCodigos === tab
                            ? 'bg-white text-slate-950 shadow-xs'
                            : 'text-slate-600 hover:text-slate-900'
                        }`}
                      >
                        {tab === 'todas' ? `Todos los Cursos (${seccionesCodigosReales.length})` : tab}
                      </button>
                    ))}
                  </div>

                  <span className="text-xs text-slate-500 font-medium">
                    {cargandoCodigosReales
                      ? 'Cargando códigos…'
                      : `${seccionesCodigosReales.length} sección(es) · ${alumnosColegioCodigos.length} alumnos en nómina`}
                  </span>
                </div>

                {seccionesCodigosReales.length === 0 && !cargandoCodigosReales && (
                  <div className="p-6 text-center text-sm text-slate-500 bg-slate-50 rounded-2xl border border-dashed border-slate-300">
                    Este colegio todavía no tiene alumnos cargados en la nómina real (pestaña "Nómina Alumnos" o "Carga de Fotos").
                  </div>
                )}

                {/* Course Codes List Grid */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {seccionesCodigosReales
                    .filter((sec) => filtroSalaCodigos === 'todas' || sec.sala === filtroSalaCodigos)
                    .map((sec) => {
                      const currentCode = codigosRealesMap[sec.id] || '';
                      const mensajeCurso = currentCode ? generarMensajeWhatsApp(sec, currentCode, colegioCodigosNombre) : '';
                      const guardando = guardandoCodigoId === sec.id;

                      return (
                        <div
                          key={sec.id}
                          className="bg-white p-4 sm:p-5 rounded-2xl border border-slate-200 shadow-xs space-y-3.5 hover:border-amber-300 transition-colors"
                        >
                          <div className="flex items-start justify-between gap-2">
                            <div>
                              <h4 className="text-sm font-bold text-slate-900 flex items-center gap-1.5">
                                <School className="w-4 h-4 text-amber-600 shrink-0" />
                                <span>{sec.nombreCompleto}</span>
                              </h4>
                              <p className="text-[11px] text-slate-500 mt-0.5">
                                {sec.sala} · Turno {sec.turno} · Div. {sec.division}
                              </p>
                            </div>
                            <span className="px-2.5 py-1 rounded-full bg-slate-100 text-slate-700 text-[11px] font-bold shrink-0">
                              {sec.totalAlumnos} alumnos
                            </span>
                          </div>

                          {/* Code edit input */}
                          <div className="space-y-1.5 bg-slate-50 p-3 rounded-xl border border-slate-200">
                            <label className="text-[10px] uppercase font-extrabold text-slate-500 tracking-wider flex items-center justify-between">
                              <span>Código real de acceso:</span>
                              <span className="text-[10px] text-slate-400 font-normal">
                                {guardando ? 'Guardando…' : 'Editable al tipear'}
                              </span>
                            </label>
                            {!currentCode ? (
                              <button
                                type="button"
                                disabled={guardando}
                                onClick={() => handleAsegurarCodigo(sec)}
                                className="w-full px-3 py-2 bg-amber-400 hover:bg-amber-300 disabled:opacity-60 text-slate-950 text-xs font-bold rounded-lg flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                              >
                                {guardando ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Key className="w-3.5 h-3.5" />}
                                <span>Generar código real para esta sección</span>
                              </button>
                            ) : (
                              <div className="flex gap-2">
                                <input
                                  type="text"
                                  defaultValue={currentCode}
                                  key={currentCode}
                                  disabled={guardando}
                                  onBlur={(e) => {
                                    const val = e.target.value.trim().toUpperCase();
                                    if (val && val !== currentCode) {
                                      handleGuardarCodigoManual(sec, val, e.target);
                                    }
                                  }}
                                  onKeyDown={(e) => {
                                    if (e.key === 'Enter') {
                                      e.preventDefault();
                                      (e.target as HTMLInputElement).blur(); // guarda una sola vez, en onBlur (11/10)
                                    }
                                  }}
                                  className="px-3 py-1.5 text-xs font-mono font-black uppercase bg-white border border-slate-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-amber-400 w-full tracking-wider text-slate-900 disabled:opacity-60"
                                />
                                <button
                                  type="button"
                                  onClick={() => handleCopiarTexto(currentCode, `Código ${currentCode} copiado al portapapeles`)}
                                  className="px-3 py-1.5 bg-amber-400 hover:bg-amber-300 text-slate-950 text-xs font-bold rounded-lg flex items-center gap-1 transition-colors cursor-pointer shrink-0"
                                  title="Copiar código al portapapeles"
                                >
                                  <Copy className="w-3.5 h-3.5" />
                                  <span>Copiar</span>
                                </button>
                                <button
                                  type="button"
                                  disabled={guardando}
                                  onClick={() => handleRegenerarCodigo(sec)}
                                  className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 disabled:opacity-60 text-slate-700 text-xs font-bold rounded-lg flex items-center gap-1 transition-colors cursor-pointer shrink-0"
                                  title="Generar un código nuevo, invalidando el anterior"
                                >
                                  <RefreshCw className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            )}
                          </div>

                          {/* Quick Message Preview & Actions */}
                          <div className="pt-2 border-t border-slate-100 space-y-2">
                            <div className="flex items-center justify-between gap-2 flex-wrap">
                              <div className="flex items-center gap-2">
                                <a
                                  href={currentCode ? `https://wa.me/?text=${encodeURIComponent(mensajeCurso)}` : undefined}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  aria-disabled={!currentCode}
                                  onClick={(e) => { if (!currentCode) e.preventDefault(); }}
                                  className={`px-2.5 py-1.5 font-bold text-xs rounded-xl flex items-center gap-1.5 shadow-xs transition-colors ${
                                    currentCode
                                      ? 'bg-emerald-600 hover:bg-emerald-500 text-white cursor-pointer'
                                      : 'bg-slate-200 text-slate-400 cursor-not-allowed'
                                  }`}
                                  title={currentCode ? 'Abrir WhatsApp con el mensaje ya redactado' : 'Primero generá un código para esta sección'}
                                >
                                  <Send className="w-3.5 h-3.5" />
                                  <span>WhatsApp</span>
                                </a>

                                <button
                                  type="button"
                                  disabled={!currentCode}
                                  onClick={() => handleCopiarTexto(mensajeCurso, `¡Mensaje de WhatsApp para ${sec.nombreCompleto} copiado!`)}
                                  className="px-2.5 py-1.5 bg-slate-100 hover:bg-slate-200 disabled:opacity-50 disabled:cursor-not-allowed text-slate-700 font-bold text-xs rounded-xl flex items-center gap-1 transition-colors cursor-pointer"
                                  title="Copiar texto completo para WhatsApp"
                                >
                                  <Copy className="w-3.5 h-3.5 text-slate-500" />
                                  <span>Copiar Texto</span>
                                </button>
                              </div>

                              <div className="flex items-center gap-1.5">
                                <button
                                  type="button"
                                  onClick={() => {
                                    setSeccionParaCircular(sec.id);
                                    setMostrarCircularModal(true);
                                  }}
                                  className="text-xs font-bold text-slate-600 hover:text-slate-900 flex items-center gap-1 p-1 rounded-lg hover:bg-slate-100 transition-colors cursor-pointer"
                                  title="Ver e imprimir nota para cuaderno de este curso"
                                >
                                  <Scissors className="w-3.5 h-3.5 text-amber-600" />
                                  <span>Imprimir Nota</span>
                                </button>

                                {onProbarCodigo && currentCode && (
                                  <button
                                    type="button"
                                    onClick={() => onProbarCodigo(currentCode)}
                                    className="text-xs font-bold text-amber-700 hover:text-amber-800 flex items-center gap-1 p-1 rounded-lg hover:bg-amber-50 transition-colors cursor-pointer"
                                  >
                                    <span>Probar</span>
                                    <ExternalLink className="w-3 h-3" />
                                  </button>
                                )}
                              </div>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                </div>
              </div>
            )}

            {/* TAB: NOMINA ALUMNOS 2026 */}
            {activeTab === 'alumnos' && (
              <div className="space-y-4">
                {/* Auditoría 2026-09 (pedido de Pablo): "esta sección no debe desplazarse, solo
                    el listado de nombres". Esta franja (título+botones, filtros y encabezado de
                    columnas) queda fija, apilada justo debajo de la barra superior fija, usando
                    su altura real (medida con ResizeObserver) como offset. Sólo las filas de la
                    tabla (tbody) se desplazan por detrás. */}
                <div
                  className="sticky z-10 -mx-4 sm:-mx-6 px-4 sm:px-6 pb-3 bg-white space-y-3 border-b border-slate-200"
                  style={{ top: alturaBarraSuperior }}
                >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-50 p-4 rounded-2xl border border-slate-200">
                  <div>
                    <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                      <Users className="w-5 h-5 text-amber-500" />
                      <span>Nómina Escolar 2026</span>
                    </h3>
                    <p className="text-xs text-slate-500">
                      {cargandoNominaReal
                        ? 'Cargando nómina real desde Supabase...'
                        : `${alumnosNominaReal.length} alumnos registrados en ${seccionesReales.length} secciones (datos reales del padrón)`}
                    </p>
                  </div>

                  <div className="flex items-center gap-2 flex-wrap">
                    <button
                      type="button"
                      onClick={cargarNominaReal}
                      disabled={cargandoNominaReal}
                      className="px-3 py-1.5 bg-white border border-slate-300 hover:bg-slate-100 disabled:opacity-50 rounded-xl text-xs font-semibold text-slate-700 flex items-center gap-1.5 cursor-pointer shadow-xs transition-colors"
                      title="Volver a traer la nómina desde Supabase"
                    >
                      <RefreshCw className={`w-3.5 h-3.5 text-slate-500 ${cargandoNominaReal ? 'animate-spin' : ''}`} />
                      <span>Actualizar</span>
                    </button>

                    {verListaNomina && <BotonesChequeoNomina onFotografiados={() => alternarVarios(alumnosFiltradosAdmin)} onSeno={() => alternarSenoVarios(alumnosFiltradosAdmin)} onGrupal={() => alternarGrupalVarios(alumnosFiltradosAdmin)} />}

                    <button
                      type="button"
                      onClick={handleExportarNominaExcel}
                      className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-xs transition-colors"
                      title="Exporta la nómina completa directamente a un archivo de Excel (.XLSX)"
                    >
                      <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-200" />
                      <span>Exportar a Excel (.XLSX)</span>
                    </button>
                  </div>
                </div>

                {/* Filters */}
                <div className="space-y-2">
                  <div className="flex flex-col sm:flex-row gap-3">
                    <div className="relative flex-1">
                      <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                      <input
                        type="text"
                        value={busquedaAlumnos}
                        onChange={(e) => setBusquedaAlumnos(e.target.value)}
                        placeholder="Buscar por nombre de alumno o grado..."
                        className="w-full pl-9 pr-3 py-2 text-xs bg-white border border-slate-300 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-amber-400"
                      />
                    </div>
                    <FiltroFotografiadoNomina valor={filtroFoto} onCambiar={setFiltroFoto} cuentas={cuentasFoto} />
                    <div className="sm:w-64">
                      <select
                        value={idsSeccionesPrimaria.has(filtroSeccionAlumnos) || filtroSeccionAlumnos === 'todas-primaria' ? filtroSeccionAlumnos : 'todas-primaria'}
                        onChange={(e) => setFiltroSeccionAlumnos(e.target.value)}
                        className="w-full px-3 py-2 text-xs bg-white border border-slate-300 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-amber-400 font-medium text-slate-700"
                      >
                        <option value="todas-primaria">Primaria/Inicial: todas ({totalAlumnosPrimaria} alumnos)</option>
                        {seccionesPrimaria.map((sec) => (
                          <option key={sec.id} value={sec.id}>
                            {sec.nombreCompleto} ({sec.totalAlumnos} alumnos)
                          </option>
                        ))}
                      </select>
                    </div>
                    <div className="sm:w-64">
                      <select
                        value={idsSeccionesSecundaria.has(filtroSeccionAlumnos) || filtroSeccionAlumnos === 'todas-secundaria' ? filtroSeccionAlumnos : 'todas-secundaria'}
                        onChange={(e) => setFiltroSeccionAlumnos(e.target.value)}
                        className="w-full px-3 py-2 text-xs bg-white border border-slate-300 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-amber-400 font-medium text-slate-700"
                      >
                        <option value="todas-secundaria">Secundaria: todas ({totalAlumnosSecundaria} alumnos)</option>
                        {seccionesSecundaria.map((sec) => (
                          <option key={sec.id} value={sec.id}>
                            {sec.nombreCompleto} ({sec.totalAlumnos} alumnos)
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>

                  {filtroSeccionAlumnos !== 'todas' && (
                    <button
                      onClick={() => setFiltroSeccionAlumnos('todas')}
                      className="text-[11px] font-semibold text-slate-500 hover:text-slate-800 underline underline-offset-2 cursor-pointer"
                    >
                      Ver todas las secciones ({alumnosNominaReal.length} alumnos)
                    </button>
                  )}
                  <ResumenCursosNomina alumnos={alumnosNominaReal} secciones={seccionesReales} idDe={seccionIdDeAlumno} seleccionada={filtroSeccionAlumnos} onElegir={setFiltroSeccionAlumnos} />
                </div>

                {/* Encabezado de columnas: es una tabla aparte (sólo colgroup + thead), no
                    "position: sticky" dentro del contenedor con scroll horizontal de la tabla de
                    abajo (eso rompe el sticky, ver nota más arriba). Vive dentro de esta misma
                    franja fija, así queda pegado justo debajo del título y los filtros. Usa las
                    mismas proporciones de columna (colgroup) que la tabla de filas para que
                    ambas queden alineadas. */}
                <div className={`rounded-t-2xl border border-b-0 border-slate-200 bg-white overflow-hidden ${verListaNomina ? '' : 'hidden'}`}>
                  <table className="w-full table-fixed text-left text-xs">
                    <ColumnasNomina />
                    <thead className="bg-slate-50 text-slate-500 uppercase font-semibold border-b border-slate-200">
                      <tr>
                        <th className="py-2.5 px-3 text-center">✓</th>
                        <th className="py-2.5 px-3 text-slate-400">#</th>
                        <th className="py-2.5 px-4 font-bold text-slate-800">Apellido y Nombre</th>
                        <th className="py-2.5 px-4">Grado</th>
                        <th className="py-2.5 px-4">Turno</th>
                        <th className="py-2.5 px-4">División</th>
                        <th className="py-2.5 px-4 text-center">Estado Foto</th>
                        <th className="py-2.5 px-3">Observaciones</th>
                      </tr>
                    </thead>
                  </table>
                </div>
                </div>
                {/* fin franja fija de nómina (título, filtros, encabezado de tabla) */}

                {/* Table: sólo las filas (tbody) — se desplazan por detrás de la franja fija de
                    arriba. Usa el mismo colgroup que el encabezado para quedar alineada. */}
                <div className={`rounded-b-2xl border border-t-0 border-slate-200 bg-white ${verListaNomina ? '' : 'hidden'}`}>
                  <table className="w-full table-fixed text-left text-xs">
                    <ColumnasNomina />
                    <tbody className="divide-y divide-slate-100">
                      {alumnosFiltradosAdmin.length === 0 ? (
                        <tr>
                          <td colSpan={8} className="py-8 text-center text-slate-400">
                            {cargandoNominaReal
                              ? 'Cargando nómina...'
                              : 'No se encontraron alumnos con los criterios seleccionados.'}
                          </td>
                        </tr>
                      ) : (
                        alumnosFiltradosAdmin.map((alu, index) => {
                          const isChecked = !!checkedAlumnos[alu.id];
                          return (
                            <tr
                              key={alu.id}
                              onClick={() => toggleCheckAlumno(alu.id, alu.nombre)}
                              className={`cursor-pointer transition-colors ${
                                isChecked ? 'bg-amber-50/50 hover:bg-amber-50' : 'hover:bg-slate-50'
                              }`}
                            >
                              <td className="py-2.5 px-3 text-center">
                                <input
                                  type="checkbox"
                                  checked={isChecked}
                                  onClick={(event) => event.stopPropagation()}
                                  onChange={() => toggleCheckAlumno(alu.id, alu.nombre)}
                                  className="w-4 h-4 rounded text-amber-500 focus:ring-amber-400 cursor-pointer"
                                />
                              </td>
                              <td className="py-2.5 px-3 text-slate-400 font-mono text-[11px]">
                                {alu.numero_lista ?? index + 1}
                              </td>
                              <td className="py-2.5 px-4 font-bold text-slate-900">
                                <NombreConCambioCurso alumno={alu} onCambiar={abrirCambioCurso} />
                              </td>
                              <td className="py-2.5 px-4">
                                <span className="px-2 py-0.5 rounded-md bg-slate-100 text-slate-700 font-medium text-[11px]">
                                  {alu.grado}
                                </span>
                              </td>
                              <td className="py-2.5 px-4">
                                <span className="px-2 py-0.5 rounded-md bg-amber-100 text-amber-900 font-medium text-[11px]">
                                  {alu.turno || '—'}
                                </span>
                              </td>
                              <td className="py-2.5 px-4">
                                <span className="px-2 py-0.5 rounded-md bg-sky-100 text-sky-800 font-medium text-[11px]">
                                  {alu.division}
                                </span>
                              </td>
                              <td className="py-2.5 px-4 text-center">
                                <EstadoFotoNomina fotografiado={isChecked} seno={!!conSeno[alu.id]} grupal={!!conGrupal[alu.id]} onSeno={() => alternarSeno(alu.id, alu.nombre)} onGrupal={() => alternarGrupal(alu.id, alu.nombre)} />
                              </td>
                              <td className="py-2.5 px-3"><CeldaObservacionesNomina alumno={alu} observaciones={observacionesDe(alu.id)} onAbrir={abrirObservaciones} /></td>
                            </tr>
                          );
                        })
                      )}
                    </tbody>
                  </table>
                </div>

                {modalCambioCurso}
                {modalObservaciones}
                <div className="flex items-center justify-between text-xs text-slate-500 px-2">
                  <span>
                    {verListaNomina ? `Mostrando ${alumnosFiltradosAdmin.length} de ${alumnosNominaReal.length} alumnos` : <strong className="text-slate-700">Elegí un curso en «Avance por curso» o en los selectores (o buscá un nombre) para ver sus alumnos.</strong>}
                  </span>
                  <span role={errorFotografiados || errorObservaciones ? 'alert' : undefined} className={errorFotografiados || errorObservaciones ? 'text-rose-600 font-semibold' : ''}>
                    {errorFotografiados || errorObservaciones || `${Object.values(checkedAlumnos).filter(Boolean).length} con individual · ${Object.values(conSeno).filter(Boolean).length} con la seño · ${Object.values(conGrupal).filter(Boolean).length} con grupal (quedan guardados)`}
                  </span>
                </div>
              </div>
            )}
            {activeTab === 'estado-pagos' && <AdminEstadoPagosTab />}
            {activeTab === 'cancelaciones' && <AdminCancelacionesTab />}
            {activeTab === 'precios' && <AdminPreciosTab />}{activeTab === 'configuracion' && <AdminConfiguracionTab />}
            {activeTab === 'importar-alumnos' && <AdminImportarAlumnosTab />}
            {activeTab === 'observaciones' && <AdminObservacionesTab />}
            {activeTab === 'faltantes' && <AdminFaltantesTab />}
            {activeTab === 'descuentos' && <AdminDescuentosTab />}
            {activeTab === 'emails' && <AdminEmailsTab />}
            {activeTab === 'subir' && (
              <AdminLoteFotosTab />
            )}

            {/* TAB 3: COLEGIOS */}
            {activeTab === 'colegios' && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <form onSubmit={handleCrearColegio} className="space-y-4 bg-slate-50 p-6 rounded-2xl border border-slate-200">
                  <div className="flex items-center justify-between">
                    <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider">
                      {colegioEditandoId ? 'Editar Colegio' : 'Dar de Alta Nuevo Colegio'}
                    </h3>
                    {colegioEditandoId && (
                      <button
                        type="button"
                        onClick={limpiarFormularioColegio}
                        className="text-[11px] font-bold text-slate-500 hover:text-slate-800 cursor-pointer"
                      >
                        Cancelar edición
                      </button>
                    )}
                  </div>

                  <p className="text-[11px] text-slate-500 -mt-2">
                    Se guarda en Supabase: queda visible al instante para todas las familias que entren al sitio.
                  </p>

                  {errorColegio && (
                    <div className="p-2.5 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-[11px] font-semibold flex items-center gap-1.5">
                      <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                      <span>{errorColegio}</span>
                    </div>
                  )}

                  <div className="space-y-1">
                    <label className="text-xs font-bold text-slate-700">Nombre de la Institución *</label>
                    <input
                      type="text"
                      required
                      value={nuevoNombre}
                      onChange={e => setNuevoNombre(e.target.value)}
                      placeholder="Ej: Colegio San Jorge"
                      className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs bg-white"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-xs font-bold text-slate-700">Localidad / Barrio</label>
                    <input
                      type="text"
                      value={nuevaLocalidad}
                      onChange={e => setNuevaLocalidad(e.target.value)}
                      placeholder="Ej: Quilmes / Zona Sur"
                      className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs bg-white"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-xs font-bold text-slate-700">Código de Acceso Familias *</label>
                    <input
                      type="text"
                      required
                      value={nuevoCodigo}
                      onChange={e => setNuevoCodigo(e.target.value)}
                      placeholder="Ej: SANJORGE26"
                      className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs bg-white font-mono font-bold uppercase"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-xs font-bold text-slate-700">WhatsApp de Solicitud de Códigos (Opcional)</label>
                    <input
                      type="text"
                      value={nuevoWhatsapp}
                      onChange={e => setNuevoWhatsapp(e.target.value)}
                      placeholder="Ej: 54911xxxxxxxx (vacío para usar número general)"
                      className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs bg-white font-mono"
                    />
                    <p className="text-[10px] text-slate-500">
                      Si lo dejás en blanco, usará el número configurado en la pestaña WhatsApp.
                    </p>
                  </div>

                  <div className="pt-2 border-t border-slate-200 space-y-3">
                    <p className="text-[11px] font-bold text-slate-600 uppercase tracking-wider">
                      Grados, Divisiones y Turnos de este Colegio
                    </p>
                    <p className="text-[10px] text-slate-500 -mt-2">
                      Tildá los que apliquen. Si no encontrás alguno, agregalo con "+ Agregar". Si no tildás nada, se usa una lista genérica por defecto.
                    </p>

                    <div className="space-y-1">
                      <label className="text-xs font-bold text-slate-700">Grados / Salas</label>
                      <SelectorMultiple
                        value={nuevosGrados}
                        onChange={setNuevosGrados}
                        opciones={OPCIONES_GRADOS_COLEGIO}
                        placeholderOtro="Ej: Nivelación, Plurigrado..."
                      />
                    </div>

                    <div className="space-y-1">
                      <label className="text-xs font-bold text-slate-700">Divisiones</label>
                      <SelectorMultiple
                        value={nuevasDivisiones}
                        onChange={setNuevasDivisiones}
                        opciones={OPCIONES_DIVISIONES_COLEGIO}
                        placeholderOtro="Ej: E, Única..."
                      />
                    </div>

                    <div className="space-y-1">
                      <label className="text-xs font-bold text-slate-700">Turnos</label>
                      <SelectorMultiple
                        value={nuevosTurnos}
                        onChange={setNuevosTurnos}
                        opciones={OPCIONES_TURNOS_COLEGIO}
                        placeholderOtro="Ej: Nocturno..."
                      />
                    </div>
                  </div>

                  {/* 04/10 (pedido de Pablo): muestras con lupa, por colegio. */}
                  <label className="flex items-start gap-2 rounded-xl border border-slate-200 bg-slate-50 p-3 text-xs text-slate-700 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={nuevaMuestrasLupa}
                      onChange={(e) => setNuevaMuestrasLupa(e.target.checked)}
                      className="mt-0.5 h-4 w-4 accent-amber-500"
                    />
                    <span>
                      <span className="font-bold text-slate-900">Muestras con lupa</span>: la foto se ve apenas desenfocada con
                      «PASÁ LA LUPA POR LA IMAGEN» y la familia la ve nítida con la lupa. Apagado: la marca de siempre.
                      <span className="block text-[11px] text-slate-500 mt-0.5">
                        Al cambiarlo, tocá «Actualizar Muestras» en la pestaña de fotos para rehacer las que ya están subidas.
                      </span>
                    </span>
                  </label>

                  <button
                    type="submit"
                    disabled={guardandoColegio}
                    className="w-full py-2.5 rounded-xl bg-amber-500 hover:bg-amber-600 disabled:opacity-60 text-slate-950 font-bold text-xs shadow flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    {guardandoColegio ? (
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    ) : null}
                    <span>
                      {guardandoColegio
                        ? 'Guardando...'
                        : colegioEditandoId
                        ? 'Guardar Cambios'
                        : 'Guardar Colegio'}
                    </span>
                  </button>
                </form>

                <div className="space-y-3">
                  <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider">
                    Colegios Activos ({colegiosList.length})
                  </h3>
                  <div className="divide-y divide-slate-100 max-h-[28rem] overflow-y-auto bg-white rounded-2xl border border-slate-200">
                    {colegiosList.map(c => (
                      <div key={c.id} className="p-3.5 hover:bg-slate-50 transition-colors space-y-1.5">
                        <div className="flex items-center justify-between gap-2">
                          <div>
                            <h4 className="text-xs font-bold text-slate-900">{c.nombre}</h4>
                            <div className="flex items-center gap-2 flex-wrap mt-0.5">
                              <span className="text-[11px] text-slate-500">{c.localidad} ({c.zona})</span>
                              {c.whatsappContacto && (
                                <span className="text-[10px] bg-emerald-100 text-emerald-800 font-mono font-bold px-1.5 py-0.5 rounded">
                                  WA: {c.whatsappContacto}
                                </span>
                              )}
                              {c.muestrasLupa && (
                                <span className="text-[10px] bg-amber-100 text-amber-800 font-bold px-1.5 py-0.5 rounded">Con lupa</span>
                              )}
                            </div>
                          </div>
                          <div className="flex items-center gap-1.5 shrink-0">
                            <span className="px-2 py-0.5 rounded bg-slate-100 font-mono text-xs font-bold text-slate-800">
                              {c.codigoAcceso}
                            </span>
                            <button
                              type="button"
                              onClick={() => handleEditarColegioClick(c)}
                              className="p-1 rounded-lg text-slate-400 hover:text-amber-600 hover:bg-amber-50 transition-colors cursor-pointer"
                              title="Editar colegio"
                            >
                              <Pencil className="w-3.5 h-3.5" />
                            </button>
                            {colegiosList.length > 1 && (
                              <button
                                type="button"
                                disabled={borrandoColegioId === c.id}
                                onClick={() => handleBorrarColegioClick(c)}
                                className="p-1 rounded-lg text-slate-400 hover:text-red-600 hover:bg-red-50 disabled:opacity-50 transition-colors cursor-pointer"
                                title="Eliminar colegio"
                              >
                                {borrandoColegioId === c.id ? (
                                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                                ) : (
                                  <Trash2 className="w-3.5 h-3.5" />
                                )}
                              </button>
                            )}
                          </div>
                        </div>
                        <div className="flex flex-wrap gap-1 text-[10px] text-slate-500">
                          <span className="px-1.5 py-0.5 bg-slate-50 border border-slate-200 rounded">
                            {(c.grados || []).length} grados
                          </span>
                          <span className="px-1.5 py-0.5 bg-slate-50 border border-slate-200 rounded">
                            {(c.divisiones || []).length} divisiones
                          </span>
                          <span className="px-1.5 py-0.5 bg-slate-50 border border-slate-200 rounded">
                            {(c.turnos || []).length} turnos
                          </span>
                        </div>

                        <div className="pt-1.5 mt-1.5 border-t border-slate-100 space-y-1">
                          <p className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">
                            Link de carga de padrón (para la institución)
                          </p>
                          {padronTokens[c.id] ? (
                            <div className="flex items-center gap-1.5">
                              <input
                                type="text"
                                readOnly
                                value={construirLinkPadron(c.id)}
                                onFocus={(e) => e.target.select()}
                                className="flex-1 min-w-0 px-2 py-1 rounded-lg border border-slate-200 bg-slate-50 text-[10px] font-mono text-slate-600"
                              />
                              <button
                                type="button"
                                onClick={() => handleCopiarLinkPadron(c.id)}
                                title="Copiar link"
                                className="p-1.5 rounded-lg text-slate-400 hover:text-amber-600 hover:bg-amber-50 transition-colors cursor-pointer shrink-0"
                              >
                                {copiadoPadronId === c.id ? (
                                  <Check className="w-3.5 h-3.5 text-emerald-600" />
                                ) : (
                                  <Copy className="w-3.5 h-3.5" />
                                )}
                              </button>
                              <button
                                type="button"
                                disabled={regenerandoPadronId === c.id}
                                onClick={() => handleRegenerarPadron(c)}
                                title="Regenerar link (invalida el anterior)"
                                className="p-1.5 rounded-lg text-slate-400 hover:text-red-600 hover:bg-red-50 disabled:opacity-50 transition-colors cursor-pointer shrink-0"
                              >
                                {regenerandoPadronId === c.id ? (
                                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                                ) : (
                                  <RefreshCw className="w-3.5 h-3.5" />
                                )}
                              </button>
                            </div>
                          ) : (
                            <p className="text-[10px] text-slate-400">Cargando link...</p>
                          )}
                          <p className="text-[9px] text-slate-400">
                            Compartilo solo con la institución — ellos cargan ahí los datos de contacto de las familias.
                          </p>
                        </div>
                        {/* 10/10: panel propio del colegio (link + PIN, fechas de la campaña). */}
                        <AdminPanelColegioAcceso colegioId={c.id} colegioNombre={c.nombre} />
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* TAB: CERRAR AÑO (borrado real de temporada, ver services/cierreAnioService.ts) */}
            {activeTab === 'cerrar-anio' && (
              <div className="max-w-2xl space-y-5">
                <div className="p-4 rounded-2xl bg-rose-50 border border-rose-200 flex items-start gap-3">
                  <AlertCircle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
                  <div className="space-y-1">
                    <h3 className="text-sm font-bold text-rose-900">Cerrar año / arrancar temporada nueva</h3>
                    <p className="text-[11px] text-rose-800 leading-relaxed">
                      Esto borra, para el colegio que elijas (o para todos), los datos DE LA TEMPORADA:
                      alumnos, familias, pedidos, fotos y sus archivos en storage, inscripciones, padres
                      autorizados y códigos de sección. El colegio en sí <strong>no</strong> se borra —
                      queda listo para cargarle la nómina y las fotos del año que viene. Es una acción
                      irreversible sobre datos reales: no hay forma de deshacerla.
                    </p>
                  </div>
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-700">Colegio a cerrar</label>
                  <select
                    value={cierreAnioColegioId}
                    onChange={(e) => {
                      setCierreAnioColegioId(e.target.value);
                      setCierreAnioResumen(null);
                      setResultadoCierreAnio(null);
                      setErrorCierreAnio(null);
                      setTextoConfirmacionCierre('');
                      setBloqueosCierreAnio(null);
                      setCierreRequiereForzar(false);
                    }}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs bg-white"
                  >
                    {colegiosList.map((c) => (
                      <option key={c.id} value={c.id}>{c.nombre}</option>
                    ))}
                    <option value="todos">— Todos los colegios —</option>
                  </select>
                </div>

                <button
                  type="button"
                  onClick={handleVerResumenCierreAnio}
                  disabled={!cierreAnioColegioId || cargandoResumenCierre}
                  className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-900 disabled:opacity-50 text-white font-bold text-xs shadow flex items-center gap-1.5 cursor-pointer"
                >
                  {cargandoResumenCierre ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Eye className="w-3.5 h-3.5" />}
                  <span>{cargandoResumenCierre ? 'Calculando...' : 'Ver qué se borraría'}</span>
                </button>

                {errorCierreAnio && (
                  <div className="p-2.5 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-[11px] font-semibold flex items-center gap-1.5">
                    <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                    <span>{errorCierreAnio}</span>
                  </div>
                )}

                {resultadoCierreAnio && (
                  <div className="p-3.5 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-900 text-xs space-y-1">
                    <p className="font-bold">Año cerrado correctamente.</p>
                    <p>
                      Se borraron {resultadoCierreAnio.alumnos} alumnos, {resultadoCierreAnio.familias} familias,{' '}
                      {resultadoCierreAnio.pedidos} pedidos y {resultadoCierreAnio.fotos} fotos (con sus archivos).
                    </p>
                    {!!resultadoCierreAnio.pedidosPreservados && (
                      <p>
                        Se conservaron {resultadoCierreAnio.pedidosPreservados} pedido(s) cobrado(s), archivados para la liquidación al colegio.
                      </p>
                    )}
                  </div>
                )}

                {cierreAnioResumen && (
                  <div className="p-4 rounded-2xl bg-white border-2 border-rose-200 space-y-4">
                    <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                      Se va a borrar de "{cierreAnioNombreConfirmado}"
                    </h4>
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 text-center">
                      {[
                        ['Alumnos', cierreAnioResumen.alumnos],
                        ['Familias', cierreAnioResumen.familias],
                        ['Pedidos', cierreAnioResumen.pedidos],
                        ['Fotos', cierreAnioResumen.fotos],
                        ['Fotos en pedidos', cierreAnioResumen.pedidoFotos],
                        ['Inscripciones', cierreAnioResumen.inscripciones],
                        ['Padres autorizados', cierreAnioResumen.padresAutorizados],
                        ['Códigos de sección', cierreAnioResumen.codigosSeccion],
                        ['Solicitudes de código', cierreAnioResumen.solicitudesCodigo],
                        ...(cierreAnioResumen.pedidosPreservados ? [['Pedidos cobrados (se conservan)', cierreAnioResumen.pedidosPreservados]] : []),
                      ].map(([label, valor]) => (
                        <div key={label as string} className="p-2 rounded-xl bg-slate-50 border border-slate-200">
                          <div className="text-lg font-black text-slate-900">{valor as number}</div>
                          <div className="text-[9px] text-slate-500 font-bold uppercase">{label}</div>
                        </div>
                      ))}
                    </div>

                    <div className="pt-2 border-t border-slate-200 space-y-1.5">
                      <label className="text-xs font-bold text-slate-700">
                        Para confirmar, escribí exactamente: <span className="font-mono text-rose-700">{fraseConfirmacionCierreAnio}</span>
                      </label>
                      <input
                        type="text"
                        value={textoConfirmacionCierre}
                        onChange={(e) => setTextoConfirmacionCierre(e.target.value)}
                        placeholder={fraseConfirmacionCierreAnio}
                        className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs bg-white font-mono"
                      />
                    </div>

                    <button
                      type="button"
                      disabled={
                        ejecutandoCierreAnio ||
                        textoConfirmacionCierre.trim().toLowerCase() !== fraseConfirmacionCierreAnio.trim().toLowerCase()
                      }
                      onClick={() => handleEjecutarCierreAnio()}
                      className="w-full py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 disabled:opacity-40 text-white font-bold text-xs shadow flex items-center justify-center gap-1.5 cursor-pointer"
                    >
                      {ejecutandoCierreAnio ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Trash2 className="w-3.5 h-3.5" />}
                      <span>{ejecutandoCierreAnio ? 'Cerrando año...' : 'Cerrar año (borrado definitivo)'}</span>
                    </button>

                    {bloqueosCierreAnio && (
                      <div className="p-3 rounded-xl bg-amber-50 border border-amber-300 text-amber-900 text-[11px] space-y-2">
                        <p className="font-bold flex items-center gap-1.5">
                          <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                          <span>Hay pedidos que frenan el cierre:</span>
                        </p>
                        <ul className="list-disc pl-5 space-y-0.5">
                          <li><strong>{bloqueosCierreAnio.pagadosSinEntregar}</strong> pedido(s) pagado(s) todavía sin imprimir/entregar</li>
                          <li><strong>{bloqueosCierreAnio.pendientesRecientes}</strong> pedido(s) pendiente(s) de pago con movimiento en las últimas 48 h</li>
                        </ul>
                        {cierreRequiereForzar && (
                          <button
                            type="button"
                            disabled={
                              ejecutandoCierreAnio ||
                              textoConfirmacionCierre.trim().toLowerCase() !== fraseConfirmacionCierreAnio.trim().toLowerCase()
                            }
                            onClick={() => handleEjecutarCierreAnio(true)}
                            className="w-full py-2 rounded-xl bg-amber-600 hover:bg-amber-700 disabled:opacity-40 text-white font-bold text-xs shadow flex items-center justify-center gap-1.5 cursor-pointer"
                          >
                            {ejecutandoCierreAnio ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Trash2 className="w-3.5 h-3.5" />}
                            <span>Cerrar igual</span>
                          </button>
                        )}
                      </div>
                    )}
                  </div>
                )}
              </div>
            )}

            {/* TAB: WHATSAPP CONFIG & SUPABASE */}
            {activeTab === 'whatsapp' && (
              <>
                {/* SECCIÓN WHATSAPP: CAMPO DE ENTRADA Y BOTÓN GUARDAR EN TABLA 'configuracion' DE SUPABASE.
                    Antes estaba siempre visible arriba del todo; se usa poco, así que ahora vive
                    dentro de esta pestaña. */}
                <div className="bg-white rounded-2xl p-4 sm:p-5 border-2 border-emerald-500/40 shadow-xs space-y-3.5 relative overflow-hidden mb-4">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center shrink-0">
                        <Phone className="w-5 h-5" />
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <h4 className="text-sm font-black text-slate-900 font-['Outfit']">
                            Número de WhatsApp (Widget Flotante & Atención)
                          </h4>
                          <span className="text-[10px] font-mono font-bold bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-full border border-emerald-300 flex items-center gap-1">
                            <Database className="w-2.5 h-2.5" />
                            <span>Supabase: configuracion</span>
                          </span>
                        </div>
                        <p className="text-xs text-slate-500">
                          Ingresá el número de teléfono con código de país para guardarlo de manera persistente en Supabase y sincronizarlo al instante con el widget flotante.
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 text-xs text-slate-500 bg-slate-50 px-3 py-1.5 rounded-xl border border-slate-200 shrink-0">
                      <span>Actual:</span>
                      <strong className="font-mono text-emerald-700 font-bold">
                        {formatearNumeroVisual(whatsappNumero)}
                      </strong>
                    </div>
                  </div>

                  <form onSubmit={handleGuardarWhatsApp} className="flex flex-col sm:flex-row gap-2.5 items-stretch sm:items-center">
                    <div className="relative flex-1">
                      <div className="absolute left-3.5 top-3 flex items-center pointer-events-none text-slate-400">
                        <Globe className="w-4 h-4 text-emerald-600" />
                      </div>
                      <input
                        id="admin-modal-input-whatsapp"
                        type="text"
                        required
                        value={whatsappNumero}
                        onChange={(e) => setWhatsappNumero(e.target.value)}
                        placeholder="Ej: +54 9 11 1234-5678 o 5491112345678"
                        className="w-full pl-10 pr-4 py-2.5 rounded-xl border-2 border-emerald-500/40 text-sm font-mono font-bold text-slate-900 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-600 bg-emerald-50/20 transition-all"
                      />
                    </div>

                    <button
                      id="admin-modal-btn-guardar-whatsapp"
                      type="submit"
                      disabled={whatsappGuardando || !whatsappNumero.trim()}
                      className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 active:scale-95 disabled:opacity-50 text-white font-bold text-xs sm:text-sm rounded-xl shadow-md shadow-emerald-600/20 transition-all flex items-center justify-center gap-2 cursor-pointer shrink-0"
                    >
                      <Save className="w-4 h-4" />
                      <span>{whatsappGuardando ? 'Guardando...' : 'Guardar en Supabase'}</span>
                    </button>
                  </form>

                  {whatsappFeedback && (
                    <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-300 text-emerald-900 text-xs font-semibold flex items-center gap-2 animate-in fade-in">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                      <span>{whatsappFeedback}</span>
                    </div>
                  )}

                  {whatsappError && (
                    <div className="p-3 rounded-xl bg-rose-50 border border-rose-300 text-rose-900 text-xs font-semibold flex items-center gap-2 animate-in fade-in">
                      <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                      <span>{whatsappError}</span>
                    </div>
                  )}
                </div>

                <AdminConfigWhatsAppTab />
              </>
            )}

          </div>
        )}

        {/* Printable & Cutout Notes Modal */}
        <CircularImprimibleModal
          isOpen={mostrarCircularModal}
          onClose={() => setMostrarCircularModal(false)}
          secciones={seccionesCodigosReales}
          codigosMap={codigosRealesMap}
          colegioNombre={colegioCodigosNombre}
          seccionSeleccionadaInicial={seccionParaCircular}
        />

      </div>
    </div>
  );
}
