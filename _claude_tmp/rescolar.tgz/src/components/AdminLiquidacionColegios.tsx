import { useEffect, useRef, useState } from 'react';
import { Calculator, Download, Loader2, RefreshCw, Save } from 'lucide-react';
import {
  actualizarComisionesReales,
  guardarCostosLiquidacion,
  guardarPorcentajeColegio,
  obtenerCostosLiquidacion,
  obtenerLiquidacionColegio,
  useColegiosLista,
  type CostosLiquidacion,
  type Liquidacion,
} from '../services/colegiosService';
import { descargarCSV } from '../services/excelDownloadHelper';
import AdminGastosPlataforma from './AdminGastosPlataforma';

/**
 * Liquidación al colegio (pedido de Pablo 1/10): el colegio se lleva un % de la GANANCIA NETA, no de
 * la venta (cláusula OCTAVA BIS del convenio). Ganancia neta = lo cobrado − impresión del laboratorio
 * (precio fijo por carpeta y por copia) − comisión del medio de cobro − impuestos. Se liquida una vez,
 * al cerrar la temporada del colegio. El cálculo lo hace el servidor (GET /api/admin/liquidacion).
 */
const CAMPOS: { k: keyof CostosLiquidacion; etiqueta: string; pct?: boolean }[] = [
  { k: 'costo_carpeta', etiqueta: 'Carpeta impresa (sin las fotos)' },
  { k: 'costo_foto_20x30', etiqueta: 'Copia 20x30' },
  { k: 'costo_foto_15x21', etiqueta: 'Copia 15x21' },
  { k: 'comision_mercadopago_pct', etiqueta: 'Comisión Mercado Pago', pct: true },
  { k: 'comision_nave_pct', etiqueta: 'Comisión Nave', pct: true },
  // Convenio 2/10, OCTAVA BIS (iii): sólo percepciones/retenciones que no se puedan computar ni recuperar.
  // Siendo monotributista, normalmente 0%: confirmarlo con el contador.
  { k: 'impuestos_pct', etiqueta: 'Retenciones no recuperables (consultar al contador)', pct: true },
];

// Período de la liquidación (convenio OCTAVA BIS b): por fecha de cobro. "Temporada" = 1/1 al 31/12;
// "Complementaria" = lo cobrado después, del 1/1 al 30/6 del año siguiente.
const ANIO_ACTUAL = new Date().getFullYear();
type TipoPeriodo = 'temporada' | 'complementaria';
function rangoPeriodo(anio: number, tipo: TipoPeriodo) {
  return tipo === 'temporada' ? { desde: `${anio}-01-01`, hasta: `${anio}-12-31` } : { desde: `${anio + 1}-01-01`, hasta: `${anio + 1}-06-30` };
}
const fechaCorta = (iso: string | null | undefined) => (iso ? new Date(`${iso.length === 10 ? `${iso}T12:00:00` : iso}`).toLocaleDateString('es-AR') : '');
const NOMBRE_MEDIO: Record<string, string> = { mercadopago: 'Mercado Pago', nave: 'Nave', transferencia: 'Transferencia', efectivo: 'Efectivo' };

const pesos = (n: number) => `$${(Number(n) || 0).toLocaleString('es-AR', { minimumFractionDigits: 0, maximumFractionDigits: 2 })}`;

export default function AdminLiquidacionColegios() {
  const { colegios } = useColegiosLista();
  const [costos, setCostos] = useState<Record<string, string>>({});
  const [guardandoCostos, setGuardandoCostos] = useState(false);
  const [mensajeCostos, setMensajeCostos] = useState<string | null>(null);
  const [colegioId, setColegioId] = useState('');
  const [liq, setLiq] = useState<Liquidacion | null>(null);
  const [cargando, setCargando] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [porcentaje, setPorcentaje] = useState('');
  const [mensajePorcentaje, setMensajePorcentaje] = useState<string | null>(null);
  const [anio, setAnio] = useState(ANIO_ACTUAL);
  const [tipoPeriodo, setTipoPeriodo] = useState<TipoPeriodo>('temporada');
  const [actualizandoComisiones, setActualizandoComisiones] = useState(false);
  const [mensajeComisiones, setMensajeComisiones] = useState<string | null>(null);
  const rango = rangoPeriodo(anio, tipoPeriodo);
  // Auditoría 03/10 noche (R8): consulta vigente (colegio + período). Si se cambia de colegio o de
  // período mientras el servidor contesta, la respuesta vieja se descarta: antes podía pisar la
  // pantalla con los datos del colegio anterior, y entonces "Guardar %" grababa ese porcentaje en el
  // colegio nuevo y el CSV salía del colegio anterior.
  const consultaVigente = useRef<{ n: number; colegioId: string; desde: string; hasta: string }>({ n: 0, colegioId: '', desde: '', hasta: '' });
  const colegioIdActual = useRef(colegioId);
  colegioIdActual.current = colegioId;
  // Período elegido AHORA (calcular se llama también después de un await, desde un render viejo).
  const rangoActual = useRef(rango);
  rangoActual.current = rango;
  /** La liquidación en pantalla es del colegio y período elegidos ahora. */
  const liqEsDeLaSeleccion = Boolean(
    liq && liq.colegio?.id === colegioId && liq.periodo?.desde === rango.desde && liq.periodo?.hasta === rango.hasta
  );

  useEffect(() => {
    obtenerCostosLiquidacion().then((c) => {
      if (c) setCostos(Object.fromEntries(Object.entries(c).map(([k, v]) => [k, String(v)])));
    });
  }, []);

  // 08/10: la lista arranca con un colegio de muestra (COLEGIO_POR_DEFECTO, id inventado) hasta que
  // llega la real. Antes se quedaba con ese id y el servidor respondía "Colegio no encontrado.":
  // ahora, si el elegido no está en la lista, se pasa al primero real (igual que AdminPadronTab).
  useEffect(() => {
    if (colegios.length > 0 && (!colegioId || !colegios.some((c) => c.id === colegioId))) {
      setColegioId(colegios[0].id);
    }
  }, [colegios, colegioId]);

  const calcular = async (id = colegioIdActual.current) => {
    if (!id) return;
    const { desde, hasta } = rangoActual.current;
    const anterior = consultaVigente.current;
    const consulta = { n: anterior.n + 1, colegioId: id, desde, hasta };
    consultaVigente.current = consulta;
    // Otro colegio/período: se limpia lo anterior para que nada (ni el % ni el CSV) quede del otro.
    if (anterior.colegioId !== id || anterior.desde !== desde || anterior.hasta !== hasta) {
      setLiq(null);
      setPorcentaje('');
      setMensajePorcentaje(null);
    }
    setCargando(true);
    setError(null);
    const r = await obtenerLiquidacionColegio(id, desde, hasta);
    if (consultaVigente.current.n !== consulta.n) return; // respuesta vieja: se descarta
    setCargando(false);
    if (!r.success || !r.liquidacion) {
      setLiq(null);
      return setError(r.error || 'No se pudo calcular.');
    }
    if (r.liquidacion.colegio?.id && r.liquidacion.colegio.id !== id) return; // por las dudas
    setLiq(r.liquidacion);
    setPorcentaje(String(r.liquidacion.porcentaje));
  };

  useEffect(() => {
    if (colegioId) void calcular(colegioId);
    setMensajeComisiones(null);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [colegioId, anio, tipoPeriodo]);

  // Trae de Mercado Pago / Nave la comisión real de cada pago (en tandas, hasta terminar).
  const traerComisionesReales = async () => {
    // Se fijan colegio y período al empezar, por si se cambian mientras corre.
    const id = colegioId;
    const { desde, hasta } = rango;
    setActualizandoComisiones(true);
    setMensajeComisiones(null);
    const acumulado = { real: 0, sinDato: 0, errores: 0 };
    let terminado = false;
    let quedan = 0;
    for (let vuelta = 0; vuelta < 20; vuelta++) {
      const r = await actualizarComisionesReales(id, desde, hasta);
      if (!r.success) {
        setMensajeComisiones(r.error || 'No se pudieron actualizar las comisiones.');
        terminado = true;
        break;
      }
      quedan = r.pendientes || 0;
      acumulado.real += r.real || 0;
      acumulado.sinDato += r.sinDato || 0;
      acumulado.errores += r.errores || 0;
      if (!r.pendientes) {
        const partes = [`${acumulado.real} pago(s) con comisión real`];
        if (acumulado.sinDato) partes.push(`${acumulado.sinDato} sin el dato en la pasarela (se estiman con el %)`);
        if (acumulado.errores) partes.push(`${acumulado.errores} con error de conexión (probá de nuevo más tarde)`);
        setMensajeComisiones(`Listo: ${partes.join(', ')}.`);
        terminado = true;
        break;
      }
    }
    if (!terminado) setMensajeComisiones(`Quedan ${quedan} pago(s) por revisar: volvé a tocar el botón.`);
    setActualizandoComisiones(false);
    // Auditoría 03/10 noche (R8): antes comparaba contra el colegioId capturado al empezar (siempre
    // igual). Ahora contra el colegio elegido AHORA.
    if (id === colegioIdActual.current) void calcular(id);
  };

  const guardarCostos = async () => {
    setGuardandoCostos(true);
    setMensajeCostos(null);
    const r = await guardarCostosLiquidacion(costos);
    setGuardandoCostos(false);
    setMensajeCostos(r.success ? 'Costos guardados.' : r.error || 'No se pudieron guardar.');
    if (r.success) void calcular();
  };

  const guardarPorcentaje = async () => {
    // Auditoría 03/10 noche (R8): sólo con la liquidación del colegio elegido a la vista (si no, el %
    // del cuadro podía ser el del colegio anterior) y se graba en el colegio de ESA liquidación.
    if (!liq || !liqEsDeLaSeleccion || cargando) {
      setMensajePorcentaje('Esperá a que termine de cargar la liquidación de este colegio.');
      return;
    }
    const id = liq.colegio.id;
    setMensajePorcentaje(null);
    const r = await guardarPorcentajeColegio(id, porcentaje);
    if (id !== colegioIdActual.current) return; // se cambió de colegio mientras se guardaba
    setMensajePorcentaje(r.success ? 'Porcentaje guardado.' : r.error || 'No se pudo guardar.');
    if (r.success) void calcular(id);
  };

  const descargar = () => {
    // Auditoría 03/10 noche (R8): nunca el CSV de otro colegio o período.
    if (!liq || !liqEsDeLaSeleccion) return;
    // Este CSV es el que se manda al colegio: sin nombres de alumnos (convenio, OCTAVA BIS c).
    const filas: Record<string, string | number>[] = liq.filas.map((f) => ({
      Pedido: f.pedido,
      'Fecha de cobro': fechaCorta(f.pagado || f.fecha),
      Curso: f.curso,
      Kit: f.kit,
      'Medio de pago': NOMBRE_MEDIO[f.medio] || f.medio,
      'Cobrado ($)': f.venta,
      Carpetas: f.carpetas,
      'Copias 20x30': f.fotos20x30,
      'Copias 15x21': f.fotos15x21,
      'Impresión lab ($)': f.costoLaboratorio,
      'Comisión cobro ($)': f.comision,
      'Comisión': f.comisionOrigen === 'real' ? 'Real (informada por la pasarela)' : f.comisionOrigen === 'estimada' ? 'Estimada (%)' : 'Sin comisión',
      'Impuestos ($)': f.impuestos,
      'Ganancia neta ($)': f.ganancia,
      Observación: f.fotosPendientes ? 'Reserva sin fotos elegidas: el costo de impresión puede cambiar' : '',
    }));
    if (liq.gastosPlataforma && liq.totales.gastosPlataforma > 0) {
      filas.push({
        Pedido: 'Gastos de la plataforma',
        'Fecha de cobro': '',
        Curso: '',
        Kit: '',
        'Medio de pago': '',
        'Cobrado ($)': '',
        Carpetas: '',
        'Copias 20x30': '',
        'Copias 15x21': '',
        'Impresión lab ($)': '',
        'Comisión cobro ($)': '',
        'Comisión': '',
        'Impuestos ($)': '',
        'Ganancia neta ($)': -liq.totales.gastosPlataforma,
        Observación: `Convenio OCTAVA BIS (iv): ${(liq.gastosPlataforma.proporcion * 100).toFixed(2)}% de $${liq.gastosPlataforma.gastosPeriodo} pagados en el período${liq.gastosPlataforma.topeAplicado ? `, con tope del ${liq.gastosPlataforma.topePct}% de lo cobrado` : ''}`,
      });
    }
    filas.push({
      Pedido: 'TOTAL',
      'Fecha de cobro': '',
      Curso: '',
      Kit: '',
      'Medio de pago': '',
      'Cobrado ($)': liq.totales.venta,
      Carpetas: liq.filas.reduce((a, f) => a + f.carpetas, 0),
      'Copias 20x30': liq.filas.reduce((a, f) => a + f.fotos20x30, 0),
      'Copias 15x21': liq.filas.reduce((a, f) => a + f.fotos15x21, 0),
      'Impresión lab ($)': liq.totales.costoLaboratorio,
      'Comisión cobro ($)': liq.totales.comision,
      'Comisión': '',
      'Impuestos ($)': liq.totales.impuestos,
      'Ganancia neta ($)': liq.totales.ganancia,
      Observación: `Participación del colegio (${liq.porcentaje}% de la ganancia neta): $${liq.participacion}`,
    });
    // Resumen por medio de cobro, para cruzar con los reportes de cada pasarela.
    for (const m of liq.resumenPorMedio) {
      filas.push({
        Pedido: `Resumen ${NOMBRE_MEDIO[m.medio] || m.medio}`,
        'Fecha de cobro': '',
        Curso: '',
        Kit: `${m.pedidos} pedido(s)`,
        'Medio de pago': NOMBRE_MEDIO[m.medio] || m.medio,
        'Cobrado ($)': m.cobrado,
        Carpetas: '',
        'Copias 20x30': '',
        'Copias 15x21': '',
        'Impresión lab ($)': '',
        'Comisión cobro ($)': m.comision,
        'Comisión': m.comisionesEstimadas ? `${m.comisionesEstimadas} estimada(s)` : 'Real',
        'Impuestos ($)': '',
        'Ganancia neta ($)': '',
        Observación: m.retencionesInformadas ? `Retenciones informadas por la pasarela: $${m.retencionesInformadas} (no se descuentan salvo que no sean recuperables)` : '',
      });
    }
    const topes = liq.topesAnexoIV;
    filas.push({
      Pedido: 'Período',
      'Fecha de cobro': `${fechaCorta(liq.periodo.desde)} al ${fechaCorta(liq.periodo.hasta)}`,
      Curso: '', Kit: '', 'Medio de pago': '', 'Cobrado ($)': '', Carpetas: '', 'Copias 20x30': '', 'Copias 15x21': '',
      'Impresión lab ($)': '', 'Comisión cobro ($)': '', 'Comisión': '', 'Impuestos ($)': '', 'Ganancia neta ($)': '',
      Observación: topes
        ? `Precios de impresión usados (tope Anexo IV): carpeta $${liq.costos.costo_carpeta}, 20x30 $${liq.costos.costo_foto_20x30}, 15x21 $${liq.costos.costo_foto_15x21}`
        : `Precios de impresión usados: carpeta $${liq.costos.costo_carpeta}, 20x30 $${liq.costos.costo_foto_20x30}, 15x21 $${liq.costos.costo_foto_15x21}`,
    });
    descargarCSV(filas, `liquidacion-${liq.colegio.nombre.replace(/[^\w]+/g, '-').toLowerCase()}-${liq.periodo.desde}-al-${liq.periodo.hasta}`);
  };

  return (
    <div className="bg-white rounded-2xl border border-slate-200 p-4 sm:p-5 space-y-4">
      <div>
        <h4 className="text-xs font-extrabold text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
          <Calculator className="w-4 h-4 text-slate-500" />
          <span>Liquidación al colegio (% de la ganancia neta)</span>
        </h4>
        <p className="text-[11px] text-slate-500 mt-1">
          Ganancia neta = lo cobrado − impresión del laboratorio − comisión del medio de cobro − impuestos − gastos de la plataforma
          (este último, sólo a los colegios que firmaron el convenio 2026-10-30). Sólo cuentan los pedidos
          pagados (no los cancelados ni devueltos). Se liquida al cerrar la temporada del colegio (cláusula OCTAVA BIS del convenio).
        </p>
      </div>

      <div className="rounded-xl border border-slate-200 bg-slate-50 p-3 space-y-2">
        <p className="text-[11px] font-bold text-slate-700">Costos que se descuentan (valen para todos los colegios)</p>
        <p className="text-[10px] text-slate-500">
          Los 3 precios de impresión son el Anexo IV del convenio: el colegio no puede firmar hasta que estén cargados, y en
          su liquidación nunca se descuenta más que lo que figuraba al firmar.
        </p>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
          {CAMPOS.map((c) => (
            <label key={c.k} className="text-[11px] text-slate-600">
              {c.etiqueta} {c.pct ? '(%)' : '($)'}
              <input
                type="number"
                min="0"
                step="0.01"
                value={costos[c.k] ?? ''}
                onChange={(e) => setCostos((a) => ({ ...a, [c.k]: e.target.value }))}
                className="mt-0.5 w-full rounded-lg border border-slate-300 px-2 py-1.5 text-xs"
              />
            </label>
          ))}
        </div>
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => void guardarCostos()}
            disabled={guardandoCostos}
            className="inline-flex items-center gap-1.5 rounded-lg bg-slate-900 px-3 py-1.5 text-xs font-bold text-white disabled:opacity-60"
          >
            {guardandoCostos ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Save className="w-3.5 h-3.5" />} Guardar costos
          </button>
          {mensajeCostos && <span className="text-[11px] text-slate-600">{mensajeCostos}</span>}
        </div>
        <p className="text-[10px] text-slate-400">
          La impresión se cuenta como el laboratorio: cada carpeta lleva 1 copia 20x30 (grupal) y 1 o 2 copias 15x21 (individual y con la seño);
          las fotos sueltas van en 15x21. Las transferencias no tienen comisión.
        </p>
      </div>

      <AdminGastosPlataforma
        desde={rango.desde}
        hasta={rango.hasta}
        onCambio={() => {
          if (colegioIdActual.current) calcular();
        }}
      />

      <div className="flex flex-col sm:flex-row sm:items-end gap-2">
        <label className="text-[11px] text-slate-600 flex-1">
          Colegio
          <select value={colegioId} onChange={(e) => setColegioId(e.target.value)} className="mt-0.5 w-full rounded-lg border border-slate-300 px-2 py-1.5 text-xs">
            {colegios.map((c) => (
              <option key={c.id} value={c.id}>{c.nombre}</option>
            ))}
          </select>
        </label>
        <label className="text-[11px] text-slate-600 sm:w-40">
          % para el colegio
          <input
            type="number"
            min="0"
            max="100"
            step="0.5"
            value={porcentaje}
            disabled={Boolean(liq?.porcentajeDelConvenio)}
            onChange={(e) => setPorcentaje(e.target.value)}
            className="mt-0.5 w-full rounded-lg border border-slate-300 px-2 py-1.5 text-xs disabled:bg-slate-100"
          />
        </label>
        {!liq?.porcentajeDelConvenio && (
          <button type="button" onClick={() => void guardarPorcentaje()} disabled={!liqEsDeLaSeleccion || cargando} className="rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-xs font-bold text-slate-800 disabled:opacity-50">
            Guardar %
          </button>
        )}
      </div>
      {liq?.porcentajeDelConvenio && liq.convenioFirmado && (
        <p className="text-[11px] text-emerald-700">
          El {liq.porcentaje}% quedó fijado en el convenio que firmó {liq.convenioFirmado.razonSocial} el {new Date(liq.convenioFirmado.fecha).toLocaleDateString('es-AR')}.
        </p>
      )}
      {mensajePorcentaje && <p className="text-[11px] text-slate-600">{mensajePorcentaje} Antes de que el colegio firme, este es el % que va a ver en el convenio.</p>}
      <div className="flex flex-col sm:flex-row sm:items-end gap-2">
        <label className="text-[11px] text-slate-600 sm:w-32">
          Temporada
          <select value={anio} onChange={(e) => setAnio(Number(e.target.value))} className="mt-0.5 w-full rounded-lg border border-slate-300 px-2 py-1.5 text-xs">
            {[ANIO_ACTUAL - 1, ANIO_ACTUAL, ANIO_ACTUAL + 1].map((a) => (
              <option key={a} value={a}>{a}</option>
            ))}
          </select>
        </label>
        <label className="text-[11px] text-slate-600 flex-1">
          Liquidación
          <select value={tipoPeriodo} onChange={(e) => setTipoPeriodo(e.target.value as TipoPeriodo)} className="mt-0.5 w-full rounded-lg border border-slate-300 px-2 py-1.5 text-xs">
            <option value="temporada">Temporada: cobrado del 1/1/{anio} al 31/12/{anio}</option>
            <option value="complementaria">Complementaria: cobrado del 1/1/{anio + 1} al 30/6/{anio + 1}</option>
          </select>
        </label>
      </div>

      {cargando ? (
        <div className="py-4 text-center text-slate-400"><Loader2 className="w-5 h-5 mx-auto animate-spin" /></div>
      ) : error ? (
        <p className="text-xs text-red-600">{error}</p>
      ) : liq ? (
        <div className="space-y-2">
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 text-xs">
            <div className="rounded-lg bg-slate-50 p-2"><p className="text-slate-500">Cobrado ({liq.totales.pedidos} pedidos)</p><p className="font-bold">{pesos(liq.totales.venta)}</p></div>
            <div className="rounded-lg bg-slate-50 p-2"><p className="text-slate-500">Impresión laboratorio</p><p className="font-bold">− {pesos(liq.totales.costoLaboratorio)}</p></div>
            <div className="rounded-lg bg-slate-50 p-2"><p className="text-slate-500">Comisiones de cobro</p><p className="font-bold">− {pesos(liq.totales.comision)}</p></div>
            <div className="rounded-lg bg-slate-50 p-2"><p className="text-slate-500">Impuestos</p><p className="font-bold">− {pesos(liq.totales.impuestos)}</p></div>
            <div className="rounded-lg bg-slate-50 p-2">
              <p className="text-slate-500">Gastos de la plataforma</p>
              {liq.gastosPlataforma ? (
                <>
                  <p className="font-bold">− {pesos(liq.gastosPlataforma.asignado)}</p>
                  <p className="text-[10px] text-slate-500">
                    {(liq.gastosPlataforma.proporcion * 100).toLocaleString('es-AR', { maximumFractionDigits: 2 })}% de {pesos(liq.gastosPlataforma.gastosPeriodo)}
                    {liq.gastosPlataforma.topeAplicado ? ` · con tope ${liq.gastosPlataforma.topePct}%` : ''}
                  </p>
                </>
              ) : (
                <p className="text-[10px] text-slate-500">No se descuentan: su convenio es anterior al 30/10/2026.</p>
              )}
            </div>
            <div className="rounded-lg bg-slate-50 p-2"><p className="text-slate-500">Ganancia neta</p><p className="font-bold">{pesos(liq.totales.ganancia)}</p></div>
            <div className="rounded-lg bg-amber-100 p-2"><p className="text-amber-800">Para el colegio ({liq.porcentaje}%)</p><p className="font-extrabold text-amber-900">{pesos(liq.participacion)}</p></div>
          </div>
          {liq.resumenPorMedio.length > 0 && (
            <div className="overflow-x-auto">
              <table className="w-full text-[11px]">
                <thead>
                  <tr className="text-left text-slate-500">
                    <th className="py-1 pr-2">Medio de cobro</th><th className="py-1 pr-2">Pedidos</th><th className="py-1 pr-2">Cobrado</th><th className="py-1 pr-2">Comisión</th><th className="py-1">Retenciones informadas</th>
                  </tr>
                </thead>
                <tbody>
                  {liq.resumenPorMedio.map((m) => (
                    <tr key={m.medio} className="border-t border-slate-100">
                      <td className="py-1 pr-2 font-semibold">{NOMBRE_MEDIO[m.medio] || m.medio}</td>
                      <td className="py-1 pr-2">{m.pedidos}</td>
                      <td className="py-1 pr-2">{pesos(m.cobrado)}</td>
                      <td className="py-1 pr-2">{pesos(m.comision)}{m.comisionesEstimadas ? <span className="text-amber-700"> ({m.comisionesEstimadas} estimada{m.comisionesEstimadas === 1 ? '' : 's'})</span> : null}</td>
                      <td className="py-1">{m.retencionesInformadas ? pesos(m.retencionesInformadas) : '—'}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
          {(liq.comisionesEstimadas > 0 || liq.comisionesPorActualizar > 0) && (
            <div className="rounded-lg border border-amber-200 bg-amber-50 p-2 space-y-1.5">
              <p className="text-[11px] text-amber-800">
                {liq.comisionesEstimadas} pedido(s) tienen la comisión estimada con el %. Traé la comisión real de Mercado Pago / Nave antes de mandarle la liquidación al colegio.
              </p>
              <button
                type="button"
                onClick={() => void traerComisionesReales()}
                disabled={actualizandoComisiones}
                className="inline-flex items-center gap-1.5 rounded-lg bg-slate-900 px-3 py-1.5 text-xs font-bold text-white disabled:opacity-60"
              >
                {actualizandoComisiones ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <RefreshCw className="w-3.5 h-3.5" />} Traer comisiones reales
              </button>
            </div>
          )}
          {mensajeComisiones && <p className="text-[11px] text-slate-600">{mensajeComisiones}</p>}
          <p className="text-[10px] text-slate-400">
            Las retenciones que informa la pasarela (p. ej. Ingresos Brutos) no se descuentan solas: sólo se descuentan con el % de
            "Retenciones no recuperables" si tu contador confirma que no las podés recuperar.
          </p>
          {liq.pedidosConFotosPendientes > 0 && (
            <p className="text-[11px] text-amber-700">
              {liq.pedidosConFotosPendientes} reserva(s) todavía no eligieron fotos: su costo de impresión puede cambiar. Liquidá cuando estén todas elegidas.
            </p>
          )}
          <button
            type="button"
            onClick={descargar}
            disabled={liq.filas.length === 0 || !liqEsDeLaSeleccion}
            className="inline-flex items-center gap-1.5 rounded-lg bg-amber-400 px-3 py-1.5 text-xs font-bold text-slate-950 disabled:opacity-50"
          >
            <Download className="w-3.5 h-3.5" /> Descargar detalle para el colegio (Excel)
          </button>
        </div>
      ) : null}
    </div>
  );
}
