import { useCallback, useEffect, useRef, useState } from 'react';
import { CheckCircle2, FolderDown, ImagePlus, Loader2, Printer } from 'lucide-react';
import { fetchLab, marcarLoteEnProduccion, SesionLabVencida } from '../services/laboratorioService';

/**
 * Lotes de FOTOS EXTRA en el panel del laboratorio (29/10/2026, pedido de Pablo: «que esos pedidos se impriman en
 * otro lote para que no se mezcle con los kit»). Las fotos extra son copias sueltas (15x21 / 20x30) que las familias
 * piden aparte con el kit ya pagado. Nunca entran en los lotes de kits: acá se arma su propio lote numerado y se baja
 * un ZIP con una carpeta por tamaño (un archivo por copia) + LISTA_ENSOBRADO.csv. Habla con /api/lab/extras/…
 * (servidor/panel/laboratorioExtras.ts); «Marcar en producción» usa la misma ruta que los kits.
 */
interface LoteExtras {
  id: string;
  numero: number;
  created_at: string;
  cantidad: number;
  en_produccion_at: string | null;
  fotos_15x21: number;
  fotos_20x30: number;
}

interface ArchivoManifiesto {
  carpeta: string;
  nombre: string;
  url: string | null;
  pedido: string;
  alumno: string;
  curso: string;
  numeroLista: number | null;
  copia: number;
  copias: number;
}

interface Props {
  onError: (e: unknown) => void;
  recargarCon?: unknown;
  onPendientes?: (n: number) => void;
}

function guardarBlob(blob: Blob, nombre: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = nombre;
  document.body.appendChild(a);
  a.click();
  setTimeout(() => {
    URL.revokeObjectURL(url);
    a.remove();
  }, 5000);
}

async function leerJson(res: Response) {
  const data = await res.json().catch(() => null);
  if (!res.ok || !data?.success) throw new Error(data?.error || 'Algo salió mal. Probá de nuevo.');
  return data;
}

/** Planilla para ensobrar (CSV con «;» y BOM: Excel en castellano lo abre directo). */
export function planillaEnsobrado(archivos: ArchivoManifiesto[]): string {
  const filas = new Map<string, { curso: string; numero: string; alumno: string; pedido: string; tam: string; copias: number; archivos: string[] }>();
  for (const a of archivos) {
    const clave = `${a.pedido}|${a.carpeta}|${a.nombre.replace(/_\d+de\d+\.jpg$/, '')}`;
    const f = filas.get(clave) || { curso: a.curso, numero: a.numeroLista ? String(a.numeroLista) : '', alumno: a.alumno, pedido: a.pedido, tam: a.carpeta, copias: a.copias, archivos: [] };
    f.archivos.push(a.nombre);
    filas.set(clave, f);
  }
  const celda = (v: unknown) => {
    const t = String(v ?? '');
    const seguro = /^[=+\-@]/.test(t) ? `'${t}` : t;
    return /[;"\n]/.test(seguro) ? `"${seguro.replace(/"/g, '""')}"` : seguro;
  };
  const lineas = [['Curso', 'N° lista', 'Alumno/a', 'Pedido', 'Tamaño', 'Copias', 'Archivos', 'Hecho'].join(';')];
  for (const f of filas.values()) lineas.push([f.curso, f.numero, f.alumno, f.pedido, f.tam, f.copias, f.archivos.join(' | '), ''].map(celda).join(';'));
  return `﻿${lineas.join('\r\n')}\r\n`;
}

export default function LotesFotosExtraLab({ onError, recargarCon, onPendientes }: Props) {
  const [nuevos, setNuevos] = useState<{ pedidos: number; fotos15x21: number; fotos20x30: number }>({ pedidos: 0, fotos15x21: 0, fotos20x30: 0 });
  const [lotes, setLotes] = useState<LoteExtras[]>([]);
  const [trabajando, setTrabajando] = useState<string | null>(null);
  const [progreso, setProgreso] = useState('');
  const [errorLocal, setErrorLocal] = useState('');
  const refError = useRef(onError);
  refError.current = onError;
  const refPendientes = useRef(onPendientes);
  refPendientes.current = onPendientes;
  const avisarError = (e: unknown) => {
    if (e instanceof SesionLabVencida) refError.current(e);
    else setErrorLocal(e instanceof Error ? e.message : 'Algo salió mal con las fotos extra.');
  };

  const cargar = useCallback(async () => {
    try {
      const data = await leerJson(await fetchLab('/api/lab/extras'));
      setNuevos(data.nuevos || { pedidos: 0, fotos15x21: 0, fotos20x30: 0 });
      const lista: LoteExtras[] = data.lotes || [];
      setLotes(lista);
      setErrorLocal('');
      refPendientes.current?.((data.nuevos?.pedidos ? 1 : 0) + lista.filter((l) => !l.en_produccion_at).length);
    } catch (e) {
      if (e instanceof SesionLabVencida) refError.current(e);
      else setErrorLocal(e instanceof Error ? e.message : 'No se pudieron cargar las fotos extra.');
    }
  }, []);

  useEffect(() => {
    void cargar();
  }, [cargar, recargarCon]);

  // Baja cada original una vez (aunque tenga varias copias) y arma el ZIP en el navegador, en partes de ~80 archivos.
  const descargarZip = async (lote: Pick<LoteExtras, 'id' | 'numero'>) => {
    setProgreso('Preparando la lista de archivos…');
    const data = await leerJson(await fetchLab(`/api/lab/extras/lotes/${encodeURIComponent(lote.id)}/manifiesto`));
    const archivos: ArchivoManifiesto[] = data.archivos || [];
    if (archivos.length === 0) throw new Error('Este lote no tiene copias para imprimir (¿se anularon sus pedidos?).');
    const porUrl = new Map<string, ArchivoManifiesto[]>();
    const sinOriginal: string[] = [];
    for (const a of archivos) {
      if (a.url) porUrl.set(a.url, [...(porUrl.get(a.url) || []), a]);
      else sinOriginal.push(`${a.nombre} (sin original en el servidor)`);
    }
    const urls = [...porUrl.keys()];
    const partes: string[][] = [];
    let actual: string[] = [];
    let enActual = 0;
    for (const url of urls) {
      const n = porUrl.get(url)?.length || 1;
      if (actual.length && enActual + n > 80) {
        partes.push(actual);
        actual = [];
        enActual = 0;
      }
      actual.push(url);
      enActual += n;
    }
    if (actual.length || partes.length === 0) partes.push(actual);
    const JSZip = (await import('jszip')).default;
    const faltanTodas: string[] = [...sinOriginal];
    for (let n = 0; n < partes.length; n++) {
      const zip = new JSZip();
      const etiqueta = partes.length > 1 ? ` (parte ${n + 1} de ${partes.length})` : '';
      const faltan: string[] = n === partes.length - 1 ? [...sinOriginal] : [];
      let i = 0;
      let hechos = 0;
      const lista = partes[n];
      const trabajador = async () => {
        while (i < lista.length) {
          const url = lista[i++];
          try {
            const r = await fetch(url);
            if (!r.ok) throw new Error(`HTTP ${r.status}`);
            const datos = await r.arrayBuffer();
            for (const a of porUrl.get(url) || []) zip.file(`${a.carpeta}/${a.nombre}`, datos, { binary: true });
          } catch (e) {
            for (const a of porUrl.get(url) || []) {
              faltan.push(`${a.nombre} (${e instanceof Error ? e.message : 'error'})`);
              faltanTodas.push(a.nombre);
            }
          }
          hechos++;
          setProgreso(`Lote N° ${lote.numero}: bajando originales ${hechos} de ${lista.length}…${etiqueta}`);
        }
      };
      await Promise.all([trabajador(), trabajador(), trabajador(), trabajador()]);
      if (n === 0) zip.file('LISTA_ENSOBRADO.csv', planillaEnsobrado(archivos));
      if (faltan.length) zip.file('FALTAN_ARCHIVOS.txt', `No se pudieron incluir (volvé a descargar el lote):\r\n${faltan.join('\r\n')}`);
      setProgreso(`Armando el ZIP${etiqueta}…`);
      const blob = await zip.generateAsync({ type: 'blob', compression: 'STORE' });
      const sufijo = partes.length > 1 ? `-parte-${n + 1}-de-${partes.length}` : '';
      guardarBlob(blob, `Fotos-extra-Lote-${lote.numero}${sufijo}.zip`);
    }
    const c15 = archivos.filter((a) => a.carpeta === '15x21').length;
    const c20 = archivos.filter((a) => a.carpeta === '20x30').length;
    setProgreso(
      faltanTodas.length
        ? `⚠️ Lote N° ${lote.numero}: faltaron ${faltanTodas.length} archivo(s). Mirá FALTAN_ARCHIVOS.txt dentro del ZIP y volvé a descargarlo.`
        : `✓ Lote N° ${lote.numero} descargado: ${c15} copia(s) 15x21 y ${c20} de 20x30 (${data.pedidosVigentes} pedido(s)). Cuando lo empiecen a imprimir, tocá «Marcar en producción».`
    );
  };

  const armarLote = async () => {
    setTrabajando('nuevo');
    setErrorLocal('');
    setProgreso('Armando el lote…');
    try {
      const data = await leerJson(await fetchLab('/api/lab/extras/lotes', { method: 'POST' }));
      await cargar();
      await descargarZip(data.lote);
    } catch (e) {
      setProgreso('');
      avisarError(e);
    } finally {
      setTrabajando(null);
    }
  };

  const redescargar = async (lote: LoteExtras) => {
    setTrabajando(lote.id);
    setErrorLocal('');
    try {
      await descargarZip(lote);
    } catch (e) {
      setProgreso('');
      avisarError(e);
    } finally {
      setTrabajando(null);
    }
  };

  const enProduccion = async (lote: LoteExtras) => {
    if (!window.confirm(`¿Marcar el lote de fotos extra N° ${lote.numero} "En producción"? Cada familia recibe un email avisando que se están imprimiendo.`)) return;
    setTrabajando(`prod-${lote.id}`);
    setErrorLocal('');
    try {
      const r = await marcarLoteEnProduccion(lote.id, (avisados, restantes) => setProgreso(`Lote N° ${lote.numero}: ${avisados} familia(s) avisadas, faltan ${restantes}…`));
      if (!r.success) setErrorLocal(r.error || 'No se pudo marcar el lote.');
      else setProgreso(`✓ Lote de fotos extra N° ${lote.numero} en producción. Se avisó a ${r.avisados ?? 0} familia(s).`);
      await cargar();
    } catch (e) {
      avisarError(e);
    } finally {
      setTrabajando(null);
    }
  };

  const fecha = (iso: string) => new Date(iso).toLocaleString('es-AR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' });
  const ocupado = trabajando !== null;

  return (
    <section className="rounded-3xl border border-sky-200 bg-gradient-to-br from-sky-50 via-white to-amber-50/50 p-5 shadow-sm sm:p-6">
      <p className="flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-sky-800">
        <ImagePlus className="h-3.5 w-3.5" /> Copias sueltas · aparte de los kits
      </p>
      <h2 className="font-['Outfit'] text-2xl font-black text-slate-900">Fotos extra</h2>
      <p className="mt-1 text-sm text-slate-600">
        Copias que las familias piden aparte del kit. Van en su propio lote (nunca se mezclan con los kits): una carpeta por tamaño, un archivo por copia y la lista para ensobrar.
      </p>

      {errorLocal && <p className="mt-3 rounded-2xl border border-red-200 bg-red-50 px-3 py-2 text-sm font-semibold text-red-700">{errorLocal}</p>}
      {progreso && <p className="mt-3 rounded-2xl bg-white px-3 py-2 text-sm font-semibold text-slate-700 shadow-sm" aria-live="polite">{progreso}</p>}

      <button
        type="button"
        onClick={() => void armarLote()}
        disabled={nuevos.pedidos === 0 || ocupado}
        className="mt-4 flex w-full items-center justify-center gap-2 rounded-2xl bg-slate-900 px-5 py-4 text-base font-extrabold text-white shadow-lg hover:bg-slate-800 disabled:bg-slate-300 disabled:text-slate-500 disabled:shadow-none"
      >
        {trabajando === 'nuevo' ? <Loader2 className="h-5 w-5 animate-spin" /> : <FolderDown className="h-5 w-5 text-amber-400" />}
        {trabajando === 'nuevo'
          ? 'Armando el ZIP…'
          : nuevos.pedidos === 0
            ? 'No hay fotos extra nuevas por ahora'
            : `Descargar fotos extra nuevas · ${nuevos.pedidos} pedido(s) · 15x21: ${nuevos.fotos15x21} · 20x30: ${nuevos.fotos20x30}`}
      </button>

      <div className="mt-4 space-y-3">
        {lotes.length === 0 && <p className="rounded-2xl border border-dashed border-slate-300 bg-white px-4 py-6 text-center text-sm text-slate-500">Todavía no hay lotes de fotos extra.</p>}
        {lotes.map((l) => (
          <div key={l.id} className="flex flex-wrap items-center gap-3 rounded-2xl border border-slate-200 bg-white p-4">
            <div className="min-w-[200px] flex-1">
              <p className="font-bold text-slate-900">
                Fotos extra — Lote {l.numero}{' '}
                <span className={`ml-1 rounded-full px-2 py-0.5 text-[11px] font-bold ${l.en_produccion_at ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'}`}>
                  {l.en_produccion_at ? 'En producción' : 'Descargado'}
                </span>
              </p>
              <p className="text-xs text-slate-600">
                Armado {fecha(l.created_at)} · {l.cantidad} pedido(s) · 15x21: {l.fotos_15x21} · 20x30: {l.fotos_20x30}
              </p>
            </div>
            <button type="button" onClick={() => void redescargar(l)} disabled={ocupado} className="flex items-center gap-1.5 rounded-xl bg-amber-400 px-3 py-2 text-xs font-bold text-slate-950 hover:bg-amber-300 disabled:opacity-50">
              {trabajando === l.id ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <FolderDown className="h-3.5 w-3.5" />}
              Descargar ZIP
            </button>
            {!l.en_produccion_at && (
              <button type="button" onClick={() => void enProduccion(l)} disabled={ocupado} className="flex items-center gap-1.5 rounded-xl bg-emerald-600 px-3 py-2 text-xs font-bold text-white hover:bg-emerald-500 disabled:opacity-50">
                {trabajando === `prod-${l.id}` ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Printer className="h-3.5 w-3.5" />} Marcar en producción
              </button>
            )}
            {l.en_produccion_at && (
              <span className="flex items-center gap-1 text-xs font-semibold text-emerald-700">
                <CheckCircle2 className="h-3.5 w-3.5" /> {fecha(l.en_produccion_at)}
              </span>
            )}
          </div>
        ))}
      </div>
    </section>
  );
}
