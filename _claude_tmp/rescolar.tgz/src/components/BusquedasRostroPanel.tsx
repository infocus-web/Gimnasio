import { useCallback, useEffect, useState } from 'react';
import { Loader2, RefreshCw, ScanFace } from 'lucide-react';
import { listarBusquedasRostro, type BusquedaRostroAdmin } from '../services/buscadorRostroService';

/**
 * Panel (pestaña «Faltantes»): las búsquedas por reconocimiento facial que hicieron las familias (24/10/2026, Pablo:
 * automática pero registrada). Quién buscó, cuándo y cuántas fotos se sumaron a su galería. La imagen nunca se guarda.
 */
const RESULTADO: Record<BusquedaRostroAdmin['resultado'], string> = { ok: 'Encontró', sin_resultados: 'Sin resultados', sin_cara: 'Sin cara en la foto', error: 'Error' };
const fecha = (iso: string) => new Date(iso).toLocaleString('es-AR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' });

export default function BusquedasRostroPanel({ colegioId }: { colegioId: string }) {
  const [busquedas, setBusquedas] = useState<BusquedaRostroAdmin[]>([]);
  const [configurado, setConfigurado] = useState<boolean | null>(null);
  const [cargando, setCargando] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const cargar = useCallback(async () => {
    if (!colegioId) return;
    setCargando(true);
    setError(null);
    const r = await listarBusquedasRostro(colegioId);
    if (r.success) {
      setBusquedas(r.busquedas || []);
      setConfigurado(r.configurado ?? null);
    } else setError(r.error || 'No se pudieron cargar las búsquedas.');
    setCargando(false);
  }, [colegioId]);

  useEffect(() => {
    setBusquedas([]);
    void cargar();
  }, [cargar]);

  const nuevas = busquedas.reduce((t, b) => t + (b.fotos_nuevas || 0), 0);

  return (
    <section className="mt-8 space-y-3" aria-label="Búsquedas por reconocimiento facial">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <h3 className="text-sm font-bold text-slate-800 flex items-center gap-2">
          <ScanFace className="w-4 h-4 text-indigo-600" aria-hidden="true" /> Búsquedas por rostro ({busquedas.length}) · {nuevas} foto{nuevas === 1 ? '' : 's'} sumada{nuevas === 1 ? '' : 's'}
        </h3>
        <button type="button" onClick={() => void cargar()} disabled={cargando} className="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 px-3 py-1.5 text-xs font-bold text-slate-700 hover:bg-slate-50 disabled:opacity-50 cursor-pointer">
          {cargando ? <Loader2 className="w-3.5 h-3.5 animate-spin" aria-hidden="true" /> : <RefreshCw className="w-3.5 h-3.5" aria-hidden="true" />} Actualizar
        </button>
      </div>
      {configurado === false && (
        <p className="text-xs rounded-lg border border-amber-300 bg-amber-50 p-2.5 text-amber-900">El buscador está apagado: faltan las variables AWS_REKOGNITION_ACCESS_KEY_ID y AWS_REKOGNITION_SECRET_ACCESS_KEY en Vercel.</p>
      )}
      {error && <p className="text-xs rounded-lg border border-red-200 bg-red-50 p-2.5 text-red-800">{error}</p>}
      {busquedas.length === 0 && !cargando && !error ? (
        <p className="text-xs text-slate-500">Todavía ninguna familia usó el buscador en este colegio.</p>
      ) : (
        <div className="overflow-x-auto rounded-xl border border-slate-200">
          <table className="min-w-full text-xs">
            <thead className="bg-slate-50 text-left text-slate-600">
              <tr><th className="px-3 py-2">Fecha</th><th className="px-3 py-2">Alumno/a</th><th className="px-3 py-2">Curso</th><th className="px-3 py-2">Resultado</th><th className="px-3 py-2">Sumadas</th><th className="px-3 py-2">Ya estaban</th></tr>
            </thead>
            <tbody>
              {busquedas.map((b) => (
                <tr key={b.id} className="border-t border-slate-100">
                  <td className="px-3 py-2 whitespace-nowrap">{fecha(b.created_at)}</td>
                  <td className="px-3 py-2">{b.alumno_nombre}</td>
                  <td className="px-3 py-2">{b.codigo_curso}</td>
                  <td className="px-3 py-2">{RESULTADO[b.resultado] || b.resultado}</td>
                  <td className="px-3 py-2 font-bold" title={(b.copias || []).map((c) => `${c.nombre} (desde ${c.cursoOrigen || '¿?'})`).join(', ')}>
                    {b.fotos_nuevas}
                    {(b.copias || []).length > 0 && <span className="block font-normal text-[11px] text-slate-500">{(b.copias || []).map((c) => `${c.nombre} ← ${c.cursoOrigen || '¿?'}`).join(' · ')}</span>}
                  </td>
                  <td className="px-3 py-2">{b.fotos_ya_en_galeria}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </section>
  );
}
