import { useEffect, useState } from 'react';
import { Bot, CheckCircle2, ChevronDown, Loader2 } from 'lucide-react';
import { fetchAdminAutenticado } from '../services/adminAuthService';

/**
 * 25/10/2026 (Pablo: «la IA debe actualizarse en tiempo real, con todos los cambios que vamos haciendo»):
 * «Lo que la IA tiene que saber». Las decisiones del momento, en palabras simples; la IA de consultas las lee en cada
 * respuesta (en menos de 30 s, sin deploy) y tienen prioridad sobre sus reglas fijas. Servidor: novedadesIa.ts.
 */
export default function NovedadesIA() {
  const [abierto, setAbierto] = useState(false);
  const [texto, setTexto] = useState('');
  const [guardado, setGuardado] = useState('');
  const [actualizado, setActualizado] = useState<string | null>(null);
  const [estado, setEstado] = useState<'cargando' | 'listo' | 'guardando' | 'error'>('cargando');
  const [error, setError] = useState('');

  useEffect(() => {
    void (async () => {
      try {
        const res = await fetchAdminAutenticado('/api/admin/novedades-ia');
        const data = await res.json().catch(() => ({}));
        if (!res.ok || !data.success) throw new Error(data.error || 'No se pudo leer.');
        setTexto(data.texto || ''); setGuardado(data.texto || ''); setActualizado(data.actualizado || null);
        setEstado('listo');
      } catch (err: any) {
        setError(err?.message || 'No se pudo leer.'); setEstado('error');
      }
    })();
  }, []);

  const guardar = async () => {
    setEstado('guardando'); setError('');
    try {
      const res = await fetchAdminAutenticado('/api/admin/novedades-ia', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ texto }) });
      const data = await res.json().catch(() => ({}));
      if (!res.ok || !data.success) throw new Error(data.error || 'No se pudo guardar.');
      setGuardado(texto); setActualizado(data.actualizado || new Date().toISOString());
      setEstado('listo');
    } catch (err: any) {
      setError(err?.message || 'No se pudo guardar.'); setEstado('listo');
    }
  };

  const cambios = texto !== guardado;
  const lineas = guardado.split('\n').filter((l) => l.trim()).length;
  return (
    <section className="rounded-2xl border border-violet-200 bg-violet-50">
      <button type="button" onClick={() => setAbierto((a) => !a)} aria-expanded={abierto} className="w-full px-4 py-3 flex items-center gap-2 text-left cursor-pointer">
        <Bot className="w-4 h-4 text-violet-700 shrink-0" />
        <span className="text-sm font-bold text-violet-950 flex-1">Lo que la IA tiene que saber hoy{lineas ? ` (${lineas})` : ''}</span>
        {actualizado && <span className="hidden sm:inline text-[11px] text-violet-700">actualizado {new Date(actualizado).toLocaleString('es-AR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' })}</span>}
        <ChevronDown className={`w-4 h-4 text-violet-700 transition-transform ${abierto ? 'rotate-180' : ''}`} />
      </button>
      {abierto && (
        <div className="px-4 pb-4 space-y-2">
          <p className="text-xs text-violet-900">Escribí las decisiones y novedades del momento, una por línea. La IA las usa en cada respuesta desde que guardás (sin esperar un deploy) y tienen prioridad sobre sus reglas. Borrá las que ya no valgan.</p>
          <textarea
            value={texto}
            onChange={(e) => setTexto(e.target.value)}
            disabled={estado === 'cargando'}
            rows={6}
            maxLength={4000}
            aria-label="Lo que la IA tiene que saber"
            placeholder={'Ej.:\n- Sala 4 C turno mañana: la grupal se saca el jueves 29/10 a las 10 en el salón. Avisamos por mail.\n- Las individuales de secundaria (2° a 6° año) se sacan el martes 27/10.'}
            className="w-full rounded-xl border border-violet-200 bg-white p-3 text-sm leading-relaxed outline-none focus:border-violet-500 focus:ring-2 focus:ring-violet-200"
          />
          <div className="flex items-center gap-2">
            <button type="button" disabled={!cambios || estado !== 'listo'} onClick={() => void guardar()} className="px-4 py-2 rounded-xl bg-violet-600 hover:bg-violet-500 text-white text-xs font-bold inline-flex items-center gap-1.5 disabled:opacity-50 cursor-pointer">
              {estado === 'guardando' ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <CheckCircle2 className="w-3.5 h-3.5" />}Guardar
            </button>
            {cambios && <span className="text-[11px] font-semibold text-amber-700">Sin guardar</span>}
            {error && <span role="alert" className="text-xs text-rose-700">{error}</span>}
          </div>
        </div>
      )}
    </section>
  );
}
