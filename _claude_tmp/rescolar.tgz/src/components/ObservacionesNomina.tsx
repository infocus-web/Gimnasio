import { useCallback, useEffect, useMemo, useState } from 'react';
import { Loader2, NotebookPen, Plus, Trash2, X } from 'lucide-react';
import type { AlumnoNominaReal } from '../services/colegiosService';
import {
  TIPOS_OBSERVACION,
  borrarObservacionAdmin,
  crearObservacionAdmin,
  etiquetaTipoObservacion,
  obtenerObservacionesAdmin,
  type ObservacionAlumno,
  type TipoObservacion,
} from '../services/observacionesService';
import { nuevaClaveEnvio } from '../utils/claveEnvio';
import { useBorradorAdmin } from '../utils/useBorradorAdmin';

// Nómina del panel: «Observaciones» en cada alumno (14/10/2026, Pablo: «en cada alumno de la nómina, agregame
// observaciones para agregar notas»). Usa la misma tabla y rutas que la pestaña «Observaciones»
// (`observaciones_alumnos`, servidor/panel/observaciones.ts): lo que se anota acá aparece allá y al revés.
// Fuera de AdminModal.tsx a propósito (ese archivo tiene techo de líneas): la Nómina sólo usa
// `useObservacionesNomina`, `CeldaObservacionesNomina` y `ColumnasNomina`.

/** Anchos de columna de la Nómina (encabezado y filas son dos tablas: tienen que usar los mismos). */
export function ColumnasNomina() {
  return (
    <colgroup>
      {[5, 6, 26, 12, 12, 11, 13, 15].map((ancho, i) => (
        <col key={i} style={{ width: `${ancho}%` }} />
      ))}
    </colgroup>
  );
}

const fechaHora = (iso: string) =>
  new Date(iso).toLocaleString('es-AR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' });

const textoObservacion = (o: ObservacionAlumno) =>
  o.tipo === 'otra' ? o.detalle || '' : `${etiquetaTipoObservacion(o.tipo)}${o.detalle ? `: ${o.detalle}` : ''}`;

/** Observaciones de todos los colegios de la nómina, la ventana de un alumno y la función para abrirla. */
export function useObservacionesNomina(alumnos: AlumnoNominaReal[]) {
  const [observaciones, setObservaciones] = useState<ObservacionAlumno[]>([]);
  const [errorObservaciones, setErrorObservaciones] = useState<string | null>(null);
  const [alumno, setAlumno] = useState<AlumnoNominaReal | null>(null);

  const colegios = useMemo(
    () => [...new Set(alumnos.map((a) => a.colegio_id).filter((c): c is string => !!c))].sort().join(','),
    [alumnos]
  );

  // Trae (o vuelve a traer) las de un colegio y reemplaza sólo esas.
  const cargarColegio = useCallback(async (colegioId: string) => {
    const r = await obtenerObservacionesAdmin(colegioId);
    if (!r.success) {
      setErrorObservaciones(r.error || 'No se pudieron cargar las observaciones.');
      return;
    }
    setErrorObservaciones(null);
    setObservaciones((prev) => [...prev.filter((o) => o.colegio_id !== colegioId), ...r.observaciones]);
  }, []);

  useEffect(() => {
    if (!colegios) return;
    colegios.split(',').forEach((c) => void cargarColegio(c));
  }, [colegios, cargarColegio]);

  const porAlumno = useMemo(() => {
    const mapa = new Map<string, ObservacionAlumno[]>();
    [...observaciones]
      .sort((a, b) => b.created_at.localeCompare(a.created_at))
      .forEach((o) => {
        if (!o.alumno_id) return;
        if (!mapa.has(o.alumno_id)) mapa.set(o.alumno_id, []);
        mapa.get(o.alumno_id)!.push(o);
      });
    return mapa;
  }, [observaciones]);

  const observacionesDe = useCallback((alumnoId: string) => porAlumno.get(alumnoId) || [], [porAlumno]);

  const abrirObservaciones = useCallback(
    (a: AlumnoNominaReal) => {
      setAlumno(a);
      // Al abrir se refresca el colegio: así aparece lo que se anotó desde la pestaña «Observaciones» u otro equipo.
      if (a.colegio_id) void cargarColegio(a.colegio_id);
    },
    [cargarColegio]
  );

  const modalObservaciones = alumno ? (
    <ModalObservacionesAlumno
      alumno={alumno}
      observaciones={observacionesDe(alumno.id)}
      onCerrar={() => setAlumno(null)}
      onAgregada={(o) => setObservaciones((prev) => [o, ...prev.filter((x) => x.id !== o.id)])}
      onBorrada={(id) => setObservaciones((prev) => prev.filter((x) => x.id !== id))}
    />
  ) : null;

  return { observacionesDe, abrirObservaciones, modalObservaciones, errorObservaciones };
}

/** Celda «Observaciones» de una fila de la Nómina (no marca la fila como fotografiada). */
export function CeldaObservacionesNomina({
  alumno,
  observaciones,
  onAbrir,
}: {
  alumno: AlumnoNominaReal;
  observaciones: ObservacionAlumno[];
  onAbrir: (a: AlumnoNominaReal) => void;
}) {
  const ultima = observaciones[0];
  return (
    <button
      type="button"
      onClick={(event) => {
        event.stopPropagation();
        onAbrir(alumno);
      }}
      title={ultima ? observaciones.map(textoObservacion).join('\n') : 'Agregar una nota'}
      aria-label={ultima ? `Ver las ${observaciones.length} observaciones de ${alumno.nombre}` : `Agregar una observación a ${alumno.nombre}`}
      className={`w-full min-w-0 inline-flex items-center gap-1.5 rounded-md border px-1.5 py-0.5 text-[10px] font-semibold cursor-pointer text-left ${
        ultima
          ? 'border-violet-200 bg-violet-50 text-violet-800 hover:border-violet-400'
          : 'border-slate-200 text-slate-400 hover:border-amber-400 hover:text-amber-700 hover:bg-amber-50'
      }`}
    >
      {ultima ? (
        <>
          <span className="shrink-0 rounded-full bg-violet-600 text-white px-1.5 leading-4">{observaciones.length}</span>
          <span className="min-w-0 truncate font-medium">{textoObservacion(ultima)}</span>
        </>
      ) : (
        <>
          <Plus className="w-3 h-3 shrink-0" /> <span className="truncate">Nota</span>
        </>
      )}
    </button>
  );
}

const FORM_VACIO = { tipo: 'otra' as TipoObservacion, detalle: '', clave: '', claveDe: '' };

function ModalObservacionesAlumno({
  alumno,
  observaciones,
  onCerrar,
  onAgregada,
  onBorrada,
}: {
  alumno: AlumnoNominaReal;
  observaciones: ObservacionAlumno[];
  onCerrar: () => void;
  onAgregada: (o: ObservacionAlumno) => void;
  onBorrada: (id: string) => void;
}) {
  // El texto a medio escribir se guarda solo en el servidor (sobrevive a recargar o cambiar de equipo).
  const [form, setForm, borrador] = useBorradorAdmin(`observacion-nomina-${alumno.id}`, FORM_VACIO);
  const [guardando, setGuardando] = useState(false);
  const [borrandoId, setBorrandoId] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const ocupado = guardando || !!borrandoId;
  const detalle = form.detalle.trim();

  const guardar = async () => {
    if (ocupado) return;
    if (form.tipo === 'otra' && !detalle) {
      setError('Escribí la nota.');
      return;
    }
    setGuardando(true);
    setError(null);
    // Misma clave si se reintenta el mismo texto (corte de red, doble clic): el servidor no la anota dos veces.
    const contenido = `${alumno.id}|${form.tipo}|${detalle}`;
    const clave = form.clave && form.claveDe === contenido ? form.clave : nuevaClaveEnvio();
    if (clave !== form.clave) setForm((f) => ({ ...f, clave, claveDe: contenido }));
    const r = await crearObservacionAdmin(alumno.id, form.tipo, detalle, clave);
    setGuardando(false);
    if (!r.success || !r.observacion) {
      setError(r.error || 'No se pudo guardar la observación.');
      return;
    }
    onAgregada(r.observacion);
    borrador.fijarSinGuardar(FORM_VACIO);
    void borrador.borrar();
  };

  const borrar = async (o: ObservacionAlumno) => {
    if (ocupado || !window.confirm(`¿Borrar esta observación de ${alumno.nombre}?\n\n${textoObservacion(o)}`)) return;
    setBorrandoId(o.id);
    setError(null);
    const r = await borrarObservacionAdmin(o.id);
    setBorrandoId(null);
    if (!r.success) {
      setError(r.error || 'No se pudo borrar la observación.');
      return;
    }
    onBorrada(o.id);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4" onClick={() => !ocupado && onCerrar()}>
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby="titulo-observaciones-alumno"
        className="bg-white rounded-2xl p-5 w-full max-w-md shadow-xl space-y-4 max-h-[90vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-start justify-between gap-3">
          <div className="min-w-0">
            <p id="titulo-observaciones-alumno" className="font-bold text-slate-900 text-sm flex items-center gap-2">
              <NotebookPen className="w-4 h-4 text-violet-600" /> Observaciones
            </p>
            <p className="text-xs text-slate-700 mt-1 font-semibold truncate">{alumno.nombre}</p>
            <p className="text-[11px] text-slate-500">
              {alumno.grado} "{alumno.division}" ({alumno.turno || 'sin turno'})
            </p>
          </div>
          <button type="button" onClick={onCerrar} disabled={ocupado} className="p-1 text-slate-400 hover:text-slate-700 cursor-pointer" aria-label="Cerrar">
            <X className="w-5 h-5" />
          </button>
        </div>

        {observaciones.length === 0 ? (
          <p className="text-[11px] text-slate-400">Todavía no tiene observaciones.</p>
        ) : (
          <ul className="space-y-2" aria-label="Observaciones guardadas">
            {observaciones.map((o) => (
              <li key={o.id} className="flex items-start gap-2 rounded-xl border border-slate-200 bg-slate-50 px-3 py-2">
                <div className="min-w-0 flex-1">
                  <p className="text-[10px] font-semibold text-slate-500">
                    {etiquetaTipoObservacion(o.tipo)} · {fechaHora(o.created_at)}
                  </p>
                  {o.detalle && <p className="text-xs text-slate-800 whitespace-pre-wrap break-words">{o.detalle}</p>}
                </div>
                <button
                  type="button"
                  onClick={() => void borrar(o)}
                  disabled={ocupado}
                  aria-label="Borrar observación"
                  className="shrink-0 p-1 text-slate-400 hover:text-rose-600 disabled:opacity-50 cursor-pointer"
                >
                  {borrandoId === o.id ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Trash2 className="w-3.5 h-3.5" />}
                </button>
              </li>
            ))}
          </ul>
        )}

        <div className="space-y-2 border-t border-slate-100 pt-3">
          <label className="block text-[11px] font-semibold text-slate-700">
            Tipo
            <select
              value={form.tipo}
              onChange={(e) => setForm((f) => ({ ...f, tipo: e.target.value as TipoObservacion }))}
              disabled={guardando}
              className="mt-1 w-full rounded-xl border border-slate-300 px-3 py-2 text-xs font-normal bg-white"
            >
              {TIPOS_OBSERVACION.map((t) => (
                <option key={t.valor} value={t.valor}>
                  {t.valor === 'otra' ? 'Nota' : t.etiqueta}
                </option>
              ))}
            </select>
          </label>
          <label className="block text-[11px] font-semibold text-slate-700">
            {form.tipo === 'otra' ? 'Nota' : 'Detalle (opcional)'}
            <textarea
              value={form.detalle}
              onChange={(e) => setForm((f) => ({ ...f, detalle: e.target.value }))}
              disabled={guardando}
              maxLength={1000}
              rows={3}
              autoFocus
              placeholder="Ej.: llega tarde los martes, sacarle la foto con la hermana…"
              className="mt-1 w-full rounded-xl border border-slate-300 px-3 py-2 text-xs font-normal resize-y"
            />
          </label>
        </div>

        {error && <p role="alert" className="text-[11px] font-semibold text-rose-700">{error}</p>}

        <div className="flex justify-end gap-2">
          <button type="button" onClick={onCerrar} disabled={ocupado} className="px-3 py-2 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100 cursor-pointer">
            Cerrar
          </button>
          <button
            type="button"
            onClick={() => void guardar()}
            disabled={ocupado || (form.tipo === 'otra' && !detalle)}
            className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold bg-amber-500 text-white hover:bg-amber-600 disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer"
          >
            {guardando && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
            Agregar observación
          </button>
        </div>
      </div>
    </div>
  );
}
