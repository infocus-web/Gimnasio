import { useCallback, useEffect, useState, type ReactNode } from 'react';
import { AlertTriangle, CheckCircle2, ClipboardList, CreditCard, GraduationCap, Inbox, Loader2, Mail, Phone, Search, User, X } from 'lucide-react';
import { FichaCliente, FichaPedido, obtenerFichaClienteAdmin } from '../services/fichaClienteService';

/**
 * Ficha del cliente (19/10/2026, pedido de Pablo: «desde el panel de consultas no puedo investigar al cliente…
 * necesito ver todo lo referente a ese cliente desde un panel»). Se abre desde una consulta con su email,
 * teléfono y número de pedido; se puede volver a buscar con otro dato (muchas familias pagan con otro email).
 * Sólo muestra: no cambia nada.
 */

const pesos = (n: number) => `$${(Number(n) || 0).toLocaleString('es-AR')}`;
const fecha = (f: string | null | undefined, conHora = false) => {
  if (!f) return '';
  const d = new Date(f);
  if (Number.isNaN(d.getTime())) return String(f);
  return conHora
    ? d.toLocaleString('es-AR', { day: '2-digit', month: '2-digit', year: '2-digit', hour: '2-digit', minute: '2-digit', hourCycle: 'h23' })
    : d.toLocaleDateString('es-AR', { day: '2-digit', month: '2-digit', year: '2-digit' });
};
const curso = (c: { grado?: string | null; division?: string | null; turno?: string | null } | null) =>
  c ? [c.grado, c.division, c.turno].filter(Boolean).join(' · ') : '';

const ESTADO_PEDIDO: Record<string, { texto: string; estilo: string }> = {
  pagado: { texto: 'Pagado', estilo: 'bg-emerald-100 text-emerald-800' },
  entregado: { texto: 'Pagado', estilo: 'bg-emerald-100 text-emerald-800' },
  pendiente_pago: { texto: 'Sin pagar', estilo: 'bg-amber-100 text-amber-800' },
  pendiente: { texto: 'Sin pagar', estilo: 'bg-amber-100 text-amber-800' },
  cancelado: { texto: 'Cancelado', estilo: 'bg-red-100 text-red-700' },
};
const METODO: Record<string, string> = { mercadopago: 'Mercado Pago', nave: 'Tarjeta (Nave)', transferencia: 'Transferencia' };
const LAB: Record<string, string> = { en_produccion: 'En producción', listo_retiro: 'Listo para retirar', entregado: 'Entregado' };
const INSCRIPCION: Record<string, string> = { aceptado: 'Aprobada', pendiente: 'Pendiente', rechazado: 'Rechazada' };
const OBSERVACION: Record<string, string> = { sin_foto_individual: 'No quiso foto individual', sin_foto_grupal: 'No quiso foto grupal', ausente: 'Ausente', otra: 'Otra' };

function Seccion({ titulo, icono, children, vacio }: { titulo: string; icono: ReactNode; children?: ReactNode; vacio?: string | false }) {
  return (
    <section className="space-y-2">
      <h3 className="flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wide text-slate-500">{icono}{titulo}</h3>
      {vacio ? <p className="text-xs text-slate-400 border border-dashed border-slate-200 rounded-xl p-3">{vacio}</p> : children}
    </section>
  );
}

function Etiqueta({ texto, estilo }: { texto: string; estilo: string }) {
  return <span className={`inline-block px-2 py-0.5 rounded-full text-[10px] font-bold ${estilo}`}>{texto}</span>;
}

function TarjetaPedido({ p }: { p: FichaPedido }) {
  const estado = p.canceladoDefinitivo
    ? { texto: 'Cancelado (definitivo)', estilo: 'bg-red-100 text-red-700' }
    : ESTADO_PEDIDO[p.estado] || { texto: p.estado, estilo: 'bg-slate-100 text-slate-700' };
  const pagado = p.estado === 'pagado' || p.estado === 'entregado';
  return (
    <div className={`rounded-xl border p-3 text-xs ${p.soloPorNumero ? 'border-amber-300 bg-amber-50/50' : 'border-slate-200 bg-white'}`}>
      <div className="flex flex-wrap items-center justify-between gap-2">
        <p className="font-bold text-slate-900">{p.numero || 'Sin número'} · {p.alumno || 'Alumno sin nombre'}</p>
        <div className="flex flex-wrap gap-1">
          <Etiqueta {...estado} />
          {p.archivado && <Etiqueta texto="Archivado" estilo="bg-slate-200 text-slate-600" />}
          {p.enEspera && <Etiqueta texto="En espera" estilo="bg-violet-100 text-violet-700" />}
        </div>
      </div>
      {p.soloPorNumero && <p className="mt-1 text-[11px] font-semibold text-amber-800">Es el pedido que mencionó, pero no está a nombre de este email ni teléfono.</p>}
      <dl className="mt-2 grid grid-cols-2 sm:grid-cols-3 gap-x-4 gap-y-1 text-[11px]">
        <div><dt className="text-slate-400">Kit</dt><dd className="font-semibold text-slate-800">{p.kit || '—'}{p.esMejora ? ' (mejora a impreso)' : ''}</dd></div>
        <div><dt className="text-slate-400">Total</dt><dd className="font-semibold text-slate-800">{pesos(p.total)}</dd></div>
        <div><dt className="text-slate-400">Medio de pago</dt><dd className="text-slate-700">{METODO[p.metodoPago || ''] || p.metodoPago || '—'}</dd></div>
        <div><dt className="text-slate-400">Colegio / curso</dt><dd className="text-slate-700">{[p.colegio, p.curso].filter(Boolean).join(' — ') || '—'}</dd></div>
        <div><dt className="text-slate-400">Pedido</dt><dd className="text-slate-700">{fecha(p.createdAt, true)}</dd></div>
        <div><dt className="text-slate-400">Pago</dt><dd className="text-slate-700">{pagado ? `${fecha(p.pagadoAt, true) || 'sí'}${p.aprobadoManual ? ' (aprobado a mano)' : ''}` : p.transferenciaVencida ? 'Transferencia vencida' : p.metodoPago === 'transferencia' ? (p.comprobante ? 'Comprobante subido, sin aprobar' : 'Sin comprobante') : 'No'}</dd></div>
        <div><dt className="text-slate-400">Fotos elegidas</dt><dd className="text-slate-700">{p.seleccionPendiente ? 'Todavía no eligió (reserva)' : `${p.fotosElegidas}${p.copiasExtras ? ` + ${p.copiasExtras} copias extra` : ''}`}</dd></div>
        <div><dt className="text-slate-400">Laboratorio</dt><dd className="text-slate-700">{LAB[p.estadoLab || ''] || (pagado ? 'Sin enviar' : '—')}{p.entregadoAt ? ` (${fecha(p.entregadoAt)})` : ''}</dd></div>
        <div><dt className="text-slate-400">Fotos HD</dt><dd className="text-slate-700">{p.hdEnviado ? `Enviadas ${fecha(p.hdEnviadoAt)}${p.descargasHd ? ` · bajadas ${p.descargasHd}` : ' · sin bajar'}` : pagado ? 'Sin enviar' : '—'}</dd></div>
      </dl>
      {p.notaEspera && <p className="mt-1 text-[11px] text-violet-700">Nota: {p.notaEspera}</p>}
    </div>
  );
}

export default function ModalFichaCliente({
  inicial,
  onCerrar,
}: {
  inicial: { nombre?: string | null; email?: string | null; telefono?: string | null; pedido?: string | null };
  onCerrar: () => void;
}) {
  const [email, setEmail] = useState(inicial.email || '');
  const [telefono, setTelefono] = useState(inicial.telefono || '');
  const [pedido, setPedido] = useState(inicial.pedido || '');
  const [ficha, setFicha] = useState<FichaCliente | null>(null);
  const [cargando, setCargando] = useState(false);
  const [error, setError] = useState('');

  const buscar = useCallback(async (criterios: { email: string; telefono: string; pedido: string }) => {
    setCargando(true);
    setError('');
    try {
      setFicha(await obtenerFichaClienteAdmin(criterios));
    } catch (e: any) {
      setFicha(null);
      setError(e?.message || 'No se pudo cargar la ficha del cliente.');
    } finally {
      setCargando(false);
    }
  }, []);

  useEffect(() => {
    void buscar({ email: inicial.email || '', telefono: inicial.telefono || '', pedido: inicial.pedido || '' });
  }, [buscar, inicial.email, inicial.telefono, inicial.pedido]);

  useEffect(() => {
    const alTeclear = (e: KeyboardEvent) => { if (e.key === 'Escape') onCerrar(); };
    window.addEventListener('keydown', alTeclear);
    return () => window.removeEventListener('keydown', alTeclear);
  }, [onCerrar]);

  const pedidosPropios = ficha?.pedidos.filter((p) => !p.soloPorNumero) || [];
  const totalPagado = pedidosPropios.filter((p) => p.estado === 'pagado' || p.estado === 'entregado').reduce((s, p) => s + p.total, 0)
    + (ficha?.pedidosEventos || []).filter((p) => p.estado === 'pagado').reduce((s, p) => s + p.total, 0);
  const sinPagar = pedidosPropios.filter((p) => p.estado === 'pendiente_pago' && !p.canceladoDefinitivo).length;

  return (
    <div className="fixed inset-0 z-50 bg-black/50 flex items-stretch sm:items-center justify-center sm:p-4" onClick={onCerrar}>
      <div role="dialog" aria-modal="true" aria-label="Ficha del cliente" className="bg-slate-50 sm:rounded-2xl w-full max-w-4xl max-h-full sm:max-h-[92vh] flex flex-col shadow-xl" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-start justify-between gap-3 px-4 sm:px-5 pt-4 pb-3 border-b border-slate-200 bg-white sm:rounded-t-2xl">
          <div className="min-w-0">
            <p className="text-[10px] font-bold uppercase tracking-wide text-slate-400">Ficha del cliente</p>
            <p className="font-extrabold text-slate-900 text-base truncate">{ficha?.inscripciones[0]?.tutor || ficha?.familias[0]?.nombre || inicial.nombre || 'Cliente'}</p>
          </div>
          <button type="button" onClick={onCerrar} className="p-1 text-slate-400 hover:text-slate-700 cursor-pointer" aria-label="Cerrar"><X className="w-5 h-5" /></button>
        </div>

        <form
          className="px-4 sm:px-5 py-3 border-b border-slate-200 bg-white grid grid-cols-1 sm:grid-cols-[1fr_1fr_0.8fr_auto] gap-2"
          onSubmit={(e) => { e.preventDefault(); void buscar({ email, telefono, pedido }); }}
        >
          <input value={email} onChange={(e) => setEmail(e.target.value)} placeholder="Email" aria-label="Email" className="px-3 py-2 border border-slate-200 rounded-xl text-xs" />
          <input value={telefono} onChange={(e) => setTelefono(e.target.value)} placeholder="Teléfono / WhatsApp" aria-label="Teléfono" className="px-3 py-2 border border-slate-200 rounded-xl text-xs" />
          <input value={pedido} onChange={(e) => setPedido(e.target.value)} placeholder="N° de pedido" aria-label="Número de pedido" className="px-3 py-2 border border-slate-200 rounded-xl text-xs" />
          <button type="submit" disabled={cargando} className="px-3 py-2 bg-slate-900 hover:bg-slate-700 text-white rounded-xl text-xs font-bold inline-flex items-center justify-center gap-1.5 disabled:opacity-50 cursor-pointer">
            {cargando ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Search className="w-3.5 h-3.5" />}Buscar
          </button>
        </form>

        <div className="overflow-y-auto px-4 sm:px-5 py-4 space-y-5">
          {error && <p className="p-3 rounded-xl border border-red-200 bg-red-50 text-red-700 text-xs">{error}</p>}
          {cargando && !ficha && <div className="py-12 text-center text-slate-400"><Loader2 className="w-6 h-6 animate-spin mx-auto" /></div>}
          {ficha && !ficha.encontrado && (
            <p className="p-4 rounded-xl border border-amber-200 bg-amber-50 text-amber-900 text-xs">No hay inscripciones, compras ni pedidos con estos datos. Probá con otro email o con el teléfono de la familia.</p>
          )}

          {ficha && ficha.encontrado && (
            <>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {[
                  ['Hijos', String(ficha.hijos.length)],
                  ['Pedidos', String(pedidosPropios.length + ficha.pedidosEventos.length)],
                  ['Sin pagar', String(sinPagar)],
                  ['Total pagado', pesos(totalPagado)],
                ].map(([t, v]) => (
                  <div key={t} className="rounded-xl bg-white border border-slate-200 p-3">
                    <p className="text-[10px] font-bold uppercase text-slate-400">{t}</p>
                    <p className="text-lg font-extrabold text-slate-900">{v}</p>
                  </div>
                ))}
              </div>

              {ficha.pedidoMencionado && !ficha.pedidoMencionado.encontrado && (
                <p className="p-3 rounded-xl border border-amber-200 bg-amber-50 text-amber-900 text-xs">El pedido {ficha.pedidoMencionado.numero} no existe en el sistema.</p>
              )}

              <Seccion titulo="Datos e inscripciones" icono={<User className="w-3.5 h-3.5" />} vacio={ficha.inscripciones.length === 0 && ficha.familias.length === 0 && 'Sin inscripción con estos datos.'}>
                <div className="grid gap-2 sm:grid-cols-2">
                  {ficha.inscripciones.map((i) => (
                    <div key={i.id} className="rounded-xl border border-slate-200 bg-white p-3 text-xs space-y-1">
                      <div className="flex items-center justify-between gap-2">
                        <p className="font-bold text-slate-900">{i.tutor || 'Tutor sin nombre'}</p>
                        <Etiqueta texto={INSCRIPCION[i.estado] || i.estado} estilo={i.estado === 'aceptado' ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'} />
                      </div>
                      <p className="text-slate-600">{i.colegio || 'Colegio sin nombre'}</p>
                      {i.email && <p className="flex items-center gap-1 text-slate-600"><Mail className="w-3 h-3" />{i.email}</p>}
                      {i.telefono && <p className="flex items-center gap-1 text-slate-600"><Phone className="w-3 h-3" />{i.telefono}</p>}
                      <p className="text-[11px] text-slate-500">DNI tutor: {i.dniTutor || 'sin cargar'} · Código: <span className="font-mono">{i.codigo || '—'}</span>{i.estado === 'aceptado' ? (i.emailCodigoEnviado ? ' (enviado)' : ' (sin enviar)') : ''}</p>
                      <p className="text-[11px] text-slate-500">Inscripta {fecha(i.createdAt)}{i.accesoConfirmadoAt ? ` · entró a la galería ${fecha(i.accesoConfirmadoAt)}` : ' · todavía no confirmó el acceso'}{i.fotoHermanos ? ' · quiere foto de hermanos' : ''}</p>
                    </div>
                  ))}
                  {ficha.familias
                    .filter((f) => !ficha.inscripciones.some((i) => (i.email || '').toLowerCase() === (f.email || '').toLowerCase()))
                    .map((f) => (
                      <div key={f.id} className="rounded-xl border border-slate-200 bg-white p-3 text-xs space-y-1">
                        <p className="font-bold text-slate-900">{f.nombre || 'Sin nombre'} <span className="font-normal text-slate-400">(datos de compra)</span></p>
                        {f.email && <p className="flex items-center gap-1 text-slate-600"><Mail className="w-3 h-3" />{f.email}</p>}
                        {f.whatsapp && <p className="flex items-center gap-1 text-slate-600"><Phone className="w-3 h-3" />{f.whatsapp}</p>}
                      </div>
                    ))}
                </div>
              </Seccion>

              <Seccion titulo="Hijos" icono={<GraduationCap className="w-3.5 h-3.5" />} vacio={ficha.hijos.length === 0 && 'No hay hijos inscriptos con estos datos.'}>
                <div className="rounded-xl border border-slate-200 bg-white divide-y divide-slate-100">
                  {ficha.hijos.map((h) => (
                    <div key={`${h.inscripcionId}-${h.nombre}`} className="p-3 text-xs flex flex-wrap items-start justify-between gap-2">
                      <div className="min-w-0">
                        <p className="font-bold text-slate-900">{h.nombre}{h.dni ? <span className="font-normal text-slate-400"> · DNI {h.dni}</span> : null}</p>
                        <p className="text-slate-600">{h.colegio} — {curso(h.curso)}</p>
                        <p className={`flex items-center gap-1 text-[11px] ${h.coincideConNomina ? 'text-emerald-700' : 'text-amber-700'}`}>
                          {h.coincideConNomina ? <CheckCircle2 className="w-3 h-3" /> : <AlertTriangle className="w-3 h-3" />}
                          {h.coincideConNomina ? 'Coincide con la nómina' : h.enNomina ? `En la nómina figura en ${curso(h.cursoNomina)}` : 'No figura en la nómina'}
                        </p>
                        {h.fotosPublicadas !== null && <p className="text-[11px] text-slate-500">Fotos publicadas del curso: {h.fotosPublicadas}</p>}
                      </div>
                      <Etiqueta texto={h.pagado ? 'Pagó' : h.pedidos ? 'Pedido sin pagar' : 'Sin pedido'} estilo={h.pagado ? 'bg-emerald-100 text-emerald-800' : h.pedidos ? 'bg-amber-100 text-amber-800' : 'bg-slate-100 text-slate-600'} />
                    </div>
                  ))}
                </div>
              </Seccion>

              <Seccion titulo="Pedidos del colegio" icono={<CreditCard className="w-3.5 h-3.5" />} vacio={ficha.pedidos.length === 0 && 'No hizo pedidos del colegio.'}>
                <div className="space-y-2">{ficha.pedidos.map((p) => <TarjetaPedido key={p.id} p={p} />)}</div>
              </Seccion>

              {ficha.pedidosEventos.length > 0 && (
                <Seccion titulo="Pedidos de eventos" icono={<CreditCard className="w-3.5 h-3.5" />}>
                  <div className="rounded-xl border border-slate-200 bg-white divide-y divide-slate-100">
                    {ficha.pedidosEventos.map((p) => (
                      <div key={p.id} className="p-3 text-xs flex flex-wrap items-start justify-between gap-2">
                        <div>
                          <p className="font-bold text-slate-900">{p.numero || 'Sin número'} · {p.evento || 'Evento'}</p>
                          <p className="text-slate-600">{[p.nino, p.curso].filter(Boolean).join(' — ') || '—'} · {pesos(p.total)} · {METODO[p.medioPago || ''] || p.medioPago || '—'}</p>
                          <p className="text-[11px] text-slate-500">Pedido {fecha(p.createdAt, true)}{p.fechaPago ? ` · pagado ${fecha(p.fechaPago, true)}` : ''}{p.estadoEntrega ? ` · ${LAB[p.estadoEntrega] || p.estadoEntrega}` : ''}{p.digitalesEnviados ? ' · digitales enviadas' : ''}</p>
                        </div>
                        <Etiqueta {...(ESTADO_PEDIDO[p.estado] || { texto: p.estado, estilo: 'bg-slate-100 text-slate-700' })} />
                      </div>
                    ))}
                  </div>
                </Seccion>
              )}

              {ficha.observaciones.length > 0 && (
                <Seccion titulo="Observaciones de la toma" icono={<ClipboardList className="w-3.5 h-3.5" />}>
                  <ul className="rounded-xl border border-slate-200 bg-white divide-y divide-slate-100">
                    {ficha.observaciones.map((o) => (
                      <li key={o.id} className="p-3 text-xs">
                        <span className="font-bold text-slate-900">{o.alumno}</span> <span className="text-slate-500">({o.curso})</span>: {OBSERVACION[o.tipo] || o.tipo}{o.detalle ? ` — ${o.detalle}` : ''} <span className="text-slate-400">· {fecha(o.createdAt)}</span>
                      </li>
                    ))}
                  </ul>
                </Seccion>
              )}

              {ficha.consultas.length > 0 && (
                <Seccion titulo="Consultas de este email" icono={<Inbox className="w-3.5 h-3.5" />}>
                  <ul className="rounded-xl border border-slate-200 bg-white divide-y divide-slate-100">
                    {ficha.consultas.map((c) => (
                      <li key={c.id} className="p-3 text-xs flex justify-between gap-2"><span className="truncate text-slate-800">{c.asunto}</span><span className="shrink-0 text-slate-400">{c.estado} · {fecha(c.createdAt)}</span></li>
                    ))}
                  </ul>
                </Seccion>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
}
