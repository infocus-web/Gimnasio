import React, { useEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { Check, Loader2, Mail, Search, UserPlus, X } from 'lucide-react';
import type { InscripcionFamilia } from '../services/inscripcionesService';
import { enviarEmailAprobacionAdmin } from '../services/inscripcionesService';
import { buscarHijosEnNomina, sumarHijoAInscripcion, type AlumnoNominaCandidato } from '../services/sumarHijoService';

/**
 * 27/10/2026 (Pablo): Inscriptos → «Sumar hijo». Para la familia que se inscribió con un hijo y se olvidó de
 * otro: se busca al chico en la nómina del colegio, se suma como hermano y se ofrece reenviar el código (el
 * mismo de siempre; el email lista a todos los hijos). Antes se hacía con SQL a mano.
 */
export default function SumarHijoInscripcion({ inscripcion, onCambio }: { inscripcion: InscripcionFamilia; onCambio: () => void | Promise<void> }) {
  const [abierto, setAbierto] = useState(false);
  const [q, setQ] = useState('');
  const [buscando, setBuscando] = useState(false);
  const [resultados, setResultados] = useState<AlumnoNominaCandidato[] | null>(null);
  const [sumandoId, setSumandoId] = useState<string | null>(null);
  const [sumado, setSumado] = useState<AlumnoNominaCandidato | null>(null);
  const [reenvio, setReenvio] = useState<'no' | 'enviando' | 'ok'>('no');
  const [error, setError] = useState<string | null>(null);
  const entrada = useRef<HTMLInputElement>(null);

  const cerrar = () => {
    setAbierto(false);
    setQ('');
    setResultados(null);
    setSumado(null);
    setReenvio('no');
    setError(null);
  };

  useEffect(() => {
    if (!abierto) return;
    entrada.current?.focus();
    const alTeclado = (e: KeyboardEvent) => e.key === 'Escape' && cerrar();
    window.addEventListener('keydown', alTeclado);
    return () => window.removeEventListener('keydown', alTeclado);
  }, [abierto]);

  const buscar = async (e?: React.FormEvent) => {
    e?.preventDefault();
    if (q.trim().length < 2) return setError('Escribí al menos 2 letras del nombre.');
    setBuscando(true);
    setError(null);
    const r = await buscarHijosEnNomina(inscripcion.id, q.trim());
    setBuscando(false);
    if (!r.success) return setError(r.error || 'No se pudo buscar.');
    setResultados(r.alumnos || []);
  };

  const sumar = async (a: AlumnoNominaCandidato) => {
    setSumandoId(a.id);
    setError(null);
    const r = await sumarHijoAInscripcion(inscripcion.id, a.id);
    setSumandoId(null);
    if (!r.success) return setError(r.error || 'No se pudo sumar.');
    setSumado(a);
    await onCambio();
  };

  const reenviar = async () => {
    setReenvio('enviando');
    setError(null);
    const r = await enviarEmailAprobacionAdmin(inscripcion.id, { reenviar: true });
    if (!r.success) {
      setReenvio('no');
      return setError(r.error || 'No se pudo reenviar el email.');
    }
    setReenvio('ok');
    await onCambio();
  };

  const puedeReenviar = Boolean(inscripcion.codigoAsignado && inscripcion.email);

  return (
    <>
      <button
        type="button"
        onClick={() => setAbierto(true)}
        className="px-2.5 py-1 bg-amber-50 hover:bg-amber-100 text-amber-800 border border-amber-200 font-bold text-[11px] rounded-lg transition-colors flex items-center gap-1 cursor-pointer"
        title="Sumar otro hijo/a de la nómina a esta inscripción"
      >
        <UserPlus className="w-3 h-3" aria-hidden="true" />
        <span>Sumar hijo</span>
      </button>
      {abierto &&
        createPortal(
          <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4" onClick={cerrar}>
            <div
              role="dialog"
              aria-modal="true"
              aria-labelledby={`sumar-hijo-${inscripcion.id}`}
              onClick={(e) => e.stopPropagation()}
              className="bg-white rounded-2xl max-w-lg w-full max-h-[90vh] overflow-y-auto p-6 space-y-4 shadow-2xl border border-slate-200 text-left"
            >
              <div className="flex items-start justify-between gap-3 pb-3 border-b border-slate-100">
                <div>
                  <h3 id={`sumar-hijo-${inscripcion.id}`} className="text-base font-extrabold text-slate-900">Sumar hijo a la inscripción</h3>
                  <p className="text-xs text-slate-500 mt-0.5">
                    {inscripcion.padreNombre} · ya tiene a {[`${inscripcion.alumnoNombre} ${inscripcion.alumnoApellido}`, ...(inscripcion.hermanos || []).map((h) => `${h.alumnoNombre} ${h.alumnoApellido}`)].join(', ')}
                  </p>
                </div>
                <button type="button" onClick={cerrar} aria-label="Cerrar" className="p-1.5 rounded-lg text-slate-500 hover:bg-slate-100 cursor-pointer">
                  <X className="w-4 h-4" />
                </button>
              </div>

              {sumado ? (
                <div className="space-y-3">
                  <p className="text-sm text-emerald-800 bg-emerald-50 border border-emerald-200 rounded-xl px-3 py-2.5 flex items-start gap-2">
                    <Check className="w-4 h-4 mt-0.5 shrink-0" aria-hidden="true" />
                    <span>
                      <strong>{sumado.nombre}</strong> ({sumado.grado} "{sumado.division}") quedó sumado. Con el mismo código, nombre y DNI la familia ya lo ve.
                    </span>
                  </p>
                  {reenvio === 'ok' ? (
                    <p className="text-xs font-semibold text-blue-800">Listo: le reenviamos el código a {inscripcion.email} con todos sus hijos.</p>
                  ) : puedeReenviar ? (
                    <button
                      type="button"
                      onClick={reenviar}
                      disabled={reenvio === 'enviando'}
                      className="px-3.5 py-2 bg-blue-600 hover:bg-blue-500 disabled:opacity-60 text-white font-bold text-xs rounded-xl flex items-center gap-1.5 cursor-pointer"
                    >
                      {reenvio === 'enviando' ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Mail className="w-3.5 h-3.5" />}
                      <span>Reenviar código a {inscripcion.email}</span>
                    </button>
                  ) : (
                    <p className="text-xs text-slate-500">Esta inscripción todavía no tiene código o email: el aviso sale cuando la apruebes.</p>
                  )}
                </div>
              ) : (
                <>
                  <form onSubmit={buscar} className="flex gap-2">
                    <label className="sr-only" htmlFor={`buscar-hijo-${inscripcion.id}`}>Nombre del alumno en la nómina</label>
                    <input
                      id={`buscar-hijo-${inscripcion.id}`}
                      ref={entrada}
                      value={q}
                      onChange={(e) => setQ(e.target.value)}
                      placeholder="Nombre o apellido (ej: Perea Belen)"
                      className="flex-1 min-w-0 px-3 py-2 text-sm rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-amber-400"
                    />
                    <button type="submit" disabled={buscando} className="px-3.5 py-2 bg-slate-900 hover:bg-slate-800 disabled:opacity-60 text-white font-bold text-xs rounded-xl flex items-center gap-1.5 cursor-pointer">
                      {buscando ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Search className="w-3.5 h-3.5" />}
                      <span>Buscar</span>
                    </button>
                  </form>
                  <p className="text-[11px] text-slate-500">Busca en la nómina de {inscripcion.colegioNombre || 'su colegio'}.</p>
                  {resultados && resultados.length === 0 && <p className="text-xs text-slate-600">No hay nadie con ese nombre en la nómina.</p>}
                  {resultados && resultados.length > 0 && (
                    <ul className="divide-y divide-slate-100 border border-slate-200 rounded-xl overflow-hidden">
                      {resultados.map((a) => (
                        <li key={a.id} className="flex items-center justify-between gap-3 px-3 py-2.5">
                          <div className="min-w-0">
                            <p className="text-sm font-bold text-slate-900 truncate">{a.nombre}</p>
                            <p className="text-[11px] text-slate-500">
                              {a.grado} · Div. {a.division}
                              {a.turno ? ` · ${a.turno}` : ''}
                            </p>
                          </div>
                          {a.yaIncluido ? (
                            <span className="text-[11px] font-bold text-slate-500">Ya está</span>
                          ) : (
                            <button
                              type="button"
                              onClick={() => sumar(a)}
                              disabled={sumandoId !== null}
                              className="shrink-0 px-3 py-1.5 bg-amber-400 hover:bg-amber-300 disabled:opacity-60 text-slate-900 font-bold text-xs rounded-lg flex items-center gap-1 cursor-pointer"
                            >
                              {sumandoId === a.id ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <UserPlus className="w-3.5 h-3.5" />}
                              <span>Sumar</span>
                            </button>
                          )}
                        </li>
                      ))}
                    </ul>
                  )}
                </>
              )}
              {error && <p role="alert" className="text-xs font-semibold text-red-700">{error}</p>}
            </div>
          </div>,
          document.body
        )}
    </>
  );
}
