import { useState } from 'react';
import { AlertTriangle, Check, ChevronDown, ChevronRight, Copy, Eye, KeyRound, Loader2, Power } from 'lucide-react';
import {
  abrirVistaPreviaColegioAdmin,
  generarPinColegioAdmin,
  guardarPanelColegioAdmin,
  obtenerPanelColegioAdmin,
  type FechasCampana,
  type PanelColegioAdmin,
} from '../services/panelColegioService';
import { copiarAlPortapapeles } from '../utils/portapapeles';

/**
 * Panel del fotógrafo → Colegios → «Panel del colegio» (10/10/2026, pedido de Pablo). Por colegio: link
 * propio, PIN de 6 números (se muestra UNA vez: si se lo olvidan, se genera otro y el anterior deja de
 * valer), prender/apagar el acceso y las fechas de la campaña que usan los mensajes de difusión.
 * Se carga recién al abrirlo, para no pedir los datos de todos los colegios al entrar a la pestaña.
 */
export default function AdminPanelColegioAcceso({ colegioId, colegioNombre }: { colegioId: string; colegioNombre: string }) {
  const [abierto, setAbierto] = useState(false);
  const [panel, setPanel] = useState<PanelColegioAdmin | null>(null);
  const [cargando, setCargando] = useState(false);
  const [trabajando, setTrabajando] = useState(false);
  const [error, setError] = useState('');
  const [pinNuevo, setPinNuevo] = useState('');
  const [fechas, setFechas] = useState<FechasCampana>({ tomaFotos: null, cierrePedidos: null, entregaKits: null });
  const [copiado, setCopiado] = useState<string | null>(null);
  const [guardadoFechas, setGuardadoFechas] = useState(false);
  const [abriendoVista, setAbriendoVista] = useState(false);
  const [vistaBloqueada, setVistaBloqueada] = useState(false);

  const cargar = async () => {
    setCargando(true);
    setError('');
    try {
      const datos = await obtenerPanelColegioAdmin(colegioId);
      setPanel(datos);
      setFechas(datos.fechas);
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setCargando(false);
    }
  };

  const alternar = () => {
    const abrir = !abierto;
    setAbierto(abrir);
    if (abrir && !panel) void cargar();
  };

  const copiar = (texto: string, clave: string) => {
    void copiarAlPortapapeles(texto);
    setCopiado(clave);
    window.setTimeout(() => setCopiado(null), 2000);
  };

  const generarPin = async () => {
    if (panel?.tienePin && !window.confirm(`¿Generar un PIN nuevo para ${colegioNombre}?\n\nEl PIN anterior deja de funcionar y se cierran las sesiones abiertas.`)) return;
    setTrabajando(true);
    setError('');
    try {
      const resultado = await generarPinColegioAdmin(colegioId);
      setPanel(resultado.panel);
      setPinNuevo(resultado.pin);
    } catch (e) {
      // 14/10/2026 (auditoría): si la respuesta se perdió, el servidor pudo haber cambiado el PIN igual (y el
      // anterior ya no anda): no hay forma de recuperar el nuevo, hay que generar otro.
      setError(`${(e as Error).message} Ojo: el PIN anterior puede haber dejado de funcionar. Generá uno nuevo y pasáselo al colegio.`);
    } finally {
      setTrabajando(false);
    }
  };

  const cambiarActivo = async (activo: boolean) => {
    if (!activo && !window.confirm(`¿Apagar el acceso de ${colegioNombre}?\n\nSe cierran las sesiones abiertas. Lo podés volver a prender cuando quieras (con el mismo PIN).`)) return;
    setTrabajando(true);
    setError('');
    try {
      setPanel(await guardarPanelColegioAdmin(colegioId, { activo }));
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setTrabajando(false);
    }
  };

  // Vista previa (Pablo, 10/10: «quiero ver cómo es el panel»): sólo lectura, sin PIN ni convenio, 2 horas.
  // La pestaña se abre en el mismo clic (si no, el navegador la bloquea) y se completa al tener la sesión.
  const verVistaPrevia = async () => {
    setAbriendoVista(true);
    setVistaBloqueada(false);
    setError('');
    const ventana = window.open('', '_blank');
    try {
      await abrirVistaPreviaColegioAdmin(colegioId);
      if (ventana) ventana.location.href = '/colegio?vista=1';
      else setVistaBloqueada(true);
    } catch (e) {
      ventana?.close();
      setError((e as Error).message);
    } finally {
      setAbriendoVista(false);
    }
  };

  const guardarFechas = async () => {
    setTrabajando(true);
    setError('');
    try {
      const actualizado = await guardarPanelColegioAdmin(colegioId, { fechas });
      setPanel(actualizado);
      setFechas(actualizado.fechas);
      setGuardadoFechas(true);
      window.setTimeout(() => setGuardadoFechas(false), 2000);
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setTrabajando(false);
    }
  };

  // Sin convenio firmado el colegio no puede entrar: el mensaje le pide primero firmarlo.
  const mensajeParaColegio = panel?.link && pinNuevo
    ? panel.convenio.firmado || !panel.convenio.link
      ? `Hola, les comparto el acceso al panel del colegio de Retrato Escolar:\n${panel.link}\nPIN: ${pinNuevo}\n\nAhí van a ver la comisión, cómo viene cada curso, mensajes para difundir a las familias y la lista para entregar los kits impresos.`
      : `Hola, les comparto el acceso al panel del colegio de Retrato Escolar. El panel se habilita cuando el colegio firma el convenio:\n\n1) Leer y firmar el convenio: ${panel.convenio.link}\n2) Entrar al panel: ${panel.link}\nPIN: ${pinNuevo}\n\nAhí van a ver la comisión, cómo viene cada curso, mensajes para difundir a las familias y la lista para entregar los kits impresos.`
    : '';

  return (
    <div className="pt-1.5 mt-1.5 border-t border-slate-100 space-y-1.5">
      <button type="button" onClick={alternar} className="flex items-center gap-1 text-[10px] font-bold text-slate-500 uppercase tracking-wider hover:text-amber-700 cursor-pointer">
        {abierto ? <ChevronDown className="w-3 h-3" /> : <ChevronRight className="w-3 h-3" />}
        Panel del colegio (link + PIN)
        {panel && (
          <span className={`ml-1 normal-case tracking-normal px-1.5 py-0.5 rounded ${panel.activo ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-100 text-slate-500'}`}>
            {panel.activo ? 'Activo' : panel.tienePin ? 'Apagado' : 'Sin PIN'}
          </span>
        )}
      </button>

      {abierto && (
        <div className="space-y-2 rounded-xl border border-slate-200 bg-slate-50 p-2.5">
          {cargando && <p className="flex items-center gap-1.5 text-[11px] text-slate-500"><Loader2 className="w-3 h-3 animate-spin" /> Cargando…</p>}
          {error && <p className="text-[11px] font-semibold text-red-600">{error}</p>}

          {panel && (
            <>
              {panel.convenio.firmado ? (
                <p className="flex items-center gap-1.5 text-[11px] font-semibold text-emerald-700">
                  <Check className="w-3.5 h-3.5" /> Convenio firmado{panel.convenio.fecha ? ` el ${new Date(panel.convenio.fecha).toLocaleDateString('es-AR', { timeZone: 'America/Argentina/Buenos_Aires' })}` : ''}: el colegio puede entrar.
                </p>
              ) : (
                <div className="rounded-lg border border-amber-300 bg-amber-50 p-2 space-y-1.5">
                  <p className="flex items-start gap-1.5 text-[11px] font-semibold text-amber-900">
                    <AlertTriangle className="w-3.5 h-3.5 shrink-0 mt-px" />
                    Todavía no firmó el convenio: con el PIN no va a poder entrar hasta firmarlo (al intentarlo le aparece el botón para firmar).
                  </p>
                  {panel.convenio.link && (
                    <button type="button" onClick={() => copiar(panel.convenio.link || '', 'convenio')} className="flex items-center gap-1.5 rounded-lg border border-amber-300 bg-white hover:bg-amber-100 px-2.5 py-1 text-[11px] font-bold text-amber-900 cursor-pointer">
                      {copiado === 'convenio' ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                      {copiado === 'convenio' ? 'Copiado' : 'Copiar link del convenio'}
                    </button>
                  )}
                </div>
              )}

              {panel.link ? (
                <div className="flex items-center gap-1.5">
                  <input
                    type="text"
                    readOnly
                    value={panel.link}
                    onFocus={(e) => e.target.select()}
                    className="flex-1 min-w-0 px-2 py-1 rounded-lg border border-slate-200 bg-white text-[10px] font-mono text-slate-600"
                  />
                  <button type="button" onClick={() => copiar(panel.link || '', 'link')} title="Copiar link" className="p-1.5 rounded-lg text-slate-400 hover:text-amber-600 hover:bg-amber-50 cursor-pointer shrink-0">
                    {copiado === 'link' ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                  </button>
                </div>
              ) : (
                <p className="text-[11px] text-slate-500">Todavía no tiene acceso. Generá el PIN y se crea el link.</p>
              )}

              {pinNuevo && (
                <div className="rounded-lg border-2 border-amber-400 bg-amber-50 p-2 space-y-1.5">
                  <p className="text-[11px] text-amber-900">
                    PIN de {colegioNombre}: <strong className="font-mono text-base tracking-[0.3em]">{pinNuevo}</strong>
                  </p>
                  <p className="text-[10px] text-amber-800">Se muestra una sola vez: copialo y mandáselo al colegio. Si se lo olvidan, generá otro.</p>
                  <button type="button" onClick={() => copiar(mensajeParaColegio, 'mensaje')} className="flex items-center gap-1.5 rounded-lg bg-amber-400 hover:bg-amber-300 px-2.5 py-1 text-[11px] font-bold text-slate-950 cursor-pointer">
                    {copiado === 'mensaje' ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                    {copiado === 'mensaje' ? 'Copiado' : 'Copiar mensaje con link y PIN'}
                  </button>
                </div>
              )}

              <div className="flex flex-wrap gap-1.5">
                <button
                  type="button"
                  disabled={trabajando}
                  onClick={() => void generarPin()}
                  className="flex items-center gap-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 px-2.5 py-1 text-[11px] font-bold text-white disabled:opacity-50 cursor-pointer"
                >
                  {trabajando ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <KeyRound className="w-3.5 h-3.5" />}
                  {panel.tienePin ? 'PIN nuevo' : 'Generar PIN'}
                </button>
                <button
                  type="button"
                  disabled={abriendoVista}
                  onClick={() => void verVistaPrevia()}
                  className="flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white hover:bg-slate-100 px-2.5 py-1 text-[11px] font-bold text-slate-700 disabled:opacity-50 cursor-pointer"
                >
                  {abriendoVista ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Eye className="w-3.5 h-3.5" />}
                  Ver cómo lo ve el colegio
                </button>
                {panel.tienePin && (
                  <button
                    type="button"
                    disabled={trabajando}
                    onClick={() => void cambiarActivo(!panel.activo)}
                    className={`flex items-center gap-1.5 rounded-lg border px-2.5 py-1 text-[11px] font-bold disabled:opacity-50 cursor-pointer ${panel.activo ? 'border-rose-200 bg-white text-rose-700 hover:bg-rose-50' : 'border-emerald-300 bg-white text-emerald-700 hover:bg-emerald-50'}`}
                  >
                    <Power className="w-3.5 h-3.5" />
                    {panel.activo ? 'Apagar acceso' : 'Prender acceso'}
                  </button>
                )}
              </div>

              {vistaBloqueada && (
                <p className="text-[11px] text-slate-600">
                  El navegador bloqueó la pestaña nueva:{' '}
                  <a href="/colegio?vista=1" target="_blank" rel="noopener" className="font-bold text-amber-700 underline">
                    abrir la vista previa
                  </a>
                </p>
              )}

              <div className="space-y-1">
                <p className="text-[10px] font-bold text-slate-500">Fechas de la campaña (aparecen en el panel y en los mensajes para las familias)</p>
                <div className="grid grid-cols-1 gap-1.5 sm:grid-cols-3">
                  {(
                    [
                      ['tomaFotos', 'Toma de fotos'],
                      ['cierrePedidos', 'Cierre de pedidos'],
                      ['entregaKits', 'Entrega de kits'],
                    ] as [keyof FechasCampana, string][]
                  ).map(([clave, texto]) => (
                    <label key={clave} className="text-[10px] text-slate-600">
                      {texto}
                      <input
                        type="date"
                        value={fechas[clave] || ''}
                        onChange={(e) => setFechas((f) => ({ ...f, [clave]: e.target.value || null }))}
                        className="mt-0.5 block w-full rounded-lg border border-slate-200 bg-white px-2 py-1 text-[11px]"
                      />
                    </label>
                  ))}
                </div>
                <button
                  type="button"
                  disabled={trabajando}
                  onClick={() => void guardarFechas()}
                  className="flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white hover:bg-slate-100 px-2.5 py-1 text-[11px] font-bold text-slate-700 disabled:opacity-50 cursor-pointer"
                >
                  {guardadoFechas ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : null}
                  {guardadoFechas ? 'Guardado' : 'Guardar fechas'}
                </button>
              </div>
            </>
          )}
        </div>
      )}
    </div>
  );
}
