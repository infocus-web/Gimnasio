import { useCallback, useEffect, useState } from 'react';
import { Wrench } from 'lucide-react';
import { fetchAdminAutenticado } from '../services/adminAuthService';

/**
 * MODO MANTENIMIENTO (09/10/2026, pedido de Pablo): interruptor en «Estado del sistema». Prendido, toda
 * la web muestra "Estamos realizando mantenimiento a la plataforma…" (middleware.ts) salvo para este
 * navegador y los avisos de pago, que siguen entrando. Cambia en unos segundos, sin volver a publicar.
 */
export default function AdminModoMantenimiento() {
  const [activo, setActivo] = useState<boolean | null>(null);
  const [desde, setDesde] = useState<string | null>(null);
  const [guardando, setGuardando] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const cargar = useCallback(async () => {
    try {
      const res = await fetchAdminAutenticado('/api/admin/mantenimiento');
      const data = await res.json();
      if (!res.ok || !data.success) throw new Error(data?.error);
      setActivo(Boolean(data.activo));
      setDesde(data.desde || null);
      setError(null);
    } catch {
      setError('No se pudo leer el modo mantenimiento.');
    }
  }, []);

  useEffect(() => {
    void cargar();
  }, [cargar]);

  const cambiar = async (nuevo: boolean) => {
    const pregunta = nuevo
      ? '¿Poner la web en mantenimiento? Las familias van a ver el cartel de mantenimiento hasta que lo apagues. Vos vas a poder seguir usándola desde este navegador.'
      : '¿Sacar la web de mantenimiento? Las familias van a poder volver a entrar.';
    if (!window.confirm(pregunta)) return;
    setGuardando(true);
    try {
      const res = await fetchAdminAutenticado('/api/admin/mantenimiento', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ activo: nuevo }),
      });
      const data = await res.json();
      if (!res.ok || !data.success) throw new Error(data?.error);
      setActivo(Boolean(data.activo));
      setDesde(data.desde || null);
      setError(null);
    } catch {
      setError('No se pudo cambiar el modo mantenimiento. Probá de nuevo.');
    } finally {
      setGuardando(false);
    }
  };

  if (activo === null && !error) return null;

  return (
    // 14/10/2026 (Pablo: el encabezado ocupaba 2/3 de la pantalla): va en la misma línea del estado del sistema.
    <div
      className={`flex flex-wrap items-center gap-1.5 rounded-full border px-2 py-0.5 ${
        activo ? 'border-amber-300 bg-amber-50 text-amber-900' : 'border-slate-200 bg-slate-50 text-slate-600'
      }`}
    >
      <Wrench className="h-3 w-3" />
      <span className="font-bold">Mantenimiento:</span>
      <span className="font-semibold">
        {activo === null ? '—' : activo ? 'PRENDIDO (las familias ven el cartel)' : 'apagado'}
        {activo && desde ? ` · desde ${new Date(desde).toLocaleString('es-AR', { hour: '2-digit', minute: '2-digit', day: '2-digit', month: '2-digit' })}` : ''}
      </span>
      {activo !== null && (
        <button
          type="button"
          disabled={guardando}
          onClick={() => void cambiar(!activo)}
          className={`rounded-full px-2 py-0.5 font-bold text-white disabled:opacity-60 cursor-pointer ${activo ? 'bg-emerald-600 hover:bg-emerald-700' : 'bg-amber-600 hover:bg-amber-700'}`}
        >
          {guardando ? 'Guardando…' : activo ? 'Apagar' : 'Activar'}
        </button>
      )}
      {error && <span className="basis-full font-semibold text-rose-700">{error}</span>}
    </div>
  );
}
