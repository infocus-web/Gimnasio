import { Fragment, useCallback, useEffect, useMemo, useState } from 'react';
import { AlertTriangle, CheckCircle2, FileSpreadsheet, FolderDown, FolderOpen, Image as ImageIcon, ImagePlus, Layers, Loader2, LogOut, Moon, Package, PartyPopper, Printer, RefreshCw, RotateCcw, Sun, Users } from 'lucide-react';
import CampoPin from './CampoPin';
import {
  cerrarSesionLab,
  crearLoteLab,
  descargarExcelLab,
  haySesionLab,
  ingresarLab,
  marcarLoteEnProduccion,
  nombreBase,
  obtenerDatosLab,
  opcionesArmadoLab,
  planificarZipLab,
  reportarProblemaLab,
  SesionLabVencida,
  type LoteLab,
  type PedidoLab,
} from '../services/laboratorioService';
import ResumenFacturacionLab from './ResumenFacturacionLab';
import ReimprimirPedidoLab from './ReimprimirPedidoLab';
import LotesEventosLab from './LotesEventosLab';
import LotesFotosExtraLab from './LotesFotosExtraLab';
import { useModoNoche } from '../utils/modoNoche';
import { PanelDescargaZip, useDescargaZipPorPartes } from './DescargaZipPorPartes';
import { resumenFallas } from '../services/zipLaboratorio';

type Estructura = 'solo_2_carpetas_tamano' | 'por_alumno';
// Pestañas del panel (pedido de Pablo, 2/10/2026: "redistribuir por pestañas, así queda más organizado").
type Pestana = 'nuevos' | 'lotes' | 'extras' | 'eventos' | 'reimprimir'; // 29/10: «Fotos extra» (lotes aparte de los kits)
// Auditoría 03/10 noche (R11): los avisos que empiezan así se muestran como alerta (ámbar), no como "listo".
const PREFIJO_ALERTA = '⚠️';

/**
 * Panel del laboratorio (retratoescolar.com.ar/laboratorio). Pedido de Pablo, 27/9/2026: un acceso
 * aparte para el laboratorio, que sólo descarga (ZIP en los dos modos y Excel) y gestiona sus
 * lotes. No ve datos de contacto de las familias ni importes.
 */
export default function PanelLaboratorio() {
  const [logueado, setLogueado] = useState(haySesionLab());
  const [pin, setPin] = useState('');
  const [errorLogin, setErrorLogin] = useState('');
  const [ingresando, setIngresando] = useState(false);

  const [pedidos, setPedidos] = useState<PedidoLab[]>([]);
  const [lotes, setLotes] = useState<LoteLab[]>([]);
  const [cargando, setCargando] = useState(false);
  const [error, setError] = useState('');
  const [aviso, setAviso] = useState('');
  const [estructura, setEstructura] = useState<Estructura>('solo_2_carpetas_tamano');
  const [trabajando, setTrabajando] = useState<string | null>(null);
  const [actualizado, setActualizado] = useState<Date | null>(null);
  const [problemaDe, setProblemaDe] = useState<string | null>(null);
  const [motivo, setMotivo] = useState('');
  const [pestana, setPestana] = useState<Pestana>('nuevos');
  const [eventosPendientes, setEventosPendientes] = useState(0);
  const [extrasPendientes, setExtrasPendientes] = useState(0);
  const [progresoProduccion, setProgresoProduccion] = useState('');
  // Modo día / noche, igual que en el panel del fotógrafo (pedido de Pablo, 2/10).
  const [modoNoche, alternarModoNoche] = useModoNoche();

  const manejarError = useCallback((e: unknown) => {
    if (e instanceof SesionLabVencida) {
      setLogueado(false);
      setErrorLogin('La sesión venció. Ingresá de nuevo con el PIN.');
      return;
    }
    setError(e instanceof Error ? e.message : 'Algo salió mal. Probá de nuevo.');
  }, []);
  // ZIP por partes con la lista de fotos que faltan (auditoría 03/10, crítico 3).
  const zip = useDescargaZipPorPartes(manejarError);

  /** Arma el ZIP de estos pedidos: si es chico lo baja ya; si es grande muestra un botón por parte. */
  const bajarZip = async (lista: PedidoLab[], etiqueta: string, loteId?: string): Promise<string> => {
    const plan = planificarZipLab(lista, estructura);
    const r = await zip.iniciar(plan, nombreBase(lista, etiqueta), opcionesArmadoLab, loteId); // 14/10: recuerda las partes bajadas
    const avisoExcluidos = plan.pedidosExcluidos.length > 0 ? ` Ojo: ${plan.pedidosExcluidos.length} pedido(s) no entran al ZIP (en espera, archivados o sin fotos elegidas).` : '';
    if (r.partes > 1) return ` Es grande: bajalo en ${r.partes} partes con los botones de abajo.${avisoExcluidos}`;
    if (r.fallas.length > 0) setError(`Faltan ${r.fallas.length} foto(s) en el ZIP (van como tarjeta roja FALTA_…, no imprimir): ${resumenFallas(r.fallas)}.`);
    return avisoExcluidos;
  };

  // `conservarError`: al recargar después de una acción no se borra el error que esa acción mostró.
  const cargar = useCallback(async (conservarError = false) => {
    setCargando(true);
    if (!conservarError) setError('');
    try {
      const datos = await obtenerDatosLab();
      setPedidos(datos.pedidos);
      setLotes(datos.lotes);
      setActualizado(new Date());
    } catch (e) {
      manejarError(e);
    } finally {
      setCargando(false);
    }
  }, []);

  useEffect(() => {
    if (logueado) void cargar();
  }, [logueado, cargar]);

  const nuevos = useMemo(() => pedidos.filter((p) => !p.loteLabId && !p.estadoLab), [pedidos]);
  const contar = (lista: PedidoLab[]) => ({
    carpetas: lista.reduce((a, p) => a + p.carpetas, 0),
    c15: lista.reduce((a, p) => a + p.archivosParaLaboratorio.filter((f) => f.tamanoImpresion !== '20x30').length, 0),
    c20: lista.reduce((a, p) => a + p.archivosParaLaboratorio.filter((f) => f.tamanoImpresion === '20x30').length, 0),
  });
  const totNuevos = contar(nuevos);

  const ingresar = async (e: React.FormEvent) => {
    e.preventDefault();
    setIngresando(true);
    setErrorLogin('');
    const r = await ingresarLab(pin.trim());
    setIngresando(false);
    if (!r.success) return setErrorLogin(r.error || 'No se pudo ingresar.');
    setPin('');
    setLogueado(true);
  };

  const descargarNuevos = async () => {
    setError('');
    setAviso('');
    setTrabajando('nuevos');
    try {
      // Auditoría 03/10 (alto 19): antes el lote se armaba en el servidor con TODOS los pedidos
      // nuevos, pero el ZIP con la lista vieja del navegador — los pagados después de la última
      // carga quedaban en el lote y fuera del ZIP (nunca se imprimían). Ahora se refresca antes,
      // y el ZIP se arma sólo con los pedidos que el servidor dice que están en el lote.
      let datos = await obtenerDatosLab();
      setPedidos(datos.pedidos);
      setLotes(datos.lotes);
      const r = await crearLoteLab();
      if (!r.success || !r.lote || !r.pedidoIds) {
        setError(r.error || 'No se pudo armar el lote.');
        await cargar(true);
        return;
      }
      const ids = new Set(r.pedidoIds);
      const loteId = r.lote.id;
      const delLoteEn = (lista: PedidoLab[]) => lista.filter((p) => (p.supabaseId && ids.has(p.supabaseId)) || p.loteLabId === loteId);
      let delLote = delLoteEn(datos.pedidos);
      if (delLote.length !== ids.size) {
        // Entró un pedido entre la recarga y el lote: se vuelve a pedir la lista, ya con el lote puesto.
        datos = await obtenerDatosLab();
        setPedidos(datos.pedidos);
        setLotes(datos.lotes);
        delLote = delLoteEn(datos.pedidos);
      }
      if (delLote.length !== ids.size || delLote.some((p) => !p.supabaseId || !ids.has(p.supabaseId))) {
        setError(
          `El Lote N° ${r.lote.numero} quedó con ${ids.size} pedido(s), pero el panel sólo encontró ${delLote.length}. No se bajó nada para no dejar pedidos afuera: tocá "Actualizar" y bajalo desde la pestaña Lotes.`
        );
        await cargar(true);
        return;
      }
      const etiqueta = `LOTE_${r.lote.numero}`;
      await descargarExcelLab(delLote, etiqueta);
      const extra = await bajarZip(delLote, etiqueta, loteId);
      setAviso(`Lote N° ${r.lote.numero} armado (${delLote.length} pedidos).${extra} Cuando lo empiecen a imprimir, tocá "Marcar en producción".`);
      await cargar(true);
    } catch (e) {
      manejarError(e);
    } finally {
      setTrabajando(null);
    }
  };

  const pedidosDeLote = (loteId: string) => pedidos.filter((p) => p.loteLabId === loteId);

  const redescargar = async (lote: LoteLab, tipo: 'zip' | 'excel') => {
    setError('');
    setTrabajando(`${tipo}-${lote.id}`);
    try {
      const lista = pedidosDeLote(lote.id);
      if (tipo === 'excel') await descargarExcelLab(lista, `LOTE_${lote.numero}`);
      else {
        // Auditoría 03/10 noche (R11): antes el aviso de lote incompleto se pisaba con el de partes /
        // excluidos y el laboratorio no se enteraba. Ahora se concatenan, el de lote incompleto primero.
        const avisoIncompleto =
          lista.length !== lote.cantidad
            ? `${PREFIJO_ALERTA} OJO: el Lote N° ${lote.numero} tiene ${lote.cantidad} pedido(s) y el panel muestra ${lista.length}: el ZIP puede venir incompleto (tocá "Actualizar" y volvé a bajarlo).`
            : '';
        setAviso(avisoIncompleto);
        const extra = await bajarZip(lista, `LOTE_${lote.numero}`, lote.id);
        const textos = [avisoIncompleto, extra ? `Lote N° ${lote.numero}.${extra}` : ''].filter(Boolean);
        if (textos.length > 0) setAviso(textos.join(' '));
      }
    } catch (e) {
      manejarError(e);
    } finally {
      setTrabajando(null);
    }
  };

  const enProduccion = async (lote: LoteLab) => {
    if (!window.confirm(`¿Marcar el Lote N° ${lote.numero} "En producción"? Cada familia recibe un email avisando que sus fotos se están imprimiendo.`)) return;
    setError('');
    setTrabajando(`prod-${lote.id}`);
    try {
      const r = await marcarLoteEnProduccion(lote.id, (avisados, restantes) =>
        setProgresoProduccion(`Lote N° ${lote.numero}: ${avisados} familia(s) avisadas, faltan ${restantes}…`)
      );
      if (!r.success) setError(r.error || 'No se pudo marcar el lote.');
      else
        setAviso(
          `Lote N° ${lote.numero} en producción. Se avisó a ${r.avisados ?? 0} familia(s).${r.errores?.length ? ` No se pudo avisar a ${r.errores.length}: ${r.errores.slice(0, 3).join('; ')}` : ''}`
        );
      await cargar(true);
    } catch (e) {
      manejarError(e);
    } finally {
      setTrabajando(null);
      setProgresoProduccion('');
    }
  };

  const enviarProblema = async (p: PedidoLab) => {
    if (!p.supabaseId) return;
    setTrabajando(`prob-${p.supabaseId}`);
    try {
      const r = await reportarProblemaLab(p.supabaseId, motivo.trim());
      if (!r.success) setError(r.error || 'No se pudo enviar el reporte.');
      else {
        setAviso(`Listo: le avisamos al fotógrafo del problema con ${p.alumnoNombre}.`);
        setProblemaDe(null);
        setMotivo('');
      }
    } catch (e) {
      manejarError(e);
    } finally {
      setTrabajando(null);
    }
  };

  const fecha = (iso: string) =>
    new Date(iso).toLocaleString('es-AR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' });

  if (!logueado) {
    return (
      <div className={`flex min-h-screen items-center justify-center bg-slate-950 p-4 ${modoNoche ? 'modo-noche' : ''}`}>
        <form onSubmit={ingresar} className="w-full max-w-sm space-y-4 rounded-2xl bg-white p-6 shadow-xl">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-amber-400">
              <Printer className="h-5 w-5 text-slate-950" />
            </div>
            <div>
              <h1 className="font-['Outfit'] text-lg font-extrabold text-slate-900">Panel del Laboratorio</h1>
              <p className="text-xs text-slate-500">Retrato Escolar</p>
            </div>
          </div>
          <CampoPin
            inputMode="numeric"
            value={pin}
            onChange={(e) => setPin(e.target.value)}
            placeholder="PIN del laboratorio"
            className="w-full rounded-xl border border-slate-300 px-4 py-3 text-center text-sm font-bold tracking-widest"
            autoFocus
          />
          {errorLogin && <p className="text-xs font-semibold text-red-600">{errorLogin}</p>}
          <button
            type="submit"
            disabled={ingresando || !pin.trim()}
            className="flex w-full items-center justify-center gap-2 rounded-xl bg-amber-400 py-3 text-sm font-bold text-slate-950 hover:bg-amber-300 disabled:opacity-50"
          >
            {ingresando && <Loader2 className="h-4 w-4 animate-spin" />}
            Ingresar
          </button>
        </form>
      </div>
    );
  }

  const plural = (n: number, s: string, p: string) => `${n} ${n === 1 ? s : p}`;
  const hora = actualizado ? actualizado.toLocaleTimeString('es-AR', { hour: '2-digit', minute: '2-digit' }) : '';
  const lotesPendientes = lotes.filter((l) => !l.en_produccion_at).length;

  return (
    <div className={`min-h-screen bg-slate-100 text-slate-900 ${modoNoche ? 'modo-noche' : ''}`}>
      <header className="sticky top-0 z-20 bg-gradient-to-r from-slate-950 via-slate-900 to-slate-800 text-white shadow-lg">
        <div className="mx-auto flex max-w-7xl flex-wrap items-center gap-3 px-4 py-3 sm:px-6">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-amber-400 shadow-md shadow-amber-500/30">
            <Printer className="h-5 w-5 text-slate-950" />
          </div>
          <div className="mr-auto">
            <p className="font-['Outfit'] text-lg font-extrabold leading-tight">Panel del Laboratorio</p>
            <p className="text-xs text-slate-400">Retrato Escolar{hora && ` · actualizado ${hora}`}</p>
          </div>
          <button
            type="button"
            onClick={alternarModoNoche}
            title={modoNoche ? 'Pasar a modo día' : 'Pasar a modo noche'}
            aria-label={modoNoche ? 'Pasar a modo día' : 'Pasar a modo noche'}
            className="flex items-center justify-center rounded-xl bg-white/10 p-2 hover:bg-white/20"
          >
            {modoNoche ? <Sun className="h-4 w-4 text-amber-300" /> : <Moon className="h-4 w-4" />}
          </button>
          <button type="button" onClick={() => void cargar()} className="flex items-center gap-1.5 rounded-xl bg-white/10 px-3 py-2 text-xs font-bold hover:bg-white/20">
            <RefreshCw className={`h-3.5 w-3.5 ${cargando ? 'animate-spin' : ''}`} />
            Actualizar
          </button>
          <button
            type="button"
            onClick={() => {
              cerrarSesionLab();
              setLogueado(false);
            }}
            className="flex items-center gap-1.5 rounded-xl bg-white/10 px-3 py-2 text-xs font-bold hover:bg-white/20"
          >
            <LogOut className="h-3.5 w-3.5" />
            Salir
          </button>
        </div>
      </header>

      <main className="mx-auto max-w-7xl space-y-5 px-4 py-5 sm:px-6">
        {error && <p className="rounded-2xl border border-red-200 bg-red-50 p-3 text-sm font-semibold text-red-700">{error}</p>}
        {progresoProduccion && (
          <p className="flex items-center gap-2 rounded-2xl border border-violet-200 bg-violet-50 p-3 text-sm font-semibold text-violet-800" role="status">
            <Loader2 className="h-4 w-4 animate-spin" /> {progresoProduccion}
          </p>
        )}
        <PanelDescargaZip zip={zip} />
        {aviso && (aviso.startsWith(PREFIJO_ALERTA) ? (
          // Auditoría 03/10 noche (R11): el aviso de lote incompleto va en ámbar, bien visible.
          <p role="alert" className="flex items-center gap-2 rounded-2xl border-2 border-amber-400 bg-amber-50 p-3 text-sm font-bold text-amber-900">
            <AlertTriangle className="h-5 w-5 shrink-0 text-amber-600" /> {aviso}
          </p>
        ) : (
          <p className="flex items-center gap-2 rounded-2xl border border-emerald-200 bg-emerald-50 p-3 text-sm font-semibold text-emerald-800">
            <CheckCircle2 className="h-4 w-4 shrink-0" /> {aviso}
          </p>
        ))}

        <div className="grid gap-5 lg:grid-cols-3">
          <div className="min-w-0 space-y-5 lg:col-span-2">
            <nav className="sticky top-[68px] z-10 -mx-1 flex gap-1.5 overflow-x-auto rounded-2xl border border-slate-200 bg-white/95 p-1.5 shadow-sm backdrop-blur" role="tablist" aria-label="Secciones del panel">
              {(
                [
                  ['nuevos', 'Pedidos nuevos', Package, nuevos.length, 'bg-amber-400 text-slate-950'],
                  ['lotes', 'Lotes', Layers, lotesPendientes, 'bg-violet-600 text-white'],
                  ['extras', 'Fotos extra', ImagePlus, extrasPendientes, 'bg-sky-600 text-white'],
                  ['eventos', 'Eventos', PartyPopper, eventosPendientes, 'bg-sky-500 text-white'],
                  ['reimprimir', 'Reimprimir', RotateCcw, 0, ''],
                ] as const
              ).map(([valor, texto, Icono, cuenta, colorCuenta]) => {
                const activa = pestana === valor;
                return (
                  <button
                    key={valor}
                    type="button"
                    role="tab"
                    aria-selected={activa}
                    onClick={() => setPestana(valor)}
                    className={`flex flex-1 items-center justify-center gap-2 whitespace-nowrap rounded-xl px-3 py-2.5 text-sm font-extrabold transition ${
                      activa ? 'bg-slate-900 text-white shadow-md' : 'text-slate-600 hover:bg-slate-100'
                    }`}
                  >
                    <Icono className="h-4 w-4" />
                    {texto}
                    {cuenta > 0 && <span className={`rounded-full px-2 py-0.5 text-[11px] font-black ${colorCuenta}`}>{cuenta}</span>}
                  </button>
                );
              })}
            </nav>

            {/* 29/10/2026: fotos extra (copias sueltas pedidas aparte del kit). Montado siempre, para el contador. */}
            <div hidden={pestana !== 'extras'}>
              <LotesFotosExtraLab onError={manejarError} recargarCon={actualizado} onPendientes={setExtrasPendientes} />
            </div>

            {/* Lotes del módulo de eventos (comuniones, actos). Queda montado para que el contador de la pestaña esté al día. */}
            <div hidden={pestana !== 'eventos'}>
              <LotesEventosLab onError={manejarError} recargarCon={actualizado} onPendientes={setEventosPendientes} mostrarVacio />
            </div>

            {/* Pedidos nuevos */}
            {pestana === 'nuevos' && (
            <section className="rounded-3xl border border-amber-200 bg-gradient-to-br from-amber-50 via-amber-100/40 to-emerald-50/50 p-5 shadow-sm sm:p-6">
              <div className="flex flex-wrap items-end justify-between gap-2">
                <div>
                  <p className="text-xs font-bold uppercase tracking-wider text-amber-800">Para imprimir</p>
                  <h2 className="font-['Outfit'] text-2xl font-black text-slate-900">Pedidos nuevos</h2>
                </div>
                <p className="text-xs text-slate-600">Pedidos cobrados que todavía no bajaron</p>
              </div>

              <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-4">
                {(
                  [
                    ['Pedidos', nuevos.length, Package],
                    ['Carpetas', totNuevos.carpetas, FolderOpen],
                    ['Fotos 20x30', totNuevos.c20, ImageIcon],
                    ['Fotos 15x21', totNuevos.c15, ImageIcon],
                  ] as const
                ).map(([k, v, Icono]) => (
                  <div key={k} className="rounded-2xl border border-white bg-white/80 px-4 py-3 shadow-xs">
                    <p className="flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wide text-slate-500">
                      <Icono className="h-3.5 w-3.5" /> {k}
                    </p>
                    <p className="font-['Outfit'] text-3xl font-black text-slate-900">{cargando && pedidos.length === 0 ? '…' : v}</p>
                  </div>
                ))}
              </div>

              <p className="mt-5 text-xs font-bold uppercase tracking-wider text-slate-600">Cómo querés las carpetas del ZIP</p>
              <div className="mt-2 grid gap-3 sm:grid-cols-2">
                {(
                  [
                    ['solo_2_carpetas_tamano', 'Por tamaño', 'Dos carpetas: 15x21 y 20x30. Ideal para mandar directo a la máquina.', Layers],
                    ['por_alumno', 'Por alumno', 'Una carpeta por cada alumno con todas sus fotos.', Users],
                  ] as const
                ).map(([valor, titulo, detalle, Icono]) => {
                  const activo = estructura === valor;
                  return (
                    <button
                      key={valor}
                      type="button"
                      aria-pressed={activo}
                      onClick={() => setEstructura(valor)}
                      className={`flex items-start gap-3 rounded-2xl border-2 p-3.5 text-left transition ${
                        activo ? 'border-amber-500 bg-white shadow-md' : 'border-transparent bg-white/60 hover:bg-white'
                      }`}
                    >
                      <span className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-xl ${activo ? 'bg-amber-400 text-slate-950' : 'bg-slate-100 text-slate-500'}`}>
                        <Icono className="h-4.5 w-4.5" />
                      </span>
                      <span>
                        <span className="block text-sm font-extrabold text-slate-900">{titulo}</span>
                        <span className="block text-xs text-slate-600">{detalle}</span>
                      </span>
                      {activo && <CheckCircle2 className="ml-auto h-5 w-5 shrink-0 text-amber-600" />}
                    </button>
                  );
                })}
              </div>

              <button
                type="button"
                onClick={() => void descargarNuevos()}
                disabled={nuevos.length === 0 || trabajando !== null || zip.ocupado}
                className="mt-5 flex w-full items-center justify-center gap-2 rounded-2xl bg-slate-900 px-5 py-4 text-base font-extrabold text-white shadow-lg hover:bg-slate-800 disabled:bg-slate-300 disabled:text-slate-500 disabled:shadow-none"
              >
                {trabajando === 'nuevos' ? <Loader2 className="h-5 w-5 animate-spin" /> : <FolderDown className="h-5 w-5 text-amber-400" />}
                {trabajando === 'nuevos'
                  ? 'Armando el ZIP…'
                  : nuevos.length === 0
                    ? 'No hay pedidos nuevos por ahora'
                    : `Descargar pedidos nuevos (ZIP + Excel) · ${plural(nuevos.length, 'pedido', 'pedidos')}`}
              </button>
              <p className="mt-2 text-center text-xs text-slate-600">
                Cada descarga arma un <strong>lote numerado</strong>: un pedido nunca sale en dos lotes. Los lotes quedan en la pestaña{' '}
                <button type="button" onClick={() => setPestana('lotes')} className="font-bold underline">
                  Lotes
                </button>{' '}
                para volver a bajarlos.
              </p>
            </section>
            )}

            {pestana === 'reimprimir' && (
            <ReimprimirPedidoLab
              estructura={estructura}
              onError={manejarError}
              onAviso={(t) => {
                setError('');
                setAviso(t);
              }}
            />
            )}

            {/* Lotes */}
            {pestana === 'lotes' && (
            <section className="space-y-3">
              <div className="flex items-center gap-2 px-1">
                <h2 className="font-['Outfit'] text-lg font-extrabold text-slate-900">Lotes descargados</h2>
                <span className="rounded-full bg-slate-200 px-2 py-0.5 text-xs font-bold text-slate-700">{lotes.length}</span>
                {lotesPendientes > 0 && (
                  <span className="rounded-full bg-amber-100 px-2 py-0.5 text-xs font-bold text-amber-800">
                    {lotesPendientes} sin marcar en producción
                  </span>
                )}
              </div>
              {lotes.length === 0 && (
                <p className="rounded-3xl border border-dashed border-slate-300 bg-white px-4 py-10 text-center text-sm text-slate-500">
                  Todavía no hay lotes. Cuando descarguen los pedidos nuevos, el lote aparece acá.
                </p>
              )}
              {lotes.map((lote) => {
                const lista = pedidosDeLote(lote.id);
                const t = contar(lista);
                const enProd = Boolean(lote.en_produccion_at);
                return (
                  <article key={lote.id} className="overflow-hidden rounded-3xl border border-slate-200 bg-white shadow-sm">
                    <div className="flex flex-wrap items-center gap-4 p-4 sm:p-5">
                      <div className={`flex h-14 w-14 shrink-0 flex-col items-center justify-center rounded-2xl ${enProd ? 'bg-violet-600 text-white' : 'bg-amber-400 text-slate-950'}`}>
                        <span className="text-[10px] font-bold uppercase leading-none opacity-80">Lote</span>
                        <span className="font-['Outfit'] text-2xl font-black leading-none">{lote.numero}</span>
                      </div>
                      <div className="min-w-0 flex-1">
                        <p className="font-['Outfit'] text-lg font-extrabold text-slate-900">Lote N° {lote.numero}</p>
                        <div className="mt-1 flex flex-wrap items-center gap-1.5 text-xs">
                          <span className="flex items-center gap-1 whitespace-nowrap rounded-full bg-emerald-100 px-2 py-0.5 font-bold text-emerald-800">
                            <CheckCircle2 className="h-3 w-3" /> Descargado {fecha(lote.created_at)}
                          </span>
                          <span className="text-slate-300">→</span>
                          {enProd ? (
                            <span className="flex items-center gap-1 whitespace-nowrap rounded-full bg-violet-100 px-2 py-0.5 font-bold text-violet-800">
                              <Printer className="h-3 w-3" /> En producción {fecha(lote.en_produccion_at as string)}
                            </span>
                          ) : (
                            <span className="whitespace-nowrap rounded-full border border-dashed border-slate-300 px-2 py-0.5 font-semibold text-slate-500">En producción: pendiente</span>
                          )}
                        </div>
                      </div>
                      <div className="flex flex-wrap gap-2">
                        <button type="button" onClick={() => void redescargar(lote, 'zip')} disabled={trabajando !== null || zip.ocupado || lista.length === 0} className="flex items-center gap-1.5 rounded-xl border border-slate-300 px-3 py-2 text-xs font-bold hover:bg-slate-50 disabled:opacity-50">
                          {trabajando === `zip-${lote.id}` ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <FolderDown className="h-3.5 w-3.5" />} Bajar ZIP
                        </button>
                        <button type="button" onClick={() => void redescargar(lote, 'excel')} disabled={trabajando !== null || lista.length === 0} className="flex items-center gap-1.5 rounded-xl border border-slate-300 px-3 py-2 text-xs font-bold hover:bg-slate-50 disabled:opacity-50">
                          <FileSpreadsheet className="h-3.5 w-3.5" /> Bajar Excel
                        </button>
                        {!enProd && (
                          <button type="button" onClick={() => void enProduccion(lote)} disabled={trabajando !== null} className="flex items-center gap-1.5 rounded-xl bg-violet-600 px-3 py-2 text-xs font-bold text-white shadow-md shadow-violet-500/20 hover:bg-violet-500 disabled:opacity-50">
                            {trabajando === `prod-${lote.id}` ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Printer className="h-3.5 w-3.5" />} Marcar en producción
                          </button>
                        )}
                      </div>
                    </div>

                    {/* Auditoría 05/10: pedidos cancelados después de armar el lote (ya no están en la lista de abajo). */}
                    {(lote.anulados?.length ?? 0) > 0 && (
                      <div className="mx-4 mb-3 rounded-2xl border border-rose-200 bg-rose-50 px-4 py-3 text-sm text-rose-900 sm:mx-5">
                        <p className="font-bold">
                          <AlertTriangle className="mr-1 inline h-4 w-4" />
                          {lote.anulados!.length} pedido{lote.anulados!.length === 1 ? '' : 's'} de este lote {lote.anulados!.length === 1 ? 'fue anulado' : 'fueron anulados'} después de armarlo: no imprimirlo{lote.anulados!.length === 1 ? '' : 's'}.
                        </p>
                        <ul className="mt-1 list-disc pl-5">
                          {lote.anulados!.map((a) => (
                            <li key={`${a.friendlyId}-${a.alumno}`}>
                              <span className="font-mono font-bold">{a.friendlyId}</span>{a.alumno ? ` · ${a.alumno}` : ''}
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}

                    <div className="grid grid-cols-2 gap-px border-y border-slate-100 bg-slate-100 sm:grid-cols-4">
                      {(
                        [
                          ['Pedidos', lote.cantidad],
                          ['Carpetas', lote.carpetas ?? t.carpetas],
                          ['Fotos 20x30', lote.fotos_20x30 ?? t.c20],
                          ['Fotos 15x21', lote.fotos_15x21 ?? t.c15],
                        ] as const
                      ).map(([k, v]) => (
                        <div key={k} className="bg-slate-50 px-4 py-2.5">
                          <p className="text-[11px] font-bold uppercase tracking-wide text-slate-500">{k}</p>
                          <p className="font-['Outfit'] text-xl font-black text-slate-900">{v}</p>
                        </div>
                      ))}
                    </div>

                    <div className="overflow-x-auto">
                      <table className="w-full min-w-[640px] text-left text-sm">
                        <thead className="text-[11px] font-bold uppercase tracking-wide text-slate-500">
                          <tr>
                            <th className="px-4 py-2 sm:px-5">Alumno/a</th>
                            <th className="px-2 py-2">Colegio · Curso</th>
                            <th className="px-2 py-2">Pedido</th>
                            <th className="px-2 py-2 text-center">Carpetas</th>
                            <th className="px-2 py-2 text-center">20x30</th>
                            <th className="px-2 py-2 text-center">15x21</th>
                            <th className="px-4 py-2 sm:px-5" />
                          </tr>
                        </thead>
                        <tbody>
                          {lista.map((p) => {
                            const falta = p.archivosParaLaboratorio.some((a) => a.sinFotoReal);
                            const abiertoProblema = problemaDe === p.supabaseId;
                            return (
                              <Fragment key={p.supabaseId}>
                                <tr className="border-t border-slate-100 hover:bg-slate-50/60">
                                  <td className="px-4 py-2.5 font-bold sm:px-5">
                                    {p.alumnoNombre}
                                    {falta && <span className="ml-2 whitespace-nowrap rounded bg-red-100 px-1.5 py-0.5 text-[11px] font-bold text-red-700">Falta una foto</span>}
                                  </td>
                                  <td className="px-2 py-2.5 text-xs text-slate-600">
                                    {p.colegioNombre} · {p.grado} "{p.division}"
                                  </td>
                                  <td className="whitespace-nowrap px-2 py-2.5 font-mono text-xs text-slate-600">{p.id}</td>
                                  <td className="px-2 py-2.5 text-center font-bold">{p.carpetas}</td>
                                  <td className="px-2 py-2.5 text-center">{p.archivosParaLaboratorio.filter((a) => a.tamanoImpresion === '20x30').length}</td>
                                  <td className="px-2 py-2.5 text-center">{p.archivosParaLaboratorio.filter((a) => a.tamanoImpresion !== '20x30').length}</td>
                                  <td className="px-4 py-2.5 text-right sm:px-5">
                                    <button
                                      type="button"
                                      onClick={() => {
                                        setProblemaDe(abiertoProblema ? null : p.supabaseId || null);
                                        setMotivo('');
                                      }}
                                      className="inline-flex items-center gap-1 whitespace-nowrap rounded-lg px-2 py-1 text-xs font-bold text-red-600 hover:bg-red-50"
                                    >
                                      <AlertTriangle className="h-3.5 w-3.5" /> Hay un problema
                                    </button>
                                  </td>
                                </tr>
                                {abiertoProblema && (
                                  <tr className="bg-red-50/60">
                                    <td colSpan={7} className="px-4 py-3 sm:px-5">
                                      <p className="mb-2 text-xs text-red-800">Contanos qué pasa con este pedido. Le llega un aviso al fotógrafo.</p>
                                      <div className="flex flex-wrap gap-2">
                                        <input
                                          value={motivo}
                                          onChange={(e) => setMotivo(e.target.value)}
                                          placeholder="Ej: la foto individual sale borrosa / falta la grupal"
                                          className="min-w-[220px] flex-1 rounded-xl border border-red-200 bg-white px-3 py-2 text-sm"
                                          maxLength={600}
                                          autoFocus
                                        />
                                        <button
                                          type="button"
                                          onClick={() => void enviarProblema(p)}
                                          disabled={motivo.trim().length < 3 || trabajando !== null}
                                          className="rounded-xl bg-red-600 px-4 py-2 text-sm font-bold text-white hover:bg-red-500 disabled:opacity-50"
                                        >
                                          Avisar al fotógrafo
                                        </button>
                                      </div>
                                    </td>
                                  </tr>
                                )}
                              </Fragment>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>
                  </article>
                );
              })}
            </section>
            )}
          </div>

          {/* Columna derecha */}
          <aside className="min-w-0 space-y-5">
            <ResumenFacturacionLab variante="lateral" recargarCon={lotes} />

            <section className="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm">
              <p className="font-['Outfit'] text-base font-extrabold text-slate-900">Cómo se usa</p>
              <ol className="mt-3 space-y-3 text-sm">
                {(
                  [
                    ['bg-amber-400 text-slate-950', 'Descargar', 'Bajan los pedidos nuevos: se arma un lote con su ZIP y su Excel.'],
                    ['bg-violet-600 text-white', 'Marcar en producción', 'Cuando empiezan a imprimir el lote. Las familias reciben un aviso y el lote entra en el resumen del mes.'],
                    ['bg-red-600 text-white', 'Hay un problema', 'Si una foto sale mal o falta algo, avisen desde el pedido y le llega al fotógrafo.'],
                    ['bg-slate-900 text-white', 'Reimprimir', 'Si algo ya impreso salió mal, búsquenlo en la pestaña "Reimprimir" y bajen un ZIP sólo con esas fotos. Si fue una falla de impresión, va sin cargo.'],
                  ] as const
                ).map(([color, titulo, texto], i) => (
                  <li key={titulo} className="flex gap-3">
                    <span className={`flex h-7 w-7 shrink-0 items-center justify-center rounded-full text-xs font-black ${color}`}>{i + 1}</span>
                    <span>
                      <span className="block font-bold text-slate-900">{titulo}</span>
                      <span className="block text-xs text-slate-600">{texto}</span>
                    </span>
                  </li>
                ))}
              </ol>
              <p className="mt-4 rounded-2xl bg-slate-50 px-3 py-2 text-xs text-slate-600">
                El ensobrado lo hace el estudio: el ZIP trae sólo las fotos para imprimir, con el nombre del alumno en cada archivo.
              </p>
            </section>
          </aside>
        </div>
      </main>
    </div>
  );
}
