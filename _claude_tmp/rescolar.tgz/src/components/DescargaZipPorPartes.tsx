import { useCallback, useRef, useState } from 'react';
import { AlertTriangle, CheckCircle2, FolderDown, Loader2, X } from 'lucide-react';
import {
  type FallaZipLab,
  type OpcionesArmadoZipLab,
  type PlanZipLab,
  armarParteZipLaboratorio,
  descargarBlobComoArchivo,
} from '../services/zipLaboratorio';
import { guardarZipPartesLote, leerZipPartesLote } from '../services/laboratorioService';

/**
 * Auditoría 03/10 (crítico 3): descarga del ZIP del laboratorio por partes. Un lote chico (una
 * sola parte) se baja solo; uno grande muestra un botón por parte para no armar varios GB en la
 * memoria del navegador de una vez. Las fotos que no se pudieron bajar se listan siempre.
 */
interface EstadoZip {
  plan: PlanZipLab;
  nombreBase: string;
  armado: OpcionesArmadoZipLab;
  hechas: number[];
  fallas: FallaZipLab[];
  trabajandoEn: number | null;
  progreso: { hechas: number; total: number } | null;
  /** 14/10/2026: lote del laboratorio (si hay): las partes bajadas se guardan en el servidor y se recuperan al recargar. */
  loteId?: string;
}

export function useDescargaZipPorPartes(onError: (e: unknown) => void) {
  const [estado, setEstado] = useState<EstadoZip | null>(null);
  const estadoRef = useRef<EstadoZip | null>(null);
  const actualizar = (cambio: (e: EstadoZip) => EstadoZip) => {
    if (!estadoRef.current) return;
    estadoRef.current = cambio(estadoRef.current);
    setEstado(estadoRef.current);
  };

  const bajarParte = useCallback(
    async (indice: number): Promise<FallaZipLab[]> => {
      const actual = estadoRef.current;
      if (!actual || actual.trabajandoEn !== null) return [];
      actualizar((e) => ({ ...e, trabajandoEn: indice, progreso: { hechas: 0, total: e.plan.partes[indice]?.length || 0 } }));
      try {
        const r = await armarParteZipLaboratorio(actual.plan, indice, {
          ...actual.armado,
          onProgreso: (hechas, total) => actualizar((e) => ({ ...e, progreso: { hechas, total } })),
        });
        // Lo que no entró por tamaño (~500 MB) pasa a una parte nueva, justo después de esta.
        if (r.sobrantes.length > 0) {
          actual.plan.partes[indice] = actual.plan.partes[indice].filter((x) => !r.sobrantes.includes(x));
          actual.plan.partes.splice(indice + 1, 0, r.sobrantes);
        }
        const total = actual.plan.partes.length;
        const nombre = total > 1 ? `${actual.nombreBase}_PARTE_${indice + 1}_DE_${total}.zip` : `${actual.nombreBase}.zip`;
        descargarBlobComoArchivo(r.blob, nombre);
        actualizar((e) => ({
          ...e,
          hechas: [...new Set([...e.hechas.map((h) => (r.sobrantes.length > 0 && h > indice ? h + 1 : h)), indice])],
          fallas: [...e.fallas.filter((f) => !r.fallas.some((n) => n.archivo === f.archivo)), ...r.fallas],
        }));
        const e = estadoRef.current;
        if (e?.loteId && e.plan.partes.length > 1) void guardarZipPartesLote(e.loteId, { total: e.plan.partes.length, hechas: e.hechas, nombre: e.nombreBase });
        return r.fallas;
      } finally {
        actualizar((e) => ({ ...e, trabajandoEn: null, progreso: null }));
      }
    },
    []
  );

  /** Prepara la descarga. Si entra en una sola parte, la baja enseguida. */
  const iniciar = useCallback(
    async (plan: PlanZipLab, nombreBase: string, armado: OpcionesArmadoZipLab, loteId?: string): Promise<{ partes: number; fallas: FallaZipLab[] }> => {
      estadoRef.current = { plan, nombreBase, armado, hechas: [], fallas: [], trabajandoEn: null, progreso: null, loteId };
      setEstado(estadoRef.current);
      // 14/10/2026: si este lote ya se estaba bajando por partes (y se recargó la página), se marcan las ya bajadas.
      if (loteId && plan.partes.length > 1) {
        const guardado = await leerZipPartesLote(loteId);
        if (guardado && guardado.total === plan.partes.length && estadoRef.current?.loteId === loteId) {
          actualizar((e) => ({ ...e, hechas: guardado.hechas.filter((h) => h < e.plan.partes.length) }));
        }
      }
      if (plan.partes.length === 1) {
        const fallas = await bajarParte(0);
        return { partes: estadoRef.current?.plan.partes.length || 1, fallas };
      }
      return { partes: plan.partes.length, fallas: [] };
    },
    [bajarParte]
  );

  const cerrar = useCallback(() => {
    estadoRef.current = null;
    setEstado(null);
  }, []);

  // Los botones de cada parte avisan los errores con onError (sesión vencida, red caída…).
  return { estado, iniciar, bajarParte, cerrar, onError, ocupado: estado?.trabajandoEn != null };
}

export function PanelDescargaZip({ zip }: { zip: ReturnType<typeof useDescargaZipPorPartes> }) {
  const e = zip.estado;
  if (!e) return null;
  const total = e.plan.partes.length;
  const terminado = e.hechas.length >= total && e.trabajandoEn === null;
  if (total <= 1 && e.fallas.length === 0 && e.trabajandoEn === null) return null;
  return (
    <section className="space-y-3 rounded-2xl border border-slate-200 bg-white p-4 text-sm shadow-sm" aria-label="Descarga del ZIP">
      <div className="flex items-start justify-between gap-2">
        <div>
          <p className="font-extrabold text-slate-900">
            {e.nombreBase} · {e.plan.totalFotos} foto(s){total > 1 ? ` en ${total} partes` : ''}
          </p>
          {total > 1 && (
            <p className="text-xs text-slate-600">
              El lote es grande: se baja por partes para no colgar el navegador. Bajá cada parte y descomprimilas todas en la misma carpeta.
            </p>
          )}
        </div>
        {e.trabajandoEn === null && (
          <button type="button" onClick={zip.cerrar} className="rounded-lg p-1 text-slate-500 hover:bg-slate-100" aria-label="Cerrar">
            <X className="h-4 w-4" />
          </button>
        )}
      </div>
      {total > 1 && (
        <div className="flex flex-wrap gap-2">
          {e.plan.partes.map((parte, i) => {
            const hecha = e.hechas.includes(i);
            const enCurso = e.trabajandoEn === i;
            return (
              <button
                key={i}
                type="button"
                disabled={e.trabajandoEn !== null}
                onClick={() => void zip.bajarParte(i).catch(zip.onError)}
                className={`flex items-center gap-1.5 rounded-xl border px-3 py-2 text-xs font-bold disabled:opacity-60 ${
                  hecha ? 'border-emerald-300 bg-emerald-50 text-emerald-800' : 'border-slate-300 hover:bg-slate-50'
                }`}
              >
                {enCurso ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : hecha ? <CheckCircle2 className="h-3.5 w-3.5" /> : <FolderDown className="h-3.5 w-3.5" />}
                Parte {i + 1} de {total} ({parte.length} fotos)
              </button>
            );
          })}
        </div>
      )}
      {e.progreso && (
        <p className="text-xs font-semibold text-slate-600" role="status">
          Bajando fotos de la parte {(e.trabajandoEn ?? 0) + 1}: {e.progreso.hechas} de {e.progreso.total}…
        </p>
      )}
      {terminado && total > 1 && <p className="text-xs font-bold text-emerald-700">Listo: se bajaron las {total} partes.</p>}
      {e.fallas.length > 0 && (
        <div className="rounded-xl border border-red-200 bg-red-50 p-3 text-xs text-red-800" role="alert">
          <p className="flex items-center gap-1.5 font-extrabold">
            <AlertTriangle className="h-4 w-4" /> Faltan {e.fallas.length} foto(s): van como tarjeta roja FALTA_… (no imprimir) y en FALTAN_FOTOS.txt
          </p>
          <ul className="mt-1.5 max-h-40 list-disc space-y-0.5 overflow-y-auto pl-5">
            {e.fallas.map((f) => (
              <li key={f.archivo}>
                <strong>{f.alumno}</strong> · {f.archivo.split('/').pop()} · pedido {f.pedido} — {f.motivo}
              </li>
            ))}
          </ul>
        </div>
      )}
    </section>
  );
}
