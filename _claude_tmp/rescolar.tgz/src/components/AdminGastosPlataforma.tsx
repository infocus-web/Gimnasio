import { useEffect, useState } from 'react';
import { Loader2, Plus, Server, Trash2 } from 'lucide-react';
import { agregarGastoPlataforma, borrarGastoPlataforma, obtenerGastosPlataforma, type GastoPlataforma } from '../services/colegiosService';

/**
 * Gastos de operación de la plataforma (convenio 2026-10-30, OCTAVA BIS punto iv): alojamiento, base de datos y
 * fotos, correos, servicios automatizados (IA) y dominio, en PESOS, tal como se pagaron. La liquidación de cada
 * colegio que firmó esa versión descuenta la parte proporcional a lo cobrado, con tope del 5 % de lo cobrado.
 * Cargar sólo gastos de ESTA plataforma: el colegio puede pedir los comprobantes (cláusula «Respaldo»).
 */
const pesos = (n: number) => `$${(Number(n) || 0).toLocaleString('es-AR', { minimumFractionDigits: 0, maximumFractionDigits: 2 })}`;
const hoy = () => new Date().toLocaleDateString('en-CA', { timeZone: 'America/Argentina/Buenos_Aires' });
const VACIO = { fecha: hoy(), concepto: '', monto: '', monedaOriginal: 'USD', montoOriginal: '', comprobante: '' };

export default function AdminGastosPlataforma({ desde, hasta, onCambio }: { desde: string; hasta: string; onCambio?: () => void }) {
  const [gastos, setGastos] = useState<GastoPlataforma[]>([]);
  const [cargando, setCargando] = useState(false);
  const [form, setForm] = useState(VACIO);
  const [guardando, setGuardando] = useState(false);
  const [mensaje, setMensaje] = useState<string | null>(null);

  const cargar = async () => {
    setCargando(true);
    const r = await obtenerGastosPlataforma(desde, hasta);
    setCargando(false);
    if (r.success) setGastos(r.gastos || []);
    else setMensaje(r.error || 'No se pudieron leer los gastos.');
  };
  useEffect(() => {
    cargar();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [desde, hasta]);

  const agregar = async (e: React.FormEvent) => {
    e.preventDefault();
    setGuardando(true);
    setMensaje(null);
    const r = await agregarGastoPlataforma(form);
    setGuardando(false);
    if (!r.success) return setMensaje(r.error || 'No se pudo guardar.');
    setForm({ ...VACIO, fecha: form.fecha });
    await cargar();
    onCambio?.();
  };

  const borrar = async (g: GastoPlataforma) => {
    if (!window.confirm(`¿Borrar "${g.concepto}" del ${g.fecha} (${pesos(g.monto)})?`)) return;
    const r = await borrarGastoPlataforma(g.id);
    if (!r.success) return setMensaje(r.error || 'No se pudo borrar.');
    await cargar();
    onCambio?.();
  };

  const total = gastos.reduce((a, g) => a + (Number(g.monto) || 0), 0);
  const input = 'w-full rounded-lg border border-slate-200 bg-white px-2 py-1.5 text-xs';

  return (
    <div className="rounded-xl border border-slate-200 bg-slate-50 p-3 space-y-2">
      <div className="flex flex-wrap items-baseline justify-between gap-2">
        <p className="text-[11px] font-bold text-slate-700 flex items-center gap-1.5">
          <Server className="w-3.5 h-3.5 text-slate-500" /> Gastos de la plataforma ({desde} al {hasta})
        </p>
        <p className="text-[11px] font-bold text-slate-800">Total: {pesos(total)}</p>
      </div>
      <p className="text-[10px] text-slate-500">
        Punto (iv) de la ganancia neta del convenio 2026-10-30: hosting, base de datos y fotos, correos, IA y dominio, en
        pesos como se pagaron. Cargá sólo gastos de esta plataforma y guardá los comprobantes: el colegio puede pedirlos. A cada
        colegio que firmó esa versión se le descuenta la parte proporcional a lo cobrado, con tope del 5 % de lo cobrado.
      </p>

      <form onSubmit={agregar} className="grid grid-cols-2 sm:grid-cols-6 gap-2 items-end">
        <label className="text-[11px] text-slate-600">Fecha de pago
          <input type="date" required className={input} value={form.fecha} onChange={(e) => setForm({ ...form, fecha: e.target.value })} />
        </label>
        <label className="text-[11px] text-slate-600 col-span-2 sm:col-span-1">Concepto
          <input required maxLength={120} placeholder="Vercel Pro, IA, dominio…" className={input} value={form.concepto} onChange={(e) => setForm({ ...form, concepto: e.target.value })} />
        </label>
        <label className="text-[11px] text-slate-600">Pagado en pesos
          <input required inputMode="decimal" placeholder="$" className={input} value={form.monto} onChange={(e) => setForm({ ...form, monto: e.target.value })} />
        </label>
        <label className="text-[11px] text-slate-600">Monto original
          <span className="flex gap-1">
            <select className="rounded-lg border border-slate-200 bg-white px-1 text-xs" value={form.monedaOriginal} onChange={(e) => setForm({ ...form, monedaOriginal: e.target.value })}>
              <option value="USD">USD</option>
              <option value="ARS">ARS</option>
            </select>
            <input inputMode="decimal" placeholder="opcional" className={input} value={form.montoOriginal} onChange={(e) => setForm({ ...form, montoOriginal: e.target.value })} />
          </span>
        </label>
        <label className="text-[11px] text-slate-600">Comprobante
          <input maxLength={120} placeholder="N.º factura" className={input} value={form.comprobante} onChange={(e) => setForm({ ...form, comprobante: e.target.value })} />
        </label>
        <button type="submit" disabled={guardando} className="inline-flex items-center justify-center gap-1 rounded-lg bg-slate-800 px-3 py-2 text-xs font-bold text-white disabled:opacity-60">
          {guardando ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Plus className="w-3.5 h-3.5" />} Agregar
        </button>
      </form>
      {mensaje && <p className="text-[11px] text-red-600">{mensaje}</p>}

      {cargando ? (
        <div className="py-2 text-center text-slate-400"><Loader2 className="w-4 h-4 mx-auto animate-spin" /></div>
      ) : gastos.length ? (
        <div className="overflow-x-auto">
          <table className="w-full text-[11px]">
            <thead>
              <tr className="text-left text-slate-500">
                <th className="py-1 pr-2">Fecha</th><th className="py-1 pr-2">Concepto</th><th className="py-1 pr-2">Pesos</th><th className="py-1 pr-2">Original</th><th className="py-1 pr-2">Comprobante</th><th />
              </tr>
            </thead>
            <tbody>
              {gastos.map((g) => (
                <tr key={g.id} className="border-t border-slate-200">
                  <td className="py-1 pr-2 whitespace-nowrap">{new Date(`${g.fecha}T12:00:00`).toLocaleDateString('es-AR')}</td>
                  <td className="py-1 pr-2">{g.concepto}</td>
                  <td className="py-1 pr-2 font-semibold">{pesos(g.monto)}</td>
                  <td className="py-1 pr-2 text-slate-500">{g.monto_original ? `${g.moneda_original ?? ''} ${Number(g.monto_original).toLocaleString('es-AR')}` : ''}</td>
                  <td className="py-1 pr-2 text-slate-500">{g.comprobante ?? ''}</td>
                  <td className="py-1 text-right">
                    <button type="button" onClick={() => borrar(g)} className="p-1 text-slate-400 hover:text-red-600" aria-label={`Borrar ${g.concepto}`}>
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        <p className="text-[11px] text-slate-500">Todavía no cargaste gastos en este período.</p>
      )}
    </div>
  );
}
