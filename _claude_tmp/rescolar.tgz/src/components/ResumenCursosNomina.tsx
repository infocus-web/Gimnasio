import { useMemo, useState } from 'react';
import type { AlumnoNominaReal } from '../services/colegiosService';

// Nómina: «Avance por curso» (20/10/2026, Pablo: «no me queda claro qué curso ya fue fotografiado y cuál no,
// tengo que revisar uno por uno»). Todos los cursos de un vistazo, con cuántos faltan; tocar uno lo filtra.
// 21/10/2026 (Pablo: «estos botones son confusos, prefiero un listado, verde, amarillo y rojo»): pasó de
// tarjetas a una lista con una fila por curso. Verde = todos los alumnos tienen las 3 fotos (individual, con la
// seño y grupal); amarillo = falta alguna foto a algún alumno; rojo = no se sacó ninguna foto en el curso.
// 21/10/2026 (Pablo: «quitá el listado de cursos, poné el avance en botones más grandes»): tres botones grandes
// (completos / con faltantes / sin fotos); al tocar uno se ven sólo los cursos de ese color, y tocar un curso lo elige.
// Fuera de AdminModal.tsx a propósito (ese archivo tiene techo de líneas).

type Seccion = { id: string; nombreCompleto: string; esSecundaria: boolean };
export type EstadoCurso = 'completo' | 'faltan' | 'sin-empezar';
export type AvanceCurso = Seccion & {
  total: number;
  conIndividual: number;
  conSeno: number;
  conGrupal: number;
  /** Alumnos con las 3 fotos. */
  completos: number;
  estado: EstadoCurso;
};

/** Cuenta por curso cuántos alumnos tienen cada foto, en el orden de `secciones`, y el color del curso. */
export function avancePorCurso(alumnos: AlumnoNominaReal[], secciones: Seccion[], idDe: (a: AlumnoNominaReal) => string): AvanceCurso[] {
  const vacio = () => ({ total: 0, conIndividual: 0, conSeno: 0, conGrupal: 0, completos: 0, conAlguna: 0 });
  const cuentas = new Map<string, ReturnType<typeof vacio>>();
  for (const a of alumnos) {
    const c = cuentas.get(idDe(a)) || vacio();
    const ind = !!a.fotografiado_at;
    const seno = !!a.foto_seno_at;
    const grupal = !!a.foto_grupal_at;
    c.total += 1;
    if (ind) c.conIndividual += 1;
    if (seno) c.conSeno += 1;
    if (grupal) c.conGrupal += 1;
    if (ind && seno && grupal) c.completos += 1;
    if (ind || seno || grupal) c.conAlguna += 1;
    cuentas.set(idDe(a), c);
  }
  return secciones.map((s) => {
    const { conAlguna, ...c } = cuentas.get(s.id) || vacio();
    const estado: EstadoCurso = c.total > 0 && c.completos === c.total ? 'completo' : conAlguna > 0 ? 'faltan' : 'sin-empezar';
    return { ...s, ...c, estado };
  });
}

const ESTADOS: { estado: EstadoCurso; texto: string; boton: string; activo: string; punto: string; curso: string }[] = [
  { estado: 'completo', texto: 'completos', boton: 'border-emerald-300 bg-emerald-50 text-emerald-800 hover:bg-emerald-100', activo: 'ring-2 ring-emerald-500 bg-emerald-100', punto: 'bg-emerald-500', curso: 'bg-emerald-100 hover:bg-emerald-200 text-emerald-900 border-emerald-300' },
  { estado: 'faltan', texto: 'con faltantes', boton: 'border-amber-300 bg-amber-50 text-amber-800 hover:bg-amber-100', activo: 'ring-2 ring-amber-500 bg-amber-100', punto: 'bg-amber-400', curso: 'bg-amber-100 hover:bg-amber-200 text-amber-900 border-amber-300' },
  { estado: 'sin-empezar', texto: 'sin fotos', boton: 'border-rose-300 bg-rose-50 text-rose-800 hover:bg-rose-100', activo: 'ring-2 ring-rose-500 bg-rose-100', punto: 'bg-rose-500', curso: 'bg-rose-100 hover:bg-rose-200 text-rose-900 border-rose-300' },
];

export default function ResumenCursosNomina({
  alumnos,
  secciones,
  idDe,
  seleccionada,
  onElegir,
}: {
  alumnos: AlumnoNominaReal[];
  secciones: Seccion[];
  idDe: (a: AlumnoNominaReal) => string;
  seleccionada: string;
  onElegir: (id: string) => void;
}) {
  const [abierto, setAbierto] = useState<EstadoCurso | null>(null);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  const cursos = useMemo(() => avancePorCurso(alumnos, secciones, idDe), [alumnos, secciones]);
  if (cursos.length === 0) return null;
  const elegido = ESTADOS.find((e) => e.estado === abierto);
  const deEsteEstado = abierto ? cursos.filter((c) => c.estado === abierto) : [];
  const grupos = [
    { titulo: 'Primaria / Inicial', lista: deEsteEstado.filter((c) => !c.esSecundaria) },
    { titulo: 'Secundaria', lista: deEsteEstado.filter((c) => c.esSecundaria) },
  ].filter((g) => g.lista.length > 0);

  return (
    <div className="space-y-2">
      <div className="flex flex-wrap items-center gap-2">
        <span className="text-sm font-bold text-slate-700 mr-1">Avance por curso:</span>
        {ESTADOS.map((e) => {
          const n = cursos.filter((c) => c.estado === e.estado).length;
          const activo = abierto === e.estado;
          return (
            <button
              key={e.estado}
              type="button"
              onClick={() => setAbierto(activo ? null : e.estado)}
              aria-expanded={activo}
              title={activo ? 'Tocá de nuevo para cerrar' : `Ver los cursos ${e.texto}`}
              className={`inline-flex items-center gap-2 px-4 py-2.5 rounded-xl border text-sm font-bold cursor-pointer transition-colors ${e.boton} ${activo ? e.activo : ''}`}
            >
              <span className={`w-3 h-3 rounded-full shrink-0 ${e.punto}`} aria-hidden="true" />
              <span className="text-lg leading-none tabular-nums">{n}</span>
              {e.texto}
            </button>
          );
        })}
      </div>
      {elegido && (
        <div className="rounded-xl border border-slate-200 bg-slate-50 p-3 space-y-2 max-h-[40vh] overflow-y-auto">
          {grupos.length === 0 && <p className="text-xs text-slate-500 font-semibold">No hay cursos {elegido.texto}.</p>}
          {grupos.map((g) => (
            <div key={g.titulo} className="space-y-1">
              <p className="text-[10px] uppercase font-bold text-slate-400">{g.titulo}</p>
              <div className="flex flex-wrap gap-1.5">
                {g.lista.map((c) => {
                  const faltan = c.total - c.completos;
                  return (
                    <button
                      key={c.id}
                      type="button"
                      onClick={() => {
                        onElegir(c.id);
                        setAbierto(null);
                      }}
                      aria-current={c.id === seleccionada ? 'true' : undefined}
                      title={`${c.nombreCompleto} · Individual ${c.conIndividual}/${c.total} · Seño ${c.conSeno}/${c.total} · Grupal ${c.conGrupal}/${c.total}`}
                      className={`px-2.5 py-1.5 rounded-lg border text-xs font-semibold cursor-pointer transition-colors ${elegido.curso} ${c.id === seleccionada ? 'outline-2 outline-slate-700' : ''}`}
                    >
                      {c.nombreCompleto}
                      {c.estado === 'faltan' && <span className="font-normal"> · faltan {faltan}</span>}
                    </button>
                  );
                })}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
