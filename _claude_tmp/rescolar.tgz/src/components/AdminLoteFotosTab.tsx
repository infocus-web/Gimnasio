import React, { useState, useMemo, useEffect, useRef } from 'react';
import {
  Camera, Upload, CheckCircle2,
  Trash2, RefreshCw, ShieldCheck, Check,
  AlertCircle, AlertTriangle, Database, Copy, HardDrive,
  Image as ImageIcon, Sparkles, User,
  X, CheckSquare, Square, Wand2, Send, EyeOff
} from 'lucide-react';
import {
  useColegiosLista,
  obtenerAlumnosNominaAdmin,
  AlumnoNominaReal,
  COLEGIO_POR_DEFECTO
} from '../services/colegiosService';
import { determinarCodigoParaInscripcion } from '../services/inscripcionesService';
import { 
  uploadFotoWeb, uploadFotoHD, testSupabaseConnection, SupabaseDiagnosticResult
} from '../services/supabaseClient';
import ReenviarAvisoFotos from './ReenviarAvisoFotos';
import PublicarTodosCursos from './PublicarTodosCursos';
import PrepararLupa from './PrepararLupa';
import {
  registrarFotosAdmin,
  listarFotosActivasAdmin,
  limpiarArchivosHuerfanosAdmin,
  eliminarFotoActivaAdmin,
  eliminarFotosEnLoteAdmin,
  regenerarMiniaturasAdmin,
  regenerarMarcaAguaAdmin,
  publicarFotosAdmin,
  FotoRegistrada,
  type DatosFotoParaRegistrar
} from '../services/fotosSubidasService';
import { copiarAlPortapapeles } from '../utils/portapapeles';
import { separarYaSubidas, useAvisoAlCerrar } from '../utils/subidaFotos';
import { crearFila, recorrerConLimite } from '../utils/concurrencia';

// Cada foto de la cola guarda SÓLO el File: la muestra y la miniatura se generan al subir, de a una (03/10, memoria).
interface FotoLoteItem {
  id: string;
  file?: File;
  /** URL (blob:) de la miniatura, sólo para mirarla en la cola; se libera al sacar la foto. */
  thumbUrl?: string;
  tipo: 'individual' | 'grupal' | 'docente' | 'familia' | 'patio';
  nombreOriginal: string;
  // procesada = lista para subir · subida = en Storage pero falta registrarla · registrada = lista
  estado: 'procesada' | 'subiendo' | 'subida' | 'registrada' | 'error';
  errorMensaje?: string;
  alumnoNombre?: string;
  /** Datos para registrarla en el catálogo sin volver a subirla (reintento). */
  registro?: DatosFotoParaRegistrar;
}

// Cuántas tarjetas de la cola se dibujan (con miles de fotos, dibujarlas todas traba el panel).
const MAX_TARJETAS_COLA = 60;
// Miniaturas que se generan al elegir las fotos, para poder revisarlas antes de subir.
const MINIATURAS_DE_REVISION = 12;
// 24/10 (velocidad): fotos que se suben a la vez (más de 3-4 no rinde y cada una ocupa memoria al armar la muestra).
const SUBIDAS_SIMULTANEAS = 3;

function liberarUrl(url?: string) {
  if (url && url.startsWith('blob:')) {
    try {
      URL.revokeObjectURL(url);
    } catch {
      /* nada */
    }
  }
}

function canvasABlob(canvas: HTMLCanvasElement, calidad: number): Promise<Blob> {
  return new Promise((resolve, reject) => {
    canvas.toBlob((b) => {
      // Se libera la memoria del canvas apenas se tiene el JPEG.
      canvas.width = 0;
      canvas.height = 0;
      if (b && b.size > 0) resolve(b);
      else reject(new Error('El navegador no pudo generar la imagen.'));
    }, 'image/jpeg', calidad);
  });
}

function cargarImagen(file: File): Promise<HTMLImageElement> {
  const url = URL.createObjectURL(file);
  return new Promise<HTMLImageElement>((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error('Formato no soportado por el navegador (usá JPG o PNG). Esta foto no se va a subir.'));
    img.src = url;
  }).finally(() => URL.revokeObjectURL(url));
}

export default function AdminLoteFotosTab() {
  const { colegios } = useColegiosLista();
  const [colegioSeleccionado, setColegioSeleccionado] = useState<string>(() => colegios[0]?.id || 'col-isba-2026');
  // El curso se arma con los grados/turnos/divisiones REALES de cada colegio (antes: lista fija de nivel inicial).
  const [gradoSeleccionado, setGradoSeleccionado] = useState<string>('');
  const [turnoSeleccionado, setTurnoSeleccionado] = useState<string>('');
  const [divisionSeleccionada, setDivisionSeleccionada] = useState<string>('');
  const [alumnosColegioActual, setAlumnosColegioActual] = useState<AlumnoNominaReal[]>([]);
  const [tipoFotoLote, setTipoFotoLote] = useState<'individual' | 'grupal' | 'docente' | 'familia' | 'patio'>('individual');
  const [alumnoSeleccionadoId, setAlumnoSeleccionadoId] = useState<string>('');

  const [fotosLote, setFotosLote] = useState<FotoLoteItem[]>([]);
  // Para liberar las miniaturas (blob:) si se cierra el panel con fotos en la cola.
  const fotosLoteRef = useRef<FotoLoteItem[]>([]);
  fotosLoteRef.current = fotosLote;
  useEffect(() => () => fotosLoteRef.current.forEach((f) => liberarUrl(f.thumbUrl)), []);
  const [fotosActivasCurso, setFotosActivasCurso] = useState<FotoRegistrada[]>([]);

  const [isProcessing, setIsProcessing] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  useAvisoAlCerrar(isUploading || fotosLote.length > 0); // 14/10: avisa antes de cerrar o recargar con fotos sin subir
  const [uploadProgress, setUploadProgress] = useState<{ actual: number; total: number }>({ actual: 0, total: 0 });
  const [statusMessage, setStatusMessage] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const cancelarSubidaRef = useRef(false);
  // 03/10: marca de comienzo de una subida que terminó SIN el aviso «ya están tus fotos» (cancelada o con la última
  // tanda fallida): si se retoma el mismo curso se reusa, así sigue siendo «galería nueva» y el aviso sale al final.
  const marcaSubidaPendienteRef = useRef<{ curso: string; marca: string } | null>(null);
  const [cancelandoSubida, setCancelandoSubida] = useState(false);

  // Selección múltiple para borrar varias fotos activas de una sola vez
  const [modoSeleccionActivas, setModoSeleccionActivas] = useState(false);
  const [idsSeleccionados, setIdsSeleccionados] = useState<Set<string>>(new Set());
  const [borrandoSeleccionadas, setBorrandoSeleccionadas] = useState(false);

  // 22/09 (Pablo: «un listado de los cursos que tienen fotos subidas»): TODAS las fotos del colegio elegido,
  // agrupadas más abajo en `resumenCursosConFotos`.
  const [fotosColegioCompleto, setFotosColegioCompleto] = useState<FotoRegistrada[]>([]);
  const [cargandoResumenCursos, setCargandoResumenCursos] = useState(false);
  // Auditoría 03/10 noche (R10): de qué colegio es `fotosColegioCompleto` y si la lista NO se pudo
  // leer (antes un error se mostraba como "no hay fotos" y Pablo las volvía a subir).
  const [resumenCursosColegioId, setResumenCursosColegioId] = useState('');
  const [errorResumenCursos, setErrorResumenCursos] = useState<string | null>(null);
  const [errorFotosCurso, setErrorFotosCurso] = useState<string | null>(null);
  const consultaFotosCursoRef = useRef(0);
  const consultaResumenCursosRef = useRef(0);
  const [cursoEliminandoCarpeta, setCursoEliminandoCarpeta] = useState<string | null>(null);
  // 06/10 (botón «Publicar»): qué se está publicando ('curso:<clave>', 'actual' o 'seleccion').
  const [publicando, setPublicando] = useState<string | null>(null);
  // Filtro por categoría en "Fotos Activas": permite ver/seleccionar/borrar sólo una
  // categoría puntual (por ejemplo, sólo "Grupal") sin tocar el resto del curso.
  const [filtroCategoriaActivas, setFiltroCategoriaActivas] = useState<'todas' | 'sin_publicar' | 'individual' | 'grupal' | 'docente' | 'familia' | 'patio'>('todas');

  // Migración de miniaturas limpias para fotos subidas antes de este cambio
  const [regenerandoMiniaturas, setRegenerandoMiniaturas] = useState(false);
  const [progresoMiniaturas, setProgresoMiniaturas] = useState<{ procesadas: number; fallidas: number; restantes: number } | null>(null);

  // Migración de la marca de agua más liviana para fotos ya subidas (vista ampliada)
  const [regenerandoMarcaAgua, setRegenerandoMarcaAgua] = useState(false);
  const [progresoMarcaAgua, setProgresoMarcaAgua] = useState<{ procesadas: number; fallidas: number; restantes: number } | null>(null);

  // Supabase Diagnostics & Settings
  const [diagnostico, setDiagnostico] = useState<SupabaseDiagnosticResult | null>(null);
  const [isTestingSupabase, setIsTestingSupabase] = useState(false);
  const [mostrarSqlHelper, setMostrarSqlHelper] = useState(false);
  const [sqlCopiado, setSqlCopiado] = useState(false);

  // Form config

  // Colegio actualmente seleccionado, para leer sus grados/turnos/divisiones configurados
  const colegioActualObj = useMemo(
    () => colegios.find(c => c.id === colegioSeleccionado),
    [colegios, colegioSeleccionado]
  );

    // BUG CORREGIDO (2026-09-09): "colegioSeleccionado" se inicializaba con colegios[0]?.id en el
    // primer render, pero useColegiosLista() arranca con [COLEGIO_POR_DEFECTO] (un colegio de
    // relleno con id de mentira, ej. "col-divino-pastor-2026") mientras todavía no llegó la lista
    // real desde Supabase — y como useState solo lee ese valor inicial UNA vez, "colegioSeleccionado"
    // se quedaba pegado en ese id de mentira para siempre, aunque un instante después llegara la
    // lista real con el id verdadero del colegio. El desplegable de arriba mostraba igual el nombre
    // correcto (porque coincide por casualidad), asi que no se notaba a simple vista — pero todas
    // las fotos que se subian quedaban guardadas con ese colegio_id de mentira en la base, y por eso
    // el portal de familias nunca las encontraba (buscaba por el id real) y mostraba las fotos
    // genericas de muestra en su lugar. Este efecto corrige la seleccion apenas llega la lista real.
    useEffect(() => {
          if (colegios.length > 0 && !colegios.some(c => c.id === colegioSeleccionado)) {
                  setColegioSeleccionado(colegios[0].id);
          }
    }, [colegios, colegioSeleccionado]);

  // Si el colegio todavía no configuró sus propios grados/turnos/divisiones, se usa una lista
  // genérica (la misma que ofrece el alta de colegios) para que esta pestaña nunca quede vacía.
  const gradosDisponibles = colegioActualObj?.grados?.length ? colegioActualObj.grados : COLEGIO_POR_DEFECTO.grados;
  const turnosDisponibles = colegioActualObj?.turnos?.length ? colegioActualObj.turnos : COLEGIO_POR_DEFECTO.turnos;
  const divisionesDisponibles = colegioActualObj?.divisiones?.length ? colegioActualObj.divisiones : COLEGIO_POR_DEFECTO.divisiones;

  // Al cambiar de colegio (o al entrar), si el grado/turno/división elegidos no existen en la
  // nueva lista, se cae al primero disponible — así nunca queda un curso "fantasma" seleccionado.
  useEffect(() => {
    if (!gradosDisponibles.includes(gradoSeleccionado)) setGradoSeleccionado(gradosDisponibles[0] || '');
    if (!turnosDisponibles.includes(turnoSeleccionado)) setTurnoSeleccionado(turnosDisponibles[0] || '');
    if (!divisionesDisponibles.includes(divisionSeleccionada)) setDivisionSeleccionada(divisionesDisponibles[0] || '');
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [colegioSeleccionado, gradosDisponibles.join('|'), turnosDisponibles.join('|'), divisionesDisponibles.join('|')]);

  // Antes esto era un `id` fijo de una de las 11 secciones hardcodeadas de nivel inicial. Ahora
  // se calcula con la misma fórmula que usa el resto de la app (inscripciones, servidor) para
  // cualquier grado/turno/división real — ver determinarCodigoParaInscripcion. Se usa como
  // nombre de carpeta en Storage; el código real que ven las familias lo calcula el servidor.
  const cursoSeleccionado = useMemo(() => {
    if (!gradoSeleccionado || !turnoSeleccionado) return '';
    return determinarCodigoParaInscripcion({ grado: gradoSeleccionado, turno: turnoSeleccionado, division: divisionSeleccionada });
  }, [gradoSeleccionado, turnoSeleccionado, divisionSeleccionada]);

  const nombreSeccionActual =
    [gradoSeleccionado, divisionSeleccionada, turnoSeleccionado].filter(Boolean).join(' · ') || 'el curso seleccionado';

  // Nómina REAL (tabla `alumnos` de Supabase) del colegio elegido — antes era la lista fija
  // ALUMNOS_NOMINA_2026 de una sola sala de nivel inicial. Se trae una vez por colegio y se
  // filtra localmente por grado/turno/división para armar el selector de "Asignar a Alumno".
  useEffect(() => {
    let cancelado = false;
    if (!colegioSeleccionado) {
      setAlumnosColegioActual([]);
      return;
    }
    obtenerAlumnosNominaAdmin(colegioSeleccionado).then(lista => {
      if (!cancelado) setAlumnosColegioActual(lista);
    });
    return () => {
      cancelado = true;
    };
  }, [colegioSeleccionado]);

  // Alumnos del curso actual para asignación opcional
  const alumnosDelCurso = useMemo(() => {
    if (!gradoSeleccionado || !turnoSeleccionado) return [];
    return alumnosColegioActual.filter(
      a => a.grado === gradoSeleccionado && a.turno === turnoSeleccionado && a.division === divisionSeleccionada
    );
  }, [alumnosColegioActual, gradoSeleccionado, turnoSeleccionado, divisionSeleccionada]);

  // Auditoría 03/10 noche (R10): selección vigente (colegio + curso). Las recargas se llaman también
  // después de un await (al terminar una subida o un borrado), desde un render viejo: leen la
  // selección de acá y descartan la respuesta si mientras tanto se cambió de colegio o de curso.
  const seleccionActualRef = useRef({ colegio: colegioSeleccionado, grado: gradoSeleccionado, turno: turnoSeleccionado, division: divisionSeleccionada });
  seleccionActualRef.current = { colegio: colegioSeleccionado, grado: gradoSeleccionado, turno: turnoSeleccionado, division: divisionSeleccionada };
  const colaPendiente = fotosLote.some(f => f.estado !== 'registrada'); // FOT-1 (11/10): la cola se sube al curso elegido
  const avisoCola = colaPendiente ? 'Subí o vaciá la cola antes de cambiar de colegio o curso: las fotos se registran en el curso elegido.' : undefined;
  const claveSeleccion = (s: { colegio: string; grado: string; turno: string; division: string }) => `${s.colegio}__${s.grado}__${s.turno}__${s.division}`;

  // Cargar fotos activas del curso (desde Supabase, vía el panel admin)
  const recargarFotosActivas = async () => {
    const pedida = { ...seleccionActualRef.current };
    const n = ++consultaFotosCursoRef.current;
    if (!pedida.grado || !pedida.turno) {
      setFotosActivasCurso([]);
      setErrorFotosCurso(null);
      return;
    }
    const r = await listarFotosActivasAdmin({
      colegioId: pedida.colegio,
      grado: pedida.grado,
      turno: pedida.turno,
      division: pedida.division,
    });
    // Respuesta vieja (se pidió otra después, o cambió el colegio/curso): se descarta.
    if (n !== consultaFotosCursoRef.current || claveSeleccion(pedida) !== claveSeleccion(seleccionActualRef.current)) return;
    if (r.success) {
      setFotosActivasCurso(r.fotos);
      setErrorFotosCurso(null);
    } else {
      setFotosActivasCurso([]);
      setErrorFotosCurso(r.error || 'No se pudo leer la lista de fotos.');
    }
  };

  useEffect(() => {
    setFotosActivasCurso([]); setErrorFotosCurso(null); // FOT-4 (11/10): «Publicar» no puede ver la lista del curso anterior
    recargarFotosActivas();
    // Al cambiar de curso, no arrastrar selección ni filtro del curso anterior.
    setFiltroCategoriaActivas('todas');
    setModoSeleccionActivas(false);
    setIdsSeleccionados(new Set());
    setAlumnoSeleccionadoId('');
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [gradoSeleccionado, turnoSeleccionado, divisionSeleccionada, colegioSeleccionado]);

  // Trae TODAS las fotos del colegio elegido (sin filtrar por curso) para armar el listado de
  // "qué cursos ya tienen fotos subidas". Se llama al entrar, al cambiar de colegio, y de nuevo
  // después de subir o borrar fotos (arriba, o desde el listado mismo) para que quede al día.
  const recargarResumenCursos = async () => {
    const colegio = seleccionActualRef.current.colegio;
    const n = ++consultaResumenCursosRef.current;
    if (!colegio) {
      setFotosColegioCompleto([]);
      setResumenCursosColegioId('');
      setErrorResumenCursos(null);
      return;
    }
    // Otro colegio: no se muestra (ni se puede borrar) la lista del anterior mientras carga.
    if (colegio !== resumenCursosColegioId) {
      setFotosColegioCompleto([]);
      setResumenCursosColegioId('');
    }
    setCargandoResumenCursos(true);
    const r = await listarFotosActivasAdmin({ colegioId: colegio });
    // Auditoría 03/10 noche (R10): respuesta vieja (de otro colegio o de una consulta anterior): se descarta.
    if (n !== consultaResumenCursosRef.current || colegio !== seleccionActualRef.current.colegio) return;
    if (r.success) {
      // Por las dudas, sólo las fotos de ESTE colegio.
      setFotosColegioCompleto(r.fotos.filter((f) => !f.colegioId || f.colegioId === colegio));
      setErrorResumenCursos(null);
    } else {
      setFotosColegioCompleto([]);
      setErrorResumenCursos(r.error || 'No se pudo leer la lista de fotos.');
    }
    setResumenCursosColegioId(colegio);
    setCargandoResumenCursos(false);
  };

  useEffect(() => {
    recargarResumenCursos();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [colegioSeleccionado]);

  // Agrupa `fotosColegioCompleto` por curso (grado+turno+división) para el listado — cada fila
  // es un curso con al menos una foto, con el conteo total y por categoría.
  const resumenCursosConFotos = useMemo(() => {
    const mapa = new Map<string, {
      clave: string;
      grado: string;
      turno: string;
      division: string;
      codigoCurso: string;
      total: number;
      individual: number;
      grupal: number;
      docente: number;
      familia: number;
      patio: number;
      sinPublicar: number;
    }>();
    for (const f of fotosColegioCompleto) {
      const grado = f.grado || '';
      const turno = f.turno || '';
      const division = f.division || '';
      const clave = `${grado}__${turno}__${division}`;
      let fila = mapa.get(clave);
      if (!fila) {
        fila = {
          clave, grado, turno, division,
          codigoCurso: f.codigoCurso || '',
          total: 0, individual: 0, grupal: 0, docente: 0, familia: 0, patio: 0, sinPublicar: 0,
        };
        mapa.set(clave, fila);
      }
      fila.total++;
      if (!f.publicada) fila.sinPublicar++;
      if (f.categoria === 'individual') fila.individual++;
      else if (f.categoria === 'grupal') fila.grupal++;
      else if (f.categoria === 'docente') fila.docente++;
      else if (f.categoria === 'familia') fila.familia++;
      else if (f.categoria === 'patio') fila.patio++;
    }
    return Array.from(mapa.values()).sort((a, b) =>
      a.grado.localeCompare(b.grado, 'es') ||
      a.division.localeCompare(b.division, 'es') ||
      a.turno.localeCompare(b.turno, 'es')
    );
  }, [fotosColegioCompleto]);

  const handleVerCursoDelResumen = (fila: { grado: string; turno: string; division: string }) => {
    if (colaPendiente) return; // FOT-1 (revisión): con fotos en la cola tampoco se cambia de curso desde el resumen
    setGradoSeleccionado(fila.grado);
    setTurnoSeleccionado(fila.turno);
    setDivisionSeleccionada(fila.division);
  };

  // Elimina TODAS las fotos de un curso de una sola vez ("eliminar la carpeta") — reutiliza
  // eliminarFotoActivaAdmin foto por foto (mismo que ya usa handleEliminarSeleccionadas), así
  // borra también los archivos reales en Storage, no sólo el registro en la tabla `fotos`.
  const handleEliminarCarpetaCurso = async (fila: { clave: string; grado: string; turno: string; division: string; total: number }) => {
    const etiqueta = [fila.grado, fila.division, fila.turno].filter(Boolean).join(' · ');
    // Auditoría 03/10 noche (R10): la lista tiene que ser del colegio elegido ahora (si no, se
    // borraría en el colegio equivocado), y el nombre del colegio va en la confirmación.
    const colegioDeLaLista = resumenCursosColegioId;
    if (cargandoResumenCursos || errorResumenCursos || !colegioDeLaLista || colegioDeLaLista !== colegioSeleccionado) {
      setErrorMessage('Esperá a que termine de cargar la lista de cursos de este colegio antes de borrar una carpeta.');
      setTimeout(() => setErrorMessage(null), 5000);
      return;
    }
    const nombreColegio = colegios.find((c) => c.id === colegioDeLaLista)?.nombre || 'este colegio';
    const confirmar = window.confirm(
      `¿Eliminar TODA la carpeta de "${etiqueta}" del colegio ${nombreColegio}? Se van a borrar las ${fila.total} foto(s) de ese curso (Supabase y Storage). Esta acción no se puede deshacer.`
    );
    if (!confirmar) return;

    setCursoEliminandoCarpeta(fila.clave);
    const aBorrar = fotosColegioCompleto.filter(
      f => (!f.colegioId || f.colegioId === colegioDeLaLista) &&
        (f.grado || '') === fila.grado && (f.turno || '') === fila.turno && (f.division || '') === fila.division
    );
    // Auditoría 03/10: borrado en tandas de 200 (antes una llamada por foto).
    const resultadoBorrado = await eliminarFotosEnLoteAdmin(aBorrar.map(f => f.id));
    const exitosas = resultadoBorrado.borradas;
    const fallidas = resultadoBorrado.errores.length;
    const enUso = resultadoBorrado.errores.filter(e => e.enUso).length;
    setCursoEliminandoCarpeta(null);

    await recargarResumenCursos();
    // Si la carpeta borrada es la que está abierta abajo, refrescá también esa vista.
    if (fila.grado === gradoSeleccionado && fila.turno === turnoSeleccionado && fila.division === divisionSeleccionada) {
      await recargarFotosActivas();
    }

    if (fallidas > 0) {
      setErrorMessage(`Carpeta "${etiqueta}": se eliminaron ${exitosas} foto(s), ${fallidas} no se pudieron eliminar${enUso > 0 ? ` (${enUso} están en pedidos ya pagados: borralas de a una para confirmar)` : ''}.`);
      setTimeout(() => setErrorMessage(null), 6000);
    } else {
      setStatusMessage(`Carpeta "${etiqueta}" eliminada: ${exitosas} foto(s) borradas.`);
      setTimeout(() => setStatusMessage(null), 4000);
    }
  };

  // Ejecutar diagnóstico automático al iniciar
  useEffect(() => {
    handleEjecutarDiagnostico();
  }, []);

  const handleEjecutarDiagnostico = async () => {
    setIsTestingSupabase(true);
    try {
      const diag = await testSupabaseConnection();
      setDiagnostico(diag);
      if (diag.fotosWebStatus === 'rls_blocked') {
        setMostrarSqlHelper(true);
      }
    } catch (err: any) {
      console.error('Error al probar Supabase:', err);
    } finally {
      setIsTestingSupabase(false);
    }
  };

  // Nombre de archivo cualquiera (espacios, tildes, "ñ", paréntesis) → clave segura para Storage
  // (sin esto, "con la seño (1).png" fallaba con "Invalid key").
  const sanitizarNombreParaStorage = (nombre: string): string => {
    return nombre
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '') // saca tildes/diacríticos (é→e, ñ→n, etc.)
      .replace(/[^a-zA-Z0-9._-]/g, '_') // espacios, paréntesis y cualquier otro símbolo → "_"
      .replace(/_+/g, '_').replace(/\.{2,}/g, '.') // FOT-2 (11/10): el servidor descarta rutas con «..»
      .replace(/^_+|_+$/g, '') || 'foto';
  };

  // Desenfoque de la muestra con lupa (04/10): sigma 1,35 px en una muestra de 800 px (Pablo pidió un 50% más
  // que el "muy suave" de 0,9), igual que SIGMA_DESENFOQUE_800 en lupa/muestra.ts.
  const dibujarDesenfocada = (ctx: CanvasRenderingContext2D, img: HTMLImageElement, ancho: number, alto: number) => {
    const sigma = Math.max(0.3, 1.35 * (Math.max(ancho, alto) / 800));
    if (typeof ctx.filter === 'string') {
      ctx.filter = `blur(${sigma.toFixed(2)}px)`;
      ctx.drawImage(img, 0, 0, ancho, alto);
      ctx.filter = 'none';
      return;
    }
    // Navegadores sin filtros en canvas (Safari): se achica y se vuelve a agrandar, que suaviza parecido.
    const chico = document.createElement('canvas');
    chico.width = Math.max(1, Math.round(ancho / (1 + sigma)));
    chico.height = Math.max(1, Math.round(alto / (1 + sigma)));
    chico.getContext('2d')?.drawImage(img, 0, 0, chico.width, chico.height);
    ctx.imageSmoothingQuality = 'high';
    ctx.drawImage(chico, 0, 0, ancho, alto);
    chico.width = 0;
    chico.height = 0;
  };

  // Watermarking generator function — además reduce el tamaño para que la copia pública
  // (fotos-web) sea liviana: la marca de agua queda quemada en los píxeles, no es un
  // simple overlay, así que esta es la única versión que se sube al bucket público.
  //
  // 04/10 (pedido de Pablo): depende del interruptor «Muestras con lupa» del colegio.
  //   - Prendido: 800 px, desenfoque "muy suave" y "PASÁ LA LUPA POR LA IMAGEN": la foto nítida se ve
  //     sólo dentro de la lupa (el servidor manda el pedacito que se mira, ver lupa/recorte.ts).
  //   - Apagado: la clásica de siempre (1600 px, "MUESTRA · RETRATO ESCOLAR").
  // Mismas recetas que lupa/muestra.ts: si se cambian acá, cambiarlas allá también.
  const applyWatermarkToCanvas = (img: HTMLImageElement, conLupa: boolean): HTMLCanvasElement | null => {
    const MAX_DIMENSION = conLupa ? 800 : 1600;
    let anchoDestino = img.width;
    let altoDestino = img.height;
    if (anchoDestino > MAX_DIMENSION || altoDestino > MAX_DIMENSION) {
      const escala = MAX_DIMENSION / Math.max(anchoDestino, altoDestino);
      anchoDestino = Math.round(anchoDestino * escala);
      altoDestino = Math.round(altoDestino * escala);
    }

    const canvas = document.createElement('canvas');
    canvas.width = anchoDestino;
    canvas.height = altoDestino;
    const ctx = canvas.getContext('2d');
    if (!ctx) return null;

    if (conLupa) dibujarDesenfocada(ctx, img, anchoDestino, altoDestino);
    else ctx.drawImage(img, 0, 0, anchoDestino, altoDestino);

    ctx.save();
    // Marca de agua real, quemada en los píxeles (no se puede desactivar ni quitar):
    // visible y legible, pero sin la densidad exagerada de la versión original.
    //
    // Importante: el texto anterior ("MUESTRA RETRATO ESCOLAR · FOTOGRAFÍA ESCOLAR") medía
    // más ancho que el espacio entre repeticiones (stepX), así que cada copia se superponía
    // con la siguiente y el resultado se veía como si hubiera dos marcas de agua pisándose.
    // Por eso ahora el texto es más corto y stepX se calcula a partir del ancho real del
    // texto medido con measureText, con un margen — así nunca se pisan entre sí.
    const text = conLupa ? 'PASÁ LA LUPA POR LA IMAGEN' : 'MUESTRA · RETRATO ESCOLAR';
    const fontSize = Math.max(14, Math.round(canvas.width * 0.032));
    ctx.font = `bold ${fontSize}px sans-serif`;
    ctx.fillStyle = 'rgba(255, 255, 255, 0.6)';
    ctx.shadowColor = 'rgba(0, 0, 0, 0.65)';
    ctx.shadowBlur = 4;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';

    const anchoTexto = ctx.measureText(text).width;
    const stepX = anchoTexto * 1.25;
    const stepY = canvas.height * 0.26;

    ctx.translate(canvas.width / 2, canvas.height / 2);
    ctx.rotate((-25 * Math.PI) / 180);

    const anchoVirtual = canvas.width * 2.2;
    const altoVirtual = canvas.height * 2.2;
    let fila = 0;
    for (let y = -altoVirtual / 2; y < altoVirtual / 2; y += stepY) {
      const offsetFila = fila % 2 === 0 ? 0 : stepX / 2;
      for (let x = -anchoVirtual / 2 + offsetFila; x < anchoVirtual / 2; x += stepX) {
        ctx.fillText(text, x, y);
      }
      fila++;
    }
    ctx.restore();

    return canvas;
  };

  // Miniatura liviana SIN marca de agua: es la que ven las familias en la grilla de la
  // galería. Al ser chica (ideal para una miniatura) no sirve para imprimir ni para robar
  // una copia útil, así que no hace falta quemarle el texto encima — la protección real
  // (marca de agua quemada en los píxeles) sigue estando en la versión ampliada.
  const generarMiniaturaLimpia = (img: HTMLImageElement): HTMLCanvasElement | null => {
    // Auditoría 2026-09-26 (M7): 320 px (antes 500). Esta copia no lleva marca de agua y es
    // pública; a 500 px ya servía para compartir en redes sin comprar. 320 alcanza para la grilla.
    const MAX_DIMENSION_THUMB = 320;
    let anchoDestino = img.width;
    let altoDestino = img.height;
    if (anchoDestino > MAX_DIMENSION_THUMB || altoDestino > MAX_DIMENSION_THUMB) {
      const escala = MAX_DIMENSION_THUMB / Math.max(anchoDestino, altoDestino);
      anchoDestino = Math.round(anchoDestino * escala);
      altoDestino = Math.round(altoDestino * escala);
    }
    const canvas = document.createElement('canvas');
    canvas.width = anchoDestino;
    canvas.height = altoDestino;
    const ctx = canvas.getContext('2d');
    if (!ctx) return null;
    ctx.drawImage(img, 0, 0, anchoDestino, altoDestino);
    return canvas;
  };

  /** Genera, de a una foto, la muestra con marca de agua y la miniatura limpia (Blobs, no base64). */
  const procesarFoto = async (file: File, conLupa: boolean): Promise<{ web: Blob; thumb: Blob }> => {
    const img = await cargarImagen(file);
    try {
      const canvasWeb = applyWatermarkToCanvas(img, conLupa);
      const canvasThumb = generarMiniaturaLimpia(img);
      if (!canvasWeb || !canvasThumb) throw new Error('El navegador no pudo procesar esta foto.');
      const web = await canvasABlob(canvasWeb, 0.85);
      const thumb = await canvasABlob(canvasThumb, 0.82);
      return { web, thumb };
    } finally {
      img.src = '';
    }
  };

  /** Miniatura chica sólo para revisar la cola (se libera al subir o al sacar la foto). */
  const miniaturaDeRevision = async (file: File): Promise<string | undefined> => {
    try {
      const img = await cargarImagen(file);
      const canvas = generarMiniaturaLimpia(img);
      img.src = '';
      if (!canvas) return undefined;
      return URL.createObjectURL(await canvasABlob(canvas, 0.7));
    } catch {
      return undefined;
    }
  };

  const handleFilesSelected = async (files: FileList | File[] | null) => {
    if (!files || files.length === 0) return;
    setIsProcessing(true);
    setErrorMessage(null);

    const alumnoEncontrado = alumnosDelCurso.find(a => a.id === alumnoSeleccionadoId);
    // Sólo se guarda el File: la muestra con marca y la miniatura se generan al subir (crítico 5).
    // 14/10: se saltean las que ya están subidas en este curso o en la cola (mismo nombre y tamaño).
    const { nuevos: archivos, repetidos } = separarYaSubidas(Array.from(files), [...fotosActivasCurso, ...fotosLote.map((f) => ({ nombreOriginal: f.nombreOriginal, bytesOriginal: f.file?.size }))]);
    const base = Date.now();
    const nuevosItems: FotoLoteItem[] = archivos.map((file, i) => ({
      id: `foto-${base}-${i}`,
      file,
      tipo: tipoFotoLote,
      nombreOriginal: file.name,
      estado: 'procesada' as const,
      alumnoNombre: alumnoEncontrado ? alumnoEncontrado.nombre : undefined,
    }));
    setFotosLote(prev => [...nuevosItems, ...prev]);

    // Unas pocas miniaturas, de a una, para poder revisar la tanda antes de subirla.
    for (const item of nuevosItems.slice(0, MINIATURAS_DE_REVISION)) {
      const thumbUrl = await miniaturaDeRevision(item.file as File);
      if (!thumbUrl) continue;
      // Si la foto ya no está en la cola (la sacaron), se libera enseguida.
      if (!fotosLoteRef.current.some(f => f.id === item.id && !f.thumbUrl)) {
        liberarUrl(thumbUrl);
        continue;
      }
      setFotosLote(prev => prev.map(f => (f.id === item.id && !f.thumbUrl ? { ...f, thumbUrl } : f)));
    }

    setIsProcessing(false);
    setStatusMessage(`¡${archivos.length} foto(s) listas para subir a ${nombreSeccionActual}! La marca de agua se aplica al subir.${repetidos > 0 ? ` Se saltearon ${repetidos} que ya estaban subidas a este curso o en la lista.` : ''}`);
    setTimeout(() => setStatusMessage(null), 4000);
  };

  const handleEliminarFotoDeCola = (id: string) => {
    setFotosLote(prev => {
      prev.filter(f => f.id === id).forEach(f => liberarUrl(f.thumbUrl));
      return prev.filter(f => f.id !== id);
    });
  };

  const handleVaciarCola = () => {
    fotosLote.forEach(f => liberarUrl(f.thumbUrl));
    setFotosLote([]);
    setStatusMessage('Lista de espera vaciada.');
    setTimeout(() => setStatusMessage(null), 3000);
  };

  const handleCancelarSubida = () => {
    cancelarSubidaRef.current = true;
    setCancelandoSubida(true);
  };

  const handleSubirASupabase = async () => {
    if (fotosLote.length === 0) return;
    setIsUploading(true);
    setCancelandoSubida(false);
    cancelarSubidaRef.current = false;
    setErrorMessage(null);

    // Se trabaja sobre copias de los ítems (el estado de React no se muta).
    const cola: FotoLoteItem[] = fotosLote.map(f => ({ ...f }));
    const aProcesar = cola.filter(f => f.estado !== 'registrada');
    setUploadProgress({ actual: 0, total: aProcesar.length });

    let registradas = 0;
    let fallidas = 0;
    let emailsEnviados = 0;
    let avisoEmail: string | undefined;
    let errorRegistro: string | undefined;
    let fueCancelada = false;
    const porRegistrar: FotoLoteItem[] = [];

    const refrescar = () => setFotosLote(cola.filter(f => f.estado !== 'registrada'));

    const claveCurso = `${colegioSeleccionado}|${gradoSeleccionado}|${turnoSeleccionado}|${divisionSeleccionada}`;
    let marcaSubida: string | undefined =
      marcaSubidaPendienteRef.current?.curso === claveCurso ? marcaSubidaPendienteRef.current.marca : undefined;
    let avisoMandado = false;

    // Auditoría 03/10 (crítico 5): se registran a medida que suben (un corte no deja todo sin anotar).
    // Las tandas intermedias van con avisar:false; el aviso sale con la final (o al tocar «Publicar»).
    const registrarTandaAhora = async (final: boolean) => {
      // 14/10: cada foto se anota en el catálogo apenas sube (antes de a 40: un corte dejaba hasta 40 sin anotar).
      if (porRegistrar.length === 0) return;
      const tanda = porRegistrar.splice(0, porRegistrar.length);
      const avisar = final && !fueCancelada;
      const resultado = await registrarFotosAdmin(tanda.map(f => f.registro as DatosFotoParaRegistrar), { avisar, subidaDesde: marcaSubida });
      if (!marcaSubida && resultado.marcaSubida) marcaSubida = resultado.marcaSubida;
      if (resultado.success && avisar) avisoMandado = true;
      if (resultado.success) {
        for (const f of tanda) {
          f.estado = 'registrada';
          f.errorMensaje = undefined;
          liberarUrl(f.thumbUrl);
          f.thumbUrl = undefined;
          f.file = undefined;
        }
        registradas += tanda.length;
        emailsEnviados += resultado.emailsEnviados || 0;
        avisoEmail = avisoEmail || resultado.warning;
      } else {
        errorRegistro = resultado.error || 'No se pudieron registrar en el catálogo.';
        for (const f of tanda) {
          f.estado = 'subida';
          f.errorMensaje = 'Subida, falta registrarla en el catálogo (reintentá: no se vuelve a subir).';
        }
      }
      refrescar();
    };

    // 24/10 (velocidad): se suben SUBIDAS_SIMULTANEAS fotos a la vez, pero el registro va en fila (una marca de aviso, sin dobles).
    const enFila = crearFila();
    const registrarTanda = (final: boolean) => enFila(() => registrarTandaAhora(final));
    let terminadas = 0;

    const subirUna = async (item: FotoLoteItem) => {
      if (item.estado === 'subida' && item.registro) porRegistrar.push(item); // reintento: ya está en Storage, falta registrarla
      else if (item.file) await subirArchivo(item, item.file);
      setUploadProgress({ actual: ++terminadas, total: aProcesar.length });
      refrescar();
      await registrarTanda(false);
    };

    const subirArchivo = async (item: FotoLoteItem, archivo: File) => {
      try {
        item.estado = 'subiendo';
        item.errorMensaje = undefined;
        refrescar();

        // Muestra con marca de agua y miniatura limpia, generadas recién ahora y de a una.
        const { web, thumb } = await procesarFoto(archivo, colegios.find((c) => c.id === colegioSeleccionado)?.muestrasLupa === true);
        if (!item.thumbUrl) item.thumbUrl = URL.createObjectURL(thumb);

        // Nombre saneado para la clave de Storage (ver sanitizarNombreParaStorage más arriba).
        const extensionOriginal = (item.nombreOriginal.match(/\.[a-zA-Z0-9]{1,5}$/)?.[0] || '.jpg'); // FOT-2: extensión saneada
        const nombreBaseOriginal = item.nombreOriginal.replace(/\.[^./]+$/, '');
        // Auditoría 2026-09-24 (CRÍTICO): la ruta lleva el colegio y un sufijo único (dos archivos iguales no se pisan).
        const nombreBaseSaneado = sanitizarNombreParaStorage(nombreBaseOriginal);
        const sufijoUnico = `${Date.now().toString(36)}${Math.random().toString(36).slice(2, 8)}`;
        const carpetaColegio = sanitizarNombreParaStorage(colegioSeleccionado || 'colegio');
        const nombreUnico = `${nombreBaseSaneado}_${sufijoUnico}`;
        const pathHD = `2026/${carpetaColegio}/${cursoSeleccionado}/originales/${nombreUnico}${extensionOriginal}`;
        const pathWeb = `2026/${carpetaColegio}/${cursoSeleccionado}/muestras/${nombreUnico}.jpg`;
        const pathThumb = `2026/${carpetaColegio}/${cursoSeleccionado}/miniaturas/${nombreUnico}.jpg`;

        // 1. Original HD sin tocar al bucket privado · 2 y 3. muestra con marca y miniatura limpia, juntas (24/10).
        const resHD = await uploadFotoHD(archivo, pathHD);
        const sinSubir = { publicUrl: '', error: undefined as string | undefined };
        const [resWeb, resThumb] = resHD.error
          ? [sinSubir, sinSubir]
          : await Promise.all([uploadFotoWeb(web, pathWeb), uploadFotoWeb(thumb, pathThumb)]);

        if (resHD.error || resWeb.error || resThumb.error) {
          item.estado = 'error';
          item.errorMensaje = resHD.error || resWeb.error || resThumb.error;
          fallidas++;
        } else {
          // "?v=..." evita que el navegador reuse una versión vieja de la imagen en caché.
          const versionCache = Date.now();
          item.registro = {
            colegioId: colegioSeleccionado,
            categoria: item.tipo,
            grado: gradoSeleccionado,
            turno: turnoSeleccionado,
            division: divisionSeleccionada,
            storagePathHD: pathHD,
            storagePathWeb: resWeb.publicUrl ? `${resWeb.publicUrl}?v=${versionCache}` : pathWeb,
            storagePathThumb: resThumb.publicUrl ? `${resThumb.publicUrl}?v=${versionCache}` : pathThumb,
            alumnoNombre: item.alumnoNombre,
            nombreOriginal: item.nombreOriginal,
            bytesOriginal: archivo.size,
          };
          item.estado = 'subida';
          porRegistrar.push(item);
        }
      } catch (errFoto: any) {
        item.estado = 'error';
        item.errorMensaje = errFoto?.message || 'Error inesperado al subir esta foto.';
        fallidas++;
      }
    };

    if (await recorrerConLimite(aProcesar, SUBIDAS_SIMULTANEAS, subirUna, () => cancelarSubidaRef.current)) fueCancelada = true;

    // Lo que quedó subido sin registrar (fin, cancelación o tanda incompleta) se registra ahora.
    await registrarTanda(true);
    marcaSubidaPendienteRef.current = !avisoMandado && marcaSubida ? { curso: claveCurso, marca: marcaSubida } : null;

    setIsUploading(false);
    setCancelandoSubida(false);
    cancelarSubidaRef.current = false;
    refrescar();
    await recargarFotosActivas();
    await recargarResumenCursos();

    const sinRegistrar = cola.filter(f => f.estado === 'subida').length;
    const pendientes = cola.filter(f => f.estado !== 'registrada').length;

    if (errorRegistro || sinRegistrar > 0) {
      setErrorMessage(`Se registraron ${registradas} foto(s). ${sinRegistrar} quedaron subidas pero sin registrar en el catálogo (${errorRegistro || 'error al registrar'}). Tocá "Subir" de nuevo: sólo se registran, no se vuelven a subir.${fallidas > 0 ? ` Además ${fallidas} foto(s) fallaron al subir.` : ''}`);
    } else if (fueCancelada) {
      setStatusMessage(`Subida cancelada: ${registradas} foto(s) ya quedaron guardadas (sin publicar), ${pendientes} quedaron pendientes en la lista para subir después.`);
      setTimeout(() => setStatusMessage(null), 7000);
    } else if (fallidas > 0) {
      setErrorMessage(`Se subieron y registraron ${registradas} fotos. ${fallidas} fotos fallaron (quedan en la lista). Revisá el diagnóstico de arriba (puede ser la sesión de admin vencida) y volvé a intentar.`);
    } else {
      // 06/10: quedan SIN PUBLICAR hasta que Pablo toque «Publicar» (ahí sale el aviso por email).
      setStatusMessage(`¡${registradas} foto(s) subidas para ${nombreSeccionActual}! Quedaron SIN PUBLICAR: las familias todavía no las ven. Revisalas abajo (borrá las que estén mal) y tocá «Publicar».${emailsEnviados > 0 ? ` Se enviaron ${emailsEnviados} aviso(s) por email.` : ''}${avisoEmail ? ` ${avisoEmail}` : ''}`);
      setTimeout(() => setStatusMessage(null), 12000);
    }
  };

  // Migración: fotos que ya estaban subidas antes de separar la miniatura limpia de la
  // versión con marca de agua. Genera la miniatura faltante a partir del original guardado,
  // sin tener que volver a subir nada. Se llama al endpoint en bucle porque el servidor
  // procesa de a un lote chico por vez (para no exceder el tiempo de una función serverless).
  // Auditoría 2026-09-26 (M8): primero cuenta y pide confirmación; recién ahí borra.
  const [limpiandoHuerfanos, setLimpiandoHuerfanos] = useState(false);
  const handleLimpiarHuerfanos = async () => {
    setLimpiandoHuerfanos(true);
    setErrorMessage(null);
    try {
      const conteo = await limpiarArchivosHuerfanosAdmin(false);
      if (!conteo.success) {
        setErrorMessage(conteo.error || 'No se pudo revisar el almacenamiento.');
        return;
      }
      const total = (conteo.muestrasPublicasHuerfanas || 0) + (conteo.originalesHdHuerfanos || 0) + (conteo.zipsSinPedidoCobrado || 0);
      if (total === 0) {
        setStatusMessage('No hay archivos huérfanos: el almacenamiento coincide con el catálogo.');
        setTimeout(() => setStatusMessage(null), 5000);
        return;
      }
      const confirmar = window.confirm(
        `Se encontraron archivos que ya no están en el catálogo:\n\n` +
        `• ${conteo.muestrasPublicasHuerfanas || 0} muestras/miniaturas públicas\n` +
        `• ${conteo.originalesHdHuerfanos || 0} originales HD\n` +
        `• ${conteo.zipsSinPedidoCobrado || 0} .zip de pedidos no cobrados\n\n` +
        `¿Borrarlos? No se puede deshacer. (No lo hagas mientras se está subiendo un lote de fotos.)`
      );
      if (!confirmar) return;
      const resultado = await limpiarArchivosHuerfanosAdmin(true);
      if (!resultado.success) {
        setErrorMessage(resultado.error || 'No se pudieron borrar los archivos huérfanos.');
        return;
      }
      setStatusMessage(`Listo: se borraron ${resultado.borrados || 0} archivo(s) huérfano(s).`);
      setTimeout(() => setStatusMessage(null), 6000);
    } finally {
      setLimpiandoHuerfanos(false);
    }
  };

  const handleRegenerarMiniaturas = async () => {
    const confirmar = window.confirm(
      'Esto va a generar la miniatura limpia (sin marca de agua) para todas las fotos que ya subiste antes de este cambio — incluidas las de prueba duplicadas. Puede tardar unos minutos. ¿Continuar?'
    );
    if (!confirmar) return;

    setRegenerandoMiniaturas(true);
    setErrorMessage(null);
    let totalProcesadas = 0;
    let totalFallidas = 0;
    let restantes = 1;

    try {
      while (restantes > 0) {
        const resultado = await regenerarMiniaturasAdmin(12);
        if (!resultado.success) {
          setErrorMessage(resultado.error || 'No se pudieron regenerar las miniaturas.');
          break;
        }
        totalProcesadas += resultado.procesadas || 0;
        totalFallidas += resultado.fallidas || 0;
        restantes = resultado.restantes || 0;
        setProgresoMiniaturas({ procesadas: totalProcesadas, fallidas: totalFallidas, restantes });
      }
      setStatusMessage(
        `¡Listo! Se regeneraron ${totalProcesadas} miniatura(s) limpia(s)${totalFallidas > 0 ? `, ${totalFallidas} fallaron` : ''}.`
      );
      setTimeout(() => setStatusMessage(null), 8000);
      await recargarFotosActivas();
    } finally {
      setRegenerandoMiniaturas(false);
      setProgresoMiniaturas(null);
    }
  };

  // Migración: re-genera la vista ampliada (con marca de agua quemada) de TODAS las fotos
  // ya subidas, usando la nueva versión más liviana y espaciada — a partir del original
  // guardado, sin volver a subir nada. Avanza con "offset" en lugar de filtrar, porque acá
  // se quiere reprocesar cada foto una sola vez, ya tenga o no la marca vieja.
  const handleRegenerarMarcaAgua = async () => {
    const confirmar = window.confirm(
      'Esto va a rehacer la vista ampliada de TODAS las fotos ya subidas según lo elegido en cada colegio: con «Muestras con lupa» (desenfoque suave + «PASÁ LA LUPA POR LA IMAGEN») o la clásica de siempre. No hay que volver a subir nada. Puede tardar varios minutos. ¿Continuar?'
    );
    if (!confirmar) return;

    setRegenerandoMarcaAgua(true);
    setErrorMessage(null);
    let totalProcesadas = 0;
    let totalFallidas = 0;
    let restantes = 1;
    let offset = 0;

    try {
      while (restantes > 0) {
        const resultado = await regenerarMarcaAguaAdmin(8, offset);
        if (!resultado.success) {
          setErrorMessage(resultado.error || 'No se pudo regenerar la marca de agua.');
          break;
        }
        totalProcesadas += resultado.procesadas || 0;
        totalFallidas += resultado.fallidas || 0;
        restantes = resultado.restantes || 0;
        offset = resultado.siguienteOffset || offset;
        setProgresoMarcaAgua({ procesadas: totalProcesadas, fallidas: totalFallidas, restantes });
      }
      setStatusMessage(
        `¡Listo! Se actualizó la muestra de ${totalProcesadas} foto(s)${totalFallidas > 0 ? `, ${totalFallidas} fallaron` : ''}.`
      );
      setTimeout(() => setStatusMessage(null), 8000);
      await recargarFotosActivas();
    } finally {
      setRegenerandoMarcaAgua(false);
      setProgresoMarcaAgua(null);
    }
  };

  const handleEliminarFotoActiva = async (foto: FotoRegistrada) => {
    const confirmar = window.confirm('¿Deseás eliminar esta foto de Supabase y del catálogo del curso?');
    if (!confirmar) return;

    let resultado = await eliminarFotoActivaAdmin(foto);
    // Auditoría 2026-09-26 (M9): la foto está en pedidos ya pagados — se pide confirmación explícita.
    if (!resultado.success && resultado.enUso) {
      const forzar = window.confirm(`${resultado.error}\n\n¿Borrarla igual?`);
      if (!forzar) return;
      resultado = await eliminarFotoActivaAdmin(foto, { forzar: true });
    }
    if (!resultado.success) {
      setErrorMessage(resultado.error || 'No se pudo eliminar la foto.');
      setTimeout(() => setErrorMessage(null), 5000);
      return;
    }
    await recargarFotosActivas();
    await recargarResumenCursos();
    // Auditoría 2026-09-22: eliminarFotoActivaAdmin ahora puede devolver success:true con un
    // `error` informativo cuando el registro se borró del catálogo pero el archivo en el bucket
    // no se pudo borrar (antes esto pasaba desapercibido). Se muestra ese caso como advertencia
    // en vez del mensaje de éxito normal.
    if (resultado.error) {
      setErrorMessage(resultado.error);
      setTimeout(() => setErrorMessage(null), 8000);
    } else {
      setStatusMessage('Foto eliminada de Supabase.');
      setTimeout(() => setStatusMessage(null), 3000);
    }
  };

  const handleToggleModoSeleccion = () => {
    setModoSeleccionActivas(prev => !prev);
    setIdsSeleccionados(new Set());
  };

  // Conteo de fotos activas por categoría (para las pestañas de filtro) y la lista ya
  // filtrada según la categoría elegida — "todas" muestra el curso completo, como antes.
  const conteoActivasPorCategoria = useMemo(() => {
    const conteo = { individual: 0, grupal: 0, docente: 0, familia: 0, patio: 0 };
    for (const f of fotosActivasCurso) {
      if (f.categoria === 'individual') conteo.individual++;
      else if (f.categoria === 'grupal') conteo.grupal++;
      else if (f.categoria === 'docente') conteo.docente++;
      else if (f.categoria === 'familia') conteo.familia++;
      else if (f.categoria === 'patio') conteo.patio++;
    }
    return conteo;
  }, [fotosActivasCurso]);

  const fotosActivasFiltradas = useMemo(() => {
    if (filtroCategoriaActivas === 'todas') return fotosActivasCurso;
    if (filtroCategoriaActivas === 'sin_publicar') return fotosActivasCurso.filter(f => !f.publicada);
    return fotosActivasCurso.filter(f => f.categoria === filtroCategoriaActivas);
  }, [fotosActivasCurso, filtroCategoriaActivas]);
  const sinPublicarCurso = useMemo(() => fotosActivasCurso.filter(f => !f.publicada), [fotosActivasCurso]);
  const publicadasCurso = fotosActivasCurso.length - sinPublicarCurso.length;

  // 06/10/2026 (Pablo): las fotos se suben SIN PUBLICAR y las familias recién las ven al tocar «Publicar». Si el
  // curso todavía no tiene el aviso confirmado, ahí sale el email «ya están tus fotos» (14/10: se puede reenviar).
  const handlePublicar = async (ids: string[], etiqueta: string, clave: string) => {
    if (ids.length === 0 || publicando) return;
    const confirmar = window.confirm(
      `¿Publicar ${ids.length} foto(s) de ${etiqueta}?\n\nDesde ese momento las ven las familias del curso. Si el curso todavía no fue avisado, les llega el email «¡Las fotos ya están online!».`
    );
    if (!confirmar) return;
    setPublicando(clave);
    setErrorMessage(null);
    const r = await publicarFotosAdmin({ ids });
    setPublicando(null);
    if (clave === 'seleccion') {
      setIdsSeleccionados(new Set());
      setModoSeleccionActivas(false);
    }
    await recargarFotosActivas();
    await recargarResumenCursos();
    if (!r.success) {
      setErrorMessage(`${r.publicadas > 0 ? `Se publicaron ${r.publicadas} foto(s), pero ` : ''}${r.error || 'No se pudieron publicar las fotos.'}`);
      setTimeout(() => setErrorMessage(null), 8000);
      return;
    }
    // Auditoría 08/10 (A3): si no se publicó ninguna (p. ej. individuales sin nombre), se muestra el motivo.
    if (r.publicadas === 0 && r.warning) {
      setErrorMessage(r.warning);
      setTimeout(() => setErrorMessage(null), 10000);
      return;
    }
    setStatusMessage(
      `¡Listo! ${r.publicadas} foto(s) publicadas en ${etiqueta}: ya las ven las familias.` +
      (r.emailsEnviados > 0 ? ` Se avisó por email a ${r.emailsEnviados} familia(s).` : ' No se mandó email (el curso ya había sido avisado o no tiene familias inscriptas aprobadas).') +
      (r.warning ? ` ${r.warning}` : '')
    );
    setTimeout(() => setStatusMessage(null), 9000);
  };

  const handleToggleSeleccionFoto = (id: string) => {
    setIdsSeleccionados(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const handleSeleccionarTodasActivas = () => {
    // Respeta el filtro de categoría activo: si estás viendo sólo "Grupal", selecciona
    // sólo esas — no todo el curso.
    setIdsSeleccionados(new Set(fotosActivasFiltradas.map(f => f.id)));
  };

  const handleEliminarSeleccionadas = async () => {
    if (idsSeleccionados.size === 0) return;
    const confirmar = window.confirm(
      `¿Deseás eliminar ${idsSeleccionados.size} foto(s) de Supabase y del catálogo del curso? Esta acción no se puede deshacer.`
    );
    if (!confirmar) return;

    setBorrandoSeleccionadas(true);
    const aBorrar = fotosActivasCurso.filter(f => idsSeleccionados.has(f.id));
    // Auditoría 03/10: borrado en tandas de 200 (antes una llamada por foto).
    const resultadoBorrado = await eliminarFotosEnLoteAdmin(aBorrar.map(f => f.id));
    const exitosas = resultadoBorrado.borradas;
    const fallidas = resultadoBorrado.errores.length;
    const enUso = resultadoBorrado.errores.filter(e => e.enUso).length;

    setBorrandoSeleccionadas(false);
    setIdsSeleccionados(new Set());
    setModoSeleccionActivas(false);
    await recargarFotosActivas();
    await recargarResumenCursos();

    if (fallidas > 0) {
      setErrorMessage(`Se eliminaron ${exitosas} foto(s). ${fallidas} no se pudieron eliminar${enUso > 0 ? ` (${enUso} están en pedidos ya pagados: borralas de a una para confirmar)` : ''}.`);
      setTimeout(() => setErrorMessage(null), 6000);
    } else {
      setStatusMessage(`${exitosas} foto(s) eliminadas de Supabase.`);
      setTimeout(() => setStatusMessage(null), 4000);
    }
  };

  // Auditoría 2026-09-09: este script antes dejaba política pública de INSERT en fotos-web,
  // e INSERT + SELECT + "FOR ALL" (o sea, también UPDATE/DELETE) públicas en fotos-hd — eso es
  // lo que permitía a cualquier visitante (sin PIN, sin login) descargar gratis todas las
  // fotos originales y borrar todo el storage del negocio. Ya no hace falta ninguna de esas
  // políticas: la app ahora sube/borra/limpia todo a través del servidor (con sesión de admin
  // y la Service Role Key, que no necesita RLS). Este script queda solo para (re)crear los
  // buckets si hiciera falta (sin ninguna política pública: ver auditoría 2026-09-26 abajo).
  const sqlPoliticas = `-- ==========================================
-- CONFIGURACIÓN DE BUCKETS PARA SUPABASE STORAGE
-- Ejecutar en Supabase -> SQL Editor -> Run
-- (auditoría 2026-09-09: ya NO se necesitan políticas de INSERT/UPDATE/DELETE públicas —
--  todo eso lo hace el servidor con la Service Role Key)
-- ==========================================

-- 1. Crear / Asegurar los dos buckets necesarios
INSERT INTO storage.buckets (id, name, public)
VALUES
  ('fotos-web', 'fotos-web', true),
  ('fotos-hd', 'fotos-hd', false)
ON CONFLICT (id) DO UPDATE SET public = EXCLUDED.public;

-- 2. NO hace falta ninguna política de lectura: un bucket público ya sirve cada archivo por su URL.
--    (Auditoría 2026-09-26: la vieja política "Permitir lectura publica fotos-web" permitía LISTAR
--    todo el bucket con la clave pública y bajar las fotos de todos los cursos. No la vuelvas a crear.)
DROP POLICY IF EXISTS "Permitir lectura publica fotos-web" ON storage.objects;

-- NO agregar políticas de INSERT/UPDATE/DELETE ni de SELECT sobre fotos-hd acá: eso reabriría
-- el agujero de seguridad de la auditoría 2026-09-09. Todo eso pasa por el servidor.`;

  const handleCopiarSql = () => {
    void copiarAlPortapapeles(sqlPoliticas);
    setSqlCopiado(true);
    setTimeout(() => setSqlCopiado(false), 3000);
  };

  return (
    <div className="space-y-6 text-left">
      {/* Toast Feedback */}
      {statusMessage && (
        <div className="p-4 bg-emerald-50 border border-emerald-300 text-emerald-950 rounded-2xl text-xs font-bold flex items-center justify-between gap-3 shadow-xs animate-in fade-in">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
            <span>{statusMessage}</span>
          </div>
          <button 
            onClick={() => setStatusMessage(null)}
            className="text-emerald-700 hover:text-emerald-900 text-xs px-2 py-1 rounded bg-emerald-100 cursor-pointer"
          >
            Cerrar
          </button>
        </div>
      )}

      {errorMessage && (
        <div className="p-4 bg-rose-50 border border-rose-300 text-rose-950 rounded-2xl text-xs font-bold flex items-center justify-between gap-3 shadow-xs animate-in fade-in">
          <div className="flex items-center gap-2">
            <AlertCircle className="w-5 h-5 text-rose-600 shrink-0" />
            <span>{errorMessage}</span>
          </div>
          <button 
            onClick={() => setErrorMessage(null)}
            className="text-rose-700 hover:text-rose-900 text-xs px-2 py-1 rounded bg-rose-100 cursor-pointer"
          >
            Cerrar
          </button>
        </div>
      )}

      {/* Supabase Connection Status Card — Auditoría 2026-09-22 (pedido de Pablo): los dos
          casilleros de estado de buckets ("Bucket Público"/"Bucket Privado") vivían en su propia
          fila grande debajo del título. Se meten como chips compactos EN la misma fila del título
          y los botones, y todo el sector se achica a la mitad (padding, íconos y tipografía). */}
      <div className="p-2.5 rounded-2xl bg-slate-900 text-white shadow-sm">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center border border-emerald-500/30 shrink-0">
              <Database className="w-3.5 h-3.5" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <h3 className="text-xs font-bold tracking-wide">Almacenamiento Supabase Pro (100 GB)</h3>
                <span className="px-1.5 py-0.5 rounded-full text-[9px] font-extrabold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                  Activo
                </span>
              </div>
              <p className="text-[10px] text-slate-400">Estado del almacenamiento de fotografías</p>
            </div>
          </div>

          {/* Diagnostic Status Chips — compactos, ahora en línea con el título */}
          <div className="flex items-center gap-1.5 text-[10px] font-mono font-bold">
            <span className="flex items-center gap-1 bg-slate-800/80 px-2 py-1 rounded-lg border border-slate-700/60">
              <span className="text-slate-400 font-sans font-normal">Web:</span>
              <span className="text-amber-300">fotos-web</span>
              {diagnostico ? (
                diagnostico.fotosWebStatus === 'ok' ? (
                  <span className="text-emerald-400">✓</span>
                ) : diagnostico.fotosWebStatus === 'rls_blocked' ? (
                  <span className="text-amber-400" title="Falta RLS">⚠</span>
                ) : (
                  <span className="text-rose-400" title="Error">✗</span>
                )
              ) : (
                <span className="text-slate-500 font-sans font-normal">…</span>
              )}
            </span>
            <span className="flex items-center gap-1 bg-slate-800/80 px-2 py-1 rounded-lg border border-slate-700/60">
              <span className="text-slate-400 font-sans font-normal">HD:</span>
              <span className="text-sky-300">fotos-hd</span>
              {diagnostico ? (
                diagnostico.fotosHdStatus === 'ok' ? (
                  <span className="text-emerald-400" title="Bucket privado, protegido por el servidor (no por RLS pública) — así debe estar.">✓</span>
                ) : (
                  <span className="text-rose-400" title={diagnostico.fotosHdError || 'Servidor no responde'}>✗</span>
                )
              ) : (
                <span className="text-slate-500 font-sans font-normal">…</span>
              )}
            </span>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              onClick={handleEjecutarDiagnostico}
              disabled={isTestingSupabase}
              className="px-2 py-1 bg-slate-800 hover:bg-slate-700 disabled:opacity-50 text-[10px] font-bold rounded-lg transition-all border border-slate-700 flex items-center gap-1 cursor-pointer"
              title="Probar conexión con Supabase Storage"
            >
              <RefreshCw className={`w-3 h-3 text-amber-400 ${isTestingSupabase ? 'animate-spin' : ''}`} />
              <span>Probar Conexión</span>
            </button>
            <button
              onClick={handleRegenerarMiniaturas}
              disabled={regenerandoMiniaturas}
              className="px-2 py-1 bg-slate-800 hover:bg-slate-700 disabled:opacity-50 text-[10px] font-bold rounded-lg transition-all border border-slate-700 flex items-center gap-1 cursor-pointer"
              title="Generar la miniatura limpia (sin marca de agua) para fotos subidas antes de este cambio"
            >
              <Wand2 className={`w-3 h-3 text-amber-400 ${regenerandoMiniaturas ? 'animate-pulse' : ''}`} />
              <span>
                {regenerandoMiniaturas
                  ? `Regenerando miniaturas... (${progresoMiniaturas?.procesadas || 0} listas, ${progresoMiniaturas?.restantes ?? '…'} restantes)`
                  : 'Regenerar Miniaturas'}
              </span>
            </button>
            <button
              onClick={handleRegenerarMarcaAgua}
              disabled={regenerandoMarcaAgua}
              className="px-2 py-1 bg-slate-800 hover:bg-slate-700 disabled:opacity-50 text-[10px] font-bold rounded-lg transition-all border border-slate-700 flex items-center gap-1 cursor-pointer"
              title="Rehacer la vista ampliada de las fotos ya subidas según el interruptor «Muestras con lupa» de cada colegio"
            >
              <Sparkles className={`w-3 h-3 text-amber-400 ${regenerandoMarcaAgua ? 'animate-pulse' : ''}`} />
              <span>
                {regenerandoMarcaAgua
                  ? `Actualizando muestras... (${progresoMarcaAgua?.procesadas || 0} listas, ${progresoMarcaAgua?.restantes ?? '…'} restantes)`
                  : 'Actualizar Muestras'}
              </span>
            </button>
            <button
              onClick={handleLimpiarHuerfanos}
              // Auditoría 03/10 (crítico 5): no se limpia mientras se sube un lote (borraría lo recién subido).
              disabled={limpiandoHuerfanos || isUploading || fotosLote.some(f => f.estado === 'subida')}
              className="px-2 py-1 bg-slate-800 hover:bg-slate-700 disabled:opacity-50 text-[10px] font-bold rounded-lg transition-all border border-slate-700 flex items-center gap-1 cursor-pointer"
              title="Borrar del almacenamiento las fotos que ya no están en el catálogo y los .zip de pedidos no cobrados (primero muestra cuántos hay)"
            >
              <Trash2 className="w-3 h-3 text-rose-400" />
              <span>{limpiandoHuerfanos ? 'Revisando…' : 'Limpiar Archivos Huérfanos'}</span>
            </button>
          </div>
        </div>

        {/* Expandable SQL RLS Helper */}
        {mostrarSqlHelper && (
          <div className="mt-2.5 bg-amber-950/40 border border-amber-500/40 p-4 rounded-xl space-y-3">
            <div className="flex items-start justify-between gap-2">
              <div>
                <h5 className="text-xs font-bold text-amber-300 flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-amber-400" />
                  <span>Configurar Permisos RLS en Supabase (Solo 1 Vez)</span>
                </h5>
                <p className="text-[11px] text-amber-200/90 mt-1">
                  Si Supabase bloquea las subidas por política de seguridad (RLS), copiá este script y pegalo en el <strong>SQL Editor</strong> de tu panel de Supabase:
                </p>
              </div>
              <button
                type="button"
                onClick={handleCopiarSql}
                className="px-3 py-1.5 bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold text-xs rounded-lg flex items-center gap-1.5 shrink-0 cursor-pointer shadow"
              >
                {sqlCopiado ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{sqlCopiado ? '¡Copiado!' : 'Copiar SQL'}</span>
              </button>
            </div>

            <pre className="p-3 bg-slate-950/80 rounded-lg text-[10px] font-mono text-slate-300 overflow-x-auto max-h-36 border border-slate-800">
              {sqlPoliticas}
            </pre>
          </div>
        )}
      </div>

      {/* Course & Batch Selection Controls */}
      <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-xs space-y-4">
        <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider flex items-center gap-2">
          <Camera className="w-4 h-4 text-amber-600" />
          <span>Carga Masiva de Fotos por Curso / Sesión</span>
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-3 lg:grid-cols-6 gap-4">
          <div className="space-y-1">
            <label className="text-xs font-bold text-slate-700">Colegio</label>
            <select
              value={colegioSeleccionado} disabled={colaPendiente} title={avisoCola}
              onChange={(e) => setColegioSeleccionado(e.target.value)}
              className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs bg-slate-50 font-medium"
            >
              {colegios.map(c => (
                <option key={c.id} value={c.id}>{c.nombre}</option>
              ))}
            </select>
          </div>

          <div className="space-y-1">
            <label className="text-xs font-bold text-slate-700">Grado / Sala</label>
            <select
              value={gradoSeleccionado} disabled={colaPendiente} title={avisoCola}
              onChange={(e) => setGradoSeleccionado(e.target.value)}
              className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs bg-slate-50 font-bold"
            >
              {gradosDisponibles.map(g => (
                <option key={g} value={g}>{g}</option>
              ))}
            </select>
          </div>

          <div className="space-y-1">
            <label className="text-xs font-bold text-slate-700">Turno</label>
            <select
              value={turnoSeleccionado} disabled={colaPendiente} title={avisoCola}
              onChange={(e) => setTurnoSeleccionado(e.target.value)}
              className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs bg-slate-50 font-bold"
            >
              {turnosDisponibles.map(t => (
                <option key={t} value={t}>{t}</option>
              ))}
            </select>
          </div>

          <div className="space-y-1">
            <label className="text-xs font-bold text-slate-700">División</label>
            <select
              value={divisionSeleccionada} disabled={colaPendiente} title={avisoCola}
              onChange={(e) => setDivisionSeleccionada(e.target.value)}
              className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs bg-slate-50 font-bold"
            >
              {divisionesDisponibles.map(d => (
                <option key={d} value={d}>{d}</option>
              ))}
            </select>
          </div>

          <div className="space-y-1">
            <label className="text-xs font-bold text-slate-700">Categoría de la Toma</label>
            <select
              value={tipoFotoLote}
              onChange={(e) => setTipoFotoLote(e.target.value as any)}
              className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs bg-slate-50 font-medium"
            >
              <option value="individual">Retratos Individuales (15x21)</option>
              <option value="grupal">Foto Grupal del Curso (20x30)</option>
              <option value="docente">Foto con Docente / Seño (15x21)</option>
              {/* 06/10: en secundaria va en lugar de la del docente (3ª foto del kit). La ve todo el curso. */}
              <option value="familia">Foto con Familia y/o Amigos (15x21)</option>
              <option value="patio">Fotos Sueltas / Eventos (Digital HD)</option>
            </select>
          </div>

          <div className="space-y-1">
            <label className="text-xs font-bold text-slate-700">
              Asignar a Alumno <span className="font-normal text-slate-400">(opcional)</span>
            </label>
            <select
              value={alumnoSeleccionadoId}
              onChange={(e) => setAlumnoSeleccionadoId(e.target.value)}
              className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs bg-slate-50 font-medium truncate"
            >
              <option value="">-- Sin asignar / Múltiples --</option>
              {alumnosDelCurso.map(a => (
                <option key={a.id} value={a.id}>
                  {a.nombre}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Drag and Drop Zone */}
        <div className="relative border-2 border-dashed border-amber-300 hover:border-amber-400 bg-amber-50/50 hover:bg-amber-50/80 rounded-2xl p-8 text-center transition-all">
          <input
            type="file"
            multiple
            accept="image/*"
            disabled={isProcessing || isUploading}
            onChange={(e) => { const lista = Array.from(e.target.files || []); e.target.value = ''; handleFilesSelected(lista); }} // FOT-5
            className="absolute inset-0 w-full h-full opacity-0 cursor-pointer disabled:cursor-not-allowed"
          />
          <div className="space-y-2 pointer-events-none">
            <div className="w-12 h-12 rounded-full bg-amber-400 text-slate-950 flex items-center justify-center mx-auto shadow-md">
              <Upload className="w-6 h-6" />
            </div>
            <p className="text-sm font-extrabold text-slate-900">
              Arrastrá las fotos de {nombreSeccionActual} aquí o hacé clic para seleccionar
            </p>
            <p className="text-xs text-slate-500 max-w-xl mx-auto">
              Podés seleccionar 1, 20 o 50 fotos al mismo tiempo. El sistema aplicará la marca de agua fotográfica y las preparará para subirlas a Supabase Storage con código <strong className="text-amber-900 font-mono">{cursoSeleccionado}</strong>.
            </p>
          </div>
        </div>
      </div>

      {/* Cursos con fotos subidas — pedido de Pablo (22/9): "necesito un listado de los cursos
          que tiene sus fotos subidas, y un boton para eliminar las carpetas". Antes había que
          elegir cada grado/turno/división a mano arriba para saber si ya tenía fotos; esto trae
          TODAS las fotos del colegio elegido y las agrupa por curso, con conteo y un botón para
          borrar la carpeta completa (todas las fotos de ese curso) de una sola vez. */}
      <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-xs space-y-3">
        <div className="flex items-center justify-between gap-3">
          <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider flex items-center gap-2">
            <HardDrive className="w-4 h-4 text-amber-600" />
            <span>Cursos con Fotos Subidas — {colegioActualObj?.nombre || 'este colegio'}</span>
          </h3>
          <button
            type="button"
            onClick={recargarResumenCursos}
            disabled={cargandoResumenCursos}
            className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 disabled:opacity-50 text-[11px] font-bold text-slate-600 rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer"
          >
            <RefreshCw className={`w-3 h-3 ${cargandoResumenCursos ? 'animate-spin' : ''}`} />
            <span>Actualizar</span>
          </button>
        </div>
        <PublicarTodosCursos filas={resumenCursosConFotos} fotos={fotosColegioCompleto} colegioId={resumenCursosColegioId} deshabilitado={Boolean(publicando) || cargandoResumenCursos || resumenCursosColegioId !== colegioSeleccionado} alTerminar={async () => { await recargarFotosActivas(); await recargarResumenCursos(); }} />
        <PrepararLupa />

        {errorResumenCursos ? (
          <div role="alert" className="p-3 rounded-xl border border-red-300 bg-red-50 text-xs text-red-800 font-semibold space-y-1">
            <p className="flex items-center gap-1.5"><AlertTriangle className="w-3.5 h-3.5 shrink-0" /> {errorResumenCursos}</p>
            <p className="font-normal">Esto NO quiere decir que no haya fotos subidas: no las vuelvas a subir. Tocá "Actualizar" para reintentar.</p>
          </div>
        ) : cargandoResumenCursos && resumenCursosConFotos.length === 0 ? (
          <p className="text-xs text-slate-500">Buscando cursos con fotos...</p>
        ) : resumenCursosConFotos.length === 0 ? (
          <p className="text-xs text-slate-500">Todavía no hay fotos subidas para ningún curso de este colegio.</p>
        ) : (
          <div className="divide-y divide-slate-100 border border-slate-200 rounded-xl overflow-hidden">
            {resumenCursosConFotos.map((fila) => {
              const esActual = fila.grado === gradoSeleccionado && fila.turno === turnoSeleccionado && fila.division === divisionSeleccionada;
              return (
                <div
                  key={fila.clave}
                  className={`flex flex-wrap items-center justify-between gap-2 px-3 py-2 text-xs ${esActual ? 'bg-amber-50' : 'bg-white'}`}
                >
                  <button
                    type="button"
                    onClick={() => handleVerCursoDelResumen(fila)} disabled={colaPendiente}
                    className="flex-1 min-w-[160px] text-left cursor-pointer group disabled:cursor-not-allowed"
                    title={avisoCola || 'Ver este curso en el selector de arriba'}
                  >
                    <span className="font-extrabold text-slate-900 group-hover:text-amber-700 transition-colors">
                      {[fila.grado, fila.division, fila.turno].filter(Boolean).join(' · ') || fila.codigoCurso || '(sin datos de curso)'}
                    </span>
                    {esActual && (
                      <span className="ml-1.5 text-[9px] uppercase font-bold text-amber-700 bg-amber-100 px-1.5 py-0.5 rounded-full border border-amber-200">
                        viendo
                      </span>
                    )}
                  </button>
                  <span className="text-slate-500">
                    Total <strong className="text-slate-900">{fila.total}</strong>
                  </span>
                  <span className="text-slate-400 text-[11px]">
                    Ind. {fila.individual} · Grup. {fila.grupal} · Doc. {fila.docente}{fila.familia > 0 ? ` · Fam./Amigos ${fila.familia}` : ''} · Sueltas {fila.patio}
                  </span>
                  {fila.sinPublicar > 0 && (
                    <button
                      type="button"
                      onClick={() => {
                        const ids = fotosColegioCompleto
                          .filter(f => !f.publicada && (!f.colegioId || f.colegioId === resumenCursosColegioId) &&
                            (f.grado || '') === fila.grado && (f.turno || '') === fila.turno && (f.division || '') === fila.division)
                          .map(f => f.id);
                        void handlePublicar(ids, [fila.grado, fila.division, fila.turno].filter(Boolean).join(' · '), `curso:${fila.clave}`);
                      }}
                      disabled={Boolean(publicando) || cargandoResumenCursos || resumenCursosColegioId !== colegioSeleccionado}
                      className="px-2.5 py-1 bg-amber-400 hover:bg-amber-300 disabled:opacity-50 text-slate-950 font-extrabold rounded-lg border border-amber-500 transition-colors flex items-center gap-1.5 cursor-pointer shrink-0"
                      title="Las familias todavía no ven estas fotos"
                    >
                      {publicando === `curso:${fila.clave}` ? <RefreshCw className="w-3 h-3 animate-spin" /> : <Send className="w-3 h-3" />}
                      <span>Publicar ({fila.sinPublicar} sin publicar)</span>
                    </button>
                  )}
                  {fila.total > fila.sinPublicar && <ReenviarAvisoFotos colegioId={resumenCursosColegioId || ''} codigoCurso={fila.codigoCurso} nombreCurso={[fila.grado, fila.division, fila.turno].filter(Boolean).join(' · ')} />}
                  <button
                    type="button"
                    onClick={() => handleEliminarCarpetaCurso(fila)}
                    disabled={cursoEliminandoCarpeta === fila.clave || cargandoResumenCursos || resumenCursosColegioId !== colegioSeleccionado}
                    className="px-2.5 py-1 bg-rose-50 hover:bg-rose-100 disabled:opacity-50 text-rose-700 font-bold rounded-lg border border-rose-200 transition-colors flex items-center gap-1.5 cursor-pointer shrink-0"
                    title={`Eliminar toda la carpeta de ${[fila.grado, fila.division, fila.turno].filter(Boolean).join(' · ')}`}
                  >
                    {cursoEliminandoCarpeta === fila.clave ? (
                      <RefreshCw className="w-3 h-3 animate-spin" />
                    ) : (
                      <Trash2 className="w-3 h-3" />
                    )}
                    <span>Eliminar carpeta</span>
                  </button>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* STAGING QUEUE: Fotos seleccionadas pendientes de subir */}
      {fotosLote.length > 0 && (
        <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-xs space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-3">
            <div>
              <h4 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                <span>Fotos preparadas para subir ({fotosLote.length})</span>
                <span className="text-[11px] font-bold text-amber-800 bg-amber-100 px-2 py-0.5 rounded-full border border-amber-200">
                  {cursoSeleccionado}
                </span>
              </h4>
              <span className="text-[11px] text-slate-500">
                Verificá las muestras antes de sincronizarlas con Supabase Pro
              </span>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={handleVaciarCola}
                disabled={isUploading}
                className="px-3 py-1.5 text-xs text-slate-600 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 rounded-xl transition-colors cursor-pointer"
              >
                Vaciar lista
              </button>
              <button
                type="button"
                onClick={handleSubirASupabase}
                disabled={isUploading || isProcessing}
                className="px-4 py-2 bg-amber-500 hover:bg-amber-600 disabled:opacity-50 text-slate-950 text-xs font-extrabold rounded-xl transition-all shadow flex items-center gap-2 cursor-pointer"
              >
                {isUploading ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin text-slate-950" />
                    <span>Subiendo ({uploadProgress.actual}/{uploadProgress.total})...</span>
                  </>
                ) : (
                  <>
                    <HardDrive className="w-4 h-4" />
                    <span>Subir {fotosLote.length} foto(s) a Supabase</span>
                  </>
                )}
              </button>
              {isUploading && (
                <button
                  type="button"
                  onClick={handleCancelarSubida}
                  disabled={cancelandoSubida}
                  title="Termina la foto que se está subiendo ahora y detiene el resto — lo que ya se subió queda guardado"
                  className="px-3 py-2 bg-rose-100 hover:bg-rose-200 disabled:opacity-50 text-rose-700 text-xs font-bold rounded-xl transition-all flex items-center gap-1.5 cursor-pointer"
                >
                  <X className="w-3.5 h-3.5" />
                  <span>{cancelandoSubida ? 'Cancelando...' : 'Cancelar subida'}</span>
                </button>
              )}
            </div>
          </div>

          {fotosLote.length > MAX_TARJETAS_COLA && (
            <p className="text-[11px] text-slate-500">
              Se muestran las primeras {MAX_TARJETAS_COLA} de {fotosLote.length} fotos (las demás también se suben).
            </p>
          )}
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3">
            {fotosLote.slice(0, MAX_TARJETAS_COLA).map((foto) => (
              <div 
                key={foto.id}
                className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-2xs group relative"
              >
                <div className="relative aspect-4/3 bg-black overflow-hidden">
                  {foto.thumbUrl ? (
                    <img
                      src={foto.thumbUrl}
                      alt={foto.nombreOriginal}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center bg-slate-800 text-slate-400">
                      <ImageIcon className="w-6 h-6" />
                    </div>
                  )}
                  <span className="absolute top-1.5 left-1.5 px-1.5 py-0.5 rounded text-[9px] font-bold bg-slate-950/80 text-amber-300 uppercase">
                    {foto.tipo}
                  </span>

                  {!isUploading && (
                    <button
                      type="button"
                      onClick={() => handleEliminarFotoDeCola(foto.id)}
                      className="absolute top-1.5 right-1.5 p-1 rounded bg-rose-600/90 text-white opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer"
                      title="Quitar de la lista"
                    >
                      <Trash2 className="w-3 h-3" />
                    </button>
                  )}

                  {/* Upload State Overlay */}
                  {foto.estado === 'subiendo' && (
                    <div className="absolute inset-0 bg-slate-950/70 flex flex-col items-center justify-center text-amber-400 gap-1 text-[10px] font-bold">
                      <RefreshCw className="w-4 h-4 animate-spin" />
                      <span>Subiendo...</span>
                    </div>
                  )}

                  {foto.estado === 'subida' && (
                    <div className="absolute top-1.5 right-1.5 p-1 rounded-full bg-emerald-500 text-slate-950 shadow">
                      <Check className="w-3 h-3 stroke-[3]" />
                    </div>
                  )}

                  {foto.estado === 'subida' && foto.errorMensaje && (
                    <div className="absolute inset-x-0 bottom-0 bg-amber-500/90 p-1 text-center text-[9px] font-bold text-slate-950">
                      Falta registrar
                    </div>
                  )}

                  {foto.estado === 'error' && (
                    <div className="absolute inset-0 bg-rose-950/80 p-2 flex flex-col items-center justify-center text-rose-200 text-center text-[10px]">
                      <AlertCircle className="w-4 h-4 text-rose-400 mb-1" />
                      <span className="font-bold">Error al subir</span>
                      <span className="text-[9px] line-clamp-2 mt-0.5">{foto.errorMensaje}</span>
                    </div>
                  )}
                </div>

                <div className="p-2 text-[10px]">
                  <p className="font-semibold text-slate-800 truncate" title={foto.nombreOriginal}>
                    {foto.nombreOriginal}
                  </p>
                  {foto.alumnoNombre && (
                    <p className="text-amber-700 font-bold truncate">
                      👤 {foto.alumnoNombre}
                    </p>
                  )}
                  <div className="flex items-center justify-between text-slate-400 mt-0.5">
                    <span>{foto.estado === 'procesada' ? 'Marca al subir' : 'Marca lista'}</span>
                    <span className={`font-bold ${
                      foto.estado === 'subida' ? 'text-emerald-600' :
                      foto.estado === 'error' ? 'text-rose-600' :
                      foto.estado === 'subiendo' ? 'text-amber-600' : 'text-slate-500'
                    }`}>
                      {foto.estado === 'subida' ? '✓ En Supabase' :
                       foto.estado === 'error' ? '✗ Error' :
                       foto.estado === 'subiendo' ? '⏳ Subiendo' : 'Listo'}
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ACTIVE SUPABASE PHOTOS FOR CURRENT COURSE */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <div>
            <h4 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <ImageIcon className="w-4 h-4 text-amber-600" />
              <span>Fotos Activas en Supabase para {nombreSeccionActual} ({fotosActivasCurso.length})</span>
            </h4>
            <span className="text-[11px] text-slate-500">
              Las <strong>publicadas</strong> son las que ven las familias cuando ingresan el código <strong className="text-slate-900 font-mono">{cursoSeleccionado}</strong>. Las que subís quedan <strong>sin publicar</strong> hasta que toques «Publicar».
            </span>
          </div>

          <div className="flex flex-wrap items-center justify-end gap-2">
            {publicadasCurso > 0 && !modoSeleccionActivas && (
              <span className="text-xs font-semibold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-full border border-emerald-200 flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                <span>{publicadasCurso} publicadas (a la venta)</span>
              </span>
            )}
            {sinPublicarCurso.length > 0 && !modoSeleccionActivas && (
              <button
                type="button"
                onClick={() => void handlePublicar(sinPublicarCurso.map(f => f.id), nombreSeccionActual, 'actual')}
                disabled={Boolean(publicando)}
                className="px-3 py-1.5 text-xs font-extrabold text-slate-950 bg-amber-400 hover:bg-amber-300 disabled:opacity-50 rounded-xl border border-amber-500 shadow-sm transition-colors cursor-pointer flex items-center gap-1.5"
              >
                {publicando === 'actual' ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Send className="w-3.5 h-3.5" />}
                <span>Publicar {sinPublicarCurso.length} foto(s) sin publicar</span>
              </button>
            )}
            {fotosActivasCurso.length > 0 && (
              <button
                type="button"
                onClick={handleToggleModoSeleccion}
                className="px-3 py-1.5 text-xs font-bold text-slate-600 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 rounded-xl transition-colors cursor-pointer flex items-center gap-1.5"
              >
                {modoSeleccionActivas ? (
                  <>
                    <X className="w-3.5 h-3.5" />
                    <span>Cancelar selección</span>
                  </>
                ) : (
                  <>
                    <CheckSquare className="w-3.5 h-3.5" />
                    <span>Seleccionar varias</span>
                  </>
                )}
              </button>
            )}
          </div>
        </div>

        {fotosActivasCurso.length > 0 && (
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs">
            {([
              { id: 'todas' as const, label: 'Todas', cantidad: fotosActivasCurso.length },
              ...(sinPublicarCurso.length > 0 ? [{ id: 'sin_publicar' as const, label: 'Sin publicar', cantidad: sinPublicarCurso.length }] : []),
              { id: 'individual' as const, label: 'Individual', cantidad: conteoActivasPorCategoria.individual },
              { id: 'grupal' as const, label: 'Grupal', cantidad: conteoActivasPorCategoria.grupal },
              { id: 'docente' as const, label: 'Docente', cantidad: conteoActivasPorCategoria.docente },
              { id: 'familia' as const, label: 'Familia / Amigos', cantidad: conteoActivasPorCategoria.familia },
              { id: 'patio' as const, label: 'Sueltas / Eventos', cantidad: conteoActivasPorCategoria.patio },
            ]).map(op => (
              <button
                key={op.id}
                type="button"
                onClick={() => {
                  setFiltroCategoriaActivas(op.id);
                  setIdsSeleccionados(new Set());
                }}
                className={`px-2.5 py-1 rounded-lg text-[11px] font-bold whitespace-nowrap transition-colors cursor-pointer ${
                  filtroCategoriaActivas === op.id
                    ? 'bg-amber-400 text-slate-950'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                {op.label} ({op.cantidad})
              </button>
            ))}
          </div>
        )}

        {modoSeleccionActivas && (
          <div className="flex flex-wrap items-center gap-2 p-3 rounded-xl bg-amber-50 border border-amber-200">
            <span className="text-xs font-bold text-amber-900">
              {idsSeleccionados.size} seleccionada(s)
            </span>
            <button
              type="button"
              onClick={handleSeleccionarTodasActivas}
              className="px-2.5 py-1 text-[11px] font-bold text-amber-800 hover:text-amber-950 bg-white hover:bg-amber-100 border border-amber-300 rounded-lg transition-colors cursor-pointer"
            >
              Seleccionar todas las {filtroCategoriaActivas === 'todas' ? '' : `de "${filtroCategoriaActivas}"`} ({fotosActivasFiltradas.length})
            </button>
            {(() => {
              const idsSinPublicar = fotosActivasCurso.filter(f => idsSeleccionados.has(f.id) && !f.publicada).map(f => f.id);
              if (idsSinPublicar.length === 0) return null;
              return (
                <button
                  type="button"
                  onClick={() => void handlePublicar(idsSinPublicar, nombreSeccionActual, 'seleccion')}
                  disabled={Boolean(publicando) || borrandoSeleccionadas}
                  className="px-3 py-1.5 text-xs font-extrabold text-slate-950 bg-amber-400 hover:bg-amber-300 disabled:opacity-50 rounded-lg border border-amber-500 transition-colors cursor-pointer flex items-center gap-1.5"
                >
                  {publicando === 'seleccion' ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Send className="w-3.5 h-3.5" />}
                  <span>Publicar seleccionadas ({idsSinPublicar.length})</span>
                </button>
              );
            })()}
            <button
              type="button"
              onClick={handleEliminarSeleccionadas}
              disabled={idsSeleccionados.size === 0 || borrandoSeleccionadas}
              className="ml-auto px-3 py-1.5 text-xs font-extrabold text-white bg-rose-600 hover:bg-rose-700 disabled:opacity-50 rounded-lg transition-colors cursor-pointer flex items-center gap-1.5"
            >
              {borrandoSeleccionadas ? (
                <RefreshCw className="w-3.5 h-3.5 animate-spin" />
              ) : (
                <Trash2 className="w-3.5 h-3.5" />
              )}
              <span>Eliminar seleccionadas{idsSeleccionados.size > 0 ? ` (${idsSeleccionados.size})` : ''}</span>
            </button>
          </div>
        )}

        {errorFotosCurso ? (
          <div role="alert" className="p-4 rounded-2xl border border-red-300 bg-red-50 text-xs text-red-800 font-semibold space-y-1">
            <p className="flex items-center gap-1.5"><AlertTriangle className="w-4 h-4 shrink-0" /> {errorFotosCurso}</p>
            <p className="font-normal">No sabemos qué fotos hay en {nombreSeccionActual}: NO quiere decir que esté vacío, no las vuelvas a subir.</p>
            <button type="button" onClick={() => void recargarFotosActivas()} className="mt-1 inline-flex items-center gap-1 rounded-lg border border-red-300 bg-white px-2.5 py-1 font-bold text-red-700 hover:bg-red-100 cursor-pointer">
              <RefreshCw className="w-3 h-3" /> Reintentar
            </button>
          </div>
        ) : fotosActivasCurso.length === 0 ? (
          <div className="p-8 rounded-2xl bg-slate-50 border border-dashed border-slate-300 text-center space-y-2">
            <div className="w-10 h-10 rounded-full bg-slate-200 text-slate-500 flex items-center justify-center mx-auto">
              <Camera className="w-5 h-5" />
            </div>
            <p className="text-sm font-bold text-slate-700">
              No hay fotos cargadas aún para {nombreSeccionActual}
            </p>
            <p className="text-xs text-slate-500 max-w-md mx-auto">
              El almacenamiento está limpio y listo. Arrastrá las fotos del curso arriba para comenzar la carga a Supabase Pro.
            </p>
          </div>
        ) : fotosActivasFiltradas.length === 0 ? (
          <div className="p-8 rounded-2xl bg-slate-50 border border-dashed border-slate-300 text-center space-y-2">
            <div className="w-10 h-10 rounded-full bg-slate-200 text-slate-500 flex items-center justify-center mx-auto">
              <Camera className="w-5 h-5" />
            </div>
            <p className="text-sm font-bold text-slate-700">
              No hay fotos "{filtroCategoriaActivas}" en {nombreSeccionActual}
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3">
            {fotosActivasFiltradas.map((foto) => {
              const seleccionada = idsSeleccionados.has(foto.id);
              return (
              <div
                key={foto.id}
                onClick={() => modoSeleccionActivas && handleToggleSeleccionFoto(foto.id)}
                className={`bg-white rounded-xl border overflow-hidden shadow-2xs group relative ${
                  modoSeleccionActivas ? 'cursor-pointer' : ''
                } ${seleccionada ? 'border-amber-500 ring-2 ring-amber-400/40' : 'border-slate-200'}`}
              >
                <div className="relative aspect-4/3 bg-black overflow-hidden">
                  <img
                    src={foto.urlWeb}
                    alt={foto.alumnoNombre || foto.categoria}
                    className={`w-full h-full object-cover ${seleccionada ? 'opacity-80' : ''}`}
                  />
                  <span className="absolute top-1.5 left-1.5 px-1.5 py-0.5 rounded text-[9px] font-bold bg-slate-950/80 text-amber-300 uppercase">
                    {foto.categoria}
                  </span>
                  {!foto.publicada && (
                    <span className="absolute bottom-1.5 left-1.5 px-1.5 py-0.5 rounded text-[9px] font-extrabold bg-amber-400 text-slate-950 uppercase flex items-center gap-1">
                      <EyeOff className="w-3 h-3" /> Sin publicar
                    </span>
                  )}

                  {modoSeleccionActivas ? (
                    <div
                      className={`absolute top-1.5 right-1.5 p-0.5 rounded shadow ${
                        seleccionada ? 'bg-amber-500 text-slate-950' : 'bg-white/90 text-slate-500'
                      }`}
                    >
                      {seleccionada ? <CheckSquare className="w-4 h-4" /> : <Square className="w-4 h-4" />}
                    </div>
                  ) : (
                    <button
                      type="button"
                      onClick={() => handleEliminarFotoActiva(foto)}
                      className="absolute top-1.5 right-1.5 p-1 rounded bg-rose-600/90 text-white opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer"
                      title="Eliminar de Supabase"
                    >
                      <Trash2 className="w-3 h-3" />
                    </button>
                  )}
                </div>

                <div className="p-2 text-[10px]">
                  <p className="font-semibold text-slate-800 truncate uppercase" title={foto.categoria}>
                    {foto.categoria}
                  </p>
                  {foto.alumnoNombre && (
                    <p className="text-amber-700 font-bold truncate">
                      👤 {foto.alumnoNombre}
                    </p>
                  )}
                  <div className="flex items-center justify-between text-slate-400 mt-0.5 text-[9px]">
                    <span className="truncate">{foto.createdAt ? new Date(foto.createdAt).toLocaleDateString('es-AR') : ''}</span>
                    {foto.publicada ? (
                      <span className="text-emerald-600 font-bold">✓ Publicada</span>
                    ) : (
                      <span className="text-amber-700 font-bold">Sin publicar</span>
                    )}
                  </div>
                </div>
              </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
