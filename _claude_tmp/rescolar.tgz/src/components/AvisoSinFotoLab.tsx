import type { PedidoEscolarCompleto } from '../services/pedidosLabService';

const NOMBRES: Record<string, string> = { individual: 'individual', grupal: 'grupal', docente: '3ª foto' };

/**
 * 22/10/2026: en el panel de Laboratorio, aviso de que la familia marcó «Mi hijo/a no tiene esta foto» en
 * algún lugar del pack (en ese lugar va otra foto del curso o ninguna; ver src/utils/fotosFaltantes.ts).
 */
export default function AvisoSinFotoLab({ pedido }: { pedido: Pick<PedidoEscolarCompleto, 'fotosSeleccionadas'> }) {
  const lugares = pedido.fotosSeleccionadas?.sinFoto || [];
  if (lugares.length === 0) return null;
  return (
    <span className="inline-block text-[11px] font-bold text-amber-900 bg-amber-100 border border-amber-300 px-2 py-0.5 rounded-full">
      La familia avisó que no tiene: {lugares.map((l) => NOMBRES[l] || l).join(', ')}
    </span>
  );
}
