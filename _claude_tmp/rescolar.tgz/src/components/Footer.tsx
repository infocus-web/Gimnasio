import { Camera, ShieldCheck, Mail, MapPin, Lock } from 'lucide-react';
import RetratoEscolarLogo from './RetratoEscolarLogo';
import { abrirLegal } from '../legal/aceptacion';
import { PROVEEDOR } from '../legal/textosLegales';
import { formatoPrecio, usePrecios } from '../services/preciosService';

interface FooterProps {
  onOpenFamilias: () => void;
  onScrollTo: (id: string) => void;
  onOpenAdmin?: () => void;
}

export default function Footer({ onOpenFamilias, onScrollTo, onOpenAdmin }: FooterProps) {
  const precios = usePrecios();
  return (
    <footer className="bg-slate-900 text-slate-400 text-xs border-t border-slate-800 pt-16 pb-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10 pb-12 border-b border-slate-800 text-left">
          {/* Brand Info */}
          <div className="space-y-4">
            <div className="text-white">
              <RetratoEscolarLogo variant="full" theme="dark" size="md" />
            </div>

            <p className="text-slate-400 leading-relaxed">
              Portal fotográfico escolar exclusivo para familias en <strong>retratoescolar.com.ar</strong>. Selección de tomas online, pago digital seguro y descarga inmediata de fotos en alta definición.
            </p>

            <div className="flex items-center gap-2 text-slate-300 font-medium">
              <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>Pagos seguros con Mercado Pago y transferencia</span>
            </div>
          </div>

          {/* Families Links */}
          <div className="space-y-3">
            <p className="text-xs font-bold text-white uppercase tracking-wider">
              Acceso Familias
            </p>
            <ul className="space-y-2">
              <li>
                <button
                  onClick={() => onOpenFamilias()}
                  className="hover:text-amber-400 transition-colors cursor-pointer font-bold text-amber-400"
                >
                  Ver Fotos de mi Hijo/a
                </button>
              </li>
              <li>
                <button
                  onClick={() => onScrollTo('proceso')}
                  className="hover:text-amber-400 transition-colors cursor-pointer"
                >
                  Cómo Funciona el Acceso
                </button>
              </li>
              <li>
                <button
                  onClick={() => onScrollTo('muestrario')}
                  className="hover:text-amber-400 transition-colors cursor-pointer"
                >
                  Kits y Formatos Disponibles
                </button>
              </li>
              <li>
                <button
                  onClick={() => onScrollTo('faq')}
                  className="hover:text-amber-400 transition-colors cursor-pointer"
                >
                  Preguntas Frecuentes
                </button>
              </li>
            </ul>
          </div>

          {/* Kits & Quality */}
          <div className="space-y-3">
            <p className="text-xs font-bold text-white uppercase tracking-wider">
              Formatos y Productos
            </p>
            <ul className="space-y-2 text-slate-400">
              <li>
                <span className="text-slate-300 font-medium">Kit Impreso + Digital ({formatoPrecio(precios.kitClasico)})</span>
                <p className="text-[11px] text-slate-500">20x30 + 15x21 + carpeta + HD de regalo</p>
              </li>
              <li>
                <span className="text-slate-300 font-medium">Solo Digital HD ({formatoPrecio(precios.kitDigital)})</span>
                <p className="text-[11px] text-slate-500">3 fotos en máxima resolución sin marcas</p>
              </li>
              <li>
                <span className="text-slate-300 font-medium">Copia extra de la carpeta ({formatoPrecio(precios.carpetaExtra)})</span>
                <p className="text-[11px] text-slate-500">Para abuelos o familiares, con el Kit Impreso</p>
              </li>
            </ul>
          </div>

          {/* Zones & Contact */}
          <div className="space-y-3">
            <p className="text-xs font-bold text-white uppercase tracking-wider">
              Atención y Contacto
            </p>
            <div className="space-y-2 text-slate-400">
              <p className="flex items-center gap-2">
                <MapPin className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                <span>{PROVEEDOR.domicilio}</span>
              </p>
              <a
                href="mailto:contacto@retratoescolar.com.ar"
                className="flex items-center gap-2 hover:text-sky-400 transition-colors"
              >
                <Mail className="w-3.5 h-3.5 text-sky-400 shrink-0" />
                <span className="truncate">contacto@retratoescolar.com.ar</span>
              </a>
            </div>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-slate-500">
          <div className="space-y-1 text-center sm:text-left">
            <p>© {new Date().getFullYear()} Infocus Producciones · Retrato Escolar. Todos los derechos reservados.</p>
            {/* Identificación del proveedor en el sitio (comercio electrónico, Res. 104/2005). */}
            <p className="text-[11px] text-slate-500">
              {PROVEEDOR.titular} · CUIT {PROVEEDOR.cuit} · {PROVEEDOR.domicilio} · {PROVEEDOR.email}
            </p>
          </div>
          <div className="flex flex-wrap items-center justify-center sm:justify-start gap-x-4 gap-y-2 text-[11px]">
            {/* Nombre exigido por la Disp. 954/2025: el link se tiene que llamar así. */}
            <button type="button" id="btn-arrepentimiento-footer" onClick={() => abrirLegal('arrepentimiento')} className="hover:text-amber-400 underline-offset-2 hover:underline">
              Botón de arrepentimiento
            </button>
            <span>·</span>
            <button type="button" onClick={() => abrirLegal('terminos')} className="hover:text-amber-400 underline-offset-2 hover:underline">Términos y Condiciones</button>
            <span>·</span>
            <button type="button" onClick={() => abrirLegal('privacidad')} className="hover:text-amber-400 underline-offset-2 hover:underline">Privacidad y Protección de Menores</button>
            <span>·</span>
            <button type="button" onClick={() => abrirLegal('licencia')} className="hover:text-amber-400 underline-offset-2 hover:underline">Licencia de uso de las fotos</button>
            <span>·</span>
            <a href="https://www.argentina.gob.ar/produccion/defensadelconsumidor" target="_blank" rel="noopener noreferrer" className="hover:text-amber-400 underline-offset-2 hover:underline">Defensa del Consumidor</a>
            {onOpenAdmin && (
              <>
                <span>·</span>
                <button
                  onClick={onOpenAdmin}
                  className="text-slate-400 hover:text-amber-400 flex items-center gap-1 cursor-pointer transition-colors"
                >
                  <Lock className="w-3 h-3" />
                  <span>Panel Fotógrafo</span>
                </button>
              </>
            )}
          </div>
        </div>
      </div>
    </footer>
  );
}
