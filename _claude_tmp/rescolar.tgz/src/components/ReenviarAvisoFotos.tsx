import { useState } from 'react';
import { Mail, RefreshCw } from 'lucide-react';
import { reenviarAvisoFotosAdmin } from '../services/fotosSubidasService';

// 14/10/2026 (auditoría): si el aviso «ya están tus fotos» falló al publicar, antes no había forma de volver
// a mandarlo. Este botón (en cada curso con fotos publicadas de «Cargar fotos») lo reenvía a todas las
// familias aprobadas del curso. Va aparte para no agrandar AdminLoteFotosTab.
export default function ReenviarAvisoFotos({ colegioId, codigoCurso, nombreCurso }: { colegioId: string; codigoCurso: string; nombreCurso: string }) {
  const [enviando, setEnviando] = useState(false);
  const [mensaje, setMensaje] = useState<{ ok: boolean; texto: string } | null>(null);
  if (!colegioId || !codigoCurso) return null;

  const reenviar = async () => {
    if (enviando) return;
    if (!window.confirm(`¿Reenviar el email «¡Las fotos ya están online!» a las familias aprobadas de ${nombreCurso}?\n\nLes llega sólo a las que todavía no lo recibieron.`)) return;
    setEnviando(true);
    setMensaje(null);
    const r = await reenviarAvisoFotosAdmin(colegioId, codigoCurso);
    setEnviando(false);
    if (!r.success) setMensaje({ ok: false, texto: r.error || 'No se pudo reenviar el aviso.' });
    else setMensaje({ ok: !r.warning, texto: r.warning || `Listo: se avisó a ${r.emailsEnviados} familia(s).` });
  };

  return (
    <span className="inline-flex items-center gap-1.5 shrink-0">
      <button
        type="button"
        onClick={() => void reenviar()}
        disabled={enviando}
        className="px-2.5 py-1 bg-sky-50 hover:bg-sky-100 disabled:opacity-50 text-sky-800 font-bold rounded-lg border border-sky-200 transition-colors flex items-center gap-1.5 cursor-pointer"
        title="Vuelve a mandar el email «ya están tus fotos» a las familias del curso"
      >
        {enviando ? <RefreshCw className="w-3 h-3 animate-spin" /> : <Mail className="w-3 h-3" />}
        <span>Reenviar aviso a las familias</span>
      </button>
      {mensaje && (
        <span role="status" className={`text-[11px] font-semibold ${mensaje.ok ? 'text-emerald-700' : 'text-rose-700'}`}>{mensaje.texto}</span>
      )}
    </span>
  );
}
