import { AlertTriangle, HelpCircle, Lightbulb, ScanSearch, ShieldAlert } from 'lucide-react';
import type { AnalisisRespuestaIA } from '../services/consultasFamiliasService';

/**
 * 26/10/2026 (Pablo: «no me sirve una IA que responda tan mal y genéricamente»). Arriba del cuadro de respuesta:
 * qué entendió la IA que pide la familia, lo que se puede leer de dos formas, lo que tiene que decidir Pablo (con
 * opciones: tocar una la pone como «idea» para que la IA arme la respuesta con eso) y lo que el control automático
 * encontró sin respaldo en los datos. Ver servidor/familias/respuestaVerificada.ts.
 */
export function hayAnalisis(a: AnalisisRespuestaIA | null | undefined): a is AnalisisRespuestaIA {
  return Boolean(a && (a.entendido || a.ambiguedades?.length || a.decisiones?.length || a.alertas?.length || a.nota));
}

export default function AnalisisRespuestaIA({ analisis, onUsarOpcion }: { analisis: AnalisisRespuestaIA; onUsarOpcion?: (texto: string) => void }) {
  const ambiguedades = analisis.ambiguedades || [];
  const decisiones = analisis.decisiones || [];
  const alertas = analisis.alertas || [];
  return (
    <div className="space-y-2 rounded-xl border border-slate-200 bg-slate-50 p-3 text-left">
      {analisis.entendido && (
        <p className="flex items-start gap-1.5 text-xs text-slate-700">
          <ScanSearch className="mt-px h-3.5 w-3.5 shrink-0 text-slate-500" aria-hidden="true" />
          <span><strong>La IA entendió:</strong> {analisis.entendido}</span>
        </p>
      )}
      {ambiguedades.map((a, i) => (
        <p key={`a${i}`} className="flex items-start gap-1.5 text-xs text-amber-900">
          <HelpCircle className="mt-px h-3.5 w-3.5 shrink-0 text-amber-600" aria-hidden="true" />
          <span><strong>Puede leerse de otra forma:</strong> {a}</span>
        </p>
      ))}
      {decisiones.map((d, i) => (
        <div key={`d${i}`} className="rounded-lg border border-sky-200 bg-white p-2.5">
          <p className="flex items-start gap-1.5 text-xs font-bold text-sky-900">
            <Lightbulb className="mt-px h-3.5 w-3.5 shrink-0 text-sky-600" aria-hidden="true" />
            <span>Tenés que decidir: {d.pregunta}</span>
          </p>
          {d.opciones.length > 0 && (
            <div className="mt-1.5 flex flex-wrap gap-1.5">
              {d.opciones.map((o) => (
                <button
                  key={o}
                  type="button"
                  onClick={() => onUsarOpcion?.(o)}
                  disabled={!onUsarOpcion}
                  title="Usar esta opción como idea para la respuesta"
                  className="rounded-lg border border-sky-300 bg-sky-50 px-2.5 py-1 text-[11px] font-semibold text-sky-900 hover:bg-sky-100 cursor-pointer disabled:cursor-default"
                >
                  {o}
                </button>
              ))}
            </div>
          )}
        </div>
      ))}
      {alertas.length > 0 && (
        <div className="rounded-lg border border-red-200 bg-red-50 p-2.5">
          <p className="flex items-center gap-1.5 text-xs font-bold text-red-800">
            <ShieldAlert className="h-3.5 w-3.5 shrink-0" aria-hidden="true" /> El control encontró cosas sin respaldo en los datos
          </p>
          <ul className="mt-1 space-y-0.5">
            {alertas.map((a, i) => (
              <li key={i} className="text-[11px] text-red-900">
                {a.frase ? <>«{a.frase}» — </> : null}{a.motivo}
              </li>
            ))}
          </ul>
        </div>
      )}
      {analisis.nota && <p className="text-[11px] text-slate-500">{analisis.nota}</p>}
      {analisis.verificado === false && alertas.length === 0 && (
        <p className="flex items-center gap-1.5 text-[11px] text-amber-800">
          <AlertTriangle className="h-3.5 w-3.5 shrink-0" aria-hidden="true" /> Este borrador todavía no pasó el control automático: leelo con atención.
        </p>
      )}
    </div>
  );
}
