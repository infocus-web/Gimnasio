import React, { useState, useEffect, useMemo, useCallback, useRef } from 'react';
import { UserCheck, CheckCircle2, Clock, Search, Mail, Check, RefreshCw, Eye, MessageCircle, Copy, X, Users, XCircle, Loader2, School, Trash2 } from 'lucide-react';
import {
  InscripcionFamilia,
  obtenerInscripcionesAdmin,
  aprobarInscripcionAdmin,
  rechazarInscripcionAdmin,
  borrarDniTutorAdmin,
  eliminarInscripcionAdmin,
  generarEnlaceWhatsAppAprobacion,
  generarMensajeWhatsAppAprobacion,
  prepararEmailAprobacion,
  enviarEmailAprobacionAdmin,
  marcarWhatsAppEnviadoAdmin
} from '../services/inscripcionesService';
import { enviarCodigosEnSerie, resumenEnvioMasivo } from './inscriptosEnvioMasivo';
import { iniciarProceso } from '../utils/procesoEnCurso';
import { copiarAlPortapapeles } from '../utils/portapapeles';
import { nombresCompatibles } from '../utils/nombresAlumno';
import { fetchAdminAutenticado } from '../services/adminAuthService';
import AdminConsultaFotoHermanos from './AdminConsultaFotoHermanos';
import SumarHijoInscripcion from './SumarHijoInscripcion'; // 27/10: «Sumar hijo» (antes, SQL a mano)

/**
 * Contrato 10 (auditoría 03/10 noche): las filas de GET /api/admin/inscripciones traen
 * `acceso_confirmado_at` (null = la familia aprobada sola todavía no confirmó su email). El mapeo
 * de inscripcionesService (equipo portal) no lo expone, así que el panel lo lee aparte: id → fecha
 * o null. Si el servidor todavía no manda la columna, la fila no aparece en el mapa y no se muestra
 * ninguna etiqueta (para no marcar "sin confirmar" a todos por error).
 */
async function obtenerAccesosConfirmados(): Promise<Map<string, string | null> | null> {
  try {
    const res = await fetchAdminAutenticado('/api/admin/inscripciones');
    const data = await res.json().catch(() => null);
    if (!res.ok || !data?.success || !Array.isArray(data.inscripciones)) return null;
    const mapa = new Map<string, string | null>();
    for (const fila of data.inscripciones) {
      if (fila && typeof fila.id === 'string' && 'acceso_confirmado_at' in fila) mapa.set(fila.id, fila.acceso_confirmado_at || null);
    }
    return mapa;
  } catch {
    return null;
  }
}

async function marcarAccesoVerificadoAdmin(id: string): Promise<{ success: boolean; error?: string }> {
  try {
    const res = await fetchAdminAutenticado(`/api/admin/inscripciones/${encodeURIComponent(id)}/confirmar-acceso`, { method: 'POST' });
    const data = await res.json().catch(() => null);
    if (!res.ok || !data?.success) return { success: false, error: data?.error || 'No se pudo marcar como verificada.' };
    return { success: true };
  } catch (err: any) {
    return { success: false, error: err?.message || 'Error de red.' };
  }
}

interface AdminInscriptosTabProps {
  onProbarCodigo?: (codigo: string) => void;
}

// Código SUGERIDO para aprobar: se deriva del `id` interno de la inscripción (UUID que el público nunca ve), no de
// grado/turno/división (era adivinable). Es estable en pantalla; el servidor decide el código final (reusa el de la
// sección si ya existe, o registra éste si es el primero).
function sugerirCodigoSeguro(semilla: string): string {
  let h1 = 0xdeadbeef ^ semilla.length;
  let h2 = 0x41c6ce57 ^ semilla.length;
  for (let i = 0; i < semilla.length; i++) {
    const ch = semilla.charCodeAt(i);
    h1 = Math.imul(h1 ^ ch, 2654435761);
    h2 = Math.imul(h2 ^ ch, 1597334677);
  }
  h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909);
  h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909);
  const crudo = ((h1 >>> 0).toString(36) + (h2 >>> 0).toString(36) + 'X7K9QPWM2R')
    .toUpperCase()
    .replace(/[^A-Z0-9]/g, '');
  const codigo = crudo.slice(0, 8).padEnd(8, 'X');
  return `${codigo.slice(0, 4)}-${codigo.slice(4, 8)}`;
}

export default function AdminInscriptosTab({ onProbarCodigo }: AdminInscriptosTabProps) {
  const [inscripciones, setInscripciones] = useState<InscripcionFamilia[]>([]);
  const [cargando, setCargando] = useState(true);
  const [filtroEstado, setFiltroEstado] = useState<'todos' | 'pendiente' | 'aceptado'>('todos');
  const [searchQuery, setSearchQuery] = useState('');
  const [procesandoId, setProcesandoId] = useState<string | null>(null);
  const [toastNotificacion, setToastNotificacion] = useState<{
    titulo: string;
    mensaje: string;
    tipo: 'success' | 'info' | 'error';
  } | null>(null);

  // Modal for previewing sent email / whatsapp dispatch
  const [detalleEnvioModal, setDetalleEnvioModal] = useState<{
    familia: InscripcionFamilia;
    codigo: string;
    emailData: ReturnType<typeof prepararEmailAprobacion>;
    whatsappMsg: string;
    whatsappUrl: string;
  } | null>(null);

  // Editable codes for pending items
  const [codigosEditables, setCodigosEditables] = useState<Record<string, string>>({});

  // Real state of the email send (Resend) for whichever family is shown in detalleEnvioModal
  const [envioEmail, setEnvioEmail] = useState<{ enviando: boolean; enviado: boolean; error: string | null }>({
    enviando: false,
    enviado: false,
    error: null
  });

  // Contrato 10: id → acceso_confirmado_at. Se lee al entrar y con "Actualizar" (no en cada acción,
  // para no traer la lista entera dos veces).
  const [accesosConfirmados, setAccesosConfirmados] = useState<Map<string, string | null>>(new Map());
  const [verificandoId, setVerificandoId] = useState<string | null>(null);

  const cargarInscripciones = useCallback(async (mostrarSpinner = false) => {
    if (mostrarSpinner) setCargando(true);
    const [datos, accesos] = await Promise.all([
      obtenerInscripcionesAdmin(),
      mostrarSpinner ? obtenerAccesosConfirmados() : Promise.resolve(null),
    ]);
    setInscripciones(datos);
    if (accesos) setAccesosConfirmados(accesos);
    if (mostrarSpinner) setCargando(false);
  }, []);

  const emailSinConfirmar = (item: InscripcionFamilia) =>
    item.estado === 'aceptado' && accesosConfirmados.has(item.id) && !accesosConfirmados.get(item.id);

  const handleMarcarVerificada = async (item: InscripcionFamilia) => {
    if (!window.confirm(`¿Marcar como verificado el email de ${item.padreNombre || 'esta familia'} (${item.email})?\n\nHacelo sólo si confirmaste por otro medio que el email es de la familia.`)) return;
    setVerificandoId(item.id);
    const r = await marcarAccesoVerificadoAdmin(item.id);
    setVerificandoId(null);
    if (r.success) {
      setAccesosConfirmados((actual) => new Map(actual).set(item.id, new Date().toISOString()));
      setToastNotificacion({ titulo: 'Email verificado', mensaje: `${item.email} quedó marcado como verificado.`, tipo: 'success' });
    } else {
      setToastNotificacion({ titulo: 'No se pudo verificar', mensaje: r.error || 'Probá de nuevo.', tipo: 'error' });
    }
  };

  useEffect(() => {
    cargarInscripciones(true);
  }, [cargarInscripciones]);

  const totalInscriptos = inscripciones.length;
  const pendientes = useMemo(() => inscripciones.filter((i) => i.estado === 'pendiente'), [inscripciones]);
  const aceptados = useMemo(() => inscripciones.filter((i) => i.estado === 'aceptado'), [inscripciones]);
  // Familias ya aprobadas a las que nunca se les mandó el email con su código (23/09; ver handleEnviarTodosLosEmailsPendientes).
  const emailsPendientes = useMemo(
    () => aceptados.filter((i) => !i.notificacionEmailEnviada),
    [aceptados]
  );
  // Progreso del envío masivo de emails: se muestra en vivo en el botón ("Enviando 5/47...")
  // porque mandar decenas de emails uno por uno con pausa entre cada uno puede tardar varios
  // minutos, y sin esto Pablo no tendría forma de saber si sigue en marcha o se colgó.
  const [progresoEnvioMasivo, setProgresoEnvioMasivo] = useState<{ hechos: number; total: number } | null>(null);
  const envioMasivoActivo = useRef(false);
  const montado = useRef(true);
  useEffect(() => { montado.current = true; return () => { montado.current = false; }; }, []);

  // Filtered list
  const inscripcionesFiltradas = useMemo(() => {
    return inscripciones.filter((item) => {
      const matchEstado =
        filtroEstado === 'todos' || item.estado === filtroEstado;

      if (!matchEstado) return false;

      if (!searchQuery.trim()) return true;
      const q = searchQuery.toLowerCase().trim();
      return (
        // 27/10 (Pablo: «Niza no aparece»): busca también en los hermanos y por «nombre apellido» juntos.
        [item, ...(item.hermanos || [])].some((h) => `${h.alumnoNombre || ''} ${h.alumnoApellido || ''}`.toLowerCase().includes(q)) ||
        item.padreNombre.toLowerCase().includes(q) ||
        item.email.toLowerCase().includes(q) ||
        item.telefonoWhatsApp.toLowerCase().includes(q) ||
        item.grado.toLowerCase().includes(q) ||
        item.division.toLowerCase().includes(q) ||
        item.colegioNombre.toLowerCase().includes(q) ||
        (item.codigoAsignado && item.codigoAsignado.toLowerCase().includes(q))
      );
    });
  }, [inscripciones, filtroEstado, searchQuery]);

  // Envía de verdad (vía Resend) el email con el código a la familia dada, y refleja el resultado real
  // 14/10: `reenviar` sólo desde el botón del modal cuando el email ya figuraba enviado (si no, no se repite).
  const handleEnviarEmail = async (id: string, reenviar = false) => {
    setEnvioEmail({ enviando: true, enviado: false, error: null });
    const resultado = await enviarEmailAprobacionAdmin(id, { reenviar });
    if (resultado.success) {
      setEnvioEmail({ enviando: false, enviado: true, error: null });
      await cargarInscripciones();
    } else {
      setEnvioEmail({ enviando: false, enviado: false, error: resultado.error || 'No se pudo enviar el email.' });
    }
  };

  // 14/10/2026: al abrir el chat de WhatsApp queda anotado (antes «WhatsApp: Pendiente» no cambiaba nunca).
  const anotarWhatsApp = async (id: string) => {
    if (await marcarWhatsAppEnviadoAdmin(id)) setInscripciones((actual) => actual.map((i) => (i.id === id ? { ...i, notificacionWhatsAppEnviada: true } : i)));
  };

  // Auditoría 2026-09-22 (pedido de Pablo: "en el momento de inscribirme para probar, me envio
  // un whatsapp, no deberia"): al aprobar, además de mostrar el modal "Aprobación & Código
  // Despachado" (que ya tiene su propio botón "Abrir Chat de WhatsApp con la Familia" para
  // mandarlo a mano), este handler TAMBIÉN abría un `window.open` directo al link de wa.me con
  // el mensaje ya cargado — una acción de más, sin que nadie la pidiera, apenas se tocaba
  // "Aceptar y Enviar". El default pasa a `false`: el WhatsApp se prepara y se puede mandar
  // desde el botón del modal, pero ya no se dispara solo.
  const handleAprobar = async (item: InscripcionFamilia, abrirWhatsAppAuto = false) => {
    const codigoElegido =
      codigosEditables[item.id] ||
      item.codigoAsignado ||
      sugerirCodigoSeguro(item.id);

    setProcesandoId(item.id);
    const resultado = await aprobarInscripcionAdmin(item.id, codigoElegido);
    setProcesandoId(null);

    if (!resultado.success || !resultado.familia || !resultado.codigo) {
      setToastNotificacion({
        titulo: 'No se pudo aprobar la inscripción',
        mensaje: resultado.error || 'Error desconocido al aprobar la inscripción.',
        tipo: 'error'
      });
      setTimeout(() => setToastNotificacion(null), 6000);
      return;
    }

    await cargarInscripciones();

    const emailData = prepararEmailAprobacion(resultado.familia, resultado.codigo);
    const whatsappMsg = generarMensajeWhatsAppAprobacion(resultado.familia, resultado.codigo);
    const whatsappUrl = generarEnlaceWhatsAppAprobacion(resultado.familia, resultado.codigo);

    // Show modal preview
    setDetalleEnvioModal({
      familia: resultado.familia,
      codigo: resultado.codigo,
      emailData,
      whatsappMsg,
      whatsappUrl
    });

    // Envío real del email por Resend (el WhatsApp lo despacha vos mismo desde el botón de abajo)
    void handleEnviarEmail(resultado.familia.id);

    setToastNotificacion({
      titulo: `¡Inscripción aprobada para ${item.alumnoNombre}!`,
      mensaje: `Código ${resultado.codigo} asignado. Enviando email a ${item.email} y listo para despachar por WhatsApp (+${item.telefonoWhatsApp}).`,
      tipo: 'success'
    });

    setTimeout(() => {
      setToastNotificacion(null);
    }, 6000);

    // If requested, open WhatsApp in a new window/tab
    if (abrirWhatsAppAuto) {
      try {
        window.open(whatsappUrl, '_blank', 'noopener,noreferrer');
      } catch (e) {
        console.log('Popup prevented, accessible from detail modal');
      }
    }
  };

  const handleRechazar = async (item: InscripcionFamilia) => {
    // Auditoría 2026-09-22: a diferencia de las demás acciones destructivas/irreversibles del
    // panel (borrar pedido, borrar colegio, ejecutar cierre de año, borrar foto, etc.), rechazar
    // una inscripción no pedía confirmación — un clic accidental rechazaba a la familia sin forma
    // de deshacerlo desde la UI. Se agrega el mismo guard window.confirm que usan esas acciones.
    const confirmado = window.confirm(
      `¿Rechazar la inscripción de ${item.alumnoNombre} ${item.alumnoApellido}? Esta acción no se puede deshacer desde acá.`
    );
    if (!confirmado) return;

    setProcesandoId(item.id);
    const resultado = await rechazarInscripcionAdmin(item.id);
    setProcesandoId(null);

    if (!resultado.success) {
      if (resultado.conflicto) await cargarInscripciones(); // 14/10: ya no estaba pendiente (lista vieja)
      setToastNotificacion({
        titulo: 'No se pudo rechazar la inscripción',
        mensaje: resultado.error || 'Error desconocido al rechazar la inscripción.',
        tipo: 'error'
      });
      setTimeout(() => setToastNotificacion(null), 6000);
      return;
    }

    await cargarInscripciones();
    setToastNotificacion({
      titulo: 'Inscripción rechazada',
      mensaje: `Se marcó como rechazada la inscripción de ${item.alumnoNombre} ${item.alumnoApellido}.`,
      tipo: 'info'
    });
    setTimeout(() => setToastNotificacion(null), 5000);
  };

  // Auditoría 2026-09-22 (pedido de Pablo: "como hago para eliminar a un inscripto?"): antes no
  // había forma de sacar a nadie de este listado — "Rechazar" sólo existe para pendientes y sólo
  // cambia el estado, no borra la fila. Esto sí la borra por completo, para cualquier estado
  // (pendiente, rechazada o ya aprobada). No toca pedidos/fotos: eso vive en otras tablas.
  const handleEliminar = async (item: InscripcionFamilia) => {
    const confirmado = window.confirm(
      `¿Eliminar por completo la inscripción de ${item.alumnoNombre} ${item.alumnoApellido}? Esto la saca de este listado para siempre (no se puede deshacer). Si la familia ya usó su Código Familiar en el Portal, sus pedidos y fotos NO se borran — sólo desaparece esta ficha de inscripción.`
    );
    if (!confirmado) return;

    setProcesandoId(item.id);
    const resultado = await eliminarInscripcionAdmin(item.id);
    setProcesandoId(null);

    if (!resultado.success) {
      setToastNotificacion({
        titulo: 'No se pudo eliminar la inscripción',
        mensaje: resultado.error || 'Error desconocido al eliminar la inscripción.',
        tipo: 'error'
      });
      setTimeout(() => setToastNotificacion(null), 6000);
      return;
    }

    await cargarInscripciones();
    setToastNotificacion({
      titulo: 'Inscripción eliminada',
      mensaje: `Se eliminó del listado la inscripción de ${item.alumnoNombre} ${item.alumnoApellido}.`,
      tipo: 'info'
    });
    setTimeout(() => setToastNotificacion(null), 5000);
  };

  const handleBorrarDni = async (item: InscripcionFamilia) => {
    const confirmado = window.confirm(
      `¿Borrar el DNI de ingreso de ${item.padreNombre}? Usalo si la familia avisa que no fue ella quien ingresó o si cargó mal el DNI. El próximo ingreso con nombre + DNI lo vuelve a registrar.`
    );
    if (!confirmado) return;
    setProcesandoId(item.id);
    const resultado = await borrarDniTutorAdmin(item.id);
    setProcesandoId(null);
    setToastNotificacion(
      resultado.success
        ? { titulo: 'DNI borrado', mensaje: 'La familia vuelve a ingresar con nombre y DNI.', tipo: 'info' }
        : { titulo: 'No se pudo borrar el DNI', mensaje: resultado.error || 'Error desconocido.', tipo: 'error' }
    );
    setTimeout(() => setToastNotificacion(null), 5000);
    if (resultado.success) await cargarInscripciones();
  };

  const handleAprobarTodosLosPendientes = async () => {
    if (pendientes.length === 0) return;
    // INS-2 (auditoría 11/10): se saltean las que el servidor retuvo por seguridad (el chico ya figura en otra
    // inscripción del colegio, o un hermano no está en el padrón): esas se revisan y aprueban de a una.
    // Revisión: todos los chicos de la familia contra todos los de las otras, con la regla del servidor (orden y 2º nombre).
    const chicos = (i: InscripcionFamilia) => [i, ...(i.hermanos || [])].map((h) => `${h.alumnoNombre || ''} ${h.alumnoApellido || ''}`);
    const yaInscripto = (it: InscripcionFamilia) => inscripciones.some((o) => o.id !== it.id && o.estado !== 'rechazado' && o.colegioId === it.colegioId &&
      chicos(o).some((a) => chicos(it).some((b) => nombresCompatibles(a, b))));
    const lista = pendientes.filter((it) => !yaInscripto(it) && !(it.hermanos || []).some((h: any) => h.verificadoEnPadron === false));
    const salteadas = pendientes.length - lista.length;
    const confirmado = window.confirm(
      `¿Aprobar ${lista.length} inscripciones pendientes y mandarle a cada familia el email con su código?\n\nRevisá antes que el curso (grado, turno y división) de cada una sea el correcto: el código que reciben es el de ese curso.${salteadas ? `\n\n${salteadas} quedan afuera para revisar de a una: el chico ya figura en otra inscripción o un hermano no está en el padrón.` : ''}`
    );
    if (!confirmado || lista.length === 0) return;
    setProcesandoId('__todos__');
    const finProceso = iniciarProceso('Aceptar todas las inscripciones'); // 14/10: avisa antes de cerrar la pestaña
    let aprobadas = 0;
    let emailsOk = 0;
    const fallidas: string[] = [];
    for (let i = 0; i < lista.length && montado.current; i++) {
      const item = lista[i];
      const codigoElegido =
        codigosEditables[item.id] || item.codigoAsignado || sugerirCodigoSeguro(item.id);
      const resultado = await aprobarInscripcionAdmin(item.id, codigoElegido);
      // 23/09: la aprobación masiva también manda el email con el código.
      if (resultado.success && resultado.familia) {
        aprobadas++;
        const envio = await enviarEmailAprobacionAdmin(resultado.familia.id);
        if (envio.success) emailsOk++;
        else fallidas.push(`${item.alumnoNombre} ${item.alumnoApellido} (aprobada, pero el email falló: ${envio.error || 'error desconocido'})`);
      } else {
        fallidas.push(`${item.alumnoNombre} ${item.alumnoApellido} (${resultado.error || 'no se pudo aprobar'})`);
      }
      if (i < lista.length - 1) await new Promise((resolve) => setTimeout(resolve, 600));
    }
    finProceso();
    if (!montado.current) return;
    setProcesandoId(null);
    await cargarInscripciones();
    setToastNotificacion(
      fallidas.length === 0
        ? {
            titulo: salteadas ? `Aprobadas ${aprobadas}; ${salteadas} quedan para revisar de a una` : '¡Todas las solicitudes fueron aprobadas!',
            mensaje: `Se aprobaron ${aprobadas} inscripciones y se mandó el email con el código a las ${emailsOk} familias.`,
            tipo: 'success'
          }
        : {
            titulo: 'Aprobación masiva terminada con errores',
            mensaje: `Aprobadas: ${aprobadas}. Emails enviados: ${emailsOk}. Con problemas: ${fallidas.join('; ')}`,
            tipo: 'error'
          }
    );
    setTimeout(() => setToastNotificacion(null), fallidas.length === 0 ? 5000 : 15000);
  };

  // Envía (o reintenta) el email con el código de acceso a TODAS las familias ya aprobadas que
  // todavía figuran con "Email: Pendiente" — reemplaza tener que abrir la ficha de cada una y
  // tocar "Enviar Email" a mano, que con muchas familias acumuladas es directamente inviable.
  const handleEnviarTodosLosEmailsPendientes = async () => {
    const lista = emailsPendientes;
    if (lista.length === 0 || envioMasivoActivo.current) return; // 14/10: nunca dos bucles a la vez

    const confirmado = window.confirm(
      `¿Enviar el email con el código de acceso a las ${lista.length} familias que todavía no lo recibieron?\n\nSe manda de a uno, con una pequeña pausa entre cada envío para no saturar el servicio de correo — con muchas familias puede tardar varios minutos. No cierres esta pestaña hasta que termine.`
    );
    if (!confirmado) return;

    envioMasivoActivo.current = true;
    setProgresoEnvioMasivo({ hechos: 0, total: lista.length });
    const resultado = await enviarCodigosEnSerie(lista, {
      seguir: () => montado.current, // 14/10: si se cierra la pestaña de Inscriptos, el bucle corta
      onProgreso: (hechos, total) => setProgresoEnvioMasivo({ hechos, total }),
    }).finally(() => { envioMasivoActivo.current = false; });
    if (resultado.cortado) return;
    setProgresoEnvioMasivo(null);
    await cargarInscripciones();
    const { fallidos } = resultado;
    setToastNotificacion(resumenEnvioMasivo(resultado, lista.length)); // 14/10: «ya figuraba enviado» aparte
    setTimeout(() => setToastNotificacion(null), fallidos.length === 0 ? 6000 : 12000);
  };

  return (
    <div className="space-y-2 text-slate-900">
      {/* Toast feedback banner */}
      {toastNotificacion && (
        <div
          className={`p-4 rounded-2xl border text-left flex items-start justify-between gap-3 shadow-md animate-in slide-in-from-top-2 duration-200 ${
            toastNotificacion.tipo === 'success'
              ? 'bg-emerald-50 border-emerald-300 text-emerald-950'
              : toastNotificacion.tipo === 'error'
              ? 'bg-red-50 border-red-300 text-red-950'
              : 'bg-amber-50 border-amber-300 text-amber-950'
          }`}
        >
          <div className="flex items-start gap-3">
            {toastNotificacion.tipo === 'error' ? (
              <XCircle className="w-5 h-5 text-red-600 shrink-0 mt-0.5" />
            ) : (
              <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
            )}
            <div>
              <p className="font-bold text-sm">{toastNotificacion.titulo}</p>
              <p className="text-xs opacity-90 mt-0.5">{toastNotificacion.mensaje}</p>
            </div>
          </div>
          <button
            onClick={() => setToastNotificacion(null)}
            className="text-slate-400 hover:text-slate-700 p-1 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Summary Metrics Cards: compactas, del mismo tamaño y estilo que el resto de tarjetas del panel */}
      {/* 28/9 (celular): las 3 métricas en una fila de tarjetas chicas en vez de 3 filas enteras. */}
      {/* 14/10/2026 (Pablo: el encabezado ocupaba 2/3 de la pantalla): se sacaron las 3 tarjetas de totales; los
          mismos números están en los botones Todos / Pendientes / Aprobados de abajo. */}
      {/* Consulta «foto de hermanos» (08/10): email a las familias que quedaron marcadas por defecto */}
      <AdminConsultaFotoHermanos />

      {/* Control Bar: Filters & Actions */}
      <div className="bg-slate-50 p-2 rounded-2xl border border-slate-200 flex flex-col md:flex-row md:items-center justify-between gap-2 text-left">
        {/* State Tabs */}
        <div className="grid grid-cols-3 sm:flex items-center gap-1 sm:gap-1.5 bg-white p-1 rounded-xl border border-slate-200 shadow-2xs">
          <button
            type="button"
            onClick={() => setFiltroEstado('todos')}
            className={`px-2 sm:px-3 py-1.5 rounded-lg text-xs font-bold whitespace-nowrap transition-all cursor-pointer ${
              filtroEstado === 'todos'
                ? 'bg-slate-900 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            Todos ({totalInscriptos})
          </button>
          <button
            type="button"
            onClick={() => setFiltroEstado('pendiente')}
            className={`px-2 sm:px-3 py-1.5 rounded-lg text-xs font-bold whitespace-nowrap transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
              filtroEstado === 'pendiente'
                ? 'bg-amber-500 text-slate-950 shadow-xs'
                : 'text-amber-800 hover:bg-amber-100/60'
            }`}
          >
            <Clock className="hidden sm:block w-3 h-3" />
            <span>Pendientes ({pendientes.length})</span>
          </button>
          <button
            type="button"
            onClick={() => setFiltroEstado('aceptado')}
            className={`px-2 sm:px-3 py-1.5 rounded-lg text-xs font-bold whitespace-nowrap transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
              filtroEstado === 'aceptado'
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'text-emerald-700 hover:bg-emerald-100/60'
            }`}
          >
            <CheckCircle2 className="hidden sm:block w-3 h-3" />
            <span>Aprobados ({aceptados.length})</span>
          </button>
        </div>

        {/* Search & Actions */}
        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => cargarInscripciones(true)}
            className="px-3 py-2 bg-white hover:bg-slate-100 text-slate-600 border border-slate-200 text-xs font-bold rounded-xl shadow-2xs transition-colors flex items-center gap-1.5 cursor-pointer"
            title="Actualizar lista"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${cargando ? 'animate-spin' : ''}`} />
            <span>Actualizar</span>
          </button>
          <div className="relative flex-1 min-w-0 sm:w-64">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-3" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Buscar alumno, tutor o curso"
              className="w-full pl-9 pr-3 py-2 text-xs bg-white border border-slate-300 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-amber-400"
            />
          </div>

          {pendientes.length > 0 && (
            <button
              type="button"
              onClick={handleAprobarTodosLosPendientes}
              disabled={procesandoId === '__todos__'}
              className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-60 text-white text-xs font-bold rounded-xl shadow-xs transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              {procesandoId === '__todos__' ? (
                <Loader2 className="w-3.5 h-3.5 animate-spin" />
              ) : (
                <Check className="w-3.5 h-3.5" />
              )}
              <span>Aceptar Todos ({pendientes.length})</span>
            </button>
          )}

          {/* Pedido 2026-09-23 de Pablo: mandar el email de a uno por familia era inviable con
              tantas acumuladas — este botón manda a TODAS las que figuran "Email: Pendiente" en
              una sola tanda (ver handleEnviarTodosLosEmailsPendientes). */}
          {emailsPendientes.length > 0 && (
            <button
              type="button"
              onClick={handleEnviarTodosLosEmailsPendientes}
              disabled={progresoEnvioMasivo !== null}
              className="px-3.5 py-2 bg-blue-600 hover:bg-blue-500 disabled:opacity-60 text-white text-xs font-bold rounded-xl shadow-xs transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              {progresoEnvioMasivo ? (
                <>
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  <span>Enviando {progresoEnvioMasivo.hechos}/{progresoEnvioMasivo.total}...</span>
                </>
              ) : (
                <>
                  <Mail className="w-3.5 h-3.5" />
                  <span>Enviar Emails Pendientes ({emailsPendientes.length})</span>
                </>
              )}
            </button>
          )}
        </div>
      </div>

      {/* Main Table / Ficha de Inscriptos */}
      <div className="overflow-x-auto rounded-2xl border border-slate-200 bg-white shadow-2xs text-left">
        <table className="w-full text-xs">
          <thead className="bg-slate-50 text-slate-500 uppercase font-semibold border-b border-slate-200 text-[10px] tracking-wider">
            <tr>
              <th className="py-3 px-4">Estado & Aprobación</th>
              <th className="py-3 px-4">Alumno & Curso</th>
              <th className="py-3 px-4">Tutor / Contacto</th>
              <th className="py-3 px-4">Código de Acceso</th>
              <th className="py-3 px-4">Envíos (WhatsApp / Email)</th>
              <th className="py-3 px-4 text-right">Acciones</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {cargando ? (
              <tr>
                <td colSpan={6} className="py-12 text-center text-slate-400">
                  <Loader2 className="w-6 h-6 mx-auto animate-spin mb-2" />
                  <p className="text-xs">Cargando inscripciones...</p>
                </td>
              </tr>
            ) : inscripcionesFiltradas.length === 0 ? (
              <tr>
                <td colSpan={6} className="py-12 text-center text-slate-400 space-y-2">
                  <UserCheck className="w-8 h-8 mx-auto text-slate-300" />
                  <p className="text-sm font-semibold text-slate-600">
                    No se encontraron inscripciones con el criterio seleccionado.
                  </p>
                  <p className="text-xs text-slate-400">
                    Las inscripciones solicitadas por familias desde el portal aparecerán aquí para su validación.
                  </p>
                </td>
              </tr>
            ) : (
              inscripcionesFiltradas.map((item) => {
                const esPendiente = item.estado === 'pendiente';
                const esRechazado = item.estado === 'rechazado';
                const codigoSugerido =
                  codigosEditables[item.id] ||
                  item.codigoAsignado ||
                  sugerirCodigoSeguro(item.id);
                const procesando = procesandoId === item.id;

                return (
                  <tr
                    key={item.id}
                    className={`transition-colors ${
                      esPendiente ? 'bg-amber-50/30 hover:bg-amber-50/60' : 'hover:bg-slate-50/70'
                    }`}
                  >
                    {/* Status & Check Action */}
                    <td className="py-3.5 px-4 align-top">
                      <div className="space-y-1.5">
                        {esPendiente ? (
                          <div className="space-y-2">
                            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-extrabold bg-amber-100 text-amber-900 border border-amber-300">
                              <Clock className="w-3 h-3 text-amber-600 animate-pulse" />
                              <span>Pendiente</span>
                            </span>
                            <button
                              type="button"
                              onClick={() => handleAprobar(item)}
                              disabled={procesando}
                              className="w-full px-3 py-2 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-60 text-white font-extrabold text-[11px] rounded-xl shadow-xs transition-all flex items-center justify-center gap-1.5 cursor-pointer active:scale-98"
                              title="Aprobar y despachar código de acceso por Email"
                            >
                              {procesando ? (
                                <Loader2 className="w-3.5 h-3.5 animate-spin" />
                              ) : (
                                <Check className="w-3.5 h-3.5 stroke-[3]" />
                              )}
                              <span>Aceptar y Enviar</span>
                            </button>
                            <button
                              type="button"
                              onClick={() => handleRechazar(item)}
                              disabled={procesando}
                              className="w-full px-3 py-1.5 bg-white hover:bg-red-50 disabled:opacity-60 text-red-600 border border-red-200 font-bold text-[11px] rounded-xl transition-all flex items-center justify-center gap-1.5 cursor-pointer"
                            >
                              <XCircle className="w-3.5 h-3.5" />
                              <span>Rechazar</span>
                            </button>
                          </div>
                        ) : esRechazado ? (
                          <div className="space-y-1">
                            <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-extrabold bg-red-100 text-red-900 border border-red-200">
                              <XCircle className="w-3 h-3 text-red-600" />
                              <span>Rechazado</span>
                            </span>
                          </div>
                        ) : (
                          <div className="space-y-1">
                            <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-extrabold bg-emerald-100 text-emerald-900 border border-emerald-200">
                              <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                              <span>Aprobado</span>
                            </span>
                            {/* Contrato 10 (auditoría 03/10 noche): aprobada sola y sin confirmar el email. */}
                            {emailSinConfirmar(item) && (
                              <div className="space-y-1">
                                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-extrabold bg-amber-100 text-amber-900 border border-amber-300" title="La familia todavía no tocó el link de confirmación del email del código">
                                  Email sin confirmar
                                </span>
                                <button
                                  type="button"
                                  onClick={() => void handleMarcarVerificada(item)}
                                  disabled={verificandoId === item.id}
                                  className="block text-[10px] font-bold text-sky-700 hover:text-sky-900 underline cursor-pointer disabled:opacity-60"
                                >
                                  {verificandoId === item.id ? 'Marcando…' : 'Marcar como verificada'}
                                </button>
                              </div>
                            )}
                            <p className="text-[10px] text-slate-400">
                              {item.fechaAprobacion || item.fechaInscripcion}
                            </p>
                            {item.padreDni && (
                              <button
                                type="button"
                                onClick={() => handleBorrarDni(item)}
                                disabled={procesando}
                                className="text-[10px] text-slate-500 hover:text-red-600 underline cursor-pointer disabled:opacity-60"
                                title="Borra el DNI registrado en el primer ingreso"
                              >
                                DNI de ingreso: …{item.padreDni.slice(-3)} · borrar
                              </button>
                            )}
                          </div>
                        )}
                        <span className="text-[10px] font-mono text-slate-400 block">
                          ID: {item.id}
                        </span>
                      </div>
                    </td>

                    {/* Alumno & Curso (Con soporte de Hermanos) */}
                    <td className="py-3.5 px-4 align-top">
                      <div className="space-y-1.5">
                        <div className="flex items-center gap-1.5">
                          <h4 className="font-extrabold text-sm text-slate-900">
                            {item.alumnoNombre} {item.alumnoApellido}
                          </h4>
                          {item.hermanos && item.hermanos.length > 0 && (
                            <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-amber-100 text-amber-900 border border-amber-300">
                              +{item.hermanos.length} hermano{item.hermanos.length > 1 ? 's' : ''}
                            </span>
                          )}
                        </div>
                        <p className="text-xs text-slate-600 font-medium">
                          {item.grado} · Div. {item.division} · Turno {item.turno}
                        </p>
                        {item.alumnoDni && (
                          <p className="text-[10px] text-slate-500 font-mono">
                            DNI: {item.alumnoDni}
                          </p>
                        )}

                        {/* Listado de hermanos vinculados */}
                        {item.hermanos && item.hermanos.length > 0 && (
                          <div className="pt-1 space-y-1 border-t border-slate-200/80">
                            <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">
                              Hermanos en la Institución:
                            </span>
                            {item.hermanos.map((h, i) => (
                              <div key={h.id || i} className="text-[11px] text-slate-700 bg-slate-100 px-2 py-1 rounded-md">
                                <span className="font-bold text-slate-900">• {h.alumnoNombre} {h.alumnoApellido}</span>
                                <span className="text-slate-500 block text-[10px]">
                                  {h.grado} · Div. {h.division} · Turno {h.turno}
                                  {h.alumnoDni ? ` · DNI: ${h.alumnoDni}` : ''}
                                </span>
                              </div>
                            ))}
                          </div>
                        )}

                        {/* 08/10: hasta ese día la marca salía sola para toda familia con hermanos; se distingue
                            la confirmada (la familia la eligió) de la marcada por defecto. */}
                        {item.solicitaFotoHermanos && (
                          item.fotoHermanosConfirmadaAt ? (
                            <span className="inline-flex items-center gap-1 text-[10px] font-bold text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-300 mt-1">
                              📸 Foto de Hermanos solicitada · confirmada
                            </span>
                          ) : (
                            <span
                              className="inline-flex items-center gap-1 text-[10px] font-bold text-amber-800 bg-amber-50 px-2 py-0.5 rounded border border-amber-300 mt-1"
                              title="Quedó marcada por defecto (error de antes del 08/10): falta que la familia confirme"
                            >
                              📸 Foto de Hermanos · sin confirmar
                            </span>
                          )
                        )}
                        {!item.solicitaFotoHermanos && item.fotoHermanosConfirmadaAt && (item.hermanos?.length ?? 0) > 0 && (
                          <span className="inline-flex items-center gap-1 text-[10px] font-bold text-slate-600 bg-slate-50 px-2 py-0.5 rounded border border-slate-300 mt-1">
                            📸 No quieren foto de hermanos
                          </span>
                        )}

                        <p className="text-[11px] text-slate-400 flex items-center gap-1 mt-0.5">
                          <School className="w-3 h-3 text-slate-400" />
                          <span>{item.colegioNombre}</span>
                        </p>
                        <span className="text-[10px] text-slate-400 block mt-1">
                          Inscripto: {item.fechaInscripcion}
                        </span>
                      </div>
                    </td>

                    {/* Tutor & Contacts */}
                    <td className="py-3.5 px-4 align-top">
                      <div className="space-y-1">
                        <p className="font-bold text-slate-900">{item.padreNombre}</p>
                        <div className="flex items-center gap-1.5 text-slate-600 text-xs font-mono">
                          <MessageCircle className="w-3.5 h-3.5 text-[#25D366] shrink-0" />
                          <span>{item.telefonoWhatsApp}</span>
                        </div>
                        <div className="flex items-center gap-1.5 text-slate-600 text-xs">
                          <Mail className="w-3.5 h-3.5 text-blue-500 shrink-0" />
                          <span className="break-all">{item.email}</span>
                        </div>
                      </div>
                    </td>

                    {/* Access Code Assigned */}
                    <td className="py-3.5 px-4 align-top">
                      <div className="space-y-2">
                        {esPendiente ? (
                          <div className="space-y-1">
                            <span className="text-[10px] text-amber-800 font-semibold uppercase tracking-wider block">
                              Código a asignar:
                            </span>
                            <input
                              type="text"
                              value={codigoSugerido}
                              onChange={(e) =>
                                setCodigosEditables((prev) => ({
                                  ...prev,
                                  [item.id]: e.target.value.toUpperCase()
                                }))
                              }
                              className="px-2 py-1 text-xs font-mono font-bold uppercase tracking-wider bg-white border-2 border-amber-300 rounded-lg w-28 text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-amber-500"
                            />
                            <span className="text-[10px] text-slate-400 block">
                              Sugerido por sala
                            </span>
                          </div>
                        ) : (
                          <div className="space-y-1">
                            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-amber-400 text-slate-950 font-mono font-black text-xs shadow-2xs">
                              <Users className="w-3 h-3" />
                              <span>{item.codigoAsignado || item.codigoFamiliar || '—'}</span>
                            </span>
                            {onProbarCodigo && item.codigoAsignado && (
                              <button
                                type="button"
                                onClick={() => onProbarCodigo(item.codigoAsignado!)}
                                className="text-[10px] text-amber-700 hover:text-amber-900 hover:underline flex items-center gap-1 font-semibold cursor-pointer"
                              >
                                <Eye className="w-2.5 h-2.5" />
                                <span>Probar en Portal</span>
                              </button>
                            )}
                          </div>
                        )}
                      </div>
                    </td>

                    {/* Delivery channels state */}
                    <td className="py-3.5 px-4 align-top">
                      <div className="space-y-1.5">
                        <div className="flex items-center gap-1.5 text-xs">
                          <span
                            className={`w-2 h-2 rounded-full ${
                              item.notificacionWhatsAppEnviada ? 'bg-emerald-500' : 'bg-slate-300'
                            }`}
                          />
                          <span
                            className={`font-semibold ${
                              item.notificacionWhatsAppEnviada
                                ? 'text-emerald-800'
                                : 'text-slate-400'
                            }`}
                          >
                            WhatsApp:{' '}
                            {item.notificacionWhatsAppEnviada ? 'Enviado ✓' : 'Pendiente'}
                          </span>
                        </div>

                        <div className="flex items-center gap-1.5 text-xs">
                          <span
                            className={`w-2 h-2 rounded-full ${
                              item.notificacionEmailEnviada ? 'bg-blue-500' : 'bg-slate-300'
                            }`}
                          />
                          <span
                            className={`font-semibold ${
                              item.notificacionEmailEnviada ? 'text-blue-800' : 'text-slate-400'
                            }`}
                          >
                            Email:{' '}
                            {item.notificacionEmailEnviada ? 'Despachado ✓' : 'Pendiente'}
                          </span>
                        </div>
                      </div>
                    </td>

                    {/* Action Buttons */}
                    <td className="py-3.5 px-4 align-top text-right">
                      <div className="flex flex-col items-end gap-1.5">
                        {esPendiente ? null : !esRechazado ? (
                          <>
                            <a
                              href={item.codigoAsignado ? generarEnlaceWhatsAppAprobacion(item, item.codigoAsignado) : undefined} // INS-5: nunca un código inventado
                              onClick={() => void anotarWhatsApp(item.id)}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="px-2.5 py-1 bg-[#25D366]/15 hover:bg-[#25D366]/25 text-[#128C7E] font-bold text-[11px] rounded-lg transition-colors flex items-center gap-1 cursor-pointer"
                              title="Reenviar mensaje por WhatsApp"
                            >
                              <MessageCircle className="w-3 h-3 fill-current" />
                              <span>Reenviar WhatsApp</span>
                            </a>

                            <button
                              type="button"
                              onClick={() => {
                                const codigo = item.codigoAsignado || sugerirCodigoSeguro(item.id);
                                setEnvioEmail({ enviando: false, enviado: Boolean(item.notificacionEmailEnviada), error: null });
                                setDetalleEnvioModal({
                                  familia: item,
                                  codigo,
                                  emailData: prepararEmailAprobacion(item, codigo),
                                  whatsappMsg: generarMensajeWhatsAppAprobacion(item, codigo),
                                  whatsappUrl: generarEnlaceWhatsAppAprobacion(item, codigo)
                                });
                              }}
                              className="px-2.5 py-1 bg-blue-50 hover:bg-blue-100 text-blue-700 font-bold text-[11px] rounded-lg transition-colors flex items-center gap-1 cursor-pointer"
                            >
                              <Mail className="w-3 h-3" />
                              <span>{item.notificacionEmailEnviada ? 'Ver Email Enviado' : 'Enviar Email'}</span>
                            </button>
                          </>
                        ) : null}

                        {!esRechazado && <SumarHijoInscripcion inscripcion={item} onCambio={() => cargarInscripciones()} />}
                        {/* 22/09 (Pablo): «Eliminar» saca la ficha completa, en cualquier estado («Rechazar» es sólo para pendientes). */}
                        <button
                          type="button"
                          onClick={() => handleEliminar(item)}
                          disabled={procesandoId === item.id}
                          className="px-2.5 py-1 bg-white hover:bg-red-50 disabled:opacity-60 text-red-600 border border-red-200 font-bold text-[11px] rounded-lg transition-colors flex items-center gap-1 cursor-pointer"
                          title="Eliminar esta inscripción del listado (no borra pedidos ni fotos ya generados)"
                        >
                          {procesandoId === item.id ? (
                            <Loader2 className="w-3 h-3 animate-spin" />
                          ) : (
                            <Trash2 className="w-3 h-3" />
                          )}
                          <span>Eliminar</span>
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>

      {/* MODAL: Dispatch Details (WhatsApp & Email dispatched view) */}
      {detalleEnvioModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-xl w-full max-h-[90vh] overflow-y-auto p-6 space-y-5 shadow-2xl border border-slate-200 text-left animate-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <div className="w-9 h-9 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center">
                  <CheckCircle2 className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-slate-900 font-['Outfit']">
                    Aprobación & Código Despachado
                  </h3>
                  <p className="text-xs text-slate-500">
                    Familia de {detalleEnvioModal.familia.alumnoNombre}{' '}
                    {detalleEnvioModal.familia.alumnoApellido}
                  </p>
                </div>
              </div>
              <button
                onClick={() => setDetalleEnvioModal(null)}
                className="p-2 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-100"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Code Highlight */}
            <div className="p-4 bg-linear-to-r from-amber-500/10 via-amber-100/60 to-white rounded-xl border border-amber-300 flex items-center justify-between">
              <div>
                <span className="text-[10px] font-bold text-amber-900 uppercase tracking-wider block">
                  Código de Acceso Desbloqueado
                </span>
                <span className="text-2xl font-mono font-black text-slate-950 tracking-wider">
                  {detalleEnvioModal.codigo}
                </span>
                <span className="text-xs text-slate-600 block mt-0.5">
                  Asignado para {detalleEnvioModal.familia.grado} (
                  {detalleEnvioModal.familia.turno})
                </span>
              </div>
              <button
                type="button"
                onClick={() => {
                  void copiarAlPortapapeles(detalleEnvioModal.codigo);
                  setToastNotificacion({
                    titulo: 'Código copiado',
                    mensaje: `Código ${detalleEnvioModal.codigo} copiado al portapapeles.`,
                    tipo: 'info'
                  });
                }}
                className="px-3 py-1.5 bg-slate-900 hover:bg-slate-800 text-amber-300 text-xs font-bold rounded-lg flex items-center gap-1 cursor-pointer"
              >
                <Copy className="w-3.5 h-3.5" />
                <span>Copiar</span>
              </button>
            </div>

            {/* Canal 1: WhatsApp */}
            <div className="space-y-2 border border-slate-200 rounded-xl p-4 bg-slate-50/50">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
                  <MessageCircle className="w-4 h-4 text-[#25D366] fill-current" />
                  <span>Mensaje de WhatsApp ({detalleEnvioModal.familia.telefonoWhatsApp})</span>
                </span>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-100 text-emerald-800">
                  Listo para Enviar
                </span>
              </div>
              <div className="p-3 bg-white border border-slate-200 rounded-lg text-xs font-mono whitespace-pre-line text-slate-700 max-h-32 overflow-y-auto">
                {detalleEnvioModal.whatsappMsg}
              </div>
              <div className="flex justify-end gap-2 pt-1">
                <a
                  href={detalleEnvioModal.whatsappUrl}
                  onClick={() => void anotarWhatsApp(detalleEnvioModal.familia.id)}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-3.5 py-2 bg-[#25D366] hover:bg-[#20ba5a] text-white font-bold text-xs rounded-xl shadow-xs flex items-center gap-1.5 cursor-pointer"
                >
                  <MessageCircle className="w-3.5 h-3.5 fill-white" />
                  <span>Abrir Chat de WhatsApp con la Familia</span>
                </a>
              </div>
            </div>

            {/* Canal 2: Email */}
            <div className="space-y-2 border border-slate-200 rounded-xl p-4 bg-slate-50/50">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
                  <Mail className="w-4 h-4 text-blue-600" />
                  <span>Correo Electrónico ({detalleEnvioModal.familia.email})</span>
                </span>
                {envioEmail.enviando ? (
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-slate-200 text-slate-700 flex items-center gap-1">
                    <Loader2 className="w-3 h-3 animate-spin" />
                    Enviando...
                  </span>
                ) : envioEmail.enviado ? (
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-100 text-emerald-800">
                    Enviado ✓
                  </span>
                ) : envioEmail.error ? (
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-red-100 text-red-800">
                    No se pudo enviar
                  </span>
                ) : (
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-slate-200 text-slate-600">
                    No enviado
                  </span>
                )}
              </div>
              <div className="p-3 bg-white border border-slate-200 rounded-lg text-xs space-y-1">
                <p className="font-bold text-slate-800">
                  Asunto: {detalleEnvioModal.emailData.asunto}
                </p>
                <div className="pt-2 border-t border-slate-100 whitespace-pre-line text-slate-600 font-mono text-[11px] max-h-36 overflow-y-auto">
                  {detalleEnvioModal.emailData.contenido}
                </div>
              </div>
              {envioEmail.error && (
                <p className="text-[11px] text-red-700 font-semibold">{envioEmail.error}</p>
              )}
              <div className="flex justify-end pt-1">
                <button
                  type="button"
                  onClick={() => handleEnviarEmail(detalleEnvioModal.familia.id, envioEmail.enviado || Boolean(detalleEnvioModal.familia.notificacionEmailEnviada))}
                  disabled={envioEmail.enviando}
                  className="px-3.5 py-2 bg-blue-600 hover:bg-blue-500 disabled:opacity-60 text-white font-bold text-xs rounded-xl shadow-xs flex items-center gap-1.5 cursor-pointer"
                >
                  {envioEmail.enviando ? (
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  ) : (
                    <Mail className="w-3.5 h-3.5" />
                  )}
                  <span>{envioEmail.enviado ? 'Reenviar Email' : 'Enviar Email Ahora'}</span>
                </button>
              </div>
            </div>

            <div className="pt-2 flex justify-end">
              <button
                type="button"
                onClick={() => setDetalleEnvioModal(null)}
                className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs rounded-xl"
              >
                Cerrar Ventana
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
