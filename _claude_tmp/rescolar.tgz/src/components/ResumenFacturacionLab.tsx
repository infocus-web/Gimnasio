import { useCallback, useEffect, useRef, useState } from 'react';
import { FileSpreadsheet, Loader2, Receipt } from 'lucide-react';
import { descargarExcelResumen, obtenerResumenFacturacion, type ResumenFacturacion } from '../services/laboratorioService';

/**
 * Resumen de impresiones para facturar (27/9/2026). Lo usan el panel del laboratorio y el panel
 * del fotógrafo, así los dos ven los mismos números. Cuenta los lotes marcados "En producción"
 * dentro del mes elegido; los descargados sin marcar se muestran aparte. Se carga solo al abrir
 * y al cambiar de mes. `variante="lateral"` es la columna del panel del laboratorio.
 */
export default function ResumenFacturacionLab({
  fetcher,
  variante = 'horizontal',
  recargarCon,
}: {
  fetcher?: (url: string) => Promise<Response>;
  variante?: 'horizontal' | 'lateral';
  /** Cambia cuando el panel recarga datos (ej. después de marcar un lote), para refrescar el resumen. */
  recargarCon?: unknown;
}) {
  const hoy = new Date();
  const [mes, setMes] = useState(`${hoy.getFullYear()}-${String(hoy.getMonth() + 1).padStart(2, '0')}`);
  const [resumen, setResumen] = useState<ResumenFacturacion | null>(null);
  const [cargando, setCargando] = useState(false);
  const [error, setError] = useState('');
  // Auditoría 11/10 (ADM-10): sólo se muestra la respuesta de la última consulta (un mes viejo que llega tarde se descarta).
  const ultimaConsulta = useRef(0);

  const consultar = useCallback(
    async (m: string) => {
      if (!/^\d{4}-\d{2}$/.test(m)) return;
      const mia = ++ultimaConsulta.current;
      setCargando(true);
      setError('');
      try {
        const [a, mm] = m.split('-').map(Number);
        const ultimo = new Date(a, mm, 0).getDate();
        const r = await obtenerResumenFacturacion(`${m}-01`, `${m}-${String(ultimo).padStart(2, '0')}`, fetcher);
        if (mia === ultimaConsulta.current) setResumen(r);
      } catch (e) {
        if (mia === ultimaConsulta.current) setError(e instanceof Error ? e.message : 'No se pudo armar el resumen.');
      } finally {
        if (mia === ultimaConsulta.current) setCargando(false);
      }
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    []
  );

  useEffect(() => {
    void consultar(mes);
  }, [mes, consultar, recargarCon]);

  const t = resumen?.totales;
  const lateral = variante === 'lateral';
  const fechaCorta = (iso: string) => iso.split('-').reverse().join('/');
  const tarjetas: [string, number, string][] = t
    ? [
        ['Carpetas', t.carpetas, 'from-amber-400 to-amber-500 text-slate-950'],
        ['Fotos 20x30', t.fotos20x30, 'from-violet-500 to-violet-600 text-white'],
        ['Fotos 15x21', t.fotos15x21, 'from-sky-500 to-sky-600 text-white'],
        ['Pedidos', t.pedidos, 'from-slate-100 to-slate-200 text-slate-900'],
        ['Lotes', t.lotes, 'from-slate-100 to-slate-200 text-slate-900'],
      ]
    : [];

  return (
    <section className={`rounded-3xl border border-slate-200 bg-white p-5 shadow-sm ${lateral ? 'space-y-4' : ''}`}>
      <div className="flex flex-wrap items-center gap-2">
        <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-emerald-100">
          <Receipt className="h-4.5 w-4.5 text-emerald-700" />
        </div>
        <div className="mr-auto">
          <p className="font-['Outfit'] text-base font-extrabold text-slate-900">Resumen para facturar</p>
          <p className="text-[11px] text-slate-500">Lo que se marcó "En producción" en el mes</p>
        </div>
        <input
          type="month"
          aria-label="Mes"
          value={mes}
          onChange={(e) => setMes(e.target.value)}
          className="rounded-xl border border-slate-300 px-2.5 py-1.5 text-xs font-semibold"
        />
        {cargando && <Loader2 className="h-4 w-4 animate-spin text-slate-400" />}
      </div>
      {error && <p className="mt-2 text-xs font-semibold text-red-600">{error}</p>}
      {resumen && t && (
        <div className={lateral ? 'space-y-3' : 'mt-4 space-y-3'}>
          <div className={`grid gap-2 ${lateral ? 'grid-cols-2' : 'grid-cols-2 sm:grid-cols-5'}`}>
            {tarjetas.map(([k, v, color], i) => (
              <div key={k} className={`rounded-2xl bg-gradient-to-br px-3.5 py-3 ${color} ${lateral && i === 0 ? 'col-span-2' : ''}`}>
                <p className="text-[11px] font-bold uppercase tracking-wide opacity-80">{k}</p>
                <p className="font-['Outfit'] text-2xl font-black leading-tight">{v}</p>
              </div>
            ))}
          </div>
          <p className="text-xs text-slate-500">
            Del {fechaCorta(resumen.desde)} al {fechaCorta(resumen.hasta)}
            {t.sueltas > 0 && ` · de las fotos 15x21, ${t.sueltas} son fotos sueltas`}
            {resumen.lotes.length > 0 ? ` · Lotes: ${resumen.lotes.map((l) => `N° ${l.numero}`).join(', ')}.` : ' · Todavía no hay lotes en producción este mes.'}
          </p>
          {resumen.reimpresiones && resumen.reimpresiones.length > 0 && resumen.totalesReimpresiones && (
            <div className="rounded-2xl border border-slate-200 bg-slate-50 px-3.5 py-3 text-xs text-slate-700">
              <p className="font-bold">Reimpresiones del período</p>
              <p className="mt-0.5">
                Con cargo: {resumen.totalesReimpresiones.conCargo.fotos20x30} fotos 20x30 · {resumen.totalesReimpresiones.conCargo.fotos15x21} fotos 15x21
                ({resumen.totalesReimpresiones.conCargo.cantidad} reimpresión/es). Se suman aparte del total de los lotes.
              </p>
              <p className="mt-0.5 text-slate-500">
                Sin cargo (falla de impresión): {resumen.totalesReimpresiones.sinCargo.fotos20x30} fotos 20x30 · {resumen.totalesReimpresiones.sinCargo.fotos15x21} fotos 15x21.
              </p>
            </div>
          )}
          {resumen.pendientes.length > 0 && (
            <div className="rounded-2xl border border-amber-200 bg-amber-50 px-3.5 py-3 text-xs text-amber-900">
              <p className="font-bold">Pendientes de confirmar: {resumen.pendientes.map((l) => `Lote N° ${l.numero}`).join(', ')}</p>
              <p className="mt-0.5">
                {resumen.totalesPendientes.carpetas} carpetas · {resumen.totalesPendientes.fotos20x30} fotos 20x30 · {resumen.totalesPendientes.fotos15x21} fotos 15x21. Entran en el total cuando se marcan "En producción".
              </p>
            </div>
          )}
          <button
            type="button"
            onClick={() => void descargarExcelResumen(resumen)}
            className={`flex items-center justify-center gap-1.5 rounded-xl border border-slate-300 px-3 py-2 text-xs font-bold hover:bg-slate-50 ${lateral ? 'w-full' : ''}`}
          >
            <FileSpreadsheet className="h-3.5 w-3.5" /> Descargar resumen en Excel
          </button>
        </div>
      )}
    </section>
  );
}
