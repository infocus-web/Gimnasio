import { registrarContextoDeError, registrarFallaDePago } from '../services/reporteErrores';
import { useNaveHabilitado } from '../services/mediosPagoService';
import SubirComprobante from './SubirComprobante';
import TarjetaPedidoExistente from './TarjetaPedidoExistente';
import TarjetaFotoHermanos from './TarjetaFotoHermanos';
import AvisoPlazoTransferencia from './AvisoPlazoTransferencia';
import { montarLupa } from '../utils/lupaMuestra';
import { useState, useEffect, useRef, FormEvent, KeyboardEvent } from 'react';
import { ViewfinderFocusIcon } from './RetratoEscolarLogo';
import {
  X,
  Search,
  School,
  User,
  Sparkles,
  Check,
  CheckCircle2,
  Lock,
  Eye,
  CreditCard,
  Building2,
  ArrowRight,
  ArrowLeft,
  Download,
  Smartphone,
  ShieldCheck,
  Package,
  PackageCheck,
  Clock,
  Truck,
  Key,
  CheckCheck,
  AlertCircle,
  Mail,
  FolderCheck,
  Printer,
  Copy,
  Plus,
  Minus,
  RefreshCw,
  Send,
  Images,
  ShoppingCart,
  Loader2,
  UserPlus,
} from 'lucide-react';
import { KITS_DISPONIBLES } from '../data/colegiosData';
import { hayCursoDeSecundaria, kitsParaGrados, useSinSoloDigitalEnSecundaria } from '../utils/kitsSecundaria'; import { kitOfrecido, plazoKitImpresoAbierto } from '../utils/plazoKitImpreso'; import { usePlazosTemporada } from '../utils/plazosTemporada'; import AvisoPlazoKitImpreso from './AvisoPlazoKitImpreso'; // 26/10: Kit Impreso hasta el 15/11
import { cargarPreciosDelServidor, formatoPrecio, preciosVienenDelServidor, usePrecios } from '../services/preciosService';
import { sugerirCorreccionEmail } from '../utils/emailSugerencia';
import { volvioSinPagar } from '../utils/pagoRetorno';
import AceptacionTerminos from './legal/AceptacionTerminos';
import { AVISO_CONFIRMAR_FOTOS } from '../legal/textosLegales';
import { abrirLegal, marcarTerminosAceptados } from '../legal/aceptacion';
import { useColegiosLista } from '../services/colegiosService';
import {
  registrarPedidoDesdePortal,
  registrarCarritoMultipleDesdePortal,
  obtenerPedidosGuardados,
  guardarPedidosEnStorageDelPortal,
  cambiarMetodoPagoPedido,
  PedidoEscolarCompleto,
  buscarPedidoPorSeguimiento,
  reenviarLinkDescargaPorEmail,
  ErrorLimiteBusqueda,
  PedidoExistenteResumen,
  ItemCarritoHijo,
  CODIGO_KIT_YA_PAGADO,
  nuevoUuidPedido,
  nuevoNumeroPedido,
  borrarPedidosLocalesDelPortal,
  totalDelServidor,
} from '../services/pedidosLabService';
import { consultarPedidoExistente } from '../services/verificacionesCompraService';
import { esStatusTransitorio, fetchConTimeout } from '../utils/fetchConTimeout';
import { borrarCheckoutDeSesion, firmaDeCheckout, guardarCheckoutEnSesion, idsParaCheckout, leerCheckoutDeSesion, type IdsCheckout } from '../utils/checkoutEstable';
import { crearPreferenciaMercadoPago, crearPreferenciaMercadoPagoMultiple } from '../services/mercadoPagoService';
import { crearIntencionPagoNave, crearIntencionPagoNaveMultiple } from '../services/naveService';
import {
  obtenerFamiliaActiva,
  cerrarSesionFamilia,
  InscripcionFamilia,
  buscarMiInscripcion,
  guardarFamiliaActiva,
  determinarCodigoParaInscripcion,
  obtenerHijosDeFamiliaConEstado,
  confirmarAccesoInscripcion,
  textoEstadoInscripcion,
  HijoConCodigoSeccion
} from '../services/inscripcionesService';
import { enviarSolicitudCodigo } from '../services/solicitudesCodigoService';
import { obtenerGaleriaPublica } from '../services/fotosSubidasService';
import { crearReserva, elegirFotosDeReserva, KITS_RESERVA, obtenerEstadoReserva, type ReservaParaSumar, type ReservaPendiente } from '../services/reservasService';
import ReservaKitAnticipada from './ReservaKitAnticipada';
import { irAConsultasConDatos } from '../utils/consultaPrefill';
import { Colegio, KitProducto, Foto } from '../types';
import { borrarLlavesPedidos, urlEstadoPedido } from '../utils/accesoPedido';
import { montoDelPedido } from '../utils/montoPedido';
import { fotoVisibleParaAlumno, normalizarNombreAlumno } from '../utils/nombresAlumno';
import { esTerceraFoto, etiquetaTerceraFoto, pasoDelPack, textosTerceraFoto } from '../utils/terceraFoto';
import { categoriaValeEnLugar, idValidoEnLugar, lugarDeLaFoto, NOMBRE_LUGAR, textoFaltaEnElPack, type LugarPack } from '../utils/fotosFaltantes';
import AvisoSinFotoPack from './AvisoSinFotoPack'; import { AvisoHijoSinFotos, useHijosSinFotos } from './HijoSinFotos'; // 26/10: «No quiero las fotos de este hijo/a»
import BuscadorRostro from './BuscadorRostro';
import { useFaltantesSolicitadas } from './useFaltantesSolicitadas';
import CampoCodigoDescuento from './CampoCodigoDescuento';
import { descuentoDeKit, descuentoDelCarrito, type CodigoDescuentoAplicado } from '../services/descuentosService';

interface PortalFamiliasModalProps {
  isOpen: boolean;
  onClose: () => void;
  preselectedColegioId?: string;
  preselectedKitId?: string;
  preselectedCodigo?: string;
  onOpenInscripcion?: () => void;
  /** Abrir directo en la galería (p. ej. "Elegir otro medio de pago" de una reserva sin pagar). */
  abrirEnGaleria?: boolean;
}

/**
 * Carrito multi-hijo («un solo pedido, un solo pago», Pablo 16/09): al cambiar de hijo en el Paso 2 la
 * selección del hijo saliente se guarda con esta forma; en el Paso 4 se arman todos los pedidos guardados
 * más el del hijo activo y, si hay más de uno, se cobran juntos en un solo checkout.
 */
interface SeleccionCarritoHijo {
  hijoId: string;
  nombreCompleto: string;
  colegioNombre?: string;
  grado?: string;
  division?: string;
  turno?: string;
  codigoSeccion: string;
  kitId: string;
  kitNombre: string;
  extraCarpetas: number;
  fotoSeleccionadaIndividual: string;
  fotoSeleccionadaGrupal: string;
  fotoSeleccionadaDocente: string;
  fotosSueltasSeleccionadas: string[];
  sinFoto?: LugarPack[]; // 22/10: lugares que la familia marcó «no tiene esta foto» (utils/fotosFaltantes.ts)
  total: number;
  completo: boolean;
}

// Auditoría 16/09: Object.values() sobre el estado (tipado `any` acá) da `unknown[]`; este helper lo tipa.
function valoresDelCarrito(carrito: Record<string, SeleccionCarritoHijo>): SeleccionCarritoHijo[] {
  return Object.values(carrito);
}

/**
 * Auditoría 2026-09-20 (pedido de Pablo: "¿se puede aplicar un efecto lupa al pasar por la
 * miniatura?" en el resumen del pedido). Las miniaturas ahí son chiquitas (56x56px) y de baja
 * resolución (foto.thumbnail) — agrandar ESA imagen se vería borroso. En vez de eso: al pasar el
 * mouse se ve un ícono de lupa y un leve zoom como invitación (sólo cosmético, no depende de que
 * el dispositivo tenga mouse); al hacer clic o tocar se abre la vista ampliada reutilizando el
 * modal de vista previa que ya existía en la grilla de selección (foto.url, la versión más
 * grande con marca de agua) — así funciona igual en computadora que en el celular, donde el
 * "hover" no existe y una lupa que sigue el cursor no serviría de nada.
 */
function MiniaturaAmpliable({
  foto,
  alt,
  onAmpliar,
  className = 'h-14 w-14',
}: {
  foto: Foto;
  alt: string;
  onAmpliar: (foto: Foto) => void;
  className?: string;
}) {
  return (
    <button
      type="button"
      onClick={() => onAmpliar(foto)}
      className={`group relative ${className} shrink-0 rounded-lg overflow-hidden cursor-zoom-in focus:outline-none focus-visible:ring-2 focus-visible:ring-amber-400`}
      title="Tocá para ver la foto ampliada"
    >
      <img
        src={foto.thumbnail}
        alt={alt}
        className="h-full w-full object-cover transition-transform duration-200 ease-out group-hover:scale-125"
      />
      <span className="absolute inset-0 flex items-center justify-center bg-slate-950/0 group-hover:bg-slate-950/30 transition-colors duration-200">
        <Search className="w-4 h-4 text-white opacity-0 group-hover:opacity-100 transition-opacity duration-200 drop-shadow" />
      </span>
    </button>
  );
}

/**
 * Pedido "de respaldo" para la pantalla de confirmación cuando la familia vuelve de Mercado Pago /
 * Nave en un navegador que no tiene el pedido guardado (típico en el celular). Antes se armaba a
 * mano, incompleto (sin `archivosParaLaboratorio`, `tutorEmail`, etc.), y la pantalla explotaba al
 * leer esos campos. El estado real se consulta después al servidor.
 */
function pedidoDeRespaldo(datos: {
  referencia: string;
  esGrupo: boolean;
  metodoPago: PedidoEscolarCompleto['metodoPago'];
  estadoPago: PedidoEscolarCompleto['estadoPago'];
}): PedidoEscolarCompleto {
  return {
    id: datos.referencia,
    supabaseId: datos.referencia,
    grupoPagoId: datos.esGrupo ? datos.referencia : undefined,
    fecha: new Date().toLocaleDateString('es-AR'),
    colegioId: '',
    colegioNombre: '',
    cursoCodigo: '',
    grado: '',
    division: '',
    turno: '',
    alumnoNumeroLista: 0,
    alumnoNombre: datos.esGrupo ? 'tus hijos/as' : '',
    codigoAlumno: '',
    tutorNombre: '',
    tutorTelefono: '',
    tutorEmail: '',
    kitId: 'kit-clasico',
    kitNombre: datos.esGrupo ? 'Varios kits' : 'Kit Retrato Escolar',
    total: 0,
    metodoPago: datos.metodoPago,
    estadoPago: datos.estadoPago,
    estadoEntrega: 'laboratorio_listo',
    fotosSeleccionadas: { individualId: '', grupalId: '' },
    archivosParaLaboratorio: [],
    linkDescargaHD: '',
    emailEnviado: false,
  };
}

/**
 * Auditoría 03/10 noche (M9b/R7): estados con que Mercado Pago devuelve a la familia cuando el pago
 * quedó EN PROCESO (típico: generó un ticket de Rapipago/Pago Fácil y todavía no lo pagó, o lo pagó y
 * no se acreditó). No es "no pagaste": no hay que ofrecerle pagar de nuevo sin preguntar.
 */
const MP_ESTADOS_EN_PROCESO = new Set(['pending', 'in_process']);
// 05/10 (bug 3): valor interno de `retornoMp.estado` para la vuelta de Nave (?nave_status=vuelta).
const NAVE_ESTADO_VUELTA = 'nave_vuelta';
const TEXTO_PAGO_EN_PROCESO =
  'Tenés un pago en proceso (por ejemplo un ticket de Rapipago/Pago Fácil). No vuelvas a pagar: se acredita solo en hasta 48 h hábiles.';
// 14/10/2026: transferencia con el comprobante ya subido (antes se seguía ofreciendo pagar con tarjeta: cobro doble).
const TEXTO_COMPROBANTE_EN_REVISION = 'Recibimos el comprobante de tu transferencia y lo estamos revisando: lo confirmamos en el día y te llega un email. No vuelvas a pagar.';

/**
 * Colegio de la familia: el de la lista pública si está; si no (colegio no marcado como público,
 * o la lista todavía no cargó / falló), uno armado con los datos de la propia inscripción. Antes se
 * caía a `colegios[0]` — el pedido quedaba registrado en OTRO colegio (y el .zip HD nunca se podía
 * armar) — o directamente no se mostraba nada en el Paso 1.
 */
function colegioDeLaFamilia(colegios: Colegio[], familia: InscripcionFamilia): Colegio | null {
  const enLista = colegios.find((c) => c.id === familia.colegioId);
  if (enLista) return enLista;
  if (!familia.colegioId) return null;
  return {
    id: familia.colegioId,
    slug: familia.colegioId,
    nombre: familia.colegioNombre || 'Colegio',
    localidad: '',
    zona: 'CABA',
    eventoActual: '',
    grados: familia.grado ? [familia.grado] : [],
    divisiones: familia.division ? [familia.division] : [],
    turnos: familia.turno ? [familia.turno] : [],
    codigoAcceso: '',
  };
}

export default function PortalFamiliasModal({
  isOpen,
  onClose,
  preselectedColegioId,
  preselectedKitId,
  preselectedCodigo,
  onOpenInscripcion,
  abrirEnGaleria,
}: PortalFamiliasModalProps) {
  // Navigation Steps
  // 1: Colegio y Alumno
  // 2: Galería y Selección de Fotos
  // 3: Selección de Kit y Adicionales
  // 4: Checkout y Pago
  // 5: Pedido Confirmado
  const [step, setStep] = useState<1 | 2 | 3 | 4 | 5>(1);
  // Precios vigentes (se editan desde el panel): re-renderiza si cambian.
  const precios = usePrecios();

  // Mode: 'pedido' (order flow) | 'seguimiento' (order tracking tool)
  const [modalMode, setModalMode] = useState<'pedido' | 'seguimiento'>('pedido');
  const [trackingQuery, setTrackingQuery] = useState('');
  const [searchedOrder, setSearchedOrder] = useState<any | null>(null);
  // Auditoría 2026-09-26 (A2): "Reenviarme el link por email" en el seguimiento de pedido.
  const [reenviandoLink, setReenviandoLink] = useState(false);
  const [mensajeReenvioLink, setMensajeReenvioLink] = useState<string | null>(null);
  const [trackingError, setTrackingError] = useState('');
  const [buscandoSeguimiento, setBuscandoSeguimiento] = useState(false);
  // Auditoría 2026-09-22 (pedido de Pablo: "por qué me deja volver a comprar si ya tengo un
  // pedido hecho? debería mostrarme el pedido que ya realicé y preguntarme si deseo hacer otro").
  // `pedidoExistente` se llena automáticamente (ver el useEffect más abajo) apenas se resuelve
  // el alumno/a activo, si ya hay un pedido registrado para él/ella en este curso — mientras esté
  // seteado se muestra un cartel de confirmación en la pantalla de "Acceso validado" en vez del
  // botón normal para pasar al Paso 2.
  const [pedidoExistente, setPedidoExistente] = useState<PedidoExistenteResumen | null>(null);
  const [verificandoPedidoExistente, setVerificandoPedidoExistente] = useState(false);
  // Pasar un Kit Solo Digital ya pago a Kit Impreso: el pago (con los 3 medios) está en TarjetaPedidoExistente → PagoPedidoAdicional (29/10/2026).

  // Step 1: School & Student Selection
  const { colegios } = useColegiosLista();
  const [selectedColegio, setSelectedColegio] = useState<Colegio | null>(null);
  const [grado, setGrado] = useState('');
  const [division, setDivision] = useState('');
  const [turno, setTurno] = useState('');
  const [nombreAlumno, setNombreAlumno] = useState('');
  const [codigoAcceso, setCodigoAcceso] = useState('');
  // Auditoría 2026-09-22 (pedido de Pablo: "que cada vez que vayan a ingresar, lo hagan con
  // nombre y apellido del padre/tutor/encargado, el DNI del padre/tutor/encargado, y el código
  // generado"): el código de curso lo comparte toda la sección, así que ahora hacen falta estos
  // dos datos más, junto al código, para que el servidor identifique a la familia exacta.
  const [codigoTutorNombreInput, setCodigoTutorNombreInput] = useState('');
  const [codigoTutorDniInput, setCodigoTutorDniInput] = useState('');
  const [codigoValidadoMsg, setCodigoValidadoMsg] = useState<string | null>(null);
  const [codigoErrorMsg, setCodigoErrorMsg] = useState<string | null>(null);
  // Auditoría 03/10 noche (contratos 2, 3 y 4): avisos del ingreso que NO son "datos incorrectos"
  // (email sin confirmar, inscripción pendiente) y el "¡Listo! Confirmaste tu email" del link del correo.
  const [codigoAviso, setCodigoAviso] = useState<{ tipo: 'ok' | 'aviso'; texto: string } | null>(null);
  // Código del curso que precargó el link "Confirmar mi email" (contrato 3): sobrevive a que el
  // efecto de apertura vuelva a correr cuando termina de cargar la lista de colegios.
  const codigoPrecargadoRef = useRef('');
  // Auditoría 03/10 (alto 22): "Validar" no daba ninguna señal mientras consultaba al servidor.
  const [validandoCodigo, setValidandoCodigo] = useState(false);
  const [familiaActiva, setFamiliaActiva] = useState<InscripcionFamilia | null>(null);
  // Código real y secreto ya validado contra el servidor (ver `codigos_seccion` en server.ts).
  // Es la ÚNICA llave que habilita traer fotos reales — elegir grado/turno/división del
  // desplegable ya NO alcanza para verlas (antes sí, y ahí estaba el problema de seguridad).
  const [codigoSeccionValidado, setCodigoSeccionValidado] = useState<string | null>(null);

  // "No encuentro mi código de curso": recuperación y consultas únicamente por email.
  const [mostrarFormSolicitudCodigo, setMostrarFormSolicitudCodigo] = useState(false);
  const [solicitudNombre, setSolicitudNombre] = useState('');
  const [solicitudContacto, setSolicitudContacto] = useState('');
  const [enviandoSolicitudCodigo, setEnviandoSolicitudCodigo] = useState(false);
  const [solicitudCodigoEnviada, setSolicitudCodigoEnviada] = useState(false);
  const [solicitudCodigoMensaje, setSolicitudCodigoMensaje] = useState('');
  // false = no se encontró una inscripción con ese email (la solicitud queda para revisión manual).
  const [solicitudCodigoEncontrada, setSolicitudCodigoEncontrada] = useState(true);
  // 27/10: por qué no se mandó el código (sin inscripción con ese email, o inscripción en revisión).
  const [solicitudCodigoMotivo, setSolicitudCodigoMotivo] = useState<'pendiente' | 'sin_inscripcion' | null>(null);
  // Email con posible error de tipeo ("gmail.comm"): se pregunta antes de enviar.
  const [sugerenciaEmailSolicitud, setSugerenciaEmailSolicitud] = useState<string | null>(null);
  const [solicitudCodigoError, setSolicitudCodigoError] = useState<string | null>(null);

  // Step 2: Gallery
  // Pedido de Pablo (25/9): el recorrido empieza en 1/3 Grupal (antes arrancaba en el Retrato, el
  // paso del medio) y avanza solo al siguiente paso pendiente al elegir cada foto.
  const [categoriaActiva, setCategoriaActiva] = useState<'individual' | 'grupal' | 'docente' | 'patio'>('grupal');
  const [avisoAvancePack, setAvisoAvancePack] = useState('');
  const panelPackRef = useRef<HTMLDivElement>(null);
  const botonContinuarPackRef = useRef<HTMLDivElement>(null);
  const timerAvancePackRef = useRef<number | null>(null);
  useEffect(() => () => {
    if (timerAvancePackRef.current) window.clearTimeout(timerAvancePackRef.current);
  }, []);
  const [fotoSeleccionadaIndividual, setFotoSeleccionadaIndividual] = useState<string>('');
  const [fotoSeleccionadaGrupal, setFotoSeleccionadaGrupal] = useState<string>('');
  const [fotoSeleccionadaDocente, setFotoSeleccionadaDocente] = useState<string>('');
  const [fotosSueltasSeleccionadas, setFotosSueltasSeleccionadas] = useState<string[]>([]);
  const [sinFoto, setSinFoto] = useState<LugarPack[]>([]); // 22/10: «Mi hijo/a no tiene esta foto» (AvisoSinFotoPack)
  const sinFotoRef = useRef(sinFoto);
  sinFotoRef.current = sinFoto;
  // Auditoría 2026-09-20 (pedido de Pablo: efecto "lupa" en las miniaturas del resumen del
  // pedido). "soloVista" es opcional para no romper el único llamado que ya existía (la grilla de
  // selección del paso 2, que sigue sin mandarlo y por lo tanto sigue mostrando "Elegir esta
  // foto" como siempre). Se usa desde el resumen del pedido para ampliar sin ofrecer ese botón —
  // ahí la foto ya está elegida, no tiene sentido "reelegirla" desde una pantalla de repaso.
  const [modalFotoPreview, setModalFotoPreview] = useState<(Foto & { soloVista?: boolean }) | null>(null);
  const [errorSeleccionFotos, setErrorSeleccionFotos] = useState('');

  // Sólo fotos reales del curso cargadas en Supabase; nunca se muestran fotos genéricas.
  const [fotosDisponibles, setFotosDisponibles] = useState<Foto[]>([]);
  // Sesión guardada sin llave de galería (y sin DNI para pedirla de nuevo): hay que volver a ingresar
  // para ver la foto individual de cada hijo (auditoría 28/9).
  const [faltaReingresoGaleria, setFaltaReingresoGaleria] = useState(false);
  // Auditoría 03/10 (alto 23): estado real de la galería. Antes, cargando, error de red, código
  // vencido y "todavía no hay fotos" se veían iguales ("Tus fotos todavía no fueron ingresadas").
  const [estadoGaleria, setEstadoGaleria] = useState<'cargando' | 'ok' | 'vacia' | 'codigo_invalido' | 'error'>('vacia');
  const [errorGaleria, setErrorGaleria] = useState<string | null>(null);
  const [reintentoGaleria, setReintentoGaleria] = useState(0);
  // 25/10/2026: llave de la última galería cargada. Si sólo se pide recargar la misma (p. ej. el buscador por rostro sumó
  // fotos), no se vacía la pantalla: así no vuelve a «Grupal» ni se pierde el mensaje del buscador.
  const galeriaCargadaRef = useRef('');
  // Visor ampliado (medio, 03/10): qué foto terminó de cargar, para no dejar "Elegir" sobre la anterior.
  const [previewCargadaId, setPreviewCargadaId] = useState<string | null>(null);
  // 04/10 (pedido de Pablo): lupa en la vista ampliada. La muestra está apenas desenfocada y dice "PASÁ
  // LA LUPA POR LA IMAGEN"; la lupa muestra la foto nítida en esa zona (el servidor manda sólo ese
  // pedacito, con sellos "MUESTRA · código"). Ver src/utils/lupaMuestra.ts y lupa/recorte.ts.
  const contenedorPreviewRef = useRef<HTMLDivElement>(null);
  const imgPreviewRef = useRef<HTMLImageElement>(null);
  const lupaUrlPreview = modalFotoPreview?.lupaUrl || '';
  const lupaLista = !!lupaUrlPreview && previewCargadaId === modalFotoPreview?.id;
  useEffect(() => {
    const contenedor = contenedorPreviewRef.current;
    const img = imgPreviewRef.current;
    if (!lupaLista || !contenedor || !img) return;
    const lupa = montarLupa(contenedor, img, {
      urlRecorte: (cx, cy, s) => `${lupaUrlPreview}&cx=${cx}&cy=${cy}&s=${s}`,
    });
    return () => lupa.destruir();
  }, [lupaLista, lupaUrlPreview]);

  useEffect(() => {
    let cancelado = false;
    // Auditoría 03/10 (medio): al cambiar de hijo (otra sección) se veía la galería del hermano
    // anterior hasta que llegaba la nueva, y se podía elegir una foto que no era de este chico.
    // Ahora se limpia apenas cambia la llave y se muestra "cargando".
    const llaveGaleria = `${codigoSeccionValidado}|${familiaActiva?.id || ''}|${familiaActiva?.accesoGaleria || ''}`;
    const mismaGaleria = galeriaCargadaRef.current === llaveGaleria;
    galeriaCargadaRef.current = llaveGaleria;
    if (!mismaGaleria) setEstadoGaleria(codigoSeccionValidado ? 'cargando' : 'vacia');
    setErrorGaleria(null);
    if (!mismaGaleria) setFotosDisponibles((previas) => (previas.length ? [] : previas));
    setModalFotoPreview(null);
    // Sin un código real y validado no se expone ninguna galería.
    (async () => {
      // Auditoría 28/9: las fotos individuales de cada chico sólo las manda el servidor con la
      // llave de la familia. Una sesión guardada antes de este cambio no la tiene: se pide de nuevo
      // con los mismos datos del ingreso (código + nombre + DNI del tutor), sin molestar a la familia.
      let fam = familiaActiva;
      const codigoFam = fam?.codigoAsignado || fam?.codigoFamiliar;
      if (codigoSeccionValidado && fam && !fam.accesoGaleria && fam.padreDni && codigoFam) {
        const r = await buscarMiInscripcion(codigoFam, fam.padreNombre, fam.padreDni);
        if (r.encontrada && r.inscripcion?.accesoGaleria) {
          fam = { ...fam, accesoGaleria: r.inscripcion.accesoGaleria };
          guardarFamiliaActiva(fam);
          // 05/10 (bug 7): la llave recuperada también va al estado (antes sólo al storage, y las
          // consultas de hermanos/reservas seguían sin llave). Al cambiar `familiaActiva.accesoGaleria`
          // este mismo efecto vuelve a correr ya con la llave (y no vuelve a pedirla): se corta acá.
          if (!cancelado) setFamiliaActiva(fam);
          return null;
        }
      }
      if (!cancelado) setFaltaReingresoGaleria(Boolean(codigoSeccionValidado && fam && !fam.accesoGaleria));
      return obtenerGaleriaPublica({ codigo: codigoSeccionValidado, familiaId: fam?.id, acceso: fam?.accesoGaleria });
    })().then((resultado) => {
      if (cancelado || !resultado) return;
      setFotosDisponibles(resultado.fotos);
      setEstadoGaleria(resultado.estado);
      setErrorGaleria(resultado.error || null);
      // Auditoría 2026-09-23: el curso real de esta galería es el que resuelve el servidor a
      // partir del código (codigos_seccion). Se toma de ahí para que el pedido se registre con el
      // mismo grado/turno/división de las fotos: si el grado de la inscripción ya no figuraba
      // textual en la lista del colegio (el fotógrafo la editó), un efecto de más abajo lo
      // reemplazaba por el primero de la lista, y el pedido quedaba con un curso sin fotos (el
      // .zip HD nunca se podía armar).
      if (resultado.seccion) {
        const { grado: gradoSeccion, turno: turnoSeccion, division: divisionSeccion } = resultado.seccion;
        if (gradoSeccion) setGrado(gradoSeccion);
        if (turnoSeccion) setTurno(turnoSeccion);
        if (divisionSeccion !== undefined && divisionSeccion !== null) setDivision(divisionSeccion);
      }
    });
    return () => {
      cancelado = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [codigoSeccionValidado, familiaActiva?.id, familiaActiva?.accesoGaleria, reintentoGaleria]);

  // Al cambiar de galería se conservan únicamente elecciones que sigan existiendo.
  // Nunca se elige automáticamente la primera foto: la decisión debe ser explícita.
  useEffect(() => {
    // 06/10: la 3ª foto puede ser con la seño o con familia/amigos; 22/10: en un lugar «no tiene esta foto»
    // vale otra foto del curso (idValidoEnLugar, utils/fotosFaltantes.ts).
    const sf = sinFotoRef.current;
    setFotoSeleccionadaIndividual((actual) => idValidoEnLugar(fotosDisponibles, actual, 'individual', sf));
    setFotoSeleccionadaGrupal((actual) => idValidoEnLugar(fotosDisponibles, actual, 'grupal', sf));
    setFotoSeleccionadaDocente((actual) => idValidoEnLugar(fotosDisponibles, actual, 'docente', sf));
    setFotosSueltasSeleccionadas((actuales) => actuales.filter((id) => fotosDisponibles.some((f) => f.id === id && f.categoria === 'patio')));
    if (!fotosDisponibles.some((f) => f.categoria === 'patio')) {
      const primeraConFotos = (['grupal', 'individual', 'docente'] as const).find((c) => fotosDisponibles.some((f) => pasoDelPack(f.categoria) === c));
      setCategoriaActiva((actual) => (fotosDisponibles.some((f) => pasoDelPack(f.categoria) === actual) ? actual : primeraConFotos || 'grupal'));
    }
    setAvisoAvancePack('');
    setErrorSeleccionFotos('');
  }, [fotosDisponibles]);

  usePlazosTemporada(); // Step 3: Kit & Extras. 30/10: re-renderiza cuando llegan las fechas límite del panel → Configuración
  const [selectedKit, setSelectedKit] = useState<KitProducto>(
    KITS_DISPONIBLES.find((k) => k.id === (plazoKitImpresoAbierto() ? 'kit-clasico' : 'kit-digital')) || KITS_DISPONIBLES[0]
  );
  // Copia extra de la carpeta completa para abuelos o familiares
  const [extraCarpetas, setExtraCarpetas] = useState<number>(0);

  // Step 4: Checkout
  const [tutorNombre, setTutorNombre] = useState('');
  const [tutorWhatsapp, setTutorWhatsapp] = useState('');
  const [tutorEmail, setTutorEmail] = useState('');
  const [metodoPago, setMetodoPago] = useState<'mercadopago' | 'transferencia' | 'nave'>('mercadopago');
  const [descuento, setDescuento] = useState<CodigoDescuentoAplicado | null>(null); // 22/10: código de descuento (Paso 4)
  const naveHabilitado = useNaveHabilitado();
  // Si Nave no está habilitado y quedó elegido, se vuelve a Mercado Pago.
  useEffect(() => {
    if (!naveHabilitado && metodoPago === 'nave' && step < 5) setMetodoPago('mercadopago');
  }, [naveHabilitado, metodoPago, step]);
  const [isProcessingPayment, setIsProcessingPayment] = useState(false);
  // Marco legal (27/9): casilla obligatoria "Leí y acepto" antes de pagar (sin premarcar).
  const [aceptaTerminos, setAceptaTerminos] = useState(false);
  const [faltaAceptarTerminos, setFaltaAceptarTerminos] = useState(false);
  // Pedido de Pablo (29/9): por transferencia, la familia tiene que tildar que entiende que el
  // pedido se cancela si no sube el comprobante en 48 hs (ver AvisoPlazoTransferencia).
  const [aceptaPlazoTransferencia, setAceptaPlazoTransferencia] = useState(false);
  const [faltaAceptarPlazo, setFaltaAceptarPlazo] = useState(false);
  // Auditoría 11/10 (POR-12): pasar un pedido ya registrado a transferencia también exige la casilla.
  const [cambioATransferencia, setCambioATransferencia] = useState<{ acepta: boolean; falta: boolean } | null>(null);
  // Auditoría 11/10 (POR-5): sin los precios del servidor no se muestra un monto a pagar (puede no ser el cobrado).
  const [cargandoPrecios, setCargandoPrecios] = useState(false);
  const reintentarPrecios = () => {
    if (preciosVienenDelServidor()) return;
    setCargandoPrecios(true);
    void cargarPreciosDelServidor().finally(() => setCargandoPrecios(false));
  };
  useEffect(() => {
    if (isOpen && step === 4) reintentarPrecios();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isOpen, step]);
  const preciosOk = preciosVienenDelServidor();
  const [numeroPedido, setNumeroPedido] = useState('');
  const [pedidoGenerado, setPedidoGenerado] = useState<PedidoEscolarCompleto | null>(null);
  const [mpRedirectUrl, setMpRedirectUrl] = useState<string | null>(null);
  const [naveRedirectUrl, setNaveRedirectUrl] = useState<string | null>(null);
  const [pagoError, setPagoError] = useState<string | null>(null);
  // 05/10 (bug 2b): el carrito quedó registrado pero el kit por adelantado de un hermano no se pudo
  // sumar (el servidor lo rechazó). Se muestra en el Paso 5 junto al pago del carrito.
  const [avisoReservaNoSumada, setAvisoReservaNoSumada] = useState<string | null>(null);
  // Pedido de Pablo (28/9): todo error que se le muestra a la familia al pagar queda registrado solo.
  useEffect(() => {
    // Auditoría 03/10: se manda el pedido para que el registro sea uno por pedido + motivo.
    if (pagoError)
      registrarFallaDePago('portal', pagoError, {
        email: tutorEmail.trim(),
        metodoPago,
        paso: step,
        pedido: pedidoGenerado?.grupoPagoId || pedidoGenerado?.supabaseId || checkoutIdsRef.current?.pedidoId || '',
      });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [pagoError]);

  // Caso real 25/9: el pedido guardado en este navegador (o el de la URL de vuelta del pago) ya no
  // existe en la base — lo borró el admin o se anuló. Antes quedaba la pantalla de "Pendiente de
  // pago" con botones para pagar y un aviso rojo confuso; ahora se descarta y se ofrece armar otro.
  const [pedidoYaNoExiste, setPedidoYaNoExiste] = useState(false);
  // Auditoría 03/10 (crítico 2): ids del pedido estables durante el checkout (ver checkoutEstable.ts).
  const checkoutIdsRef = useRef<IdsCheckout | null>(null);
  // Auditoría 03/10 (alto 8): el servidor avisó que ya hay un kit pagado (409 KIT_YA_PAGADO).
  const [confirmacionOtroKit, setConfirmacionOtroKit] = useState<{ alumnos: string[]; mensaje: string } | null>(null);
  // Auditoría 11/10 (POR-1): cambia cada vez que el pedido en pantalla pasa a ser otro; una
  // respuesta de estado de un pedido anterior que llega tarde se descarta.
  const generacionPedidoRef = useRef(0);
  // Auditoría 11/10 (POR-3): fila real de un carrito consultado por su grupo_pago_id (respaldo sin storage).
  const filaRealDelGrupoRef = useRef<Record<string, string>>({});
  // Lo que viaja con un reporte de error ("Avisar al equipo técnico"): en qué paso y con qué pedido.
  useEffect(() => {
    registrarContextoDeError('portal', {
      abierto: isOpen,
      paso: step,
      colegio: selectedColegio?.nombre,
      alumno: nombreAlumno,
      grado,
      division,
      turno,
      kit: selectedKit?.id,
      metodoPago,
      pedido: pedidoGenerado ? { id: pedidoGenerado.id, supabaseId: pedidoGenerado.supabaseId, grupo: pedidoGenerado.grupoPagoId, estado: pedidoGenerado.estadoPago, metodo: pedidoGenerado.metodoPago, total: pedidoGenerado.total } : null,
      avisoEnPantalla: pagoError,
    });
  });
  const descartarPedidoInexistente = (referencia?: string | null) => {
    setPedidoYaNoExiste(true);
    setPagoError(null);
    setMensajeEstadoPago(null);
    setMpRedirectUrl(null);
    setNaveRedirectUrl(null);
    try {
      const ref = referencia || '';
      guardarPedidosEnStorageDelPortal(
        obtenerPedidosGuardados().filter((p) => !ref || (p.supabaseId !== ref && p.id !== ref && p.grupoPagoId !== ref))
      );
      const url = new URL(window.location.href);
      ['mp_status', 'nave_status', 'pedido_id', 'grupo_pago_id', 'status', 'payment_id', 'collection_status', 't'].forEach((k) => url.searchParams.delete(k));
      window.history.replaceState(null, '', url.pathname + (url.search ? url.search : '') + url.hash);
    } catch {
      /* sin storage: igual se muestra el aviso */
    }
  };
  const esErrorPedidoInexistente = (error?: string) => /No encontramos el pedido registrado/i.test(error || '');
  // 25/10 (ERR-EGJ7Q/I6H3G/RWLSX): MP la devolvió por la URL de "rechazado" pero el pago entró → se consulta el estado real, no es un error.
  const esErrorPedidoYaPagado = (error?: string) => /ya está pagado/i.test(error || '');
  const [verificandoPago, setVerificandoPago] = useState(false);
  const [mensajeEstadoPago, setMensajeEstadoPago] = useState<string | null>(null);
  const [generandoLinkPago, setGenerandoLinkPago] = useState(false);
  const [generandoLinkNave, setGenerandoLinkNave] = useState(false);
  const [cambiandoMetodoPago, setCambiandoMetodoPago] = useState(false);

  /**
   * Genera (o regenera) el link de Checkout Pro de Mercado Pago para un pedido ya registrado.
   * Hace falta porque el link original (mpRedirectUrl) vive solo en memoria del navegador:
   * si la familia recarga la página, vuelve más tarde, o Mercado Pago la devuelve con el pago
   * pendiente/rechazado, ese link se pierde y sin esto no había forma de volver a pagar.
   */
  const generarLinkDePago = async (pedido: PedidoEscolarCompleto, autoRedirigir = false) => {
    if (generandoLinkPago) return;
    setGenerandoLinkPago(true);
    setPagoError(null);
    try {
      // Auditoría 2026-09-23 (bug real): para un carrito de varios hijos esto regeneraba el link con
      // el id del PRIMER pedido del grupo — el reintento cobraba sólo a ese hijo, y los hermanos
      // quedaban sin pagar. Un pedido con grupo de pago se regenera como pago combinado.
      const res = pedido.grupoPagoId
        ? await crearPreferenciaMercadoPagoMultiple({
            grupoPagoId: pedido.grupoPagoId,
            items: [],
            tutorNombre: pedido.tutorNombre || 'Tutor',
            tutorEmail: pedido.tutorEmail,
            tutorTelefono: pedido.tutorTelefono || undefined, confirmarIgual: confirmoPagarDeNuevo,
          })
        : await crearPreferenciaMercadoPago({
        pedidoId: pedido.supabaseId || pedido.id,
        kitId: pedido.kitId,
        kitNombre: pedido.kitNombre,
        alumnoNombre: pedido.alumnoNombre || 'Alumno',
        colegioNombre: pedido.colegioNombre || 'Colegio',
        cursoCodigo: pedido.cursoCodigo,
        total: pedido.total,
        carpetasExtras: pedido.copiasExtras?.carpetasExtras || 0,
        // Auditoría 2026-09-20 (bug real, CRÍTICO): faltaba mandar esto — el servidor recalcula
        // el total SIEMPRE del lado propio (nunca confía en "total"), pero sin este dato trataba
        // cualquier pedido con "Otras Fotos" como si tuviera 0, cobrando de menos por Mercado
        // Pago aunque el .zip HD sí las incluyera igual. Ver calcularTotalPedido en server.ts.
        cantidadFotosSueltas: pedido.copiasExtras?.otras15x21 || 0,
        tutorNombre: pedido.tutorNombre || 'Tutor',
        tutorEmail: pedido.tutorEmail,
        tutorTelefono: pedido.tutorTelefono || undefined, confirmarIgual: confirmoPagarDeNuevo,
      });
      if (res.initPoint) {
        setMpRedirectUrl(res.initPoint);
        if (autoRedirigir) {
          window.location.href = res.initPoint;
        }
      } else {
        if (esErrorPedidoInexistente(res.error)) descartarPedidoInexistente(pedido.grupoPagoId || pedido.supabaseId || pedido.id);
        else if (esErrorPedidoYaPagado(res.error)) void verificarEstadoRealPedido(pedido.supabaseId || pedido.grupoPagoId || pedido.id);
        else if (res.codigo === 'COMPROBANTE_YA_SUBIDO') setComprobanteEnRevision(true); // 14/10/2026
        else setPagoError(res.error || 'No se pudo generar el link de pago de Mercado Pago.');
      }
    } catch (err: any) {
      setPagoError(err?.message || 'Error de conexión con el servidor de pagos.');
    } finally {
      setGenerandoLinkPago(false);
    }
  };

  /**
   * Genera (o regenera) el link de Checkout de Nave para un pedido ya registrado.
   * Mismo motivo que generarLinkDePago: el link vive solo en memoria del navegador.
   */
  const generarLinkDeNave = async (pedido: PedidoEscolarCompleto, autoRedirigir = false) => {
    if (generandoLinkNave) return;
    setGenerandoLinkNave(true);
    setPagoError(null);
    try {
      // Mismo caso que generarLinkDePago: un carrito de varios hijos se cobra combinado.
      const res = pedido.grupoPagoId
        ? await crearIntencionPagoNaveMultiple({
            grupoPagoId: pedido.grupoPagoId,
            items: [],
            tutorNombre: pedido.tutorNombre || 'Tutor',
            tutorEmail: pedido.tutorEmail,
            tutorTelefono: pedido.tutorTelefono || undefined, confirmarIgual: confirmoPagarDeNuevo,
          })
        : await crearIntencionPagoNave({
        pedidoId: pedido.supabaseId || pedido.id,
        kitId: pedido.kitId,
        kitNombre: pedido.kitNombre,
        alumnoNombre: pedido.alumnoNombre || 'Alumno',
        colegioNombre: pedido.colegioNombre || 'Colegio',
        carpetasExtras: pedido.copiasExtras?.carpetasExtras || 0,
        // Auditoría 2026-09-20 (bug real, CRÍTICO): ver comentario equivalente en
        // generarLinkDePago (Mercado Pago) — mismo problema en Nave.
        cantidadFotosSueltas: pedido.copiasExtras?.otras15x21 || 0,
        tutorNombre: pedido.tutorNombre || 'Tutor',
        tutorEmail: pedido.tutorEmail,
        tutorTelefono: pedido.tutorTelefono || undefined, confirmarIgual: confirmoPagarDeNuevo,
      });
      if (res.checkoutUrl) {
        setNaveRedirectUrl(res.checkoutUrl);
        if (autoRedirigir) {
          window.location.href = res.checkoutUrl;
        }
      } else {
        if (esErrorPedidoInexistente(res.error)) descartarPedidoInexistente(pedido.grupoPagoId || pedido.supabaseId || pedido.id);
        else if (esErrorPedidoYaPagado(res.error)) void verificarEstadoRealPedido(pedido.supabaseId || pedido.grupoPagoId || pedido.id);
        else if ((res as { codigo?: string }).codigo === 'COMPROBANTE_YA_SUBIDO') setComprobanteEnRevision(true); // 14/10/2026
        else setPagoError(res.error || 'No se pudo generar el link de pago de Nave.');
      }
    } catch (err: any) {
      setPagoError(err?.message || 'Error de conexión con el servidor de pagos.');
    } finally {
      setGenerandoLinkNave(false);
    }
  };

  // Auditoría 03/10 noche (M9a/M9b): lo que dijo Mercado Pago en la URL de vuelta (mp_status) y a
  // qué pedido/grupo corresponde. NUNCA alcanza para mostrar "aprobado" (eso lo dice sólo el
  // servidor); sirve para no ofrecer pagar de nuevo un pago que quedó en proceso.
  const [retornoMp] = useState<{ estado: string; referencia: string }>(() => {
    if (typeof window === 'undefined') return { estado: '', referencia: '' };
    try {
      const params = new URLSearchParams(window.location.search);
      if (params.get('reserva') === '1') return { estado: '', referencia: '' };
      const referencia = params.get('pedido_id') || params.get('grupo_pago_id') || '';
      // 05/10 (bug 3): la vuelta de Nave (nave_status=vuelta) no trae el resultado en la URL; se la
      // trata como "esperando confirmación" (mismo freno que un pago en proceso de Mercado Pago).
      if (!params.get('mp_status') && params.get('nave_status')) return { estado: NAVE_ESTADO_VUELTA, referencia };
      return { estado: params.get('mp_status') || '', referencia };
    } catch {
      return { estado: '', referencia: '' };
    }
  });
  // Ids (pedido, grupo, primer pedido del grupo) que pertenecen a esa vuelta de Mercado Pago.
  const idsDelRetornoMpRef = useRef<Set<string>>(new Set(retornoMp.referencia ? [retornoMp.referencia] : []));
  const esPedidoDelRetornoMp = (id?: string | null) => Boolean(id && idsDelRetornoMpRef.current.has(id));
  const pedidoEsDelRetornoMp = (p: PedidoEscolarCompleto | null) =>
    Boolean(p && (esPedidoDelRetornoMp(p.supabaseId) || esPedidoDelRetornoMp(p.grupoPagoId) || esPedidoDelRetornoMp(p.id)));
  // La familia confirmó expresamente que igual quiere pagar de otra forma (M9b).
  const [confirmoPagarDeNuevo, setConfirmoPagarDeNuevo] = useState(false);
  const [preguntandoPagarDeNuevo, setPreguntandoPagarDeNuevo] = useState(false);
  // 14/10/2026: el pedido en pantalla ya tiene el comprobante de una transferencia subido (lo dice el servidor o SubirComprobante).
  const [comprobanteEnRevision, setComprobanteEnRevision] = useState(false);
  useEffect(() => setComprobanteEnRevision(false), [pedidoGenerado?.supabaseId, pedidoGenerado?.grupoPagoId]);
  // Pago que Mercado Pago informó en proceso / aprobado y el servidor todavía ve pendiente: no se
  // genera un link nuevo solo ni se ofrecen otros medios sin una confirmación explícita.
  const pagoEnProcesoMp = MP_ESTADOS_EN_PROCESO.has(retornoMp.estado) && pedidoEsDelRetornoMp(pedidoGenerado);
  const aprobadoSegunMp = retornoMp.estado === 'approved' && pedidoEsDelRetornoMp(pedidoGenerado);
  // 05/10 (bug 3): volvió de Nave y el servidor todavía no confirmó: no se genera otro link de Nave
  // solo ni se ofrece pagar de nuevo (antes se regeneraba el link y se ofrecía pagar otra vez).
  const esperandoNave = retornoMp.estado === NAVE_ESTADO_VUELTA && pedidoEsDelRetornoMp(pedidoGenerado);
  const bloquearPagoNuevo =
    (pagoEnProcesoMp || aprobadoSegunMp || esperandoNave || comprobanteEnRevision) && pedidoGenerado?.estadoPago === 'pendiente' && !confirmoPagarDeNuevo;

  // Consulta en tiempo real el estado del pedido en la base de datos (Supabase / Backend)
  // Devuelve true si el servidor respondió (sirve al polling para espaciar las consultas si falla).
  const verificarEstadoRealPedido = async (idParaConsultar?: string): Promise<boolean> => {
    const id = idParaConsultar || pedidoGenerado?.supabaseId || pedidoGenerado?.id;
    if (!id) return false;
    const generacion = generacionPedidoRef.current;
    const esOtroPedido = () => generacionPedidoRef.current !== generacion;
    setVerificandoPago(true);
    setMensajeEstadoPago(null);
    try {
      const res = await fetchConTimeout(urlEstadoPedido(id));
      if (esOtroPedido()) return true;
      if (res.status === 404) {
        if (generacionPedidoRef.current === generacion) descartarPedidoInexistente(id);
        return true;
      }
      if (esStatusTransitorio(res.status)) {
        setMensajeEstadoPago(
          res.status === 429
            ? 'Hay muchas consultas en este momento; seguimos verificando tu pago en un rato.'
            : 'No pudimos consultar el estado del pago en este momento; lo volvemos a intentar solos.'
        );
        return false;
      }
      const data = await res.json().catch(() => ({}));
      if (esOtroPedido()) return true;
      if (data.success) {
        if (typeof data.pedidoId === 'string' && data.pedidoId !== id) filaRealDelGrupoRef.current[id] = data.pedidoId;
        if (data.comprobanteSubido === true) setComprobanteEnRevision(true);
        // Auditoría 03/10 noche (M7/H6): se adopta SIEMPRE el total del servidor (el que se cobra),
        // sea mayor o menor que el que tenía este navegador. Antes sólo se corregía si el servidor
        // decía MÁS, y la familia podía ver (y transferir) un monto calculado en el navegador.
        const totalServidor = totalDelServidor(data.total);
        if (totalServidor !== null) {
          setPedidoGenerado((prev) => (prev && prev.total !== totalServidor ? { ...prev, total: totalServidor } : prev));
        }
        if (data.estadoPago === 'aprobado') {
          // Auditoría 2026-09-18 (reporte de Pablo): "el botón de descarga inmediata no se
          // activa" — el .zip HD se termina de generar unos segundos después de que el pago
          // queda aprobado, así que acá se suma el link apenas el servidor lo tiene (además de
          // llegar por email), en vez de obligar a la familia a esperar el correo.
          setPedidoGenerado((prev) =>
            prev
              ? {
                  ...prev,
                  estadoPago: 'aprobado',
                  estadoEntrega: 'laboratorio_listo',
                  linkDescargaHD: data.linkDescargaHD || prev.linkDescargaHD,
                  // 05/10 (bug 8): mejora a impreso → no hay .zip propio (opcional, lo manda el servidor).
                  esMejora: data.esMejora === true || prev.esMejora, esFotosExtra: data.esFotosExtra === true || prev.esFotosExtra,
                }
              : null
          );
          setMensajeEstadoPago(
            data.linkDescargaHD
              ? '¡Pago confirmado! Ya podés descargar tus fotos en alta resolución.'
              : data.esMejora === true
                ? data.esFotosExtra === true ? '¡Pago confirmado! Tus fotos extra se imprimen y se entregan en el colegio.' : '¡Pago confirmado! Tu carpeta impresa se suma al pedido anterior.'
                : '¡Pago confirmado y acreditado con éxito! Estamos preparando tu descarga.'
          );
        } else if (data.estadoPago === 'rechazado') {
          setPedidoGenerado((prev) =>
            prev ? { ...prev, estadoPago: 'rechazado' } : null
          );
          setMensajeEstadoPago('El pago fue rechazado o cancelado.');
        } else {
          // Auditoría 03/10 noche (M9a/R6): se muestra sólo lo que dice el servidor — si dice
          // pendiente, el pedido vuelve a pendiente aunque en pantalla figurara otra cosa.
          setPedidoGenerado((prev) => (prev && prev.estadoPago !== 'pendiente' ? { ...prev, estadoPago: 'pendiente' } : prev));
          if (volvioSinPagar(window.location.search) && esPedidoDelRetornoMp(id)) {
            // Volvió de Mercado Pago sin pagar ("Volver a la tienda"): no es un pago en proceso.
            setMensajeEstadoPago('No completaste el pago: no se te cobró nada. Podés volver a intentarlo cuando quieras.');
          } else if (MP_ESTADOS_EN_PROCESO.has(retornoMp.estado) && esPedidoDelRetornoMp(id)) {
            setMensajeEstadoPago(TEXTO_PAGO_EN_PROCESO);
          } else if (retornoMp.estado === 'approved' && esPedidoDelRetornoMp(id)) {
            setMensajeEstadoPago('Estamos confirmando tu pago… Apenas se acredite lo vas a ver acá y te llega un email.');
          } else if (retornoMp.estado === NAVE_ESTADO_VUELTA && esPedidoDelRetornoMp(id)) {
            // 05/10 (bug 3): Nave no informa el resultado en la URL; se espera al servidor.
            setMensajeEstadoPago('Estamos confirmando tu pago con Nave… Apenas se acredite lo vas a ver acá y te llega un email. Si no llegaste a pagar, tocá "Quiero pagar de otra forma".');
          } else {
            setMensajeEstadoPago('El pago aún se encuentra en procesamiento.');
          }
        }
      }
      return true;
    } catch (e) {
      console.warn('Error al verificar estado de pago:', e);
      if (!esOtroPedido()) setMensajeEstadoPago('Sin conexión con el servidor; volvemos a verificar tu pago en un rato.');
      return false;
    } finally {
      setVerificandoPago(false);
    }
  };

  // Cambiar el medio de un pedido sin pagar (sólo mientras siga cobrable); limpia los links viejos.
  // Si la familia eligió a mano Nave / Mercado Pago, apenas esté el link se la lleva a pagar.
  const redirigirAlTenerLinkRef = useRef(false);
  const handleCambiarMetodoPago = async (nuevoMetodo: 'mercadopago' | 'nave' | 'transferencia') => {
    if (!pedidoGenerado || cambiandoMetodoPago || nuevoMetodo === pedidoGenerado.metodoPago) return;
    // POR-3 (11/10): en el respaldo de un carrito supabaseId es el grupo; el servidor necesita una fila.
    const id = filaRealDelGrupoRef.current[pedidoGenerado.supabaseId || ''] || pedidoGenerado.supabaseId || pedidoGenerado.id;
    if (!id) return;

    setCambiandoMetodoPago(true);
    setPagoError(null);
    try {
      const res = await cambiarMetodoPagoPedido(id, nuevoMetodo, pedidoGenerado.grupoPagoId || undefined, confirmoPagarDeNuevo);
      if (res.codigo === 'COMPROBANTE_YA_SUBIDO') return setComprobanteEnRevision(true); // 14/10/2026: se pregunta antes
      if (!res.success) {
        setPagoError(res.error || 'No se pudo cambiar el método de pago.');
        return;
      }

      redirigirAlTenerLinkRef.current = nuevoMetodo !== 'transferencia';
      // Revisión 11/10: el servidor lo deja en pendiente_pago (p. ej. tarjeta rechazada → transferencia): reflejarlo, si no no salen los datos bancarios.
      setPedidoGenerado((prev) => (prev ? { ...prev, metodoPago: nuevoMetodo, estadoPago: prev.estadoPago === 'aprobado' ? 'aprobado' : 'pendiente' } : null));
      setMetodoPago(nuevoMetodo);
      setMpRedirectUrl(null);
      setNaveRedirectUrl(null);

      // El servidor ya agrupa el cambio por grupo_pago_id cuando es un carrito multi-hijo (ver
      // /api/pedidos/:id/cambiar-metodo-pago) — acá solo se refleja en el localStorage el propio
      // pedido en pantalla, que es lo único que este navegador cachea localmente por id.
      const pedidosGuardados = obtenerPedidosGuardados();
      const actualizados = pedidosGuardados.map((p) =>
        p.supabaseId === id || p.id === id ? { ...p, metodoPago: nuevoMetodo, estadoPago: (p.estadoPago === 'aprobado' ? 'aprobado' : 'pendiente') as typeof p.estadoPago } : p
      );
      guardarPedidosEnStorageDelPortal(actualizados);
    } catch (err: any) {
      setPagoError(err?.message || 'Error de conexión al cambiar el método de pago.');
    } finally {
      setCambiandoMetodoPago(false);
    }
  };

  // Volvió de Mercado Pago sin pagar ("Volver a la tienda"): el pedido existe pero NO está pago.
  // Caso real (25/9): la pantalla decía "¡Gracias por tu pedido!" y seguía "verificando" 30 minutos.
  const [volvioSinPagarAlCargar] = useState(() => (typeof window !== 'undefined' ? volvioSinPagar(window.location.search) : false));
  // Auditoría 11/10 (POR-2): sólo vale para el pedido de esa vuelta, no para una compra posterior.
  const volvioSinPagarEste = volvioSinPagarAlCargar && pedidoEsDelRetornoMp(pedidoGenerado);

  // Sondeo en el Paso 5 mientras el pago está pendiente (o aprobado sin link HD): setTimeout
  // encadenado que se espacia, se pausa con la pestaña oculta y tiene tope de intentos.
  useEffect(() => {
    if (!isOpen || step !== 5 || !pedidoGenerado) return;
    const pagoPendiente = pedidoGenerado.estadoPago !== 'aprobado' && pedidoGenerado.estadoPago !== 'rechazado' && !volvioSinPagarEste;
    // 05/10 (bug 8): una mejora a impreso pagada no tiene .zip propio — no se la sondea esperando uno.
    const aprobadoSinLink = pedidoGenerado.estadoPago === 'aprobado' && !pedidoGenerado.linkDescargaHD && !pedidoGenerado.esMejora;
    if (!pagoPendiente && !aprobadoSinLink) return;

    // Auditoría 2026-09-23: antes se consultaba cada 4 s sin tope — una pantalla abierta agotaba
    // el límite de consultas de la IP (compartida con otras familias en celulares/WiFi del colegio).
    // Transferencia/efectivo no se acreditan solos (los aprueba el fotógrafo): se consulta más
    // espaciado. Siempre con tope; el botón "Verificar estado" sigue disponible.
    const esPagoManual = pedidoGenerado.metodoPago === 'transferencia' || pedidoGenerado.metodoPago === 'efectivo';
    const intervaloMs = aprobadoSinLink ? 8000 : esPagoManual ? 60000 : 10000;
    const maxIntentos = aprobadoSinLink ? 45 : esPagoManual ? 30 : 180; // ~6 min esperando el .zip; ~30 min esperando el pago
    const esperaMaxima = intervaloMs * 4;
    let intentos = 0;
    let espera = intervaloMs;
    let cancelado = false;
    let pausado = false;
    let temporizador: number | undefined;
    const programar = () => {
      if (cancelado) return;
      temporizador = window.setTimeout(consultar, espera);
    };
    const consultar = async () => {
      temporizador = undefined;
      if (cancelado) return;
      if (typeof document !== 'undefined' && document.hidden) {
        pausado = true; // se retoma en visibilitychange
        return;
      }
      intentos += 1;
      const respondio = await verificarEstadoRealPedido();
      if (cancelado || intentos >= maxIntentos) return;
      espera = respondio ? Math.min(Math.round(espera * 1.15), esperaMaxima) : Math.min(espera * 2, 120000);
      programar();
    };
    const alCambiarVisibilidad = () => {
      if (!document.hidden && pausado && !cancelado) {
        pausado = false;
        espera = intervaloMs;
        programar();
      }
    };
    document.addEventListener('visibilitychange', alCambiarVisibilidad);
    programar();
    return () => {
      cancelado = true;
      if (temporizador !== undefined) window.clearTimeout(temporizador);
      document.removeEventListener('visibilitychange', alCambiarVisibilidad);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isOpen, step, pedidoGenerado?.estadoPago, pedidoGenerado?.linkDescargaHD, pedidoGenerado?.id, pedidoGenerado?.supabaseId, volvioSinPagarEste]);

  // Si se llega al paso 5 con un pedido de Mercado Pago pendiente pero sin link de pago a mano
  // (por ejemplo, al volver de Mercado Pago con el pago rechazado/pendiente, o tras recargar la
  // página), se genera un link nuevo automáticamente para que siempre haya forma de reintentar.
  useEffect(() => {
    if (
      step !== 5 ||
      !pedidoGenerado ||
      pedidoGenerado.metodoPago !== 'mercadopago' ||
      pedidoGenerado.estadoPago === 'aprobado' ||
      mpRedirectUrl ||
      generandoLinkPago ||
      // Auditoría 03/10 noche (M9b/R7): con un pago en proceso (ticket de Rapipago/Pago Fácil ya
      // generado) o que Mercado Pago informó aprobado, NO se genera un link nuevo solo: sólo si la
      // familia confirma que igual quiere pagar de otra forma.
      bloquearPagoNuevo
    ) {
      return;
    }
    const redirigir = redirigirAlTenerLinkRef.current;
    redirigirAlTenerLinkRef.current = false;
    generarLinkDePago(pedidoGenerado, redirigir);
  }, [step, pedidoGenerado?.id, pedidoGenerado?.supabaseId, pedidoGenerado?.estadoPago, mpRedirectUrl, pedidoGenerado?.metodoPago, bloquearPagoNuevo]);

  // Mismo mecanismo que el de arriba, pero para pedidos pagados con Nave.
  useEffect(() => {
    if (
      step !== 5 ||
      !pedidoGenerado ||
      pedidoGenerado.metodoPago !== 'nave' ||
      pedidoGenerado.estadoPago === 'aprobado' ||
      naveRedirectUrl ||
      generandoLinkNave ||
      // Auditoría 03/10 noche (M9b/R7): mismo freno que Mercado Pago.
      bloquearPagoNuevo
    ) {
      return;
    }
    const redirigir = redirigirAlTenerLinkRef.current;
    redirigirAlTenerLinkRef.current = false;
    generarLinkDeNave(pedidoGenerado, redirigir);
  }, [step, pedidoGenerado?.id, pedidoGenerado?.supabaseId, pedidoGenerado?.estadoPago, naveRedirectUrl, pedidoGenerado?.metodoPago, bloquearPagoNuevo]);

  // Vuelta de Mercado Pago / Nave (?mp_status / ?nave_status + pedido_id o, para un carrito de
  // hermanos, grupo_pago_id). El estado real lo decide siempre el servidor.
  // retornoDePagoRef evita que el efecto de "sesión familiar" mande la confirmación al Paso 1.
  const retornoDePagoRef = useRef(false);
  useEffect(() => {
    try {
      const searchParams = new URLSearchParams(window.location.search);
      // La vuelta de un pago anticipado la muestra ReservaRetorno (App.tsx), no el portal.
      if (searchParams.get('reserva') === '1') return;
      const mpStatus = searchParams.get('mp_status');
      const naveStatus = searchParams.get('nave_status');
      const pedidoId = searchParams.get('pedido_id');
      const grupoPagoId = searchParams.get('grupo_pago_id');
      if ((mpStatus || naveStatus) && (pedidoId || grupoPagoId)) retornoDePagoRef.current = true;

      // Auditoría 03/10 noche (M9a/R6): la confirmación nace SIEMPRE pendiente ("estamos confirmando
      // tu pago…"), aunque la URL diga mp_status=approved (se puede escribir a mano): "¡Pago
      // Aprobado!" lo decide sólo el servidor (verificarEstadoRealPedido).
      const armarConfirmacionGrupo = (metodo: 'mercadopago' | 'nave') => {
        const estadoInicial = 'pendiente' as const;
        const pedidosGuardados = obtenerPedidosGuardados();
        const pedidosDelGrupo = pedidosGuardados.filter((item) => item.grupoPagoId === grupoPagoId);
        if (pedidosDelGrupo.length > 0) {
          const primero = pedidosDelGrupo[0].supabaseId || pedidosDelGrupo[0].id;
          // 05/10 (bug 3): también la vuelta de Nave, para que el freno de "esperando confirmación" aplique.
          if ((mpStatus || naveStatus) && primero) idsDelRetornoMpRef.current.add(primero);
          const totalGrupo = pedidosDelGrupo.reduce((acc, p) => acc + (p.total || 0), 0);
          const nombreFriendly = pedidosDelGrupo.map((p) => p.id).join(', ');
          setPedidoGenerado({
            ...pedidosDelGrupo[0],
            id: nombreFriendly,
            alumnoNombre: pedidosDelGrupo.map((p) => p.alumnoNombre).join(', '),
            kitNombre: `${pedidosDelGrupo.length} hijos/as`,
            total: totalGrupo,
            // Auditoría 03/10 noche (M9a): ver estadoInicial.
            estadoPago: estadoInicial,
          });
          setNumeroPedido(nombreFriendly);
          setStep(5);
          // El estado real (aprobado/rechazado/pendiente) es el mismo para todo el grupo — el
          // webhook de pago marca todas las filas del grupo juntas con una sola confirmación —
          // así que alcanza con consultar por el primer pedido del grupo.
          verificarEstadoRealPedido(pedidosDelGrupo[0].supabaseId || pedidosDelGrupo[0].id);
        } else {
          // Mismo fallback genérico que ya existía para el camino de un solo hijo cuando no se
          // encuentra nada en localStorage (otro navegador/dispositivo, storage limpiado, etc.)
          // — acá no hay ningún id de pedido individual para consultar el estado real, sólo el
          // grupoPagoId, que /api/pedidos/:id/status no sabe buscar.
          setNumeroPedido(grupoPagoId || '');
          setPedidoGenerado(pedidoDeRespaldo({ referencia: grupoPagoId || '', esGrupo: true, metodoPago: metodo, estadoPago: estadoInicial }));
          // /api/pedidos/:id/status ahora también resuelve por grupo_pago_id.
          if (grupoPagoId) verificarEstadoRealPedido(grupoPagoId);
          setStep(5);
        }
      };

      if (naveStatus && grupoPagoId && !mpStatus && !pedidoId) {
        armarConfirmacionGrupo('nave');
        return;
      }

      if (mpStatus && grupoPagoId && !pedidoId) {
        armarConfirmacionGrupo('mercadopago');
        return;
      }

      if (naveStatus && pedidoId && !mpStatus) {
        const pedidosGuardados = obtenerPedidosGuardados();
        const pEncontrado = pedidosGuardados.find(
          (item) => item.supabaseId === pedidoId || item.id === pedidoId
        );
        if (pEncontrado) {
          // 05/10 (bug 3): el estado lo decide el servidor; hasta que responda, pendiente (como Mercado Pago).
          setPedidoGenerado({ ...pEncontrado, estadoPago: 'pendiente' });
          setNumeroPedido(pEncontrado.id);
          if (pEncontrado.supabaseId) idsDelRetornoMpRef.current.add(pEncontrado.supabaseId);
          setStep(5);
        } else {
          setNumeroPedido(pedidoId);
          setPedidoGenerado(pedidoDeRespaldo({ referencia: pedidoId, esGrupo: false, metodoPago: 'nave', estadoPago: 'pendiente' }));
          setStep(5);
        }
        verificarEstadoRealPedido(pedidoId);
        return;
      }

      if (mpStatus && pedidoId) {
        const pedidosGuardados = obtenerPedidosGuardados();
        const pEncontrado = pedidosGuardados.find(
          (item) => item.supabaseId === pedidoId || item.id === pedidoId
        );
        if (pEncontrado) {
          // Auditoría 03/10 noche (M9a): el estado lo decide el servidor; hasta que responda, pendiente.
          setPedidoGenerado({ ...pEncontrado, estadoPago: 'pendiente' });
          setNumeroPedido(pEncontrado.id);
          if (pEncontrado.supabaseId) idsDelRetornoMpRef.current.add(pEncontrado.supabaseId);
          setStep(5);
        } else {
          setNumeroPedido(pedidoId);
          // Auditoría 03/10 noche (M9a/R6): antes nacía "aprobado" con mp_status=approved y, si el
          // servidor decía pendiente, no se corregía: se mostraba "¡Pago Aprobado!" sin confirmar.
          setPedidoGenerado(pedidoDeRespaldo({ referencia: pedidoId, esGrupo: false, metodoPago: 'mercadopago', estadoPago: 'pendiente' }));
          setStep(5);
        }
        verificarEstadoRealPedido(pedidoId);
      }
    } catch (err) {
      console.warn('Error leyendo query params de pago:', err);
    }
  }, []);

  // Sibling selector inside Family Portal (1 code for all children).
  // Auditoría 2026-09-16 (pedido de Pablo): la web y el mail de aprobación prometen "1 solo
  // Código Familiar... vas a poder alternar entre tus hijos con un solo toque" incluso si están
  // en secciones distintas, pero antes esta función solo actualizaba el nombre/grado que se
  // MUESTRA — la galería seguía mostrando siempre la sección del hijo principal, porque
  // `codigoSeccionValidado` (la única llave real que trae fotos) nunca se tocaba acá. Ahora
  // `hijosFamilia` trae, para cada hermano, el código real de SU PROPIA sección (resuelto por el
  // servidor en `/api/familia/hijos` — nunca se confía en un grado/turno/división suelto del
  // navegador para traer fotos), y cambiar de hijo cambia también esa llave.
  const [hijoSeleccionadoId, setHijoSeleccionadoId] = useState<string>('principal');
  const [hijosFamilia, setHijosFamilia] = useState<HijoConCodigoSeccion[]>([]);
  // Auditoría 03/10 noche (R12): si /api/familia/hijos falla por 429/5xx/red, la lista vacía NO
  // significa "hijo único": se avisa "No pudimos cargar a tus otros hijos" con Reintentar, y no se
  // deja seguir a comprar como si fuera uno solo (ver handleContinuarAlKit y handleCompletarPago).
  const [errorHijosFamilia, setErrorHijosFamilia] = useState<string | null>(null);
  const [reintentoHijos, setReintentoHijos] = useState(0);

  useEffect(() => {
    let cancelado = false;
    const codigoFamiliar = familiaActiva?.codigoAsignado || familiaActiva?.codigoFamiliar;
    if (!codigoFamiliar) {
      setHijosFamilia([]);
      setErrorHijosFamilia(null);
      return;
    }
    setErrorHijosFamilia(null);
    obtenerHijosDeFamiliaConEstado(codigoFamiliar, familiaActiva?.id, familiaActiva?.accesoGaleria).then((resultado) => {
      if (cancelado) return;
      if (resultado.falloTransitorio) {
        // Se conserva la lista que ya hubiera (no se borra a los hermanos por una falla pasajera).
        setErrorHijosFamilia(resultado.error || 'No pudimos cargar a tus otros hijos.');
        return;
      }
      if (resultado.codigoVencido) {
        // 14/10 (caso Noguera Cabral): sesión guardada con un código viejo (le corregimos el curso): se vuelve a ingresar.
        reingresarPorCodigoVencido();
        setCodigoAviso({ tipo: 'aviso', texto: 'Tu código de acceso cambió porque corregimos el curso de tu hijo/a. Ingresá con el código nuevo que te mandamos por email, tu nombre y tu DNI.' });
        return;
      }
      setHijosFamilia(resultado.hijos);
    });
    return () => {
      cancelado = true;
    };
  }, [familiaActiva?.codigoAsignado, familiaActiva?.codigoFamiliar, familiaActiva?.id, familiaActiva?.accesoGaleria, reintentoHijos]);

  // Pago anticipado: si el hijo/a activo ya tiene un kit pagado por adelantado, en la galería se
  // eligen las fotos y se confirman sin pasar de nuevo por el pago (ver ReservaKitAnticipada).
  const [reservaActiva, setReservaActiva] = useState<ReservaPendiente | null>(null);
  // Auditoría 03/10 (alto 6): si falla (red, 429, 5xx) alguna de las consultas de "ya pagaste" /
  // "ya tenés pedido" / reserva existente, NO se toma como "no hay": se frena el avance a la compra
  // con un aviso y un botón para reintentar. Clave = qué consulta falló; valor = mensaje.
  const [fallasVerificacion, setFallasVerificacion] = useState<Record<string, string>>({});
  const [reintentoVerificacion, setReintentoVerificacion] = useState(0);
  const marcarFallaVerificacion = (clave: string, error: string | null | undefined) =>
    setFallasVerificacion((prev) => {
      if (error) return prev[clave] === error ? prev : { ...prev, [clave]: error };
      if (!(clave in prev)) return prev;
      const { [clave]: _quitada, ...resto } = prev;
      return resto;
    });
  const errorVerificacion: string | null = Object.values(fallasVerificacion)[0] || null;
  const [confirmandoReserva, setConfirmandoReserva] = useState(false);
  // Marco legal (27/9): confirmación expresa de la personalización al elegir las fotos de una reserva.
  const [confirmaPersonalizacion, setConfirmaPersonalizacion] = useState(false);
  const [errorConfirmacionReserva, setErrorConfirmacionReserva] = useState('');
  const [resultadoReserva, setResultadoReserva] = useState<{ ok: boolean; texto: string } | null>(null);
  // 05/10 (bug 4): hijos cuya reserva pagada ya quedó con las fotos confirmadas en esta sesión
  // (valor = número de pedido). Para ellos la galería queda en modo "terminado": no se ofrece
  // "Elegir Kit y Formato" ni se deja pagar otra vez.
  const [reservaConfirmadaPorHijo, setReservaConfirmadaPorHijo] = useState<Record<string, string>>({});
  // 05/10 (bug 4): la familia tocó "Sí, quiero hacer otro pedido" para un hijo que ya tiene uno pagado.
  const [quiereOtroPedido, setQuiereOtroPedido] = useState(false);
  // 05/10 (bug 4): ids de reservas ya confirmadas en esta sesión — si el servidor las devolviera
  // de nuevo al re-consultar, no se vuelve a ofrecer "Confirmar mis fotos".
  const reservasConfirmadasRef = useRef<Set<string>>(new Set());
  useEffect(() => {
    let cancelado = false;
    setReservaActiva(null);
    // 05/10 (bug 4): el "¡Listo! Guardamos tus fotos…" del hijo recién confirmado se conserva.
    if (!reservaConfirmadaPorHijo[hijoSeleccionadoId]) setResultadoReserva(null);
    if (!codigoSeccionValidado || !nombreAlumno.trim()) {
      marcarFallaVerificacion('reserva', null);
      return;
    }
    // Auditoría 03/10 noche (contrato 5): con la llave de galería de la familia (las reservas PAGADAS
    // vienen igual con o sin ella: el flujo de elegir las fotos de un kit pagado no cambia).
    obtenerEstadoReserva(codigoSeccionValidado, nombreAlumno.trim(), { familia: familiaActiva?.id, acceso: familiaActiva?.accesoGaleria }).then((estado) => {
      if (cancelado) return;
      setReservaActiva(estado.reserva && estado.reserva.id && reservasConfirmadasRef.current.has(estado.reserva.id) ? null : estado.reserva);
      marcarFallaVerificacion('reserva', estado.falloTransitorio ? estado.error || 'No pudimos verificar si ya tenés un kit pagado.' : null);
    });
    return () => {
      cancelado = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [codigoSeccionValidado, nombreAlumno, reintentoVerificacion, familiaActiva?.id, familiaActiva?.accesoGaleria]);

  // Kits ya pagados por adelantado de CADA hermano: esos chicos no entran al carrito de compra
  // normal (sería cobrarles dos veces); sus fotos se confirman aparte con "Confirmar mis fotos".
  const [reservasPorHijo, setReservasPorHijo] = useState<Record<string, boolean>>({});
  // Por hermano: ¿su curso tiene fotos? ¿ya tiene un pedido pagado? Un hermano sin fotos o con su
  // pedido ya pago no bloquea "Elegir Kit y Formato" (antes lo exigía y la familia no podía comprar).
  // Auditoría 03/10 noche (M8a/R3): `tienePedidoPendiente` = ya tiene un pedido normal esperando el pago.
  const [estadoHermanos, setEstadoHermanos] = useState<Record<string, { fotosDisponibles: boolean; tienePedidoPagado: boolean; tienePedidoPendiente?: boolean }>>({});
  // Auditoría 03/10 noche (M8a/R3 y revisión M1): qué decidió la familia con cada hermano que ya tiene
  // un pedido esperando el pago — 'incluir' (con confirmación explícita) o 'sin' (seguir sin él). Sin
  // decisión no bloquea ni entra solo al carrito; pero si ya le eligió las fotos en este carrito, no se
  // deja pagar hasta que decida (antes quedaba afuera sin que nadie lo eligiera).
  const [decisionHermanoPendiente, setDecisionHermanoPendiente] = useState<Record<string, 'incluir' | 'sin'>>({});
  // Hermanos incluidos en el checkout en curso (ids todavía sin confirmar). Si el carrito ya se
  // registró pero falló algo después (por ejemplo, sumar la reserva) y al re-consultar el servidor
  // dice que ese hermano "tiene un pedido pendiente" (¡el recién creado!), se lo sigue incluyendo:
  // así el reintento usa los mismos ids y no genera filas duplicadas.
  const incluidosEnCheckoutRef = useRef<Set<string>>(new Set());
  const [confirmandoIncluirHermano, setConfirmandoIncluirHermano] = useState<string | null>(null);
  // Reservas de hermanos SIN fotos que se suman a esta compra (pedido de Pablo, 25/9: si un hermano
  // tiene fotos, primero se eligen las suyas y todo se paga junto).
  const [reservasParaSumar, setReservasParaSumar] = useState<ReservaParaSumar[]>([]);
  // Pedido de Pablo (27/9): los hermanos SIN fotos tienen que tener decidido su kit (reservar uno
  // de los dos o "Ahora no") antes de pagar la compra del hermano con fotos. Guarda quién decidió.
  const [kitHermanoDecidido, setKitHermanoDecidido] = useState<Record<string, boolean>>({});
  const [avisoKitHermano, setAvisoKitHermano] = useState('');
  // Al volver de decidir el kit de un hermano sin fotos, se avanza solo al kit/pago del hermano
  // con fotos si ya tenía sus 3 fotos elegidas.
  const [irAlKitDe, setIrAlKitDe] = useState<string | null>(null);
  // Hermanos con reserva ya registrada (paga o esperando transferencia): no se les vuelve a preguntar.
  const [reservaRegistradaPorHijo, setReservaRegistradaPorHijo] = useState<Record<string, boolean>>({});
  const claveHijosReserva = hijosFamilia.map((h) => `${h.id}|${h.codigoSeccion}|${h.nombreCompleto}`).join(';');
  useEffect(() => {
    let cancelado = false;
    Promise.all(
      hijosFamilia.map(async (h) => [h.id, await obtenerEstadoReserva(h.codigoSeccion, h.nombreCompleto, { familia: familiaActiva?.id, acceso: familiaActiva?.accesoGaleria })] as const)
    ).then((pares) => {
      if (cancelado) return;
      const fallida = pares.find(([, e]) => e.falloTransitorio);
      marcarFallaVerificacion('hermanos', fallida ? fallida[1].error || 'No pudimos verificar los kits de tus hijos/as.' : null);
      setReservasPorHijo(Object.fromEntries(pares.map(([id, e]) => [id, Boolean(e.reserva?.pagada)])));
      setReservaRegistradaPorHijo(
        Object.fromEntries(pares.map(([id, e]) => [id, Boolean(e.reserva && (e.reserva.pagada || e.reserva.metodoPago === 'transferencia'))]))
      );
      // Sólo con respuesta confirmada del servidor: si la consulta falla, el hermano sigue contando
      // como pendiente (mejor pedir sus fotos de más que dejar pasar una compra incompleta).
      setEstadoHermanos(
        Object.fromEntries(
          pares
            .filter(([, e]) => e.ok)
            .map(([id, e]) => [id, { fotosDisponibles: e.fotosDisponibles, tienePedidoPagado: e.tienePedidoPagado, tienePedidoPendiente: Boolean(e.tienePedidoPendiente) }])
        )
      );
    });
    return () => {
      cancelado = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [claveHijosReserva, reintentoVerificacion, familiaActiva?.id, familiaActiva?.accesoGaleria]);
  // Auditoría 03/10 noche (M8a/R3): hermano (no el activo) con un pedido esperando el pago que la
  // familia NO eligió incluir: no se le exigen fotos ni entra solo al carrito.
  const hermanoIncluidoEnIntento = (hijoId: string) => checkoutIdsRef.current !== null && incluidosEnCheckoutRef.current.has(hijoId);
  const hermanoConPedidoPendiente = (hijoId: string) =>
    hijoId !== hijoSeleccionadoId && Boolean(estadoHermanos[hijoId]?.tienePedidoPendiente) && !hermanoIncluidoEnIntento(hijoId);
  const hermanoPendienteExcluido = (hijoId: string) => hermanoConPedidoPendiente(hijoId) && decisionHermanoPendiente[hijoId] !== 'incluir';
  // Revisión M1: ya le eligió las fotos en este carrito pero todavía no dijo si lo incluye o no.
  const hermanoPendienteSinDecidir = (hijoId: string) =>
    hermanoConPedidoPendiente(hijoId) && !decisionHermanoPendiente[hijoId] && Boolean((carritoHijosRef.current[hijoId] || carritoHijos[hijoId])?.completo);
  const tieneKitPagadoPorAdelantado = (hijoId: string) => Boolean(reservasPorHijo[hijoId]);

  const confirmarFotosDeReserva = async () => {
    if (!reservaActiva || !codigoSeccionValidado) return;
    // Auditoría 05/10: la reserva pagada vino sin id porque la sesión no tiene la llave de la familia.
    if (!reservaActiva.id) {
      setResultadoReserva({ ok: false, texto: 'Para confirmar las fotos de tu kit pagado volvé a ingresar con tu nombre y DNI (lo pedimos una sola vez).' });
      return;
    }
    const reservaId = reservaActiva.id;
    if (!fotoGrupalSeleccionadaValida || !fotoIndividualSeleccionadaValida || !terceraFotoOk) {
      setResultadoReserva({ ok: false, texto: `Elegí una foto grupal, una individual${terceraFotoRequerida ? ` y ${textosTercera.una}` : ''} antes de confirmar.` });
      return;
    }
    if (!confirmaPersonalizacion) {
      setErrorConfirmacionReserva('Tildá la casilla de confirmación que está arriba del botón.');
      return;
    }
    setErrorConfirmacionReserva('');
    setConfirmandoReserva(true);
    const resultado = await elegirFotosDeReserva(
      reservaId,
      codigoSeccionValidado,
      {
        grupalId: fotoSeleccionadaGrupal,
        individualId: fotoSeleccionadaIndividual,
        docenteId: fotoSeleccionadaDocente,
        ...(sinFoto.length > 0 ? { sinFoto } : {}),
      },
      confirmaPersonalizacion,
      // Revisión 03/10 noche: llave de la familia, para que el servidor valide la foto individual con
      // el hijo de la inscripción. Auditoría 05/10: el servidor la exige (o la llave del pedido).
      { familia: familiaActiva?.id, acceso: familiaActiva?.accesoGaleria, grupoPagoId: reservaActiva.grupoPagoId }
    );
    setConfirmandoReserva(false);
    // 05/10 (bug 9): un segundo "Confirmar" responde 409 "ya fueron elegidas" — es el mismo éxito.
    const yaElegidas = !resultado.success && /ya fueron elegidas/i.test(resultado.error || '');
    if (resultado.success || yaElegidas) {
      const numeroPedidoReserva = resultado.pedidoFriendlyId || reservaActiva.pedidoFriendlyId;
      reservasConfirmadasRef.current.add(reservaId);
      setReservaActiva(null);
      setReservasPorHijo((prev) => ({ ...prev, [hijoSeleccionadoId]: false }));
      // 05/10 (bug 4): queda en modo "terminado" y se refresca el estado del hijo (pedido pagado).
      setReservaConfirmadaPorHijo((prev) => ({ ...prev, [hijoSeleccionadoId]: numeroPedidoReserva }));
      setCarritoHijos((prev) => {
        if (!prev[hijoSeleccionadoId]) return prev;
        const { [hijoSeleccionadoId]: _confirmado, ...resto } = prev;
        return resto;
      });
      setReintentoVerificacion((n) => n + 1);
      setResultadoReserva({
        ok: true,
        texto: yaElegidas
          ? `Las fotos del pedido ${numeroPedidoReserva} ya estaban confirmadas. La descarga en alta resolución te llega por email.`
          : `¡Listo! Guardamos tus fotos del pedido ${numeroPedidoReserva}. En unos minutos te llega por email la descarga en alta resolución.`,
      });
    } else {
      setResultadoReserva({ ok: false, texto: resultado.error || 'No se pudo guardar tu elección.' });
    }
  };

  // Carrito multi-hijo (ver interfaz SeleccionCarritoHijo más arriba, fuera del componente).
  const [carritoHijos, setCarritoHijos] = useState<Record<string, SeleccionCarritoHijo>>({});
  // Espejo en un ref para poder leer el carrito más reciente dentro de efectos/callbacks sin
  // tener que agregar `carritoHijos` a sus dependencias (evita relanzar esos efectos de más).
  const carritoHijosRef = useRef(carritoHijos);
  useEffect(() => {
    carritoHijosRef.current = carritoHijos;
  }, [carritoHijos]);

  // Restaura la selección guardada del hijo que queda activo (corre después de la limpieza de la
  // galería). Cada campo se fija siempre, con '' si no hay nada válido: nunca queda la foto de otro hermano.
  useEffect(() => {
    const guardado = carritoHijosRef.current[hijoSeleccionadoId];
    if (!guardado) return;
    const patio = fotosDisponibles.filter((f) => f.categoria === 'patio');
    const sf = guardado.sinFoto || [];
    setSinFoto(sf);
    setFotoSeleccionadaIndividual(idValidoEnLugar(fotosDisponibles, guardado.fotoSeleccionadaIndividual, 'individual', sf));
    setFotoSeleccionadaGrupal(idValidoEnLugar(fotosDisponibles, guardado.fotoSeleccionadaGrupal, 'grupal', sf));
    setFotoSeleccionadaDocente(idValidoEnLugar(fotosDisponibles, guardado.fotoSeleccionadaDocente, 'docente', sf));
    setFotosSueltasSeleccionadas(
      guardado.fotosSueltasSeleccionadas?.length
        ? guardado.fotosSueltasSeleccionadas.filter((fid) => patio.some((f) => f.id === fid))
        : []
    );
  }, [fotosDisponibles, hijoSeleccionadoId]);

  const seleccionarHijo = (id: string) => {
    if (id === hijoSeleccionadoId) return;

    // El cartel de "ya tenés un pedido" es específico del alumno/a que estaba activo — al
    // cambiar de hijo/a se limpia, así no queda mostrado por error para otro hermano.
    setPedidoExistente(null);
    setQuiereOtroPedido(false); // 05/10 (bug 4): la decisión era para el hijo que estaba activo.

    // Auditoría 03/10 noche (R13): si la galería del hijo saliente todavía está cargando (o falló),
    // sus fotos en pantalla están vacías SÓLO porque no llegó la galería — guardar ese estado vacío
    // pisaba las fotos que ya había elegido (pasaba al alternar rápido entre hermanos de secciones
    // distintas). En ese caso se conserva lo que ya estaba guardado para él.
    const galeriaSalienteSinCargar = estadoGaleria === 'cargando' || estadoGaleria === 'error';
    // 05/10 (bug 1): la identidad del hijo saliente se toma de `hijosFamilia` (lo que dijo el
    // servidor para ESE id), no del estado suelto `nombreAlumno`/`codigoSeccionValidado`, que al
    // reabrir el portal podía haber quedado con los datos del alumno principal.
    const hijoSaliente = hijosFamilia.find((h) => h.id === hijoSeleccionadoId);
    // El curso en pantalla lo resolvió el servidor a partir de la galería (ver la carga de la
    // galería): se conserva sólo si en pantalla estaba realmente ESTE hijo.
    const estadoEsDeEsteHijo = !hijoSaliente || hijoSaliente.nombreCompleto === nombreAlumno;
    if (!galeriaSalienteSinCargar) setCarritoHijos((prev) => ({
      ...prev,
      [hijoSeleccionadoId]: {
        hijoId: hijoSeleccionadoId,
        nombreCompleto: hijoSaliente?.nombreCompleto || nombreAlumno,
        colegioNombre: selectedColegio?.nombre || hijoSaliente?.colegioNombre,
        grado: estadoEsDeEsteHijo ? grado : hijoSaliente?.grado || grado,
        division: estadoEsDeEsteHijo ? division : hijoSaliente?.division || division,
        turno: estadoEsDeEsteHijo ? turno : hijoSaliente?.turno || turno,
        codigoSeccion: hijoSaliente?.codigoSeccion || codigoSeccionValidado || '',
        kitId: selectedKit.id,
        kitNombre: selectedKit.nombre,
        extraCarpetas,
        fotoSeleccionadaIndividual,
        fotoSeleccionadaGrupal,
        fotoSeleccionadaDocente,
        fotosSueltasSeleccionadas,
        sinFoto,
        total,
        completo: fotoGrupalSeleccionadaValida && fotoIndividualSeleccionadaValida && terceraFotoOk,
      },
    }));

    setHijoSeleccionadoId(id);
    const guardadoDestino = carritoHijosRef.current[id];
    // 05/10 (bug 5): el kit es uno solo para todos los hijos del carrito — al cambiar de hijo se
    // conserva el elegido (antes el hermano "nuevo" volvía a Kit Impreso y el guardado se congelaba
    // con el kit que tuviera en ese momento). Las carpetas extra sí son por hijo.
    setExtraCarpetas(guardadoDestino?.extraCarpetas || 0);
    // 21/09 (hermanos en el mismo curso: `fotosDisponibles` no cambia de referencia y los efectos no se disparan):
    // acá se calculan de forma síncrona los 4 campos de fotos desde `guardadoDestino` ('' si no hay o ya no existe),
    // así no queda ni un frame con las fotos del hermano anterior; si la galería del destino recién carga, el efecto corrige.
    const patioDestino = fotosDisponibles.filter((f) => f.categoria === 'patio');
    const sfDestino = guardadoDestino?.sinFoto || [];
    setSinFoto(sfDestino);
    sinFotoRef.current = sfDestino;
    setFotoSeleccionadaIndividual(idValidoEnLugar(fotosDisponibles, guardadoDestino?.fotoSeleccionadaIndividual, 'individual', sfDestino));
    setFotoSeleccionadaGrupal(idValidoEnLugar(fotosDisponibles, guardadoDestino?.fotoSeleccionadaGrupal, 'grupal', sfDestino));
    setFotoSeleccionadaDocente(idValidoEnLugar(fotosDisponibles, guardadoDestino?.fotoSeleccionadaDocente, 'docente', sfDestino));
    setFotosSueltasSeleccionadas(
      guardadoDestino?.fotosSueltasSeleccionadas?.length
        ? guardadoDestino.fotosSueltasSeleccionadas.filter((fid) => patioDestino.some((f) => f.id === fid))
        : []
    );

    const hijoConCodigo = hijosFamilia.find((h) => h.id === id);
    if (hijoConCodigo) {
      // Esta es la parte que antes faltaba: sin esto, la galería mostrada nunca cambiaba de
      // sección al tocar otro hijo, aunque el nombre de arriba sí se actualizara.
      setCodigoSeccionValidado(hijoConCodigo.codigoSeccion);
      if (hijoConCodigo.grado) setGrado(hijoConCodigo.grado);
      if (hijoConCodigo.division) setDivision(hijoConCodigo.division);
      if (hijoConCodigo.turno) setTurno(hijoConCodigo.turno);
      setNombreAlumno(hijoConCodigo.nombreCompleto);
      return;
    }
    // Respaldo (no debería pasar salvo que `hijosFamilia` todavía no haya terminado de cargar):
    // al menos deja el nombre/grado mostrados coherentes con lo que ya sabíamos localmente.
    if (!familiaActiva) return;
    if (id === 'principal') {
      setNombreAlumno(`${familiaActiva.alumnoNombre} ${familiaActiva.alumnoApellido}`);
      if (familiaActiva.grado) setGrado(familiaActiva.grado);
      if (familiaActiva.division) setDivision(familiaActiva.division);
      if (familiaActiva.turno) setTurno(familiaActiva.turno);
    } else {
      const h = familiaActiva.hermanos?.find((item) => item.id === id);
      if (h) {
        setNombreAlumno(`${h.alumnoNombre} ${h.alumnoApellido}`);
        if (h.grado) setGrado(h.grado);
        if (h.division) setDivision(h.division);
        if (h.turno) setTurno(h.turno);
      }
    }
  };

  // Sync preselected options and active family registration
  useEffect(() => {
    if (isOpen) {
      const fam = obtenerFamiliaActiva();
      // 05/10 (bug 1): el modal queda montado al cerrarse. Si se reabre con la MISMA familia ya
      // cargada y un hermano activo, antes se volvía a poner el nombre/curso/código del alumno
      // principal sin tocar `hijoSeleccionadoId`: el carrito terminaba con dos filas del mismo
      // alumno (y el hermano desaparecía). Con la misma familia no se pisan los datos del alumno.
      const mismaFamiliaYaCargada = Boolean(fam && familiaActiva && familiaActiva.id === fam.id);
      setFamiliaActiva(fam);
      if (fam) {
        setTutorNombre(fam.padreNombre);
        setTutorWhatsapp(fam.telefonoWhatsApp);
        setTutorEmail(fam.email);
        if (!mismaFamiliaYaCargada) {
          // Otra familia (u otra sesión): se vuelve al alumno principal y se vacía el carrito.
          setHijoSeleccionadoId('principal');
          setCarritoHijos({});
          setNombreAlumno(`${fam.alumnoNombre} ${fam.alumnoApellido}`);
          if (fam.turno) setTurno(fam.turno);
          if (fam.grado) setGrado(fam.grado);
          if (fam.division) setDivision(fam.division);
        }
        if (fam.codigoFamiliar) {
          setCodigoAcceso(fam.codigoFamiliar);
          setCodigoValidadoMsg(`Código de acceso activo: ${fam.codigoFamiliar}`);
          // Al reabrir el portal, restaurar también la llave usada por la consulta de
          // galería. Antes sólo se completaba el campo visible y la pantalla quedaba
          // falsamente en "Esperando fotos" aunque el curso ya tuviera imágenes.
          if (!mismaFamiliaYaCargada) setCodigoSeccionValidado(fam.codigoAsignado || fam.codigoFamiliar);
        }
        // Se vuelve a correr cuando carga la lista de colegios (dependencia `colegios`), así que
        // el colegio "de respaldo" se reemplaza por el real apenas llega.
        const col = colegioDeLaFamilia(colegios, fam);
        if (col) setSelectedColegio(col);
      } else {
        // El modal permanece montado cuando se cierra. Si ya no existe una sesión familiar,
        // eliminar todo dato sensible retenido por la instancia anterior antes de mostrarlo.
        setFamiliaActiva(null);
        setHijoSeleccionadoId('principal');
        setCarritoHijos({});
        // Se conserva el código que llegó precargado ("Probar en Portal", link compartido o, desde
        // el 03/10 noche, el link "Confirmar mi email" del correo — ver confirmarAccesoUsadoRef).
        setCodigoAcceso(preselectedCodigo || codigoPrecargadoRef.current || '');
        setCodigoValidadoMsg(null);
        setCodigoErrorMsg(null);
        setCodigoSeccionValidado(null);
        setFotosDisponibles([]);
        setFotoSeleccionadaIndividual('');
        setFotoSeleccionadaGrupal('');
        setFotoSeleccionadaDocente('');
        setFotosSueltasSeleccionadas([]);
        setSinFoto([]);
        setNombreAlumno('');
        setTutorNombre('');
        setTutorWhatsapp('');
        setTutorEmail('');
        // Auditoría 2026-09-23 (bug real): al volver de Mercado Pago/Nave en un navegador sin la
        // sesión familiar guardada (muy común en el celular: la app de pago abre la vuelta en otro
        // navegador), el efecto de retorno ponía el Paso 5 (confirmación) y este efecto — que corre
        // después, y de nuevo cuando termina de cargar la lista de colegios — lo pisaba con el
        // Paso 1: la familia no veía nunca la confirmación de su pago.
        if (!retornoDePagoRef.current) setStep(1);
      }
    }
  }, [isOpen, colegios]);

  useEffect(() => {
    if (preselectedColegioId) {
      const col = colegios.find((c) => c.id === preselectedColegioId);
      if (col) setSelectedColegio(col);
    }
  }, [preselectedColegioId, colegios]);

  useEffect(() => {
    // Con un código de sección ya validado, el curso lo define el servidor (ver la carga de la
    // galería más arriba) — no se lo pisa con el primero de la lista del colegio.
    if (selectedColegio && !codigoSeccionValidado) {
      if (!grado || !selectedColegio.grados.includes(grado)) {
        setGrado(selectedColegio.grados[0] || '');
      }
      if (!division || !selectedColegio.divisiones.includes(division)) {
        setDivision(selectedColegio.divisiones[0] || '');
      }
      if (!turno || !selectedColegio.turnos.includes(turno)) {
        setTurno(selectedColegio.turnos[0] || '');
      }
    }
  }, [selectedColegio]);

  useEffect(() => {
    // Auditoría 2026-09-23 (bug real): la tarjeta "Fotos Sueltas de Eventos" de la home también
    // llama acá, pero ese kit no se vende suelto desde el portal (las fotos de eventos se suman
    // como "Otras Fotos" a cualquiera de los dos kits): quedaba preseleccionado un kit que el
    // servidor rechaza, y la familia recién se enteraba al querer pagar ("Kit no reconocido").
    if (preselectedKitId && preselectedKitId !== 'kit-evento-suelto') {
      const k = KITS_DISPONIBLES.find((item) => item.id === preselectedKitId && kitOfrecido(item.id));
      if (k) setSelectedKit(k);
    }
  }, [preselectedKitId]);

  // Function to validate and bind course code, family access code, or school code
  const validarCodigoIngresado = async (codigoInput: string, tutorNombreInput?: string, dniInput?: string) => {
    const clean = codigoInput.trim().toUpperCase();
    if (!clean) {
      setCodigoErrorMsg('Por favor ingresá un código para validar.');
      setCodigoValidadoMsg(null);
      return false;
    }

    // Único camino que desbloquea fotos reales: código de la sección + nombre y DNI del tutor (el
    // código lo comparte el curso). Un teléfono/email nunca entrega el código acá (se reenvía por correo).
    const resultadoBusqueda = await buscarMiInscripcion(clean, tutorNombreInput, dniInput);
    setCodigoAviso(null);
    // Auditoría 03/10 (alto 22): un 429 ("demasiados intentos") o una falla de red/servidor se
    // mostraban como "código no encontrado" y la familia pensaba que su código estaba mal.
    if (resultadoBusqueda.errorConexion) {
      setCodigoErrorMsg(resultadoBusqueda.errorConexion);
      setCodigoValidadoMsg(null);
      return false;
    }
    // Auditoría 03/10 noche (contrato 2): la familia todavía no confirmó su email. Es un aviso (con
    // el texto del servidor), no un error de datos, y no se reintenta solo.
    if (resultadoBusqueda.requiereConfirmacion) {
      setCodigoErrorMsg(null);
      setCodigoValidadoMsg(null);
      setCodigoSeccionValidado(null);
      setCodigoAviso({ tipo: 'aviso', texto: resultadoBusqueda.avisoConfirmacion || 'Antes de ingresar, confirmá tu email con el botón del correo que te mandamos.' });
      return false;
    }
    // Auditoría 03/10 noche (contrato 4): búsqueda por teléfono/email de una inscripción pendiente o
    // rechazada — el servidor sólo informa estado y colegio.
    if (resultadoBusqueda.estadoInscripcion) {
      setCodigoErrorMsg(null);
      setCodigoValidadoMsg(null);
      setCodigoSeccionValidado(null);
      setCodigoAviso({
        tipo: 'aviso',
        texto: textoEstadoInscripcion(resultadoBusqueda.estadoInscripcion.estado, resultadoBusqueda.estadoInscripcion.colegioNombre),
      });
      return false;
    }
    if (resultadoBusqueda.requiereDatosTutor) {
      const curso = resultadoBusqueda.cursoInfo;
      const descCurso = curso ? `${curso.grado || ''} "${curso.division || ''}" · Turno ${curso.turno || ''} (${curso.colegioNombre || ''})`.trim() : null;
      setCodigoErrorMsg(
        resultadoBusqueda.datosNoCoinciden
          ? `El nombre y DNI que ingresaste no coinciden con ninguna familia registrada con este código${descCurso ? ` (${descCurso})` : ''}. Revisá que estén escritos igual que en tu inscripción.`
          : `Este código es de todo el curso${descCurso ? ` (${descCurso})` : ''}. Para identificar a tu familia, completá también el nombre y el DNI del tutor con el que te inscribiste.`
      );
      setCodigoValidadoMsg(null);
      setCodigoSeccionValidado(null);
      return false;
    }
    if (resultadoBusqueda.yaRegistrado) {
      setCodigoErrorMsg(
        resultadoBusqueda.emailReenviado
          ? `Por seguridad no mostramos el código acá escribiendo el teléfono o email. Ya te lo reenviamos a ${resultadoBusqueda.emailDestino || 'tu correo registrado'} — copialo desde ahí y pegalo en este casillero.`
          : 'Encontramos tu inscripción, pero no pudimos reenviarte el código por correo en este momento. Contactá al equipo fotográfico para que te lo reenvíen desde el panel.'
      );
      setCodigoValidadoMsg(null);
      setCodigoSeccionValidado(null);
      return false;
    }
    const famFound = resultadoBusqueda.inscripcion;
    if (famFound && famFound.estado === 'pendiente') {
      setCodigoErrorMsg('Tu inscripción todavía está pendiente de validación por el equipo fotográfico. Te avisaremos por email en cuanto tengas tu código de acceso.');
      setCodigoValidadoMsg(null);
      setCodigoSeccionValidado(null);
      return false;
    }
    if (famFound && famFound.estado === 'aceptado' && famFound.codigoAsignado) {
      guardarFamiliaActiva(famFound);
      setFamiliaActiva(famFound);
      setHijoSeleccionadoId('principal');

      setTutorNombre(famFound.padreNombre);
      setTutorWhatsapp(famFound.telefonoWhatsApp);
      setTutorEmail(famFound.email);
      setNombreAlumno(`${famFound.alumnoNombre} ${famFound.alumnoApellido}`);
      if (famFound.turno) setTurno(famFound.turno);
      if (famFound.grado) setGrado(famFound.grado);
      if (famFound.division) setDivision(famFound.division);

      const colMatch = colegioDeLaFamilia(colegios, famFound);
      if (colMatch) setSelectedColegio(colMatch);

      const totalHijos = 1 + (famFound.hermanos?.length || 0);
      const nombresHijos = [
        famFound.alumnoNombre,
        ...(famFound.hermanos?.map((h) => h.alumnoNombre) || [])
      ].join(', ');

      setCodigoValidadoMsg(
        `¡Código de acceso verificado (${famFound.codigoFamiliar})! Familia ${famFound.padreNombre} · ${totalHijos} hijo${totalHijos > 1 ? 's' : ''} (${nombresHijos})`
      );
      setCodigoErrorMsg(null);
      setCodigoSeccionValidado(famFound.codigoAsignado);
      setSolicitudCodigoEnviada(false);
      setSolicitudCodigoMensaje('');
      setMostrarFormSolicitudCodigo(false);
      return true;
    }

    // Auditoría 2026-09-09: acá había un paso más que buscaba el código contra el sistema
    // viejo de secciones de nivel inicial (códigos inventados en localStorage, ver antiguo
    // src/data/codigosCursos.ts). Ya no desbloqueaba fotos reales por sí solo, y además
    // siempre asumía que el colegio era el primero de la lista (`colegios[0]`), lo cual es
    // incorrecto para cualquier colegio que no sea ese. Se saca del todo: si el código no es
    // ni una familia real ni el código general de un colegio, se informa el error de una.

    // 2. Código general de institución (ej: ISBA2026): sólo identifica el colegio para
    // facilitar la búsqueda — tampoco desbloquea fotos reales por sí solo.
    const colFound = colegios.find(
      (c) => c.codigoAcceso.toUpperCase() === clean
    );
    if (colFound) {
      setSelectedColegio(colFound);
      setCodigoValidadoMsg(`Institución reconocida: ${colFound.nombre}. Para ver las fotos reales, ingresá el código de acceso de tu curso.`);
      setCodigoErrorMsg(null);
      setCodigoSeccionValidado(null);
      setSolicitudCodigoEnviada(false);
      setSolicitudCodigoMensaje('');
      setMostrarFormSolicitudCodigo(false);
      return true;
    }

    setCodigoErrorMsg(`Código "${codigoInput}" no encontrado. Verificá si está bien escrito o seleccioná tu curso abajo.`);
    setCodigoValidadoMsg(null);
    setCodigoSeccionValidado(null);
    return false;
  };

  // Auditoría 03/10 noche (contrato 3, revisado): link del email del código
  // "/?confirmar-acceso=<id>.<token>". Ya NO se confirma solo al abrir: se muestra una pantallita que
  // pide el DNI de la persona que hizo la inscripción y recién al tocar "Confirmar" se llama al
  // servidor ({ id, token, dni }). El resultado (y el error) vive en su propio estado, así no lo borra
  // el efecto de apertura cuando termina de cargar la lista de colegios (B4).
  const [confirmacionAcceso, setConfirmacionAcceso] = useState<{ valor: string; dni: string; enviando: boolean; error: string | null } | null>(null);
  const confirmarAccesoUsadoRef = useRef(false);
  const sacarParametroConfirmarAcceso = () => {
    try {
      const url = new URL(window.location.href);
      if (!url.searchParams.has('confirmar-acceso')) return;
      url.searchParams.delete('confirmar-acceso');
      window.history.replaceState(null, '', url.pathname + url.search + url.hash);
    } catch {
      /* URL inválida: no hay nada que sacar */
    }
  };
  useEffect(() => {
    if (!isOpen || confirmarAccesoUsadoRef.current || typeof window === 'undefined') return;
    let valor = '';
    try {
      valor = new URLSearchParams(window.location.search).get('confirmar-acceso') || '';
    } catch {
      valor = '';
    }
    if (!valor) return;
    confirmarAccesoUsadoRef.current = true;
    setConfirmacionAcceso({ valor, dni: '', enviando: false, error: null });
  }, [isOpen]);
  const cerrarConfirmacionAcceso = () => {
    setConfirmacionAcceso(null);
    sacarParametroConfirmarAcceso();
  };
  const enviarConfirmacionAcceso = async () => {
    if (!confirmacionAcceso || confirmacionAcceso.enviando) return;
    const { valor, dni } = confirmacionAcceso;
    if (dni.length < 6) {
      setConfirmacionAcceso((prev) => (prev ? { ...prev, error: 'Escribí el DNI completo, sólo números.' } : prev));
      return;
    }
    setConfirmacionAcceso((prev) => (prev ? { ...prev, enviando: true, error: null } : prev));
    const resultado = await confirmarAccesoInscripcion(valor, dni);
    if (!resultado.success) {
      // DNI que no coincide u otro error: se muestra tal cual (en rojo) y se deja reintentar.
      setConfirmacionAcceso((prev) => (prev ? { ...prev, enviando: false, error: resultado.error || 'No pudimos confirmar tu email.' } : prev));
      return;
    }
    if (resultado.codigo) {
      // Mismo criterio que "Probar en Portal": si este navegador tenía guardada OTRA familia (de
      // otro curso), se cierra esa sesión para que se pueda ingresar con el código confirmado.
      const guardada = obtenerFamiliaActiva();
      const normalizar = (c?: string | null) => String(c || '').replace(/[^A-Z0-9]/gi, '').toUpperCase();
      if (guardada && ![guardada.codigoAsignado, guardada.codigoFamiliar].some((c) => normalizar(c) === normalizar(resultado.codigo))) {
        cerrarSesionFamilia();
        setFamiliaActiva(null);
        setCodigoValidadoMsg(null);
        setCodigoSeccionValidado(null);
      }
      codigoPrecargadoRef.current = resultado.codigo;
      setCodigoAcceso(resultado.codigo);
    }
    setCodigoErrorMsg(null);
    setCodigoAviso({ tipo: 'ok', texto: '¡Listo! Confirmaste tu email. Ingresá con tu nombre y DNI.' });
    setConfirmacionAcceso(null);
    sacarParametroConfirmarAcceso();
  };

  useEffect(() => {
    // Auditoría 2026-09-22: un código que llega precargado por URL (link compartido) ya no
    // alcanza por sí solo para validar — ahora hace falta también el nombre y DNI del tutor (ver
    // `validarCodigoIngresado`), que nadie manda por ese link. Se precarga el casillero del
    // código para que la familia no tenga que volver a escribirlo, pero se le pide igual que
    // complete sus datos antes de poder entrar.
    if (preselectedCodigo) {
      // 2/10 ("Probar en Portal" desde el panel): si el navegador tenía guardada OTRA familia,
      // se cierra esa sesión para que se pueda ingresar con el código que se quiere probar (antes
      // quedaba la familia vieja y la pantalla "Acceso validado" vacía).
      const guardada = obtenerFamiliaActiva();
      const normalizar = (c?: string | null) => String(c || '').replace(/[^A-Z0-9]/gi, '').toUpperCase();
      if (guardada && ![guardada.codigoAsignado, guardada.codigoFamiliar].some((c) => normalizar(c) === normalizar(preselectedCodigo))) {
        cerrarSesionFamilia();
        setFamiliaActiva(null);
        setCodigoValidadoMsg(null);
        setCodigoSeccionValidado(null);
      }
      setCodigoAcceso(preselectedCodigo);
    }
  }, [preselectedCodigo]);

  // Chequeo automático de "ya tenés un pedido" para el alumno/a activo (también al cambiar de hijo).
  // OJO: todo hook va ANTES del `if (!isOpen) return null;` (Reglas de los Hooks; error #310 del 23/9).
  useEffect(() => {
    // `codigoSeccionValidado` sólo actúa de guardia (hubo una identificación real); la consulta
    // usa colegio/grado/turno/división — ver verificarPedidoExistente (fix 23/9).
    if (!codigoSeccionValidado || !nombreAlumno || !selectedColegio?.id || !grado || !turno) {
      setPedidoExistente(null);
      marcarFallaVerificacion('pedido', null);
      return;
    }
    let cancelado = false;
    setVerificandoPedidoExistente(true);
    // Auditoría 03/10 (alto 6): una falla de la consulta ya no cuenta como "no hay pedido".
    // Auditoría 05/10: con la llave de la familia el servidor devuelve el UUID (comprobante / mejora).
    consultarPedidoExistente({ codigo: codigoSeccionValidado, alumnoNombre: nombreAlumno, familia: familiaActiva?.id, acceso: familiaActiva?.accesoGaleria })
      .then((resultado) => {
        if (cancelado) return;
        setPedidoExistente(resultado.ok === true ? resultado.pedido : null);
        marcarFallaVerificacion('pedido', 'error' in resultado ? resultado.error : null);
      })
      .finally(() => {
        if (!cancelado) setVerificandoPedidoExistente(false);
      });
    return () => {
      cancelado = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [codigoSeccionValidado, nombreAlumno, selectedColegio?.id, grado, turno, division, reintentoVerificacion, familiaActiva?.id, familiaActiva?.accesoGaleria]);

  // "Elegir otro medio de pago" (vuelta de una reserva sin pagar): con la familia ya identificada,
  // se pasa solo a la galería, donde está "Reservá tu kit ahora" con los medios de pago.
  const abrirEnGaleriaUsadoRef = useRef(false);
  useEffect(() => {
    if (!isOpen) {
      abrirEnGaleriaUsadoRef.current = false;
      return;
    }
    if (!abrirEnGaleria || abrirEnGaleriaUsadoRef.current || step !== 1) return;
    if (!codigoSeccionValidado || !selectedColegio?.id || verificandoPedidoExistente || errorVerificacion) return;
    abrirEnGaleriaUsadoRef.current = true;
    setStep(2);
  }, [isOpen, abrirEnGaleria, step, codigoSeccionValidado, selectedColegio?.id, verificandoPedidoExistente, errorVerificacion]);

  // Referencia a handleContinuarAlKit (definida más abajo) para el avance automático al kit.
  const handleContinuarAlKitRef = useRef<(() => void) | null>(null);
  const seleccionCompletaRef = useRef(false);
  useEffect(() => {
    if (!irAlKitDe) return;
    if (step !== 2) {
      setIrAlKitDe(null);
      return;
    }
    if (irAlKitDe !== hijoSeleccionadoId) return;
    if (seleccionCompletaRef.current) {
      setIrAlKitDe(null);
      handleContinuarAlKitRef.current?.();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [irAlKitDe, hijoSeleccionadoId, step, fotoSeleccionadaGrupal, fotoSeleccionadaIndividual, fotoSeleccionadaDocente, fotosDisponibles]);
  useEffect(() => {
    if (!irAlKitDe) return;
    const t = setTimeout(() => setIrAlKitDe(null), 8000);
    return () => clearTimeout(t);
  }, [irAlKitDe]);

  // 05/10 (bug 2c): si la familia le elige las 3 fotos a un hermano cuyo kit se iba a sumar POR
  // ADELANTADO (sin fotos), ese kit sale de `reservasParaSumar`: el chico se compra con sus fotos,
  // no las dos cosas a la vez. (`seleccionCompletaRef` se calcula en cada render, más abajo.)
  useEffect(() => {
    if (!seleccionCompletaRef.current) return;
    if (!reservasParaSumar.some((r) => r.hijoId === hijoSeleccionadoId)) return;
    const quitada = reservasParaSumar.find((r) => r.hijoId === hijoSeleccionadoId);
    setReservasParaSumar((prev) => prev.filter((r) => r.hijoId !== hijoSeleccionadoId));
    if (quitada) setErrorSeleccionFotos(`Como elegiste las fotos de ${quitada.nombreCompleto}, su kit ya no se suma por adelantado: se compra con sus fotos en esta misma compra.`);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [hijoSeleccionadoId, reservasParaSumar, fotoSeleccionadaIndividual, fotoSeleccionadaGrupal, fotoSeleccionadaDocente, fotosDisponibles]);

  /**
   * Auditoría 03/10 noche (M8b/R4): después de que el SERVIDOR confirmó el checkout (pedido o carrito
   * registrado), lo que se armó para esa compra no tiene que quedar cargado: antes el carrito de
   * hermanos, las reservas sumadas, los kits decididos y los ids del checkout se sumaban a la compra
   * siguiente (sobre todo tras una transferencia). OJO: no se llama antes de esa confirmación — si el
   * registro falla, la familia reintenta con los mismos ids (no se duplica).
   */
  const limpiarCompraTerminada = () => {
    setDescuento(null);
    carritoHijosRef.current = {};
    setCarritoHijos({});
    setReservasParaSumar([]);
    setKitHermanoDecidido({});
    setReservaRegistradaPorHijo({});
    setEstadoHermanos({});
    setDecisionHermanoPendiente({});
    incluidosEnCheckoutRef.current = new Set();
    setConfirmandoIncluirHermano(null);
    setIrAlKitDe(null);
    setAvisoKitHermano('');
    checkoutIdsRef.current = null;
    borrarCheckoutDeSesion();
    setQuiereOtroPedido(false); // 05/10 (bug 4)
    // Auditoría 11/10 (POR-1/7/9): nada del pedido anterior pasa al siguiente (respuestas atrasadas,
    // mensaje de estado, casillas legales que tienen que tildarse de nuevo).
    generacionPedidoRef.current += 1;
    setMensajeEstadoPago(null);
    setAceptaTerminos(false);
    setAceptaPlazoTransferencia(false);
    marcarTerminosAceptados(false);
    setCambioATransferencia(null);
    // Las fotos y extras del hijo activo ya quedaron en el pedido registrado.
    setFotoSeleccionadaIndividual('');
    setFotoSeleccionadaGrupal('');
    setFotoSeleccionadaDocente('');
    setFotosSueltasSeleccionadas([]);
    setSinFoto([]);
    setExtraCarpetas(0);
    // Se vuelve a consultar al servidor el estado de cada hijo (ahora con el pedido recién hecho).
    setReintentoVerificacion((n) => n + 1);
  };

  // Pedido de Pablo (27/9): después de terminar un pedido (paso 5, por ejemplo una transferencia
  // pendiente), "Ver Fotos / Comprar" volvía siempre a esa confirmación y no dejaba ver la galería
  // ni armar otra compra. Ahora vuelve al inicio (Alumno); el aviso de "ya tenés un pedido" sigue
  // mostrando el pedido hecho.
  const irAVerFotosYComprar = () => {
    setModalMode('pedido');
    if (step === 5) {
      setPedidoYaNoExiste(false);
      setPedidoGenerado(null);
      setNumeroPedido('');
      setAvisoReservaNoSumada(null);
      // Auditoría 03/10 noche (M8b/R4): el Paso 5 sólo existe con un pedido ya registrado, así que lo
      // de esa compra no se arrastra a la siguiente.
      limpiarCompraTerminada();
      setStep(1);
    }
  };

  // Auditoría 11/10 (POR-14): Escape cierra lo de más arriba (visor, diálogo o el portal).
  const alEscapeRef = useRef<() => void>(() => {});
  useEffect(() => {
    if (!isOpen) return;
    const alTeclear = (e: globalThis.KeyboardEvent) => {
      // Revisión 11/10: no si la familia está escribiendo, ni si hay otro diálogo encima (Términos, aviso de error).
      const t = e.target as HTMLElement | null;
      const escribiendo = !!t && (/^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName) || t.isContentEditable);
      const otroDialogo = Array.from(document.querySelectorAll('[aria-modal="true"]')).some((d) => !/^titulo-(confirmar-acceso|otro-kit)$/.test(d.getAttribute('aria-labelledby') || ''));
      if (e.key === 'Escape' && !e.defaultPrevented && !escribiendo && !otroDialogo) alEscapeRef.current();
    };
    document.addEventListener('keydown', alTeclear);
    return () => document.removeEventListener('keydown', alTeclear);
  }, [isOpen]);

  // 14/10: en secundaria no se vende el Solo Digital (el kit vale para todos los hijos de la compra).
  const gradosDeLaCompra = [grado, ...valoresDelCarrito(carritoHijos).filter((c) => c.hijoId !== hijoSeleccionadoId).map((c) => c.grado)];
  useSinSoloDigitalEnSecundaria<KitProducto>(hayCursoDeSecundaria(gradosDeLaCompra), selectedKit, KITS_DISPONIBLES, setSelectedKit);
  // 22/10: «Faltantes solicitadas»: la foto pedida deja el kit de este chico en espera (AvisoSinFotoPack).
  const faltantes = useFaltantesSolicitadas({ codigo: codigoSeccionValidado, familia: familiaActiva?.id, acceso: familiaActiva?.accesoGaleria, alumnoNombre: nombreAlumno, tutorNombre: familiaActiva?.padreNombre }); const hijosSinFotos = useHijosSinFotos(familiaActiva?.id);

  if (!isOpen) return null;

  // Tarjetas y casilleros clickeables también con Enter / Espacio (POR-14).
  const activarConTeclado = (e: KeyboardEvent<HTMLElement>) => {
    if (e.key !== 'Enter' && e.key !== ' ') return;
    e.preventDefault();
    e.currentTarget.click();
  };

  // Calculate Total
  const { carpetaExtra: PRECIO_CARPETA_EXTRA, fotoEvento: PRECIO_FOTO_EVENTO } = precios;
  // Mismos topes que aplica el servidor al cobrar (MAX_CARPETAS_EXTRA / MAX_FOTOS_SUELTAS en
  // server.ts): sin esto, pasando el tope la pantalla mostraba un total y se cobraba otro.
  const MAX_CARPETAS_EXTRA = 20;
  const MAX_FOTOS_SUELTAS = 50;
  const precioBase = selectedKit.precio;
  const totalCopiasExtrasCantidad = extraCarpetas;
  const precioCopiasExtras = extraCarpetas * PRECIO_CARPETA_EXTRA;
  const total = precioBase + precioCopiasExtras + (fotosSueltasSeleccionadas.length * PRECIO_FOTO_EVENTO);

  // Carrito multi-hijo: hermanos con su selección completa guardada (ver seleccionarHijo) además del activo.
  const otrosHijosEnCarrito = valoresDelCarrito(carritoHijos).filter(
    // Auditoría 03/10 noche (M8a/R3): un hermano con un pedido esperando el pago no entra solo.
    // 05/10 (bug 2c): un hermano cuyo kit ya se suma por adelantado no entra también con fotos (sería cobrarlo dos veces).
    (c) => c.hijoId !== hijoSeleccionadoId && c.completo && !hijosSinFotos.excluido(c.hijoId) && !tieneKitPagadoPorAdelantado(c.hijoId) && !hermanoPendienteExcluido(c.hijoId) && !reservasParaSumar.some((r) => r.hijoId === c.hijoId)
  );
  const totalReservasParaSumar = reservasParaSumar.reduce((acc, r) => acc + r.precio, 0);
  const descuentoTotal = descuento ? descuentoDelCarrito([{ kitId: selectedKit.id, total }, ...otrosHijosEnCarrito].map((it) => Math.min(it.total, descuentoDeKit(it.kitId === selectedKit.id ? precioBase : KITS_DISPONIBLES.find((k) => k.id === it.kitId)?.precio || 0, descuento.porcentaje, it.kitId, descuento.sinTopeImpreso))), descuento.usosLibres) : 0; // 22/10: por kit; 24/10: un uso por kit (como el servidor)
  const totalCombinadoCarrito = total + otrosHijosEnCarrito.reduce((acc, c) => acc + c.total, 0) + totalReservasParaSumar - descuentoTotal;

  // Cuántas de las 3 fotos del pack están realmente elegidas (es decir, la selección apunta a una
  // foto que existe de verdad en esta galería, no sólo un ID que quedó de otra galería/curso). El
  // badge de "X de 3 fotos seleccionadas" mostraba siempre "3 de 3" fijo, sin importar si el curso
  // todavía no tenía cargada alguna de las 3 categorías.
  // 22/10: en un lugar marcado «no tiene esta foto» vale otra foto del curso (utils/fotosFaltantes.ts).
  const fotoEnLugar = (id: string, lugar: LugarPack) => fotosDisponibles.find((f) => f.id === id && categoriaValeEnLugar(f.categoria, lugar, sinFoto));
  const fotoGrupalSeleccionada = fotoEnLugar(fotoSeleccionadaGrupal, 'grupal');
  const fotoIndividualSeleccionada = fotoEnLugar(fotoSeleccionadaIndividual, 'individual');
  // 06/10: la 3ª foto (lugar «docente») puede ser con la seño o con familia/amigos, y es obligatoria
  // sólo si el curso tiene alguna (antes se exigía siempre: un curso de secundaria sin foto con la
  // seño no podía avanzar nunca). Mismo criterio que validarSeleccionFotos en server.ts.
  const fotoDocenteSeleccionada = fotoEnLugar(fotoSeleccionadaDocente, 'docente');
  const terceraFotoRequerida = fotosDisponibles.some((f) => esTerceraFoto(f.categoria));
  const textosTercera = textosTerceraFoto(fotosDisponibles.map((f) => f.categoria));
  const totalFotosPack = terceraFotoRequerida || fotosDisponibles.length === 0 ? 3 : 2;
  // 26/10 (Pablo): «el kit sí o sí lleva 3 fotos»: un lugar «no tiene esta foto» cuenta sólo con otra foto en su
  // lugar. La grupal no se saltea: si el chico no está, la familia nos escribe (AvisoSinFotoPack).
  const fotoGrupalSeleccionadaValida = Boolean(fotoGrupalSeleccionada);
  const fotoIndividualSeleccionadaValida = Boolean(fotoIndividualSeleccionada);
  const fotoDocenteSeleccionadaValida = Boolean(fotoDocenteSeleccionada);
  const terceraFotoOk = fotoDocenteSeleccionadaValida || !terceraFotoRequerida;
  seleccionCompletaRef.current = Boolean(fotoGrupalSeleccionadaValida && fotoIndividualSeleccionadaValida && terceraFotoOk);
  const hayFotosDeEventos = fotosDisponibles.some((f) => f.categoria === 'patio');

  // Elige una foto del pack (grupal / retrato / con seño) y, medio segundo después, pasa solo al
  // siguiente paso que TODAVÍA falte — nunca a uno ya elegido, así corregir una foto no te saca de
  // donde estás. Con las 3 elegidas se queda y lleva la vista al botón para continuar.
  const elegirFotoDelPack = (foto: { id: string; categoria: string }) => {
    // 22/10: en la pestaña de un lugar «no tiene esta foto» la foto tocada va en ESE lugar (cualquier categoría);
    // tocar la que ya está la saca. No se repite una foto en dos lugares del kit.
    const enReemplazo = categoriaActiva !== 'patio' && sinFoto.includes(categoriaActiva) && (categoriaActiva !== 'docente' || terceraFotoRequerida);
    const categoria = (enReemplazo ? categoriaActiva : pasoDelPack(foto.categoria)) as LugarPack;
    const actuales: Record<LugarPack, string> = { grupal: fotoSeleccionadaGrupal, individual: fotoSeleccionadaIndividual, docente: fotoSeleccionadaDocente };
    const nuevoId = enReemplazo && actuales[categoria] === foto.id ? '' : foto.id;
    if (nuevoId && Object.entries(actuales).some(([lugar, id]) => lugar !== categoria && id === nuevoId)) {
      setErrorSeleccionFotos('Esa foto ya está elegida en otro lugar del kit. Elegí una distinta.');
      return;
    }
    if (categoria === 'individual') setFotoSeleccionadaIndividual(nuevoId);
    if (categoria === 'grupal') setFotoSeleccionadaGrupal(nuevoId);
    if (categoria === 'docente') setFotoSeleccionadaDocente(nuevoId);
    setErrorSeleccionFotos('');
    if (!nuevoId) return;
    const elegidas: Record<string, string> = { ...actuales, [categoria]: foto.id };
    // 29/10 (Pablo: «debió avanzar y no lo hizo»): se pasa también a un lugar sin fotos (ahí se elige otra en su lugar).
    const pasos = (['grupal', 'individual', 'docente'] as const).filter((c) => c !== 'docente' || terceraFotoRequerida);
    const idx = pasos.indexOf(categoria);
    const siguiente = [...pasos.slice(idx + 1), ...pasos.slice(0, Math.max(idx, 0))].find((c) => !elegidas[c]);
    const nombreElegida = enReemplazo ? 'Foto elegida en su lugar' : { grupal: 'Foto grupal elegida', individual: 'Retrato elegido', docente: foto.categoria === 'familia' ? 'Foto con familia/amigos elegida' : textosTercera.elegida }[categoria];
    if (timerAvancePackRef.current) window.clearTimeout(timerAvancePackRef.current);
    if (siguiente) {
      const nombreSiguiente = { grupal: 'la foto grupal', individual: 'el retrato', docente: textosTercera.la }[siguiente];
      setAvisoAvancePack(`¡${nombreElegida}! Ahora elegí ${nombreSiguiente}.`);
      timerAvancePackRef.current = window.setTimeout(() => {
        setCategoriaActiva(siguiente);
        // 09/10: `?.()` porque en las pruebas (jsdom) no existe scrollIntoView y este temporizador puede
        // dispararse después de que terminó la prueba: el error suelto frenaba el deploy en Vercel.
        panelPackRef.current?.scrollIntoView?.({ behavior: 'smooth', block: 'start' });
      }, 700);
    } else {
      // 05/10 (bug 4): con la reserva ya confirmada no se invita a "Elegir Kit y Formato".
      setAvisoAvancePack(
        reservaConfirmadaPorHijo[hijoSeleccionadoId]
          ? `Las fotos del pedido ${reservaConfirmadaPorHijo[hijoSeleccionadoId]} ya están confirmadas.`
          : `¡Listo, ya elegiste las ${totalFotosPack} fotos! Tocá "${reservaActiva?.pagada ? 'Confirmar mis fotos' : 'Elegir Kit y Formato'}" para seguir.`
      );
      timerAvancePackRef.current = window.setTimeout(() => {
        botonContinuarPackRef.current?.scrollIntoView?.({ behavior: 'smooth', block: 'center' });
      }, 700);
    }
  };

  // Tocar una pestaña a mano cancela un salto automático pendiente.
  const irAPasoPack = (categoria: 'individual' | 'grupal' | 'docente' | 'patio') => {
    if (timerAvancePackRef.current) window.clearTimeout(timerAvancePackRef.current);
    setAvisoAvancePack('');
    setCategoriaActiva(categoria);
  };
  // 22/10: «Mi hijo/a no tiene esta foto» / «Deshacer». Al deshacer, si en ese lugar había otra foto en su lugar, se saca.
  const marcarSinFoto = (lugar: LugarPack, marcar: boolean) => {
    const nuevo = marcar ? [...sinFoto.filter((l) => l !== lugar), lugar] : sinFoto.filter((l) => l !== lugar);
    setSinFoto(nuevo);
    sinFotoRef.current = nuevo;
    const limpiar = (actual: string) => idValidoEnLugar(fotosDisponibles, actual, lugar, nuevo);
    if (lugar === 'individual') setFotoSeleccionadaIndividual(limpiar);
    if (lugar === 'grupal') setFotoSeleccionadaGrupal(limpiar);
    if (lugar === 'docente') setFotoSeleccionadaDocente(limpiar);
    setErrorSeleccionFotos('');
    setAvisoAvancePack('');
  };
  const enReemplazoActivo = categoriaActiva !== 'patio' && sinFoto.includes(categoriaActiva) && (categoriaActiva !== 'docente' || terceraFotoRequerida);
  const fotosDeLaPestana = fotosDisponibles.filter((f) => (enReemplazoActivo ? f.categoria !== 'patio' : pasoDelPack(f.categoria) === categoriaActiva) && fotoVisibleParaAlumno(f, nombreAlumno));
  const cantidadFotosPackSeleccionadas = [fotoGrupalSeleccionadaValida, fotoIndividualSeleccionadaValida, fotoDocenteSeleccionadaValida].filter(Boolean).length;
  const packCompleto = fotoGrupalSeleccionadaValida && fotoIndividualSeleccionadaValida && terceraFotoOk;
  const nombreDelLugar = (l: LugarPack) => (l === 'docente' ? textosTercera.la : NOMBRE_LUGAR[l]); /* 29/10: qué falta, en palabras */ const faltaEnElPack = packCompleto || reservaConfirmadaPorHijo[hijoSeleccionadoId] ? '' : textoFaltaEnElPack((['grupal', 'individual', 'docente'] as const).filter((l) => !{ grupal: fotoGrupalSeleccionadaValida, individual: fotoIndividualSeleccionadaValida, docente: terceraFotoOk }[l]), sinFoto, categoriaActiva, nombreDelLugar);

  // 21/09 y 27/09 (Pablo): carpetas extra de CUALQUIER hermano desde una sola lista: el activo toca `extraCarpetas`,
  // los demás su entrada en `carritoHijos` (sólo si ya eligió sus fotos) o su reserva sumada.
  const reservaSumadaDe = (id: string) => reservasParaSumar.find((r) => r.hijoId === id);
  const obtenerExtraCarpetasDeHijo = (id: string): number => {
    const reserva = reservaSumadaDe(id);
    if (reserva && id !== hijoSeleccionadoId) return reserva.carpetasExtras || 0;
    if (id === hijoSeleccionadoId) return extraCarpetas;
    return carritoHijos[id]?.extraCarpetas || 0;
  };

  const hijoTieneFotosCompletas = (id: string): boolean => {
    if (id !== hijoSeleccionadoId && reservaSumadaDe(id)) return true; // sus fotos se eligen cuando estén
    if (id === hijoSeleccionadoId) {
      return fotoGrupalSeleccionadaValida && fotoIndividualSeleccionadaValida && terceraFotoOk;
    }
    return Boolean(carritoHijos[id]?.completo);
  };

  const ajustarExtraCarpetasDeHijo = (id: string, delta: number) => {
    if (id !== hijoSeleccionadoId && reservaSumadaDe(id)) {
      setReservasParaSumar((prev) =>
        prev.map((r) => {
          if (r.hijoId !== id || r.kitId !== 'kit-clasico') return r;
          const cantidad = Math.min(MAX_CARPETAS_EXTRA, Math.max(0, (r.carpetasExtras || 0) + delta));
          const precioKit = KITS_RESERVA.find((k) => k.id === r.kitId)?.precio || 0;
          return { ...r, carpetasExtras: cantidad, precio: precioKit + cantidad * PRECIO_CARPETA_EXTRA };
        })
      );
      return;
    }
    if (id === hijoSeleccionadoId) {
      setExtraCarpetas((prev) => Math.min(MAX_CARPETAS_EXTRA, Math.max(0, prev + delta)));
      return;
    }
    setCarritoHijos((prev) => {
      const entry = prev[id];
      if (!entry) return prev;
      const nuevaCantidad = Math.min(MAX_CARPETAS_EXTRA, Math.max(0, (entry.extraCarpetas || 0) + delta));
      const kitPrecio = KITS_DISPONIBLES.find((k) => k.id === entry.kitId)?.precio || 0;
      const nuevoTotal = kitPrecio + nuevaCantidad * PRECIO_CARPETA_EXTRA + entry.fotosSueltasSeleccionadas.length * PRECIO_FOTO_EVENTO;
      return { ...prev, [id]: { ...entry, extraCarpetas: nuevaCantidad, total: nuevoTotal } };
    });
  };

  // Sólo tiene sentido mostrar la lista con un renglón por hermano cuando hay más de un hijo en
  // esta familia — con uno solo se deja el control simple de siempre.
  const hijosParaCarpetasExtra = hijosFamilia.length > 1 ? hijosFamilia : [];
  const totalExtraCarpetasFamilia = hijosParaCarpetasExtra.length > 0
    ? hijosParaCarpetasExtra.reduce((acc, h) => acc + obtenerExtraCarpetasDeHijo(h.id), 0)
    : extraCarpetas;

  // Auditoría 2026-09-21 (Pablo, tras probar con sus 2 mellizos): el resumen decía "1 carpeta del
  // pack principal" sin importar cuántos hermanos hubiera — con 2 hijos, cada uno con su propio
  // Kit Impreso + Digital, en realidad hay 2 carpetas de "pack principal" (una por cada hijo, ya
  // incluida en su propio kit), no 1 sola para toda la familia. Este helper cuenta cuántos
  // hermanos de la lista realmente traen una carpeta base incluida en su kit — el hijo activo se
  // lee del `selectedKit` en vivo, el resto de su `carritoHijos` guardado; si un hermano todavía
  // no llegó a elegir kit, se asume el kit por defecto (Clásico), que es el mismo criterio que ya
  // usa `selectedKit` al inicializarse.
  const hijoTieneCarpetaBaseIncluida = (id: string): boolean => {
    const reserva = id !== hijoSeleccionadoId ? reservaSumadaDe(id) : undefined;
    if (reserva) return reserva.kitId === 'kit-clasico';
    if (id === hijoSeleccionadoId) return selectedKit.id === 'kit-clasico';
    const kitDeEseHijo = carritoHijos[id]?.kitId;
    return kitDeEseHijo === undefined || kitDeEseHijo === 'kit-clasico';
  };
  const totalCarpetasBaseFamilia = hijosParaCarpetasExtra.length > 0
    ? hijosParaCarpetasExtra.filter((h) => hijoTieneCarpetaBaseIncluida(h.id)).length
    : 1;

  const renderFilaCarpetaExtra = (hijo: HijoConCodigoSeccion, compacto = false) => {
    const cantidad = obtenerExtraCarpetasDeHijo(hijo.id);
    const completo = hijoTieneFotosCompletas(hijo.id);
    // Auditoría 2026-09-22 (bug real, MEDIA): el botón "+" de esta fila sólo miraba si ESE
    // hermano ya había elegido sus 3 fotos (`completo`), pero nunca si su propio kit trae carpeta
    // de base para duplicar — el mismo chequeo que ya existe para el hijo activo (ver comentario
    // más arriba de `hijoTieneCarpetaBaseIncluida`, "no tiene sentido en un kit que no trae
    // carpeta de base") no se aplicaba fila por fila acá. Con dos hermanos, uno en "Kit Impreso +
    // Digital" y el otro en "Solo Digital HD" (sin carpeta física), se podía agregar sin ningún
    // aviso una "Carpeta Escolar Extra" para el hermano que no tiene carpeta de base que duplicar
    // — un ítem que se cobra bien pero que en el laboratorio no tiene sentido, porque no hay
    // ninguna carpeta original de ese kit para hacerle una copia.
    const tieneCarpetaBase = hijoTieneCarpetaBaseIncluida(hijo.id);
    const puedeSumar = completo && tieneCarpetaBase;
    const tamañoBoton = compacto ? 'w-8 h-8' : 'w-9 h-9';
    const tamañoIcono = compacto ? 'w-3.5 h-3.5' : 'w-4 h-4';
    return (
      <div
        key={hijo.id}
        className="flex items-center justify-between gap-3 py-2 first:pt-0 last:pb-0 border-b last:border-b-0 border-amber-200/60"
      >
        <div className="min-w-0 pr-2">
          <span className="text-xs font-bold text-slate-900 truncate block">{hijo.nombreCompleto}</span>
          {!completo && (
            <span className="text-[10px] text-slate-500 block">Elegí primero sus 3 fotos para poder sumarle una copia</span>
          )}
          {completo && !tieneCarpetaBase && (
            <span className="text-[10px] text-slate-500 block">Su kit no incluye carpeta física para duplicar</span>
          )}
        </div>
        <div className="flex items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={() => ajustarExtraCarpetasDeHijo(hijo.id, -1)}
            disabled={cantidad === 0}
            className={`${tamañoBoton} rounded-lg border border-slate-300 bg-white hover:bg-slate-100 disabled:opacity-30 disabled:cursor-not-allowed flex items-center justify-center text-slate-700 font-bold transition-colors cursor-pointer`}
            title={`Restar carpeta extra de ${hijo.nombreCompleto}`}
          >
            <Minus className={tamañoIcono} />
          </button>
          <div className="min-w-8 text-center">
            <span className="font-mono font-extrabold text-sm text-slate-900 block">{cantidad}</span>
          </div>
          <button
            type="button"
            onClick={() => ajustarExtraCarpetasDeHijo(hijo.id, 1)}
            disabled={!puedeSumar}
            className={`${tamañoBoton} rounded-lg bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold flex items-center justify-center transition-colors cursor-pointer shadow-xs disabled:opacity-30 disabled:cursor-not-allowed`}
            title={
              !completo
                ? 'Elegí primero sus 3 fotos'
                : !tieneCarpetaBase
                  ? 'Su kit no incluye carpeta física para duplicar'
                  : `Sumar carpeta extra para ${hijo.nombreCompleto}`
            }
          >
            <Plus className={tamañoIcono} />
          </button>
        </div>
      </div>
    );
  };

  // 05/10 (bug 4): aviso si el hijo ACTIVO ya tiene el kit pagado (null = puede seguir).
  const avisoHijoActivoYaPago = (confirmoOtroKit = false): string | null => {
    const numeroReserva = reservaConfirmadaPorHijo[hijoSeleccionadoId];
    if (numeroReserva) return `Las fotos del kit de ${nombreAlumno} ya quedaron confirmadas (pedido ${numeroReserva}): no hace falta elegir kit ni pagar de nuevo.`;
    // Si ya confirmó "comprar otro kit igual" (409 KIT_YA_PAGADO del servidor) no se lo vuelve a frenar.
    if (estadoHermanos[hijoSeleccionadoId]?.tienePedidoPagado && !quiereOtroPedido && !confirmoOtroKit)
      return `${nombreAlumno} ya tiene un pedido pagado. Si querés comprar otro kit igual, tocá "Atrás" y después "Sí, quiero hacer otro pedido".`;
    return null;
  };
  // 05/10 (bug 6): hermano con kit pagado por adelantado y 3 fotos elegidas que todavía no confirmó.
  const hermanoConReservaSinConfirmar = () =>
    hijosFamilia.find(
      (h) => h.id !== hijoSeleccionadoId && tieneKitPagadoPorAdelantado(h.id) && Boolean(carritoHijosRef.current[h.id]?.completo) && !reservaConfirmadaPorHijo[h.id]
    );

  const handleContinuarAlKit = () => { const otroHijo = hijosSinFotos.excluido(hijoSeleccionadoId) && hijosFamilia.find((h) => h.id !== hijoSeleccionadoId && !hijosSinFotos.excluido(h.id)); if (otroHijo) return seleccionarHijo(otroHijo.id); // 26/10: el activo «no quiere fotos»
    // Auditoría 03/10 (alto 6): sin saber si ya hay un kit pagado no se avanza a comprar.
    if (errorVerificacion) {
      setErrorSeleccionFotos(`${errorVerificacion} Tocá "Reintentar" en el aviso de arriba antes de seguir.`);
      return;
    }
    // Auditoría 03/10 noche (R12): sin la lista de hermanos no se sigue como si fuera hijo único.
    if (errorHijosFamilia) {
      setErrorSeleccionFotos('No pudimos cargar a tus otros hijos. Tocá "Reintentar" en el aviso de arriba antes de seguir.');
      return;
    }
    // 05/10 (bug 4): el hijo activo ya tiene su kit pagado (reserva recién confirmada, o pedido
    // pagado según el servidor): no se pasa a elegir kit y pagar de nuevo. Para comprar OTRO kit
    // igual, la familia lo dice expresamente en "Sí, quiero hacer otro pedido" (Paso 1).
    const avisoKitPagado = avisoHijoActivoYaPago();
    if (avisoKitPagado) {
      setErrorSeleccionFotos(avisoKitPagado);
      return;
    }
    // 05/10 (bug 6): un hermano con kit pagado por adelantado al que ya se le eligieron las 3 fotos
    // sin tocar "Confirmar mis fotos": esa elección sólo vive en este navegador — se confirma primero.
    const reservaSinConfirmar = hermanoConReservaSinConfirmar();
    if (reservaSinConfirmar) {
      setErrorSeleccionFotos(`Confirmá primero las fotos de ${reservaSinConfirmar.nombreCompleto}: su kit ya está pagado y la elección se guarda con "Confirmar mis fotos".`);
      seleccionarHijo(reservaSinConfirmar.id);
      return;
    }
    // Revisión M1: un hermano con pedido esperando el pago al que ya se le eligieron fotos no queda
    // afuera en silencio: la familia tiene que decir si lo incluye o sigue sin él.
    const pendienteSinDecidir = hijosFamilia.find((h) => hermanoPendienteSinDecidir(h.id));
    if (pendienteSinDecidir) {
      setErrorSeleccionFotos(
        `Ya elegiste las fotos de ${pendienteSinDecidir.nombreCompleto}, que tiene un pedido esperando el pago: elegí en el aviso de arriba si lo incluís en esta compra o seguís sin él.`
      );
      return;
    }
    const faltantes = [
      !fotoGrupalSeleccionadaValida ? 'una foto grupal' : null,
      !fotoIndividualSeleccionadaValida ? 'un retrato individual' : null,
      !terceraFotoOk ? textosTercera.una : null,
    ].filter(Boolean);
    if (faltantes.length > 0) {
      setErrorSeleccionFotos(`Antes de continuar, elegí ${faltantes.join(', ').replace(/, ([^,]*)$/, ' y $1')}.`);
      const primeraQueFalta = !fotoGrupalSeleccionadaValida ? 'grupal' : !fotoIndividualSeleccionadaValida ? 'individual' : 'docente'; // 29/10: lleva ahí
      if (primeraQueFalta !== categoriaActiva) irAPasoPack(primeraQueFalta); return;
    }
    // 21/09 (Pablo, con sus mellizos): no se avanza hasta que TODOS los hermanos de `hijosFamilia` tengan sus fotos
    // (uno nunca visitado no está en `carritoHijos` y cuenta como incompleto); el primero incompleto queda activo.
    const hermanoIncompleto = hijosFamilia.find((h) => {
      if (h.id === hijoSeleccionadoId || hijosSinFotos.excluido(h.id)) return false; // el activo ya se validó arriba; 26/10: «no quiero sus fotos»
      if (tieneKitPagadoPorAdelantado(h.id)) return false; // ya pagado: sus fotos se confirman aparte
      // Auditoría 03/10 noche (M8a/R3): ya tiene un pedido esperando el pago (por ejemplo una
      // transferencia sin aprobar): no se le exige elegir fotos ni comprarlo de nuevo, salvo que la
      // familia haya elegido incluirlo igual.
      if (hermanoPendienteExcluido(h.id)) return false;
      const estado = estadoHermanos[h.id];
      if (estado && (!estado.fotosDisponibles || estado.tienePedidoPagado)) return false; // sin fotos todavía, o ya compró
      return !carritoHijosRef.current[h.id]?.completo;
    });
    if (hermanoIncompleto) {
      setErrorSeleccionFotos(
        `Antes de continuar, también tenés que elegir las 3 fotos de ${hermanoIncompleto.nombreCompleto}.`
      );
      seleccionarHijo(hermanoIncompleto.id);
      return;
    }
    // Pedido de Pablo (27/9): un hermano cuyo curso todavía no tiene fotos no se puede saltear —
    // hay que elegir sí o sí qué hacer con su kit (reservarlo o "Ahora no") antes de pagar.
    const hermanoSinDecidir = hijosFamilia.find((h) => {
      if (h.id === hijoSeleccionadoId || hijosSinFotos.excluido(h.id)) return false;
      if (tieneKitPagadoPorAdelantado(h.id) || reservaRegistradaPorHijo[h.id]) return false;
      if (hermanoPendienteExcluido(h.id)) return false; // Auditoría 03/10 noche (M8a/R3)
      const estado = estadoHermanos[h.id];
      if (!estado || estado.fotosDisponibles || estado.tienePedidoPagado) return false;
      return !kitHermanoDecidido[h.id];
    });
    if (hermanoSinDecidir) {
      setAvisoKitHermano(
        `Antes de pagar, elegí qué hacés con el kit de ${hermanoSinDecidir.nombreCompleto}: reservarlo ahora (se paga junto) o "Ahora no".`
      );
      seleccionarHijo(hermanoSinDecidir.id);
      return;
    }
    setErrorSeleccionFotos('');
    setAvisoKitHermano('');
    setStep(3);
  };

  handleContinuarAlKitRef.current = handleContinuarAlKit;

  // Handlers
  const handleIngresarCodigo = async () => {
    if (!codigoAcceso.trim()) return;
    // Auditoría 2026-09-22: nombre y DNI del tutor viajan siempre junto al código (ver
    // `validarCodigoIngresado`) — son obligatorios ahora, se validan acá antes de pegarle al
    // servidor para no gastar el rate-limit con un pedido que ya sabemos que va a pedir datos.
    if (!codigoTutorNombreInput.trim() || codigoTutorDniInput.replace(/\D/g, '').length < 6) {
      setCodigoErrorMsg('Completá el nombre y apellido del tutor y su DNI, junto con el código, para poder identificar a tu familia.');
      setCodigoValidadoMsg(null);
      return;
    }
    if (validandoCodigo) return;
    setValidandoCodigo(true);
    setCodigoErrorMsg(null);
    let ok = false;
    try {
      ok = await validarCodigoIngresado(codigoAcceso, codigoTutorNombreInput, codigoTutorDniInput);
    } finally {
      setValidandoCodigo(false);
    }
    if (ok && nombreAlumno.trim()) {
      setStep(2);
    }
  };

  const handleEnviarSolicitudCodigo = async (opciones: { ignorarSugerencia?: boolean } = {}) => {
    if (!solicitudNombre.trim() || !solicitudContacto.trim()) {
      setSolicitudCodigoError('Completá tu nombre y el email con el que te registraste.');
      return;
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(solicitudContacto.trim())) {
      setSolicitudCodigoError('Ingresá un email válido.');
      return;
    }
    // Auditoría 2026-09-16 (pedido de Pablo: vio en el panel una solicitud de Valeria Soledad
    // Tolosa sin colegio ni alumno cargados, imposible de ubicar): antes colegio y alumno salían
    // de lo que ya hubiera completado en pantallas anteriores del portal, así que si la familia
    // tocaba "Solicitar mi Código" directo desde el Paso 1 (que es, de hecho, el motivo más común
    // para pedirlo — todavía no llegó a esas pantallas) esos dos datos quedaban vacíos y sin ellos
    // el fotógrafo no tiene forma de saber a qué familia corresponde el pedido. Ahora son
    // obligatorios acá mismo, en el propio formulario de solicitud (ver los dos campos nuevos más
    // abajo). Grado/división/turno siguen sin ser obligatorios: son justamente el dato que la
    // familia no tiene, por eso está pidiendo el código.
    if (!selectedColegio) {
      setSolicitudCodigoError('Seleccioná el colegio de tu hijo/a.');
      return;
    }
    if (!nombreAlumno.trim()) {
      setSolicitudCodigoError('Ingresá el nombre y apellido de tu hijo/a.');
      return;
    }
    const sugerencia = opciones.ignorarSugerencia ? null : sugerirCorreccionEmail(solicitudContacto);
    if (sugerencia) {
      setSugerenciaEmailSolicitud(sugerencia);
      return;
    }
    setSugerenciaEmailSolicitud(null);
    setEnviandoSolicitudCodigo(true);
    setSolicitudCodigoError(null);
    try {
      const resultado = await enviarSolicitudCodigo({
        nombreSolicitante: solicitudNombre.trim(),
        contacto: solicitudContacto.trim(),
        alumnoNombre: nombreAlumno.trim() || undefined,
        colegioId: selectedColegio?.id,
        colegioNombre: selectedColegio?.nombre,
        grado: grado || undefined,
        division: division || undefined,
        turno: turno || undefined,
      });
      if (resultado.success) {
        setSolicitudCodigoEncontrada(Boolean(resultado.envioAutomatico));
        setSolicitudCodigoMotivo(resultado.motivo || null);
        // Auditoría 03/10 noche (H8): el servidor responde lo mismo exista o no el email.
        setSolicitudCodigoMensaje(
          resultado.mensaje ||
            (resultado.envioAutomatico
              ? `Te mandamos el código a ${solicitudContacto.trim()}. Si no lo ves en unos minutos, revisá la carpeta de Spam o Correo no deseado.`
              : `No encontramos una inscripción con el email ${solicitudContacto.trim()}.`)
        );
        setSolicitudCodigoEnviada(true);
      } else {
        setSolicitudCodigoError(resultado.error || 'No se pudo enviar la solicitud.');
      }
    } finally {
      setEnviandoSolicitudCodigo(false);
    }
  };

  const handleCompletarPago = async (opciones: { confirmarOtroKit?: boolean } = {}) => {
    if (isProcessingPayment || !preciosVienenDelServidor()) return;
    // Auditoría 03/10 (alto 6): no se compra sin haber podido verificar si ya hay un kit pagado.
    if (errorVerificacion) {
      setPagoError(`${errorVerificacion} Tocá "Reintentar" en el aviso de arriba y después volvé a confirmar.`);
      return;
    }
    // Auditoría 03/10 noche (R12): sin la lista de hermanos no se cobra como si fuera hijo único.
    if (errorHijosFamilia) {
      setPagoError('No pudimos cargar a tus otros hijos. Tocá "Reintentar" en el aviso de arriba y después volvé a confirmar.');
      return;
    }
    // 05/10 (bug 4): mismo freno que en handleContinuarAlKit (kit del hijo activo ya pagado).
    const avisoKitPagado = avisoHijoActivoYaPago(Boolean(opciones.confirmarOtroKit));
    if (avisoKitPagado) {
      setPagoError(avisoKitPagado);
      return;
    }
    // 05/10 (bug 6): las fotos elegidas de un kit pagado por adelantado se confirman antes de cobrar
    // al hermano (al registrar esta compra se vacía el carrito y esa elección se perdería).
    const reservaSinConfirmar = hermanoConReservaSinConfirmar();
    if (reservaSinConfirmar) {
      setPagoError(`Confirmá primero las fotos de ${reservaSinConfirmar.nombreCompleto} (su kit ya está pagado): volvé a la galería, elegí a ${reservaSinConfirmar.nombreCompleto} y tocá "Confirmar mis fotos".`);
      setStep(2);
      seleccionarHijo(reservaSinConfirmar.id);
      return;
    }
    // Revisión M1: misma decisión obligatoria antes de cobrar.
    const pendienteSinDecidir = hijosFamilia.find((h) => hermanoPendienteSinDecidir(h.id));
    if (pendienteSinDecidir) {
      setPagoError(
        `Ya elegiste las fotos de ${pendienteSinDecidir.nombreCompleto}, que tiene un pedido esperando el pago: elegí en el aviso de arriba si lo incluís en esta compra o seguís sin él.`
      );
      return;
    }
    if (!aceptaTerminos) {
      // No se registra como falla de pago: es un paso que falta, se marca la casilla en rojo.
      setFaltaAceptarTerminos(true);
      return;
    }
    if (metodoPago === 'transferencia' && !aceptaPlazoTransferencia) {
      setFaltaAceptarPlazo(true);
      return;
    }
    marcarTerminosAceptados(true);
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(tutorEmail.trim())) {
      setPagoError('Ingresá un email válido para recibir el comprobante, las fotos y los avisos del pedido.');
      return;
    }
    setIsProcessingPayment(true);
    setPagoError(null);
    setAvisoReservaNoSumada(null);
    setConfirmacionOtroKit(null);
    setMpRedirectUrl(null);
    setNaveRedirectUrl(null);
    // El curso del pedido se deriva siempre de grado/turno/división (nunca del código tipeado):
    // es el codigo_curso con que se etiquetan las fotos (si no, el .zip HD no se arma).
    const codCurso = determinarCodigoParaInscripcion({ grado, turno, division });

    // Carrito multi-hijo ("el cliente debe poder hacer multiple pedido en una sola sesion, un
    // solo pago" — pedido de Pablo 2026-09-16): además del hijo activo ahora mismo, puede haber
    // hermanos con su selección ya guardada (ver seleccionarHijo, más arriba). Si hay más de uno
    // en total se registran todos juntos y se cobran en un solo checkout combinado; si hay uno
    // solo, sigue exactamente el camino de siempre (una fila, un pago) sin ningún cambio.
    const otrosHijosCarrito = valoresDelCarrito(carritoHijos).filter(
      // Auditoría 03/10 noche (M8a/R3): mismo filtro que `otrosHijosEnCarrito` (lo que se ve = lo que se cobra).
      (c) => c.hijoId !== hijoSeleccionadoId && c.completo && !hijosSinFotos.excluido(c.hijoId) && !tieneKitPagadoPorAdelantado(c.hijoId) && !hermanoPendienteExcluido(c.hijoId) && !reservasParaSumar.some((r) => r.hijoId === c.hijoId)
    );

    // Auditoría 03/10 (crítico 2): ids del pedido estables para este checkout. Se generan la
    // primera vez y se reusan en cada reintento (el servidor es idempotente por ese id); sólo
    // cambian si cambia lo que se compra. No dependen del medio de pago.
    const firma = firmaDeCheckout({
      hijo: hijoSeleccionadoId,
      alumno: nombreAlumno,
      colegio: selectedColegio?.id || '',
      curso: [grado, turno, division],
      kit: selectedKit.id,
      extras: extraCarpetas,
      fotos: [fotoSeleccionadaIndividual, fotoSeleccionadaGrupal, fotoSeleccionadaDocente, fotosSueltasSeleccionadas, ...(sinFoto.length > 0 ? [sinFoto] : [])],
      otros: otrosHijosCarrito.map((c) => [c.hijoId, c.kitId, c.extraCarpetas, c.fotoSeleccionadaIndividual, c.fotoSeleccionadaGrupal, c.fotoSeleccionadaDocente, c.fotosSueltasSeleccionadas, ...(c.sinFoto?.length ? [c.sinFoto] : [])]),
      ...(descuento ? { descuento: descuento.codigo } : {}), // 22/10: con otro código, ids nuevos (el servidor recalcula)
    }, tutorEmail);
    // 05/10 (bug 2a): las reservas sumadas tienen su propia firma — quitarlas o cambiarlas después de
    // que el carrito ya quedó registrado NO regenera los ids del carrito (antes sí: la familia tocaba
    // "Quitar" y el reintento creaba pedidos duplicados).
    const firmaReservas = JSON.stringify(reservasParaSumar.map((r) => [r.hijoId, r.kitId, r.carpetasExtras || 0]));
    // 14/10/2026: tras recargar la página se recuperan los ids guardados en esta pestaña (si es la misma compra).
    const ids = idsParaCheckout(checkoutIdsRef.current ?? leerCheckoutDeSesion(firma), firma, otrosHijosCarrito.length + 1, nuevoUuidPedido, nuevoNumeroPedido, reservasParaSumar.length, undefined, firmaReservas);
    checkoutIdsRef.current = ids;
    guardarCheckoutEnSesion(ids);
    // Revisión M1: quiénes entran en este intento (ver incluidosEnCheckoutRef).
    incluidosEnCheckoutRef.current = new Set(otrosHijosCarrito.map((c) => c.hijoId));
    const numLista = ids.numLista;

    if (otrosHijosCarrito.length > 0 || reservasParaSumar.length > 0) {
      await handleCompletarPagoMultiple(otrosHijosCarrito, numLista, codCurso, ids, Boolean(opciones.confirmarOtroKit));
      return;
    }

    const { pedido: nuevoPedido, sincronizado, errorSincronizacion, codigo: codigoError, alumnos: alumnosConKit } = await registrarPedidoDesdePortal({
      colegioId: selectedColegio?.id || 'col-general',
      colegioNombre: selectedColegio?.nombre || 'Colegio Escolar',
      cursoCodigo: codCurso,
      grado: grado || 'Sala 3',
      division: division || 'Única',
      turno: turno || 'Mañana',
      alumnoNombre: nombreAlumno || 'Alumno Escolar',
      alumnoNumeroLista: numLista,
      tutorNombre: tutorNombre.trim(),
      tutorTelefono: tutorWhatsapp.trim(),
      tutorEmail: tutorEmail.trim(),
      kitId: selectedKit.id,
      kitNombre: selectedKit.nombre,
      total: total,
      metodoPago: metodoPago,
      fotosSeleccionadas: {
        individualId: fotoSeleccionadaIndividual,
        grupalId: fotoSeleccionadaGrupal,
        docenteId: fotoSeleccionadaDocente,
        otrasIds: fotosSueltasSeleccionadas,
        ...(sinFoto.length > 0 ? { sinFoto } : {}),
      },
      copiasExtras: {
        carpetasExtras: extraCarpetas,
        individual15x21: extraCarpetas,
        grupal20x30: extraCarpetas,
        docente15x21: extraCarpetas,
        otras15x21: fotosSueltasSeleccionadas.length,
      },
      fotosDisponibles,
      pedidoId: ids.pedidoId,
      pedidoFriendlyId: ids.pedidoFriendlyId,
      confirmarOtroKit: opciones.confirmarOtroKit,
      // Auditoría 03/10 noche (A1): misma clave en cada reintento de este checkout.
      claveCheckout: ids.claveCheckout,
      codigoDescuento: descuento?.codigo,
    });

    // Auditoría 03/10 (alto 8): el alumno ya tiene un kit pagado — se pregunta antes de seguir.
    if (codigoError === CODIGO_KIT_YA_PAGADO) {
      setConfirmacionOtroKit({ alumnos: alumnosConKit || [], mensaje: errorSincronizacion || '' });
      setIsProcessingPayment(false);
      return;
    }

    // 09/09 y 03/10 (alto 7): si el servidor no confirmó el pedido, NUNCA se avanza a la pasarela ni al Paso 5: la
    // familia se queda en el Paso 4 con el aviso y reintenta con el mismo botón (mismo id: no se duplica).
    if (!sincronizado) {
      if (/no es válido o ya no está disponible/i.test(errorSincronizacion || '')) setDescuento(null); // 22/10: no queda trabado con un código que ya no vale
      setPagoError(
        errorSincronizacion
          ? `No pudimos registrar tu pedido (${errorSincronizacion}). No se te cobró nada. Volvé a tocar el botón para reintentar — no se va a duplicar.`
          : 'No pudimos registrar tu pedido. No se te cobró nada. Volvé a tocar el botón para reintentar — no se va a duplicar.'
      );
      setIsProcessingPayment(false);
      return;
    }

    // Pedido confirmado por el servidor: el próximo checkout (otra compra) usa ids nuevos.
    checkoutIdsRef.current = null;
    borrarCheckoutDeSesion();
    setPedidoYaNoExiste(false);
    setNumeroPedido(nuevoPedido.id);
    // Auditoría 03/10 noche (M7/H6): `nuevoPedido.total` ya es el total que devolvió el servidor.
    setPedidoGenerado(nuevoPedido);
    // Auditoría 03/10 noche (M8b/R4): compra registrada → no se arrastra a la siguiente.
    limpiarCompraTerminada();
    if (nuevoPedido.metodoPago === 'bonificado') return void (setIsProcessingPayment(false), setStep(5)); // 22/10: sin cargo, ya pagado

    if (metodoPago === 'mercadopago') {
      try {
        const res = await crearPreferenciaMercadoPago({
          pedidoId: nuevoPedido.supabaseId || nuevoPedido.id,
          kitId: selectedKit.id,
          kitNombre: selectedKit.nombre,
          alumnoNombre: nombreAlumno.trim() || 'Alumno',
          colegioNombre: selectedColegio?.nombre || 'Colegio',
          cursoCodigo: codCurso,
          // El servidor recalcula el monto igual; se manda el que ya informó él.
          total: nuevoPedido.total,
          carpetasExtras: extraCarpetas,
          // Auditoría 2026-09-20 (bug real, CRÍTICO): ver comentario en generarLinkDePago.
          cantidadFotosSueltas: fotosSueltasSeleccionadas.length,
          tutorNombre: tutorNombre.trim() || 'Tutor',
          tutorEmail: tutorEmail.trim(),
          tutorTelefono: tutorWhatsapp.trim() || undefined,
        });

        if (res.initPoint) {
          setMpRedirectUrl(res.initPoint);
          setIsProcessingPayment(false);
          setStep(5);
          // Redirección directa al checkout oficial de Mercado Pago
          window.location.href = res.initPoint;
          return;
        } else {
          setPagoError(res.error || 'No se pudo generar la preferencia de Mercado Pago.');
          setIsProcessingPayment(false);
          setStep(5);
        }
      } catch (err: any) {
        setPagoError(err?.message || 'Error de conexión con el servidor de pagos.');
        setIsProcessingPayment(false);
        setStep(5);
      }
    } else if (metodoPago === 'nave') {
      try {
        const res = await crearIntencionPagoNave({
          pedidoId: nuevoPedido.supabaseId || nuevoPedido.id,
          kitId: selectedKit.id,
          kitNombre: selectedKit.nombre,
          alumnoNombre: nombreAlumno.trim() || 'Alumno',
          colegioNombre: selectedColegio?.nombre || 'Colegio',
          carpetasExtras: extraCarpetas,
          // Auditoría 2026-09-20 (bug real, CRÍTICO): ver comentario en generarLinkDePago.
          cantidadFotosSueltas: fotosSueltasSeleccionadas.length,
          tutorNombre: tutorNombre.trim() || 'Tutor',
          tutorEmail: tutorEmail.trim(),
          tutorTelefono: tutorWhatsapp.trim() || undefined,
        });

        if (res.checkoutUrl) {
          setNaveRedirectUrl(res.checkoutUrl);
          setIsProcessingPayment(false);
          setStep(5);
          // Redirección directa al checkout oficial de Nave
          window.location.href = res.checkoutUrl;
          return;
        } else {
          setPagoError(res.error || 'No se pudo generar la intención de pago de Nave.');
          setIsProcessingPayment(false);
          setStep(5);
        }
      } catch (err: any) {
        setPagoError(err?.message || 'Error de conexión con el servidor de pagos.');
        setIsProcessingPayment(false);
        setStep(5);
      }
    } else {
      // Transferencia bancaria o efectivo: queda en estado 'pendiente' y pasa a la pantalla de confirmación
      setIsProcessingPayment(false);
      setStep(5);
    }
  };

  /**
   * Auditoría 2026-09-16 (pedido de Pablo: "el cliente debe poder hacer multiple pedido en una
   * sola sesion, un solo pago"): arma UN pedido por cada hijo del carrito (el/la que está
   * activo/a ahora + los que ya quedaron guardados al cambiar de hermano) y los registra todos
   * juntos con registrarCarritoMultipleDesdePortal — todos comparten un mismo "grupoPagoId" que
   * después se usa para generar un único checkout de Mercado Pago o Nave por el total combinado.
   * Sólo la llama handleCompletarPago, y sólo cuando hay más de un hijo en el carrito — con un
   * solo hijo se sigue usando el camino de siempre (arriba), sin ningún cambio.
   */
  const handleCompletarPagoMultiple = async (
    otrosHijosCarrito: SeleccionCarritoHijo[],
    numListaActivo: number,
    codCursoActivo: string,
    ids: IdsCheckout,
    confirmarOtroKit: boolean
  ) => {
    // Hasta que el servidor confirme el carrito, un error deja a la familia en el Paso 4 (alto 7).
    let carritoRegistrado = false;
    try {
      const itemActivo: ItemCarritoHijo = {
        colegioId: selectedColegio?.id || 'col-general',
        colegioNombre: selectedColegio?.nombre || 'Colegio Escolar',
        cursoCodigo: codCursoActivo,
        grado: grado || 'Sala 3',
        division: division || 'Única',
        turno: turno || 'Mañana',
        alumnoNombre: nombreAlumno || 'Alumno Escolar',
        alumnoNumeroLista: numListaActivo,
        kitId: selectedKit.id,
        kitNombre: selectedKit.nombre,
        metodoPago,
        fotosSeleccionadas: {
          individualId: fotoSeleccionadaIndividual,
          grupalId: fotoSeleccionadaGrupal,
          docenteId: fotoSeleccionadaDocente,
          otrasIds: fotosSueltasSeleccionadas,
          ...(sinFoto.length > 0 ? { sinFoto } : {}),
        },
        copiasExtras: {
          carpetasExtras: extraCarpetas,
          individual15x21: extraCarpetas,
          grupal20x30: extraCarpetas,
          docente15x21: extraCarpetas,
          otras15x21: fotosSueltasSeleccionadas.length,
        },
      };

      const itemsOtros: ItemCarritoHijo[] = otrosHijosCarrito.map((c, idx) => ({
        // Hoy el Código Familiar sólo agrupa hermanos del mismo colegio — se usa el colegio
        // activo como respaldo si por algún motivo el hermano no trajo el suyo propio.
        colegioId: selectedColegio?.id || 'col-general',
        colegioNombre: c.colegioNombre || selectedColegio?.nombre || 'Colegio Escolar',
        cursoCodigo: determinarCodigoParaInscripcion({
          grado: c.grado || '',
          turno: c.turno || '',
          division: c.division || '',
        }),
        grado: c.grado || 'Sala 3',
        division: c.division || 'Única',
        turno: c.turno || 'Mañana',
        alumnoNombre: c.nombreCompleto || 'Alumno Escolar',
        // Estable por checkout (se reenvía igual en un reintento) y distinto para cada hermano.
        alumnoNumeroLista: ((numListaActivo + idx) % 25) + 1,
        kitId: c.kitId,
        kitNombre: c.kitNombre,
        metodoPago,
        fotosSeleccionadas: {
          individualId: c.fotoSeleccionadaIndividual,
          grupalId: c.fotoSeleccionadaGrupal,
          docenteId: c.fotoSeleccionadaDocente,
          otrasIds: c.fotosSueltasSeleccionadas,
          ...(c.sinFoto?.length ? { sinFoto: c.sinFoto } : {}),
        },
        copiasExtras: {
          carpetasExtras: c.extraCarpetas,
          individual15x21: c.extraCarpetas,
          grupal20x30: c.extraCarpetas,
          docente15x21: c.extraCarpetas,
          otras15x21: c.fotosSueltasSeleccionadas.length,
        },
      }));

      const todosLosItems = [...itemsOtros, itemActivo];

      // 05/10 (bug 1, red de seguridad): dos ítems del carrito con el mismo alumno y el mismo curso
      // son el mismo chico cargado dos veces (identidad mezclada) — nunca se manda ese pedido.
      const clavesAlumno = todosLosItems.map((it) => `${normalizarNombreAlumno(it.alumnoNombre)}|${it.cursoCodigo}`);
      const repetido = todosLosItems.find((_, i) => clavesAlumno.indexOf(clavesAlumno[i]) !== i);
      if (repetido) {
        setPagoError(`${repetido.alumnoNombre} figura dos veces en el carrito. Cerrá el portal, volvé a entrar y elegí de nuevo las fotos de cada hijo/a. No se te cobró nada.`);
        setIsProcessingPayment(false);
        return;
      }

      const resultadoCarrito = await registrarCarritoMultipleDesdePortal({
        tutorNombre: tutorNombre.trim(),
        tutorTelefono: tutorWhatsapp.trim(),
        tutorEmail: tutorEmail.trim(),
        items: todosLosItems,
        pedidoIds: ids.itemIds,
        pedidoFriendlyIds: ids.itemFriendlyIds,
        confirmarOtroKit,
        // Auditoría 03/10 noche (A1): misma clave en cada reintento de este checkout.
        claveCheckout: ids.claveCheckout,
        sumaReservas: reservasParaSumar.length > 0, // 14/10/2026: el email de transferencia sale con el total final
        codigoDescuento: descuento?.codigo,
      });

      if (resultadoCarrito.codigo === CODIGO_KIT_YA_PAGADO) {
        setConfirmacionOtroKit({ alumnos: resultadoCarrito.alumnos || [], mensaje: resultadoCarrito.errorSincronizacion || '' });
        setIsProcessingPayment(false);
        return;
      }
      // Auditoría 2026-09-09 (mismo criterio que el camino de un solo hijo) y 03/10 (alto 7): si el
      // carrito no se pudo confirmar, se queda en el Paso 4 y se reintenta con los mismos ids.
      if (!resultadoCarrito.sincronizado) {
        if (/no es válido o ya no está disponible/i.test(resultadoCarrito.errorSincronizacion || '')) setDescuento(null);
        setPagoError(
          resultadoCarrito.errorSincronizacion
            ? `No pudimos registrar tus pedidos (${resultadoCarrito.errorSincronizacion}). No se te cobró nada. Volvé a tocar el botón para reintentar — no se van a duplicar.`
            : 'No pudimos registrar tus pedidos. No se te cobró nada. Volvé a tocar el botón para reintentar — no se van a duplicar.'
        );
        setIsProcessingPayment(false);
        return;
      }

      // Reservas de hermanos sin fotos: se suman al MISMO grupo de pago (un solo checkout).
      let friendlyIdsReservas: string[] = [];
      // Auditoría 03/10 noche (M7/contrato 7): total de las reservas sumadas según el servidor.
      let totalReservasServidor = 0;
      // 05/10 (bug 2b): reservas que efectivamente quedaron sumadas, y el aviso si no se pudieron sumar.
      let reservasSumadas = reservasParaSumar;
      let avisoReserva: string | null = null;
      if (resultadoCarrito.sincronizado && reservasParaSumar.length > 0) {
        const reserva = await crearReserva({
          tutorNombre: tutorNombre.trim(),
          tutorEmail: tutorEmail.trim(),
          tutorTelefono: tutorWhatsapp.trim(),
          metodoPago: metodoPago === 'nave' || metodoPago === 'transferencia' ? metodoPago : 'mercadopago',
          // Auditoría 03/10: `reservaId` estable por checkout → el reintento no duplica ni anula la reserva.
          items: reservasParaSumar.map((r, i) => ({ codigoSeccion: r.codigoSeccion, alumnoNombre: r.nombreCompleto, kitId: r.kitId, carpetasExtras: r.carpetasExtras || 0, reservaId: ids.reservaIds[i] })),
          grupoPagoId: resultadoCarrito.grupoPagoId,
          // Auditoría 03/10 (2ª vuelta): si la familia ya confirmó "comprar otro kit" para el carrito,
          // vale también para el kit por adelantado que se suma al mismo pago.
          confirmarOtroKit,
          // Auditoría 03/10 noche (A1): misma clave del checkout (también en los reintentos).
          claveCheckout: ids.claveCheckout,
        });
        // Un hermano del kit por adelantado ya tiene un kit pagado: mismo aviso que al crear el
        // pedido. Si confirma, handleCompletarPago reenvía el carrito (idempotente, mismos ids) y
        // esta reserva con los mismos reservaId y confirmarOtroKit: true.
        if (reserva.codigo === CODIGO_KIT_YA_PAGADO) {
          setConfirmacionOtroKit({ alumnos: reserva.alumnos || [], mensaje: reserva.error || '' });
          setIsProcessingPayment(false);
          return;
        }
        if (!reserva.success && reserva.transitorio !== false) {
          // Falla pasajera (red, 429, 5xx): sigue en el Paso 4 y el reintento reusa el mismo carrito
          // (mismos ids) y vuelve a sumar la reserva.
          setPagoError(`No pudimos sumar el kit por adelantado a tu compra (${reserva.error || 'error desconocido'}). No se te cobró nada. Volvé a tocar el botón para reintentar.`);
          setIsProcessingPayment(false);
          return;
        }
        if (!reserva.success) {
          // 05/10 (bug 2b): el carrito YA quedó registrado y el servidor rechazó la reserva de forma
          // definitiva (4xx: sin llave, el curso del hermano ya tiene fotos, etc.). Antes se quedaba en
          // el Paso 4 sin dejar pagar las filas que ya existen. Ahora se pasa al Paso 5 con el pedido
          // del carrito solo y se avisa que el kit del hermano no se sumó.
          avisoReserva = `El kit por adelantado de ${reservasParaSumar.map((r) => r.nombreCompleto).join(' y ')} no se pudo sumar a esta compra (${reserva.error || 'el servidor lo rechazó'}). Tu pago es sólo por ${todosLosItems.map((it) => it.alumnoNombre).join(' y ')}; después de pagar esta compra podés reservar el kit de ${reservasParaSumar.map((r) => r.nombreCompleto).join(' y ')} desde "Acceder a las Fotos".`; // 14/10/2026: antes decía «reservalo aparte» (se rechaza mientras el hermano con fotos no está pago)
          reservasSumadas = [];
        } else {
          friendlyIdsReservas = reserva.pedidoFriendlyIds || [];
          totalReservasServidor = totalDelServidor(reserva.total) ?? 0;
        }
      }
      const nombresReservas = reservasSumadas.map((r) => r.nombreCompleto);

      // Pedido «de mentira» (nunca va a Supabase) para que el Paso 5 muestre todos los hijos y el total combinado.
      const pedidoSintetico: PedidoEscolarCompleto = {
        id: resultadoCarrito.pedidoFriendlyIds[0] || resultadoCarrito.pedidoIds[0] || `GRUPO-${Date.now()}`,
        supabaseId: resultadoCarrito.pedidoIds[0],
        grupoPagoId: resultadoCarrito.grupoPagoId,
        fecha: new Date().toLocaleString('es-AR'),
        colegioId: selectedColegio?.id || 'col-general',
        colegioNombre: selectedColegio?.nombre || 'Colegio Escolar',
        cursoCodigo: codCursoActivo,
        grado,
        division,
        turno,
        alumnoNumeroLista: numListaActivo,
        alumnoNombre: [...todosLosItems.map((it) => it.alumnoNombre), ...nombresReservas].join(', '),
        codigoAlumno: '',
        tutorNombre: tutorNombre.trim(),
        tutorTelefono: tutorWhatsapp.trim(),
        tutorEmail: tutorEmail.trim(),
        kitId: selectedKit.id,
        kitNombre: `${todosLosItems.length + nombresReservas.length} hijos/as`,
        // 03/10 (M7/H6): total del servidor (carrito + reservas); si no vino, 0 («a confirmar») hasta la consulta de estado.
        total: (totalDelServidor(resultadoCarrito.total) ?? 0) + totalReservasServidor,
        metodoPago: resultadoCarrito.bonificado ? 'bonificado' : metodoPago,
        estadoPago: resultadoCarrito.bonificado ? 'aprobado' : 'pendiente',
        estadoEntrega: 'en_espera',
        fotosSeleccionadas: { individualId: '', grupalId: '' },
        // 22/09: para el cartel «¡N carpeta(s) extra(s)!» del Paso 5 también en el carrito.
        copiasExtras: {
          carpetasExtras: todosLosItems.reduce((acc, it) => acc + (it.copiasExtras?.carpetasExtras || 0), 0),
        },
        archivosParaLaboratorio: [],
        linkDescargaHD: '',
        emailEnviado: false,
      };
      setPedidoGenerado(pedidoSintetico);
      // 17/09 (Pablo): un «IFS-2026-XXXX» por hijo (antes se veían los uuid crudos).
      setNumeroPedido([...resultadoCarrito.pedidoFriendlyIds, ...friendlyIdsReservas].join(', ') || resultadoCarrito.pedidoIds.join(', ') || pedidoSintetico.id);

      // Carrito (y reservas sumadas) confirmados por el servidor.
      carritoRegistrado = true;
      checkoutIdsRef.current = null;
      borrarCheckoutDeSesion();
      setPedidoYaNoExiste(false);
      // Auditoría 03/10 noche (M8b/R4): compra registrada → el carrito, las reservas sumadas y los
      // ids no se arrastran a la siguiente. (Lo que sigue usa las copias locales de esta función.)
      limpiarCompraTerminada();
      // 05/10 (bug 2b): aviso propio (no `pagoError`, que lo limpian los generadores de links).
      setAvisoReservaNoSumada(avisoReserva);
      if (resultadoCarrito.bonificado) return void (setIsProcessingPayment(false), setStep(5)); // 22/10: carrito sin cargo, ya pagado

      const itemsParaPreferencia = todosLosItems.map((item, idx) => ({
        pedidoId: resultadoCarrito.pedidoIds[idx] || '',
        kitId: item.kitId,
        kitNombre: item.kitNombre,
        alumnoNombre: item.alumnoNombre,
        colegioNombre: item.colegioNombre,
        carpetasExtras: item.copiasExtras?.carpetasExtras || 0,
        // Auditoría 2026-09-20 (bug real, CRÍTICO): ver comentario en generarLinkDePago — mismo
        // problema acá, por hijo, para el carrito multi-hijo (Mercado Pago y Nave combinados).
        cantidadFotosSueltas: item.copiasExtras?.otras15x21 || 0,
      }));

      if (metodoPago === 'mercadopago') {
        const res = await crearPreferenciaMercadoPagoMultiple({
          grupoPagoId: resultadoCarrito.grupoPagoId,
          items: itemsParaPreferencia,
          tutorNombre: tutorNombre.trim() || 'Tutor',
          tutorEmail: tutorEmail.trim(),
          tutorTelefono: tutorWhatsapp.trim() || undefined,
        });
        if (res.initPoint) {
          setMpRedirectUrl(res.initPoint);
          setIsProcessingPayment(false);
          setStep(5);
          window.location.href = res.initPoint;
          return;
        }
        setPagoError(res.error || 'No se pudo generar la preferencia combinada de Mercado Pago.');
        setIsProcessingPayment(false);
        setStep(5);
      } else if (metodoPago === 'nave') {
        const res = await crearIntencionPagoNaveMultiple({
          grupoPagoId: resultadoCarrito.grupoPagoId,
          items: itemsParaPreferencia,
          tutorNombre: tutorNombre.trim() || 'Tutor',
          tutorEmail: tutorEmail.trim(),
          tutorTelefono: tutorWhatsapp.trim() || undefined,
        });
        if (res.checkoutUrl) {
          setNaveRedirectUrl(res.checkoutUrl);
          setIsProcessingPayment(false);
          setStep(5);
          window.location.href = res.checkoutUrl;
          return;
        }
        setPagoError(res.error || 'No se pudo generar la intención de pago combinada de Nave.');
        setIsProcessingPayment(false);
        setStep(5);
      } else {
        // Transferencia bancaria o efectivo: todos los pedidos del carrito quedan en
        // 'pendiente_pago' y se pasa a la pantalla de confirmación.
        setIsProcessingPayment(false);
        setStep(5);
      }
    } catch (err: any) {
      setPagoError(err?.message || 'Error de conexión con el servidor de pagos.');
      setIsProcessingPayment(false);
      if (carritoRegistrado) setStep(5);
    }
  };

  // Tracking query handler.
  // Auditoría 2026-09-09 (revisión a fondo): antes esta búsqueda miraba únicamente el
  // localStorage del navegador — una familia que consultara desde otro dispositivo (o que
  // hubiera borrado los datos de este) no encontraba su pedido, aunque estuviera pagado y
  // guardado en Supabase. Ahora se consulta primero al servidor (datos reales); el localStorage
  // queda sólo como respaldo si la consulta al servidor falla (por ejemplo, sin conexión).
  const handleConsultarSeguimiento = async (e?: FormEvent, queryOverride?: string) => {
    if (e) e.preventDefault();
    setTrackingError('');
    const query = (queryOverride ?? trackingQuery).trim().toUpperCase();
    if (!query) {
      setTrackingError('Por favor ingresá tu número de pedido o teléfono');
      return;
    }

    setBuscandoSeguimiento(true);
    try {
      const pedidoServidor = await buscarPedidoPorSeguimiento(query);
      if (pedidoServidor) {
        // Auditoría 2026-09 (bug reportado por Pablo, pedido IFS-2026-3330): un pedido
        // 'pendiente_pago' (por ejemplo, pagado por transferencia y todavía no confirmado)
        // quedaba con paso:2, y el paso 2 del stepper de abajo ("2. Pago") se pinta en verde
        // y dice "Acreditado" para cualquier pasoActual >= 2 — es decir, esta pantalla mostraba
        // "Pago: Acreditado" arriba mientras más abajo (y en la pantalla de confirmación del
        // pedido) se explicaba correctamente que el pago seguía pendiente. Un pedido sin pagar
        // no puede haber completado el paso "Pago", así que ahora se queda en paso:1 (sólo
        // "Pedido" completo) hasta que el estado real sea 'pagado' o 'entregado'.
        const infoEstado = {
          pendiente_pago: { texto: 'Pendiente de Acreditación del Pago', paso: 1, descarga: false },
          pagado: { texto: 'En Laboratorio Fotográfico', paso: 3, descarga: true },
          entregado: { texto: 'Entregado en la Institución', paso: 4, descarga: true },
          cancelado: { texto: 'Pedido Cancelado', paso: 0, descarga: false },
        }[pedidoServidor.estado] || { texto: 'Pendiente de Acreditación del Pago', paso: 1, descarga: false };
        // Pago anticipado ya pagado: todavía no hay fotos elegidas, así que ni laboratorio ni descarga.
        const reservaPagada = Boolean(pedidoServidor.reservaPendiente) && pedidoServidor.estado === 'pagado';
        if (reservaPagada) {
          infoEstado.texto = 'Kit pagado · falta elegir tus fotos';
          infoEstado.paso = 2;
          infoEstado.descarga = false;
        }

        setSearchedOrder({
          id: pedidoServidor.id,
          colegio: pedidoServidor.colegio,
          alumno: `${pedidoServidor.alumno} (${pedidoServidor.grado} ${pedidoServidor.division})`,
          tutor: pedidoServidor.tutor,
          telefono: pedidoServidor.telefono,
          kit: pedidoServidor.kit,
          total: pedidoServidor.total,
          fecha: pedidoServidor.fecha ? new Date(pedidoServidor.fecha).toLocaleDateString('es-AR') : '',
          estado: pedidoServidor.estado,
          estadoTexto: infoEstado.texto,
          descripcionEstado:
            pedidoServidor.estado === 'cancelado'
              ? 'Este pedido fue cancelado. Si creés que es un error, escribinos por email o desde el formulario de Consultas del sitio.'
              : reservaPagada
              ? 'Pagaste el kit por adelantado. Cuando estén las fotos de tu curso, entrá a "Acceder a las Fotos", elegí las 3 y tocá "Confirmar mis fotos" — no tenés que volver a pagar. Ahí te llega la descarga en alta resolución.'
              : pedidoServidor.estado === 'pendiente_pago'
              ? 'Todavía estamos esperando la acreditación de tu pago (por ejemplo, la confirmación de la transferencia bancaria). En cuanto se acredite, te llega por email la descarga de tus fotos y, si elegiste el Kit Impreso, pasa a impresión.'
              : 'Tus fotos se están imprimiendo. Te avisamos por email cuando la carpeta esté lista para retirar en el colegio.',
          pasoActual: infoEstado.paso,
          entregaEstimada: 'Kit impreso: se entrega en el colegio dentro de los 15 días hábiles posteriores al cierre de pedidos del curso',
          descargaLista: infoEstado.descarga,
          linkDescargaHD: pedidoServidor.linkDescargaHD,
          puedeReenviarLink: Boolean(pedidoServidor.puedeReenviarLink),
        });
        setMensajeReenvioLink(null);
        return;
      }
    } catch (err) {
      if (err instanceof ErrorLimiteBusqueda) {
        setSearchedOrder(null);
        setTrackingError(err.message);
        setBuscandoSeguimiento(false);
        return;
      }
      console.warn('Error al consultar el pedido en el servidor, se intenta con datos locales:', err);
    } finally {
      setBuscandoSeguimiento(false);
    }

    // Respaldo: búsqueda en los pedidos guardados en este navegador (por ejemplo, sin conexión)
    const pedidosRegistrados = obtenerPedidosGuardados();
    const cleanNumber = query.replace(/\D/g, '');
    // String(...): pedidos guardados por versiones viejas del sitio pueden no traer estos campos.
    const encontradoEnDb = pedidosRegistrados.find(
      (p) => String(p.id || '').toUpperCase().includes(query) || (cleanNumber.length >= 6 && String(p.tutorTelefono || '').includes(cleanNumber))
    );

    if (encontradoEnDb) {
      // Auditoría 2026-09-23 (bug real): este respaldo mostraba SIEMPRE "En laboratorio" y la
      // descarga como lista, aunque el pedido guardado en el navegador no estuviera pagado. Ahora
      // refleja el estado de pago que se conoce localmente.
      const pagado = encontradoEnDb.estadoPago === 'aprobado';
      const rechazado = encontradoEnDb.estadoPago === 'rechazado';
      setSearchedOrder({
        id: encontradoEnDb.id,
        colegio: encontradoEnDb.colegioNombre,
        alumno: `${encontradoEnDb.alumnoNombre || ''} (${encontradoEnDb.grado || ''} ${encontradoEnDb.division || ''})`,
        tutor: encontradoEnDb.tutorNombre,
        telefono: encontradoEnDb.tutorTelefono,
        kit: encontradoEnDb.kitNombre,
        total: Number(encontradoEnDb.total) || 0,
        fecha: String(encontradoEnDb.fecha || '').split(' ')[0],
        estado: rechazado ? 'cancelado' : pagado ? encontradoEnDb.estadoEntrega : 'pendiente_pago',
        estadoTexto: rechazado
          ? 'Pago rechazado'
          : !pagado
          ? 'Pendiente de Acreditación del Pago'
          : encontradoEnDb.estadoEntrega === 'entregado'
          ? 'Entregado en la Institución'
          : encontradoEnDb.estadoEntrega === 'listo_descarga'
          ? 'Descarga Digital HD Disponible'
          : 'En Laboratorio Fotográfico',
        descripcionEstado: pagado
          ? 'Tus fotos se están imprimiendo. Te avisamos por email cuando la carpeta esté lista para retirar en el colegio.'
          : 'No pudimos confirmar el estado con el servidor. Estos son los datos guardados en este dispositivo; si ya pagaste, volvé a consultar en unos minutos.',
        pasoActual: pagado ? 3 : rechazado ? 0 : 1,
        entregaEstimada: 'Kit impreso: se entrega en el colegio dentro de los 15 días hábiles posteriores al cierre de pedidos del curso',
        descargaLista: pagado && Boolean(encontradoEnDb.linkDescargaHD),
        linkDescargaHD: encontradoEnDb.linkDescargaHD,
      });
      return;
    }

    // Si no se encuentra ni en el servidor ni en los pedidos guardados de este navegador
    setSearchedOrder(null);
    setTrackingError('No se encontró ningún pedido registrado con ese número o teléfono. Verificá los datos ingresados.');
  };

  // Auditoría 03/10 (alto 6): aviso que frena la compra cuando no se pudo verificar si ya hay un
  // pedido o un kit pagado para este alumno/a (red, 429, 5xx).
  const renderAvisoVerificacion = () =>
    errorVerificacion ? (
      <div role="alert" className="rounded-xl border-2 border-rose-300 bg-rose-50 p-4 text-left text-rose-900 flex flex-col sm:flex-row sm:items-center gap-3">
        <div className="flex items-start gap-2.5 flex-1">
          <AlertCircle className="h-5 w-5 shrink-0 text-rose-600 mt-0.5" />
          <div className="text-xs">
            <p className="font-bold">No pudimos verificar si ya hiciste un pedido o pagaste un kit</p>
            <p className="mt-0.5 text-rose-800">{errorVerificacion} Para no cobrarte dos veces, esperá a que se pueda verificar antes de comprar.</p>
          </div>
        </div>
        <button
          type="button"
          onClick={() => {
            setErrorSeleccionFotos('');
            setPagoError(null);
            setReintentoVerificacion((n) => n + 1);
          }}
          className="shrink-0 inline-flex items-center justify-center gap-1.5 rounded-lg bg-rose-600 px-3 py-2 text-xs font-bold text-white hover:bg-rose-500 cursor-pointer"
        >
          <RefreshCw className="h-3.5 w-3.5" /> Reintentar
        </button>
      </div>
    ) : null;

  // Auditoría 03/10 noche (R12): no se pudo traer la lista de hijos (429/5xx/red).
  const renderAvisoHijos = () =>
    errorHijosFamilia ? (
      <div role="alert" className="rounded-xl border-2 border-rose-300 bg-rose-50 p-4 text-left text-rose-900 flex flex-col sm:flex-row sm:items-center gap-3">
        <div className="flex items-start gap-2.5 flex-1">
          <AlertCircle className="h-5 w-5 shrink-0 text-rose-600 mt-0.5" />
          <div className="text-xs">
            <p className="font-bold">No pudimos cargar a tus otros hijos.</p>
            <p className="mt-0.5 text-rose-800">{errorHijosFamilia !== 'No pudimos cargar a tus otros hijos.' ? `${errorHijosFamilia} ` : ''}Reintentá antes de comprar, así no te quedan hermanos afuera.</p>
          </div>
        </div>
        <button
          type="button"
          onClick={() => {
            setErrorSeleccionFotos('');
            setPagoError(null);
            setReintentoHijos((n) => n + 1);
          }}
          className="shrink-0 inline-flex items-center justify-center gap-1.5 rounded-lg bg-rose-600 px-3 py-2 text-xs font-bold text-white hover:bg-rose-500 cursor-pointer"
        >
          <RefreshCw className="h-3.5 w-3.5" /> Reintentar
        </button>
      </div>
    ) : null;

  // Auditoría 03/10 noche (M8a/R3): hermanos que ya tienen un pedido esperando el pago (por ejemplo
  // una transferencia sin aprobar). No bloquean la compra ni entran solos al carrito: se avisa y la
  // familia elige, con una confirmación explícita, si igual los incluye.
  const hermanosConPedidoPendiente = hijosFamilia.filter(
    (h) => hermanoConPedidoPendiente(h.id) && !tieneKitPagadoPorAdelantado(h.id) && !estadoHermanos[h.id]?.tienePedidoPagado
  );
  const renderAvisoHermanosPendientes = () =>
    hermanosConPedidoPendiente.length > 0 ? (
      <div className="rounded-xl border border-sky-300 bg-sky-50 p-3.5 text-left text-xs text-sky-950 space-y-2">
        {hermanosConPedidoPendiente.map((h) => (
          <div key={h.id} className="space-y-1.5">
            <p>
              <strong>{h.nombreCompleto}</strong> ya tiene un pedido esperando el pago.{' '}
              {decisionHermanoPendiente[h.id] === 'incluir'
                ? 'Lo estás incluyendo igual en esta compra (vas a pagar sus fotos otra vez).'
                : hermanoPendienteSinDecidir(h.id)
                ? 'Ya le elegiste las fotos: decidí si lo incluís en esta compra o seguís sin él.'
                : 'No se incluye en esta compra.'}
            </p>
            {decisionHermanoPendiente[h.id] === 'incluir' ? (
              <button
                type="button"
                onClick={() => setDecisionHermanoPendiente((prev) => ({ ...prev, [h.id]: 'sin' }))}
                className="rounded-lg border border-sky-300 bg-white px-3 py-1.5 font-bold text-sky-800 hover:bg-sky-100 cursor-pointer"
              >
                Seguir sin {h.nombreCompleto}
              </button>
            ) : confirmandoIncluirHermano === h.id ? (
              <div className="rounded-lg border border-amber-300 bg-amber-50 p-2.5 space-y-2 text-amber-950">
                <p>
                  ¿Seguro? Si incluís a {h.nombreCompleto}, se suma un pedido nuevo con sus fotos y se cobra aparte del que ya está esperando el pago.
                </p>
                <div className="flex flex-wrap gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      setDecisionHermanoPendiente((prev) => ({ ...prev, [h.id]: 'incluir' }));
                      setConfirmandoIncluirHermano(null);
                    }}
                    className="rounded-lg bg-amber-400 px-3 py-1.5 font-extrabold text-slate-950 hover:bg-amber-300 cursor-pointer"
                  >
                    Sí, incluir a {h.nombreCompleto}
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setConfirmandoIncluirHermano(null);
                      setDecisionHermanoPendiente((prev) => ({ ...prev, [h.id]: 'sin' }));
                      setErrorSeleccionFotos('');
                      setPagoError(null);
                    }}
                    className="rounded-lg border border-slate-300 bg-white px-3 py-1.5 font-bold text-slate-800 hover:bg-slate-50 cursor-pointer"
                  >
                    No, seguir sin {h.nombreCompleto}
                  </button>
                </div>
              </div>
            ) : (
              <div className="flex flex-wrap gap-2">
                <button
                  type="button"
                  onClick={() => setConfirmandoIncluirHermano(h.id)}
                  className="rounded-lg border border-sky-300 bg-white px-3 py-1.5 font-bold text-sky-800 hover:bg-sky-100 cursor-pointer"
                >
                  Incluirlo igual en esta compra
                </button>
                {hermanoPendienteSinDecidir(h.id) && (
                  <button
                    type="button"
                    onClick={() => {
                      setDecisionHermanoPendiente((prev) => ({ ...prev, [h.id]: 'sin' }));
                      setErrorSeleccionFotos('');
                      setPagoError(null);
                    }}
                    className="rounded-lg border border-slate-300 bg-white px-3 py-1.5 font-bold text-slate-800 hover:bg-slate-50 cursor-pointer"
                  >
                    Seguir sin {h.nombreCompleto}
                  </button>
                )}
              </div>
            )}
          </div>
        ))}
      </div>
    ) : null;

  /**
   * "Cerrar sesión" del portal. Auditoría 03/10 noche (M11/R5): antes quedaban escritos el nombre y el
   * DNI del tutor en los campos de ingreso, las llaves HD de los pedidos (retrato_llaves_pedidos), la
   * copia local de los pedidos (nombres, teléfono, email) y el `?t=` en la URL — en una PC compartida,
   * el siguiente veía todo eso. Ahora se borra todo, junto con el carrito y la compra en curso
   * (M8b/R4: no se suma a la compra de la próxima familia que entre).
   */
  const cerrarSesionPortal = () => {
    cerrarSesionFamilia();
    borrarLlavesPedidos();
    borrarPedidosLocalesDelPortal();
    try {
      const url = new URL(window.location.href);
      ['t', 'pedido_id', 'grupo_pago_id', 'mp_status', 'nave_status', 'status', 'payment_id', 'collection_id', 'collection_status', 'pago_pendiente', 'reserva', 'confirmar-acceso'].forEach((k) =>
        url.searchParams.delete(k)
      );
      window.history.replaceState(null, '', url.pathname + url.search + url.hash);
    } catch {
      /* URL inválida: no hay nada que sacar */
    }
    idsDelRetornoMpRef.current = new Set();
    codigoPrecargadoRef.current = '';
    limpiarCompraTerminada();
    setFamiliaActiva(null);
    setHijoSeleccionadoId('principal');
    setHijosFamilia([]);
    setErrorHijosFamilia(null);
    setCodigoAcceso('');
    setCodigoTutorNombreInput('');
    setCodigoTutorDniInput('');
    setCodigoValidadoMsg(null);
    setCodigoErrorMsg(null);
    setCodigoAviso(null);
    setCodigoSeccionValidado(null);
    setPedidoExistente(null);
    setReservaActiva(null);
    setResultadoReserva(null);
    setReservasPorHijo({});
    setReservaConfirmadaPorHijo({}); // 05/10 (bug 4)
    reservasConfirmadasRef.current = new Set();
    setQuiereOtroPedido(false);
    setFotosDisponibles([]);
    setTutorNombre('');
    setTutorWhatsapp('');
    setTutorEmail('');
    setNombreAlumno('');
    setPedidoGenerado(null);
    setNumeroPedido('');
    setPedidoYaNoExiste(false);
    setMpRedirectUrl(null);
    setNaveRedirectUrl(null);
    setPagoError(null);
    setMensajeEstadoPago(null);
    setConfirmacionOtroKit(null);
    setConfirmoPagarDeNuevo(false);
    setPreguntandoPagarDeNuevo(false);
    setSearchedOrder(null);
    setTrackingQuery('');
    setAceptaTerminos(false);
    setAceptaPlazoTransferencia(false);
    setStep(1);
  };

  // 14/10/2026: «Pagar ahora» de un pedido pendiente con tarjeta hecho en otro dispositivo (la llave la
  // guardó consultarPedidoExistente): se abre en el Paso 5, que ya tiene el link de pago y «pagar de otra forma».
  const abrirPedidoExistenteParaPagar = () => {
    const p = pedidoExistente;
    if (!p?.pedidoUuid) return;
    const referencia = p.grupoPagoId || p.pedidoUuid;
    const metodo = (p.metodoPago === 'nave' || p.metodoPago === 'transferencia' ? p.metodoPago : 'mercadopago') as PedidoEscolarCompleto['metodoPago'];
    generacionPedidoRef.current += 1;
    const base = pedidoDeRespaldo({ referencia, esGrupo: Boolean(p.grupoPagoId), metodoPago: metodo, estadoPago: 'pendiente' });
    setPedidoGenerado({ ...base, id: p.id, total: Number(p.total) || 0, kitNombre: p.kit || base.kitNombre, alumnoNombre: nombreAlumno, tutorNombre: tutorNombre || familiaActiva?.padreNombre || '', tutorEmail: tutorEmail || familiaActiva?.email || '' });
    setNumeroPedido(p.id);
    setPedidoExistente(null);
    setStep(5);
    void verificarEstadoRealPedido(referencia);
  };

  // Código vencido o falta la llave (POR-10, 11/10): se cierra la sesión guardada para que aparezca el ingreso.
  const reingresarPorCodigoVencido = () => {
    cerrarSesionFamilia();
    setFamiliaActiva(null);
    setCodigoValidadoMsg(null);
    setCodigoSeccionValidado(null);
    setStep(1);
  };

  alEscapeRef.current = () => {
    if (modalFotoPreview) setModalFotoPreview(null);
    else if (confirmacionOtroKit) setConfirmacionOtroKit(null);
    else if (confirmacionAcceso) cerrarConfirmacionAcceso();
    else onClose();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-0 sm:p-4 md:p-6 animate-in fade-in duration-200">
      {/* Celular: pantalla completa. Paso 1: ancho angosto; galería y demás pasos: hasta 7xl. */}
      <div className={`relative w-full bg-white rounded-none sm:rounded-3xl shadow-2xl border-0 sm:border border-slate-200 overflow-hidden flex flex-col h-full sm:h-auto sm:max-h-[95vh] ${modalMode === 'pedido' && step === 1 ? 'max-w-3xl' : 'max-w-5xl xl:max-w-7xl'}`}>
        {/* Top Modal Bar */}
        <div className="px-3 py-3 sm:px-6 sm:py-4 bg-slate-900 text-white flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between shrink-0">
          <div className="flex items-center justify-between gap-3">
            <div className="flex items-center gap-3 min-w-0">
              <ViewfinderFocusIcon className="w-8 h-8 shrink-0" theme="dark" />
              <div className="min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="text-base font-extrabold font-['Outfit'] tracking-tight">
                    Retrato<span className="text-amber-400">Escolar</span>
                  </span>
                  <span className="text-[10px] bg-slate-800 text-amber-400 font-bold px-2 py-0.5 rounded border border-slate-700">
                    Portal de Familias
                  </span>
                </div>
                <p className="text-xs text-slate-400 truncate">
                  {selectedColegio ? `${selectedColegio.nombre} · Ciclo 2026` : 'retratoescolar.com.ar · Ciclo Escolar 2026'}
                </p>
              </div>
            </div>

            {/* Close button: on mobile it lives here, next to the brand, so it never gets pushed off-screen by the tabs below */}
            <button
              onClick={onClose}
              className="sm:hidden p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors cursor-pointer shrink-0"
              aria-label="Cerrar"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <div className="flex items-center gap-3 sm:gap-4">
            {/* Tab switch between order and tracking */}
            <div className="flex items-center bg-slate-800 p-1 rounded-xl border border-slate-700 text-xs flex-1 sm:flex-initial">
              <button
                type="button"
                onClick={irAVerFotosYComprar}
                className={`flex-1 sm:flex-initial text-center px-3 py-2.5 sm:py-1.5 rounded-lg font-semibold transition-all cursor-pointer ${
                  modalMode === 'pedido'
                    ? 'bg-amber-400 text-slate-950 shadow-xs'
                    : 'text-slate-300 hover:text-white'
                }`}
              >
                Ver Fotos / Comprar
              </button>
              <button
                type="button"
                onClick={() => {
                  setModalMode('seguimiento');
                }}
                className={`flex-1 sm:flex-initial text-center px-3 py-2.5 sm:py-1.5 rounded-lg font-semibold transition-all cursor-pointer ${
                  modalMode === 'seguimiento'
                    ? 'bg-amber-400 text-slate-950 shadow-xs'
                    : 'text-slate-300 hover:text-white'
                }`}
              >
                Consultar Mi Pedido
              </button>
            </div>

            {/* Step indicator breadcrumb (only in pedido mode) */}
            {modalMode === 'pedido' && (
              <div className="hidden lg:flex items-center gap-2 text-xs font-semibold text-slate-400">
                <span className={step >= 1 ? 'text-amber-400 font-bold' : ''}>1. Alumno</span>
                <span>›</span>
                <span className={step >= 2 ? 'text-amber-400 font-bold' : ''}>2. Galería</span>
                <span>›</span>
                <span className={step >= 3 ? 'text-amber-400 font-bold' : ''}>3. Kit</span>
                <span>›</span>
                <span className={step >= 4 ? 'text-amber-400 font-bold' : ''}>4. Pago</span>
              </div>
            )}

            {/* Close button: on sm+ it stays in its original spot on the right */}
            <button
              onClick={onClose}
              className="hidden sm:inline-flex p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
              aria-label="Cerrar"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Scrollable Body */}
        {/* Auditoría 2026-09-22: padding vertical reducido (antes p-5 sm:p-8) para ganar algo más
            de alto disponible en pantalla y scrollear un poco menos en escritorio — ver también el
            bloque sticky del Paso 2 más abajo, que compensa este mismo valor para poder pegarse
            al borde superior real de esta zona con scroll.
            Auditoría 2026-09-22 (bis, pedido de Pablo: "hay un espacio transparente que se podría
            eliminar, se nota porque pasa la barra azul por detrás"): el fondo de esta zona tenía
            50% de opacidad (bg-slate-50/50) en vez de sólido. Con el modal superpuesto sobre un
            fondo oscuro desenfocado (backdrop-blur), cualquier hueco de esta zona dejaba pasar ese
            fondo oscuro. Ahora es 100% opaco (bg-slate-50, sin "/50"). */}
        <div className="overflow-y-auto p-4 sm:p-6 flex-1 bg-slate-50">
          {/* TRACKING TOOL VIEW */}
          {modalMode === 'seguimiento' && (
            <div className="max-w-3xl mx-auto space-y-6 animate-in fade-in duration-200">
              <div className="text-center space-y-2">
                <div className="w-12 h-12 rounded-2xl bg-amber-100 text-amber-900 flex items-center justify-center mx-auto mb-2">
                  <Package className="w-6 h-6" />
                </div>
                <h3 className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-['Outfit']">
                  Consultar Estado de Mi Pedido
                </h3>
                <p className="text-xs sm:text-sm text-slate-600 max-w-lg mx-auto">
                  Ingresá el número de pedido provisto al momento del pago o tu número de WhatsApp para conocer el estado en tiempo real.
                </p>
              </div>

              {/* Search Box */}
              <div className="bg-white p-3 rounded-2xl border border-slate-200 shadow-sm max-w-xl mx-auto">
                <form onSubmit={handleConsultarSeguimiento} className="flex gap-2">
                  <div className="relative flex-1">
                    <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                    <input
                      type="text"
                      value={trackingQuery}
                      onChange={(e) => setTrackingQuery(e.target.value)}
                      placeholder="Ingresá tu N° de pedido que te enviamos por email..."
                      className="w-full pl-10 pr-3 py-2.5 text-xs text-slate-900 placeholder:text-slate-400 bg-slate-50 rounded-xl border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-amber-400"
                    />
                  </div>
                  <button
                    type="submit"
                    disabled={buscandoSeguimiento}
                    className="px-5 py-2.5 bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-xs rounded-xl transition-all cursor-pointer shrink-0 shadow-xs disabled:opacity-60 disabled:cursor-not-allowed"
                  >
                    {buscandoSeguimiento ? 'Buscando...' : 'Consultar'}
                  </button>
                </form>

                {trackingError && (
                  <p className="text-[11px] text-red-600 mt-2 text-left px-2">{trackingError}</p>
                )}
              </div>

              {/* Order Result Card */}
              {searchedOrder && (
                <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-md text-left space-y-6 animate-in zoom-in-95 duration-150">
                  {/* Card Header */}
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-100 gap-3">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-mono font-bold px-2 py-0.5 rounded bg-slate-900 text-amber-400">
                          {searchedOrder.id}
                        </span>
                        <span className="text-xs text-slate-400">Fecha: {searchedOrder.fecha}</span>
                      </div>
                      <h4 className="text-lg font-bold text-slate-900 mt-1 font-['Outfit']">
                        {searchedOrder.alumno}
                      </h4>
                      <p className="text-xs text-slate-600">{searchedOrder.colegio}</p>
                    </div>

                    <div className="text-left sm:text-right">
                      <span className="text-[10px] uppercase font-bold tracking-wider text-slate-400 block">
                        Kit Seleccionado
                      </span>
                      <span className="text-xs font-bold text-slate-900">{searchedOrder.kit}</span>
                      <span className="text-xs font-black text-amber-600 block mt-0.5">
                        ${(Number(searchedOrder.total) || 0).toLocaleString('es-AR')} ARS
                      </span>
                    </div>
                  </div>

                  {/* 4-Step Progress Tracker */}
                  <div className="space-y-3">
                    <p className="text-xs font-bold uppercase tracking-wider text-slate-500">
                      Progreso de Producción
                    </p>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                      <div className={`p-3 rounded-xl border text-left ${searchedOrder.pasoActual >= 1 ? 'bg-emerald-50/60 border-emerald-300' : 'bg-slate-50 border-slate-200 opacity-60'}`}>
                        <div className="flex items-center gap-1.5 text-emerald-700 font-bold text-xs mb-1">
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          <span>1. Pedido</span>
                        </div>
                        <p className="text-[10px] text-slate-600">Registrado online</p>
                      </div>

                      <div className={`p-3 rounded-xl border text-left ${searchedOrder.pasoActual >= 2 ? 'bg-emerald-50/60 border-emerald-300' : 'bg-slate-50 border-slate-200 opacity-60'}`}>
                        <div className={`flex items-center gap-1.5 font-bold text-xs mb-1 ${searchedOrder.pasoActual >= 2 ? 'text-emerald-700' : 'text-slate-500'}`}>
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          <span>2. Pago</span>
                        </div>
                        <p className="text-[10px] text-slate-600">{searchedOrder.pasoActual >= 2 ? 'Acreditado' : 'Pendiente'}</p>
                      </div>

                      <div className={`p-3 rounded-xl border text-left ${searchedOrder.pasoActual >= 3 ? 'bg-amber-50/80 border-amber-400' : 'bg-slate-50 border-slate-200 opacity-60'}`}>
                        <div className="flex items-center gap-1.5 text-amber-800 font-bold text-xs mb-1">
                          <Clock className="w-3.5 h-3.5 text-amber-600" />
                          <span>3. Laboratorio</span>
                        </div>
                        <p className="text-[10px] text-slate-600">Revelado químico 260g</p>
                      </div>

                      <div className={`p-3 rounded-xl border text-left ${searchedOrder.pasoActual >= 4 ? 'bg-emerald-50/60 border-emerald-300' : 'bg-slate-50 border-slate-200 opacity-60'}`}>
                        <div className="flex items-center gap-1.5 text-slate-800 font-bold text-xs mb-1">
                          <Truck className="w-3.5 h-3.5 text-slate-600" />
                          <span>4. Entrega</span>
                        </div>
                        <p className="text-[10px] text-slate-600">Sobre cerrado en escuela</p>
                      </div>
                    </div>
                  </div>

                  {/* Status Detail Banner */}
                  <div className="p-4 bg-amber-50/60 rounded-xl border border-amber-200 text-xs space-y-1">
                    <p className="font-bold text-amber-950 flex items-center gap-2">
                      <span className="w-2 h-2 rounded-full bg-amber-500 animate-pulse" />
                      <span>{searchedOrder.estadoTexto}</span>
                    </p>
                    <p className="text-slate-700">{searchedOrder.descripcionEstado}</p>
                    <p className="text-[11px] font-semibold text-amber-800 pt-1">
                      {searchedOrder.entregaEstimada}
                    </p>
                  </div>

                  {/* Actions */}
                  <div className="pt-2 flex flex-col sm:flex-row gap-3 items-center justify-between border-t border-slate-100">
                    {searchedOrder.descargaLista && !searchedOrder.linkDescargaHD && searchedOrder.puedeReenviarLink && (
                      <div className="w-full sm:w-auto flex flex-col gap-1">
                        <button
                          type="button"
                          disabled={reenviandoLink}
                          onClick={async () => {
                            setReenviandoLink(true);
                            const r = await reenviarLinkDescargaPorEmail(String(searchedOrder.id || ''));
                            setReenviandoLink(false);
                            setMensajeReenvioLink(
                              r.success
                                ? `${r.mensaje || 'Te mandamos el link de descarga por email.'}${r.emailDestino ? ` (${r.emailDestino})` : ''} Revisá también Spam.`
                                : r.error || 'No pudimos reenviar el link.'
                            );
                          }}
                          className="w-full sm:w-auto px-4 py-2.5 bg-slate-900 hover:bg-slate-800 disabled:opacity-60 text-white text-xs font-bold rounded-xl transition-all shadow-xs flex items-center justify-center gap-2"
                        >
                          <Download className="w-3.5 h-3.5 text-amber-400" />
                          <span>{reenviandoLink ? 'Enviando…' : 'Enviarme el link de descarga por email'}</span>
                        </button>
                        {mensajeReenvioLink && <p className="text-[11px] text-slate-600">{mensajeReenvioLink}</p>}
                      </div>
                    )}
                    {searchedOrder.descargaLista && searchedOrder.linkDescargaHD && (
                      <a
                        href={searchedOrder.linkDescargaHD}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="w-full sm:w-auto px-4 py-2.5 bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold rounded-xl transition-all shadow-xs flex items-center justify-center gap-2"
                      >
                        <Download className="w-3.5 h-3.5 text-amber-400" />
                        <span>Descargar Archivos Digitales HD</span>
                      </a>
                    )}

                    <div className="flex gap-2 w-full sm:w-auto">
                      {/* Auditoría 2026-09-18 (pedido de Pablo): se sacó "Consultar por
                          WhatsApp" — las familias no deben tener ningún punto de contacto por
                          WhatsApp en la web, solo por email o el sistema de mensajería propio
                          del sitio (Consultas). Auditoría 2026-09-18 (reporte de Pablo, mismo
                          día): un mailto: no hace nada visible si el navegador no tiene un
                          cliente de correo configurado — Pablo lo probó y "no se abre nada,
                          solo vuelve a la web". Ahora lleva directo al formulario de Consultas
                          del sitio (con los datos del pedido precargados), que sí manda un
                          mensaje real. Ver src/utils/consultaPrefill.ts. */}
                      <button
                        type="button"
                        onClick={() =>
                          irAConsultasConDatos(
                            {
                              nombre: '', // el buscador devuelve el nombre abreviado (28/9)
                              // El servidor devuelve el teléfono enmascarado (***1234) desde el 23/9.
                              telefono: searchedOrder.telefono && !searchedOrder.telefono.startsWith('***') ? searchedOrder.telefono : '',
                              colegio: searchedOrder.colegio || '',
                              numeroPedido: searchedOrder.id || '',
                              asunto: 'Consulta sobre las fotos de mi hijo/a',
                              mensaje: `Hola, tengo una consulta sobre mi pedido ${searchedOrder.id} (${searchedOrder.alumno}).`,
                            },
                            onClose
                          )
                        }
                        className="flex-1 sm:flex-initial px-4 py-2.5 bg-sky-600 hover:bg-sky-500 text-white text-xs font-bold rounded-xl transition-colors flex items-center justify-center gap-2 cursor-pointer"
                      >
                        <Mail className="w-3.5 h-3.5" />
                        <span>Consultar por Email</span>
                      </button>
                      <button
                        type="button"
                        onClick={irAVerFotosYComprar}
                        className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-semibold rounded-xl transition-colors cursor-pointer"
                      >
                        Ir a Comprar Fotos
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* STEP 1: School & Student Selection (ORDER FLOW) */}
          {modalMode === 'pedido' && step === 1 && (
            <div className="max-w-3xl mx-auto space-y-8 animate-in fade-in duration-200">
              <div className="text-center space-y-2">
                {/* Auditoría 2026-09-22 (pedido de Pablo): con la familia ya identificada en este
                    navegador no hace falta buscar colegio ni ingresar ningún código — ese trabajo
                    ya está hecho. El título y el subtítulo de "buscar/ingresar" quedan sólo para
                    cuando todavía no hay una familia validada. */}
                <h3 className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-['Outfit']">
                  {familiaActiva && codigoValidadoMsg && selectedColegio ? 'Acceso validado' : 'Entrá a las fotos de tu hijo/a'}
                </h3>
                {/* 2/10: una familia guardada en el navegador SIN código válido (inscripción todavía
                    sin aprobar, o datos viejos) veía "Acceso validado" y nada más abajo: ahora ve el
                    formulario de ingreso. */}
                {!(familiaActiva && codigoValidadoMsg && selectedColegio) && (
                  <p className="text-xs sm:text-sm text-slate-600">
                    Con tu nombre, tu DNI y el código de acceso del curso.
                  </p>
                )}
              </div>

              {/* Auditoría 2026-09-22 (pedido de Pablo, tras repaso completo de la pantalla real:
                  "es demasiado! el sistema debe ser extremadamente simple para ingresar"): con la
                  familia ya identificada en este navegador, esta tarjeta de identificación
                  (nombre+DNI+código) y la tarjeta de abajo con los mismos hijos repetidos se
                  mostraban las DOS a la vez, con el código y los datos duplicados. Ahora esta
                  tarjeta sólo aparece mientras la familia todavía no está identificada; apenas se
                  valida (o al reabrir con la sesión ya guardada) desaparece y queda una sola
                  tarjeta abajo con el saludo y el botón para entrar. */}
              {!(familiaActiva && codigoValidadoMsg && selectedColegio) && (
              <>
              {/* Hero Course Code Access Card */}
              <div className="bg-linear-to-br from-amber-500/10 via-amber-50 to-white rounded-2xl p-5 sm:p-6 border-2 border-amber-300 shadow-sm space-y-4">
                <div className="flex flex-col gap-3">
                  <div className="text-left">
                    <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-amber-400 text-slate-950 text-[10px] font-extrabold uppercase tracking-wider mb-1">
                      <Key className="w-3 h-3" />
                      Acceso para Familias
                    </span>
                    <h4 className="text-base sm:text-lg font-extrabold text-slate-900 font-['Outfit']">
                      Ingresá con tus datos y el código de acceso
                    </h4>
                    <p className="text-xs text-slate-600 mt-0.5">
                      {/* Auditoría 2026-09-22 (pedido de Pablo): el código lo comparte todo el
                          curso, así que ahora hacen falta también el nombre y DNI del tutor con el
                          que se inscribió la familia, para identificar exactamente a tus hijos. */}
                      El código es el mismo para todo el curso — con tu nombre y DNI identificamos a tu familia y cargamos automáticamente el curso, turno y división.
                    </p>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    <input
                      type="text"
                      value={codigoTutorNombreInput}
                      onChange={(e) => {
                        setCodigoTutorNombreInput(e.target.value);
                        setCodigoErrorMsg(null);
                      }}
                      placeholder="Nombre y apellido del tutor"
                      autoComplete="name"
                      className="px-3.5 py-2.5 text-xs sm:text-sm bg-white border-2 border-amber-300 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-amber-500 w-full shadow-xs"
                    />
                    <input
                      type="text"
                      inputMode="numeric"
                      value={codigoTutorDniInput}
                      onChange={(e) => {
                        setCodigoTutorDniInput(e.target.value);
                        setCodigoErrorMsg(null);
                      }}
                      placeholder="DNI del tutor (sin puntos)"
                      autoComplete="off"
                      className="px-3.5 py-2.5 text-xs sm:text-sm bg-white border-2 border-amber-300 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-amber-500 w-full shadow-xs"
                    />
                  </div>

                  <div className="flex items-start gap-2 w-full sm:w-auto">
                    <div className="w-full sm:w-56">
                    <input
                      type="text"
                      value={codigoAcceso}
                      onChange={(e) => {
                        setCodigoAcceso(e.target.value);
                        setCodigoErrorMsg(null);
                      }}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') {
                          handleIngresarCodigo();
                        }
                      }}
                      placeholder="Código de acceso"
                      aria-label="Código de acceso del curso"
                      className="px-3.5 py-2.5 text-xs sm:text-sm uppercase placeholder:normal-case font-mono placeholder:font-sans font-bold placeholder:font-normal tracking-wider placeholder:tracking-normal bg-white border-2 border-amber-300 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-amber-500 w-full shadow-xs"
                    />
                    <p className="mt-1 pl-1 text-[10px] text-slate-500">Te llegó por email al inscribirte (ej: 88BU-M8TF)</p>
                    </div>
                    <button
                      type="button"
                      onClick={handleIngresarCodigo}
                      disabled={validandoCodigo}
                      aria-busy={validandoCodigo}
                      className="px-4 py-2.5 bg-slate-900 hover:bg-slate-800 text-amber-300 hover:text-white font-bold text-xs rounded-xl shadow-sm cursor-pointer shrink-0 transition-colors flex items-center gap-1.5 disabled:opacity-70 disabled:cursor-wait"
                    >
                      {validandoCodigo ? <Loader2 className="w-3.5 h-3.5 text-amber-400 animate-spin" /> : <Sparkles className="w-3.5 h-3.5 text-amber-400" />}
                      <span>{validandoCodigo ? 'Validando…' : 'Validar'}</span>
                    </button>
                  </div>
                </div>

                {/* Auditoría 03/10 noche (contratos 2, 3 y 4): aviso que no es un error de datos. */}
                {codigoAviso && !codigoValidadoMsg && (
                  <div
                    role="status"
                    className={`p-3 rounded-xl text-left flex items-start gap-2 text-xs font-semibold ${
                      codigoAviso.tipo === 'ok' ? 'bg-emerald-50 border border-emerald-300 text-emerald-900' : 'bg-amber-50 border border-amber-300 text-amber-950'
                    }`}
                  >
                    {codigoAviso.tipo === 'ok' ? <CheckCheck className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" /> : <Mail className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />}
                    <p>{codigoAviso.texto}</p>
                  </div>
                )}

                {/* Validation Success Feedback Banner */}
                {codigoValidadoMsg && (
                  <div className="p-3.5 bg-emerald-50 border border-emerald-300 rounded-xl text-left flex items-start justify-between gap-3 animate-in fade-in duration-200">
                    <div className="flex items-start gap-2.5">
                      <CheckCheck className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                      <div>
                        <p className="text-xs font-bold text-emerald-950">
                          {codigoValidadoMsg}
                        </p>
                        {hijosFamilia.length > 1 ? (
                          <div className="mt-1 space-y-0.5">
                            {hijosFamilia.map((h) => (
                              <p key={h.id} className="text-[11px] text-emerald-800">
                                <span className="font-bold">{h.nombreCompleto}:</span> {h.grado || '—'} · División {h.division || '—'} · Turno {h.turno || '—'}
                              </p>
                            ))}
                            <p className="text-[11px] text-emerald-800">
                              Podés confirmar o cambiar los datos a continuación y seleccionar a cada hijo/a.
                            </p>
                          </div>
                        ) : (
                          <p className="text-[11px] text-emerald-800 mt-0.5">
                            Asignado: {grado} · División {division} · Turno {turno}. Podés confirmar o cambiar los datos a continuación y seleccionar a tu hijo/a.
                          </p>
                        )}
                      </div>
                    </div>
                    <span className="px-2 py-0.5 bg-emerald-200 text-emerald-900 text-[10px] font-extrabold rounded-md uppercase">
                      Activo
                    </span>
                  </div>
                )}

                {/* Error Feedback */}
                {codigoErrorMsg && (
                  <div className="p-3 bg-rose-50 border border-rose-300 rounded-xl text-left flex items-start gap-2 text-rose-800 text-xs animate-in fade-in duration-200">
                    <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                    <div>
                      <p className="font-bold">{codigoErrorMsg}</p>
                      <p className="text-[11px] text-rose-700 mt-0.5">
                        Si no lo tenés a mano, tocá "Pedir mi código" acá abajo y te lo mandamos por email.
                      </p>
                    </div>
                  </div>
                )}

                {/* Course Code Request Action: queda guardado para el panel admin, no abre WhatsApp */}
                <div className="pt-3 border-t border-amber-200/80 text-left">
                  {solicitudCodigoEnviada && solicitudCodigoEncontrada ? (
                    <div className="p-4 sm:p-5 bg-emerald-50 border border-emerald-300 rounded-xl flex items-start gap-3">
                      <CheckCheck className="w-6 h-6 text-emerald-700 shrink-0 mt-0.5" />
                      <div>
                        <p className="text-lg font-extrabold text-emerald-950">¡Listo!</p>
                        <p className="text-base leading-7 text-emerald-950 mt-1.5 font-medium">
                          {solicitudCodigoMensaje}
                        </p>
                      </div>
                    </div>
                  ) : solicitudCodigoEnviada ? (
                    /* Pedido de Pablo (25/9): antes decía "¡Listo! Recibimos tu solicitud" y la familia
                       se quedaba esperando un código que no iba a llegar solo. */
                    <div className="p-4 sm:p-5 bg-amber-50 border border-amber-300 rounded-xl space-y-3">
                      <div className="flex items-start gap-3">
                        <AlertCircle className="w-6 h-6 text-amber-600 shrink-0 mt-0.5" />
                        <div>
                          <p className="text-base font-extrabold text-amber-950">{solicitudCodigoMensaje}</p>
                          {solicitudCodigoMotivo !== 'pendiente' && <p className="text-sm text-amber-900 mt-1 leading-relaxed">¿Te inscribiste con otro email? Probá con ese.</p>}
                        </div>
                      </div>
                      <div className="flex flex-col sm:flex-row gap-2">
                        <button
                          type="button"
                          onClick={() => {
                            setSolicitudCodigoEnviada(false);
                            setSolicitudContacto('');
                            setMostrarFormSolicitudCodigo(true);
                          }}
                          className="px-4 py-2.5 bg-white hover:bg-amber-100 border border-amber-300 text-amber-900 font-bold text-xs rounded-xl cursor-pointer"
                        >
                          Probar con otro email
                        </button>
                        {onOpenInscripcion && solicitudCodigoMotivo !== 'pendiente' && (
                          <button
                            type="button"
                            onClick={() => onOpenInscripcion()}
                            className="px-4 py-2.5 bg-amber-400 hover:bg-amber-300 text-slate-950 font-extrabold text-xs rounded-xl flex items-center justify-center gap-1.5 cursor-pointer"
                          >
                            <UserPlus className="w-4 h-4" />
                            Anotarme gratis
                          </button>
                        )}
                      </div>
                    </div>
                  ) : !mostrarFormSolicitudCodigo ? (
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                      <div className="text-slate-700 text-xs space-y-0.5">
                        <p className="font-bold text-slate-900 flex items-center gap-1.5">
                          <Mail className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                          <span>¿No tenés el código? Te lo mandamos por email</span>
                        </p>
                        <p className="text-[11px] text-slate-600 leading-relaxed">
                          Completá tus datos y te lo enviamos al email con el que te inscribiste.
                        </p>
                      </div>
                      <button
                        type="button"
                        onClick={() => setMostrarFormSolicitudCodigo(true)}
                        className="px-4 py-2.5 bg-slate-900 hover:bg-slate-800 text-amber-300 hover:text-white font-extrabold text-xs rounded-xl shadow-xs transition-all flex items-center justify-center gap-1.5 cursor-pointer shrink-0 active:scale-98"
                      >
                        <Mail className="w-4 h-4" />
                        <span>Pedir mi código</span>
                      </button>
                    </div>
                  ) : (
                    <div className="space-y-2.5">
                      <p className="font-bold text-slate-900 text-xs flex items-center gap-1.5">
                        <Mail className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                        <span>¿No tenés el código? Te lo mandamos por email</span>
                      </p>
                      <p className="text-[11px] text-slate-600 -mt-1">Completá tus datos y te lo enviamos al email con el que te inscribiste.</p>
                      <div className="flex flex-col sm:flex-row gap-2">
                        <input
                          type="text"
                          value={solicitudNombre}
                          onChange={(e) => setSolicitudNombre(e.target.value)}
                          placeholder="Tu nombre y apellido"
                          className="flex-1 px-3.5 py-2.5 text-xs sm:text-sm bg-white border-2 border-amber-300 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-amber-500 shadow-xs"
                        />
                        <input
                          type="email"
                          value={solicitudContacto}
                          onChange={(e) => {
                            setSolicitudContacto(e.target.value);
                            setSugerenciaEmailSolicitud(null);
                          }}
                          placeholder="Email usado al registrarte"
                          autoComplete="email"
                          className="flex-1 px-3.5 py-2.5 text-xs sm:text-sm bg-white border-2 border-amber-300 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-amber-500 shadow-xs"
                        />
                      </div>
                      {/* Auditoría 2026-09-16 (pedido de Pablo): colegio y alumno ahora se piden
                          acá mismo (y son obligatorios, ver handleEnviarSolicitudCodigo) — antes
                          dependían de pantallas anteriores que esta familia podía no haber
                          completado todavía. */}
                      <div className="flex flex-col sm:flex-row gap-2">
                        <select
                          value={selectedColegio?.id || ''}
                          onChange={(e) => {
                            const colegioElegido = colegios.find((c) => c.id === e.target.value) || null;
                            setSelectedColegio(colegioElegido);
                          }}
                          className="flex-1 px-3.5 py-2.5 text-xs sm:text-sm bg-white border-2 border-amber-300 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-amber-500 shadow-xs"
                        >
                          <option value="">Colegio de tu hijo/a</option>
                          {colegios.map((c) => (
                            <option key={c.id} value={c.id}>{c.nombre}</option>
                          ))}
                        </select>
                        <input
                          type="text"
                          value={nombreAlumno}
                          onChange={(e) => setNombreAlumno(e.target.value)}
                          placeholder="Nombre y apellido de tu hijo/a"
                          className="flex-1 px-3.5 py-2.5 text-xs sm:text-sm bg-white border-2 border-amber-300 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-amber-500 shadow-xs"
                        />
                      </div>
                      {sugerenciaEmailSolicitud && (
                        <div className="p-3 rounded-xl bg-sky-50 border border-sky-300 text-xs text-sky-950 space-y-2">
                          <p>¿Quisiste decir <strong>{sugerenciaEmailSolicitud}</strong>?</p>
                          <div className="flex flex-wrap gap-2">
                            <button
                              type="button"
                              onClick={() => {
                                setSolicitudContacto(sugerenciaEmailSolicitud);
                                setSugerenciaEmailSolicitud(null);
                              }}
                              className="px-3 py-1.5 rounded-lg bg-sky-600 hover:bg-sky-500 text-white font-bold cursor-pointer"
                            >
                              Sí, corregir
                            </button>
                            <button
                              type="button"
                              onClick={() => void handleEnviarSolicitudCodigo({ ignorarSugerencia: true })}
                              className="px-3 py-1.5 rounded-lg bg-white border border-sky-300 text-sky-800 font-bold cursor-pointer"
                            >
                              No, está bien así
                            </button>
                          </div>
                        </div>
                      )}
                      {solicitudCodigoError && (
                        <p className="text-[11px] text-rose-700 font-bold flex items-center gap-1">
                          <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                          {solicitudCodigoError}
                        </p>
                      )}
                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          disabled={enviandoSolicitudCodigo}
                          onClick={() => void handleEnviarSolicitudCodigo()}
                          className="px-4 py-2.5 bg-slate-900 hover:bg-slate-800 disabled:opacity-60 disabled:cursor-not-allowed text-amber-300 hover:text-white font-extrabold text-xs rounded-xl shadow-xs transition-all flex items-center justify-center gap-1.5 cursor-pointer active:scale-98"
                        >
                          <Send className="w-3.5 h-3.5" />
                          <span>{enviandoSolicitudCodigo ? 'Enviando...' : 'Enviarme el código'}</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => setMostrarFormSolicitudCodigo(false)}
                          className="px-3 py-2.5 text-slate-500 hover:text-slate-700 font-bold text-xs rounded-xl cursor-pointer"
                        >
                          Cancelar
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              </div>

              {/* Antes acá había un desplegable para elegir el colegio directamente, sin código.
                  Se sacó: permitía ver fotos reales (con nombre y apellido del alumno) de
                  cualquier sala/turno de cualquier colegio sin identificarse. Ahora la única
                  forma de llegar a la galería es con un código válido (de curso, familiar, o
                  de institución) — recién ahí aparece el formulario de abajo para confirmar
                  los datos del alumno/a. */}
              {!(selectedColegio && codigoValidadoMsg) && (
                <div className="bg-white border border-slate-200 rounded-2xl p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-left">
                  <div>
                    <p className="text-xs font-bold text-slate-900">¿Todavía no te inscribiste?</p>
                    <p className="text-[11px] text-slate-600">Anotate gratis con tus hijos y te mandamos el código de acceso por email.</p>
                  </div>
                  {onOpenInscripcion && (
                    <button
                      type="button"
                      onClick={() => onOpenInscripcion()}
                      className="px-4 py-2.5 bg-amber-400 hover:bg-amber-300 text-slate-950 font-extrabold text-xs rounded-xl shadow-xs flex items-center justify-center gap-1.5 cursor-pointer shrink-0"
                    >
                      <UserPlus className="w-4 h-4" />
                      <span>Anotarme gratis</span>
                    </button>
                  )}
                </div>
              )}
              </>
              )}

              {/* Student details form */}
              {selectedColegio && codigoValidadoMsg && (
                <div className="bg-white p-5 rounded-2xl border border-slate-200 space-y-4 text-left shadow-xs animate-in fade-in duration-150">
                  {familiaActiva ? (
                    // Auditoría 2026-09-22: única tarjeta que ve una familia ya identificada — antes
                    // se sumaba, arriba, una segunda tarjeta con el código+nombre+DNI ya validados y
                    // los mismos hijos repetidos. Encabezado con saludo directo en vez del rótulo
                    // impersonal "Datos del alumno/a en...".
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                      <div>
                        <h4 className="text-lg font-extrabold text-slate-900 font-['Outfit']">
                          ¡Hola, {familiaActiva.padreNombre}!
                        </h4>
                        <p className="text-[11px] text-slate-500">{selectedColegio.nombre}</p>
                      </div>
                      <div className="flex flex-wrap items-center gap-2">
                        {onOpenInscripcion && (
                          <button
                            type="button"
                            onClick={() => onOpenInscripcion()}
                            className="text-[11px] text-amber-700 hover:text-amber-800 underline font-semibold cursor-pointer"
                          >
                            Cambiar datos
                          </button>
                        )}
                        <span className="text-slate-300">|</span>
                        <button
                          type="button"
                          onClick={cerrarSesionPortal}
                          className="text-[11px] text-rose-600 hover:text-rose-800 underline font-semibold cursor-pointer"
                          title="Cerrar sesión de esta familia"
                        >
                          Cerrar sesión
                        </button>
                      </div>
                    </div>
                  ) : (
                    <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
                      <User className="w-4 h-4 text-amber-600" />
                      <span>Datos del alumno/a en {selectedColegio.nombre}:</span>
                    </h4>
                  )}

                  {/* Con familia verificada, el curso de cada hijo es de sólo lectura (lo confirmó el padrón);
                      el formulario editable queda para quien sólo reconoció la institución. */}
                  {familiaActiva ? (
                    <div className="space-y-2">
                      {hijosFamilia.length > 0 ? (
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                          {hijosFamilia.map((h) => (
                            <div
                              key={h.id}
                              className="flex flex-wrap items-center justify-between gap-x-3 gap-y-1 px-3.5 py-2.5 rounded-xl bg-slate-50 border border-slate-200"
                            >
                              <span className="text-xs font-bold text-slate-900">{h.nombreCompleto}</span>
                              <span className="text-[11px] text-slate-500 font-medium">
                                {h.grado || '—'} "{h.division || '—'}" · Turno {h.turno || '—'}
                              </span>
                            </div>
                          ))}
                        </div>
                      ) : errorHijosFamilia ? null : (
                        <p className="text-xs text-slate-400 italic">Cargando datos confirmados...</p>
                      )}
                      {renderAvisoHijos()}
                      {familiaActiva && <TarjetaFotoHermanos familia={familiaActiva} onActualizada={(f) => { guardarFamiliaActiva(f); setFamiliaActiva(f); }} />}
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3 relative">
                      <div className="sm:col-span-2">
                        <label className="text-[11px] font-semibold text-slate-600 block mb-1">
                          Nombre y Apellido del alumno/a
                        </label>
                        <input
                          type="text"
                          value={nombreAlumno}
                          onChange={(e) => setNombreAlumno(e.target.value)}
                          placeholder="Ej: Benjamín Gómez"
                          className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-amber-400 font-medium"
                        />
                      </div>

                      <div>
                        <label className="text-[11px] font-semibold text-slate-600 block mb-1">
                          Turno
                        </label>
                        <select
                          value={turno}
                          onChange={(e) => setTurno(e.target.value)}
                          className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-amber-400"
                        >
                          {selectedColegio.turnos.map((t) => (
                            <option key={t} value={t}>
                              {t}
                            </option>
                          ))}
                        </select>
                      </div>

                      <div>
                        <label className="text-[11px] font-semibold text-slate-600 block mb-1">
                          Grado / Sala / Año
                        </label>
                        <select
                          value={grado}
                          onChange={(e) => setGrado(e.target.value)}
                          className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-amber-400"
                        >
                          {selectedColegio.grados.map((g) => (
                            <option key={g} value={g}>
                              {g}
                            </option>
                          ))}
                        </select>
                      </div>

                      <div>
                        <label className="text-[11px] font-semibold text-slate-600 block mb-1">
                          División
                        </label>
                        <select
                          value={division}
                          onChange={(e) => setDivision(e.target.value)}
                          className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-amber-400"
                        >
                          {selectedColegio.divisiones.map((d) => (
                            <option key={d} value={d}>
                              División {d}
                            </option>
                          ))}
                        </select>
                      </div>
                    </div>
                  )}

                  {/* Auditoría 2026-09-22 (pedido de Pablo, viendo su propia galería con un
                      pedido previo ya hecho): mientras `pedidoExistente` esté seteado (llenado
                      automáticamente por el useEffect de arriba), se muestra este cartel en vez
                      del botón normal — avisa que ya hay un pedido para este alumno/a y deja elegir entre verlo o
                      confirmar que se quiere hacer otro. */}
                  {errorVerificacion ? (
                    renderAvisoVerificacion()
                  ) : pedidoExistente?.reservaPendiente ? (
                    <div className="p-4 sm:p-5 bg-emerald-50 border-2 border-emerald-300 rounded-xl text-left space-y-3 animate-in fade-in duration-150">
                      <div className="flex items-start gap-2.5">
                        <CheckCircle2 className="w-5 h-5 text-emerald-700 shrink-0 mt-0.5" />
                        <div>
                          <p className="text-sm font-extrabold text-emerald-950">
                            {nombreAlumno} ya tiene su {pedidoExistente.kit} pagado
                          </p>
                          <p className="text-[11px] text-emerald-800 mt-0.5">
                            Pedido <strong>{pedidoExistente.id}</strong>. Entrá a la galería, elegí las 3 fotos y tocá "Confirmar mis fotos" — no tenés que volver a pagar.
                          </p>
                        </div>
                      </div>
                      <button
                        type="button"
                        onClick={() => setStep(2)}
                        className="w-full px-4 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-xl shadow-xs cursor-pointer transition-colors flex items-center justify-center gap-1.5"
                      >
                        <span>Elegir mis fotos</span>
                        <ArrowRight className="w-4 h-4" />
                      </button>
                    </div>
                  ) : pedidoExistente ? (
                    <TarjetaPedidoExistente
                      pedido={pedidoExistente}
                      nombreAlumno={nombreAlumno}
                      codigoSeccion={codigoSeccionValidado}
                      onReingresar={reingresarPorCodigoVencido}
                      onVerPedido={() => {
                        setModalMode('seguimiento');
                        setTrackingQuery(pedidoExistente.id);
                        handleConsultarSeguimiento(undefined, pedidoExistente.id);
                        setPedidoExistente(null);
                      }}
                      onOtroPedido={() => {
                        setQuiereOtroPedido(true); // 05/10 (bug 4): habilita comprar otro kit para este hijo.
                        setStep(2);
                      }}
                      onPagarAhora={abrirPedidoExistenteParaPagar} datosCompra={{ familia: familiaActiva?.id, acceso: familiaActiva?.accesoGaleria, tutorNombre: tutorNombre || familiaActiva?.padreNombre || '', tutorEmail: tutorEmail || familiaActiva?.email || '', tutorTelefono: tutorWhatsapp || familiaActiva?.telefonoWhatsApp || '', colegioNombre: selectedColegio?.nombre || '' }}
                    />
                  ) : (
                    <div className="pt-2 flex justify-end">
                      <button
                        id="btn-continuar-galeria"
                        onClick={() => setStep(2)}
                        disabled={verificandoPedidoExistente}
                        className="px-6 py-2.5 bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-xs rounded-xl shadow-md shadow-amber-400/20 flex items-center gap-2 cursor-pointer transition-all active:scale-98 disabled:opacity-60 disabled:cursor-not-allowed"
                      >
                        <span>{verificandoPedidoExistente ? 'Verificando...' : 'Abrir Galería de Fotos'}</span>
                        <ArrowRight className="w-4 h-4" />
                      </button>
                    </div>
                  )}
                </div>
              )}
            </div>
          )}

          {/* STEP 2: Interactive Photo Gallery
              Auditoría 2026-09-22 (bug reportado por Pablo con captura: la barra sticky de este
              paso se veía solapada, a mitad de camino, debajo de "Consultar Estado de Mi Pedido").
              Causa: a esta condición le faltaba exigir también `modalMode === 'pedido'` (a
              diferencia del Paso 1, que sí lo exige). `step` y `modalMode` son dos estados
              independientes — tocar la pestaña "Consultar Mi Pedido" nunca resetea `step`, así
              que una familia que hiciera esa consulta estando parada en el Paso 2 (la galería)
              terminaba viendo los dos pasos renderizados a la vez, uno encima del otro. */}
          {modalMode === 'pedido' && step === 2 && (
            <div className="space-y-4 sm:space-y-6 animate-in fade-in duration-200">
              {/* Una sola fila: alumno + curso, selector de hermanos/as y "Cambiar datos". */}
              <div className="sticky -top-4 sm:-top-6 z-20 -mx-4 sm:-mx-6 -mt-4 sm:-mt-6 px-4 sm:px-6 pt-0 pb-3 bg-slate-50 shadow-[0_8px_12px_-8px_rgba(15,23,42,0.12)]">
                <div className="bg-white p-2.5 rounded-2xl border border-slate-200 shadow-xs flex flex-wrap items-center gap-x-3 gap-y-2">
                  <div className="flex items-center gap-2 min-w-0">
                    <span className="text-xs font-bold text-slate-900 font-['Outfit'] truncate">
                      {nombreAlumno}
                    </span>
                    <span className="text-[10px] bg-amber-100 text-amber-900 font-bold px-2 py-0.5 rounded-full shrink-0 whitespace-nowrap">
                      {grado} "{division}" · {turno}
                    </span>
                  </div>

                  <span className="text-[11px] text-slate-400 truncate hidden md:inline max-w-[200px]">
                    {selectedColegio?.nombre}
                  </span>

                  {/* Selector de hijo/a (Código Familiar): solo se muestra si hay más de uno para
                      elegir — familias de un solo hijo no ven ningún cambio acá. Auditoría
                      2026-09-16: esto es lo que hace real la promesa de "1 solo Código Familiar...
                      alterná entre tus hijos con un solo toque" que ya está en la web (Hero,
                      /proceso, FAQ). */}
                  {hijosFamilia.length > 1 && (
                    <div className="flex flex-wrap items-center gap-1.5" role="group" aria-label="Tus hijos/as en este colegio">
                      {hijosFamilia.map((h) => {
                        // Auditoría 2026-09-16 (pedido de Pablo: "un solo pedido, un solo pago"):
                        // un hijo cuenta como "listo" si ya eligió sus 3 fotos del pack, sea porque
                        // está siendo el activo ahora mismo o porque ya lo armó antes y quedó
                        // guardado en el carrito al cambiar de hermano.
                        const esActivo = hijoSeleccionadoId === h.id;
                        const listoActivo = esActivo && packCompleto;
                        const listoGuardado = !esActivo && Boolean(carritoHijos[h.id]?.completo);
                        const listo = listoActivo || listoGuardado;
                        // Auditoría 28/9: en qué etapa está cada hijo, para que la familia no tenga
                        // que entrar a cada uno para saber qué le falta.
                        const est = estadoHermanos[h.id];
                        const etapa = hijosSinFotos.excluido(h.id) ? 'Sin fotos (no las quiere)' : reservasPorHijo[h.id]
                          ? est && !est.fotosDisponibles
                            ? 'Kit pago · esperando fotos'
                            : 'Kit pago · elegí las fotos'
                          : est?.tienePedidoPagado
                            ? 'Comprado'
                            : !esActivo && hermanoPendienteSinDecidir(h.id)
                              ? 'Pedido esperando el pago · ¿lo incluís?'
                              : !esActivo && hermanoPendienteExcluido(h.id)
                                ? 'Pedido esperando el pago (no se incluye)'
                                : est && !est.fotosDisponibles
                              ? 'Sin fotos todavía'
                              : listo
                                ? '3 fotos elegidas'
                                : 'Elegir fotos';
                        return (
                          <button
                            key={h.id}
                            type="button"
                            onClick={() => seleccionarHijo(h.id)} aria-pressed={esActivo} title={esActivo ? 'Estás viendo las fotos de este hijo/a' : 'Tocá para ver sus fotos'}
                            className={`px-2.5 py-1.5 rounded-lg text-[11px] font-bold transition-colors cursor-pointer flex items-center gap-1 whitespace-nowrap ${
                              esActivo // 25/10 (Pablo: «no se distingue en cuál estoy parado»): el activo, oscuro y con borde ámbar
                                ? 'bg-slate-900 text-white shadow-sm ring-2 ring-amber-400'
                                : 'bg-white text-slate-600 border border-slate-300 hover:bg-slate-50'
                            }`}
                          >
                            {listo && <CheckCircle2 className={`w-3 h-3 ${esActivo ? 'text-amber-300' : 'text-emerald-600'}`} />}
                            <span className="flex flex-col items-start leading-tight">
                              <span>{h.nombreCompleto}</span>
                              <span className={`text-[9px] font-semibold ${esActivo ? 'text-amber-300' : 'text-slate-500'}`}>{esActivo ? `Viendo · ${etapa}` : etapa}</span>
                            </span>
                          </button>
                        );
                      })}
                    </div>
                  )}

                  <div className="flex items-center gap-2 ml-auto shrink-0">
                    <span className="hidden lg:inline-flex items-center gap-1.5 px-2 py-1 rounded-lg bg-amber-500/10 text-amber-900 border border-amber-300/80 text-[10px] font-bold whitespace-nowrap">
                      <Lock className="w-3 h-3 text-amber-700" />
                      {fotosDisponibles.length > 0 ? 'Protegidas' : 'Esperando fotos'}
                    </span>
                    <button
                      onClick={() => setStep(1)}
                      className="text-[11px] text-slate-500 hover:text-slate-800 font-medium cursor-pointer whitespace-nowrap"
                    >
                      Cambiar datos
                    </button>
                  </div>
                </div>
              </div>

              {renderAvisoVerificacion()}
              {renderAvisoHijos()}
              {faltaReingresoGaleria && fotosDisponibles.length > 0 && (
                <div className="rounded-xl border border-amber-300 bg-amber-50 px-4 py-3 text-xs text-amber-900 flex flex-wrap items-center justify-between gap-2">
                  <span>Para ver la foto individual de tu hijo/a, volvé a ingresar con tu nombre y DNI (lo pedimos una sola vez).</span>
                  <button type="button" onClick={reingresarPorCodigoVencido} className="rounded-lg bg-amber-500 px-3 py-1.5 font-bold text-slate-950 hover:bg-amber-400">
                    Ingresar de nuevo
                  </button>
                </div>
              )}
              {estadoGaleria === 'cargando' && fotosDisponibles.length === 0 ? (
                <div className="rounded-2xl border border-slate-200 bg-white px-6 py-12 text-center shadow-xs" aria-busy="true">
                  <Loader2 className="mx-auto h-8 w-8 animate-spin text-amber-500" />
                  <p className="mt-3 text-sm font-semibold text-slate-700">Cargando las fotos de {nombreAlumno || 'tu hijo/a'}…</p>
                </div>
              ) : estadoGaleria === 'error' && fotosDisponibles.length === 0 ? (
                <div role="alert" className="rounded-2xl border border-rose-200 bg-rose-50 px-6 py-10 text-center shadow-xs">
                  <AlertCircle className="mx-auto h-8 w-8 text-rose-600" />
                  <h3 className="mt-3 font-['Outfit'] text-lg font-extrabold text-slate-900">No pudimos cargar las fotos</h3>
                  <p className="mx-auto mt-1 max-w-md text-sm text-slate-600">{errorGaleria || 'Revisá tu conexión e intentá de nuevo.'}</p>
                  <button
                    type="button"
                    onClick={() => setReintentoGaleria((n) => n + 1)}
                    className="mt-5 inline-flex items-center gap-2 rounded-xl bg-slate-900 px-4 py-2.5 text-xs font-bold text-amber-300 hover:bg-slate-800 cursor-pointer"
                  >
                    <RefreshCw className="h-4 w-4" /> Reintentar
                  </button>
                </div>
              ) : estadoGaleria === 'codigo_invalido' ? (
                <div role="alert" className="rounded-2xl border border-amber-300 bg-amber-50 px-6 py-10 text-center shadow-xs">
                  <Key className="mx-auto h-8 w-8 text-amber-700" />
                  <h3 className="mt-3 font-['Outfit'] text-lg font-extrabold text-slate-900">Tu código de acceso venció o cambió</h3>
                  <p className="mx-auto mt-1 max-w-md text-sm text-slate-600">
                    {errorGaleria || 'El código guardado ya no es válido.'} Volvé a ingresar con el código que te llegó por email y tus datos.
                  </p>
                  <button
                    type="button"
                    onClick={reingresarPorCodigoVencido}
                    className="mt-5 inline-flex items-center gap-2 rounded-xl bg-amber-500 px-4 py-2.5 text-xs font-bold text-slate-950 hover:bg-amber-400 cursor-pointer"
                  >
                    <Key className="h-4 w-4" /> Ingresar de nuevo
                  </button>
                </div>
              ) : !codigoSeccionValidado ? (
                // Auditoría 11/10 (POR-8): con el código del colegio (público) no hay llave del curso: no es "sin fotos".
                <div role="alert" className="rounded-2xl border border-amber-300 bg-amber-50 px-6 py-10 text-center shadow-xs">
                  <Key className="mx-auto h-8 w-8 text-amber-700" />
                  <h3 className="mt-3 font-['Outfit'] text-lg font-extrabold text-slate-900">Para ver las fotos necesitás el código de acceso de tu curso</h3>
                  <p className="mx-auto mt-1 max-w-md text-sm text-slate-600">Te llegó por email al inscribirte. Si no lo tenés, te lo mandamos de nuevo.</p>
                  <button type="button" onClick={() => { setMostrarFormSolicitudCodigo(true); setStep(1); }} className="mt-5 inline-flex items-center gap-2 rounded-xl bg-amber-500 px-4 py-2.5 text-xs font-bold text-slate-950 hover:bg-amber-400 cursor-pointer">
                    <Mail className="h-4 w-4" /> Pedir mi código
                  </button>
                </div>
              ) : fotosDisponibles.length === 0 ? (
                <div className="rounded-2xl border border-amber-200 bg-amber-50/70 px-6 py-10 text-center shadow-xs">
                  <div className="mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-2xl bg-white text-amber-700 shadow-xs ring-1 ring-amber-200">
                    <Mail className="h-6 w-6" />
                  </div>
                  <h3 className="font-['Outfit'] text-xl font-extrabold text-slate-900">
                    Tus fotos todavía no fueron ingresadas
                  </h3>
                  <p className="mx-auto mt-2 max-w-xl text-sm leading-6 text-slate-600">
                    Apenas estén disponibles online, te enviaremos un email a{' '}
                    <strong className="text-slate-900">{tutorEmail || familiaActiva?.email || 'la dirección que registraste'}</strong>.
                    No necesitás volver a registrarte ni revisar la página todos los días.
                  </p>
                  <button
                    type="button"
                    onClick={() => setStep(1)}
                    className="mt-6 inline-flex items-center gap-2 rounded-xl border border-slate-300 bg-white px-4 py-2.5 text-xs font-bold text-slate-700 transition-colors hover:bg-slate-50"
                  >
                    <ArrowLeft className="h-4 w-4" />
                    Volver
                  </button>
                  <ReservaKitAnticipada
                    hijos={
                      hijosFamilia.length > 0
                        ? hijosFamilia.map((h) => ({ id: h.id, nombreCompleto: h.nombreCompleto, codigoSeccion: h.codigoSeccion, grado: h.grado }))
                        : [{ id: 'principal', nombreCompleto: nombreAlumno, codigoSeccion: codigoSeccionValidado || '', grado }]
                    }
                    tutorNombre={tutorNombre || familiaActiva?.padreNombre || ''}
                    tutorEmail={tutorEmail || familiaActiva?.email || ''}
                    tutorTelefono={tutorWhatsapp || familiaActiva?.telefonoWhatsApp || ''}
                    onVerFotosHijo={hijosFamilia.length > 1 ? (id) => seleccionarHijo(id) : undefined}
                    onSumarALaCompra={(reservas, hijoConFotosId, hijosDecididos) => {
                      // Conserva las copias extra que ya se habían sumado si el kit sigue siendo el Impreso.
                      setReservasParaSumar((previas) =>
                        reservas.map((r) => {
                          const previa = previas.find((p) => p.hijoId === r.hijoId);
                          if (r.carpetasExtras !== undefined || !previa?.carpetasExtras || r.kitId !== 'kit-clasico' || previa.kitId !== 'kit-clasico') return r;
                          return { ...r, carpetasExtras: previa.carpetasExtras, precio: r.precio + previa.carpetasExtras * PRECIO_CARPETA_EXTRA };
                        })
                      );
                      setKitHermanoDecidido((prev) => ({ ...prev, ...Object.fromEntries(hijosDecididos.map((id) => [id, true])) }));
                      setAvisoKitHermano('');
                      if (carritoHijosRef.current[hijoConFotosId]?.completo) setIrAlKitDe(hijoConFotosId);
                      seleccionarHijo(hijoConFotosId);
                    }}
                    reservasSumadas={reservasParaSumar}
                    hijosConFotosElegidas={Object.values(carritoHijos as Record<string, SeleccionCarritoHijo>).filter((c) => c.completo).map((c) => c.hijoId)}
                    aviso={avisoKitHermano || undefined}
                    familiaId={familiaActiva?.id}
                    accesoGaleria={familiaActiva?.accesoGaleria}
                  />
                </div>
              ) : (
                <>
              {(reservaActiva?.pagada || resultadoReserva) && (
                <div className={`mb-3 rounded-2xl border p-4 text-left ${resultadoReserva?.ok ? 'border-emerald-300 bg-emerald-50' : 'border-violet-300 bg-violet-50'}`}>
                  {reservaActiva?.pagada ? (
                    <>
                      <p className="text-sm font-extrabold text-slate-900">
                        ✅ Ya pagaste el {reservaActiva.kitNombre} de {nombreAlumno} ({reservaActiva.pedidoFriendlyId})
                      </p>
                      {reservaActiva.id ? (
                        <p className="mt-0.5 text-xs text-slate-700">
                          Elegí las {totalFotosPack} fotos (1 grupal, 1 individual{terceraFotoRequerida ? ` y ${textosTercera.una.replace(/^una /, '1 ')}` : ''}) y tocá <strong>Confirmar mis fotos</strong>. No tenés que volver a pagar.
                        </p>
                      ) : (
                        <p className="mt-0.5 text-xs text-amber-900">
                          Para elegir sus fotos volvé a ingresar con tu nombre y DNI (lo pedimos una sola vez).{' '}
                          <button type="button" onClick={reingresarPorCodigoVencido} className="font-bold underline">Ingresar de nuevo</button>
                        </p>
                      )}
                    </>
                  ) : null}
                  {resultadoReserva && (
                    <p className={`mt-1 text-xs font-semibold ${resultadoReserva.ok ? 'text-emerald-800' : 'text-red-700'}`}>{resultadoReserva.texto}</p>
                  )}
                </div>
              )}

              {/* 3 Fotos Incluidas Top Panel — padding y margen inferior reducidos el 22/9 (antes
                  p-4 sm:p-5 / mb-3, y de nuevo achicado ese mismo día — antes p-3 sm:p-4 / mb-2 —
                  como parte del mismo pedido de Pablo de necesitar menos scroll) para dejar más
                  alto libre para las fotos y el botón "Elegir" sin scrollear. */}
              {reservasParaSumar.length > 0 && !reservaActiva?.pagada && (
                <div className="mb-2 flex flex-col sm:flex-row sm:items-center justify-between gap-2 rounded-xl border border-emerald-300 bg-emerald-50 px-3 py-2 text-xs text-emerald-900">
                  <span>
                    <CheckCircle2 className="inline w-3.5 h-3.5 mr-1 text-emerald-600 align-[-2px]" />
                    Se suma el {reservasParaSumar.map((r) => `${r.kitNombre} de ${r.nombreCompleto}`).join(' y ')} (${totalReservasParaSumar.toLocaleString('es-AR')}). Elegí las fotos de {nombreAlumno} y pagás todo junto.
                  </span>
                  <button type="button" onClick={() => setReservasParaSumar([])} className="shrink-0 font-bold underline cursor-pointer">
                    Quitar
                  </button>
                </div>
              )}
                            <div ref={panelPackRef} className="scroll-mt-4 bg-slate-900 text-white rounded-2xl p-2.5 sm:p-3 shadow-md border border-slate-800">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-1.5">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="px-2.5 py-0.5 rounded-full bg-amber-400 text-slate-950 text-[10px] font-extrabold uppercase">
                        Pack Oficial Escolar
                      </span>
                      <h4 className="text-sm font-bold text-white">
                        Tus {totalFotosPack} Fotos Incluidas en el Paquete
                      </h4>
                    </div>
                    <p className="text-xs text-slate-300 mt-0.5 text-left">
                      Elegí las {totalFotosPack} tomas que integran tu recuerdo escolar: 1 grupal, 1 individual{terceraFotoRequerida ? ` y ${textosTercera.una.replace(/^una /, '1 ')}` : ''}.
                    </p>
                  </div>
                  <span className={`px-3 py-1 rounded-full border text-xs font-bold shrink-0 self-start sm:self-auto flex items-center gap-1.5 ${
                    packCompleto
                      ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30'
                      : 'bg-amber-500/20 text-amber-300 border-amber-500/30'
                  }`}>
                    <CheckCheck className={`w-3.5 h-3.5 ${packCompleto ? 'text-emerald-400' : 'text-amber-400'}`} />
                    <span>{cantidadFotosPackSeleccionadas} de {totalFotosPack} fotos seleccionadas</span>
                  </span>
                </div>

                {/* 3 Slots + Otras Fotos (mismo estilo, para que se vea igual de accesible que las 3 del pack) */}
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2 pt-0.5 text-left">
                  {/* Slot 1: Grupal — tarjetas achicadas ~50% el 22/9 (pedido de Pablo) y texto
                      recortado a lo esencial para que entre sin desbordar en el tamaño nuevo. */}
                  <div
                    onClick={() => irAPasoPack('grupal')}
                    role="button" tabIndex={0} onKeyDown={activarConTeclado}
                    className={`rounded-lg p-1.5 flex items-center gap-2.5 transition-all cursor-pointer group border ${
                      fotoGrupalSeleccionadaValida
                        ? 'bg-emerald-900/40 hover:bg-emerald-900/60 border-emerald-400 ring-1 ring-emerald-400/40'
                        : categoriaActiva === 'grupal'
                          ? 'bg-slate-800/80 hover:bg-slate-800 border-amber-400 ring-1 ring-amber-400/40'
                          : 'bg-slate-800/80 hover:bg-slate-800 border-slate-700 hover:border-slate-600'
                    }`}
                  >
                    <div className="w-14 h-14 sm:w-16 sm:h-16 rounded-md overflow-hidden bg-slate-950 shrink-0 relative border border-slate-700">
                      {fotoGrupalSeleccionada ? <><img src={fotoGrupalSeleccionada.thumbnail} alt="Foto grupal elegida" className="w-full h-full object-cover" /><div className="absolute top-0.5 right-0.5 rounded-full bg-emerald-500 p-0.5 shadow"><Check className="w-3 h-3 text-white stroke-[3]" /></div></> : <Images className="w-5 h-5 text-slate-500 absolute inset-0 m-auto" />}
                    </div>
                    <div className="min-w-0 flex-1">
                      <span className={`text-[10px] font-bold block uppercase tracking-wider leading-tight truncate ${fotoGrupalSeleccionadaValida ? 'text-emerald-300' : 'text-amber-400'}`}>
                        1/3 Grupal
                      </span>
                      <p className="text-xs font-bold text-white truncate leading-tight group-hover:text-amber-300">
                        {fotoGrupalSeleccionada?.titulo?.split(' - ')[0] || (sinFoto.includes('grupal') ? 'No tiene esta foto' : 'Sin elegir')}
                      </p>
                    </div>
                  </div>

                  {/* Slot 2: Retrato Individual */}
                  <div
                    onClick={() => irAPasoPack('individual')}
                    role="button" tabIndex={0} onKeyDown={activarConTeclado}
                    className={`rounded-lg p-1.5 flex items-center gap-2.5 transition-all cursor-pointer group border ${
                      fotoIndividualSeleccionadaValida
                        ? 'bg-emerald-900/40 hover:bg-emerald-900/60 border-emerald-400 ring-1 ring-emerald-400/40'
                        : categoriaActiva === 'individual'
                          ? 'bg-slate-800/80 hover:bg-slate-800 border-amber-400 ring-1 ring-amber-400/40'
                          : 'bg-slate-800/80 hover:bg-slate-800 border-slate-700 hover:border-slate-600'
                    }`}
                  >
                    <div className="w-14 h-14 sm:w-16 sm:h-16 rounded-md overflow-hidden bg-slate-950 shrink-0 relative border border-slate-700">
                      {fotoIndividualSeleccionada ? <><img src={fotoIndividualSeleccionada.thumbnail} alt="Retrato individual elegido" className="w-full h-full object-cover" /><div className="absolute top-0.5 right-0.5 rounded-full bg-emerald-500 p-0.5 shadow"><Check className="w-3 h-3 text-white stroke-[3]" /></div></> : <Images className="w-5 h-5 text-slate-500 absolute inset-0 m-auto" />}
                    </div>
                    <div className="min-w-0 flex-1">
                      <span className={`text-[10px] font-bold block uppercase tracking-wider leading-tight truncate ${fotoIndividualSeleccionadaValida ? 'text-emerald-300' : 'text-amber-400'}`}>
                        2/3 Retrato
                      </span>
                      <p className="text-xs font-bold text-white truncate leading-tight group-hover:text-amber-300">
                        {fotoIndividualSeleccionada?.titulo?.split(' - ')[0] || (sinFoto.includes('individual') ? 'No tiene esta foto' : 'Sin elegir')}
                      </p>
                    </div>
                  </div>

                  {/* Slot 3: Con Docente o, en secundaria, con familia/amigos (06/10) */}
                  <div
                    onClick={() => irAPasoPack('docente')}
                    role="button" tabIndex={0} onKeyDown={activarConTeclado}
                    className={`rounded-lg p-1.5 flex items-center gap-2.5 transition-all cursor-pointer group border ${
                      fotoDocenteSeleccionadaValida
                        ? 'bg-emerald-900/40 hover:bg-emerald-900/60 border-emerald-400 ring-1 ring-emerald-400/40'
                        : categoriaActiva === 'docente'
                          ? 'bg-slate-800/80 hover:bg-slate-800 border-amber-400 ring-1 ring-amber-400/40'
                          : 'bg-slate-800/80 hover:bg-slate-800 border-slate-700 hover:border-slate-600'
                    }`}
                  >
                    <div className="w-14 h-14 sm:w-16 sm:h-16 rounded-md overflow-hidden bg-slate-950 shrink-0 relative border border-slate-700">
                      {fotoDocenteSeleccionada ? <><img src={fotoDocenteSeleccionada.thumbnail} alt={`${etiquetaTerceraFoto(fotoDocenteSeleccionada.categoria)} elegida`} className="w-full h-full object-cover" /><div className="absolute top-0.5 right-0.5 rounded-full bg-emerald-500 p-0.5 shadow"><Check className="w-3 h-3 text-white stroke-[3]" /></div></> : <Images className="w-5 h-5 text-slate-500 absolute inset-0 m-auto" />}
                    </div>
                    <div className="min-w-0 flex-1">
                      <span className={`text-[10px] font-bold block uppercase tracking-wider leading-tight truncate ${fotoDocenteSeleccionadaValida ? 'text-emerald-300' : 'text-amber-400'}`}>
                        3/3 {textosTercera.corto}
                      </span>
                      <p className="text-xs font-bold text-white truncate leading-tight group-hover:text-amber-300">
                        {fotoDocenteSeleccionada?.titulo || (sinFoto.includes('docente') ? 'No tiene esta foto' : 'Sin elegir')}
                      </p>
                    </div>
                  </div>

                  {/* Slot 4: Otras Fotos — mismo tamaño y lugar que los 3 del pack (antes era un
                      botón aparte, más chico y menos visible), pero con estilo distinto (punteado,
                      sin check) para que se note que NO forma parte de las 3 fotos incluidas. */}
                  {hayFotosDeEventos && <div
                    onClick={() => irAPasoPack('patio')}
                    role="button" tabIndex={0} onKeyDown={activarConTeclado}
                    className={`bg-slate-800/40 hover:bg-slate-800/70 rounded-lg p-1.5 flex items-center gap-2.5 transition-all cursor-pointer group border border-dashed ${
                      categoriaActiva === 'patio' ? 'border-amber-400 ring-1 ring-amber-400/40 bg-slate-800/70' : 'border-slate-600 hover:border-slate-500'
                    }`}
                  >
                    <div className="w-14 h-14 sm:w-16 sm:h-16 rounded-md shrink-0 bg-slate-950/60 border border-slate-700 flex items-center justify-center">
                      <Images className="w-3.5 h-3.5 text-slate-400" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <span className="text-[10px] font-bold text-slate-400 block uppercase tracking-wider leading-tight truncate">
                        Opcional
                      </span>
                      <p className="text-xs font-bold text-white truncate leading-tight group-hover:text-amber-300">
                        Otras Fotos {fotosSueltasSeleccionadas.length > 0 ? `(${fotosSueltasSeleccionadas.length})` : ''}
                      </p>
                    </div>
                  </div>}
                </div>
              </div>

              {/* Sólo el título de la categoría que se muestra (el acceso a las 4 categorías ya está arriba, con el mismo estilo). */}
              <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-200 pb-2">
                <h5 className="text-xs font-bold text-slate-500 uppercase tracking-wider">
                  {categoriaActiva === 'patio'
                    ? 'Otras Fotos (no incluidas en el paquete)'
                    : 'Elegí tu toma tocando una foto'}
                </h5>
                {avisoAvancePack && categoriaActiva !== 'patio' && (
                  <span role="status" className="text-xs font-bold px-3 py-1 bg-emerald-50 text-emerald-800 border border-emerald-300 rounded-full flex items-center gap-1.5 animate-in fade-in duration-200">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                    {avisoAvancePack}
                  </span>
                )}

                {extraCarpetas > 0 && (
                  <span className="text-xs font-bold px-3 py-1 bg-amber-100 text-amber-900 border border-amber-300 rounded-full flex items-center gap-1.5 shadow-2xs">
                    <Copy className="w-3.5 h-3.5 text-amber-700" />
                    <span>{extraCarpetas} carpeta(s) extra(s) agregada(s)</span>
                  </span>
                )}
              </div>

              {hijosFamilia.length > 1 && <AvisoHijoSinFotos nombre={nombreAlumno} excluido={hijosSinFotos.excluido(hijoSeleccionadoId)} puedeExcluir={hijosFamilia.some((h) => h.id !== hijoSeleccionadoId && !hijosSinFotos.excluido(h.id))} onCambiar={(noQuiere) => { hijosSinFotos.marcar(hijoSeleccionadoId, noQuiere); const otro = noQuiere && hijosFamilia.find((h) => h.id !== hijoSeleccionadoId && !hijosSinFotos.excluido(h.id)); if (otro) seleccionarHijo(otro.id); }} />}
              {categoriaActiva === 'individual' && <BuscadorRostro key={hijoSeleccionadoId} acceso={codigoSeccionValidado && familiaActiva?.id && familiaActiva?.accesoGaleria && nombreAlumno ? { codigo: codigoSeccionValidado, familia: familiaActiva.id, acceso: familiaActiva.accesoGaleria, alumnoNombre: nombreAlumno } : null} onEncontradas={() => setReintentoGaleria((n) => n + 1)} fotosGaleria={fotosDisponibles} onVerFoto={setModalFotoPreview} />}
              {categoriaActiva !== 'patio' && (categoriaActiva !== 'docente' || terceraFotoRequerida) && (
                <AvisoSinFotoPack
                  key={`${hijoSeleccionadoId}-${categoriaActiva}`}
                  faltantes={faltantes}
                  contacto={{ email: familiaActiva?.email || tutorEmail || '', whatsapp: familiaActiva?.telefonoWhatsApp || tutorWhatsapp || '' }}
                  lugar={categoriaActiva}
                  nombreFoto={categoriaActiva === 'docente' ? textosTercera.la : NOMBRE_LUGAR[categoriaActiva]}
                  marcado={enReemplazoActivo} sinFotosEnPestana={!enReemplazoActivo && fotosDeLaPestana.length === 0}
                  reemplazo={{ individual: fotoIndividualSeleccionada, grupal: fotoGrupalSeleccionada, docente: fotoDocenteSeleccionada }[categoriaActiva]?.titulo}
                  onCambiar={(marcar) => marcarSinFoto(categoriaActiva, marcar)} datosAviso={{ tutor: familiaActiva?.padreNombre || '', alumno: nombreAlumno, curso: `${grado} "${division}" · ${turno}`, colegio: selectedColegio?.nombre || '' }}
                />
              )}

              {/* Grilla: las columnas se ajustan a la cantidad de fotos de la pestaña (22/9, Pablo: sin huecos vacíos). */}
              <div className={`grid grid-cols-1 gap-4 ${(() => {
                const cantidad = fotosDeLaPestana.length;
                if (cantidad >= 4) return 'sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4';
                if (cantidad === 3) return 'sm:grid-cols-2 lg:grid-cols-3';
                if (cantidad === 2) return 'sm:grid-cols-2';
                return '';
              })()}`}>
                {fotosDeLaPestana.map((foto) => {
                  const isSelected =
                    foto.id === fotoSeleccionadaIndividual ||
                    foto.id === fotoSeleccionadaGrupal ||
                    foto.id === fotoSeleccionadaDocente ||
                    fotosSueltasSeleccionadas.includes(foto.id);

                  const lugarQueOcupa = lugarDeLaFoto(foto.id, { grupal: fotoSeleccionadaGrupal, individual: fotoSeleccionadaIndividual, docente: fotoSeleccionadaDocente });
                  const enOtroLugar = enReemplazoActivo && lugarQueOcupa !== undefined && lugarQueOcupa !== categoriaActiva; // 29/10 (Pablo: «es confuso»)
                  const handleSelectThisFoto = () => {
                    if (foto.categoria !== 'patio') {
                      elegirFotoDelPack(foto);
                      return;
                    }
                    if (foto.categoria === 'patio') {
                      setFotosSueltasSeleccionadas((actuales) =>
                        actuales.includes(foto.id)
                          ? actuales.filter((id) => id !== foto.id)
                          : actuales.length >= MAX_FOTOS_SUELTAS
                          ? actuales
                          : [...actuales, foto.id]
                      );
                    }
                    setErrorSeleccionFotos('');
                  };

                  return (
                    <div
                      key={foto.id}
                      className={`relative bg-white rounded-2xl overflow-hidden border transition-all duration-200 flex flex-col justify-between ${
                        isSelected
                          ? 'border-2 border-amber-500 shadow-lg shadow-amber-500/10 ring-2 ring-amber-400/30'
                          : 'border-slate-200 hover:border-slate-300 shadow-xs'
                      }`}
                    >
                      {/* Photo Container */}
                      <div 
                        className="relative aspect-4/3 overflow-hidden bg-slate-100 select-none"
                        onContextMenu={(e) => {
                          e.preventDefault();
                          e.stopPropagation();
                        }}
                      >
                        <img loading="lazy" decoding="async"
                          src={foto.thumbnail}
                          alt={foto.titulo}
                          draggable={false}
                          className="w-full h-full object-cover object-center pointer-events-none select-none"
                        />

                        {/* Sin marca de agua en la miniatura: solo se muestra al ampliar la foto */}

                        {/* Status badge */}
                        {isSelected && (
                          <div className="absolute top-2.5 left-2.5">
                            <span className="px-2.5 py-1 rounded-md bg-amber-400 text-slate-950 text-[11px] font-extrabold flex items-center gap-1 shadow-md">
                              <Check className="w-3.5 h-3.5 stroke-[3]" />
                              <span>{foto.categoria === 'patio' ? 'Adicional elegida' : enOtroLugar ? `Ya la elegiste como ${nombreDelLugar(lugarQueOcupa!).replace(/^la (foto )?/, '')}` : enReemplazoActivo ? 'Va en su lugar' : 'En el Pack Oficial'}</span>
                            </span>
                          </div>
                        )}

                        {/* Zoom button (z-30: debe quedar por encima de la marca de agua, que usa z-20 y captura los clics) */}
                        <button
                          type="button"
                          onClick={() => setModalFotoPreview(foto)}
                          className="absolute bottom-2.5 right-2.5 z-30 p-2.5 sm:p-1.5 rounded-lg bg-white/90 hover:bg-white text-slate-800 text-xs shadow-md transition-colors cursor-pointer"
                          title="Ampliar foto"
                        >
                          <Eye className="w-4 h-4" />
                        </button>
                      </div>

                      {/* Card Details & Action Area */}
                      <div className="p-3.5 flex items-center justify-between gap-3 text-left bg-white">
                        <div>
                          <h5 className="text-xs font-bold text-slate-900 truncate">{foto.titulo}</h5>
                          <span className="text-[10px] text-slate-500">
                            {foto.categoria === 'patio' ? 'Archivo Digital HD' : (enReemplazoActivo ? categoriaActiva : foto.categoria) === 'grupal' ? 'Formato 20x30 cm' : 'Formato 15x21 cm'}{foto.numero ? ` · N° ${foto.numero}` : ''}
                          </span>
                        </div>

                        {/* Primary Pack selection button */}
                        {foto.categoria !== 'patio' ? (
                          <button
                            type="button"
                            onClick={handleSelectThisFoto} disabled={enOtroLugar}
                            className={`shrink-0 py-2.5 sm:py-1.5 px-3 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer disabled:cursor-not-allowed ${enOtroLugar ? 'bg-slate-100 text-slate-500' : enReemplazoActivo && !isSelected ? 'bg-amber-400 hover:bg-amber-300 text-slate-950 shadow-xs' : isSelected ? 'bg-emerald-500 text-white shadow-xs' : 'bg-slate-100 hover:bg-slate-200 text-slate-700'}`}
                          >
                            {enOtroLugar || enReemplazoActivo ? <span>{enOtroLugar ? 'Ya elegida' : isSelected ? 'Quitar' : 'Usar en su lugar'}</span> : isSelected ? (
                              <>
                                <CheckCircle2 className="w-3.5 h-3.5 text-white" />
                                <span>Elegida</span>
                              </>
                            ) : (
                              <span>Elegir</span>
                            )}
                          </button>
                        ) : (
                          <button
                            type="button"
                            onClick={handleSelectThisFoto}
                            className={`shrink-0 py-2.5 sm:py-1.5 px-3 rounded-lg text-xs font-bold transition-all ${isSelected ? 'bg-emerald-600 text-white' : 'bg-slate-900 text-white hover:bg-slate-800'}`}
                          >
                            {isSelected ? 'Agregada · Quitar' : `Agregar · $${PRECIO_FOTO_EVENTO.toLocaleString('es-AR')}`}
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Pedido de Pablo (27/9): la copia extra de la carpeta se ofrece una sola vez, en el paso Kit. */}

              {/* Bottom Next Step Bar */}
              {renderAvisoHermanosPendientes()}
              {errorSeleccionFotos && (
                <div role="alert" className="rounded-xl border-2 border-rose-300 bg-rose-50 p-4 text-base font-bold leading-6 text-rose-900 flex items-start gap-3">
                  <AlertCircle className="h-6 w-6 shrink-0 text-rose-600" />
                  <span>{errorSeleccionFotos}</span>
                </div>
              )}
              <div className="sticky -bottom-4 sm:-bottom-6 z-20 -mx-4 sm:-mx-6 px-4 sm:px-6 pt-3 pb-4 sm:pb-6 bg-slate-50 border-t border-slate-200 shadow-[0_-8px_12px_-8px_rgba(15,23,42,0.15)] flex flex-col sm:flex-row items-center justify-between gap-3 sm:gap-4">{/* 25/10 (Pablo): fija al pie, para no tener que bajar hasta la última foto */}
                {faltaEnElPack && <p role="status" className="text-xs font-bold text-amber-900 text-left w-full sm:max-w-sm">{faltaEnElPack}</p>}
                <div className="hidden sm:block text-xs text-slate-600 text-left">
                  <span className="font-bold text-slate-900">Fotos del pack: </span>
                  Individual, Grupal{fotoDocenteSeleccionada ? ` y ${etiquetaTerceraFoto(fotoDocenteSeleccionada.categoria)}` : ''}.
                  {extraCarpetas > 0 && (
                    <span className="ml-1.5 text-amber-800 font-bold">
                      (+ {extraCarpetas} carpeta{extraCarpetas > 1 ? 's' : ''} extra{extraCarpetas > 1 ? 's' : ''} para abuelos)
                    </span>
                  )}
                </div>

                <div className="flex flex-col items-stretch gap-2 sm:items-end">
                {reservaActiva?.pagada && (
                  <div className="max-w-md rounded-xl border-2 border-amber-400 bg-amber-50 p-3 text-left text-[11px] leading-relaxed text-slate-800">
                    <p>{AVISO_CONFIRMAR_FOTOS.texto}</p>
                    <label htmlFor="chk-confirma-personalizacion" className="mt-2 flex cursor-pointer items-start gap-2 rounded-lg bg-white p-2 font-semibold text-slate-900">
                      <input
                        id="chk-confirma-personalizacion"
                        type="checkbox"
                        checked={confirmaPersonalizacion}
                        onChange={(e) => {
                          setConfirmaPersonalizacion(e.target.checked);
                          if (e.target.checked) setErrorConfirmacionReserva('');
                        }}
                        className="mt-0.5 h-4 w-4 shrink-0 cursor-pointer rounded accent-amber-500"
                      />
                      <span>
                        {AVISO_CONFIRMAR_FOTOS.casilla}{' '}
                        <button type="button" onClick={(e) => { e.preventDefault(); abrirLegal('terminos'); }} className="font-bold text-amber-800 underline">
                          Ver términos
                        </button>
                      </span>
                    </label>
                    {errorConfirmacionReserva && <p role="alert" className="mt-1.5 font-bold text-red-700">{errorConfirmacionReserva}</p>}
                  </div>
                )}
                <div ref={botonContinuarPackRef} className="flex gap-3">
                  <button
                    onClick={() => setStep(1)}
                    className="px-4 py-2.5 text-xs font-semibold text-slate-700 hover:bg-slate-100 rounded-xl transition-colors cursor-pointer"
                  >
                    Atrás
                  </button>
                  {reservaConfirmadaPorHijo[hijoSeleccionadoId] ? (
                  // 05/10 (bug 4): reserva ya confirmada → modo "terminado" (antes volvía a aparecer
                  // "Elegir Kit y Formato" y se podía pagar el mismo kit otra vez).
                  <button
                    id="btn-ver-pedido-reserva"
                    type="button"
                    onClick={() => {
                      const numero = reservaConfirmadaPorHijo[hijoSeleccionadoId];
                      setModalMode('seguimiento');
                      setTrackingQuery(numero);
                      handleConsultarSeguimiento(undefined, numero);
                    }}
                    className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-xl shadow-md flex items-center gap-2 cursor-pointer"
                  >
                    <Package className="w-4 h-4" />
                    <span>Fotos confirmadas · Ver mi pedido</span>
                  </button>
                  ) : reservaActiva?.pagada ? (
                  <button
                    id="btn-confirmar-reserva"
                    onClick={() => void confirmarFotosDeReserva()}
                    disabled={confirmandoReserva}
                    className="px-6 py-2.5 bg-emerald-500 hover:bg-emerald-400 disabled:opacity-60 text-white font-bold text-xs rounded-xl shadow-md flex items-center gap-2 cursor-pointer"
                  >
                    {confirmandoReserva ? <Loader2 className="w-4 h-4 animate-spin" /> : <CheckCircle2 className="w-4 h-4" />}
                    <span>{packCompleto ? 'Confirmar mis fotos' : `Elegí las ${totalFotosPack} fotos (${cantidadFotosPackSeleccionadas}/${totalFotosPack})`}</span>
                  </button>
                  ) : (
                  <button
                    id="btn-continuar-kit"
                    onClick={handleContinuarAlKit}
                    className="px-6 py-2.5 bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-xs rounded-xl shadow-md shadow-amber-400/20 flex items-center gap-2 cursor-pointer transition-all active:scale-98"
                  >
                    <span>{packCompleto ? 'Elegir Kit y Formato' : `Elegí las ${totalFotosPack} fotos (${cantidadFotosPackSeleccionadas}/${totalFotosPack})`}</span>
                    {totalCopiasExtrasCantidad > 0 && (
                      <span className="px-2 py-0.5 bg-slate-950 text-amber-300 rounded text-[11px] font-black">
                        ${total.toLocaleString('es-AR')}
                      </span>
                    )}
                    <ArrowRight className="w-4 h-4" />
                  </button>
                  )}
                </div>
                </div>
              </div>
                </>
              )}
            </div>
          )}

          {/* STEP 3: Kit Selection & Add-ons */}
          {modalMode === 'pedido' && step === 3 && (
            <div className="space-y-6 animate-in fade-in duration-200">
              {renderAvisoVerificacion()}{!plazoKitImpresoAbierto() && <AvisoPlazoKitImpreso esSecundaria={false} />}
              <div className="text-center max-w-xl mx-auto">
                <h3 className="text-2xl font-extrabold text-slate-900 font-['Outfit']">
                  Elegí tu Kit Fotográfico
                </h3>
                <p className="text-xs text-slate-500 mt-1">
                  {'Los dos incluyen las mismas 3 fotos en alta resolución. El impreso suma la carpeta con las fotos en papel.'}
                  {/* 05/10 (bug 5): la familia tiene que saber que el kit vale para todos los hermanos. */}
                  {otrosHijosEnCarrito.length > 0 && (
                    <>
                      {' '}
                      <strong className="text-slate-700">El kit que elijas acá se aplica a todos tus hijos/as de esta compra</strong> ({[nombreAlumno, ...otrosHijosEnCarrito.map((c) => c.nombreCompleto)].join(', ')}).
                    </>
                  )}
                </p>
              </div>

              {/* Las fotos de eventos son adicionales y nunca reemplazan el kit de tres fotos. */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-5 max-w-3xl mx-auto">
                {kitsParaGrados(KITS_DISPONIBLES, gradosDeLaCompra).filter((kit) => kit.id !== 'kit-evento-suelto' && kitOfrecido(kit.id)).map((kit) => {
                  const isSelected = selectedKit.id === kit.id;
                  return (
                    <div
                      key={kit.id}
                      role="button" tabIndex={0} aria-pressed={isSelected} onKeyDown={activarConTeclado}
                      onClick={() => {
                        setSelectedKit(kit);
                        // 05/10 (bug 5, decisión tomada): el kit del Paso 3 es UNO para todos los
                        // hijos del carrito (las reservas por adelantado tienen su propio kit; las
                        // carpetas extra siguen siendo por hijo). Antes sólo cambiaba el del activo
                        // y el hermano guardado seguía en Kit Impreso sin que la familia lo viera.
                        setCarritoHijos((prev) => {
                          const entradas = Object.entries(prev);
                          if (entradas.length === 0) return prev;
                          return Object.fromEntries(
                            entradas.map(([id, c]) => {
                              const carpetas = kit.id === 'kit-clasico' ? c.extraCarpetas : 0;
                              return [id, { ...c, kitId: kit.id, kitNombre: kit.nombre, extraCarpetas: carpetas, total: kit.precio + carpetas * PRECIO_CARPETA_EXTRA + c.fotosSueltasSeleccionadas.length * PRECIO_FOTO_EVENTO }];
                            })
                          );
                        });
                        // Auditoría 2026-09-09 (hallazgo reportado por Pablo): la "Carpeta Escolar
                        // Extra Completa" (+$15.000) es una DUPLICADA de la carpeta que ya viene
                        // incluida en "Kit Impreso + Digital" ($30.000) — no tiene sentido en un kit
                        // que no trae carpeta de base ("Solo Digital HD", $15.000, o "Fotos Sueltas
                        // de Eventos", $5.000), porque ahí terminaba siendo una forma más barata de
                        // armar la misma carpeta completa (ej: $5.000 + $15.000 = $20.000 en vez de
                        // los $30.000 del kit que realmente la incluye). Si se cambia a un kit que no
                        // la incluye, se resetea la cantidad para no arrastrar ese precio de menos.
                        if (kit.id !== 'kit-clasico') setExtraCarpetas(0);
                      }}
                      className={`relative bg-white rounded-2xl p-5 border text-left cursor-pointer transition-all flex flex-col justify-between ${
                        isSelected
                          ? 'border-2 border-amber-500 shadow-xl shadow-amber-500/10 ring-2 ring-amber-400/30'
                          : 'border-slate-200 hover:border-slate-300'
                      }`}
                    >
                      {kit.popular && (
                        <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-amber-400 text-slate-950 text-[10px] font-extrabold px-3 py-0.5 rounded-full uppercase tracking-wider">
                          Más popular
                        </div>
                      )}

                      <div>
                        <div className="flex items-center justify-between mb-2">
                          <h4 className="text-base font-bold text-slate-900 font-['Outfit']">
                            {kit.nombre}
                          </h4>
                          {isSelected && (
                            <div className="w-5 h-5 rounded-full bg-amber-400 text-slate-950 flex items-center justify-center">
                              <Check className="w-3.5 h-3.5 stroke-[3]" />
                            </div>
                          )}
                        </div>

                        {kit.subtitulo && (
                          <p className="text-[11px] font-semibold text-slate-700 mb-1">{kit.subtitulo}</p>
                        )}
                        <p className="text-[11px] text-slate-500 mb-3 min-h-[28px]">{kit.tagline}</p>

                        <div className="mb-4 pb-3 border-b border-slate-100">
                          <div className="flex items-baseline gap-1">
                            <span className="text-2xl font-extrabold text-slate-900 font-['Outfit']">
                              ${kit.precio.toLocaleString('es-AR')}
                            </span>
                            <span className="text-xs text-slate-500">ARS</span>
                          </div>
                        </div>

                        <ul className="space-y-2 mb-6">
                          {kit.incluye.map((inc, i) => (
                            <li key={i} className="text-[11px] text-slate-700 flex items-start gap-2">
                              <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                              <span>{inc}</span>
                            </li>
                          ))}
                        </ul>
                      </div>

                      <div
                        className={`w-full py-2 rounded-xl text-xs font-bold text-center transition-colors ${
                          isSelected
                            ? 'bg-slate-900 text-white'
                            : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                        }`}
                      >
                        {isSelected ? 'Kit Seleccionado' : 'Seleccionar este Kit'}
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* 16/10/2026 (Pablo): aviso de producción para quien elige el kit impreso. */}
              {selectedKit.id === 'kit-clasico' && (
                <div role="note" className="max-w-3xl mx-auto flex items-start gap-3 rounded-2xl border border-sky-200 bg-sky-50 p-4 text-left">
                  <Printer className="w-5 h-5 text-sky-700 shrink-0 mt-0.5" aria-hidden="true" />
                  <p className="text-xs text-slate-700 leading-relaxed">
                    <strong className="text-slate-900">Importante: los pedidos impresos entran a producción sólo dos veces por mes</strong>, a mediados y a fin de mes. Cuando tu pedido entre en producción <strong>te avisamos por email</strong>, y desde ese día la carpeta se entrega en el colegio dentro de los <strong>15 días hábiles</strong>.
                  </p>
                </div>
              )}

              {/* Copia Extra de Carpeta Escolar Completa (Para Abuelos / Familiares).
                  Auditoría 2026-09-09: sólo disponible con "Kit Impreso + Digital" — ver comentario
                  junto a setSelectedKit más arriba. Con los otros kits, un cartel explica por qué
                  no está y a qué kit cambiar para conseguirla. */}
              {selectedKit.id === 'kit-clasico' ? (
              <div className="bg-gradient-to-br from-amber-50/90 via-white to-amber-50/50 rounded-2xl p-5 border-2 border-amber-300 text-left space-y-4 shadow-xs">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-amber-200/80">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-amber-400 text-slate-950 flex items-center justify-center font-bold shadow-xs shrink-0">
                      <FolderCheck className="w-5 h-5 text-slate-950" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <h4 className="text-sm font-bold text-slate-900 font-['Outfit']">
                          ¿Deseás encargar una copia extra de la carpeta escolar?
                        </h4>
                        <span className="text-[10px] font-extrabold bg-amber-200 text-amber-900 px-2 py-0.5 rounded-full uppercase tracking-wider">
                          Para abuelos o familiares
                        </span>
                      </div>
                      <p className="text-xs text-slate-600 mt-0.5">
                        Una carpeta más, igual a la del kit, con las mismas 3 fotos impresas. Ideal para regalar.
                      </p>
                    </div>
                  </div>
                </div>

                <div className="p-4 rounded-xl bg-white border border-amber-300 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-bold text-slate-900">
                        Carpeta Escolar Extra Completa
                      </span>
                      <span className="text-[10px] font-extrabold bg-amber-100 text-amber-900 px-2 py-0.5 rounded border border-amber-300">
                        +{formatoPrecio(PRECIO_CARPETA_EXTRA)} ARS c/u
                      </span>
                    </div>
                    <p className="text-xs text-slate-600 mt-1 max-w-xl">
                      Incluye la carpeta conmemorativa física más todas las copias de laboratorio de las fotos que seleccionaste (individual 15x21 + grupal 20x30{fotoDocenteSeleccionada ? ` + ${etiquetaTerceraFoto(fotoDocenteSeleccionada.categoria).toLowerCase()} 15x21` : ''}).
                    </p>
                  </div>

                  {hijosParaCarpetasExtra.length > 0 ? (
                    <div className="w-full sm:w-auto sm:min-w-[300px] shrink-0 self-start sm:self-auto">
                      {hijosParaCarpetasExtra.map((h) => renderFilaCarpetaExtra(h))}
                    </div>
                  ) : (
                  <div className="flex items-center gap-3 shrink-0 self-start sm:self-auto">
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        id="btn-menos-carpeta-extra-step3"
                        onClick={() => setExtraCarpetas((prev) => Math.max(0, prev - 1))}
                        disabled={extraCarpetas === 0}
                        className="w-9 h-9 rounded-xl border border-slate-300 bg-white hover:bg-slate-100 disabled:opacity-30 disabled:cursor-not-allowed flex items-center justify-center text-slate-700 font-bold transition-colors cursor-pointer"
                        title="Restar carpeta extra"
                      >
                        <Minus className="w-4 h-4" />
                      </button>
                      <div className="min-w-10 text-center">
                        <span className="font-mono font-extrabold text-base text-slate-900 block">
                          {extraCarpetas}
                        </span>
                        <span className="text-[9px] text-slate-500 uppercase font-bold block -mt-0.5">
                          {extraCarpetas === 1 ? 'carpeta' : 'carpetas'}
                        </span>
                      </div>
                      <button
                        type="button"
                        id="btn-mas-carpeta-extra-step3"
                        onClick={() => setExtraCarpetas((prev) => Math.min(MAX_CARPETAS_EXTRA, prev + 1))}
                        disabled={extraCarpetas >= MAX_CARPETAS_EXTRA}
                        className="w-9 h-9 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold flex items-center justify-center transition-colors cursor-pointer shadow-xs"
                        title="Agregar carpeta extra"
                      >
                        <Plus className="w-4 h-4" />
                      </button>
                    </div>

                    {extraCarpetas === 0 && (
                      <button
                        type="button"
                        onClick={() => setExtraCarpetas(1)}
                        className="hidden md:inline-flex px-3 py-2 rounded-xl bg-amber-100 hover:bg-amber-200 text-amber-950 text-xs font-bold border border-amber-300 transition-colors cursor-pointer"
                      >
                        + Sumar 1 Carpeta
                      </button>
                    )}
                  </div>
                  )}
                </div>

                {totalExtraCarpetasFamilia > 0 && (
                  <div className="p-3 rounded-xl bg-amber-100/70 border border-amber-200 text-xs text-amber-950 flex items-start gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                    <div>
                      <span>
                        <strong>Carpetas a confeccionar:</strong> {totalCarpetasBaseFamilia} carpeta{totalCarpetasBaseFamilia > 1 ? 's' : ''} del pack principal + {totalExtraCarpetasFamilia} carpeta{totalExtraCarpetasFamilia > 1 ? 's' : ''} extra{totalExtraCarpetasFamilia > 1 ? 's' : ''} = <strong>{totalCarpetasBaseFamilia + totalExtraCarpetasFamilia} carpetas completas</strong> en total (+${(totalExtraCarpetasFamilia * PRECIO_CARPETA_EXTRA).toLocaleString('es-AR')}).
                      </span>
                    </div>
                  </div>
                )}
              </div>
              ) : (
                <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 text-left flex items-start gap-3">
                  <FolderCheck className="w-5 h-5 text-slate-400 shrink-0 mt-0.5" />
                  <p className="text-xs text-slate-600">
                    La copia extra de carpeta para abuelos o familiares está disponible eligiendo el <strong>Kit Impreso + Digital</strong>, que ya incluye la carpeta original.
                  </p>
                </div>
              )}

              {/* Subtotal & Navigation */}
              <div className="pt-4 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-4">
                <div className="text-left">
                  {/* Pedido de Pablo (25/9): el total grande tiene que incluir TODO lo que se paga junto
                      (hermanos y kits por adelantado), con el detalle abajo — antes mostraba sólo el
                      del hijo activo y lo demás en letra chica, sin sumar. */}
                  <span className="text-xs text-slate-500">Total a pagar:</span>
                  <div className="text-2xl font-black text-slate-900 font-['Outfit']">
                    ${totalCombinadoCarrito.toLocaleString('es-AR')}{' '}
                    <span className="text-xs font-normal text-slate-500">ARS</span>
                  </div>
                  {(otrosHijosEnCarrito.length > 0 || reservasParaSumar.length > 0) && (
                    <div className="mt-1 space-y-0.5 text-[11px] text-slate-600">
                      <p>
                        {nombreAlumno}: <strong>${total.toLocaleString('es-AR')}</strong>
                      </p>
                      {otrosHijosEnCarrito.map((c) => (
                        <p key={c.hijoId}>
                          {c.nombreCompleto}: <strong>${c.total.toLocaleString('es-AR')}</strong>
                        </p>
                      ))}
                      {reservasParaSumar.map((r) => (
                        <p key={r.hijoId}>
                          {r.nombreCompleto} (kit por adelantado): <strong>${r.precio.toLocaleString('es-AR')}</strong>
                        </p>
                      ))}
                      <p className="font-semibold text-emerald-700">Se paga todo junto en el próximo paso.</p>
                    </div>
                  )}
                </div>

                <div className="flex gap-3">
                  <button
                    onClick={() => setStep(2)}
                    className="px-4 py-2.5 text-xs font-semibold text-slate-700 hover:bg-slate-100 rounded-xl transition-colors cursor-pointer"
                  >
                    Volver a fotos
                  </button>
                  <button
                    id="btn-continuar-pago"
                    onClick={() => {
                      // Auditoría 03/10 (alto 6): sin la verificación de "ya pagaste" no se pasa al pago.
                      if (errorVerificacion) return;
                      setStep(4);
                    }}
                    disabled={Boolean(errorVerificacion)}
                    className="px-6 py-2.5 bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-xs rounded-xl shadow-md shadow-amber-400/20 flex items-center gap-2 cursor-pointer transition-all active:scale-98"
                  >
                    <span>Ir a Datos y Pago</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* STEP 4: Checkout & Payment */}
          {modalMode === 'pedido' && step === 4 && (
            // Rediseño 27/9 (pedido de Pablo): todo a la vista sin scrollear — a la izquierda lo que se
            // compra (con las fotos grandes y el subtotal de cada hijo/a), a la derecha datos, medio
            // de pago, total y el botón de pagar.
            <div className="max-w-6xl mx-auto animate-in fade-in duration-200 text-left">
              {errorVerificacion && <div className="mb-4">{renderAvisoVerificacion()}</div>}
              {errorHijosFamilia && <div className="mb-4">{renderAvisoHijos()}</div>}
              {hermanosConPedidoPendiente.length > 0 && <div className="mb-4">{renderAvisoHermanosPendientes()}</div>}
              <div className="mb-4 flex flex-wrap items-end justify-between gap-2">
                <div>
                  <h3 className="text-xl font-extrabold text-slate-900 font-['Outfit']">Revisá tu compra y pagá</h3>
                  <p className="text-xs text-slate-600">
                    Esto es exactamente lo que vas a pagar. El comprobante y la descarga llegan a tu email.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => setStep(3)}
                  className="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-xs font-bold text-slate-700 hover:bg-slate-50 cursor-pointer"
                >
                  <ArrowLeft className="h-3.5 w-3.5" />
                  Volver a cambiar kit
                </button>
              </div>

              <div className="grid grid-cols-1 gap-4 lg:grid-cols-12">
                {/* 1. Qué estás comprando */}
                <section className="space-y-3 lg:col-span-7">
                  <p className="text-[11px] font-bold uppercase tracking-wider text-slate-500">
                    1. Qué estás comprando
                    {otrosHijosEnCarrito.length + reservasParaSumar.length > 0 &&
                      ` · ${otrosHijosEnCarrito.length + reservasParaSumar.length + 1} hijos/as`}
                  </p>

                  {/* Hijo/a activo: fotos elegidas en grande */}
                  <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-xs">
                    <div className="flex flex-wrap items-start justify-between gap-2">
                      <div className="min-w-0">
                        <p className="truncate text-sm font-extrabold text-slate-900">{nombreAlumno}</p>
                        <p className="text-[11px] text-slate-500">{grado} "{division}"</p>
                      </div>
                      <div className="text-right">
                        <span className="inline-block rounded-full bg-amber-100 px-2 py-0.5 text-[10px] font-extrabold text-amber-900">
                          {selectedKit.nombre}
                        </span>
                        <p className="mt-0.5 text-base font-black text-slate-900">${total.toLocaleString('es-AR')}</p>
                      </div>
                    </div>

                    <div className="mt-3 grid grid-cols-3 gap-2">
                      {[
                        { foto: fotoGrupalSeleccionada, tipo: 'Grupal', medida: '20x30', lugar: 'grupal' as const },
                        { foto: fotoIndividualSeleccionada, tipo: 'Individual', medida: '15x21', lugar: 'individual' as const },
                        { foto: fotoDocenteSeleccionada, tipo: fotoDocenteSeleccionada && !sinFoto.includes('docente') ? etiquetaTerceraFoto(fotoDocenteSeleccionada.categoria) : textosTercera.titulo, medida: '15x21', lugar: 'docente' as const },
                      ].map(({ foto, tipo, medida, lugar }) => (
                        <div key={tipo} className="min-w-0">
                          {foto ? (
                            <MiniaturaAmpliable
                              foto={foto}
                              alt={`${tipo} elegida`}
                              className="h-24 w-full sm:h-28"
                              onAmpliar={(f) => setModalFotoPreview({ ...f, soloVista: true })}
                            />
                          ) : (
                            <div className="h-24 w-full rounded-lg bg-slate-100 sm:h-28 flex items-center justify-center p-2 text-center text-[10px] font-bold text-slate-500">{sinFoto.includes(lugar) ? 'Sin esta foto (avisaste que no la tiene)' : ''}</div>
                          )}
                          <p className="mt-1 truncate text-[11px] font-bold text-slate-800">{sinFoto.includes(lugar) && foto ? `En lugar de: ${tipo}` : tipo}</p>
                          <p className="truncate text-[10px] text-slate-500">
                            {selectedKit.id === 'kit-clasico'
                              ? `${medida} cm · ${1 + extraCarpetas} copia${extraCarpetas > 0 ? 's' : ''} + digital`
                              : 'Digital HD'}
                          </p>
                        </div>
                      ))}
                    </div>

                    {fotosSueltasSeleccionadas.length > 0 && (
                      <div className="mt-3 flex flex-wrap items-center gap-2">
                        <span className="text-[10px] font-bold text-emerald-700">Fotos sueltas:</span>
                        {fotosSueltasSeleccionadas.map((id) => {
                          const foto = fotosDisponibles.find((item) => item.id === id);
                          return foto ? (
                            <MiniaturaAmpliable
                              key={id}
                              foto={foto}
                              alt="Foto suelta elegida"
                              className="h-10 w-10"
                              onAmpliar={(f) => setModalFotoPreview({ ...f, soloVista: true })}
                            />
                          ) : null;
                        })}
                      </div>
                    )}

                    <div className="mt-3 space-y-1 border-t border-slate-100 pt-2 text-[11px] text-slate-600">
                      <div className="flex justify-between">
                        <span>{selectedKit.nombre}</span>
                        <span>${precioBase.toLocaleString('es-AR')}</span>
                      </div>
                      {extraCarpetas > 0 && (
                        <div className="flex justify-between font-semibold text-amber-700">
                          <span className="flex items-center gap-1">
                            <Printer className="h-3 w-3" />
                            Carpeta extra para familiares (x{extraCarpetas})
                          </span>
                          <span>+${(extraCarpetas * PRECIO_CARPETA_EXTRA).toLocaleString('es-AR')}</span>
                        </div>
                      )}
                      {fotosSueltasSeleccionadas.length > 0 && (
                        <div className="flex justify-between font-semibold text-emerald-700">
                          <span>Fotos sueltas (x{fotosSueltasSeleccionadas.length})</span>
                          <span>+${(fotosSueltasSeleccionadas.length * PRECIO_FOTO_EVENTO).toLocaleString('es-AR')}</span>
                        </div>
                      )}
                      <div className="flex justify-between text-emerald-700">
                        <span>Descarga digital HD</span>
                        <span>Incluida</span>
                      </div>
                    </div>
                  </div>

                  {/* Hermanos con fotos ya elegidas */}
                  {otrosHijosEnCarrito.map((c) => {
                    const categoriasElegidas = [
                      c.fotoSeleccionadaGrupal && 'Grupal',
                      c.fotoSeleccionadaIndividual && 'Individual',
                      c.fotoSeleccionadaDocente && etiquetaTerceraFoto(fotosDisponibles.find((f) => f.id === c.fotoSeleccionadaDocente)?.categoria),
                    ].filter(Boolean) as string[];
                    return (
                      <div key={c.hijoId} className="flex items-center justify-between gap-3 rounded-2xl border border-slate-200 bg-white p-3 shadow-xs">
                        <div className="min-w-0">
                          <p className="truncate text-sm font-extrabold text-slate-900">{c.nombreCompleto}</p>
                          <p className="text-[11px] text-slate-500">
                            {c.kitNombre} · {c.grado} "{c.division}"
                            {c.extraCarpetas > 0 && ` · +${c.extraCarpetas} carpeta${c.extraCarpetas > 1 ? 's' : ''} extra`}
                          </p>
                          {categoriasElegidas.length > 0 && (
                            <p className="text-[10px] text-slate-400">
                              ✓ {categoriasElegidas.join(' + ')}
                              {c.fotosSueltasSeleccionadas.length > 0 &&
                                ` · +${c.fotosSueltasSeleccionadas.length} foto${c.fotosSueltasSeleccionadas.length > 1 ? 's' : ''} suelta${c.fotosSueltasSeleccionadas.length > 1 ? 's' : ''}`}
                            </p>
                          )}
                        </div>
                        <span className="shrink-0 text-base font-black text-slate-900">${c.total.toLocaleString('es-AR')}</span>
                      </div>
                    );
                  })}

                  {/* Hermanos con kit por adelantado (sin fotos todavía) */}
                  {reservasParaSumar.map((r) => (
                    <div key={r.hijoId} className="flex items-center justify-between gap-3 rounded-2xl border border-emerald-200 bg-emerald-50/60 p-3">
                      <div className="min-w-0">
                        <p className="flex flex-wrap items-center gap-1.5 text-sm font-extrabold text-slate-900">
                          <span className="truncate">{r.nombreCompleto}</span>
                          <span className="rounded-full bg-emerald-100 px-2 py-0.5 text-[10px] font-bold text-emerald-800">Kit por adelantado</span>
                        </p>
                        <p className="text-[11px] text-slate-600">
                          {r.kitNombre}
                          {r.carpetasExtras ? ` + ${r.carpetasExtras} carpeta${r.carpetasExtras > 1 ? 's' : ''} extra` : ''}
                        </p>
                        <p className="text-[10px] text-emerald-800">Sus fotos todavía no están: las elegís cuando se carguen, sin volver a pagar.</p>
                      </div>
                      <div className="shrink-0 text-right">
                        <p className="text-base font-black text-slate-900">${r.precio.toLocaleString('es-AR')}</p>
                        <button
                          type="button"
                          onClick={() => setReservasParaSumar((prev) => prev.filter((x) => x.hijoId !== r.hijoId))}
                          className="text-[10px] text-slate-500 underline hover:text-red-600 cursor-pointer"
                        >
                          Quitar
                        </button>
                      </div>
                    </div>
                  ))}
                </section>

                {/* 2 y 3. Datos, pago y total */}
                <section className="self-start space-y-3 rounded-2xl bg-slate-900 p-4 text-white shadow-lg lg:sticky lg:top-0 lg:col-span-5">
                  <div>
                    <p className="mb-1.5 text-[11px] font-bold uppercase tracking-wider text-amber-400">2. Tus datos</p>
                    <div className="grid grid-cols-1 gap-2 sm:grid-cols-2 lg:grid-cols-1 xl:grid-cols-2">
                      <label className="text-[10px] font-semibold text-slate-400">
                        Madre, padre o tutor
                        <input
                          type="text"
                          value={tutorNombre}
                          onChange={(e) => setTutorNombre(e.target.value)}
                          className="mt-0.5 w-full rounded-lg border border-slate-700 bg-slate-800 px-2.5 py-2 text-xs text-white focus:outline-hidden focus:ring-2 focus:ring-amber-400"
                        />
                      </label>
                      <label className="text-[10px] font-semibold text-slate-400">
                        Email (comprobante y descarga)
                        <input
                          type="email"
                          value={tutorEmail}
                          onChange={(e) => setTutorEmail(e.target.value)}
                          className="mt-0.5 w-full rounded-lg border border-slate-700 bg-slate-800 px-2.5 py-2 text-xs text-white focus:outline-hidden focus:ring-2 focus:ring-amber-400"
                        />
                      </label>
                    </div>
                  </div>

                  <div>
                    <p className="mb-1.5 text-[11px] font-bold uppercase tracking-wider text-amber-400">3. Cómo pagás</p>
                    <div className={`grid gap-2 ${naveHabilitado ? 'grid-cols-3' : 'grid-cols-2'}`}>
                      {[
                        { id: 'mercadopago' as const, nombre: 'Mercado Pago', detalle: 'Débito, crédito o dinero en cuenta', Icono: CreditCard, visible: true },
                        { id: 'nave' as const, nombre: 'Nave', detalle: 'Tarjetas y QR', Icono: Smartphone, visible: naveHabilitado },
                        { id: 'transferencia' as const, nombre: 'Transferencia', detalle: 'Alias / CBU', Icono: Building2, visible: true },
                      ]
                        .filter((m) => m.visible)
                        .map(({ id, nombre, detalle, Icono }) => (
                          <button
                            key={id}
                            type="button"
                            onClick={() => setMetodoPago(id)}
                            className={`rounded-xl border p-2.5 text-left transition-all cursor-pointer ${
                              metodoPago === id
                                ? 'border-amber-400 bg-amber-400/15 ring-1 ring-amber-400'
                                : 'border-slate-700 bg-slate-800 hover:border-slate-500'
                            }`}
                          >
                            <span className="flex items-center gap-1.5 text-xs font-bold text-white">
                              <Icono className="h-3.5 w-3.5 text-amber-400" />
                              {nombre}
                            </span>
                            <span className="mt-0.5 block text-[10px] leading-tight text-slate-400">{detalle}</span>
                          </button>
                        ))}
                    </div>
                    {/* Auditoría 03/10 (alto 7): los datos bancarios se muestran recién con el pedido
                        registrado (Paso 5): antes se veían acá y una familia podía transferir por un
                        pedido que después no se llegaba a crear. */}
                    {metodoPago === 'transferencia' && (
                      <p className="mt-2 rounded-lg border border-slate-700 bg-slate-800 p-2.5 text-[11px] text-slate-300">
                        Al confirmar el pedido te mostramos el alias y el CBU para transferir, y dónde subir el comprobante.
                      </p>
                    )}
                  </div>

                  <div className="rounded-xl bg-slate-800/70 p-3">
                    <div className="space-y-1 text-[11px] text-slate-300">
                      <div className="flex justify-between gap-2">
                        <span className="truncate">{nombreAlumno} · {selectedKit.nombre}</span>
                        <span className="shrink-0">${total.toLocaleString('es-AR')}</span>
                      </div>
                      {otrosHijosEnCarrito.map((c) => (
                        <div key={c.hijoId} className="flex justify-between gap-2">
                          <span className="truncate">{c.nombreCompleto} · {c.kitNombre}</span>
                          <span className="shrink-0">${c.total.toLocaleString('es-AR')}</span>
                        </div>
                      ))}
                      {reservasParaSumar.map((r) => (
                        <div key={r.hijoId} className="flex justify-between gap-2">
                          <span className="truncate">{r.nombreCompleto} · {r.kitNombre} (adelantado)</span>
                          <span className="shrink-0">${r.precio.toLocaleString('es-AR')}</span>
                        </div>
                      ))}
                    </div>
                    <CampoCodigoDescuento aplicado={descuento} montoDescontado={descuentoTotal} onCambiar={setDescuento} deshabilitado={isProcessingPayment} />
                    <div className="mt-2 flex items-baseline justify-between border-t border-slate-700 pt-2">
                      <span className="text-xs font-bold text-slate-300">Total a pagar</span>
                      <span className="font-['Outfit'] text-2xl font-black text-amber-400">
                        {preciosOk ? `$${totalCombinadoCarrito.toLocaleString('es-AR')}` : 'a confirmar'} <span className="text-xs font-normal text-slate-400">ARS</span>
                      </span>
                    </div>
                  </div>
                  {!preciosOk && (
                    <div role="alert" className="rounded-xl border border-rose-400 bg-rose-950/40 p-3 text-xs text-rose-100 space-y-2">
                      <p>No pudimos cargar los precios vigentes: el monto queda a confirmar y todavía no se puede pagar.</p>
                      <button type="button" onClick={reintentarPrecios} disabled={cargandoPrecios} className="inline-flex items-center gap-1.5 rounded-lg bg-rose-600 px-3 py-1.5 font-bold text-white disabled:opacity-60 cursor-pointer">
                        <RefreshCw className="h-3.5 w-3.5" /> {cargandoPrecios ? 'Cargando…' : 'Reintentar'}
                      </button>
                    </div>
                  )}

                  {metodoPago === 'transferencia' && (
                    <AvisoPlazoTransferencia
                      variante="oscuro"
                      aceptado={aceptaPlazoTransferencia}
                      onCambiar={(v) => {
                        setAceptaPlazoTransferencia(v);
                        if (v) setFaltaAceptarPlazo(false);
                      }}
                      resaltar={faltaAceptarPlazo}
                    />
                  )}

                  <AceptacionTerminos variante="oscuro" conFotosElegidas aceptado={aceptaTerminos} onCambiar={setAceptaTerminos} resaltar={faltaAceptarTerminos} />

                  {pagoError && (
                    <div role="alert" className="rounded-xl border border-rose-400 bg-rose-950/40 p-3 text-xs text-rose-100 flex items-start gap-2">
                      <AlertCircle className="h-4 w-4 shrink-0 text-rose-300 mt-0.5" />
                      <span>{pagoError}</span>
                    </div>
                  )}

                  <button
                    id="btn-confirmar-pagar"
                    onClick={() => void handleCompletarPago()}
                    disabled={isProcessingPayment || Boolean(errorVerificacion) || !preciosOk}
                    className="flex w-full items-center justify-center gap-2 rounded-xl bg-amber-400 px-4 py-3 text-sm font-extrabold text-slate-950 shadow-md shadow-amber-400/20 transition-all hover:bg-amber-300 disabled:opacity-50 cursor-pointer active:scale-98"
                  >
                    {isProcessingPayment ? (
                      <>
                        <div className="h-4 w-4 animate-spin rounded-full border-2 border-slate-950 border-t-transparent" />
                        <span>Procesando pago seguro...</span>
                      </>
                    ) : (
                      <>
                        <CheckCircle2 className="h-4 w-4 text-slate-950" />
                        <span>
                          {preciosOk && totalCombinadoCarrito === 0 ? 'Confirmar pedido sin cargo' : `${metodoPago === 'transferencia' ? 'Confirmar pedido' : 'Pagar'} ${preciosOk ? `$${totalCombinadoCarrito.toLocaleString('es-AR')}` : '(monto a confirmar)'}`}
                        </span>
                      </>
                    )}
                  </button>
                  <p className="flex items-center justify-center gap-1.5 text-[10px] text-slate-400">
                    <ShieldCheck className="h-3.5 w-3.5 text-emerald-400" />
                    Pago seguro · comprobante automático por email
                  </p>
                </section>
              </div>
            </div>
          )}

          {/* STEP 5: Success & Download */}
          {step === 5 && pedidoYaNoExiste && (
            <div className="max-w-md mx-auto py-8 text-center space-y-4">
              <div className="w-14 h-14 rounded-full bg-slate-100 text-slate-600 flex items-center justify-center mx-auto">
                <AlertCircle className="w-8 h-8" />
              </div>
              <h3 className="text-xl font-extrabold text-slate-900 font-['Outfit']">Este pedido ya no está disponible</h3>
              <p className="text-sm text-slate-600">
                Fue anulado y no se te cobró nada. Podés armar un pedido nuevo cuando quieras.
              </p>
              <button
                type="button"
                onClick={() => {
                  setPedidoYaNoExiste(false);
                  setPedidoGenerado(null);
                  setNumeroPedido('');
                  // Auditoría 03/10 noche (M8b/R4): no arrastrar el carrito de la compra anterior.
                  limpiarCompraTerminada();
                  setStep(1);
                }}
                className="inline-flex items-center justify-center gap-2 px-5 py-3 rounded-xl bg-slate-950 hover:bg-slate-800 text-white text-sm font-bold cursor-pointer"
              >
                Armar un pedido nuevo
              </button>
            </div>
          )}

          {/* Auditoría 03/10 (alto 7): el Paso 5 sólo se muestra con un pedido registrado. */}
          {step === 5 && !pedidoYaNoExiste && pedidoGenerado && (
            <div className="max-w-xl mx-auto py-4 text-center space-y-6 animate-in zoom-in-95 duration-200">
              {pedidoGenerado?.estadoPago === 'aprobado' && pedidoGenerado.linkDescargaHD ? (
                <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center mx-auto shadow-md">
                  <CheckCircle2 className="w-9 h-9" />
                </div>
              ) : (
                <div className="w-16 h-16 rounded-full bg-amber-100 text-amber-800 flex items-center justify-center mx-auto shadow-md">
                  <Clock className="w-9 h-9" />
                </div>
              )}

              <div>
                {pedidoGenerado?.estadoPago === 'aprobado' ? (
                  <span className="text-xs font-bold text-emerald-800 bg-emerald-50 px-3 py-1 rounded-full border border-emerald-200 uppercase tracking-wider">
                    ¡Pago Aprobado con Éxito!
                  </span>
                ) : volvioSinPagarEste ? (
                  <span className="text-xs font-bold text-rose-800 bg-rose-50 px-3 py-1 rounded-full border border-rose-200 uppercase tracking-wider">
                    Pago no completado
                  </span>
                ) : pedidoGenerado?.estadoPago === 'rechazado' ? (
                  // Auditoría 11/10 (POR-4): rechazado o cancelado no es "pendiente de acreditación".
                  <span className="text-xs font-bold text-rose-800 bg-rose-50 px-3 py-1 rounded-full border border-rose-200 uppercase tracking-wider">
                    Pago rechazado o pedido cancelado
                  </span>
                ) : pagoEnProcesoMp && pedidoGenerado?.estadoPago === 'pendiente' ? (
                  // Auditoría 03/10 noche (M9b/R7): ticket de Rapipago/Pago Fácil u otro pago en proceso.
                  <span className="text-xs font-bold text-sky-800 bg-sky-50 px-3 py-1 rounded-full border border-sky-200 uppercase tracking-wider">
                    Pago en proceso
                  </span>
                ) : aprobadoSegunMp && pedidoGenerado?.estadoPago === 'pendiente' ? (
                  // Auditoría 03/10 noche (M9a/R6): "aprobado" lo dice sólo el servidor.
                  <span className="text-xs font-bold text-sky-800 bg-sky-50 px-3 py-1 rounded-full border border-sky-200 uppercase tracking-wider">
                    Estamos confirmando tu pago…
                  </span>
                ) : (
                  <span className="text-xs font-bold text-amber-800 bg-amber-50 px-3 py-1 rounded-full border border-amber-200 uppercase tracking-wider">
                    Pedido Registrado · Pendiente de Acreditación
                  </span>
                )}
                {volvioSinPagarEste && pedidoGenerado?.estadoPago !== 'aprobado' ? (
                  <>
                    <h3 className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-['Outfit'] mt-3">
                      Tu pedido todavía no está pago
                    </h3>
                    <p className="text-xs sm:text-sm text-slate-600 mt-2">
                      Volviste de Mercado Pago sin completar el pago: <strong>no se te cobró nada</strong>. Tu pedido quedó guardado, así que podés pagarlo ahora con el medio que prefieras.
                    </p>
                  </>
                ) : (
                <>
                <h3 className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-['Outfit'] mt-3">
                  {/* Al volver del pago en otro navegador (sin sesión ni pedido guardados) estos
                      datos no existen: se usan los del pedido y, si tampoco están, un texto neutro
                      en vez de "¡Gracias por tu pedido, !" / "El pedido de  para ". */}
                  ¡Gracias por tu pedido{(tutorNombre || (pedidoGenerado?.tutorNombre !== 'Familia' ? pedidoGenerado?.tutorNombre : '')) ? `, ${tutorNombre || pedidoGenerado?.tutorNombre}` : ''}!
                </h3>
                <p className="text-xs sm:text-sm text-slate-600 mt-2">
                  {(nombreAlumno || selectedColegio?.nombre) ? (
                    <>
                      El pedido{nombreAlumno ? <> de <strong>{nombreAlumno}</strong></> : null}
                      {selectedColegio?.nombre ? <> para <strong>{selectedColegio.nombre}</strong></> : null} ya está registrado en el sistema.
                    </>
                  ) : (
                    'Tu pedido ya está registrado en el sistema.'
                  )}
                </p>
                </>
                )}
              </div>

              {/* Order Ticket Card */}
              <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-md text-left space-y-3">
                <div className="flex justify-between items-center pb-3 border-b border-slate-100">
                  <div>
                    <span className="text-[10px] text-slate-400 uppercase tracking-wider">
                      Número de Pedido Escolar
                    </span>
                    <p className="text-base font-mono font-bold text-slate-900">{numeroPedido}</p>
                  </div>
                  {pedidoGenerado?.estadoPago === 'aprobado' ? (
                    <span className="px-2.5 py-1 rounded-full bg-emerald-100 text-emerald-800 text-xs font-bold">
                      Aprobado
                    </span>
                  ) : pedidoGenerado?.estadoPago === 'rechazado' ? (
                    <span className="px-2.5 py-1 rounded-full bg-rose-100 text-rose-800 text-xs font-bold border border-rose-300">Rechazado / cancelado</span>
                  ) : (
                    <span className="px-2.5 py-1 rounded-full bg-amber-100 text-amber-900 text-xs font-bold border border-amber-300">
                      Pendiente de Pago
                    </span>
                  )}
                </div>

                {/* Cambiar método de pago. Auditoría 2026-09-21 (pedido real de Pablo, probado en
                    producción): "intenté pagar con Mercado Pago, me arrepentí, cancelé el pago
                    justo antes de apretar el botón, y volví a la página — me queda el pendiente
                    de pago pero no me da la opción de elegir otro medio de pago, solo el botón de
                    acceder a Mercado Pago nuevamente". Antes el método de pago quedaba fijo para
                    siempre en lo elegido al crear el pedido. Se muestra solo mientras el pedido
                    sigue sin pagarse; al elegir uno nuevo, handleCambiarMetodoPago actualiza el
                    pedido en el servidor y limpia los links viejos para que los efectos de arriba
                    generen uno nuevo del método recién elegido. */}
                {/* Auditoría 03/10 noche (M9a/M9b): con un pago en proceso o que Mercado Pago informó
                    aprobado (y el servidor todavía no confirmó), no se ofrece pagar de nuevo sin que la
                    familia lo confirme expresamente. */}
                {bloquearPagoNuevo && (
                  <div role="status" className="p-4 rounded-xl bg-sky-50 border border-sky-300 text-sky-950 space-y-2">
                    <p className="font-bold text-xs flex items-center gap-1.5 text-sky-900">
                      <Clock className="w-4 h-4 text-sky-600" />
                      {comprobanteEnRevision ? 'Comprobante en revisión' : pagoEnProcesoMp ? 'Tenés un pago en proceso' : 'Estamos confirmando tu pago…'}
                    </p>
                    <p className="text-xs text-sky-800">
                      {comprobanteEnRevision ? TEXTO_COMPROBANTE_EN_REVISION : pagoEnProcesoMp
                        ? TEXTO_PAGO_EN_PROCESO
                        : esperandoNave
                          // 05/10 (bug 3): Nave no avisa en la URL si se pagó o no.
                          ? 'Volviste de Nave: estamos consultando si el pago se acreditó. Apenas se confirme lo vas a ver acá y te llega un email. Si no llegaste a pagar, podés elegir otra forma abajo.'
                          : 'Apenas se acredite lo vas a ver acá y te llega un email. No vuelvas a pagar mientras tanto.'}
                    </p>
                    {preguntandoPagarDeNuevo ? (
                      <div className="rounded-lg border border-amber-300 bg-amber-50 p-2.5 space-y-2 text-xs text-amber-950">
                        <p>
                          {comprobanteEnRevision ? 'Ya transferiste y subiste el comprobante: si pagás con tarjeta igual, puede generar un cobro doble. ¿Seguro?' : 'Si ya pagaste (por ejemplo, el ticket de Rapipago/Pago Fácil), pagar de nuevo te puede cobrar dos veces. ¿Querés igual pagar de otra forma?'}
                        </p>
                        <div className="flex flex-wrap gap-2">
                          <button
                            type="button"
                            onClick={() => {
                              setConfirmoPagarDeNuevo(true);
                              setPreguntandoPagarDeNuevo(false);
                            }}
                            className="px-3 py-1.5 rounded-lg bg-amber-400 hover:bg-amber-300 font-extrabold text-slate-950 cursor-pointer"
                          >
                            {comprobanteEnRevision ? 'Ya transferí pero quiero pagar con tarjeta igual' : 'Sí, quiero pagar de otra forma'}
                          </button>
                          <button
                            type="button"
                            onClick={() => setPreguntandoPagarDeNuevo(false)}
                            className="px-3 py-1.5 rounded-lg border border-slate-300 bg-white font-bold text-slate-800 hover:bg-slate-50 cursor-pointer"
                          >
                            No, espero la acreditación
                          </button>
                        </div>
                      </div>
                    ) : (
                      <button
                        type="button"
                        onClick={() => setPreguntandoPagarDeNuevo(true)}
                        className="text-[11px] font-semibold text-sky-800 underline cursor-pointer"
                      >
                        Quiero pagar de otra forma
                      </button>
                    )}
                  </div>
                )}

                {pedidoGenerado?.estadoPago !== 'aprobado' && !bloquearPagoNuevo && (
                  <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
                    <p className="text-xs font-semibold text-slate-700">
                      ¿Preferís pagar de otra forma?
                    </p>
                    <div className="flex flex-wrap gap-2">
                      {(
                        [
                          // Pedido de Pablo (25/9): cada medio con el color de su marca (Mercado Pago
                          // celeste #009EE3, Nave violeta) y transferencia neutra.
                          { id: 'mercadopago' as const, label: 'Mercado Pago', clases: 'bg-[#009EE3] hover:bg-[#0087c2] text-white border-[#009EE3]' },
                          { id: 'nave' as const, label: 'Nave', clases: 'bg-violet-600 hover:bg-violet-700 text-white border-violet-600' },
                          { id: 'transferencia' as const, label: 'Transferencia', clases: 'bg-white hover:bg-slate-50 text-slate-800 border-slate-300' },
                        ]
                      )
                        .filter((opcion) => opcion.id !== pedidoGenerado?.metodoPago && (opcion.id !== 'nave' || naveHabilitado))
                        .map((opcion) => (
                          <button
                            key={opcion.id}
                            type="button"
                            onClick={() => (opcion.id === 'transferencia' ? setCambioATransferencia({ acepta: false, falta: false }) : handleCambiarMetodoPago(opcion.id))}
                            disabled={cambiandoMetodoPago}
                            className={`px-3 py-2 text-xs font-bold border rounded-lg shadow-xs transition-all cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed ${opcion.clases}`}
                          >
                            {cambiandoMetodoPago ? 'Cambiando...' : `Pagar con ${opcion.label}`}
                          </button>
                        ))}
                    </div>
                    {pedidoGenerado?.metodoPago !== 'transferencia' && cambioATransferencia && (
                      <div className="space-y-2">
                        <AvisoPlazoTransferencia
                          id="chk-plazo-cambio-transferencia"
                          aceptado={cambioATransferencia.acepta}
                          onCambiar={(v) => setCambioATransferencia({ acepta: v, falta: false })}
                          resaltar={cambioATransferencia.falta}
                        />
                        <button
                          type="button"
                          disabled={cambiandoMetodoPago}
                          onClick={() => {
                            if (!cambioATransferencia.acepta) return setCambioATransferencia({ acepta: false, falta: true });
                            setCambioATransferencia(null);
                            void handleCambiarMetodoPago('transferencia');
                          }}
                          className="px-3 py-2 text-xs font-bold border border-slate-300 rounded-lg bg-white text-slate-800 hover:bg-slate-50 cursor-pointer disabled:opacity-50"
                        >
                          Confirmar el pago por transferencia
                        </button>
                      </div>
                    )}
                  </div>
                )}

                {/* Mercado Pago Redirection / Link. Auditoría 2026-09-21: esto antes leía el
                    estado local "metodoPago" (el seleccionado en el checkout del paso 4), no el
                    método REAL del pedido ya guardado — si la familia recargaba la página o
                    volvía en una pestaña nueva (por ejemplo desde el link de vuelta de Nave), ese
                    estado local nace en su valor por defecto ('mercadopago') sin importar cuál
                    haya sido el método real, así que este bloque podía no mostrarse nunca aunque
                    sí hubiera un link listo. Ahora usa pedidoGenerado.metodoPago, que es el dato
                    persistido y siempre correcto. */}
                {pedidoGenerado?.metodoPago === 'mercadopago' && mpRedirectUrl && pedidoGenerado?.estadoPago !== 'aprobado' && !bloquearPagoNuevo && (
                  <div className="p-4 rounded-xl bg-sky-50 border border-sky-300 text-sky-950 space-y-2">
                    <p className="font-bold text-xs flex items-center gap-1.5 text-sky-900">
                      <CreditCard className="w-4 h-4 text-sky-600" />
                      Checkout Pro de Mercado Pago
                    </p>
                    <p className="text-xs text-sky-800">
                      Si la ventana de pago no se abrió de forma automática, hacé clic en el botón para completar el pago de forma segura:
                    </p>
                    <a
                      href={mpRedirectUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-2 px-4 py-2.5 bg-[#009EE3] hover:bg-[#0087c2] text-white font-bold text-xs rounded-xl shadow transition-all cursor-pointer"
                    >
                      <CreditCard className="w-3.5 h-3.5" />
                      {/* Auditoría 03/10 noche (M7/H6): el total del pedido según el servidor. */}
                      <span>Ir a Pagar{montoDelPedido(pedidoGenerado) ? ` ${montoDelPedido(pedidoGenerado)}` : ''} en Mercado Pago</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </a>
                  </div>
                )}

                {/* Sin link de pago a mano (recién llegado, recargó la página, o Mercado Pago
                    lo devolvió sin completar el pago): siempre hay forma de generar uno nuevo. */}
                {pedidoGenerado?.metodoPago === 'mercadopago' && !mpRedirectUrl && pedidoGenerado?.estadoPago !== 'aprobado' && !bloquearPagoNuevo && (
                  <div className="p-4 rounded-xl bg-sky-50 border border-sky-300 text-sky-950 space-y-2">
                    <p className="font-bold text-xs flex items-center gap-1.5 text-sky-900">
                      <CreditCard className="w-4 h-4 text-sky-600" />
                      Checkout Pro de Mercado Pago
                    </p>
                    <p className="text-xs text-sky-800">
                      {generandoLinkPago
                        ? 'Generando un link de pago seguro con Mercado Pago...'
                        : confirmoPagarDeNuevo
                        ? 'Generá un link nuevo para pagarlo de otra forma:'
                        : 'Todavía no completaste el pago de este pedido. Generá el link para pagarlo ahora:'}
                    </p>
                    <button
                      type="button"
                      onClick={() => pedidoGenerado && generarLinkDePago(pedidoGenerado, false)}
                      disabled={generandoLinkPago}
                      className="inline-flex items-center gap-2 px-4 py-2.5 bg-[#009EE3] hover:bg-[#0087c2] text-white font-bold text-xs rounded-xl shadow transition-all cursor-pointer disabled:opacity-60"
                    >
                      {generandoLinkPago ? (
                        <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                      ) : (
                        <CreditCard className="w-3.5 h-3.5" />
                      )}
                      <span>{generandoLinkPago ? 'Generando...' : `Generar Link de Pago${montoDelPedido(pedidoGenerado) ? ` de ${montoDelPedido(pedidoGenerado)}` : ''}`}</span>
                    </button>
                  </div>
                )}

                {/* Nave Redirection / Link. Mismo motivo que el bloque de Mercado Pago de
                    arriba: usa pedidoGenerado.metodoPago (el dato persistido), no el estado local
                    del checkout. */}
                {pedidoGenerado?.metodoPago === 'nave' && naveRedirectUrl && pedidoGenerado?.estadoPago !== 'aprobado' && !bloquearPagoNuevo && (
                  <div className="p-4 rounded-xl bg-violet-50 border border-violet-300 text-violet-950 space-y-2">
                    <p className="font-bold text-xs flex items-center gap-1.5 text-violet-900">
                      <Smartphone className="w-4 h-4 text-violet-600" />
                      Checkout de Nave
                    </p>
                    <p className="text-xs text-violet-800">
                      Si la ventana de pago no se abrió de forma automática, hacé clic en el botón para completar el pago de forma segura:
                    </p>
                    <a
                      href={naveRedirectUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-2 px-4 py-2.5 bg-violet-600 hover:bg-violet-700 text-white font-bold text-xs rounded-xl shadow transition-all cursor-pointer"
                    >
                      <Smartphone className="w-3.5 h-3.5" />
                      <span>Ir a Pagar{montoDelPedido(pedidoGenerado) ? ` ${montoDelPedido(pedidoGenerado)}` : ''} en Nave</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </a>
                  </div>
                )}

                {/* Sin link de pago a mano (recién llegado, recargó la página, o Nave lo devolvió
                    sin completar el pago): siempre hay forma de generar uno nuevo. */}
                {pedidoGenerado?.metodoPago === 'nave' && !naveRedirectUrl && pedidoGenerado?.estadoPago !== 'aprobado' && !bloquearPagoNuevo && (
                  <div className="p-4 rounded-xl bg-violet-50 border border-violet-300 text-violet-950 space-y-2">
                    <p className="font-bold text-xs flex items-center gap-1.5 text-violet-900">
                      <Smartphone className="w-4 h-4 text-violet-600" />
                      Checkout de Nave
                    </p>
                    <p className="text-xs text-violet-800">
                      {generandoLinkNave
                        ? 'Generando un link de pago seguro con Nave...'
                        : 'Todavía no completaste el pago de este pedido. Generá el link para pagarlo ahora:'}
                    </p>
                    <button
                      type="button"
                      onClick={() => pedidoGenerado && generarLinkDeNave(pedidoGenerado, false)}
                      disabled={generandoLinkNave}
                      className="inline-flex items-center gap-2 px-4 py-2.5 bg-violet-600 hover:bg-violet-700 text-white font-bold text-xs rounded-xl shadow transition-all cursor-pointer disabled:opacity-60"
                    >
                      {generandoLinkNave ? (
                        <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                      ) : (
                        <Smartphone className="w-3.5 h-3.5" />
                      )}
                      <span>{generandoLinkNave ? 'Generando...' : `Generar Link de Pago${montoDelPedido(pedidoGenerado) ? ` de ${montoDelPedido(pedidoGenerado)}` : ''}`}</span>
                    </button>
                  </div>
                )}

                {/* Verification box & auto-polling status */}
                {/* 05/10 (bug 8): también con el pago aprobado pero sin link HD todavía — cuando el sondeo
                    automático se agota, la familia necesita un botón para volver a consultar. */}
                {(pedidoGenerado?.estadoPago !== 'aprobado' || (!pedidoGenerado.linkDescargaHD && !pedidoGenerado.esMejora)) && (
                  <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2.5">
                    <div className="text-xs text-slate-600">
                      <p className="font-semibold text-slate-800 flex items-center gap-1.5">
                        <Clock className="w-3.5 h-3.5 text-amber-600" />
                        <span>
                          {pedidoGenerado?.estadoPago === 'aprobado'
                            ? 'Pago confirmado · esperando el link de descarga'
                            : pedidoGenerado?.estadoPago === 'rechazado'
                              ? 'Pago rechazado o pedido cancelado'
                              : volvioSinPagarEste
                              ? '¿Ya pagaste en otra pestaña?'
                              : 'Verificación automática de pago activa'}
                        </span>
                      </p>
                      <p className="text-[11px] text-slate-500 mt-0.5">
                        {pedidoGenerado?.estadoPago === 'aprobado'
                          ? 'Si pasaron varios minutos y el botón de descarga sigue sin activarse, tocá "Re-verificar Estado". El link también te llega por email.'
                          : volvioSinPagarEste
                            ? 'Si completaste el pago por otro lado, tocá "Re-verificar Estado" para actualizarlo.'
                            : mensajeEstadoPago || 'Sincronizando con Mercado Pago y la base de datos...'}
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={() => verificarEstadoRealPedido()}
                      disabled={verificandoPago}
                      className="px-3 py-1.5 bg-white hover:bg-slate-100 border border-slate-300 text-slate-700 font-bold text-xs rounded-lg shadow-xs flex items-center gap-1.5 transition-all cursor-pointer shrink-0 disabled:opacity-50"
                    >
                      {verificandoPago ? (
                        <div className="w-3.5 h-3.5 border-2 border-slate-700 border-t-transparent rounded-full animate-spin" />
                      ) : (
                        <RefreshCw className="w-3.5 h-3.5 text-slate-500" />
                      )}
                      <span>{verificandoPago ? 'Verificando...' : 'Re-verificar Estado'}</span>
                    </button>
                  </div>
                )}

                {/* 05/10 (bug 2b): el carrito está registrado y se paga; el kit del hermano no se sumó. */}
                {avisoReservaNoSumada && (
                  <div role="alert" className="p-3.5 rounded-xl bg-amber-50 border border-amber-300 text-amber-950 text-xs flex items-start gap-2">
                    <AlertCircle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                    <div>
                      <p className="font-bold">Un kit por adelantado no se pudo sumar:</p>
                      <p className="text-[11px] text-amber-900 mt-0.5">{avisoReservaNoSumada}</p>
                    </div>
                  </div>
                )}

                {/* Error notice if preference creation failed */}
                {pagoError && (
                  <div className="p-3.5 rounded-xl bg-rose-50 border border-rose-300 text-rose-900 text-xs flex items-start gap-2">
                    <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                    <div>
                      <p className="font-bold">Aviso sobre el pago:</p>
                      <p className="text-[11px] text-rose-700 mt-0.5">{pagoError}</p>
                    </div>
                  </div>
                )}

                {/* Bank Transfer Instructions if Transferencia. Mismo motivo que los bloques de
                    arriba: usa pedidoGenerado.metodoPago, no el estado local del checkout. */}
                {pedidoGenerado?.metodoPago === 'transferencia' && pedidoGenerado?.estadoPago === 'pendiente' && (
                  <div className="p-3.5 rounded-xl bg-amber-50 border border-amber-300 text-amber-950 text-xs space-y-1">
                    <p className="font-bold text-amber-900 flex items-center gap-1.5">
                      <Building2 className="w-4 h-4 text-amber-700" />
                      Datos para completar la transferencia bancaria:
                    </p>
                    <p className="text-slate-700">
                      {/* Auditoría 2026-09-17 (Pablo: "como es que elegi un kit... si elegi las
                          fotos de mis 2 hijos y me cobro 60 mil pesos?"): acá abajo usaba "total",
                          el precio del hijo que haya quedado activo en pantalla en ESE momento
                          (line 788), no el monto real del pedido que se acaba de confirmar —
                          con 2+ hijos podía mostrar un número que no tenía nada que ver con lo
                          efectivamente cobrado. "pedidoGenerado.total" es el monto congelado al
                          momento de crear el pedido (combinado si son varios hijos), que es lo
                          que corresponde mostrar acá. El cobro real nunca estuvo mal — lo
                          calcula siempre el servidor — esto era sólo un problema de qué número
                          se le mostraba a la familia. */}
                      {/* Auditoría 03/10 noche (M7/H6): el total del servidor, nunca el sumado acá. */}
                      <strong>Monto total:</strong> {montoDelPedido(pedidoGenerado) ? `${montoDelPedido(pedidoGenerado)} ARS` : 'lo estamos consultando…'}
                    </p>
                    <p className="text-slate-700">
                      <strong>Banco:</strong> Galicia
                    </p>
                    <p className="text-slate-700">
                      <strong>Titular:</strong> Alderete Pablo Gabriel
                    </p>
                    <p className="text-slate-700">
                      <strong>CUIT:</strong> 20-28306117-6
                    </p>
                    <p className="text-slate-700">
                      <strong>Alias:</strong> <span className="font-mono font-bold">RETRATO.ESCOLAR</span>
                    </p>
                    <p className="text-slate-700">
                      <strong>CBU:</strong> <span className="font-mono">0070313830004052956749</span>
                    </p>
                  </div>
                )}
                {pedidoGenerado?.metodoPago === 'transferencia' && pedidoGenerado?.estadoPago !== 'aprobado' && (pedidoGenerado.grupoPagoId || pedidoGenerado.supabaseId) && ( /* vencido: SubirComprobante dice «si ya transferiste, escribinos» */
                  <SubirComprobante
                    grupoPagoId={pedidoGenerado.grupoPagoId || undefined}
                    pedidoId={pedidoGenerado.grupoPagoId ? undefined : pedidoGenerado.supabaseId}
                    numeros={numeroPedido}
                    codigo={codigoSeccionValidado}
                    onSubido={() => setComprobanteEnRevision(true)}
                  />
                )}

                {/* Email Delivery Confirmation Card */}
                {pedidoGenerado?.estadoPago === 'aprobado' ? (
                  <div className="p-3.5 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-900 flex items-start gap-3">
                    <Mail className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                    <div className="text-xs">
                      <p className="font-bold text-emerald-950">
                        ¡Fotos HD y comprobante enviados a tu correo!
                      </p>
                      <p className="text-emerald-700 mt-0.5">
                        Enviamos el enlace privado de descarga en máxima resolución a{' '}
                        <strong>{tutorEmail || pedidoGenerado?.tutorEmail || 'tu email registrado'}</strong>.
                      </p>
                    </div>
                  </div>
                ) : (
                  <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 text-slate-700 flex items-start gap-3">
                    <Mail className="w-5 h-5 text-slate-500 shrink-0 mt-0.5" />
                    <div className="text-xs">
                      <p className="font-bold text-slate-800">
                        Envío automático de fotos HD por correo
                      </p>
                      <p className="text-slate-600 mt-0.5">
                        Cuando se confirme tu pago te mandamos al instante el link para descargar tus fotos en alta resolución a{' '}
                        <strong>{tutorEmail || pedidoGenerado?.tutorEmail || 'tu email registrado'}</strong>.
                      </p>
                    </div>
                  </div>
                )}

                {/* Extra Copies Confirmation Card if requested */}
                {pedidoGenerado && (pedidoGenerado.copiasExtras?.carpetasExtras || 0) > 0 && (
                  <div className="p-3.5 rounded-xl bg-amber-50 border border-amber-300 text-amber-950 flex items-start gap-3">
                    <FolderCheck className="w-5 h-5 text-amber-700 shrink-0 mt-0.5" />
                    <div className="text-xs">
                      <p className="font-bold text-amber-950 flex items-center gap-1.5">
                        <span>Incluye {pedidoGenerado.copiasExtras?.carpetasExtras} carpeta{(pedidoGenerado.copiasExtras?.carpetasExtras || 0) > 1 ? 's' : ''} extra</span>
                      </p>
                      <p className="text-amber-800 mt-0.5">
                        Vas a recibir una carpeta más, igual a la del kit, con las mismas 3 fotos.
                      </p>
                    </div>
                  </div>
                )}

                {/* Selected Photos Thumbnails (auditoría 2026-09, pedido de Pablo): antes acá
                    se mostraba el listado de nombres de archivo internos para el laboratorio
                    (con código de alumno y "copias extra duplicadas"), que es información
                    interna del minilab y no debería ser visible para la familia. Ahora el
                    cliente sólo ve miniaturas de las fotos que eligió — sin nombres de
                    archivo ni copias extra repetidas. El detalle de archivos para el
                    laboratorio sigue disponible para el fotógrafo en el panel de admin
                    (pestaña "Laboratorio & Ensobrado"). */}
                {/* Auditoría 2026-09-23 (bug real, encontrado con un navegador headless): al volver
                    de Mercado Pago/Nave en un navegador que no tiene el pedido guardado (el caso
                    típico en celular), el pedido de respaldo que arma la pantalla no trae
                    `archivosParaLaboratorio` — el `.filter` sobre undefined tiraba abajo todo el
                    portal justo en la pantalla de confirmación del pago. */}
                {pedidoGenerado && (pedidoGenerado.archivosParaLaboratorio || []).some((archivo) => !archivo.esCopiaExtra) && (
                  <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200">
                    <div className="flex items-center gap-1.5 text-slate-700 font-bold text-xs mb-2.5">
                      <Images className="w-4 h-4 text-slate-500" />
                      <span>Tus fotos elegidas:</span>
                    </div>
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
                      {(pedidoGenerado.archivosParaLaboratorio || [])
                        .filter(archivo => !archivo.esCopiaExtra)
                        .map((archivo, idx) => (
                          <div key={idx} className="space-y-1">
                            {archivo.sinFotoReal ? (
                              // Auditoría 2026-09-15 (pedido de Pablo: "eliminemos todas las
                              // fotos de muestra"): en vez de una imagen rota (o, peor, una
                              // foto de stock que no es la del alumno), se avisa que está
                              // pendiente de verificación por el equipo fotográfico.
                              <div className="aspect-square rounded-lg bg-amber-50 border border-amber-300 flex flex-col items-center justify-center gap-1 p-1.5 text-center">
                                <AlertCircle className="w-5 h-5 text-amber-600" />
                                <span className="text-[9px] font-semibold text-amber-800 leading-tight">Foto pendiente de verificación</span>
                              </div>
                            ) : (
                              <div className="aspect-square rounded-lg overflow-hidden bg-slate-200 border border-slate-300">
                                <img
                                  src={archivo.urlMuestra}
                                  alt={archivo.tipo}
                                  className="w-full h-full object-cover"
                                />
                              </div>
                            )}
                            <p className="text-[10px] text-slate-500 text-center capitalize">{archivo.tipo}</p>
                          </div>
                        ))}
                    </div>
                  </div>
                )}

                <div className="text-xs text-slate-600 space-y-1">
                  <p>
                    {/* Mismo fix que "Monto total" arriba: usa el kit/total congelados del
                        pedido ya confirmado (pedidoGenerado), no el estado en vivo de la
                        pantalla — que con 2+ hijos ya dice "2 hijos/as" en vez del kit de uno
                        solo (ver pedidoSintetico más arriba en este archivo). */}
                    <strong>Kit:</strong> {pedidoGenerado?.kitNombre ?? selectedKit.nombre}
                    {montoDelPedido(pedidoGenerado) ? ` (${montoDelPedido(pedidoGenerado)} ARS)` : ''}
                  </p>
                  {grado && (
                    <p>
                      <strong>Curso:</strong> {grado}{division ? ` "${division}"` : ''}{turno ? ` · Turno ${turno}` : ''}
                    </p>
                  )}
                  <p>
                    <strong>Entrega impresa:</strong> Se entrega en sobre cerrado rotulado con el código y nombre del alumno en la institución, dentro de los 15 días hábiles posteriores al cierre de pedidos del curso.
                  </p>
                  {tutorWhatsapp && (
                    <p>
                      <strong>WhatsApp de contacto:</strong> {tutorWhatsapp}
                    </p>
                  )}
                </div>
              </div>

              {/* Instant Download Action */}
              {/* Auditoría 2026-09-18 (reporte de Pablo): antes esta rama solo miraba
                  estadoPago === 'aprobado' y mostraba el botón activo con href={linkDescargaHD}
                  aunque ese link todavía estuviera vacío (se carga después, a mano, desde el
                  panel de Laboratorio) — un <a> con href="" y target="_blank" abre una pestaña
                  nueva de la propia página en vez de descargar algo, que es justo lo que
                  reportó. Ahora exige también que el link ya exista. */}
              {pedidoGenerado?.estadoPago === 'aprobado' && pedidoGenerado.linkDescargaHD ? (
                <div className="p-4 rounded-2xl bg-amber-50 border border-amber-200 text-left flex flex-col sm:flex-row items-center justify-between gap-4">
                  <div>
                    <p className="text-xs font-bold text-amber-900 flex items-center gap-1.5">
                      <Download className="w-4 h-4 text-amber-600" />
                      Descarga Inmediata en Ultra HD (Sin Marcas)
                    </p>
                    <p className="text-[11px] text-amber-700">
                      Podés descargar tus fotos ahora mismo en alta resolución además de recibirlas en tu correo.
                    </p>
                  </div>
                  <a
                    href={pedidoGenerado.linkDescargaHD}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold rounded-xl transition-all shadow-xs flex items-center gap-1.5 shrink-0 cursor-pointer"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Descargar Fotos HD</span>
                  </a>
                </div>
              ) : pedidoGenerado?.estadoPago === 'aprobado' && pedidoGenerado.esMejora ? (
                // 05/10 (bug 8): la mejora a Kit Impreso no genera un .zip propio — antes quedaba en
                // "Preparando tu descarga…" para siempre.
                <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 text-left flex flex-col sm:flex-row items-center justify-between gap-4">
                  <div>
                    <p className="text-xs font-bold text-emerald-900 flex items-center gap-1.5">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                      {pedidoGenerado.esFotosExtra ? 'Pago acreditado — fotos extra en camino' : 'Pago acreditado — carpeta impresa en camino'}
                    </p>
                    <p className="text-[11px] text-emerald-800">
                      {pedidoGenerado.esFotosExtra ? 'Las copias se imprimen aparte del kit y se entregan en el colegio. Te avisamos por email en cada paso.' : 'Tu carpeta impresa se suma al pedido anterior; la descarga digital ya la tenés en ese pedido (y en el email que te llegó al pagarlo).'}
                    </p>
                  </div>
                </div>
              ) : pedidoGenerado?.estadoPago === 'aprobado' ? (
                <div className="p-4 rounded-2xl bg-sky-50 border border-sky-200 text-left flex flex-col sm:flex-row items-center justify-between gap-4">
                  <div>
                    <p className="text-xs font-bold text-sky-900 flex items-center gap-1.5">
                      <Clock className="w-4 h-4 text-sky-600" />
                      Pago acreditado — preparando tu descarga
                    </p>
                    <p className="text-[11px] text-sky-700">
                      Ya confirmamos tu pago. El link de descarga en alta resolución se está terminando de cargar y te va a llegar por email apenas esté listo.
                    </p>
                  </div>
                  <button
                    disabled
                    className="px-4 py-2 bg-sky-200 text-sky-800 text-xs font-bold rounded-xl flex items-center gap-1.5 shrink-0 cursor-not-allowed opacity-75"
                  >
                    <Clock className="w-3.5 h-3.5" />
                    <span>Preparando...</span>
                  </button>
                </div>
              ) : (
                <div className="p-4 rounded-2xl bg-slate-100 border border-slate-300 text-left flex flex-col sm:flex-row items-center justify-between gap-4">
                  <div>
                    <p className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                      <Lock className="w-4 h-4 text-slate-500" />
                      Descarga Ultra HD (Protegida hasta confirmación de pago)
                    </p>
                    <p className="text-[11px] text-slate-500">
                      El enlace de descarga en máxima resolución se liberará automáticamente en cuanto se acredite el pago.
                    </p>
                  </div>
                  <button
                    disabled
                    className="px-4 py-2 bg-slate-300 text-slate-600 text-xs font-bold rounded-xl flex items-center gap-1.5 shrink-0 cursor-not-allowed opacity-75"
                  >
                    <Lock className="w-3.5 h-3.5" />
                    <span>Esperando Pago</span>
                  </button>
                </div>
              )}

              <div className="flex flex-col sm:flex-row gap-3 justify-center pt-2">
                {/* Auditoría 2026-09-18 (pedido de Pablo): se sacó el botón de WhatsApp — las
                    familias no deben tener ningún punto de contacto por WhatsApp en la web,
                    solo por el sistema de mensajería propio del sitio (Consultas) o por email.
                    Auditoría 2026-09-18 (reporte de Pablo, mismo día): confirmado en vivo — el
                    mailto: no abría nada, "solo vuelve a la web". Reemplazado por el formulario
                    de Consultas del sitio (con los datos ya precargados). Ver
                    src/utils/consultaPrefill.ts. */}
                {/* Pedido de Pablo (27/9): se sacó "Avisar por email" de esta pantalla. */}

                <button
                  onClick={onClose}
                  className="px-5 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-800 font-semibold text-xs rounded-xl transition-colors cursor-pointer"
                >
                  Cerrar Portal
                </button>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Modal Single Photo Fullscreen Preview */}
      {modalFotoPreview && (
        <div
          onClick={() => setModalFotoPreview(null)}
          className="fixed inset-0 z-60 bg-slate-950/90 backdrop-blur-md flex items-center justify-center p-4"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="relative max-w-3xl w-full bg-slate-900 rounded-3xl overflow-hidden p-3 text-white border border-slate-800"
          >
            <div 
              ref={contenedorPreviewRef}
              className="relative aspect-4/3 overflow-hidden rounded-2xl bg-black select-none"
              onContextMenu={(e) => {
                e.preventDefault();
                e.stopPropagation();
              }}
            >
              {/* Auditoría 03/10 (medio): `key` por foto para que el navegador no deje la imagen
                  anterior en pantalla mientras baja la nueva (se veía una foto y "Elegir" elegía
                  otra), y un spinner hasta que termina de cargar. */}
              <img
                key={modalFotoPreview.id}
                ref={imgPreviewRef}
                src={modalFotoPreview.url}
                alt={modalFotoPreview.titulo}
                draggable={false}
                onLoad={() => setPreviewCargadaId(modalFotoPreview.id)}
                onError={() => setPreviewCargadaId(modalFotoPreview.id)}
                className={`w-full h-full object-contain pointer-events-none select-none transition-opacity ${previewCargadaId === modalFotoPreview.id ? 'opacity-100' : 'opacity-0'}`}
              />
              {previewCargadaId !== modalFotoPreview.id && (
                <div className="absolute inset-0 flex items-center justify-center" aria-busy="true">
                  <Loader2 className="h-8 w-8 animate-spin text-amber-400" />
                </div>
              )}
              {/* Sin overlay de React acá: esta imagen ya trae la marca de agua quemada en
                  los píxeles desde que se subió — agregar otra capa encima solo duplicaba
                  el texto y se veía recargado. */}
            </div>

            <div className="p-3 flex items-center justify-between gap-3">
              <div className="min-w-0">
                <p className="text-xs font-bold text-white truncate">{modalFotoPreview.titulo}</p>{modalFotoPreview.numero && <p className="text-sm font-extrabold text-amber-300 mt-0.5">Foto N° {modalFotoPreview.numero}</p>}
              </div>
              <div className="flex items-center gap-2 shrink-0">
                {modalFotoPreview.categoria !== 'patio' && !modalFotoPreview.soloVista && (
                  <button
                    type="button"
                    disabled={previewCargadaId !== modalFotoPreview.id}
                    onClick={() => {
                      // Sólo una foto de la galería actual (no una que quedó de otro hijo/curso).
                      if (fotosDisponibles.some((f) => f.id === modalFotoPreview.id)) elegirFotoDelPack(modalFotoPreview);
                      setModalFotoPreview(null);
                    }}
                    className="px-3 py-1.5 bg-amber-400 hover:bg-amber-300 text-slate-950 text-xs rounded-lg font-bold cursor-pointer disabled:opacity-50 disabled:cursor-wait"
                  >
                    Elegir esta foto
                  </button>
                )}
                <button
                  onClick={() => setModalFotoPreview(null)}
                  className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-xs rounded-lg font-semibold cursor-pointer"
                >
                  Cerrar
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Auditoría 03/10 noche (contrato 3, revisado): confirmar la inscripción del link del email
          pidiendo el DNI de quien la hizo. Cerrar esta pantallita también saca el parámetro de la URL. */}
      {confirmacionAcceso && (
        <div className="fixed inset-0 z-70 bg-slate-950/80 flex items-center justify-center p-4" role="dialog" aria-modal="true" aria-labelledby="titulo-confirmar-acceso">
          <form
            className="relative max-w-md w-full rounded-2xl bg-white p-5 text-left shadow-2xl space-y-3"
            onSubmit={(e) => {
              e.preventDefault();
              void enviarConfirmacionAcceso();
            }}
          >
            <button type="button" onClick={cerrarConfirmacionAcceso} className="absolute right-3 top-3 rounded-lg p-1 text-slate-400 hover:bg-slate-100 cursor-pointer" aria-label="Cerrar sin confirmar">
              <X className="h-5 w-5" />
            </button>
            <div className="flex items-start gap-2.5 pr-6">
              <ShieldCheck className="h-6 w-6 shrink-0 text-emerald-600" />
              <h4 id="titulo-confirmar-acceso" className="text-base font-extrabold text-slate-900">
                Confirmá tu inscripción: escribí el DNI de la persona que hizo la inscripción
              </h4>
            </div>
            <input
              type="text"
              inputMode="numeric"
              autoComplete="off"
              aria-label="DNI de la persona que hizo la inscripción"
              placeholder="DNI (sólo números)"
              value={confirmacionAcceso.dni}
              onChange={(e) => {
                const dni = e.target.value.replace(/\D/g, '').slice(0, 12);
                setConfirmacionAcceso((prev) => (prev ? { ...prev, dni, error: null } : prev));
              }}
              className="w-full px-3.5 py-2.5 text-sm bg-white border-2 border-amber-300 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-amber-500"
            />
            {confirmacionAcceso.error && (
              <p role="alert" className="rounded-lg border border-rose-300 bg-rose-50 p-2.5 text-xs font-semibold text-rose-800">
                {confirmacionAcceso.error}
              </p>
            )}
            <div className="flex flex-col sm:flex-row gap-2 pt-1">
              <button
                type="button"
                onClick={cerrarConfirmacionAcceso}
                className="flex-1 rounded-xl border-2 border-slate-300 bg-white px-4 py-2.5 text-xs font-bold text-slate-800 hover:bg-slate-50 cursor-pointer"
              >
                Cerrar
              </button>
              <button
                type="submit"
                disabled={confirmacionAcceso.enviando}
                className="flex-1 inline-flex items-center justify-center gap-1.5 rounded-xl bg-amber-400 px-4 py-2.5 text-xs font-extrabold text-slate-950 hover:bg-amber-300 disabled:opacity-60 cursor-pointer"
              >
                {confirmacionAcceso.enviando && <Loader2 className="h-4 w-4 animate-spin" />}
                Confirmar
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Auditoría 03/10 (alto 8): el servidor respondió 409 KIT_YA_PAGADO — ya hay un kit pagado
          para este alumno/a (por ejemplo, lo compró el otro padre). Se pregunta con un aviso del
          propio portal y, si confirma, se reenvía el mismo pedido con confirmarOtroKit. */}
      {confirmacionOtroKit && (
        <div className="fixed inset-0 z-70 bg-slate-950/80 flex items-center justify-center p-4" role="dialog" aria-modal="true" aria-labelledby="titulo-otro-kit">
          <div className="max-w-md w-full rounded-2xl bg-white p-5 text-left shadow-2xl space-y-3">
            <div className="flex items-start gap-2.5">
              <PackageCheck className="h-6 w-6 shrink-0 text-amber-600" />
              <div>
                <h4 id="titulo-otro-kit" className="text-base font-extrabold text-slate-900">
                  Ya hay un kit pagado para {confirmacionOtroKit.alumnos.length ? confirmacionOtroKit.alumnos.join(', ') : 'este alumno/a'}
                </h4>
                <p className="mt-1 text-xs text-slate-600">
                  {confirmacionOtroKit.mensaje ? `${confirmacionOtroKit.mensaje} ` : ''}¿Querés comprar otro igual? Si no estás seguro/a, revisá primero el pedido que ya está pago (puede haberlo hecho otro familiar).
                </p>
              </div>
            </div>
            <div className="flex flex-col sm:flex-row gap-2 pt-1">
              <button
                type="button"
                onClick={() => setConfirmacionOtroKit(null)}
                className="flex-1 rounded-xl border-2 border-slate-300 bg-white px-4 py-2.5 text-xs font-bold text-slate-800 hover:bg-slate-50 cursor-pointer"
              >
                No, no comprar
              </button>
              <button
                type="button"
                onClick={() => {
                  setConfirmacionOtroKit(null);
                  void handleCompletarPago({ confirmarOtroKit: true });
                }}
                className="flex-1 rounded-xl bg-amber-400 px-4 py-2.5 text-xs font-extrabold text-slate-950 hover:bg-amber-300 cursor-pointer"
              >
                Sí, comprar otro kit
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
