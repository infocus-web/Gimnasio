import { useCallback, useEffect, useMemo, useState } from 'react';
import { AlertTriangle, BarChart3, CalendarClock, CheckCircle2, ChevronDown, History, Loader2, Mail, MailWarning, Megaphone, MessageSquareText, RefreshCw, Search, Send, Sparkles, Star, Users } from 'lucide-react';
import {
  buscarFamiliaDestino,
  calcularDestinatariosEnvio,
  corregirEmailFamilia,
  crearEnvio,
  enviarTandaEnvio,
  mandarPruebaEnvio,
  obtenerCursosDestino,
  obtenerDestinatariosEnvio,
  obtenerHistorialEnvios,
  obtenerRebotes,
  redactarEnvioConIA,
  vistaPreviaEnvio,
  type ContenidoEnvio,
  type CursoDestino,
  type DestinatarioEnvio,
  type DestinatarioVista,
  type FranjaCita,
  type FranjasCita,
  type CitaFamilia,
  type EnvioHistorial,
  type FiltroDestinatarios,
  type GrupoDestinatarios,
  type Rebote,
  type TipoEnvio,
} from '../services/emailsFamiliasService';
import { obtenerCodigosDescuentoAdmin, type CodigoDescuentoAdmin } from '../services/descuentosService';
import AdminEncuesta from './AdminEncuesta';

/**
 * 26/10/2026: pestaña «Emails» (pedido de Pablo): escribirle a las familias desde un solo lugar. Se elige el tipo
 * (mensaje, citación, promoción, encuesta), a quién (grupos calculados con los datos del sistema y cursos), se escribe
 * —o lo redacta la IA a partir de una idea—, se ve cómo queda, se manda una prueba y recién después se envía.
 * También: historial de envíos (con su estado por familia) y rebotes (mails que no llegan, para corregirlos).
 */
const TIPOS: { id: TipoEnvio; titulo: string; ayuda: string; icono: typeof Mail }[] = [
  { id: 'mensaje', titulo: 'Mensaje', ayuda: 'Aviso o novedad', icono: MessageSquareText },
  { id: 'citacion', titulo: 'Citación', ayuda: 'Día, hora y lugar', icono: CalendarClock },
  { id: 'promocion', titulo: 'Promoción', ayuda: 'Con código de descuento', icono: Megaphone },
  { id: 'encuesta', titulo: 'Encuesta', ayuda: 'De satisfacción', icono: Star },
];
const GRUPOS: { id: GrupoDestinatarios; titulo: string }[] = [
  { id: 'todas', titulo: 'Todas las familias' },
  { id: 'compraron', titulo: 'Compraron' },
  { id: 'no_compraron', titulo: 'No compraron' },
  { id: 'foto_hermanos', titulo: 'Pidieron foto de hermanos' },
  { id: 'faltantes', titulo: 'Fotos faltantes pendientes' },
  { id: 'pagados_sin_fotos', titulo: 'Pagaron y les faltan fotos' }, // 29/10
  { id: 'familia', titulo: 'Una familia' },
];
const NOMBRE_TIPO: Record<TipoEnvio, string> = { mensaje: 'Mensaje', citacion: 'Citación', promocion: 'Promoción', encuesta: 'Encuesta' };
// Franjas de la citación repartida (26/10): el mediodía, para las familias con hijos en ambos turnos.
const FRANJAS_DEFECTO: FranjasCita = { ambos: '12:00 a 13:00 h', manana: '10:30 a 11:30 h', tarde: '13:30 a 14:30 h', completa: '11:30 a 12:00 h' };
const NOMBRE_FRANJA: Record<FranjaCita | 'general', string> = { ambos: 'Hijos en ambos turnos', manana: 'Turno mañana', tarde: 'Turno tarde', completa: 'Sólo jornada completa', general: 'Sin turno cargado' };
const VACIO: ContenidoEnvio = { asunto: '', texto: '', boton: false, dia: '', hora: '', lugar: '', codigo: '', vence: '', reparto: false, dias: [], franjas: FRANJAS_DEFECTO };
const DIA_RE = /^\d{4}-\d{2}-\d{2}$/;
// Textos de Pablo para la citación repartida (26/10): se cargan solos al activar el reparto si el mail está vacío,
// según el grupo (fotos faltantes o foto de hermanos). Si se cambia de grupo sin tocar el texto, cambia con él.
const AVISO_REPARTO = 'Solo si surge un inconveniente de fuerza mayor, avísennos cuanto antes desde el formulario de consultas de la web o escribiendo a contacto@retratoescolar.com.ar.';
const TEXTOS_REPARTO = {
  hermanos: {
    asunto: 'Foto de hermanos: ¡ya tienen su día y horario!',
    texto: [
      '¡Nos alegra contarles que ya está todo listo para la foto de hermanos! En el recuadro de arriba van a encontrar el día y el horario que reservamos especialmente para ustedes.',
      'Organizamos los horarios según el turno de cada alumno, para que nadie tenga que esperar más de lo necesario. Por eso es muy importante que asistan el día y en el horario indicados.',
      AVISO_REPARTO,
      '¡Muchas gracias por su colaboración! ¡Los esperamos con muchas ganas!',
    ].join('\n\n'),
  },
  faltantes: {
    asunto: 'Fotos pendientes: ¡ya tienen su día y horario!',
    texto: [
      '¡Tenemos una buena noticia! Ya está todo listo para sacar las fotos que le faltan a {alumnos}. En el recuadro de arriba van a encontrar el día y el horario que reservamos especialmente para ustedes.',
      'Organizamos esta jornada especialmente para completar las fotos pendientes, con horarios según el turno de cada alumno. Por eso es muy importante que asistan el día y en el horario indicados.',
      AVISO_REPARTO,
      '¡Muchas gracias por su colaboración! ¡Queremos que nadie se quede sin sus fotos!',
    ].join('\n\n'),
  },
};
const textoReparto = (grupo: GrupoDestinatarios) => (grupo === 'faltantes' ? TEXTOS_REPARTO.faltantes : TEXTOS_REPARTO.hermanos);
const esTextoReparto = (asunto: string, texto: string) => Object.values(TEXTOS_REPARTO).some((t) => t.asunto === asunto && t.texto === texto);

function diaCorto(dia: string): string {
  const d = new Date(`${dia}T12:00:00-03:00`);
  return Number.isNaN(d.getTime()) ? dia : d.toLocaleDateString('es-AR', { weekday: 'long', day: 'numeric', month: 'numeric' });
}

/** «miércoles 28/10 · 12:00 a 13:00 h». */
function textoCita(cita: CitaFamilia): string {
  return `${diaCorto(cita.dia)} · ${cita.hora}`;
}

/** Cuántas familias quedaron cada día y en cada franja. */
function ResumenReparto({ lista }: { lista: DestinatarioVista[] }) {
  const dias = [...new Set(lista.map((d) => d.cita?.dia).filter(Boolean) as string[])].sort();
  if (dias.length === 0) return null;
  const franjas = (['ambos', 'manana', 'completa', 'tarde', 'general'] as const).filter((f) => lista.some((d) => d.cita?.franja === f));
  return (
    <div className="overflow-x-auto">
      <table className="w-full text-xs border border-slate-200 rounded-xl overflow-hidden">
        <thead className="bg-slate-50 text-slate-600">
          <tr><th className="text-left px-2 py-1.5 font-bold">Franja</th>{dias.map((d) => <th key={d} className="px-2 py-1.5 font-bold capitalize">{diaCorto(d)}</th>)}</tr>
        </thead>
        <tbody className="divide-y divide-slate-100">
          {franjas.map((f) => (
            <tr key={f}>
              <td className="px-2 py-1.5">{NOMBRE_FRANJA[f]} <span className="text-slate-400">· {lista.find((d) => d.cita?.franja === f)?.cita?.hora}</span></td>
              {dias.map((d) => <td key={d} className="px-2 py-1.5 text-center font-semibold">{lista.filter((x) => x.cita?.dia === d && x.cita?.franja === f).length}</td>)}
            </tr>
          ))}
          <tr className="bg-slate-50 font-bold"><td className="px-2 py-1.5">Total</td>{dias.map((d) => <td key={d} className="px-2 py-1.5 text-center">{lista.filter((x) => x.cita?.dia === d).length}</td>)}</tr>
        </tbody>
      </table>
    </div>
  );
}

function fecha(iso: string | null | undefined): string {
  if (!iso) return '';
  const d = new Date(iso);
  return Number.isNaN(d.getTime()) ? '' : d.toLocaleString('es-AR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' });
}

function Paso({ n, titulo, children }: { n: number; titulo: string; children: React.ReactNode }) {
  return (
    <section className="p-4 rounded-2xl bg-white border border-slate-200 space-y-3">
      <h3 className="text-sm font-extrabold text-slate-900 flex items-center gap-2"><span className="w-6 h-6 rounded-full bg-slate-900 text-white text-xs flex items-center justify-center">{n}</span>{titulo}</h3>
      {children}
    </section>
  );
}

export default function AdminEmailsTab() {
  const [vista, setVista] = useState<'nuevo' | 'enviados' | 'rebotes'>('nuevo');
  const [verEncuesta, setVerEncuesta] = useState(false);
  return (
    <div className="space-y-4 animate-in fade-in duration-200 text-slate-900">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap gap-1 bg-slate-100 rounded-xl p-1">
          {([['nuevo', 'Nuevo email', Mail], ['enviados', 'Enviados', History], ['rebotes', 'No llegan', MailWarning]] as const).map(([id, texto, Icono]) => (
            <button key={id} type="button" onClick={() => setVista(id)} aria-pressed={vista === id} className={`px-3 py-1.5 rounded-lg text-xs font-bold inline-flex items-center gap-1.5 cursor-pointer ${vista === id ? 'bg-white text-slate-900 shadow-2xs' : 'text-slate-500 hover:text-slate-800'}`}>
              <Icono className="w-3.5 h-3.5" />{texto}
            </button>
          ))}
        </div>
        <button type="button" onClick={() => setVerEncuesta(true)} className="px-3 py-2 rounded-xl border border-slate-300 bg-white text-xs font-bold text-slate-700 hover:bg-slate-50 inline-flex items-center gap-1.5 cursor-pointer"><BarChart3 className="w-4 h-4 text-amber-500" />Resultados de la encuesta</button>
      </div>
      {vista === 'nuevo' && <NuevoEmail onEnviado={() => setVista('enviados')} />}
      {vista === 'enviados' && <Enviados />}
      {vista === 'rebotes' && <Rebotes />}
      {verEncuesta && <AdminEncuesta onCerrar={() => setVerEncuesta(false)} />}
    </div>
  );
}

function NuevoEmail({ onEnviado }: { onEnviado: () => void }) {
  const [tipo, setTipo] = useState<TipoEnvio>('mensaje');
  const [filtro, setFiltro] = useState<FiltroDestinatarios>({ grupo: 'todas', cursos: [], email: '' });
  const [c, setC] = useState<ContenidoEnvio>(VACIO);
  const poner = <K extends keyof ContenidoEnvio>(k: K, v: ContenidoEnvio[K]) => setC((prev) => ({ ...prev, [k]: v }));
  const [cursos, setCursos] = useState<CursoDestino[]>([]);
  const [verCursos, setVerCursos] = useState(false);
  const [busqueda, setBusqueda] = useState('');
  const [encontradas, setEncontradas] = useState<{ email: string; tutor: string; alumnos: string[] }[]>([]);
  const [destinatarios, setDestinatarios] = useState<{ total: number; lista: DestinatarioVista[] } | null>(null);
  const [verLista, setVerLista] = useState(false);
  const [calculando, setCalculando] = useState(false);
  const [codigos, setCodigos] = useState<CodigoDescuentoAdmin[]>([]);
  const [idea, setIdea] = useState('');
  const [redactando, setRedactando] = useState(false);
  const [html, setHtml] = useState('');
  const [emailPrueba, setEmailPrueba] = useState('');
  const [ocupado, setOcupado] = useState(false);
  const [progreso, setProgreso] = useState('');
  const [aviso, setAviso] = useState<{ ok: boolean; texto: string } | null>(null);

  useEffect(() => {
    void obtenerCursosDestino().then(setCursos).catch(() => undefined);
    void obtenerCodigosDescuentoAdmin().then((r) => setCodigos((r.codigos || []).filter((x) => x.activo))).catch(() => undefined);
  }, []);

  // Si cambia el grupo y el texto es uno de los de por defecto (sin tocar), se pone el que corresponde al grupo nuevo.
  useEffect(() => {
    setC((prev) => (prev.reparto && esTextoReparto(prev.asunto, prev.texto) ? { ...prev, ...textoReparto(filtro.grupo) } : prev));
  }, [filtro.grupo]);

  // Reparto de la citación en varios días (sólo si está activado y hay algún día válido).
  const clavesReparto = tipo === 'citacion' && c.reparto && c.dias.some((d) => DIA_RE.test(d)) ? JSON.stringify({ dias: c.dias.filter((d) => DIA_RE.test(d)), franjas: c.franjas, hora: c.hora }) : '';

  // Cuántas familias reciben el mail (se recalcula al cambiar el grupo, los cursos o el reparto).
  useEffect(() => {
    if (filtro.grupo === 'familia' && !filtro.email) { setDestinatarios(null); return; }
    let vigente = true;
    setCalculando(true);
    const t = setTimeout(() => {
      calcularDestinatariosEnvio(filtro, clavesReparto ? JSON.parse(clavesReparto) : undefined)
        .then((r) => { if (vigente) setDestinatarios({ total: r.total, lista: r.destinatarios }); })
        .catch((err) => { if (vigente) setAviso({ ok: false, texto: err.message }); })
        .finally(() => { if (vigente) setCalculando(false); });
    }, 300);
    return () => { vigente = false; clearTimeout(t); };
  }, [filtro, clavesReparto]);

  // Búsqueda de una familia.
  useEffect(() => {
    if (filtro.grupo !== 'familia' || busqueda.trim().length < 2) { setEncontradas([]); return; }
    const t = setTimeout(() => { void buscarFamiliaDestino(busqueda.trim()).then(setEncontradas).catch(() => setEncontradas([])); }, 300);
    return () => clearTimeout(t);
  }, [busqueda, filtro.grupo]);

  // Vista previa del mail tal como le llega a una familia de ejemplo.
  useEffect(() => {
    const t = setTimeout(() => { void vistaPreviaEnvio(tipo, c).then((r) => setHtml(r.html)).catch(() => undefined); }, 400);
    return () => clearTimeout(t);
  }, [tipo, c]);

  const redactar = async () => {
    setRedactando(true); setAviso(null);
    try {
      const r = await redactarEnvioConIA(tipo, filtro.grupo, idea, tipo === 'citacion' && c.reparto);
      setC((prev) => ({ ...prev, asunto: r.asunto || prev.asunto, texto: r.texto || prev.texto }));
    } catch (err: any) {
      setAviso({ ok: false, texto: err.message });
    } finally {
      setRedactando(false);
    }
  };

  const prueba = async () => {
    setOcupado(true); setAviso(null);
    try {
      await mandarPruebaEnvio(tipo, c, emailPrueba.trim());
      setAviso({ ok: true, texto: `Prueba enviada a ${emailPrueba.trim()} (con «[PRUEBA]» en el asunto).` });
    } catch (err: any) {
      setAviso({ ok: false, texto: err.message });
    } finally {
      setOcupado(false);
    }
  };

  const enviar = async () => {
    const total = destinatarios?.total || 0;
    if (!total) return;
    if (!window.confirm(`¿Mandar «${tipo === 'encuesta' ? 'Encuesta de satisfacción' : c.asunto}» a ${total} ${total === 1 ? 'familia' : 'familias'}?\n\nNo se puede deshacer.`)) return;
    setOcupado(true); setAviso(null);
    let enviados = 0;
    let fallidos = 0;
    try {
      const { id } = await crearEnvio(tipo, c, filtro);
      for (let vuelta = 0; vuelta < 40; vuelta += 1) {
        const r = await enviarTandaEnvio(id);
        enviados += r.enviados; fallidos += r.fallidos;
        setProgreso(`Enviados ${enviados} de ${total}…`);
        if (r.pendientes === 0 || (r.enviados === 0 && r.fallidos === 0)) {
          if (r.pendientes > 0) setAviso({ ok: false, texto: `Se cortó con ${r.pendientes} pendientes. Seguí desde «Enviados» → «Continuar envío».` });
          break;
        }
      }
      setAviso((prev) => prev || { ok: true, texto: `Listo: se mandó a ${enviados} ${enviados === 1 ? 'familia' : 'familias'}.${fallidos ? ` ${fallidos} no salieron (revisalas en «Enviados»).` : ''}` });
      setC(VACIO); setIdea('');
      setTimeout(onEnviado, 1500);
    } catch (err: any) {
      setAviso({ ok: false, texto: `${err.message}${enviados ? ` Se mandaron ${enviados}; seguí desde «Enviados».` : ''}` });
    } finally {
      setOcupado(false); setProgreso('');
    }
  };

  const listo = (destinatarios?.total || 0) > 0 && (tipo === 'encuesta' || (c.asunto.trim().length >= 3 && c.texto.trim().length >= 5 && (tipo !== 'citacion' || ((c.reparto ? c.dias.some((d) => DIA_RE.test(d)) : c.dia) && c.hora && c.lugar))));
  const cursosElegidos = useMemo(() => cursos.filter((x) => filtro.cursos.includes(x.codigo)), [cursos, filtro.cursos]);

  return (
    <div className="grid lg:grid-cols-[minmax(0,1fr)_minmax(0,460px)] gap-4 items-start">
      <div className="space-y-4">
        <Paso n={1} titulo="¿Qué querés mandar?">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            {TIPOS.map(({ id, titulo, ayuda, icono: Icono }) => (
              <button key={id} type="button" onClick={() => setTipo(id)} aria-pressed={tipo === id} className={`p-3 rounded-xl border text-left cursor-pointer ${tipo === id ? 'border-amber-500 bg-amber-50 ring-2 ring-amber-200' : 'border-slate-200 hover:border-slate-400'}`}>
                <Icono className={`w-5 h-5 ${tipo === id ? 'text-amber-600' : 'text-slate-400'}`} />
                <p className="text-sm font-bold mt-1">{titulo}</p>
                <p className="text-[11px] text-slate-500">{ayuda}</p>
              </button>
            ))}
          </div>
        </Paso>

        <Paso n={2} titulo="¿A quién?">
          <div className="flex flex-wrap gap-1.5">
            {GRUPOS.map((g) => (
              <button key={g.id} type="button" onClick={() => setFiltro((f) => ({ ...f, grupo: g.id, email: g.id === 'familia' ? f.email : '' }))} aria-pressed={filtro.grupo === g.id} className={`px-3 py-1.5 rounded-full border text-xs font-bold cursor-pointer ${filtro.grupo === g.id ? 'bg-slate-900 border-slate-900 text-white' : 'bg-white border-slate-300 text-slate-700 hover:bg-slate-50'}`}>{g.titulo}</button>
            ))}
          </div>
          {filtro.grupo === 'familia' && (
            <div className="space-y-1.5">
              <label className="relative block">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-slate-400" />
                <input value={busqueda} onChange={(e) => setBusqueda(e.target.value)} placeholder="Buscá por tutor, chico o email" className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-300 text-sm" />
              </label>
              {filtro.email && <p className="text-xs">Elegida: <strong>{filtro.email}</strong></p>}
              {encontradas.length > 0 && (
                <ul className="max-h-48 overflow-y-auto divide-y divide-slate-100 rounded-xl border border-slate-200">
                  {encontradas.map((f) => (
                    <li key={f.email}><button type="button" onClick={() => { setFiltro((x) => ({ ...x, email: f.email })); setEncontradas([]); setBusqueda(''); }} className="w-full text-left px-3 py-2 text-xs hover:bg-slate-50 cursor-pointer"><strong>{f.tutor}</strong> · {f.email}<br /><span className="text-slate-500">{f.alumnos.join(' · ')}</span></button></li>
                  ))}
                </ul>
              )}
            </div>
          )}
          {filtro.grupo !== 'familia' && (
            <div>
              <button type="button" onClick={() => setVerCursos((v) => !v)} className="text-xs font-bold text-sky-700 inline-flex items-center gap-1 cursor-pointer">
                {filtro.cursos.length ? `Sólo ${filtro.cursos.length} ${filtro.cursos.length === 1 ? 'curso' : 'cursos'}: ${cursosElegidos.map((x) => x.etiqueta).join(', ')}` : 'Todos los cursos (tocá para elegir algunos)'}
                <ChevronDown className={`w-3.5 h-3.5 transition-transform ${verCursos ? 'rotate-180' : ''}`} />
              </button>
              {verCursos && (
                <div className="mt-2 flex flex-wrap gap-1.5 max-h-56 overflow-y-auto p-2 rounded-xl bg-slate-50 border border-slate-200">
                  {filtro.cursos.length > 0 && <button type="button" onClick={() => setFiltro((f) => ({ ...f, cursos: [] }))} className="px-2.5 py-1 rounded-lg text-[11px] font-bold text-rose-700 border border-rose-200 bg-white cursor-pointer">Quitar todos</button>}
                  {cursos.map((x) => {
                    const activo = filtro.cursos.includes(x.codigo);
                    return (
                      <button key={x.codigo} type="button" aria-pressed={activo} onClick={() => setFiltro((f) => ({ ...f, cursos: activo ? f.cursos.filter((k) => k !== x.codigo) : [...f.cursos, x.codigo] }))} className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold border cursor-pointer ${activo ? 'bg-amber-400 border-amber-400 text-slate-950' : 'bg-white border-slate-300 text-slate-700 hover:bg-slate-100'}`}>
                        {x.etiqueta} <span className="opacity-60">({x.familias})</span>
                      </button>
                    );
                  })}
                </div>
              )}
            </div>
          )}
          <div className="flex items-center gap-2 text-sm">
            <Users className="w-4 h-4 text-slate-500" />
            {calculando ? <span className="text-slate-500">Calculando…</span> : destinatarios ? <span>Le llega a <strong>{destinatarios.total}</strong> {destinatarios.total === 1 ? 'familia' : 'familias'}</span> : <span className="text-slate-500">Elegí la familia.</span>}
            {destinatarios && destinatarios.total > 0 && <button type="button" onClick={() => setVerLista((v) => !v)} className="text-xs font-bold text-sky-700 cursor-pointer">{verLista ? 'Ocultar lista' : 'Ver lista'}</button>}
          </div>
          {verLista && destinatarios && (
            <ul className="max-h-56 overflow-y-auto text-xs divide-y divide-slate-100 rounded-xl border border-slate-200">
              {destinatarios.lista.map((d) => <li key={d.email} className="px-3 py-1.5"><strong>{d.tutor || d.email}</strong> · {d.email} · <span className="text-slate-500">{d.alumnos.join(', ')}</span>{d.cita && <> · <strong className="text-amber-700 capitalize">{textoCita(d.cita)}</strong></>}</li>)}
            </ul>
          )}
        </Paso>

        <Paso n={3} titulo="El mail">
          {tipo === 'encuesta' ? (
            <p className="text-sm text-slate-600">Es el mail de la encuesta de satisfacción (disculpas, compromiso con las fotos que faltan y el botón con el link personal de cada familia). Mirá cómo queda a la derecha. Las respuestas se ven en «Resultados de la encuesta».</p>
          ) : (
            <>
              <div className="p-3 rounded-xl bg-violet-50 border border-violet-200 space-y-2">
                <label htmlFor="idea-email" className="text-xs font-bold text-violet-900 inline-flex items-center gap-1.5"><Sparkles className="w-3.5 h-3.5" />Contale a la IA qué querés decir y lo redacta</label>
                <textarea id="idea-email" value={idea} onChange={(e) => setIdea(e.target.value)} rows={2} maxLength={1500} placeholder={tipo === 'citacion' ? 'Ej.: los que pidieron foto de hermanos, que vengan con los dos chicos, con uniforme' : tipo === 'promocion' ? 'Ej.: 15% de descuento en el kit para los que todavía no compraron, hasta el domingo' : 'Ej.: ya están todas las fotos online, tienen tiempo de elegir hasta el 15/11'} className="w-full rounded-lg border border-violet-200 bg-white p-2 text-sm" />
                <button type="button" disabled={redactando || idea.trim().length < 5} onClick={() => void redactar()} className="px-3 py-1.5 rounded-lg bg-violet-600 hover:bg-violet-500 text-white text-xs font-bold inline-flex items-center gap-1.5 disabled:opacity-50 cursor-pointer">
                  {redactando ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Sparkles className="w-3.5 h-3.5" />}{redactando ? 'Escribiendo…' : 'Redactar con IA'}
                </button>
              </div>
              {tipo === 'citacion' && (
                <div className="space-y-2">
                  <label className="flex items-start gap-2 text-sm cursor-pointer">
                    <input type="checkbox" checked={c.reparto} onChange={(e) => setC((prev) => ({ ...prev, reparto: e.target.checked, dias: e.target.checked && prev.dias.length === 0 ? [prev.dia, '', '', '', ''] : prev.dias, hora: e.target.checked && !prev.hora ? '10:30 a 14:30 h' : prev.hora, asunto: e.target.checked && !prev.asunto.trim() ? textoReparto(filtro.grupo).asunto : prev.asunto, texto: e.target.checked && !prev.texto.trim() ? textoReparto(filtro.grupo).texto : prev.texto }))} className="w-4 h-4 mt-0.5 accent-amber-500" />
                    <span><strong>Repartir en varios días, con horario según el turno</strong><br /><span className="text-xs text-slate-500">A cada familia le llega su día y su franja. Se reparten parejo entre los días; el mediodía queda para las que tienen hijos en ambos turnos.</span></span>
                  </label>
                  {c.reparto ? (
                    <div className="p-3 rounded-xl bg-amber-50 border border-amber-200 space-y-3">
                      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-2">
                        {[0, 1, 2, 3, 4].map((i) => (
                          <label key={i} className="text-xs font-bold">Día {i + 1}{i > 0 && <span className="font-normal text-slate-500"> (opcional)</span>}
                            <input type="date" value={c.dias[i] || ''} onChange={(e) => setC((prev) => { const dias = [...prev.dias]; dias[i] = e.target.value; return { ...prev, dias }; })} className="mt-1 w-full px-2 py-2 rounded-lg border border-slate-300 text-sm font-normal bg-white" />
                          </label>
                        ))}
                      </div>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                        {(['ambos', 'manana', 'completa', 'tarde'] as FranjaCita[]).map((f) => (
                          <label key={f} className="text-xs font-bold">{NOMBRE_FRANJA[f]}{f === 'ambos' && <span className="font-normal text-slate-500"> (mediodía)</span>}
                            <input value={c.franjas[f]} onChange={(e) => setC((prev) => ({ ...prev, franjas: { ...prev.franjas, [f]: e.target.value } }))} className="mt-1 w-full px-2 py-2 rounded-lg border border-slate-300 text-sm font-normal bg-white" />
                          </label>
                        ))}
                        <label className="text-xs font-bold">Hora general <span className="font-normal text-slate-500">(familias sin turno cargado)</span>
                          <input value={c.hora} onChange={(e) => poner('hora', e.target.value)} className="mt-1 w-full px-2 py-2 rounded-lg border border-slate-300 text-sm font-normal bg-white" />
                        </label>
                        <label className="text-xs font-bold">Lugar<input value={c.lugar} onChange={(e) => poner('lugar', e.target.value)} placeholder="Salón de actos del colegio" className="mt-1 w-full px-2 py-2 rounded-lg border border-slate-300 text-sm font-normal bg-white" /></label>
                      </div>
                      <p className="text-[11px] text-slate-600">«Turno mañana» incluye a los que tienen un hijo a la mañana y otro en jornada completa; «Turno tarde», lo mismo con la tarde.</p>
                      {calculando ? <p className="text-xs text-slate-500">Repartiendo…</p> : destinatarios && <ResumenReparto lista={destinatarios.lista} />}
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                      <label className="text-xs font-bold">Día<input type="date" value={c.dia} onChange={(e) => poner('dia', e.target.value)} className="mt-1 w-full px-2 py-2 rounded-lg border border-slate-300 text-sm font-normal" /></label>
                      <label className="text-xs font-bold">Hora<input value={c.hora} onChange={(e) => poner('hora', e.target.value)} placeholder="10 a 12 hs" className="mt-1 w-full px-2 py-2 rounded-lg border border-slate-300 text-sm font-normal" /></label>
                      <label className="text-xs font-bold">Lugar<input value={c.lugar} onChange={(e) => poner('lugar', e.target.value)} placeholder="Salón de actos del colegio" className="mt-1 w-full px-2 py-2 rounded-lg border border-slate-300 text-sm font-normal" /></label>
                    </div>
                  )}
                </div>
              )}
              {tipo === 'promocion' && (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  <label className="text-xs font-bold">Código de descuento (opcional)
                    <select value={c.codigo} onChange={(e) => poner('codigo', e.target.value)} className="mt-1 w-full px-2 py-2 rounded-lg border border-slate-300 text-sm font-normal bg-white">
                      <option value="">Sin código</option>
                      {codigos.map((x) => <option key={x.id} value={x.codigo}>{x.codigo} · {x.porcentaje}%{x.nota ? ` · ${x.nota}` : ''}</option>)}
                    </select>
                  </label>
                  <label className="text-xs font-bold">Válido hasta (opcional)<input type="date" value={c.vence} onChange={(e) => poner('vence', e.target.value)} className="mt-1 w-full px-2 py-2 rounded-lg border border-slate-300 text-sm font-normal" /></label>
                </div>
              )}
              <label className="block text-xs font-bold">Asunto<input value={c.asunto} onChange={(e) => poner('asunto', e.target.value)} maxLength={150} className="mt-1 w-full px-3 py-2 rounded-lg border border-slate-300 text-sm font-normal" /></label>
              <label className="block text-xs font-bold">Texto
                <textarea value={c.texto} onChange={(e) => poner('texto', e.target.value)} rows={8} maxLength={5000} className="mt-1 w-full p-3 rounded-lg border border-slate-300 text-sm font-normal leading-relaxed" />
              </label>
              <p className="text-[11px] text-slate-500">El «Hola …» y la firma se agregan solos. Podés escribir <code className="bg-slate-100 px-1 rounded">{'{nombre}'}</code> (nombre del tutor) y <code className="bg-slate-100 px-1 rounded">{'{alumnos}'}</code> (nombres de los chicos). Dejá una línea en blanco entre párrafos.</p>
              {tipo === 'mensaje' && (
                <label className="flex items-center gap-2 text-sm cursor-pointer"><input type="checkbox" checked={c.boton} onChange={(e) => poner('boton', e.target.checked)} className="w-4 h-4 accent-amber-500" />Agregar el botón «Ver mis fotos»</label>
              )}
            </>
          )}
        </Paso>

        <Paso n={4} titulo="Probar y enviar">
          <div className="flex flex-col sm:flex-row gap-2">
            <input type="email" value={emailPrueba} onChange={(e) => setEmailPrueba(e.target.value)} placeholder="Tu email para la prueba" className="flex-1 px-3 py-2 rounded-xl border border-slate-300 text-sm" />
            <button type="button" disabled={ocupado || !emailPrueba.includes('@') || (!listo && tipo !== 'encuesta')} onClick={() => void prueba()} className="px-4 py-2 rounded-xl border border-slate-300 bg-white text-sm font-bold text-slate-700 hover:bg-slate-50 disabled:opacity-50 cursor-pointer">Mandarme una prueba</button>
          </div>
          <button type="button" disabled={ocupado || !listo} onClick={() => void enviar()} className="w-full py-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-sm font-extrabold inline-flex items-center justify-center gap-2 disabled:opacity-50 cursor-pointer">
            {ocupado && progreso ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
            {progreso || (destinatarios?.total ? `Enviar a ${destinatarios.total} ${destinatarios.total === 1 ? 'familia' : 'familias'}` : 'Enviar')}
          </button>
          {aviso && <p role={aviso.ok ? 'status' : 'alert'} className={`p-3 rounded-xl text-sm ${aviso.ok ? 'bg-emerald-50 border border-emerald-200 text-emerald-800' : 'bg-rose-50 border border-rose-200 text-rose-800'}`}>{aviso.texto}</p>}
        </Paso>
      </div>

      <aside className="lg:sticky lg:top-4 space-y-2">
        <p className="text-xs font-bold text-slate-500 uppercase tracking-wide">Así le llega (ejemplo{tipo === 'citacion' && c.reparto ? ': familia con hijos en ambos turnos' : ''})</p>
        <iframe title="Vista previa del mail" srcDoc={html} sandbox="" className="w-full h-[640px] rounded-2xl border border-slate-200 bg-white" />
      </aside>
    </div>
  );
}

function Enviados() {
  const [envios, setEnvios] = useState<EnvioHistorial[] | null>(null);
  const [error, setError] = useState('');
  const [abierto, setAbierto] = useState<string | null>(null);
  const [detalle, setDetalle] = useState<DestinatarioEnvio[] | null>(null);
  const [continuando, setContinuando] = useState<string | null>(null);

  const cargar = useCallback(async () => {
    try { setEnvios(await obtenerHistorialEnvios()); setError(''); } catch (err: any) { setError(err.message); }
  }, []);
  useEffect(() => { void cargar(); }, [cargar]);

  const abrir = async (id: string) => {
    if (abierto === id) { setAbierto(null); return; }
    setAbierto(id); setDetalle(null);
    try { setDetalle(await obtenerDestinatariosEnvio(id)); } catch (err: any) { setError(err.message); }
  };

  const continuar = async (id: string) => {
    setContinuando(id);
    try {
      for (let i = 0; i < 40; i += 1) {
        const r = await enviarTandaEnvio(id);
        if (r.pendientes === 0 || (r.enviados === 0 && r.fallidos === 0)) break;
      }
    } catch (err: any) {
      setError(err.message);
    } finally {
      setContinuando(null);
      void cargar();
    }
  };

  if (!envios && !error) return <div className="py-12 text-center text-slate-400"><Loader2 className="w-6 h-6 animate-spin mx-auto" /></div>;
  return (
    <div className="space-y-2">
      <div className="flex justify-end"><button type="button" onClick={() => void cargar()} className="p-2 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 cursor-pointer" title="Actualizar"><RefreshCw className="w-4 h-4 text-slate-600" /></button></div>
      {error && <p role="alert" className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-sm">{error}</p>}
      {envios && envios.length === 0 && <p className="py-12 text-center text-sm text-slate-500 border border-dashed border-slate-300 rounded-2xl">Todavía no se mandó ningún email desde acá.</p>}
      {envios?.map((e) => {
        const n = (k: string) => e.estados[k] || 0;
        return (
          <article key={e.id} className="bg-white border border-slate-200 rounded-2xl overflow-hidden">
            <button type="button" onClick={() => void abrir(e.id)} aria-expanded={abierto === e.id} className="w-full text-left px-4 py-3 flex flex-wrap items-center gap-x-3 gap-y-1 hover:bg-slate-50 cursor-pointer">
              <span className="px-2 py-0.5 rounded-full bg-slate-100 text-[10px] font-bold text-slate-700">{NOMBRE_TIPO[e.tipo]}</span>
              <span className="text-sm font-bold flex-1 min-w-0 truncate">{e.asunto}</span>
              <span className="text-[11px] text-slate-400">{fecha(e.creado_at)}</span>
              <span className="w-full text-xs text-slate-500">{e.descripcion_destinatarios} · <strong className="text-emerald-700">{n('enviado')} enviados</strong>{n('rebotado') ? <> · <strong className="text-rose-700">{n('rebotado')} rebotaron</strong></> : null}{n('fallido') ? <> · <strong className="text-rose-700">{n('fallido')} fallaron</strong></> : null}{n('pendiente') ? <> · <strong className="text-amber-700">{n('pendiente')} pendientes</strong></> : null} · de {e.total}</span>
            </button>
            {n('pendiente') > 0 && (
              <div className="px-4 pb-3">
                <button type="button" disabled={continuando === e.id} onClick={() => void continuar(e.id)} className="px-3 py-1.5 rounded-lg bg-amber-400 hover:bg-amber-300 text-xs font-bold text-slate-950 inline-flex items-center gap-1.5 disabled:opacity-50 cursor-pointer">
                  {continuando === e.id ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Send className="w-3.5 h-3.5" />}Continuar envío ({n('pendiente')})
                </button>
              </div>
            )}
            {abierto === e.id && (
              <div className="border-t border-slate-100 max-h-80 overflow-y-auto">
                {!detalle ? <p className="p-3 text-xs text-slate-500">Cargando…</p> : (
                  <ul className="divide-y divide-slate-100 text-xs">
                    {detalle.map((d) => (
                      <li key={d.email} className="px-4 py-1.5 flex flex-wrap gap-x-3">
                        <span className={`font-bold ${d.estado === 'enviado' ? 'text-emerald-700' : d.estado === 'pendiente' ? 'text-amber-700' : 'text-rose-700'}`}>{d.estado === 'enviado' ? 'Enviado' : d.estado === 'pendiente' ? 'Pendiente' : d.estado === 'rebotado' ? 'Rebotó' : 'Falló'}</span>
                        <span>{d.tutor || ''} · {d.email}</span>
                        <span className="text-slate-500">{d.alumnos}</span>
                        {d.cita && <strong className="text-amber-700 capitalize">{textoCita(d.cita)}</strong>}
                        {d.error && <span className="text-rose-700">{d.error}</span>}
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            )}
          </article>
        );
      })}
    </div>
  );
}

function Rebotes() {
  const [rebotes, setRebotes] = useState<Rebote[] | null>(null);
  const [error, setError] = useState('');
  const [nuevos, setNuevos] = useState<Record<string, string>>({});
  const [guardando, setGuardando] = useState<string | null>(null);
  const [aviso, setAviso] = useState('');

  const cargar = useCallback(async () => {
    try { setRebotes(await obtenerRebotes()); setError(''); } catch (err: any) { setError(err.message); }
  }, []);
  useEffect(() => { void cargar(); }, [cargar]);

  const corregir = async (viejo: string) => {
    const nuevo = (nuevos[viejo] || '').trim();
    if (!window.confirm(`¿Cambiar ${viejo} por ${nuevo} en la inscripción de la familia?\n\nLos próximos mails van a salir al nuevo. Lo que ya se mandó no se reenvía solo.`)) return;
    setGuardando(viejo); setAviso('');
    try {
      const r = await corregirEmailFamilia(viejo, nuevo);
      setAviso(`Corregido: ${viejo} → ${nuevo} (${r.inscripciones} ${r.inscripciones === 1 ? 'inscripción' : 'inscripciones'}). Si le faltaba el código o las fotos, reenviáselos desde Inscriptos o Laboratorio.`);
      void cargar();
    } catch (err: any) {
      setError(err.message);
    } finally {
      setGuardando(null);
    }
  };

  if (!rebotes && !error) return <div className="py-12 text-center text-slate-400"><Loader2 className="w-6 h-6 animate-spin mx-auto" /></div>;
  return (
    <div className="space-y-2">
      <p className="text-xs text-slate-600 flex items-start gap-1.5"><AlertTriangle className="w-4 h-4 text-amber-500 shrink-0" />Familias a las que un mail no les llegó (la casilla no existe o lo rechazó). Corregí el email si ves el error, o escribiles por WhatsApp. Los rebotes se registran desde el 25/10.</p>
      {aviso && <p role="status" className="p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-sm flex items-center gap-1.5"><CheckCircle2 className="w-4 h-4" />{aviso}</p>}
      {error && <p role="alert" className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-sm">{error}</p>}
      {rebotes && rebotes.length === 0 && <p className="py-12 text-center text-sm text-slate-500 border border-dashed border-slate-300 rounded-2xl">No hay mails rebotados.</p>}
      {rebotes?.map((r) => {
        const wa = r.whatsapp.replace(/\D/g, '');
        return (
          <article key={r.email} className={`p-3 rounded-2xl border ${r.corregido ? 'bg-slate-50 border-slate-200 opacity-70' : 'bg-white border-rose-200'}`}>
            <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-sm">
              <strong className="text-rose-800 break-all">{r.email}</strong>
              {r.tutor && <span>{r.tutor}</span>}
              <span className="text-[11px] text-slate-400">{fecha(r.fecha)}</span>
              {r.corregido && <span className="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[10px] font-bold">Ya no figura en ninguna inscripción</span>}
            </div>
            {r.alumnos.length > 0 && <p className="text-xs text-slate-500 mt-0.5">{r.alumnos.join(' · ')}</p>}
            {(r.asunto || r.motivo) && <p className="text-xs text-slate-600 mt-0.5">{r.asunto ? `«${r.asunto}» ` : ''}{r.motivo}</p>}
            {!r.corregido && (
              <div className="mt-2 flex flex-col sm:flex-row gap-2">
                <input type="email" value={nuevos[r.email] ?? r.email} onChange={(e) => setNuevos((n) => ({ ...n, [r.email]: e.target.value }))} aria-label={`Email corregido para ${r.email}`} className="flex-1 px-3 py-1.5 rounded-lg border border-slate-300 text-sm" />
                <button type="button" disabled={guardando === r.email || !(nuevos[r.email] || '').includes('@') || (nuevos[r.email] || '').trim().toLowerCase() === r.email} onClick={() => void corregir(r.email)} className="px-3 py-1.5 rounded-lg bg-slate-900 text-white text-xs font-bold disabled:opacity-40 cursor-pointer">Corregir email</button>
                {wa && <a href={`https://wa.me/${wa.startsWith('54') ? wa : `549${wa}`}`} target="_blank" rel="noopener noreferrer" className="px-3 py-1.5 rounded-lg bg-emerald-600 text-white text-xs font-bold text-center">WhatsApp {r.whatsapp}</a>}
              </div>
            )}
          </article>
        );
      })}
    </div>
  );
}
