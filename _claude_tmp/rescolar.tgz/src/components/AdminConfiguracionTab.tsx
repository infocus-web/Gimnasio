import { useEffect, useState } from 'react';
import { AlertTriangle, CalendarClock, Loader2, RefreshCw, Save, Settings } from 'lucide-react';
import { guardarPlazosAdmin } from '../services/plazosService';
import {
  cargarPlazos,
  fechaValida,
  finDelDia,
  PLAZOS_POR_DEFECTO,
  plazosVienenDelServidor,
  textoFechaLarga,
  usePlazosTemporada,
  type PlazosTemporada,
} from '../utils/plazosTemporada';

const CAMPOS: { clave: keyof PlazosTemporada; nombre: string; controla: string[] }[] = [
  {
    clave: 'kitImpreso',
    nombre: 'Kit Impreso y fotos extra',
    controla: [
      'Comprar el Kit Impreso o confirmar las fotos de uno pagado por adelantado.',
      'Pasar de Solo Digital a Kit Impreso.',
      'Pedir fotos extra (copias impresas sueltas).',
      'El Solo Digital no tiene límite: se sigue vendiendo después.',
    ],
  },
  {
    clave: 'faltantes',
    nombre: 'Pedido de fotos faltantes',
    controla: [
      'Botón «Mi hijo/a no tiene esta foto» → pedir que se la saquen.',
      'Pasada la fecha, la familia sólo puede reemplazarla por otra foto del curso.',
    ],
  },
];

const DIA_MS = 24 * 60 * 60 * 1000;
const fechaLegible = (f: string) => `${f.slice(8, 10)}/${f.slice(5, 7)}/${f.slice(0, 4)}`;

function estadoDe(fecha: string): { abierto: boolean; texto: string } {
  const resta = finDelDia(fecha) - Date.now();
  if (resta < 0) return { abierto: false, texto: `Cerrado desde el ${textoFechaLarga(fecha)}` };
  const dias = Math.ceil(resta / DIA_MS);
  return { abierto: true, texto: dias <= 1 ? 'Abierto: cierra hoy a las 23:59' : `Abierto: quedan ${dias} días` };
}

/**
 * Panel → Configuración (30/10/2026, pedido de Pablo). Por ahora, las fechas límite de la temporada: antes
 * estaban fijas en el código. Lo que se guarda acá lo usan la web de las familias, el servidor (que es el que
 * frena de verdad), los mails y las respuestas de la IA. Servidor: servidor/panel/configuracion.ts.
 */
export default function AdminConfiguracionTab() {
  const plazos = usePlazosTemporada();
  const [valores, setValores] = useState<PlazosTemporada>(() => ({ ...plazos }));
  const [estadoCarga, setEstadoCarga] = useState<'cargando' | 'ok' | 'error'>(() => (plazosVienenDelServidor() ? 'ok' : 'cargando'));
  const [guardando, setGuardando] = useState(false);
  const [mensaje, setMensaje] = useState<{ ok: boolean; texto: string } | null>(null);

  const cargar = async () => {
    setEstadoCarga('cargando');
    const ok = (await cargarPlazos({ forzar: true })) || plazosVienenDelServidor();
    setEstadoCarga(ok ? 'ok' : 'error');
  };

  useEffect(() => {
    void cargar();
  }, []);

  // Cuando llegan las del servidor (o se guardan), el formulario muestra las vigentes.
  useEffect(() => {
    setValores({ ...plazos });
  }, [plazos.kitImpreso, plazos.faltantes]);

  const cambiado = valores.kitImpreso !== plazos.kitImpreso || valores.faltantes !== plazos.faltantes;
  const invalidos = CAMPOS.filter((c) => !fechaValida(valores[c.clave]));

  const guardar = async () => {
    setMensaje(null);
    if (estadoCarga !== 'ok') {
      setMensaje({ ok: false, texto: 'No se pudieron leer las fechas del servidor: no se puede guardar. Tocá «Reintentar».' });
      return;
    }
    if (invalidos.length > 0) {
      setMensaje({ ok: false, texto: 'Completá las dos fechas con un día válido.' });
      return;
    }
    const yaCerradas = CAMPOS.filter((c) => valores[c.clave] !== plazos[c.clave] && finDelDia(valores[c.clave]) < Date.now());
    if (
      yaCerradas.length > 0 &&
      !window.confirm(`Ojo: ${yaCerradas.map((c) => `«${c.nombre}»`).join(' y ')} queda con una fecha que ya pasó, así que se CIERRA ahora mismo para las familias.\n\n¿Guardar igual?`)
    ) {
      return;
    }
    setGuardando(true);
    const r = await guardarPlazosAdmin(valores);
    setGuardando(false);
    setMensaje(
      r.success
        ? { ok: true, texto: 'Fechas guardadas. La web, el cobro, los mails y la IA ya usan las nuevas (en menos de un minuto en todos lados).' }
        : { ok: false, texto: r.error || 'No se pudieron guardar.' }
    );
  };

  return (
    <div className="max-w-2xl space-y-4 text-left">
      <div>
        <h3 className="flex items-center gap-2 text-lg font-extrabold text-slate-900 font-['Outfit']">
          <Settings className="h-5 w-5 text-amber-500" aria-hidden="true" /> Configuración
        </h3>
        <p className="text-xs text-slate-500">
          Ajustes de la temporada que antes había que cambiar en el código. Cierran al final del día elegido (23:59, hora de Argentina).
        </p>
      </div>

      <section aria-labelledby="titulo-fechas-limite" className="space-y-3 rounded-2xl border border-slate-200 bg-white p-4">
        <h4 id="titulo-fechas-limite" className="flex items-center gap-2 text-sm font-bold text-slate-800">
          <CalendarClock className="h-4 w-4 text-slate-500" aria-hidden="true" /> Fechas límite
        </h4>
        {CAMPOS.map((c) => {
          const vigente = estadoDe(plazos[c.clave]);
          const id = `plazo-${c.clave}`;
          return (
            <div key={c.clave} className="flex flex-col gap-3 rounded-xl border border-slate-100 bg-slate-50 p-3 sm:flex-row sm:items-start sm:justify-between">
              <div className="min-w-0 space-y-1">
                <label htmlFor={id} className="block text-sm font-bold text-slate-800">{c.nombre}</label>
                <ul className="list-disc space-y-0.5 pl-4 text-[11px] text-slate-600">
                  {c.controla.map((t) => <li key={t}>{t}</li>)}
                </ul>
                <p className={`inline-block rounded-full px-2 py-0.5 text-[11px] font-bold ${vigente.abierto ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800'}`}>
                  {vigente.texto}
                </p>
              </div>
              <div className="shrink-0 space-y-1 sm:text-right">
                <input
                  id={id}
                  type="date"
                  value={valores[c.clave]}
                  min="2024-01-01"
                  max="2100-12-31"
                  onChange={(e) => setValores((v) => ({ ...v, [c.clave]: e.target.value }))}
                  className="w-full rounded-lg border border-slate-300 bg-white px-2.5 py-2 font-mono text-sm sm:w-44"
                />
                <p className="text-[10px] text-slate-400">Por defecto: {fechaLegible(PLAZOS_POR_DEFECTO[c.clave])}</p>
              </div>
            </div>
          );
        })}
      </section>

      {estadoCarga === 'error' && (
        <div role="alert" className="flex flex-wrap items-center gap-2 rounded-xl border border-red-200 bg-red-50 px-4 py-2.5 text-xs font-semibold text-red-700">
          <AlertTriangle className="h-4 w-4 shrink-0" aria-hidden="true" />
          <span className="flex-1">No se pudieron leer las fechas del servidor. Lo que ves pueden no ser las vigentes: «Guardar» queda bloqueado.</span>
          <button type="button" onClick={() => void cargar()} className="inline-flex items-center gap-1 rounded-lg border border-red-300 bg-white px-2.5 py-1 font-bold text-red-700 hover:bg-red-100">
            <RefreshCw className="h-3.5 w-3.5" aria-hidden="true" /> Reintentar
          </button>
        </div>
      )}
      {estadoCarga === 'cargando' && (
        <p className="flex items-center gap-2 text-xs text-slate-500"><Loader2 className="h-3.5 w-3.5 animate-spin" aria-hidden="true" /> Leyendo las fechas vigentes del servidor…</p>
      )}
      {mensaje && (
        <p role="status" className={`rounded-xl px-4 py-2.5 text-xs font-semibold ${mensaje.ok ? 'bg-emerald-50 text-emerald-800' : 'bg-red-50 text-red-700'}`}>{mensaje.texto}</p>
      )}

      <div className="flex flex-wrap items-center gap-2">
        <button
          type="button"
          onClick={() => void guardar()}
          disabled={guardando || estadoCarga !== 'ok' || !cambiado}
          className="inline-flex items-center gap-2 rounded-xl bg-slate-900 px-5 py-2.5 text-sm font-bold text-white hover:bg-slate-800 disabled:opacity-60"
        >
          {guardando ? <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" /> : <Save className="h-4 w-4" aria-hidden="true" />} Guardar fechas
        </button>
        {cambiado && (
          <button type="button" onClick={() => setValores({ ...plazos })} className="rounded-xl border border-slate-300 px-4 py-2.5 text-sm font-bold text-slate-700 hover:bg-slate-100">
            Descartar cambios
          </button>
        )}
      </div>
    </div>
  );
}
