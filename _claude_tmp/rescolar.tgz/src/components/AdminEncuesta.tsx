import { useCallback, useEffect, useMemo, useState } from 'react';
import { BarChart3, Loader2, MessageSquareText, Star, X } from 'lucide-react';
import { obtenerEncuestaAdmin, type RespuestaEncuestaAdmin } from '../services/encuestaService';

/**
 * 25/10/2026: resultados de la encuesta de satisfacción. Arriba los números (promedios y «¿nos recomendarías?»), abajo
 * las respuestas, primero las que piden que les escribamos. El mail se manda desde la pestaña «Emails» (tipo «Encuesta»).
 */
function promedio(valores: (number | null)[]): string {
  const v = valores.filter((n): n is number => typeof n === 'number');
  return v.length ? (v.reduce((a, b) => a + b, 0) / v.length).toFixed(1) : '—';
}

export default function AdminEncuesta({ onCerrar }: { onCerrar: () => void }) {
  const [datos, setDatos] = useState<{ destinatarios: number; pendientesDeEnvio: number; respuestas: RespuestaEncuestaAdmin[] } | null>(null);
  const [error, setError] = useState('');
  const cargar = useCallback(async () => {
    try {
      setDatos(await obtenerEncuestaAdmin());
      setError('');
    } catch (err: any) {
      setError(err?.message || 'No se pudo leer la encuesta.');
    }
  }, []);
  useEffect(() => { void cargar(); }, [cargar]);

  const resumen = useMemo(() => {
    const r = datos?.respuestas || [];
    const cuenta = (v: string) => r.filter((x) => x.recomendaria === v).length;
    return {
      total: r.length,
      fotos: promedio(r.map((x) => x.fotos)),
      web: promedio(r.map((x) => x.web)),
      atencion: promedio(r.map((x) => x.atencion)),
      si: cuenta('si'),
      talVez: cuenta('tal_vez'),
      no: cuenta('no'),
      contactar: r.filter((x) => x.quiere_contacto),
      conTexto: r.filter((x) => x.sugerencias && !x.quiere_contacto),
    };
  }, [datos]);

  const Tarjeta = ({ titulo, valor, detalle }: { titulo: string; valor: string; detalle?: string }) => (
    <div className="p-3 rounded-xl bg-slate-50 border border-slate-200">
      <p className="text-[11px] font-bold text-slate-500 uppercase tracking-wide">{titulo}</p>
      <p className="text-2xl font-extrabold text-slate-900 mt-0.5">{valor}</p>
      {detalle && <p className="text-[11px] text-slate-500">{detalle}</p>}
    </div>
  );

  const Respuesta = ({ r }: { r: RespuestaEncuestaAdmin }) => (
    <li className={`p-3 rounded-xl border text-sm ${r.quiere_contacto ? 'bg-rose-50 border-rose-200' : 'bg-white border-slate-200'}`}>
      <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-slate-600">
        <strong className="text-slate-900">{r.tutor_nombre || 'Familia'}</strong>
        {r.email && <a href={`mailto:${r.email}`} className="text-sky-700 hover:underline">{r.email}</a>}
        <span className="inline-flex items-center gap-0.5"><Star className="w-3 h-3 fill-amber-400 text-amber-400" />Fotos {r.fotos ?? '—'} · Web {r.web ?? '—'} · Atención {r.atencion ?? '—'}</span>
        <span>Recomendaría: {r.recomendaria === 'si' ? 'Sí' : r.recomendaria === 'tal_vez' ? 'Tal vez' : 'No'}</span>
        <span className="text-slate-400">{new Date(r.updated_at).toLocaleString('es-AR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' })}</span>
      </div>
      {r.quiere_contacto && <p className="mt-1 text-xs font-bold text-rose-700">Pidió que le escribamos (problema sin resolver)</p>}
      {r.sugerencias && <p className="mt-1.5 whitespace-pre-wrap text-slate-800">{r.sugerencias}</p>}
    </li>
  );

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/60 overflow-y-auto p-4" role="dialog" aria-modal="true" aria-label="Encuesta a las familias" onClick={onCerrar}>
      <div className="max-w-4xl mx-auto my-4 bg-white rounded-2xl p-5 space-y-5 text-slate-900" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between gap-3">
          <h2 className="text-lg font-extrabold inline-flex items-center gap-2"><BarChart3 className="w-5 h-5 text-amber-500" />Encuesta a las familias</h2>
          <button type="button" onClick={onCerrar} aria-label="Cerrar" className="p-1.5 rounded-lg text-slate-500 hover:bg-slate-100 cursor-pointer"><X className="w-5 h-5" /></button>
        </div>

        {!datos && !error ? (
          <div className="py-12 text-center text-slate-400"><Loader2 className="w-6 h-6 animate-spin mx-auto" /></div>
        ) : (
          <>
            <section className="grid grid-cols-2 sm:grid-cols-5 gap-2">
              <Tarjeta titulo="Respuestas" valor={String(resumen.total)} detalle={datos ? `de ${datos.destinatarios} familias` : undefined} />
              <Tarjeta titulo="Fotos" valor={resumen.fotos} detalle="promedio de 5" />
              <Tarjeta titulo="Web" valor={resumen.web} detalle="promedio de 5" />
              <Tarjeta titulo="Atención" valor={resumen.atencion} detalle="promedio de 5" />
              <Tarjeta titulo="Recomendaría" valor={`${resumen.si} sí`} detalle={`${resumen.talVez} tal vez · ${resumen.no} no`} />
            </section>

            <p className="text-xs text-slate-500">{datos ? `${datos.destinatarios - datos.pendientesDeEnvio} de ${datos.destinatarios} familias ya recibieron la encuesta.` : ''} Para mandarla: pestaña «Emails» → tipo «Encuesta».</p>
            {error && <p role="alert" className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-sm">{error}</p>}

            {resumen.contactar.length > 0 && (
              <section className="space-y-2">
                <h3 className="text-sm font-extrabold text-rose-800">Piden que les escribamos ({resumen.contactar.length})</h3>
                <ul className="space-y-2">{resumen.contactar.map((r) => <Respuesta key={r.id} r={r} />)}</ul>
              </section>
            )}
            <section className="space-y-2">
              <h3 className="text-sm font-extrabold inline-flex items-center gap-1.5"><MessageSquareText className="w-4 h-4 text-slate-500" />Sugerencias ({resumen.conTexto.length})</h3>
              {resumen.conTexto.length === 0 ? <p className="text-sm text-slate-500">Todavía no hay sugerencias.</p> : <ul className="space-y-2">{resumen.conTexto.map((r) => <Respuesta key={r.id} r={r} />)}</ul>}
            </section>
          </>
        )}
      </div>
    </div>
  );
}
