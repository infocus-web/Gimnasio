import { useState, type FormEvent } from 'react';
import { CameraOff, CheckCircle2, Clock, Loader2, MessageCircle, Send, UserX, Undo2 } from 'lucide-react';
import { enviarConsultaFamilia } from '../services/consultasFamiliasService';
import type { LugarPack, MotivoFaltante } from '../utils/fotosFaltantes';
import { MOTIVOS_FALTANTE, diaConvocatoria } from '../services/fotosFaltantesService';
import type { FaltantesSolicitadas } from './useFaltantesSolicitadas';
import { textoFechaLarga, usePlazosTemporada } from '../utils/plazosTemporada';

/**
 * 22/10/2026 (Pablo): «si un alumno le falta una foto (no quiso o no estaba el día de la toma), no podrá
 * terminar el pedido». Va arriba de la grilla de cada lugar del pack en el portal de familias: la familia
 * avisa «Mi hijo/a no tiene esta foto» y, en ese lugar, elige otra foto del curso o sigue sin ella. El precio
 * del kit no cambia. Reglas en src/utils/fotosFaltantes.ts y servidor/nucleo/fotosFaltantes.ts.
 * Además («Faltantes solicitadas», mismo día): puede pedir que le saquen la foto (o que la busquen, si se la
 * sacaron y no aparece) hasta el 15/11; mientras tanto el kit de ese chico queda en espera. Pablo (22/10): no se
 * menciona nada sobre repetir una foto que no gustó (ni que se puede ni que no).
 */
interface Props {
  lugar: LugarPack;
  /** Cómo se llama esta foto en el curso («la foto con la seño», «la foto individual», …). */
  nombreFoto: string;
  marcado: boolean;
  /** Título de la foto que la familia eligió en su lugar (si eligió una). */
  reemplazo?: string;
  onCambiar: (marcado: boolean) => void;
  faltantes?: FaltantesSolicitadas;
  contacto?: { email: string; whatsapp: string };
  /** 26/10: datos para el aviso «no está en la foto grupal» (llega a Consultas del panel). */
  datosAviso?: { tutor: string; alumno: string; curso: string; colegio: string };
  /** 29/10: la pestaña no tiene ninguna foto de este lugar para este chico (por ejemplo, secundaria sin individuales). */
  sinFotosEnPestana?: boolean;
}

const BOTON = 'inline-flex items-center gap-1.5 rounded-lg border px-3 py-2 sm:py-1.5 text-xs font-bold cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed';

export default function AvisoSinFotoPack({ lugar, nombreFoto, marcado, reemplazo, onCambiar, faltantes, contacto, datosAviso, sinFotosEnPestana }: Props) {
  const hastaFaltantes = textoFechaLarga(usePlazosTemporada().faltantes); // 30/10: fecha del panel → Configuración
  const [abriendo, setAbriendo] = useState(false);
  const [motivo, setMotivo] = useState<MotivoFaltante | ''>('');
  const [email, setEmail] = useState(contacto?.email || '');
  const [whatsapp, setWhatsapp] = useState(contacto?.whatsapp || '');
  const [enviando, setEnviando] = useState(false);
  const [error, setError] = useState('');
  const pedida = faltantes?.pendiente(lugar);

  const correr = async (accion: () => Promise<string | null>) => {
    setEnviando(true);
    setError('');
    const fallo = await accion();
    setEnviando(false);
    if (fallo) setError(fallo);
    else setAbriendo(false);
  };

  // 25/10 (auditoría): el pedido pendiente se muestra siempre (antes, tras «Deshacer» o al volver desde otro equipo, el
  // lugar quedaba sin marcar y la familia no veía que tenía un pedido de foto en curso).
  if (pedida) {
    const etiqueta = MOTIVOS_FALTANTE.find((m) => m.valor === pedida.motivo);
    return (
      <div role="status" className="rounded-xl border border-sky-300 bg-sky-50 px-3 py-2.5 text-left space-y-1.5" data-lugar={lugar}>
        <p className="text-xs font-bold text-sky-900 flex items-center gap-1.5">
          <Clock className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
          {pedida.motivo === 'no_encontrada' ? `Nos pediste que busquemos ${nombreFoto} de tu hijo/a.` : `Pediste que le saquemos ${nombreFoto} a tu hijo/a.`}
        </p>
        <p className="text-xs text-sky-900">
          Te avisamos por mail cuando la publiquemos. Mientras tanto, el kit de tu hijo/a queda en espera
          {etiqueta ? ` (${etiqueta.etiqueta.toLowerCase()})` : ''}.
        </p>
        {pedida.convocatoria_dia && (
          <p className="text-xs font-bold text-sky-950 bg-white/70 border border-sky-200 rounded-lg px-2 py-1.5">
            Te esperamos el {diaConvocatoria(pedida.convocatoria_dia)}{pedida.convocatoria_hora ? `, ${pedida.convocatoria_hora}` : ''}{pedida.convocatoria_lugar ? `, en ${pedida.convocatoria_lugar}` : ''}.
          </p>
        )}
        <button type="button" disabled={enviando} onClick={() => void correr(() => faltantes!.cancelar(lugar))} className={`${BOTON} border-sky-400 bg-white text-sky-900 hover:bg-sky-100`}>
          {enviando ? <Loader2 className="w-3.5 h-3.5 animate-spin" aria-hidden="true" /> : <Undo2 className="w-3.5 h-3.5" aria-hidden="true" />}
          Cancelar el pedido de esta foto
        </button>
        {error && <p role="alert" className="text-xs font-semibold text-rose-700">{error}</p>}
      </div>
    );
  }

  // 26/10/2026 (Pablo): «si no está en la grupal, que se comunique con nosotros antes de darle la opción de no
  // elegirla; muchos pagaron por ella y el kit sí o sí lleva 3 fotos». En la grupal no hay «no tiene esta foto»:
  // la familia nos avisa (queda como consulta en el panel) y el pedido espera a que lo resolvamos.
  if (lugar === 'grupal') {
    return (
      <AvisoNoEstaEnGrupal
        contacto={contacto}
        datos={datosAviso}
        marcadoAntes={marcado}
        onDeshacer={() => onCambiar(false)}
      />
    );
  }

  // 29/10/2026 (Pablo: «es confuso, si ni yo lo supe, cómo podrían los padres»): si todavía no hay ninguna foto de este
  // lugar, se dice claro y con un solo botón para seguir (elegir otra foto del curso en su lugar).
  if (!marcado && sinFotosEnPestana) {
    return (
      <div role="status" className="rounded-xl border-2 border-amber-400 bg-amber-50 px-4 py-3 text-left space-y-2" data-lugar={lugar}>
        <p className="text-sm font-bold text-amber-950">Todavía no está {nombreFoto} de tu hijo/a en la galería.</p>
        <p className="text-sm text-amber-950">Para seguir con el pedido, elegí otra foto del curso en su lugar. El precio del kit no cambia.</p>
        <button
          type="button"
          onClick={() => onCambiar(true)}
          className="inline-flex items-center gap-1.5 rounded-lg border border-amber-500 bg-amber-400 px-4 py-2.5 text-sm font-bold text-slate-950 hover:bg-amber-300 cursor-pointer"
        >
          Elegir otra foto en su lugar
        </button>
      </div>
    );
  }

  if (!marcado) {
    return (
      <div className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-left" data-lugar={lugar}>
        <p className="text-xs text-slate-600">¿A tu hijo/a le falta esta foto? (No estuvo ese día o no quiso)</p>
        <button
          type="button"
          onClick={() => onCambiar(true)}
          className="shrink-0 inline-flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3 py-2 sm:py-1.5 text-xs font-bold text-slate-700 hover:bg-slate-100 cursor-pointer"
        >
          <UserX className="w-3.5 h-3.5" aria-hidden="true" />
          Mi hijo/a no tiene esta foto
        </button>
      </div>
    );
  }

  // 26/10/2026 (Pablo): el kit lleva siempre 3 fotos: sin «seguir sin ella»; otra foto del curso o pedirla (la grupal va aparte, arriba).
  const puedePedir = Boolean(faltantes?.disponible && faltantes.abierto);
  return (
    <div role="status" className="rounded-xl border border-amber-300 bg-amber-50 px-3 py-2.5 text-left space-y-1.5" data-lugar={lugar}>
      <p className="text-xs font-bold text-amber-900">
        Avisaste que tu hijo/a no tiene {nombreFoto}.{' '}
        {reemplazo ? <>En su lugar va: «{reemplazo}». Ya podés seguir.</> : <>Ahora tocá «Usar en su lugar» en una de las fotos de abajo.</>}
      </p>
      <p className="text-xs text-amber-900">
        La foto que elijas va en el kit en lugar de {nombreFoto}. El precio del kit no cambia.
        {puedePedir ? ` O pedinos que le saquemos esta foto (hasta el ${hastaFaltantes}).` : faltantes && !faltantes.abierto ? ` El plazo para pedir que le saquen esta foto terminó el ${hastaFaltantes}.` : ' Para pedir que le saquen esta foto, ingresá a la galería con los datos del tutor (DNI).'}
      </p>
      <div className="flex flex-wrap gap-2">
        <button type="button" onClick={() => onCambiar(false)} className={`${BOTON} border-amber-400 bg-white text-amber-900 hover:bg-amber-100`}>
          <Undo2 className="w-3.5 h-3.5" aria-hidden="true" />
          Deshacer: sí tiene esta foto
        </button>
        {puedePedir && !abriendo && (
          <button type="button" onClick={() => setAbriendo(true)} className={`${BOTON} border-amber-500 bg-amber-400 text-slate-950 hover:bg-amber-300`}>
            <CameraOff className="w-3.5 h-3.5" aria-hidden="true" />
            Quiero que le saquen esta foto
          </button>
        )}
      </div>

      {puedePedir && abriendo && (
        <form
          className="mt-2 space-y-2 rounded-xl border border-amber-200 bg-white p-3"
          onSubmit={(e) => {
            e.preventDefault();
            if (!motivo) return setError('Contanos qué pasó con la foto.');
            void correr(() => faltantes!.solicitar(lugar, motivo, email.trim(), whatsapp.trim()));
          }}
        >
          <fieldset className="space-y-1">
            <legend className="text-xs font-bold text-slate-800">Antes de pedirla: ¿qué pasó con {nombreFoto}?</legend>
            {MOTIVOS_FALTANTE.map((m) => (
              <label key={m.valor} className="flex items-start gap-2 text-xs text-slate-700 cursor-pointer">
                <input type="radio" name={`motivo-${lugar}`} value={m.valor} checked={motivo === m.valor} onChange={() => setMotivo(m.valor)} className="mt-0.5" />
                {m.etiqueta}
              </label>
            ))}
            {motivo === 'no_encontrada' && <p className="text-[11px] text-slate-500">Puede que todavía no la hayamos subido: la buscamos y te avisamos.</p>}
          </fieldset>
          <div className="grid gap-2 sm:grid-cols-2">
            <label className="text-xs font-semibold text-slate-700">
              Email para avisarte
              <input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} className="mt-1 w-full rounded-lg border border-slate-300 px-2 py-1.5 text-xs font-normal" />
            </label>
            <label className="text-xs font-semibold text-slate-700">
              WhatsApp (opcional)
              <input type="tel" value={whatsapp} onChange={(e) => setWhatsapp(e.target.value)} className="mt-1 w-full rounded-lg border border-slate-300 px-2 py-1.5 text-xs font-normal" />
            </label>
          </div>
          <div className="flex flex-wrap gap-2">
            <button type="submit" disabled={enviando} className={`${BOTON} border-amber-500 bg-amber-400 text-slate-950 hover:bg-amber-300`}>
              {enviando ? <Loader2 className="w-3.5 h-3.5 animate-spin" aria-hidden="true" /> : <Send className="w-3.5 h-3.5" aria-hidden="true" />}
              {motivo === 'no_encontrada' ? 'Pedir que la busquen' : 'Pedir la foto'}
            </button>
            <button type="button" onClick={() => { setAbriendo(false); setError(''); }} className={`${BOTON} border-slate-300 bg-white text-slate-700 hover:bg-slate-100`}>
              Cancelar
            </button>
          </div>
          <p className="text-[11px] text-slate-500">Mientras esperás la foto, el kit de tu hijo/a queda en espera (no se cierra sin ella).</p>
        </form>
      )}
      {error && <p role="alert" className="text-xs font-semibold text-rose-700">{error}</p>}
    </div>
  );
}

/** 26/10: «¿Tu hijo/a no está en la foto grupal?» → nos escribe desde acá (consulta con alumno, curso y colegio). */
function AvisoNoEstaEnGrupal({ contacto, datos, marcadoAntes, onDeshacer }: {
  contacto?: { email: string; whatsapp: string };
  datos?: { tutor: string; alumno: string; curso: string; colegio: string };
  marcadoAntes: boolean;
  onDeshacer: () => void;
}) {
  const [abierto, setAbierto] = useState(false);
  const [email, setEmail] = useState(contacto?.email || '');
  const [whatsapp, setWhatsapp] = useState(contacto?.whatsapp || '');
  const [comentario, setComentario] = useState('');
  const [enviando, setEnviando] = useState(false);
  const [enviado, setEnviado] = useState(false);
  const [error, setError] = useState('');

  const enviar = async (e: FormEvent) => {
    e.preventDefault();
    if (enviando) return;
    if (!email.trim()) return setError('Dejanos un email para responderte.');
    setEnviando(true);
    setError('');
    const alumno = datos?.alumno || 'mi hijo/a';
    const r = await enviarConsultaFamilia({
      nombre: datos?.tutor || alumno,
      email: email.trim(),
      telefono: whatsapp.trim() || undefined,
      colegio: datos?.colegio || undefined,
      asunto: `No aparece en la foto grupal: ${alumno}`,
      mensaje: `${alumno}${datos?.curso ? ` (${datos.curso})` : ''} no aparece en la foto grupal del curso.${comentario.trim() ? `\n\nComentario de la familia: ${comentario.trim()}` : ''}`,
    });
    setEnviando(false);
    if (!r.success) return setError(r.error || 'No pudimos enviar el aviso. Intentá de nuevo.');
    setEnviado(true);
  };

  if (enviado) {
    return (
      <div role="status" className="rounded-xl border border-emerald-300 bg-emerald-50 px-3 py-2.5 text-left space-y-1" data-lugar="grupal">
        <p className="text-xs font-bold text-emerald-900 flex items-center gap-1.5"><CheckCircle2 className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />Recibimos tu aviso.</p>
        <p className="text-xs text-emerald-900">Lo revisamos y te respondemos a {email.trim()}. El kit lleva siempre las 3 fotos, así que te conviene esperar nuestra respuesta antes de terminar el pedido.</p>
      </div>
    );
  }

  return (
    <div className="rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-left space-y-2" data-lugar="grupal">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <p className="text-xs text-slate-600">¿Tu hijo/a no está en la foto grupal? Avisanos antes de seguir y lo resolvemos.</p>
        {!abierto && (
          <button type="button" onClick={() => setAbierto(true)} className="shrink-0 inline-flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3 py-2 sm:py-1.5 text-xs font-bold text-slate-700 hover:bg-slate-100 cursor-pointer">
            <MessageCircle className="w-3.5 h-3.5" aria-hidden="true" />
            No está en la grupal: avisar
          </button>
        )}
      </div>
      {marcadoAntes && (
        <p className="text-xs text-amber-900">
          Antes marcaste que no tiene esta foto. El kit lleva siempre las 3 fotos: elegí la grupal o avisanos.{' '}
          <button type="button" onClick={onDeshacer} className="font-bold underline cursor-pointer">Quitar esa marca</button>
        </p>
      )}
      {abierto && (
        <form onSubmit={(e) => void enviar(e)} className="space-y-2 rounded-xl border border-slate-200 bg-white p-3">
          <p className="text-xs text-slate-700">Nos llega con el nombre de {datos?.alumno || 'tu hijo/a'}{datos?.curso ? `, ${datos.curso}` : ''}. Te respondemos por mail.</p>
          <div className="grid gap-2 sm:grid-cols-2">
            <label className="text-xs font-semibold text-slate-700">
              Email para responderte
              <input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} className="mt-1 w-full rounded-lg border border-slate-300 px-2 py-1.5 text-xs font-normal" />
            </label>
            <label className="text-xs font-semibold text-slate-700">
              WhatsApp (opcional)
              <input type="tel" value={whatsapp} onChange={(e) => setWhatsapp(e.target.value)} className="mt-1 w-full rounded-lg border border-slate-300 px-2 py-1.5 text-xs font-normal" />
            </label>
          </div>
          <label className="block text-xs font-semibold text-slate-700">
            Comentario (opcional)
            <textarea value={comentario} onChange={(e) => setComentario(e.target.value)} rows={2} maxLength={1000} placeholder="Ej.: ese día faltó / no lo encuentro en ninguna" className="mt-1 w-full rounded-lg border border-slate-300 px-2 py-1.5 text-xs font-normal" />
          </label>
          <div className="flex flex-wrap gap-2">
            <button type="submit" disabled={enviando} className={`${BOTON} border-amber-500 bg-amber-400 text-slate-950 hover:bg-amber-300`}>
              {enviando ? <Loader2 className="w-3.5 h-3.5 animate-spin" aria-hidden="true" /> : <Send className="w-3.5 h-3.5" aria-hidden="true" />}
              Enviar aviso
            </button>
            <button type="button" onClick={() => { setAbierto(false); setError(''); }} className={`${BOTON} border-slate-300 bg-white text-slate-700 hover:bg-slate-100`}>Cancelar</button>
          </div>
        </form>
      )}
      {error && <p role="alert" className="text-xs font-semibold text-rose-700">{error}</p>}
    </div>
  );
}
