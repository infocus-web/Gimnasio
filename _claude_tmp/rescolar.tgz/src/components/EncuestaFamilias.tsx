import { useEffect, useState } from 'react';
import { CheckCircle2, Heart, Loader2, Star, X } from 'lucide-react';
import { abrirEncuesta, enviarEncuesta, type Recomendaria, type RespuestaEncuesta } from '../services/encuestaService';

/**
 * 25/10/2026: encuesta de satisfacción (link personal del mail: /?encuesta=<id>.<firma>). Cuatro preguntas cortas y
 * sugerencias. Si la familia ya respondió, ve sus respuestas y las puede corregir.
 */
const VACIA: RespuestaEncuesta = { fotos: null, web: null, atencion: null, recomendaria: null, sugerencias: '', quiereContacto: false };

function Estrellas({ valor, onCambiar, etiqueta }: { valor: number | null; onCambiar: (n: number) => void; etiqueta: string }) {
  return (
    <div role="radiogroup" aria-label={etiqueta} className="flex gap-1.5">
      {[1, 2, 3, 4, 5].map((n) => (
        <button
          key={n}
          type="button"
          role="radio"
          aria-checked={valor === n}
          aria-label={`${n} de 5`}
          onClick={() => onCambiar(n)}
          className="p-1 rounded-lg hover:bg-amber-50 focus-visible:outline-2 focus-visible:outline-amber-500 cursor-pointer"
        >
          <Star className={`w-8 h-8 transition-colors ${valor !== null && n <= valor ? 'fill-amber-400 text-amber-400' : 'text-slate-300'}`} />
        </button>
      ))}
    </div>
  );
}

function Pregunta({ titulo, children }: { titulo: string; children: React.ReactNode }) {
  return (
    <fieldset className="space-y-2">
      <legend className="text-sm font-bold text-slate-900">{titulo}</legend>
      {children}
    </fieldset>
  );
}

export default function EncuestaFamilias({ token, onCerrar }: { token: string; onCerrar: () => void }) {
  const [estado, setEstado] = useState<'cargando' | 'lista' | 'enviando' | 'gracias' | 'error'>('cargando');
  const [error, setError] = useState('');
  const [tutor, setTutor] = useState('');
  const [prueba, setPrueba] = useState(false);
  const [yaRespondio, setYaRespondio] = useState(false);
  const [r, setR] = useState<RespuestaEncuesta>(VACIA);
  const poner = <K extends keyof RespuestaEncuesta>(campo: K, valor: RespuestaEncuesta[K]) => setR((prev) => ({ ...prev, [campo]: valor }));

  useEffect(() => {
    void abrirEncuesta(token).then((res) => {
      if (res.ok === false) { setError(res.error); setEstado('error'); return; }
      setTutor(res.tutor);
      setPrueba(res.prueba);
      if (res.previa) { setR(res.previa); setYaRespondio(true); }
      setEstado('lista');
    });
  }, [token]);

  const completa = r.fotos !== null && r.web !== null && r.recomendaria !== null;
  const enviar = async () => {
    if (!completa) { setError('Respondé las preguntas con estrellas y si nos recomendarías.'); return; }
    setEstado('enviando');
    setError('');
    const res = await enviarEncuesta(token, r);
    if (res.ok === false) { setError(res.error); setEstado('lista'); return; }
    setEstado('gracias');
  };

  const recomendar: { id: Recomendaria; texto: string }[] = [
    { id: 'si', texto: 'Sí' },
    { id: 'tal_vez', texto: 'Tal vez' },
    { id: 'no', texto: 'No' },
  ];

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-sm overflow-y-auto p-4" role="dialog" aria-modal="true" aria-label="Encuesta de Retrato Escolar">
      <div className="max-w-lg mx-auto my-6 bg-white rounded-3xl shadow-xl overflow-hidden">
        <div className="bg-slate-900 px-6 py-5 border-b-4 border-amber-500 flex items-start justify-between gap-3">
          <div>
            <p className="text-[11px] font-extrabold tracking-widest text-amber-400">RETRATO ESCOLAR</p>
            <h2 className="text-xl font-extrabold text-white mt-1">{tutor ? `${tutor}, ¿cómo te fue?` : '¿Cómo te fue?'}</h2>
          </div>
          <button type="button" onClick={onCerrar} aria-label="Cerrar" className="p-1.5 rounded-lg text-slate-300 hover:bg-slate-800 cursor-pointer"><X className="w-5 h-5" /></button>
        </div>

        <div className="p-6">
          {estado === 'cargando' ? (
            <div className="py-12 text-center text-slate-400"><Loader2 className="w-6 h-6 animate-spin mx-auto" /></div>
          ) : estado === 'error' ? (
            <p className="p-4 rounded-2xl bg-rose-50 border border-rose-200 text-rose-800 text-sm">{error}</p>
          ) : estado === 'gracias' ? (
            <div className="py-6 text-center space-y-3">
              <Heart className="w-12 h-12 text-rose-500 fill-rose-500 mx-auto" />
              <h3 className="text-xl font-extrabold text-slate-900">¡Gracias por tu tiempo!</h3>
              <p className="text-sm text-slate-600">Leemos cada respuesta para seguir mejorando.{r.quiereContacto ? ' Como nos pediste, te vamos a escribir.' : ''}</p>
              {prueba && <p className="text-xs font-semibold text-amber-700">(Link de prueba: esta respuesta no se guardó.)</p>}
              <button type="button" onClick={onCerrar} className="mt-2 px-5 py-2.5 rounded-xl bg-slate-900 text-white text-sm font-bold hover:bg-slate-800 cursor-pointer">Volver a la página</button>
            </div>
          ) : (
            <form className="space-y-6" onSubmit={(e) => { e.preventDefault(); void enviar(); }}>
              <p className="text-sm text-slate-600">Son 4 preguntas y te lleva menos de un minuto. {yaRespondio && <strong className="text-slate-800">Ya respondiste: podés corregir lo que quieras.</strong>}</p>
              {prueba && <p className="p-2.5 rounded-xl bg-amber-50 border border-amber-200 text-amber-800 text-xs font-semibold">Link de prueba: podés completarla para ver cómo funciona, pero no se guarda.</p>}

              <Pregunta titulo="1. ¿Qué te parecieron las fotos?">
                <Estrellas etiqueta="Las fotos" valor={r.fotos} onCambiar={(n) => poner('fotos', n)} />
              </Pregunta>
              <Pregunta titulo="2. ¿Qué tan fácil te resultó elegir y comprar en la web?">
                <Estrellas etiqueta="La web" valor={r.web} onCambiar={(n) => poner('web', n)} />
              </Pregunta>
              <Pregunta titulo="3. Si nos escribiste, ¿cómo te atendimos?">
                <Estrellas etiqueta="La atención" valor={r.atencion} onCambiar={(n) => poner('atencion', n)} />
                <button type="button" onClick={() => poner('atencion', null)} aria-pressed={r.atencion === null} className={`text-xs font-semibold px-3 py-1.5 rounded-lg border cursor-pointer ${r.atencion === null ? 'bg-slate-900 text-white border-slate-900' : 'bg-white text-slate-600 border-slate-300 hover:bg-slate-50'}`}>No les escribí</button>
              </Pregunta>
              <Pregunta titulo="4. ¿Nos recomendarías a otras familias?">
                <div className="grid grid-cols-3 gap-2">
                  {recomendar.map((o) => (
                    <button key={o.id} type="button" onClick={() => poner('recomendaria', o.id)} aria-pressed={r.recomendaria === o.id} className={`py-2.5 rounded-xl border text-sm font-bold cursor-pointer ${r.recomendaria === o.id ? 'bg-amber-400 border-amber-400 text-slate-950' : 'bg-white border-slate-300 text-slate-700 hover:bg-slate-50'}`}>{o.texto}</button>
                  ))}
                </div>
              </Pregunta>
              <div className="space-y-2">
                <label htmlFor="encuesta-sugerencias" className="block text-sm font-bold text-slate-900">¿Qué podemos mejorar? <span className="font-normal text-slate-500">(opcional)</span></label>
                <textarea id="encuesta-sugerencias" value={r.sugerencias} onChange={(e) => poner('sugerencias', e.target.value)} maxLength={2000} rows={4} placeholder="Contanos tus sugerencias, lo que te gustó o lo que no." className="w-full rounded-xl border border-slate-300 p-3 text-sm outline-none focus:border-amber-500 focus:ring-2 focus:ring-amber-200" />
                <label className="flex items-start gap-2 text-sm text-slate-700 cursor-pointer">
                  <input type="checkbox" checked={r.quiereContacto} onChange={(e) => poner('quiereContacto', e.target.checked)} className="mt-0.5 w-4 h-4 accent-amber-500" />
                  Tengo un problema sin resolver: quiero que me escriban.
                </label>
              </div>
              {error && <p role="alert" className="text-sm font-semibold text-rose-700">{error}</p>}
              <button type="submit" disabled={estado === 'enviando'} className="w-full inline-flex items-center justify-center gap-2 py-3.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 text-base font-extrabold disabled:opacity-60 cursor-pointer">
                {estado === 'enviando' ? <Loader2 className="w-5 h-5 animate-spin" /> : <CheckCircle2 className="w-5 h-5" />}
                {yaRespondio ? 'Guardar cambios' : 'Enviar respuestas'}
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}
