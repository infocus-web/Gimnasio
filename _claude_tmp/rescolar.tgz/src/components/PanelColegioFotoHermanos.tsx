import { useEffect, useMemo, useState } from 'react';
import { CalendarClock, Loader2 } from 'lucide-react';
import { obtenerFotoHermanosColegio, type FamiliaHermanosColegio, type SesionColegio } from '../services/panelColegioService';

/**
 * 26/10/2026 (Pablo: «me lo pide el colegio»): pestaña «Hermanos» del panel del colegio. Las familias que confirmaron
 * la foto de hermanos, agrupadas por día y ordenadas por horario (lo asignado en la citación repartida). Sólo lectura,
 * sin datos de contacto de las familias.
 */
function diaLargo(dia: string): string {
  const texto = new Date(`${dia}T12:00:00-03:00`).toLocaleDateString('es-AR', { weekday: 'long', day: 'numeric', month: 'long', timeZone: 'America/Argentina/Buenos_Aires' }).replace(',', '');
  return texto.charAt(0).toUpperCase() + texto.slice(1);
}

export default function PanelColegioFotoHermanos({ sesion, alFallar }: { sesion: SesionColegio; alFallar: (e: unknown) => void }) {
  const [familias, setFamilias] = useState<FamiliaHermanosColegio[] | null>(null);

  useEffect(() => {
    let vigente = true;
    obtenerFotoHermanosColegio(sesion)
      .then((f) => vigente && setFamilias(f))
      .catch((e) => {
        if (!vigente) return;
        setFamilias([]);
        alFallar(e);
      });
    return () => {
      vigente = false;
    };
  }, [sesion, alFallar]);

  const dias = useMemo(() => {
    const grupos = new Map<string, FamiliaHermanosColegio[]>();
    for (const f of familias || []) {
      const clave = f.dia || '';
      grupos.set(clave, [...(grupos.get(clave) || []), f]);
    }
    return [...grupos.entries()];
  }, [familias]);

  if (!familias) {
    return (
      <p className="flex items-center gap-2 rounded-2xl bg-white p-4 text-sm text-slate-600">
        <Loader2 className="h-4 w-4 animate-spin" /> Cargando la foto de hermanos…
      </p>
    );
  }
  if (familias.length === 0) {
    return <p className="rounded-2xl border border-slate-200 bg-white p-4 text-sm text-slate-600">Todavía no hay familias anotadas para la foto de hermanos.</p>;
  }

  const chicos = familias.reduce((a, f) => a + f.chicos.length, 0);
  return (
    <section className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3 rounded-3xl border border-slate-200 bg-white p-5 shadow-sm">
        <div>
          <p className="flex items-center gap-2 text-sm font-extrabold text-slate-900">
            <CalendarClock className="h-4 w-4 text-amber-600" /> Foto de hermanos
          </p>
          <p className="mt-1 text-sm text-slate-600">
            {familias.length} {familias.length === 1 ? 'familia' : 'familias'} · {chicos} chicos. Cada familia ya recibió por email su día y su horario.
          </p>
        </div>
      </div>

      {dias.map(([dia, lista]) => (
        <div key={dia || 'sin-dia'} className="overflow-hidden rounded-3xl border border-slate-200 bg-white shadow-sm">
          <div className={`flex flex-wrap items-baseline justify-between gap-2 px-5 py-3 ${dia ? 'bg-slate-900 text-white' : 'bg-amber-50 text-amber-900'}`}>
            <h3 className="font-['Outfit'] text-base font-extrabold">{dia ? diaLargo(dia) : 'Todavía sin día asignado'}</h3>
            <span className="text-xs font-bold opacity-80">{lista.length} {lista.length === 1 ? 'familia' : 'familias'}</span>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full min-w-[560px] table-fixed text-left text-sm">
              <colgroup>
                <col className="w-36" />
                <col className="w-[34%]" />
                <col />
              </colgroup>
              <thead className="bg-slate-50 text-xs uppercase tracking-wide text-slate-500">
                <tr>
                  <th scope="col" className="px-4 py-2 font-bold">Horario</th>
                  <th scope="col" className="px-4 py-2 font-bold">Familia</th>
                  <th scope="col" className="px-4 py-2 font-bold">Chicos (curso)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {lista.map((f, i) => (
                  <tr key={`${f.tutor}-${i}`} className="align-top">
                    <td className="whitespace-nowrap px-4 py-2.5 font-bold text-slate-900">{f.hora || '—'}</td>
                    <td className="px-4 py-2.5 font-semibold text-slate-800">{f.tutor || '—'}</td>
                    <td className="px-4 py-2.5 text-slate-700">
                      {f.chicos.map((c) => (
                        <span key={c} className="block">{c}</span>
                      ))}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      ))}
    </section>
  );
}
