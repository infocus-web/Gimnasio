import { useState } from 'react';
import { CheckCircle2, CreditCard, Loader2 } from 'lucide-react';
import AvisoPlazoTransferencia from './AvisoPlazoTransferencia';
import SubirComprobante from './SubirComprobante';
import { crearPreferenciaMercadoPago } from '../services/mercadoPagoService';
import { crearIntencionPagoNave } from '../services/naveService';
import { useNaveHabilitado } from '../services/mediosPagoService';

/**
 * Pago de un pedido que cuelga de un kit ya pagado: fotos extra o «Pasar a Kit Impreso» (29/10/2026, Pablo: «si la
 * plataforma siempre permitió los 3»). Mismos medios que el kit: Mercado Pago, Nave (sólo si está habilitado) o
 * transferencia (con el aviso de 48 h obligatorio, los datos de la cuenta y la subida del comprobante). El monto lo
 * fija el servidor al crear el pedido (`preparar`); las pasarelas cobran el total guardado en la base.
 */
export type MetodoPago = 'mercadopago' | 'nave' | 'transferencia';

export interface ResultadoPreparar {
  success: boolean;
  pedidoId?: string;
  pedidoFriendlyId?: string;
  total?: number;
  error?: string;
}

interface Props {
  /** Texto del botón (con el monto que se ve en pantalla). */
  textoBoton: string;
  deshabilitado?: boolean;
  /** Crea o reutiliza el pedido en el servidor con el medio elegido. */
  preparar: (metodo: MetodoPago) => Promise<ResultadoPreparar>;
  datos: { kitId: string; kitNombre: string; alumnoNombre: string; colegioNombre?: string; tutorNombre?: string; tutorEmail?: string; tutorTelefono?: string };
  codigoSeccion?: string | null;
  /** Para que cada casilla del aviso de 48 h tenga su propio id en la página. */
  idUnico: string;
  colorBoton?: string;
}

const MEDIOS_PAGO: { id: MetodoPago; nombre: string; detalle: string; normal: string; elegido: string }[] = [
  { id: 'mercadopago', nombre: 'Mercado Pago', detalle: 'Débito, crédito o dinero en cuenta', normal: 'border-[#009EE3] bg-white text-[#0074a8]', elegido: 'border-[#009EE3] bg-[#009EE3] text-white' },
  { id: 'nave', nombre: 'Nave', detalle: 'Tarjetas y QR', normal: 'border-violet-500 bg-white text-violet-700', elegido: 'border-violet-600 bg-violet-600 text-white' },
  { id: 'transferencia', nombre: 'Transferencia', detalle: 'Alias / CBU', normal: 'border-slate-300 bg-white text-slate-800', elegido: 'border-slate-800 bg-slate-800 text-white' },
];

export default function PagoPedidoAdicional({ textoBoton, deshabilitado = false, preparar, datos, codigoSeccion, idUnico, colorBoton }: Props) {
  const naveHabilitado = useNaveHabilitado();
  const [metodo, setMetodo] = useState<MetodoPago>('mercadopago');
  const [aceptaPlazo, setAceptaPlazo] = useState(false);
  const [faltaPlazo, setFaltaPlazo] = useState(false);
  const [enviando, setEnviando] = useState(false);
  const [error, setError] = useState('');
  const [transferencia, setTransferencia] = useState<{ pedidoId: string; numero: string; total: number | null } | null>(null);

  const pagar = async () => {
    if (enviando || deshabilitado) return;
    setError('');
    if (metodo === 'transferencia' && !aceptaPlazo) {
      setFaltaPlazo(true);
      return;
    }
    setEnviando(true);
    const pedido = await preparar(metodo);
    if (!pedido.success || !pedido.pedidoId) {
      setEnviando(false);
      setError(pedido.error || 'No pudimos preparar el pedido. Probá de nuevo.');
      return;
    }
    if (metodo === 'transferencia') {
      setEnviando(false);
      setTransferencia({ pedidoId: pedido.pedidoId, numero: pedido.pedidoFriendlyId || '', total: typeof pedido.total === 'number' ? pedido.total : null });
      return;
    }
    const base = {
      pedidoId: pedido.pedidoId,
      kitId: datos.kitId,
      kitNombre: datos.kitNombre,
      alumnoNombre: datos.alumnoNombre,
      colegioNombre: datos.colegioNombre || '',
      tutorNombre: datos.tutorNombre || '',
      tutorEmail: datos.tutorEmail || '',
      tutorTelefono: datos.tutorTelefono || '',
    };
    const pago = metodo === 'nave' ? await crearIntencionPagoNave(base) : await crearPreferenciaMercadoPago({ ...base, cursoCodigo: '', total: pedido.total || 0 });
    const url = 'checkoutUrl' in pago ? pago.checkoutUrl : 'initPoint' in pago ? pago.initPoint : undefined;
    if (pago.success && url) {
      window.location.href = url;
      return;
    }
    setEnviando(false);
    setError(pago.error || 'No se pudo iniciar el pago. Intentá de nuevo o elegí otro medio.');
  };

  if (transferencia) {
    return (
      <div className="rounded-lg border border-emerald-200 bg-white p-3 space-y-2">
        <p className="flex items-center gap-1.5 text-xs font-bold text-slate-900">
          <CheckCircle2 className="h-4 w-4 text-emerald-600" /> Pedido {transferencia.numero} registrado
        </p>
        <p className="text-[11px] text-slate-700">
          Transferí {transferencia.total !== null ? <strong>${transferencia.total.toLocaleString('es-AR')}</strong> : 'el total del pedido'} y subí el comprobante acá abajo. Cuando
          lo confirmemos te llega un email. También te mandamos estos datos por email.
        </p>
        <div className="space-y-0.5 rounded-lg bg-slate-50 p-2.5 text-[11px] text-slate-700">
          <p><strong>Titular:</strong> Alderete Pablo Gabriel</p>
          <p><strong>CUIT:</strong> 20-28306117-6</p>
          <p><strong>Alias:</strong> <span className="font-mono font-bold">RETRATO.ESCOLAR</span></p>
          <p><strong>CBU:</strong> <span className="font-mono">0070313830004052956749</span></p>
        </div>
        <SubirComprobante pedidoId={transferencia.pedidoId} numeros={transferencia.numero} codigo={codigoSeccion || undefined} />
      </div>
    );
  }

  const medios = MEDIOS_PAGO.filter((m) => m.id !== 'nave' || naveHabilitado);
  return (
    <div className="space-y-2">
      <div role="group" aria-label="Medio de pago">
        <p className="mb-1 text-[11px] font-semibold text-slate-700">Medio de pago</p>
        <div className={`grid gap-1.5 ${medios.length === 3 ? 'grid-cols-3' : 'grid-cols-2'}`}>
          {medios.map((m) => {
            const elegido = metodo === m.id;
            return (
              <button
                key={m.id}
                type="button"
                aria-pressed={elegido}
                onClick={() => {
                  setMetodo(m.id);
                  setError('');
                }}
                className={`relative rounded-lg border-2 px-2 py-1.5 text-left text-[11px] transition-all cursor-pointer ${elegido ? m.elegido : `${m.normal} opacity-80 hover:opacity-100`}`}
              >
                {elegido && <CheckCircle2 className="absolute right-1 top-1 h-3.5 w-3.5" aria-hidden="true" />}
                <span className="block font-extrabold">{m.nombre}</span>
                <span className="block text-[9px] opacity-90">{m.detalle}</span>
              </button>
            );
          })}
        </div>
      </div>
      {metodo === 'transferencia' && (
        <AvisoPlazoTransferencia
          id={`chk-plazo-${idUnico}`}
          aceptado={aceptaPlazo}
          onCambiar={(v) => {
            setAceptaPlazo(v);
            if (v) setFaltaPlazo(false);
          }}
          resaltar={faltaPlazo}
        />
      )}
      {error && <p role="alert" className="text-[11px] font-semibold text-red-600">{error}</p>}
      <button
        type="button"
        onClick={() => void pagar()}
        disabled={enviando || deshabilitado}
        className={`w-full px-4 py-2.5 ${colorBoton || 'bg-slate-900 hover:bg-slate-800 text-white'} disabled:opacity-60 font-bold text-xs rounded-xl shadow-xs cursor-pointer transition-colors flex items-center justify-center gap-1.5`}
      >
        {enviando ? <Loader2 className="w-4 h-4 animate-spin" /> : <CreditCard className="w-4 h-4" />}
        <span>{metodo === 'transferencia' ? textoBoton.replace(/^Pagar/, 'Confirmar por transferencia') : textoBoton}</span>
      </button>
    </div>
  );
}
