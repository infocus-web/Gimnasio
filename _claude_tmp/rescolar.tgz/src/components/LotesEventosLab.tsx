import { useCallback, useEffect, useRef, useState } from 'react';
import { Archive, CheckCircle2, ChevronDown, FileSpreadsheet, FolderDown, Loader2, PartyPopper } from 'lucide-react';
import { fetchLab, SesionLabVencida } from '../services/laboratorioService';

/**
 * Lotes de EVENTOS (comuniones, actos) dentro del panel del laboratorio (pedido de Pablo, 2/10/2026:
 * "que el laboratorio tenga un mismo panel de acceso"). Habla sólo con /api/eventos/lab/... (módulo de
 * eventos, función aparte) usando la misma sesión del laboratorio. Si no hay lotes de eventos, no se ve.
 */
interface LoteEvento {
  id: string;
  numero: number;
  estado: 'armado' | 'en_laboratorio' | 'terminado';
  creado_en: string;
  fecha_terminado: string | null;
  evento: { nombre: string; codigo: string } | null;
  pedidos: number;
  anulados?: number;
  copias15x21: number;
  copias20x30: number;
}

interface ArchivoManifiesto {
  carpeta: string;
  nombre: string;
  url: string | null;
}

/** Lote grande que se baja en partes (cada una con su botón). */
interface PlanZip {
  lote: LoteEvento;
  partes: string[][];
  porUrl: Map<string, ArchivoManifiesto[]>;
  total: number;
  sinOriginal: string[];
  /** Partes ya bajadas → archivos que faltaron en cada una. */
  faltanPorParte: Record<number, string[]>;
}

const ESTADOS: Record<LoteEvento['estado'], [string, string]> = {
  armado: ['Nuevo', 'bg-amber-100 text-amber-800'],
  en_laboratorio: ['Descargado', 'bg-violet-100 text-violet-800'],
  terminado: ['Terminado', 'bg-emerald-100 text-emerald-800'],
};

function guardarBlob(blob: Blob, nombre: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = nombre;
  document.body.appendChild(a);
  a.click();
  setTimeout(() => {
    URL.revokeObjectURL(url);
    a.remove();
  }, 5000);
}

async function leerJson(res: Response) {
  const data = await res.json().catch(() => null);
  if (!res.ok || !data?.success) throw new Error(data?.error || 'Algo salió mal. Probá de nuevo.');
  return data;
}

interface Props {
  onError: (e: unknown) => void;
  recargarCon?: unknown;
  /** Avisa cuántos lotes de eventos faltan terminar (para el contador de la pestaña). */
  onPendientes?: (n: number) => void;
  /** Si no hay lotes, muestra un cartel en vez de no mostrar nada (dentro de la pestaña "Eventos"). */
  mostrarVacio?: boolean;
}

export default function LotesEventosLab({ onError, recargarCon, onPendientes, mostrarVacio = false }: Props) {
  const [lotes, setLotes] = useState<LoteEvento[]>([]);
  const [trabajando, setTrabajando] = useState<string | null>(null);
  const [progreso, setProgreso] = useState('');
  // Los lotes terminados pasan solos al archivo (pedido de Pablo, 2/10: "que no se junten con los nuevos").
  const [verArchivo, setVerArchivo] = useState(false);
  // onError viene del panel sin memoizar: se guarda en una ref para no recargar en cada render.
  const refError = useRef(onError);
  refError.current = onError;
  const refPendientes = useRef(onPendientes);
  refPendientes.current = onPendientes;
  // Auditoría 02/10: los errores de eventos se muestran acá adentro (antes salían en todas las pestañas
  // del panel y parecía que fallaban los pedidos de los colegios). Sólo la sesión vencida sube al panel.
  const [errorLocal, setErrorLocal] = useState('');
  const [plan, setPlan] = useState<PlanZip | null>(null);
  const avisarError = (e: unknown) => {
    if (e instanceof SesionLabVencida) refError.current(e);
    else setErrorLocal(e instanceof Error ? e.message : 'Algo salió mal con los lotes de eventos.');
  };

  const cargar = useCallback(async () => {
    try {
      const data = await leerJson(await fetchLab('/api/eventos/lab/lotes'));
      const lista: LoteEvento[] = data.lotes || [];
      setLotes(lista);
      setErrorLocal('');
      refPendientes.current?.(lista.filter((l) => l.estado !== 'terminado').length);
    } catch (e) {
      if (e instanceof SesionLabVencida) refError.current(e);
      else setErrorLocal(e instanceof Error ? e.message : 'No se pudieron cargar los lotes de eventos.');
    }
  }, []);

  useEffect(() => {
    void cargar();
  }, [cargar, recargarCon]);

  const codigo = (l: LoteEvento) => l.evento?.codigo || 'evento';

  // Baja cada original una sola vez (aunque tenga varias copias) y arma el ZIP en el navegador.
  // Auditoría 02/10:
  // - Un lote grande se baja en partes de hasta 80 archivos (todo en un solo ZIP en memoria podía
  //   colgar la pestaña). Cada parte se baja con su propio botón: el navegador no bloquea descargas
  //   automáticas sin que nadie se entere.
  // - El lote se marca "descargado" sólo cuando se bajaron TODAS las partes y no faltó ningún archivo.
  const armarParte = async (plan: PlanZip, n: number): Promise<string[]> => {
    const JSZip = (await import('jszip')).default;
    const zip = new JSZip();
    const urls = plan.partes[n];
    const faltan: string[] = n === plan.partes.length - 1 ? [...plan.sinOriginal] : [];
    let i = 0;
    let hechos = 0;
    const etiqueta = plan.partes.length > 1 ? ` (parte ${n + 1} de ${plan.partes.length})` : '';
    const trabajador = async () => {
      while (i < urls.length) {
        const url = urls[i++];
        try {
          const r = await fetch(url);
          if (!r.ok) throw new Error(`HTTP ${r.status}`);
          const datos = await r.arrayBuffer();
          for (const a of plan.porUrl.get(url) || []) zip.file(`${a.carpeta}/${a.nombre}`, datos, { binary: true });
        } catch (e) {
          for (const a of plan.porUrl.get(url) || []) faltan.push(`${a.nombre} (${e instanceof Error ? e.message : 'error'})`);
        }
        hechos++;
        setProgreso(`Descargando originales: ${hechos} de ${urls.length}…${etiqueta}`);
      }
    };
    await Promise.all([trabajador(), trabajador(), trabajador(), trabajador()]);
    if (faltan.length) zip.file('FALTAN_ARCHIVOS.txt', `No se pudieron incluir:\r\n${faltan.join('\r\n')}`);
    setProgreso(`Armando el ZIP${etiqueta}…`);
    const blob = await zip.generateAsync({ type: 'blob', compression: 'STORE' });
    const sufijo = plan.partes.length > 1 ? `-parte-${n + 1}-de-${plan.partes.length}` : '';
    guardarBlob(blob, `Evento-${codigo(plan.lote)}-Lote-${plan.lote.numero}${sufijo}.zip`);
    return faltan;
  };

  const terminarSiCorresponde = async (plan: PlanZip) => {
    const faltan = Object.values(plan.faltanPorParte).flat();
    if (Object.keys(plan.faltanPorParte).length < plan.partes.length) {
      const quedan = plan.partes.length - Object.keys(plan.faltanPorParte).length;
      setProgreso(`✓ Parte bajada. ${quedan === 1 ? 'Falta 1 parte' : `Faltan ${quedan} partes`}: tocá «Bajar parte…» abajo.`);
      return;
    }
    if (faltan.length) {
      setProgreso(`⚠️ Faltaron ${faltan.length} archivo(s): mirá FALTAN_ARCHIVOS.txt dentro del ZIP y volvé a descargar. El lote NO se marcó como descargado.`);
    } else {
      await leerJson(await fetchLab(`/api/eventos/lab/lotes/${plan.lote.id}/estado`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ paso: 'descargado' }),
      }));
      setProgreso(`✓ Lote descargado completo (${plan.total} archivos${plan.partes.length > 1 ? ` en ${plan.partes.length} partes` : ''}).`);
    }
    setPlan(null);
    await cargar();
  };

  const descargarZip = async (lote: LoteEvento) => {
    setTrabajando(lote.id);
    setErrorLocal('');
    setPlan(null);
    setProgreso('Preparando la lista de archivos…');
    try {
      const data = await leerJson(await fetchLab(`/api/eventos/lab/lotes/${lote.id}/manifiesto`));
      const archivos: ArchivoManifiesto[] = data.archivos || [];
      if (archivos.length === 0) throw new Error('Este lote no tiene copias para imprimir.');
      const porUrl = new Map<string, ArchivoManifiesto[]>();
      for (const a of archivos) if (a.url) porUrl.set(a.url, [...(porUrl.get(a.url) || []), a]);
      const partes: string[][] = [];
      let actual: string[] = [];
      let enActual = 0;
      for (const url of porUrl.keys()) {
        const n = porUrl.get(url)?.length || 1;
        if (actual.length && enActual + n > 80) {
          partes.push(actual);
          actual = [];
          enActual = 0;
        }
        actual.push(url);
        enActual += n;
      }
      if (actual.length || partes.length === 0) partes.push(actual);
      const nuevo: PlanZip = {
        lote,
        partes,
        porUrl,
        total: archivos.length,
        sinOriginal: archivos.filter((a) => !a.url).map((a) => `${a.nombre} (sin original en el servidor)`),
        faltanPorParte: {},
      };
      nuevo.faltanPorParte[0] = await armarParte(nuevo, 0);
      if (partes.length > 1) setPlan(nuevo);
      await terminarSiCorresponde(nuevo);
    } catch (e) {
      setProgreso('');
      avisarError(e);
    } finally {
      setTrabajando(null);
    }
  };

  const descargarParte = async (n: number) => {
    if (!plan) return;
    setTrabajando(plan.lote.id);
    try {
      const faltan = await armarParte(plan, n);
      const actualizado: PlanZip = { ...plan, faltanPorParte: { ...plan.faltanPorParte, [n]: faltan } };
      setPlan(actualizado);
      await terminarSiCorresponde(actualizado);
    } catch (e) {
      avisarError(e);
    } finally {
      setTrabajando(null);
    }
  };

  const descargarExcel = async (lote: LoteEvento) => {
    setTrabajando(lote.id);
    try {
      const res = await fetchLab(`/api/eventos/lab/lotes/${lote.id}/excel`);
      if (!res.ok) throw new Error('No se pudo descargar el Excel.');
      guardarBlob(await res.blob(), `Evento-${codigo(lote)}-Lote-${lote.numero}.xlsx`);
    } catch (e) {
      avisarError(e);
    } finally {
      setTrabajando(null);
    }
  };

  const terminar = async (lote: LoteEvento) => {
    if (!window.confirm(`¿Terminaron de imprimir el lote ${lote.numero} de ${lote.evento?.nombre || 'evento'}? Le avisamos al fotógrafo.`)) return;
    setTrabajando(lote.id);
    try {
      await leerJson(await fetchLab(`/api/eventos/lab/lotes/${lote.id}/estado`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ paso: 'terminado' }),
      }));
      await cargar();
    } catch (e) {
      avisarError(e);
    } finally {
      setTrabajando(null);
    }
  };

  if (lotes.length === 0) {
    if (errorLocal && mostrarVacio) {
      return <p className="rounded-2xl border border-red-200 bg-red-50 px-4 py-3 text-sm font-semibold text-red-700">{errorLocal}</p>;
    }
    if (!mostrarVacio) return null;
    return (
      <section className="rounded-3xl border border-dashed border-sky-300 bg-white px-4 py-10 text-center shadow-sm">
        <PartyPopper className="mx-auto h-6 w-6 text-sky-500" />
        <p className="mt-2 font-['Outfit'] text-lg font-extrabold text-slate-900">Todavía no hay lotes de eventos</p>
        <p className="mt-1 text-sm text-slate-500">Cuando el fotógrafo arme un lote de una comunión o un acto, aparece acá para descargarlo.</p>
      </section>
    );
  }
  const pendientes = lotes.filter((l) => l.estado !== 'terminado').length;
  const fecha = (iso: string) => new Date(iso).toLocaleString('es-AR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' });

  const activos = lotes.filter((l) => l.estado !== 'terminado');
  const archivados = lotes.filter((l) => l.estado === 'terminado');
  const tarjeta = (l: LoteEvento) => {
          const [texto, color] = ESTADOS[l.estado] || [l.estado, 'bg-slate-100 text-slate-700'];
          const ocupado = trabajando !== null;
          return (
            <div key={l.id} className="flex flex-wrap items-center gap-3 rounded-2xl border border-slate-200 bg-white p-4">
              <div className="min-w-[220px] flex-1">
                <p className="font-bold text-slate-900">
                  {l.evento?.nombre || 'Evento'} — Lote {l.numero}{' '}
                  <span className={`ml-1 rounded-full px-2 py-0.5 text-[11px] font-bold ${color}`}>{texto}</span>
                </p>
                <p className="text-xs text-slate-600">
                  Armado {fecha(l.creado_en)} · {l.pedidos} pedido(s) · 15x21: {l.copias15x21} · 20x30: {l.copias20x30}
                  {l.fecha_terminado ? ` · terminado ${fecha(l.fecha_terminado)}` : ''}
                </p>
                {(l.anulados || 0) > 0 && (
                  <p className="mt-1 text-xs font-bold text-red-700">⚠ {l.anulados} pedido(s) de este lote se anularon: no se incluyen en el ZIP ni en el Excel.</p>
                )}
              </div>
              <button type="button" onClick={() => void descargarZip(l)} disabled={ocupado} className="flex items-center gap-1.5 rounded-xl bg-amber-400 px-3 py-2 text-xs font-bold text-slate-950 hover:bg-amber-300 disabled:opacity-50">
                {trabajando === l.id ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <FolderDown className="h-3.5 w-3.5" />}
                Descargar ZIP
              </button>
              <button type="button" onClick={() => void descargarExcel(l)} disabled={ocupado} className="flex items-center gap-1.5 rounded-xl border border-slate-300 px-3 py-2 text-xs font-bold hover:bg-slate-50 disabled:opacity-50">
                <FileSpreadsheet className="h-3.5 w-3.5" /> Excel
              </button>
              {l.estado === 'en_laboratorio' && (
                <button type="button" onClick={() => void terminar(l)} disabled={ocupado} className="flex items-center gap-1.5 rounded-xl bg-emerald-600 px-3 py-2 text-xs font-bold text-white hover:bg-emerald-500 disabled:opacity-50">
                  <CheckCircle2 className="h-3.5 w-3.5" /> Marcar terminado
                </button>
              )}
            </div>
          );
  };

  return (
    <section className="rounded-3xl border border-sky-200 bg-gradient-to-br from-sky-50 via-white to-violet-50/60 p-5 shadow-sm sm:p-6">
      <div className="flex flex-wrap items-end justify-between gap-2">
        <div>
          <p className="flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-sky-800">
            <PartyPopper className="h-3.5 w-3.5" /> Eventos · comuniones y actos
          </p>
          <h2 className="font-['Outfit'] text-2xl font-black text-slate-900">Lotes de eventos</h2>
        </div>
        <p className="text-xs text-slate-600">
          {pendientes ? `${pendientes} sin terminar · ` : ''}Carpeta por tamaño, un archivo por copia
        </p>
      </div>
      {errorLocal && <p className="mt-3 rounded-2xl border border-red-200 bg-red-50 px-3 py-2 text-sm font-semibold text-red-700">{errorLocal}</p>}
      {progreso && <p className="mt-3 rounded-2xl bg-white px-3 py-2 text-sm font-semibold text-slate-700 shadow-sm">{progreso}</p>}
      {plan && (
        <div className="mt-3 rounded-2xl border border-amber-300 bg-amber-50 p-3">
          <p className="text-sm font-bold text-amber-900">
            {plan.lote.evento?.nombre || 'Evento'} — Lote {plan.lote.numero}: es grande, se baja en {plan.partes.length} partes.
          </p>
          <div className="mt-2 flex flex-wrap gap-2">
            {plan.partes.map((_, n) => {
              const bajada = plan.faltanPorParte[n] !== undefined;
              return (
                <button
                  key={n}
                  type="button"
                  onClick={() => void descargarParte(n)}
                  disabled={trabajando !== null}
                  className={`flex items-center gap-1.5 rounded-xl px-3 py-2 text-xs font-bold disabled:opacity-50 ${bajada ? 'border border-emerald-300 bg-white text-emerald-800' : 'bg-amber-400 text-slate-950 hover:bg-amber-300'}`}
                >
                  {bajada ? <CheckCircle2 className="h-3.5 w-3.5" /> : <FolderDown className="h-3.5 w-3.5" />}
                  {bajada ? `Parte ${n + 1} bajada (otra vez)` : `Bajar parte ${n + 1} de ${plan.partes.length}`}
                </button>
              );
            })}
          </div>
        </div>
      )}
      <div className="mt-4 space-y-3">
        {activos.length === 0 && (
          <p className="rounded-2xl border border-dashed border-slate-300 bg-white px-4 py-6 text-center text-sm text-slate-500">
            No hay lotes de eventos para imprimir. Los terminados están en el archivo.
          </p>
        )}
        {activos.map(tarjeta)}
      </div>
      {archivados.length > 0 && (
        <div className="mt-4 border-t border-slate-200 pt-3">
          <button
            type="button"
            aria-expanded={verArchivo}
            onClick={() => setVerArchivo((v) => !v)}
            className="flex w-full items-center gap-2 rounded-xl px-2 py-2 text-left text-sm font-bold text-slate-600 hover:bg-white"
          >
            <Archive className="h-4 w-4" />
            Archivados ({archivados.length})
            <span className="text-xs font-normal text-slate-500">· lotes terminados</span>
            <ChevronDown className={`ml-auto h-4 w-4 transition-transform ${verArchivo ? 'rotate-180' : ''}`} />
          </button>
          {verArchivo && <div className="mt-2 space-y-3 opacity-80">{archivados.map(tarjeta)}</div>}
        </div>
      )}
    </section>
  );
}
