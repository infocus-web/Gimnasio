import { Clock } from 'lucide-react';
import { PLAZO_TRANSFERENCIA_HORAS } from '../utils/plazoTransferencia';

interface Props {
  variante?: 'claro' | 'oscuro';
  /** Con casilla: la familia tiene que tildarla antes de confirmar un pedido por transferencia. */
  aceptado?: boolean;
  onCambiar?: (aceptado: boolean) => void;
  /** Se tocó confirmar sin tildar la casilla: se resalta en rojo. */
  resaltar?: boolean;
  id?: string;
}

/**
 * Aviso del plazo de la transferencia (pedido de Pablo 29/9): se muestra ANTES de confirmar un
 * pedido por transferencia, de forma destacada y con casilla obligatoria, para que la familia sepa
 * que si no sube el comprobante en 48 horas el pedido se cancela solo.
 */
export default function AvisoPlazoTransferencia({ variante = 'claro', aceptado, onCambiar, resaltar = false, id = 'chk-plazo-transferencia' }: Props) {
  const oscuro = variante === 'oscuro';
  const conCasilla = typeof onCambiar === 'function';
  const marcarRojo = conCasilla && resaltar && !aceptado;
  return (
    <div
      role="note"
      className={`rounded-xl border-2 p-3 text-left text-[11px] leading-relaxed ${
        oscuro ? 'border-orange-400/80 bg-orange-500/10 text-slate-100' : 'border-orange-400 bg-orange-50 text-slate-800'
      }`}
    >
      <p className={`mb-1 flex items-center gap-1.5 text-xs font-extrabold ${oscuro ? 'text-orange-300' : 'text-orange-800'}`}>
        <Clock className="h-4 w-4 shrink-0" aria-hidden="true" />
        Importante: tenés {PLAZO_TRANSFERENCIA_HORAS} horas para subir el comprobante
      </p>
      <p>
        Después de confirmar el pedido, hacé la transferencia y <strong>subí el comprobante desde la web dentro de las {PLAZO_TRANSFERENCIA_HORAS} horas</strong>.
        Si en ese plazo no lo recibimos, <strong>el pedido se cancela automáticamente</strong> y vas a tener que hacerlo de nuevo.
      </p>
      {conCasilla && (
        <label htmlFor={id} className={`mt-2 flex cursor-pointer items-start gap-2 rounded-lg p-2 ${oscuro ? 'bg-slate-900/60' : 'bg-white'} ${marcarRojo ? 'ring-2 ring-red-500' : ''}`}>
          <input
            id={id}
            type="checkbox"
            checked={Boolean(aceptado)}
            onChange={(e) => onCambiar?.(e.target.checked)}
            className="mt-0.5 h-4 w-4 shrink-0 cursor-pointer rounded accent-orange-500"
          />
          <span className={`font-semibold ${oscuro ? 'text-white' : 'text-slate-900'}`}>
            Entiendo que si no subo el comprobante en {PLAZO_TRANSFERENCIA_HORAS} horas, el pedido se cancela.
          </span>
        </label>
      )}
      {marcarRojo && (
        <p role="alert" className={`mt-1.5 text-xs font-bold ${oscuro ? 'text-red-300' : 'text-red-600'}`}>
          Tildá esta casilla para confirmar el pedido por transferencia.
        </p>
      )}
    </div>
  );
}
