import { useCallback, useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import { CalendarClock, Calculator, Check, ChevronLeft, ChevronRight, CheckCircle2, Copy, Ellipsis, Eye, FileSignature, Loader2, LogOut, Megaphone, Package, Printer, RefreshCw, School, Share2, Users, Wallet } from 'lucide-react';
import CampoPin from './CampoPin';

import PanelColegioFotoHermanos from './PanelColegioFotoHermanos';
import {
  cerrarSesionColegio,
  cerrarVistaPreviaColegio,
  ingresarColegio,
  leerVistaPreviaColegio,
  leerSesionColegio,
  marcarEntregadoColegio,
  obtenerDetalleComisionColegio,
  obtenerEntregasColegio,
  obtenerResumenColegio,
  SesionColegioVencida,
  TEXTO_ESTADO_ENTREGA,
  type ComisionColegio,
  type DetalleComisionColegio,
  type EntregaColegio,
  type ResumenColegio,
  type SesionColegio,
} from '../services/panelColegioService';
import { fechaCortaColegio, linkCompartirWhatsApp, mensajeColegio, MENSAJES_COLEGIO, type TipoMensajeColegio } from '../utils/mensajesColegio';
import { copiarAlPortapapeles } from '../utils/portapapeles';

/**
 * Panel propio del colegio (retratoescolar.com.ar/colegio?c=<codigo>). Pedido de Pablo, 10/10/2026: la
 * secretaría / dirección entra con un PIN de 6 números y ve su comisión (sin datos de las familias), el
 * avance por curso en números, mensajes para difundir y las entregas de los kits impresos, que puede
 * marcar como entregados. Plan en el proyecto: claude/panel-colegio-plan.md.
 */
type Pestana = 'resumen' | 'cursos' | 'difusion' | 'entregas' | 'hermanos';

const pesos = (n: number) => `$${Math.round(Number(n) || 0).toLocaleString('es-AR')}`;
const fechaHora = (iso: string | null) =>
  iso ? new Date(iso).toLocaleString('es-AR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit', timeZone: 'America/Argentina/Buenos_Aires' }) : '';
const fechaDia = (iso: string | null) =>
  iso ? new Date(iso).toLocaleDateString('es-AR', { day: '2-digit', month: '2-digit', year: 'numeric', timeZone: 'America/Argentina/Buenos_Aires' }) : '';

const COLOR_ESTADO: Record<EntregaColegio['estado'], string> = {
  falta_elegir_fotos: 'bg-violet-100 text-violet-800',
  en_espera: 'bg-orange-100 text-orange-800',
  pagado: 'bg-slate-200 text-slate-700',
  en_laboratorio: 'bg-sky-100 text-sky-800',
  listo: 'bg-amber-100 text-amber-900',
  entregado: 'bg-emerald-100 text-emerald-800',
};

// Cursos y Entregas: una sola lista que en el celular se ve como tarjetas y en la compu como tabla
// (sin scroll lateral que esconda el estado o el botón).
const GRILLA_CURSOS = 'sm:grid-cols-[minmax(0,2fr)_repeat(4,minmax(0,1fr))] sm:gap-3';
const GRILLA_ENTREGAS = 'sm:grid-cols-[2.5rem_minmax(0,1.3fr)_minmax(0,1.6fr)_6.5rem_minmax(0,1.3fr)_9.5rem]';

function CifrasCurso({ nomina, inscriptos, compraron, impresos }: { nomina: ReactNode; inscriptos: ReactNode; compraron: ReactNode; impresos: ReactNode }) {
  const cifras: [string, ReactNode][] = [
    ['Alumnos', nomina],
    ['Inscriptas', inscriptos],
    ['Compraron', compraron],
    ['Impresos', impresos],
  ];
  return (
    <dl className="mt-2 grid grid-cols-4 gap-1.5 sm:contents">
      {cifras.map(([texto, valor]) => (
        <div key={texto} className="rounded-lg bg-slate-100/70 px-1 py-1.5 text-center sm:bg-transparent sm:p-0 sm:text-right">
          <dt className="text-[10px] font-semibold uppercase tracking-wide text-slate-500 sm:hidden">{texto}</dt>
          <dd>{valor}</dd>
        </div>
      ))}
    </dl>
  );
}

// ---------------------------------------------------------------------------------------------
// Tarjeta de la comisión: a la vista, sólo el monto que se lleva el colegio (pedido de Pablo, 10/10).
// El detalle del cálculo, sólo si lo piden desde el menú «⋯» de la esquina: recién ahí se pide al servidor.
// ---------------------------------------------------------------------------------------------
const GRILLA_DETALLE = 'sm:grid-cols-[minmax(0,1fr)_6.5rem_minmax(0,1.5fr)_minmax(0,1fr)_minmax(0,1fr)]';

function TarjetaComision({ sesion, comision, alFallar }: { sesion: SesionColegio; comision: ComisionColegio; alFallar: (e: unknown) => void }) {
  const [menuAbierto, setMenuAbierto] = useState(false);
  const [verDetalle, setVerDetalle] = useState(false);
  const [detalle, setDetalle] = useState<DetalleComisionColegio | null>(null);
  const [detalleCargado, setDetalleCargado] = useState(false);
  const [cargando, setCargando] = useState(false);
  const [errorDetalle, setErrorDetalle] = useState('');
  const [verPedidos, setVerPedidos] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  // El menú se cierra al tocar afuera o con Escape.
  useEffect(() => {
    if (!menuAbierto) return;
    const afuera = (ev: MouseEvent | TouchEvent) => {
      if (menuRef.current && !menuRef.current.contains(ev.target as Node)) setMenuAbierto(false);
    };
    const escape = (ev: KeyboardEvent) => {
      if (ev.key === 'Escape') setMenuAbierto(false);
    };
    document.addEventListener('mousedown', afuera);
    document.addEventListener('touchstart', afuera);
    document.addEventListener('keydown', escape);
    return () => {
      document.removeEventListener('mousedown', afuera);
      document.removeEventListener('touchstart', afuera);
      document.removeEventListener('keydown', escape);
    };
  }, [menuAbierto]);

  // «Actualizar» trae una comisión nueva: el detalle viejo ya no corresponde, se cierra.
  useEffect(() => {
    setVerDetalle(false);
    setDetalle(null);
    setDetalleCargado(false);
    setErrorDetalle('');
    setVerPedidos(false);
  }, [comision]);

  const traerDetalle = async () => {
    setCargando(true);
    setErrorDetalle('');
    try {
      setDetalle(await obtenerDetalleComisionColegio(sesion));
      setDetalleCargado(true);
    } catch (e) {
      if (e instanceof SesionColegioVencida) alFallar(e);
      else setErrorDetalle((e as Error)?.message || 'No pudimos cargar el detalle.');
    } finally {
      setCargando(false);
    }
  };

  const alternarDetalle = () => {
    setMenuAbierto(false);
    if (verDetalle) {
      setVerDetalle(false);
      return;
    }
    setVerDetalle(true);
    if (!detalleCargado && !cargando) void traerDetalle();
  };

  return (
    <div className="relative rounded-3xl border border-amber-200 bg-gradient-to-br from-amber-50 via-white to-emerald-50/60 p-5 shadow-sm sm:p-6">
      <div ref={menuRef} className="absolute right-3 top-3 sm:right-4 sm:top-4">
        <button
          type="button"
          aria-label="Más opciones"
          aria-haspopup="menu"
          aria-expanded={menuAbierto}
          onClick={() => setMenuAbierto((v) => !v)}
          className="rounded-full p-2 text-slate-400 transition-colors hover:bg-amber-100/70 hover:text-slate-700"
        >
          <Ellipsis className="h-5 w-5" />
        </button>
        {menuAbierto && (
          <div role="menu" className="absolute right-0 z-10 mt-1 w-60 overflow-hidden rounded-xl border border-slate-200 bg-white py-1 shadow-lg">
            <button type="button" role="menuitem" onClick={alternarDetalle} className="flex w-full items-center gap-2 px-3 py-2.5 text-left text-sm text-slate-700 hover:bg-slate-50">
              <Calculator className="h-4 w-4 text-slate-400" />
              {verDetalle ? 'Ocultar el detalle' : 'Ver el detalle del cálculo'}
            </button>
          </div>
        )}
      </div>

      <p className="pr-10 text-xs font-bold uppercase tracking-wide text-amber-800">Comisión del colegio · temporada {comision.periodo.desde.slice(0, 4)}</p>
      <p className="mt-1 font-['Outfit'] text-4xl font-extrabold text-slate-900">{pesos(comision.participacion)}</p>
      <p className="mt-3 text-xs text-slate-500">Es una estimación que se actualiza con cada pago. Cierra el 31/12 y se paga como dice el convenio.</p>

      {verDetalle && (
        <div className="mt-4 border-t border-amber-200/70 pt-4">
          {cargando && (
            <p className="flex items-center gap-2 text-sm text-slate-500">
              <Loader2 className="h-4 w-4 animate-spin" /> Cargando el detalle…
            </p>
          )}
          {errorDetalle && (
            <p className="text-sm font-semibold text-red-600">
              {errorDetalle}{' '}
              <button type="button" onClick={() => void traerDetalle()} className="underline">
                Reintentar
              </button>
            </p>
          )}
          {detalleCargado && !detalle && <p className="text-sm text-slate-600">Todavía no hay pedidos para detallar.</p>}
          {detalle && (
            <>
              <p className="text-xs font-bold uppercase tracking-wide text-slate-500">
                Cómo se calcula · {detalle.pedidos} {detalle.pedidos === 1 ? 'pedido pagado' : 'pedidos pagados'}
              </p>
              <dl className="mt-3 grid gap-2 text-sm sm:grid-cols-2">
                {(
                  [
                    ['Cobrado a las familias', detalle.venta, ''],
                    ['Impresión del laboratorio', detalle.costoLaboratorio, '−'],
                    ['Comisiones de cobro (Mercado Pago, Nave)', detalle.comisionesCobro, '−'],
                    ['Impuestos', detalle.impuestos, '−'],
                    ...((detalle.gastosPlataforma ?? 0) > 0
                      ? ([['Gastos de la plataforma (hosting, base de datos, correos, servicios automatizados, dominio)', detalle.gastosPlataforma, '−']] as [string, number, string][])
                      : []),
                    ['Ganancia neta', detalle.gananciaNeta, '='],
                    [`Comisión del colegio (${detalle.porcentaje}%)`, detalle.participacion, '='],
                  ] as [string, number, string][]
                ).map(([texto, valor, signo], i, todas) => (
                  <div key={texto} className={`flex items-center justify-between gap-3 rounded-xl px-3 py-2 ${i === todas.length - 1 ? 'bg-amber-100/80' : 'bg-white/80'}`}>
                    <dt className={`min-w-0 ${i === todas.length - 1 ? 'font-bold text-amber-900' : 'text-slate-600'}`}>{texto}</dt>
                    <dd className="shrink-0 whitespace-nowrap font-bold text-slate-900">
                      {signo} {pesos(valor)}
                    </dd>
                  </div>
                ))}
              </dl>
              {detalle.pedidosConFotosPendientes > 0 && (
                <p className="mt-2 text-xs text-slate-500">
                  {detalle.pedidosConFotosPendientes === 1
                    ? '1 pedido pagado por adelantado todavía no eligió las fotos: su costo de impresión puede cambiar.'
                    : `${detalle.pedidosConFotosPendientes} pedidos pagados por adelantado todavía no eligieron las fotos: su costo de impresión puede cambiar.`}
                </p>
              )}
              {detalle.detalle.length > 0 && (
                <button type="button" onClick={() => setVerPedidos((v) => !v)} className="mt-3 text-xs font-bold text-amber-800 underline">
                  {verPedidos ? 'Ocultar los pedidos' : `Ver los pedidos (${detalle.detalle.length})`}
                </button>
              )}
              {verPedidos && (
                <div className="mt-2 overflow-hidden rounded-2xl border border-slate-200 bg-white text-xs">
                  <div className={`hidden gap-3 bg-slate-50 px-3 py-2 text-[10px] font-bold uppercase tracking-wider text-slate-500 sm:grid ${GRILLA_DETALLE}`} aria-hidden="true">
                    <span>Pedido</span>
                    <span>Pagado</span>
                    <span>Curso</span>
                    <span className="text-right">Cobrado</span>
                    <span className="text-right">Ganancia neta</span>
                  </div>
                  <ul className="divide-y divide-slate-100">
                    {detalle.detalle.map((d) => (
                      <li key={d.pedido} className={`px-3 py-2 sm:grid sm:items-center sm:gap-3 ${GRILLA_DETALLE}`}>
                        <div className="flex items-baseline justify-between gap-2 sm:contents">
                          <span className="font-mono font-bold text-slate-900">{d.pedido}</span>
                          <span className="text-slate-500">{fechaDia(d.pagado)}</span>
                        </div>
                        <span className="block text-slate-600">{d.curso}</span>
                        <div className="mt-1 flex justify-between gap-3 sm:mt-0 sm:contents">
                          <span className="sm:text-right">
                            <span className="text-slate-500 sm:hidden">Cobrado </span>
                            {pesos(d.venta)}
                          </span>
                          <span className="font-bold sm:text-right">
                            <span className="font-normal text-slate-500 sm:hidden">Ganancia neta </span>
                            {pesos(d.gananciaNeta)}
                          </span>
                        </div>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </>
          )}
        </div>
      )}
    </div>
  );
}

function codigoDeLaUrl(): string {
  if (typeof window === 'undefined') return '';
  return (new URLSearchParams(window.location.search).get('c') || '').trim().toUpperCase();
}

/** /colegio?vista=1: la vista previa que abre Pablo desde su panel (Colegios → Panel del colegio). */
function esVistaPrevia(): boolean {
  if (typeof window === 'undefined') return false;
  return new URLSearchParams(window.location.search).get('vista') === '1';
}

export default function PanelColegio() {
  const codigo = useMemo(codigoDeLaUrl, []);
  const vistaPrevia = useMemo(esVistaPrevia, []);
  const [sesion, setSesion] = useState<SesionColegio | null>(() =>
    vistaPrevia ? leerVistaPreviaColegio() : codigo ? leerSesionColegio(codigo) : null
  );
  const [pin, setPin] = useState('');
  const [errorLogin, setErrorLogin] = useState('');
  const [linkConvenio, setLinkConvenio] = useState<string | null>(null);
  const [ingresando, setIngresando] = useState(false);

  const [resumen, setResumen] = useState<ResumenColegio | null>(null);
  const [entregas, setEntregas] = useState<EntregaColegio[]>([]);
  const [cargando, setCargando] = useState(false);
  const [error, setError] = useState('');
  const [pestana, setPestana] = useState<Pestana>('resumen');
  const [cursoEntregas, setCursoEntregas] = useState('');
  const [marcando, setMarcando] = useState<string | null>(null);
  const [tipoMensaje, setTipoMensaje] = useState<TipoMensajeColegio>('inscripcion');
  const [cursoDifusion, setCursoDifusion] = useState('');
  const [copiado, setCopiado] = useState(false);

  const manejarError = useCallback((e: unknown) => {
    if (e instanceof SesionColegioVencida) {
      setSesion(null);
      setErrorLogin(e.message);
      setLinkConvenio(e.linkConvenio);
      return;
    }
    setError((e as Error)?.message || 'Algo salió mal. Probá de nuevo.');
  }, []);

  const cargar = useCallback(async () => {
    if (!sesion) return;
    setCargando(true);
    setError('');
    try {
      const [datos, lista] = await Promise.all([obtenerResumenColegio(sesion), obtenerEntregasColegio(sesion)]);
      setResumen(datos);
      setEntregas(lista);
    } catch (e) {
      manejarError(e);
    } finally {
      setCargando(false);
    }
  }, [sesion, manejarError]);

  useEffect(() => {
    void cargar();
  }, [cargar]);

  const ingresar = async (ev: React.FormEvent) => {
    ev.preventDefault();
    setIngresando(true);
    setErrorLogin('');
    setLinkConvenio(null);
    const resultado = await ingresarColegio(codigo, pin);
    setIngresando(false);
    if (!resultado.success || !resultado.sesion) {
      setErrorLogin(resultado.error || 'No se pudo entrar. Probá de nuevo.');
      setLinkConvenio(resultado.linkConvenio || null);
      return;
    }
    setPin('');
    setSesion(resultado.sesion);
  };

  // Entregas agrupadas por curso, en el orden en que llegan (curso y número de lista).
  const cursosEntregas = useMemo(() => {
    const porCurso = new Map<string, { clave: string; etiqueta: string; filas: EntregaColegio[] }>();
    for (const e of entregas) {
      const grupo = porCurso.get(e.curso) || { clave: e.curso, etiqueta: e.cursoEtiqueta, filas: [] };
      grupo.filas.push(e);
      porCurso.set(e.curso, grupo);
    }
    const orden = new Map((resumen?.cursos || []).map((c, i) => [c.clave, i]));
    return [...porCurso.values()].sort((a, b) => (orden.get(a.clave) ?? 999) - (orden.get(b.clave) ?? 999) || a.etiqueta.localeCompare(b.etiqueta));
  }, [entregas, resumen]);
  const cursoElegido = cursosEntregas.find((c) => c.clave === cursoEntregas) || cursosEntregas[0] || null;

  const marcarEntregado = async (e: EntregaColegio) => {
    if (!sesion) return;
    if (sesion.vistaPrevia) {
      setError('Es la vista previa: desde acá no se marcan entregas (sólo el colegio, desde su panel).');
      return;
    }
    if (!window.confirm(`¿Marcar como entregado el kit de ${e.alumno} (${e.codigoSobre || e.pedido})?`)) return;
    setMarcando(e.pedido);
    try {
      const { entregadoAt } = await marcarEntregadoColegio(sesion, e.pedido);
      setEntregas((prev) => prev.map((x) => (x.pedido === e.pedido ? { ...x, estado: 'entregado', entregadoAt: entregadoAt || x.entregadoAt || new Date().toISOString(), entregadoPor: 'colegio' } : x)));
    } catch (err) {
      manejarError(err);
    } finally {
      setMarcando(null);
    }
  };

  if (vistaPrevia && !sesion) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-slate-950 p-4">
        <div className="w-full max-w-sm space-y-2 rounded-2xl bg-white p-6 text-center shadow-xl">
          <Eye className="mx-auto h-8 w-8 text-amber-500" />
          <h1 className="font-['Outfit'] text-lg font-extrabold text-slate-900">Vista previa del panel del colegio</h1>
          <p className="text-sm text-slate-600">
            {errorLogin || 'La vista previa venció o no se abrió desde tu panel.'} Abrila desde tu panel → Colegios → «Panel del colegio» → «Ver cómo lo ve el colegio».
          </p>
        </div>
      </div>
    );
  }

  if (!codigo && !vistaPrevia) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-slate-950 p-4">
        <div className="w-full max-w-sm space-y-2 rounded-2xl bg-white p-6 text-center shadow-xl">
          <School className="mx-auto h-8 w-8 text-amber-500" />
          <h1 className="font-['Outfit'] text-lg font-extrabold text-slate-900">Panel del colegio</h1>
          <p className="text-sm text-slate-600">El link está incompleto. Abrí el link completo que te mandó el fotógrafo.</p>
        </div>
      </div>
    );
  }

  if (!sesion) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-slate-950 p-4">
        <form onSubmit={ingresar} className="w-full max-w-sm space-y-4 rounded-2xl bg-white p-6 shadow-xl">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-amber-400">
              <School className="h-5 w-5 text-slate-950" />
            </div>
            <div>
              <h1 className="font-['Outfit'] text-lg font-extrabold text-slate-900">Panel del colegio</h1>
              <p className="text-xs text-slate-500">Retrato Escolar</p>
            </div>
          </div>
          <p className="text-xs text-slate-600">Ingresá el PIN de 6 números que te dio el fotógrafo. En este dispositivo queda abierto 7 días.</p>
          <CampoPin
            inputMode="numeric"
            maxLength={6}
            value={pin}
            onChange={(e) => setPin(e.target.value.replace(/\D/g, '').slice(0, 6))}
            placeholder="PIN"
            aria-label="PIN del colegio"
            className="w-full rounded-xl border border-slate-300 px-4 py-3 text-center text-lg font-bold tracking-[0.4em]"
            autoFocus
          />
          {errorLogin && !linkConvenio && <p className="text-xs font-semibold text-red-600">{errorLogin}</p>}
          {linkConvenio && (
            <div className="space-y-2 rounded-xl border border-amber-300 bg-amber-50 p-3">
              <p className="flex items-start gap-2 text-sm font-semibold text-amber-900">
                <FileSignature className="mt-0.5 h-4 w-4 shrink-0" />
                {errorLogin}
              </p>
              <p className="text-xs text-amber-800">Firmalo online y después volvé a entrar con el mismo PIN.</p>
              <a
                href={linkConvenio}
                target="_blank"
                rel="noopener noreferrer"
                className="flex w-full items-center justify-center gap-2 rounded-xl bg-slate-900 py-2.5 text-sm font-bold text-white hover:bg-slate-800"
              >
                <FileSignature className="h-4 w-4" />
                Leer y firmar el convenio
              </a>
            </div>
          )}
          <button
            type="submit"
            disabled={ingresando || pin.length !== 6}
            className="flex w-full items-center justify-center gap-2 rounded-xl bg-amber-400 py-3 text-sm font-bold text-slate-950 hover:bg-amber-300 disabled:opacity-50"
          >
            {ingresando && <Loader2 className="h-4 w-4 animate-spin" />}
            Ingresar
          </button>
          <p className="text-[11px] text-slate-500">¿Te olvidaste el PIN? Pedíselo al fotógrafo: te da uno nuevo al instante.</p>
        </form>
      </div>
    );
  }

  const comision = resumen?.comision || null;
  const totalCursos = (resumen?.cursos || []).reduce(
    (acc, c) => ({ nomina: acc.nomina + c.nomina, inscriptos: acc.inscriptos + c.inscriptos, compraron: acc.compraron + c.compraron, impresos: acc.impresos + c.impresos }),
    { nomina: 0, inscriptos: 0, compraron: 0, impresos: 0 }
  );
  const listos = entregas.filter((e) => e.estado === 'listo').length;
  const cursoDifusionEtiqueta = (resumen?.cursos || []).find((c) => c.clave === cursoDifusion)?.etiqueta || '';
  const textoMensaje = resumen
    ? mensajeColegio(tipoMensaje, {
        colegioNombre: resumen.colegio.nombre,
        curso: cursoDifusionEtiqueta,
        fechas: resumen.fechas,
        urlSitio: resumen.difusion.urlSitio,
        urlInscripcion: resumen.difusion.urlInscripcion,
      })
    : '';

  const pestanas: [Pestana, string, typeof Wallet, number | null][] = [
    ['resumen', 'Comisión', Wallet, null],
    ['cursos', 'Cursos', Users, null],
    ['difusion', 'Difusión', Megaphone, null],
    ['entregas', 'Entregas', Package, listos || null],
    ['hermanos', 'Hermanos', CalendarClock, null], // 26/10: foto de hermanos con día y horario
  ];

  return (
    <div className="min-h-screen bg-slate-100 text-slate-900">
      <header className="sticky top-0 z-20 bg-gradient-to-r from-slate-950 via-slate-900 to-slate-800 text-white shadow-lg print:hidden">
        <div className="mx-auto flex max-w-6xl flex-wrap items-center gap-3 px-4 py-3 sm:px-6">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-amber-400 shadow-md shadow-amber-500/30">
            <School className="h-5 w-5 text-slate-950" />
          </div>
          <div className="mr-auto min-w-0">
            <p className="truncate font-['Outfit'] text-lg font-extrabold leading-tight">{resumen?.colegio.nombre || sesion.colegioNombre || 'Panel del colegio'}</p>
            <p className="text-xs text-slate-400">Panel del colegio · Retrato Escolar</p>
          </div>
          <button type="button" onClick={() => void cargar()} className="flex items-center gap-1.5 rounded-xl bg-white/10 px-3 py-2 text-xs font-bold hover:bg-white/20">
            <RefreshCw className={`h-3.5 w-3.5 ${cargando ? 'animate-spin' : ''}`} />
            Actualizar
          </button>
          <button
            type="button"
            onClick={() => {
              if (sesion.vistaPrevia) cerrarVistaPreviaColegio();
              else cerrarSesionColegio();
              setErrorLogin(sesion.vistaPrevia ? 'Cerraste la vista previa.' : '');
              setSesion(null);
              setResumen(null);
              setEntregas([]);
            }}
            className="flex items-center gap-1.5 rounded-xl bg-white/10 px-3 py-2 text-xs font-bold hover:bg-white/20"
          >
            <LogOut className="h-3.5 w-3.5" />
            Salir
          </button>
        </div>
      </header>

      <main className="mx-auto max-w-6xl space-y-5 px-4 py-5 sm:px-6 print:hidden">
        {sesion.vistaPrevia && (
          <p className="flex items-start gap-2 rounded-2xl border border-sky-200 bg-sky-50 p-3 text-sm text-sky-900">
            <Eye className="mt-0.5 h-4 w-4 shrink-0" />
            <span>
              <strong>Vista previa (sólo la ves vos).</strong> Así ve el panel el colegio, con sus datos reales. Desde acá no se marcan entregas. Dura 2 horas.
            </span>
          </p>
        )}
        {error && <p className="rounded-2xl border border-red-200 bg-red-50 p-3 text-sm font-semibold text-red-700">{error}</p>}
        {!resumen && cargando && (
          <p className="flex items-center gap-2 rounded-2xl bg-white p-4 text-sm text-slate-600">
            <Loader2 className="h-4 w-4 animate-spin" /> Cargando…
          </p>
        )}

        {resumen && (
          <>
            <nav className="grid grid-cols-5 gap-1 rounded-2xl border border-slate-200 bg-white p-1.5 shadow-sm sm:flex sm:gap-1.5" role="tablist" aria-label="Secciones del panel">
              {pestanas.map(([id, texto, Icono, contador]) => {
                const activa = pestana === id;
                return (
                  <button
                    key={id}
                    type="button"
                    role="tab"
                    aria-selected={activa}
                    onClick={() => setPestana(id)}
                    className={`flex min-w-0 flex-col items-center gap-1 rounded-xl px-1 py-2 text-[11px] font-bold transition-colors sm:shrink-0 sm:flex-row sm:gap-2 sm:px-3.5 sm:text-sm ${activa ? 'bg-slate-900 text-white shadow-md' : 'text-slate-600 hover:bg-slate-100'}`}
                  >
                    <Icono className="h-4 w-4" />
                    <span className="flex items-center gap-1">
                      {texto}
                      {contador ? <span className="rounded-full bg-amber-400 px-1.5 py-0.5 text-[10px] leading-none text-slate-950">{contador}</span> : null}
                    </span>
                  </button>
                );
              })}
            </nav>

            {pestana === 'resumen' && (
              <section className="space-y-4">
                {comision && sesion ? (
                  <TarjetaComision sesion={sesion} comision={comision} alFallar={manejarError} />
                ) : (
                  <p className="rounded-2xl border border-slate-200 bg-white p-4 text-sm text-slate-600">Todavía no hay pedidos pagados esta temporada.</p>
                )}

                <div className="grid gap-4 sm:grid-cols-2">
                  <div className="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm">
                    <p className="flex items-center gap-2 text-sm font-extrabold text-slate-900">
                      <FileSignature className="h-4 w-4 text-amber-600" /> Convenio
                    </p>
                    {resumen.convenio.firmado ? (
                      <p className="mt-2 text-sm text-slate-600">
                        Firmado el {fechaDia(resumen.convenio.fecha)}. Participación del colegio: <strong>{resumen.convenio.porcentaje}%</strong> (cláusula OCTAVA BIS).
                      </p>
                    ) : (
                      <p className="mt-2 text-sm text-slate-600">Todavía no está firmado. Pedile el link del convenio al fotógrafo.</p>
                    )}
                  </div>
                  <div className="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm">
                    <p className="flex items-center gap-2 text-sm font-extrabold text-slate-900">
                      <Megaphone className="h-4 w-4 text-amber-600" /> Fechas de la campaña
                    </p>
                    <ul className="mt-2 space-y-1 text-sm text-slate-600">
                      <li>Toma de fotos: <strong>{fechaCortaColegio(resumen.fechas.tomaFotos) || 'a confirmar'}</strong></li>
                      <li>Cierre de pedidos: <strong>{fechaCortaColegio(resumen.fechas.cierrePedidos) || 'a confirmar'}</strong></li>
                      <li>Entrega de kits: <strong>{fechaCortaColegio(resumen.fechas.entregaKits) || 'a confirmar'}</strong></li>
                    </ul>
                  </div>
                </div>
              </section>
            )}

            {pestana === 'cursos' && (
              <section className="space-y-3">
                <p className="text-sm text-slate-600">Cómo viene cada curso, sólo en números: no mostramos quién compró ni cuánto pagó.</p>
                <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white text-sm shadow-sm">
                  <div className={`hidden bg-slate-50 px-4 py-3 text-[10px] font-bold uppercase tracking-wider text-slate-500 sm:grid ${GRILLA_CURSOS}`} aria-hidden="true">
                    <span>Curso</span>
                    <span className="text-right">Alumnos</span>
                    <span className="text-right">Familias inscriptas</span>
                    <span className="text-right">Compraron</span>
                    <span className="text-right">Kits impresos</span>
                  </div>
                  <ul className="divide-y divide-slate-100">
                    {resumen.cursos.map((c) => {
                      const pct = c.nomina > 0 ? Math.min(100, Math.round((c.inscriptos / c.nomina) * 100)) : null;
                      return (
                        <li key={c.clave} data-curso={c.clave} className={`px-4 py-3 sm:grid sm:items-center sm:py-2.5 ${GRILLA_CURSOS}`}>
                          <p className="font-bold text-slate-900">{c.etiqueta}</p>
                          <CifrasCurso
                            nomina={c.nomina ? String(c.nomina) : '—'}
                            inscriptos={
                              <>
                                {c.inscriptos}
                                {pct !== null && <span className="ml-1 text-xs font-normal text-slate-400">({pct}%)</span>}
                              </>
                            }
                            compraron={c.compraron}
                            impresos={c.impresos}
                          />
                        </li>
                      );
                    })}
                    <li data-curso="total" className={`bg-slate-50 px-4 py-3 font-extrabold sm:grid sm:items-center sm:py-2.5 ${GRILLA_CURSOS}`}>
                      <p>Total del colegio</p>
                      <CifrasCurso nomina={totalCursos.nomina} inscriptos={totalCursos.inscriptos} compraron={totalCursos.compraron} impresos={totalCursos.impresos} />
                    </li>
                  </ul>
                </div>
              </section>
            )}

            {pestana === 'difusion' && (
              <section className="space-y-4">
                <p className="text-sm text-slate-600">
                  Elegí el mensaje y el curso, y compartilo en el grupo de WhatsApp de las familias. El código del curso no va en el mensaje: a cada familia le llega por email cuando se inscribe.
                </p>
                <div className="grid grid-cols-2 gap-2 sm:flex sm:flex-wrap" role="group" aria-label="Mensaje">
                  {MENSAJES_COLEGIO.map((m) => (
                    <button
                      key={m.tipo}
                      type="button"
                      aria-pressed={tipoMensaje === m.tipo}
                      onClick={() => setTipoMensaje(m.tipo)}
                      className={`rounded-2xl border px-3 py-2 text-left text-sm transition-colors ${tipoMensaje === m.tipo ? 'border-slate-900 bg-slate-900 text-white' : 'border-slate-300 bg-white text-slate-700 hover:bg-slate-50'}`}
                    >
                      <span className="block font-bold">{m.titulo}</span>
                      <span className={`block text-[11px] ${tipoMensaje === m.tipo ? 'text-slate-300' : 'text-slate-500'}`}>{m.cuando}</span>
                    </button>
                  ))}
                </div>
                <label className="block text-sm font-bold text-slate-700">
                  Curso
                  <select
                    value={cursoDifusion}
                    onChange={(e) => setCursoDifusion(e.target.value)}
                    className="mt-1 block w-full max-w-md rounded-xl border border-slate-300 bg-white px-3 py-2 text-sm font-normal"
                  >
                    <option value="">Todo el colegio</option>
                    {resumen.cursos.map((c) => (
                      <option key={c.clave} value={c.clave}>
                        {c.etiqueta}
                      </option>
                    ))}
                  </select>
                </label>
                <pre className="whitespace-pre-wrap rounded-2xl border border-slate-200 bg-white p-4 font-sans text-sm text-slate-800 shadow-sm">{textoMensaje}</pre>
                <div className="flex flex-wrap gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      void copiarAlPortapapeles(textoMensaje);
                      setCopiado(true);
                      window.setTimeout(() => setCopiado(false), 2000);
                    }}
                    className="flex items-center gap-2 rounded-xl border border-slate-300 bg-white px-4 py-2.5 text-sm font-bold hover:bg-slate-50"
                  >
                    {copiado ? <Check className="h-4 w-4 text-emerald-600" /> : <Copy className="h-4 w-4" />}
                    {copiado ? 'Copiado' : 'Copiar'}
                  </button>
                  <a
                    href={linkCompartirWhatsApp(textoMensaje)}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-2 rounded-xl bg-emerald-600 px-4 py-2.5 text-sm font-bold text-white hover:bg-emerald-500"
                  >
                    <Share2 className="h-4 w-4" />
                    Compartir por WhatsApp
                  </a>
                </div>
                {(!resumen.fechas.tomaFotos || !resumen.fechas.cierrePedidos || !resumen.fechas.entregaKits) && (
                  <p className="text-xs text-slate-500">Las fechas que falten las carga el fotógrafo; mientras tanto el mensaje sale sin fecha.</p>
                )}
              </section>
            )}

            {pestana === 'hermanos' && <PanelColegioFotoHermanos sesion={sesion} alFallar={manejarError} />}

            {pestana === 'entregas' && (
              <section className="space-y-4">
                {cursosEntregas.length === 0 ? (
                  <p className="rounded-2xl border border-slate-200 bg-white p-4 text-sm text-slate-600">Todavía no hay kits impresos pagados.</p>
                ) : (
                  <>
                    {/* 26/10 (Pablo: «esos botones enormes son horribles»): un selector por nivel en vez de un botón por curso. */}
                    {cursoElegido && (
                      <div className="space-y-2">
                        <SelectorCursoEntregas cursos={cursosEntregas} elegido={cursoElegido.clave} onElegir={setCursoEntregas} />
                        <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white text-sm shadow-sm">
                          <div className={`hidden gap-3 bg-slate-50 px-3 py-3 text-[10px] font-bold uppercase tracking-wider text-slate-500 sm:grid ${GRILLA_ENTREGAS}`} aria-hidden="true">
                            <span>N°</span>
                            <span>Alumno</span>
                            <span>Código del sobre</span>
                            <span>Kit</span>
                            <span>Estado</span>
                            <span></span>
                          </div>
                          <ul className="divide-y divide-slate-100">
                            {cursoElegido.filas.map((f) => (
                              <li key={f.pedido} data-pedido={f.pedido} className={`flex flex-col gap-1.5 px-4 py-3 sm:grid sm:items-center sm:gap-3 sm:px-3 sm:py-2.5 ${GRILLA_ENTREGAS}`}>
                                <div className="flex items-baseline gap-2 sm:contents">
                                  <span className="w-6 shrink-0 text-slate-500">{f.numeroLista ?? '—'}</span>
                                  <span className="min-w-0 font-bold text-slate-900">{f.alumno}</span>
                                </div>
                                <span className="pl-8 font-mono text-[11px] text-slate-500 break-all sm:pl-0 sm:text-xs sm:text-slate-700">{f.codigoSobre || f.pedido}</span>
                                <span className="pl-8 text-[11px] text-slate-500 sm:pl-0 sm:text-xs sm:text-slate-700">{f.kit}</span>
                                <div className="pl-8 sm:pl-0">
                                  <span className={`inline-block rounded-full px-2 py-0.5 text-[11px] font-bold ${COLOR_ESTADO[f.estado]}`}>{TEXTO_ESTADO_ENTREGA[f.estado]}</span>
                                  {f.estado === 'entregado' && f.entregadoAt && (
                                    <span className="block text-[10px] text-slate-400">
                                      {fechaHora(f.entregadoAt)}
                                      {f.entregadoPor === 'colegio' ? ' · por el colegio' : ''}
                                    </span>
                                  )}
                                </div>
                                <div className="pl-8 sm:pl-0 sm:text-right">
                                  {f.estado === 'listo' && (
                                    <button
                                      type="button"
                                      onClick={() => void marcarEntregado(f)}
                                      disabled={marcando === f.pedido}
                                      className="mt-1 inline-flex w-full items-center justify-center gap-1.5 rounded-xl bg-emerald-600 px-3 py-2.5 text-sm font-bold text-white hover:bg-emerald-500 disabled:opacity-50 sm:mt-0 sm:w-auto sm:py-1.5 sm:text-xs"
                                    >
                                      {marcando === f.pedido ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <CheckCircle2 className="h-3.5 w-3.5" />}
                                      Marcar entregado
                                    </button>
                                  )}
                                </div>
                              </li>
                            ))}
                          </ul>
                        </div>
                        <p className="text-xs text-slate-500">
                          «Marcar entregado» aparece cuando el kit llega al colegio (estado «Listo para entregar»). Si marcaste uno por error, avisale al fotógrafo.
                        </p>
                      </div>
                    )}
                  </>
                )}
              </section>
            )}
          </>
        )}
      </main>

      {/* Planilla para imprimir (sólo se ve al imprimir): el curso elegido en Entregas, con columna de firma. */}
      {cursoElegido && (
        <div className="hidden p-6 text-black print:block">
          <h1 className="text-lg font-bold">{resumen?.colegio.nombre} · Entrega de kits impresos</h1>
          <p className="mb-3 text-sm">
            {cursoElegido.etiqueta} · {new Date().toLocaleDateString('es-AR')}
          </p>
          <table className="w-full border-collapse text-sm">
            <thead>
              <tr>
                {['N°', 'Alumno', 'Código del sobre', 'Kit', 'Estado', 'Firma de quien recibe'].map((t) => (
                  <th key={t} className="border border-black px-2 py-1 text-left">
                    {t}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {cursoElegido.filas.map((f) => (
                <tr key={f.pedido}>
                  <td className="border border-black px-2 py-2">{f.numeroLista ?? ''}</td>
                  <td className="border border-black px-2 py-2">{f.alumno}</td>
                  <td className="border border-black px-2 py-2 font-mono text-xs">{f.codigoSobre || f.pedido}</td>
                  <td className="border border-black px-2 py-2">{f.kit}</td>
                  <td className="border border-black px-2 py-2">{TEXTO_ESTADO_ENTREGA[f.estado]}</td>
                  <td className="w-48 border border-black px-2 py-2"></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

/** 26/10: nivel del curso por su etiqueta («Sala 3 años…», «2° grado…», «4° año…»), para agrupar el selector. */
function nivelDeCurso(etiqueta: string): string {
  const e = etiqueta.toLowerCase();
  if (e.startsWith('sala')) return 'Nivel inicial';
  if (e.includes('grado')) return 'Primaria';
  if (/\baño\b/.test(e)) return 'Secundaria';
  return 'Otros';
}

/** 26/10: barra compacta de la pestaña Entregas: curso (agrupado por nivel), anterior/siguiente, avance e imprimir. */
function SelectorCursoEntregas({ cursos, elegido, onElegir }: { cursos: { clave: string; etiqueta: string; filas: EntregaColegio[] }[]; elegido: string; onElegir: (clave: string) => void }) {
  const indice = Math.max(0, cursos.findIndex((c) => c.clave === elegido));
  const actual = cursos[indice];
  const cuenta = (c: (typeof cursos)[number]) => ({
    entregados: c.filas.filter((f) => f.estado === 'entregado').length,
    listos: c.filas.filter((f) => f.estado === 'listo').length,
  });
  const niveles = [...new Set(cursos.map((c) => nivelDeCurso(c.etiqueta)))];
  const { entregados, listos } = cuenta(actual);
  const flecha = 'flex h-9 w-9 items-center justify-center rounded-lg border border-slate-300 bg-white text-slate-600 hover:bg-slate-50 disabled:opacity-40 disabled:cursor-not-allowed';
  return (
    <div className="flex flex-wrap items-center gap-x-3 gap-y-2 rounded-2xl border border-slate-200 bg-white p-3 shadow-sm">
      <label htmlFor="curso-entregas" className="sr-only">Curso</label>
      <div className="flex w-full min-w-0 items-center gap-1.5 lg:w-auto lg:flex-1">
        <button type="button" className={flecha} disabled={indice === 0} onClick={() => onElegir(cursos[indice - 1].clave)} aria-label="Curso anterior">
          <ChevronLeft className="h-4 w-4" />
        </button>
        <select
          id="curso-entregas"
          value={actual.clave}
          onChange={(e) => onElegir(e.target.value)}
          className="h-9 min-w-0 flex-1 truncate rounded-lg border border-slate-300 bg-white px-2.5 text-sm font-semibold text-slate-900 focus:border-amber-500 focus:outline-none focus:ring-2 focus:ring-amber-200"
        >
          {niveles.map((nivel) => (
            <optgroup key={nivel} label={nivel}>
              {cursos
                .filter((c) => nivelDeCurso(c.etiqueta) === nivel)
                .map((c) => {
                  const n = cuenta(c);
                  return (
                    <option key={c.clave} value={c.clave}>
                      {c.etiqueta} ({n.entregados}/{c.filas.length}){n.listos ? ` · ${n.listos} para entregar` : ''}
                    </option>
                  );
                })}
            </optgroup>
          ))}
        </select>
        <button type="button" className={flecha} disabled={indice === cursos.length - 1} onClick={() => onElegir(cursos[indice + 1].clave)} aria-label="Curso siguiente">
          <ChevronRight className="h-4 w-4" />
        </button>
      </div>
      <p className="text-xs text-slate-600">
        <strong className="text-slate-900">{entregados}</strong> de {actual.filas.length} entregados
        {listos ? <span className="ml-1.5 rounded-full bg-amber-100 px-2 py-0.5 font-bold text-amber-900">{listos} para entregar</span> : null}
      </p>
      <button type="button" onClick={() => window.print()} className="ml-auto flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs font-bold text-slate-700 hover:bg-slate-50">
        <Printer className="h-3.5 w-3.5" />
        Imprimir planilla
      </button>
    </div>
  );
}
