import { useEffect, useState } from 'react';
import { AlertTriangle, Loader2, RefreshCw, Save, Tag } from 'lucide-react';
import { cargarPreciosDelServidor, guardarPreciosAdmin, preciosVienenDelServidor, usePrecios, type PreciosSitio } from '../services/preciosService';

const CAMPOS: { clave: keyof PreciosSitio; nombre: string; ayuda: string }[] = [
  { clave: 'kitClasico', nombre: 'Kit Impreso + Digital', ayuda: 'Carpeta con las 3 fotos impresas + descarga HD.' },
  { clave: 'kitDigital', nombre: 'Solo Digital HD', ayuda: 'Las 3 fotos en alta resolución, sin impresión.' },
  { clave: 'carpetaExtra', nombre: 'Copia extra de la carpeta', ayuda: 'Cada copia adicional (sólo con el Kit Impreso).' },
  { clave: 'fotoEvento', nombre: 'Foto suelta ("Otras Fotos")', ayuda: 'Cada toma extra que se suma a la compra.' },
  { clave: 'extra15x21', nombre: 'Foto extra 15x21', ayuda: 'Cada copia impresa que la familia pide aparte, con el kit ya pagado.' },
  { clave: 'extra20x30', nombre: 'Foto extra 20x30', ayuda: 'Cada copia impresa 20x30 que la familia pide aparte, con el kit ya pagado.' },
];

/**
 * Precios en un solo lugar (auditoría 28/9). Lo que se guarda acá lo usan la web, el cobro, los
 * emails y las respuestas de la IA. Los pedidos ya creados mantienen el precio con el que se hicieron.
 */
export default function AdminPreciosTab() {
  const precios = usePrecios();
  const [valores, setValores] = useState<Record<keyof PreciosSitio, string>>(() => aTexto(precios));
  const [guardando, setGuardando] = useState(false);
  const [mensaje, setMensaje] = useState<{ ok: boolean; texto: string } | null>(null);
  // Auditoría 03/10 noche (M7): si los precios no se pudieron leer del servidor, "Guardar" queda
  // bloqueado: se guardan los 4 juntos, y cambiar uno pisaría los otros 3 con los valores por
  // defecto de la web (no con los reales).
  const [estadoCarga, setEstadoCarga] = useState<'cargando' | 'ok' | 'error'>(() => (preciosVienenDelServidor() ? 'ok' : 'cargando'));

  const cargar = async (forzar = false) => {
    setEstadoCarga('cargando');
    // Si la relectura falla pero ya se tenían los del servidor de antes, se siguen usando esos.
    const ok = (await cargarPreciosDelServidor({ forzar })) || preciosVienenDelServidor();
    setEstadoCarga(ok ? 'ok' : 'error');
    if (ok) setValores(aTexto(precios));
  };

  useEffect(() => {
    void cargar(true);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const guardar = async () => {
    if (estadoCarga !== 'ok' || !preciosVienenDelServidor()) {
      setMensaje({ ok: false, texto: 'No se pudieron leer los precios del servidor: no se puede guardar. Tocá "Reintentar".' });
      return;
    }
    const nuevos = Object.fromEntries(CAMPOS.map((c) => [c.clave, Number(valores[c.clave].replace(/[^\d]/g, ''))])) as unknown as PreciosSitio;
    if (nuevos.kitClasico <= nuevos.kitDigital) {
      setMensaje({ ok: false, texto: 'El Kit Impreso tiene que costar más que el Solo Digital (la diferencia es lo que se cobra al pasar de uno a otro).' });
      return;
    }
    setGuardando(true);
    const r = await guardarPreciosAdmin(nuevos);
    setGuardando(false);
    setMensaje(r.success ? { ok: true, texto: 'Precios guardados. La web y el cobro ya usan los nuevos valores.' } : { ok: false, texto: r.error || 'No se pudieron guardar.' });
  };

  return (
    <div className="max-w-xl space-y-4">
      <div>
        <h3 className="flex items-center gap-2 text-lg font-extrabold text-slate-900 font-['Outfit']">
          <Tag className="h-5 w-5 text-amber-500" /> Precios
        </h3>
        <p className="text-xs text-slate-500">
          Un solo lugar para los precios: se actualizan en la web, en el cobro, en los emails y en las respuestas automáticas. Los pedidos ya hechos mantienen su precio.
        </p>
      </div>
      <div className="space-y-3 rounded-2xl border border-slate-200 bg-white p-4">
        {CAMPOS.map((c) => (
          <label key={c.clave} className="flex items-center justify-between gap-3">
            <span>
              <span className="block text-sm font-bold text-slate-800">{c.nombre}</span>
              <span className="block text-[11px] text-slate-500">{c.ayuda}</span>
            </span>
            <span className="flex items-center gap-1 text-sm font-bold text-slate-700">
              $
              <input
                inputMode="numeric"
                value={valores[c.clave]}
                onChange={(e) => setValores((v) => ({ ...v, [c.clave]: e.target.value }))}
                className="w-28 rounded-lg border border-slate-300 px-2.5 py-1.5 text-right font-mono"
              />
            </span>
          </label>
        ))}
      </div>
      {estadoCarga === 'error' && (
        <div role="alert" className="flex flex-wrap items-center gap-2 rounded-xl border border-red-200 bg-red-50 px-4 py-2.5 text-xs font-semibold text-red-700">
          <AlertTriangle className="h-4 w-4 shrink-0" />
          <span className="flex-1">
            No se pudieron leer los precios del servidor. Lo que ves son los valores por defecto de la web, no los vigentes: "Guardar" queda bloqueado para no pisarlos.
          </span>
          <button type="button" onClick={() => void cargar(true)} className="inline-flex items-center gap-1 rounded-lg border border-red-300 bg-white px-2.5 py-1 font-bold text-red-700 hover:bg-red-100">
            <RefreshCw className="h-3.5 w-3.5" /> Reintentar
          </button>
        </div>
      )}
      {estadoCarga === 'cargando' && (
        <p className="flex items-center gap-2 text-xs text-slate-500"><Loader2 className="h-3.5 w-3.5 animate-spin" /> Leyendo los precios vigentes del servidor…</p>
      )}
      {mensaje && <p className={`rounded-xl px-4 py-2.5 text-xs font-semibold ${mensaje.ok ? 'bg-emerald-50 text-emerald-800' : 'bg-red-50 text-red-700'}`}>{mensaje.texto}</p>}
      <button
        type="button"
        onClick={() => void guardar()}
        disabled={guardando || estadoCarga !== 'ok'}
        className="inline-flex items-center gap-2 rounded-xl bg-slate-900 px-5 py-2.5 text-sm font-bold text-white hover:bg-slate-800 disabled:opacity-60"
      >
        {guardando ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />} Guardar precios
      </button>
    </div>
  );
}

function aTexto(p: PreciosSitio): Record<keyof PreciosSitio, string> {
  return { kitClasico: String(p.kitClasico), kitDigital: String(p.kitDigital), carpetaExtra: String(p.carpetaExtra), fotoEvento: String(p.fotoEvento), extra15x21: String(p.extra15x21), extra20x30: String(p.extra20x30) };
}
