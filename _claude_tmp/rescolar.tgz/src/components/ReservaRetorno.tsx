import { useEffect, useState } from 'react';
import { CheckCircle2, Clock, Loader2, X, XCircle } from 'lucide-react';
import { volvioSinPagar } from '../utils/pagoRetorno';
import { crearPreferenciaMercadoPago, crearPreferenciaMercadoPagoMultiple, type DatosPreferenciaMercadoPago } from '../services/mercadoPagoService';
import { crearIntencionPagoNave, crearIntencionPagoNaveMultiple, type DatosIntencionNave } from '../services/naveService';
import { urlEstadoPedido } from '../utils/accesoPedido';
import { cambiarMetodoPagoPedido } from '../services/pedidosLabService';
import { useNaveHabilitado } from '../services/mediosPagoService';
import SubirComprobante from './SubirComprobante';
import AvisoPlazoTransferencia from './AvisoPlazoTransferencia';
import { fetchConTimeout } from '../utils/fetchConTimeout';
import { PLAZO_TRANSFERENCIA_HORAS } from '../utils/plazoTransferencia';

type Medio = 'mercadopago' | 'nave' | 'transferencia';

// Pedido de Pablo (25/9 y 28/9): cada medio con el color de su marca.
const MEDIOS: { id: Medio; label: string; clases: string }[] = [
  { id: 'mercadopago', label: 'Mercado Pago', clases: 'bg-[#009EE3] hover:bg-[#0087c2] text-white border-[#009EE3]' },
  { id: 'nave', label: 'Nave', clases: 'bg-violet-600 hover:bg-violet-700 text-white border-violet-600' },
  { id: 'transferencia', label: 'Transferencia', clases: 'bg-white hover:bg-slate-50 text-slate-800 border-slate-300' },
];

interface Props {
  /** Pago de un grupo (reserva o carrito de hermanos). */
  grupoPagoId?: string;
  /** Pedido suelto, sin grupo de pago (sólo llega desde el email de recordatorio). */
  pedidoIdSuelto?: string;
  /**
   * Vino del email de recordatorio de pago pendiente (?pago_pendiente=1, pedido de Pablo 28/9):
   * no hay un pago en curso que esperar, así que se muestra el estado apenas responde el servidor
   * y, si es por transferencia, directamente los datos y la subida del comprobante.
   */
  recordatorio?: boolean;
  onCerrar: () => void;
  /** Reabre el portal (reserva) para elegir otro medio de pago. */
  onElegirOtroMedio?: () => void;
}

// 17/10/2026: 'no_encontrado' = el pedido ya no existe (borrado o link viejo); antes quedaba un minuto en
// "Confirmando tu pago…" consultando un pedido que el servidor respondía 404.
type Estado = 'consultando' | 'aprobado' | 'pendiente' | 'rechazado' | 'error' | 'no_encontrado';

/**
 * Pantalla de vuelta de Mercado Pago / Nave después de pagar un kit por adelantado. Consulta el
 * estado real del pago en el servidor (unas cuantas veces, porque la confirmación de la pasarela
 * puede demorar unos segundos) y le explica a la familia qué sigue.
 */
export default function ReservaRetorno({ grupoPagoId, pedidoIdSuelto, recordatorio = false, onCerrar, onElegirOtroMedio }: Props) {
  const referencia = grupoPagoId || pedidoIdSuelto || '';
  const [estado, setEstado] = useState<Estado>('consultando');
  // Pago anticipado ("reserva") o compra normal: cambia el texto de la confirmación.
  const [esReserva, setEsReserva] = useState(!recordatorio);
  // Volvió de Mercado Pago sin pagar ("Volver a la tienda"): se consulta una sola vez por las dudas
  // y, si no está aprobado, se dice claramente que el pago no se hizo (antes esperaba 1 minuto y
  // mostraba "Tu pago se está procesando", aunque no hubiera ningún pago).
  const [sinPago] = useState(() => (typeof window !== 'undefined' ? volvioSinPagar(window.location.search) : false));
  const [pedido, setPedido] = useState('');
  const [metodoPago, setMetodoPago] = useState<string>('');
  const [reintentando, setReintentando] = useState(false);
  const [errorReintento, setErrorReintento] = useState('');
  const [pedidoId, setPedidoId] = useState('');
  const [total, setTotal] = useState(0);
  // Pedido de Pablo (28/9): "Elegir otro medio de pago" muestra los medios acá mismo, sobre la
  // misma reserva (antes reabría el portal y había que volver a elegir el kit).
  const [eligiendoMedio, setEligiendoMedio] = useState(false);
  const [transferencia, setTransferencia] = useState(false);
  // Auditoría 11/10 (POR-12): pasar a transferencia exige tildar el plazo de 48 h (como en el portal).
  const [plazoTransferencia, setPlazoTransferencia] = useState<{ acepta: boolean; falta: boolean } | null>(null);
  const naveHabilitado = useNaveHabilitado();

  // El servidor cobra lo registrado para este pago, así que alcanza con el grupo (o el pedido suelto).
  const abrirPasarela = async (medio: Medio) => {
    if (grupoPagoId) {
      const datos = { grupoPagoId, items: [], tutorNombre: '', tutorEmail: '' };
      return medio === 'nave' ? crearIntencionPagoNaveMultiple(datos) : crearPreferenciaMercadoPagoMultiple(datos);
    }
    const datos = { pedidoId: pedidoIdSuelto || pedidoId, tutorNombre: '', tutorEmail: '' };
    return medio === 'nave'
      ? crearIntencionPagoNave(datos as unknown as DatosIntencionNave)
      : crearPreferenciaMercadoPago(datos as unknown as DatosPreferenciaMercadoPago);
  };

  const irALaPasarela = async (medio: Medio) => {
    const pago = await abrirPasarela(medio);
    const url = 'checkoutUrl' in pago ? pago.checkoutUrl : 'initPoint' in pago ? pago.initPoint : undefined;
    if (pago.success && url) {
      window.location.href = url;
      return true;
    }
    setErrorReintento(pago.error || 'No se pudo abrir el pago. Probá con otro medio.');
    return false;
  };

  const elegirMedio = async (medio: Medio) => {
    setReintentando(true);
    setErrorReintento('');
    if (medio !== metodoPago) {
      const cambio: { success: boolean; error?: string; codigo?: string } = pedidoId ? await cambiarMetodoPagoPedido(pedidoId, medio, referencia) : { success: false };
      if (!cambio.success) {
        setReintentando(false);
        // 11/10: transferencia vencida (409 TRANSFERENCIA_VENCIDA): se muestra el mensaje del servidor.
        if (cambio.error && (cambio.codigo === 'TRANSFERENCIA_VENCIDA' || /venci/i.test(cambio.error))) return setErrorReintento(cambio.error);
        // La reserva ya no se puede retomar (por ejemplo, la pasarela la canceló): se arma de nuevo.
        if (onElegirOtroMedio) return onElegirOtroMedio();
        return setErrorReintento('No pudimos cambiar el medio de pago. Volvé a entrar al portal para pagar tu reserva.');
      }
      setMetodoPago(medio);
    }
    if (medio === 'transferencia') {
      setReintentando(false);
      setTransferencia(true);
      return;
    }
    const ok = await irALaPasarela(medio);
    if (!ok) setReintentando(false);
  };

  // "Volver a intentar": vuelve directo a la pasarela con el mismo medio de pago. El servidor cobra
  // lo registrado para este grupo, así que alcanza con el grupoPagoId.
  const reintentar = async () => {
    setReintentando(true);
    setErrorReintento('');
    const pago = await abrirPasarela(metodoPago === 'nave' ? 'nave' : 'mercadopago');
    const url = 'checkoutUrl' in pago ? pago.checkoutUrl : 'initPoint' in pago ? pago.initPoint : undefined;
    if (pago.success && url) {
      window.location.href = url;
      return;
    }
    setReintentando(false);
    setErrorReintento(pago.error || 'No se pudo volver a abrir el pago. Probá con otro medio.');
  };

  useEffect(() => {
    let cancelado = false;
    let intentos = 0;
    const consultar = async () => {
      intentos += 1;
      try {
        const res = await fetchConTimeout(urlEstadoPedido(referencia));
        const data = await res.json();
        if (cancelado) return;
        if (res.status === 404) return setEstado('no_encontrado');
        if (data?.pedidoFriendlyId) setPedido(data.pedidoFriendlyId);
        if (data?.pedidoId) setPedidoId(data.pedidoId);
        if (data?.total) setTotal(Number(data.total) || 0);
        if (data?.metodoPago) setMetodoPago(data.metodoPago);
        if (data?.success) setEsReserva(Boolean(data.reservaAnticipada));
        if (data?.estadoPago === 'aprobado') return setEstado('aprobado');
        if (data?.estadoPago === 'rechazado' || sinPago) return setEstado('rechazado');
        if (recordatorio && data?.success) {
          // Transferencia sin comprobante: se muestran directo los datos y el botón para subirlo.
          if (data.metodoPago === 'transferencia') setTransferencia(true);
          return setEstado('pendiente');
        }
        if (intentos >= 12) return setEstado('pendiente');
      } catch {
        if (intentos >= 12) return setEstado('error');
      }
      setTimeout(() => {
        if (!cancelado) void consultar();
      }, 5000);
    };
    void consultar();
    return () => {
      cancelado = true;
    };
  }, [referencia, sinPago, recordatorio]);

  return (
    <div className="fixed inset-0 z-[90] flex items-center justify-center bg-slate-950/60 p-4">
      <div className="relative w-full max-w-md rounded-2xl bg-white p-6 text-center shadow-xl">
        <button type="button" onClick={onCerrar} className="absolute right-3 top-3 rounded-lg p-1 text-slate-400 hover:bg-slate-100" aria-label="Cerrar">
          <X className="h-5 w-5" />
        </button>
        {estado === 'consultando' && (
          <>
            <Loader2 className="mx-auto h-10 w-10 animate-spin text-amber-500" />
            <p className="mt-3 font-bold text-slate-900">Confirmando tu pago…</p>
            <p className="mt-1 text-sm text-slate-500">Esto puede tardar unos segundos.</p>
          </>
        )}
        {estado === 'aprobado' && (
          <>
            <CheckCircle2 className="mx-auto h-12 w-12 text-emerald-500" />
            <p className="mt-3 text-lg font-extrabold text-slate-900">{esReserva ? '¡Reserva confirmada!' : '¡Pago confirmado!'}</p>
            <p className="mt-2 text-sm text-slate-600">
              Tu {esReserva ? 'kit' : 'pedido'} {pedido ? <>(pedido <strong>{pedido}</strong>) </> : null}ya está pagado. Te mandamos la confirmación por email.
            </p>
            {esReserva && (
              <p className="mt-2 text-sm text-slate-600">
                Cuando estén las fotos, entrá a <strong>Acceder a las Fotos</strong>, elegí las 3 que más te gusten y tocá <strong>Confirmar mis fotos</strong>. No vas a tener que volver a pagar.
              </p>
            )}
          </>
        )}
        {(estado === 'pendiente' || estado === 'error') && (
          <>
            <Clock className="mx-auto h-12 w-12 text-amber-500" />
            <p className="mt-3 text-lg font-extrabold text-slate-900">{recordatorio ? `Tu pedido${pedido ? ` ${pedido}` : ''} está pendiente de pago` : 'Todavía no vemos tu pago'}</p>
            <p className="mt-2 text-sm text-slate-600">
              {recordatorio
                ? transferencia
                  ? 'Si ya transferiste, subí el comprobante acá abajo. Si todavía no, estos son los datos.'
                  : 'Podés completar el pago ahora. Si ya pagaste por transferencia, tocá "Elegir otro medio de pago" → Transferencia y subí el comprobante.'
                : `Si lo completaste, puede tardar unos minutos: apenas se acredite te llega un email con la confirmación de tu ${esReserva ? 'reserva' : 'pedido'}. Si no llegaste a pagar, podés volver a intentarlo.`}
            </p>
          </>
        )}
        {estado === 'no_encontrado' && (
          <>
            <XCircle className="mx-auto h-12 w-12 text-slate-400" />
            <p className="mt-3 text-lg font-extrabold text-slate-900">No encontramos este pedido</p>
            <p className="mt-2 text-sm text-slate-600">Puede que se haya cancelado o que el link sea de un pedido anterior. Si todavía querés las fotos, entrá a <strong>Acceder a las Fotos</strong> y armá el pedido de nuevo. Ante cualquier duda, respondé el email que te llegó.</p>
          </>
        )}
        {estado === 'rechazado' && (
          <>
            <XCircle className="mx-auto h-12 w-12 text-red-500" />
            <p className="mt-3 text-lg font-extrabold text-slate-900">El pago no se completó</p>
            <p className="mt-2 text-sm text-slate-600">No se te cobró nada. Podés volver a intentarlo cuando quieras, con el mismo u otro medio de pago.</p>
          </>
        )}
        {errorReintento && <p className="mt-3 text-xs font-semibold text-red-600">{errorReintento}</p>}
        {transferencia ? (
          <div className="mt-4 space-y-3 text-left">
            <p className="text-sm text-slate-700">
              Transferí <strong>${total.toLocaleString('es-AR')}</strong>{pedido ? <> (pedido <strong>{pedido}</strong>)</> : null} y subí el comprobante acá abajo. Cuando lo confirmemos te llega un email.
            </p>
            <div className="space-y-0.5 rounded-xl bg-slate-50 p-3 text-xs text-slate-700">
              <p><strong>Alias:</strong> <span className="font-mono font-bold">RETRATO.ESCOLAR</span></p>
              <p><strong>CBU:</strong> <span className="font-mono">0070313830004052956749</span> · Banco Galicia</p>
              <p><strong>Titular:</strong> Alderete Pablo Gabriel · CUIT 20-28306117-6</p>
            </div>
            <SubirComprobante grupoPagoId={grupoPagoId} pedidoId={grupoPagoId ? undefined : pedidoIdSuelto || pedidoId} numeros={pedido} />
            <button type="button" onClick={onCerrar} className="w-full rounded-xl px-5 py-2 text-sm font-semibold text-slate-500 hover:text-slate-800">
              Cerrar
            </button>
          </div>
        ) : eligiendoMedio ? (
          <div className="mt-5 space-y-2">
            <p className="text-sm font-semibold text-slate-700">¿Cómo querés pagar tu {esReserva ? 'reserva' : 'pedido'}?</p>
            <div className="flex flex-col gap-2">
              {MEDIOS.filter((m) => m.id !== 'nave' || naveHabilitado).map((m) => (
                <button
                  key={m.id}
                  type="button"
                  onClick={() => (m.id === 'transferencia' && metodoPago !== 'transferencia' ? setPlazoTransferencia({ acepta: false, falta: false }) : void elegirMedio(m.id))}
                  disabled={reintentando}
                  className={`inline-flex items-center justify-center gap-2 rounded-xl border px-5 py-2.5 text-sm font-bold shadow-xs disabled:opacity-60 ${m.clases}`}
                >
                  {reintentando && <Loader2 className="h-4 w-4 animate-spin" />}
                  Pagar con {m.label}
                </button>
              ))}
            </div>
            {metodoPago !== 'transferencia' && !plazoTransferencia && (
              <p className="text-xs text-slate-500">
                Si elegís <strong>Transferencia</strong>, tenés {PLAZO_TRANSFERENCIA_HORAS} horas para subir el comprobante; si no, el pedido se cancela automáticamente.
              </p>
            )}
            {plazoTransferencia && (
              <div className="space-y-2">
                <AvisoPlazoTransferencia id="chk-plazo-transferencia-retorno" aceptado={plazoTransferencia.acepta} onCambiar={(v) => setPlazoTransferencia({ acepta: v, falta: false })} resaltar={plazoTransferencia.falta} />
                <button
                  type="button"
                  disabled={reintentando}
                  onClick={() => {
                    if (!plazoTransferencia.acepta) return setPlazoTransferencia({ acepta: false, falta: true });
                    setPlazoTransferencia(null);
                    void elegirMedio('transferencia');
                  }}
                  className="w-full rounded-xl border border-slate-300 bg-white px-5 py-2.5 text-sm font-bold text-slate-800 hover:bg-slate-50 disabled:opacity-60"
                >
                  Confirmar el pago por transferencia
                </button>
              </div>
            )}
            <button type="button" onClick={() => { setEligiendoMedio(false); setPlazoTransferencia(null); }} disabled={reintentando} className="rounded-xl px-5 py-2 text-sm font-semibold text-slate-500 hover:text-slate-800">
              Volver
            </button>
          </div>
        ) : estado === 'rechazado' || estado === 'pendiente' || estado === 'error' ? (
          <div className="mt-5 flex flex-col gap-2">
            {metodoPago !== 'transferencia' && (
              <button
                type="button"
                onClick={() => void reintentar()}
                disabled={reintentando}
                className="inline-flex items-center justify-center gap-2 rounded-xl bg-amber-400 px-5 py-2.5 text-sm font-bold text-slate-950 hover:bg-amber-300 disabled:opacity-60"
              >
                {reintentando && <Loader2 className="h-4 w-4 animate-spin" />}
                Volver a intentar{metodoPago === 'nave' ? ' con Nave' : metodoPago === 'mercadopago' ? ' con Mercado Pago' : ''}
              </button>
            )}
            {(pedidoId || onElegirOtroMedio) && (
              <button type="button" onClick={() => (pedidoId ? setEligiendoMedio(true) : onElegirOtroMedio?.())} disabled={reintentando} className="rounded-xl border border-slate-300 bg-white px-5 py-2.5 text-sm font-bold text-slate-800 hover:bg-slate-50">
                Elegir otro medio de pago
              </button>
            )}
            <button type="button" onClick={onCerrar} disabled={reintentando} className="rounded-xl px-5 py-2 text-sm font-semibold text-slate-500 hover:text-slate-800">
              Cerrar
            </button>
          </div>
        ) : (
          <button type="button" onClick={onCerrar} className="mt-5 rounded-xl bg-slate-900 px-5 py-2.5 text-sm font-bold text-white hover:bg-slate-800">
            Entendido
          </button>
        )}
      </div>
    </div>
  );
}
