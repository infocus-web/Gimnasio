import { useCallback, useEffect, useMemo, useState } from 'react';
import { ClipboardList, Loader2, Search, Trash2, X } from 'lucide-react';
import { useColegiosLista, obtenerAlumnosNominaAdmin, type AlumnoNominaReal } from '../services/colegiosService';
import {
  TIPOS_OBSERVACION,
  borrarObservacionAdmin,
  crearObservacionAdmin,
  etiquetaTipoObservacion,
  obtenerObservacionesAdmin,
  type ObservacionAlumno,
  type TipoObservacion,
} from '../services/observacionesService';
import { nuevaClaveEnvio } from '../utils/claveEnvio';
import { useBorradorAdmin } from '../utils/useBorradorAdmin';

// Pestaña «Observaciones» (pedido de Pablo, 13/10/2026: «un alumno no quiso foto individual, debo registrar esos
// eventos»). Se busca al alumno en la nómina, se elige qué pasó y se agrega un detalle. Abajo, todas las del colegio.

const normalizar = (v: string | null | undefined) =>
  String(v || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/\s+/g, ' ').trim();

const cursoDe = (a: { grado: string | null; division: string | null; turno: string | null }) =>
  `${a.grado || ''} "${a.division || '-'}"${a.turno ? ` (${a.turno})` : ''}`;

// 14/10/2026: el formulario se guarda solo como borrador (alumno, tipo y detalle) y lleva la `clave` del envío,
// así un reintento tras un corte (o tras recargar) no anota dos veces la misma observación.
const FORM_VACIO = { alumnoId: '', tipo: 'sin_foto_individual' as TipoObservacion, detalle: '', clave: '', claveDe: '' };

const fechaHora = (iso: string) =>
  new Date(iso).toLocaleString('es-AR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' });

export default function AdminObservacionesTab() {
  const { colegios } = useColegiosLista();
  const [colegioId, setColegioId] = useState(() => colegios[0]?.id || '');
  const [nomina, setNomina] = useState<AlumnoNominaReal[]>([]);
  const [observaciones, setObservaciones] = useState<ObservacionAlumno[]>([]);
  const [cargando, setCargando] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [aviso, setAviso] = useState<string | null>(null);

  const [busqueda, setBusqueda] = useState('');
  const [alumno, setAlumno] = useState<AlumnoNominaReal | null>(null);
  const [form, setForm, borradorForm] = useBorradorAdmin(colegioId ? `observacion-${colegioId}` : null, FORM_VACIO);
  const { tipo, detalle } = form;
  const setTipo = (t: TipoObservacion) => setForm((f) => ({ ...f, tipo: t }));
  const setDetalle = (d: string) => setForm((f) => ({ ...f, detalle: d }));
  const [guardando, setGuardando] = useState(false);
  const [borrandoId, setBorrandoId] = useState<string | null>(null);

  const [filtroTipo, setFiltroTipo] = useState<'todas' | TipoObservacion>('todas');
  const [filtroTexto, setFiltroTexto] = useState('');

  useEffect(() => {
    if (colegios.length > 0 && (!colegioId || !colegios.some((c) => c.id === colegioId))) setColegioId(colegios[0].id);
  }, [colegios, colegioId]);

  const cargar = useCallback(async () => {
    if (!colegioId) return;
    setCargando(true);
    setError(null);
    const [alumnos, obs] = await Promise.all([obtenerAlumnosNominaAdmin(colegioId), obtenerObservacionesAdmin(colegioId)]);
    setNomina(alumnos);
    if (obs.success) setObservaciones(obs.observaciones);
    else setError(obs.error || 'No se pudieron cargar las observaciones.');
    setCargando(false);
  }, [colegioId]);

  useEffect(() => {
    void cargar();
  }, [cargar]);

  const coincidencias = useMemo(() => {
    const palabras = normalizar(busqueda).split(' ').filter((p) => p.length >= 2);
    if (palabras.length === 0 || alumno) return [];
    return nomina.filter((a) => palabras.every((p) => normalizar(a.nombre).includes(p))).slice(0, 8);
  }, [busqueda, nomina, alumno]);

  const visibles = useMemo(() => {
    const texto = normalizar(filtroTexto);
    return observaciones.filter(
      (o) =>
        (filtroTipo === 'todas' || o.tipo === filtroTipo) &&
        (!texto || normalizar(`${o.alumno_nombre} ${cursoDe(o)} ${o.detalle || ''}`).includes(texto))
    );
  }, [observaciones, filtroTipo, filtroTexto]);

  // Borrador recuperado: se vuelve a elegir el alumno que estaba elegido (cuando ya cargó la nómina).
  useEffect(() => {
    if (alumno || !form.alumnoId) return;
    const guardado = nomina.find((a) => a.id === form.alumnoId);
    if (guardado) { setAlumno(guardado); setBusqueda(guardado.nombre); }
  }, [form.alumnoId, nomina, alumno]);

  const elegir = (a: AlumnoNominaReal) => {
    setForm((f) => ({ ...f, alumnoId: a.id }));
    setAlumno(a);
    setBusqueda(a.nombre);
    setAviso(null);
  };

  const limpiarFormulario = () => {
    setAlumno(null);
    setBusqueda('');
    borradorForm.fijarSinGuardar(FORM_VACIO);
    void borradorForm.borrar();
  };

  const guardar = async () => {
    if (!alumno || guardando) return;
    if (tipo === 'otra' && !detalle.trim()) {
      setError('Contá qué pasó en el detalle.');
      return;
    }
    setGuardando(true);
    setError(null);
    const contenido = `${alumno.id}|${tipo}|${detalle.trim()}`;
    const clave = form.clave && form.claveDe === contenido ? form.clave : nuevaClaveEnvio();
    if (clave !== form.clave) setForm((f) => ({ ...f, clave, claveDe: contenido }));
    const r = await crearObservacionAdmin(alumno.id, tipo, detalle.trim(), clave);
    setGuardando(false);
    if (!r.success || !r.observacion) {
      setError(r.error || 'No se pudo guardar la observación.');
      return;
    }
    setObservaciones((prev) => [r.observacion as ObservacionAlumno, ...prev]);
    setAviso(`Guardada: ${r.observacion.alumno_nombre} — ${etiquetaTipoObservacion(r.observacion.tipo)}.`);
    limpiarFormulario();
  };

  const borrar = async (o: ObservacionAlumno) => {
    if (!window.confirm(`¿Borrar la observación de ${o.alumno_nombre} (${etiquetaTipoObservacion(o.tipo)})?`)) return;
    setBorrandoId(o.id);
    const r = await borrarObservacionAdmin(o.id);
    setBorrandoId(null);
    if (!r.success) {
      setError(r.error || 'No se pudo borrar la observación.');
      return;
    }
    setObservaciones((prev) => prev.filter((x) => x.id !== o.id));
  };

  return (
    <div className="space-y-5 text-slate-900 text-left">
      <div className="p-4 bg-amber-50/70 border border-amber-200 rounded-2xl flex items-start gap-3">
        <ClipboardList className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
        <div className="text-xs text-amber-950 leading-relaxed">
          <p className="font-bold">Observaciones de la toma de fotos</p>
          <p className="mt-1 text-amber-900/90">
            Anotá lo que pasó con un alumno el día de las fotos: si no quiso la individual o la grupal, si estuvo ausente u
            otra cosa. Se guarda con su curso de la nómina. Sólo lo ves vos: las familias y el colegio no lo ven.
          </p>
        </div>
      </div>

      <label className="block text-xs font-semibold text-slate-700 max-w-md">
        Colegio
        <select
          value={colegioId}
          onChange={(e) => {
            setColegioId(e.target.value);
            limpiarFormulario();
          }}
          className="mt-1 w-full rounded-xl border border-slate-300 px-3 py-2 text-sm font-normal bg-white"
        >
          {colegios.map((c) => (
            <option key={c.id} value={c.id}>
              {c.nombre}
            </option>
          ))}
        </select>
      </label>

      <section className="rounded-2xl border border-slate-200 bg-white p-4 space-y-3" aria-labelledby="titulo-nueva-observacion">
        <h3 id="titulo-nueva-observacion" className="text-sm font-bold text-slate-900">Nueva observación</h3>

        <div className="relative max-w-xl">
          <label htmlFor="obs-alumno" className="block text-xs font-semibold text-slate-700">Alumno</label>
          <div className="mt-1 flex items-center gap-2 rounded-xl border border-slate-300 px-3 py-2 bg-white">
            <Search className="w-4 h-4 text-slate-400 shrink-0" />
            <input
              id="obs-alumno"
              value={busqueda}
              onChange={(e) => {
                setBusqueda(e.target.value);
                setAlumno(null);
                if (form.alumnoId) setForm((f) => ({ ...f, alumnoId: '' }));
              }}
              placeholder={cargando ? 'Cargando la nómina…' : 'Escribí nombre o apellido'}
              autoComplete="off"
              className="w-full text-sm outline-none bg-transparent"
            />
            {busqueda && (
              <button type="button" onClick={limpiarFormulario} aria-label="Borrar búsqueda" className="text-slate-400 hover:text-slate-700 cursor-pointer">
                <X className="w-4 h-4" />
              </button>
            )}
          </div>
          {coincidencias.length > 0 && (
            <ul role="listbox" aria-label="Alumnos encontrados" className="absolute z-10 mt-1 w-full rounded-xl border border-slate-200 bg-white shadow-lg overflow-hidden">
              {coincidencias.map((a) => (
                <li key={a.id}>
                  <button
                    type="button"
                    role="option"
                    aria-selected={false}
                    onClick={() => elegir(a)}
                    className="w-full text-left px-3 py-2 text-sm hover:bg-amber-50 cursor-pointer"
                  >
                    <span className="font-semibold">{a.nombre}</span>
                    <span className="text-xs text-slate-500"> · {cursoDe(a)}</span>
                  </button>
                </li>
              ))}
            </ul>
          )}
          {alumno && <p className="mt-1 text-[11px] text-slate-500">Curso: {cursoDe(alumno)}</p>}
          {!alumno && normalizar(busqueda).length >= 3 && coincidencias.length === 0 && !cargando && (
            <p className="mt-1 text-[11px] text-slate-500">No hay nadie con ese nombre en la nómina de este colegio.</p>
          )}
        </div>

        <fieldset className="space-y-1">
          <legend className="text-xs font-semibold text-slate-700">Qué pasó</legend>
          <div className="flex flex-wrap gap-2">
            {TIPOS_OBSERVACION.map((t) => (
              <label
                key={t.valor}
                className={`cursor-pointer rounded-xl border px-3 py-1.5 text-xs font-semibold ${
                  tipo === t.valor ? 'border-amber-500 bg-amber-50 text-amber-900' : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                }`}
              >
                <input type="radio" name="obs-tipo" value={t.valor} checked={tipo === t.valor} onChange={() => setTipo(t.valor)} className="sr-only" />
                {t.etiqueta}
              </label>
            ))}
          </div>
        </fieldset>

        <label className="block text-xs font-semibold text-slate-700 max-w-xl">
          Detalle {tipo === 'otra' ? '(obligatorio)' : '(opcional)'}
          <textarea
            value={detalle}
            onChange={(e) => setDetalle(e.target.value)}
            maxLength={1000}
            rows={2}
            placeholder="Ej: se le propuso dos veces, prefirió sólo la grupal"
            className="mt-1 w-full rounded-xl border border-slate-300 px-3 py-2 text-sm font-normal"
          />
        </label>

        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={() => void guardar()}
            disabled={!alumno || guardando}
            className="inline-flex items-center gap-1.5 rounded-xl bg-amber-500 px-4 py-2 text-xs font-bold text-white hover:bg-amber-600 disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer"
          >
            {guardando && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
            Guardar observación
          </button>
          {aviso && <p role="status" className="text-xs font-semibold text-emerald-700">{aviso}</p>}
        </div>
        {error && <p role="alert" className="text-xs font-semibold text-rose-700">{error}</p>}
      </section>

      <section className="space-y-3" aria-labelledby="titulo-lista-observaciones">
        <div className="flex flex-wrap items-end justify-between gap-3">
          <h3 id="titulo-lista-observaciones" className="text-sm font-bold text-slate-900">
            Observaciones ({visibles.length}{visibles.length !== observaciones.length ? ` de ${observaciones.length}` : ''})
          </h3>
          <div className="flex flex-wrap gap-2">
            <select
              value={filtroTipo}
              onChange={(e) => setFiltroTipo(e.target.value as 'todas' | TipoObservacion)}
              aria-label="Filtrar por tipo"
              className="rounded-xl border border-slate-300 px-3 py-1.5 text-xs bg-white"
            >
              <option value="todas">Todas</option>
              {TIPOS_OBSERVACION.map((t) => (
                <option key={t.valor} value={t.valor}>{t.etiqueta}</option>
              ))}
            </select>
            <input
              value={filtroTexto}
              onChange={(e) => setFiltroTexto(e.target.value)}
              placeholder="Buscar alumno o curso"
              aria-label="Buscar en las observaciones"
              className="rounded-xl border border-slate-300 px-3 py-1.5 text-xs"
            />
          </div>
        </div>

        {cargando ? (
          <p className="text-xs text-slate-500">Cargando…</p>
        ) : visibles.length === 0 ? (
          <p className="text-xs text-slate-500">{observaciones.length === 0 ? 'Todavía no hay observaciones en este colegio.' : 'No hay observaciones con ese filtro.'}</p>
        ) : (
          <ul className="divide-y divide-slate-100 rounded-2xl border border-slate-200 bg-white">
            {visibles.map((o) => (
              <li key={o.id} className="flex items-start justify-between gap-3 px-4 py-3">
                <div className="min-w-0 text-xs">
                  <p className="font-bold text-slate-900 text-sm">{o.alumno_nombre}</p>
                  <p className="text-slate-500">{cursoDe(o)} · {fechaHora(o.created_at)}</p>
                  <p className="mt-1">
                    <span className="inline-block rounded-full bg-amber-100 px-2 py-0.5 text-[11px] font-semibold text-amber-900">
                      {etiquetaTipoObservacion(o.tipo)}
                    </span>
                  </p>
                  {o.detalle && <p className="mt-1 text-slate-700 whitespace-pre-wrap">{o.detalle}</p>}
                </div>
                <button
                  type="button"
                  onClick={() => void borrar(o)}
                  disabled={borrandoId === o.id}
                  aria-label={`Borrar la observación de ${o.alumno_nombre}`}
                  className="shrink-0 rounded-lg p-1.5 text-slate-400 hover:bg-rose-50 hover:text-rose-600 disabled:opacity-50 cursor-pointer"
                >
                  {borrandoId === o.id ? <Loader2 className="w-4 h-4 animate-spin" /> : <Trash2 className="w-4 h-4" />}
                </button>
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  );
}
