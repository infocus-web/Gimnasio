import { useEffect, useRef, useState } from 'react';
import { Loader2, ZoomIn } from 'lucide-react';
import { fetchAdminAutenticado } from '../services/adminAuthService';

// 25/10/2026 (Pablo: la lupa tardaba la primera vez). Deja preparadas de antemano las copias nítidas de la lupa de
// todas las fotos publicadas (servidor/panel/prepararLupa.ts). Va de a tandas de ~35 s hasta terminar; además hay una
// tarea automática cada 15 minutos para las que se publiquen después. Va aparte para no agrandar AdminLoteFotosTab.

async function llamar(soloContar: boolean): Promise<{ success: boolean; preparadas?: number; errores?: number; restantes?: number; error?: string }> {
  try {
    const res = await fetchAdminAutenticado('/api/admin/fotos/preparar-lupa', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ soloContar }) });
    const data = await res.json().catch(() => ({}));
    return res.ok && data.success ? data : { success: false, error: data?.error || `Error ${res.status}` };
  } catch (err: any) {
    return { success: false, error: err?.message || 'Error de conexión.' };
  }
}

export default function PrepararLupa() {
  const [pendientes, setPendientes] = useState<number | null>(null);
  const [trabajando, setTrabajando] = useState(false);
  const [mensaje, setMensaje] = useState('');
  const detener = useRef(false);

  useEffect(() => {
    void llamar(true).then((r) => { if (r.success) setPendientes(r.restantes ?? 0); });
    return () => { detener.current = true; };
  }, []);

  if (!pendientes && !trabajando && !mensaje) return null;

  const preparar = async () => {
    setTrabajando(true);
    setMensaje('');
    detener.current = false;
    let total = 0;
    let errores = 0;
    for (let vuelta = 0; vuelta < 400 && !detener.current; vuelta++) {
      const r = await llamar(false);
      if (!r.success) { setMensaje(`Se cortó: ${r.error}. Tocá de nuevo para seguir.`); break; }
      total += r.preparadas || 0;
      errores += r.errores || 0;
      setPendientes(r.restantes ?? 0);
      if (!r.restantes || (r.preparadas || 0) === 0) {
        setMensaje(`Listo: ${total} foto(s) con la lupa preparada.${errores ? ` ${errores} no se pudieron (se arman solas la primera vez que alguien pasa la lupa).` : ''}`);
        break;
      }
    }
    setTrabajando(false);
  };

  return (
    <div className="flex flex-wrap items-center gap-2 text-[11px]">
      {pendientes ? (
        <button type="button" onClick={() => void preparar()} disabled={trabajando} className="px-2.5 py-1 bg-sky-50 hover:bg-sky-100 disabled:opacity-60 font-bold text-sky-800 rounded-lg border border-sky-200 transition-colors flex items-center gap-1.5 cursor-pointer" title="Prepara de antemano la imagen nítida de la lupa, así la primera vez aparece enseguida">
          {trabajando ? <Loader2 className="w-3 h-3 animate-spin" aria-hidden="true" /> : <ZoomIn className="w-3 h-3" aria-hidden="true" />}
          {trabajando ? `Preparando la lupa… faltan ${pendientes} foto(s)` : `Preparar lupa (${pendientes} foto(s) pendientes)`}
        </button>
      ) : null}
      {trabajando && <span className="text-slate-500">No cierres esta pestaña.</span>}
      {mensaje && <span role="status" className="font-semibold text-emerald-700">{mensaje}</span>}
    </div>
  );
}
