import { CheckCircle2, CheckSquare, Users } from 'lucide-react';
import type { FiltroFoto } from './fotografiadosNomina';

// Nómina: elegir «Sin fotografiar» para ver sólo los alumnos que faltan (14/10/2026, pedido de Pablo).
// Va entre el buscador y los desplegables de cursos. Fuera de AdminModal.tsx (techo de líneas).
// 14/10/2026 (noche, Pablo: «les hicimos las individuales y con la seño, faltan las grupales, se las haremos la
// próxima semana»): la grupal se marca aparte. Acá también la celda «Estado Foto» y los botones de chequeo.
// 21/10/2026 (Pablo: «¿cómo tildo si falta la foto individual y/o con la seño?»): la foto con la seño también aparte.
export default function FiltroFotografiadoNomina({
  valor,
  onCambiar,
  cuentas,
}: {
  valor: FiltroFoto;
  onCambiar: (v: FiltroFoto) => void;
  cuentas: { total: number; faltaAlguna: number; pendientes: number; sinSeno: number; sinGrupal: number; completos: number };
}) {
  return (
    <div className="sm:w-52">
      <select
        aria-label="Filtrar por estado de la foto"
        value={valor}
        onChange={(e) => onCambiar(e.target.value as FiltroFoto)}
        className={`w-full px-3 py-2 text-xs border rounded-xl focus:outline-hidden focus:ring-2 focus:ring-amber-400 font-medium ${
          valor !== 'todos' && valor !== 'fotografiados' ? 'bg-amber-50 border-amber-400 text-amber-900' : 'bg-white border-slate-300 text-slate-700'
        }`}
      >
        <option value="todos">Todos ({cuentas.total})</option>
        <option value="alguna">Falta alguna foto ({cuentas.faltaAlguna})</option>
        <option value="pendientes">Falta individual ({cuentas.pendientes})</option>
        <option value="sin-seno">Falta con la seño ({cuentas.sinSeno})</option>
        <option value="sin-grupal">Falta grupal ({cuentas.sinGrupal})</option>
        <option value="fotografiados">Completos, las 3 ({cuentas.completos})</option>
      </select>
    </div>
  );
}

/** Botón de una foto de la celda «Estado Foto» (seño o grupal): la marca o la desmarca. */
function BotonFoto({ hecha, etiqueta, nombre, onClick }: { hecha: boolean; etiqueta: string; nombre: string; onClick: () => void }) {
  return (
    <button
      type="button"
      onClick={(event) => {
        event.stopPropagation();
        onClick();
      }}
      aria-pressed={hecha}
      title={hecha ? `${nombre} sacada (tocá para desmarcar)` : `Marcar la foto ${nombre.toLowerCase()} como sacada`}
      className={`inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full border cursor-pointer transition-colors ${
        hecha
          ? 'text-sky-800 bg-sky-100 border-sky-200 hover:bg-sky-200'
          : 'text-amber-800 bg-amber-50 border-amber-300 border-dashed hover:bg-amber-100'
      }`}
    >
      <Users className="w-3 h-3" /> {hecha ? etiqueta : `Falta ${etiqueta.toLowerCase()}`}
    </button>
  );
}

/** Celda «Estado Foto»: la individual (la casilla de la fila) y, aparte, la de la seño y la grupal (21/10/2026). */
export function EstadoFotoNomina({
  fotografiado,
  seno,
  grupal,
  onSeno,
  onGrupal,
}: {
  fotografiado: boolean;
  seno: boolean;
  grupal: boolean;
  onSeno: () => void;
  onGrupal: () => void;
}) {
  return (
    <div className="flex flex-col items-center gap-1">
      {fotografiado ? (
        <span className="inline-flex items-center gap-1 text-[10px] font-bold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded-full">
          <CheckCircle2 className="w-3 h-3" /> Individual
        </span>
      ) : (
        <span className="inline-block text-[10px] font-semibold text-slate-400 bg-slate-100 px-2 py-0.5 rounded-full">Falta individual</span>
      )}
      <BotonFoto hecha={seno} etiqueta="Seño" nombre="Con la seño" onClick={onSeno} />
      <BotonFoto hecha={grupal} etiqueta="Grupal" nombre="Grupal" onClick={onGrupal} />
    </div>
  );
}

/** «Chequear filtrados» (individual), «Seño a filtrados» y «Grupal a filtrados». */
export function BotonesChequeoNomina({ onFotografiados, onSeno, onGrupal }: { onFotografiados: () => void; onSeno: () => void; onGrupal: () => void }) {
  const clase = 'px-3 py-1.5 bg-white border border-slate-300 hover:bg-slate-100 rounded-xl text-xs font-semibold text-slate-700 flex items-center gap-1.5 cursor-pointer shadow-xs transition-colors';
  return (
    <>
      <button type="button" onClick={onFotografiados} className={clase} title="Marca la foto individual a todos los alumnos que se ven en la lista (si ya la tienen todos, la quita)">
        <CheckSquare className="w-3.5 h-3.5 text-slate-500" />
        <span>Chequear filtrados</span>
      </button>
      <button type="button" onClick={onSeno} className={clase} title="Marca la foto con la seño a todos los alumnos que se ven en la lista (si ya la tienen todos, la quita)">
        <Users className="w-3.5 h-3.5 text-sky-600" />
        <span>Seño a filtrados</span>
      </button>
      <button type="button" onClick={onGrupal} className={clase} title="Marca la foto grupal a todos los alumnos que se ven en la lista (si ya la tienen todos, la quita)">
        <Users className="w-3.5 h-3.5 text-sky-600" />
        <span>Grupal a filtrados</span>
      </button>
    </>
  );
}
