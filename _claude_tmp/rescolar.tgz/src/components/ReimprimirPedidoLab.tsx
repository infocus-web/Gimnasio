import { useState } from 'react';
import { FolderDown, Loader2, RotateCcw, Search } from 'lucide-react';
import {
  buscarPedidoParaReimprimir,
  MOTIVOS_REIMPRESION,
  reimprimirPedidoLab,
  SesionLabVencida,
  type MotivoReimpresion,
  type PedidoLab,
} from '../services/laboratorioService';

type Estructura = 'solo_2_carpetas_tamano' | 'por_alumno';

interface Props {
  estructura: Estructura;
  onError: (e: unknown) => void;
  onAviso: (texto: string) => void;
}

/**
 * Reimprimir un pedido que salió mal (pedido de Pablo, 2/10/2026). El laboratorio lo busca por
 * número de pedido, código o nombre del alumno (también los ya entregados), elige qué fotos
 * reimprimir y el motivo, y baja un ZIP sólo con esas fotos. Queda registrado y le llega un aviso
 * al fotógrafo; en el resumen para facturar va sin cargo si fue una falla de impresión.
 */
export default function ReimprimirPedidoLab({ estructura, onError, onAviso }: Props) {
  const [texto, setTexto] = useState('');
  const [buscando, setBuscando] = useState(false);
  const [resultados, setResultados] = useState<PedidoLab[] | null>(null);
  const [previas, setPrevias] = useState<Record<string, number>>({});
  const [elegido, setElegido] = useState<PedidoLab | null>(null);
  const [marcadas, setMarcadas] = useState<Set<string>>(new Set());
  const [motivo, setMotivo] = useState<MotivoReimpresion | ''>('');
  const [detalle, setDetalle] = useState('');
  const [descargando, setDescargando] = useState(false);
  const [errorLocal, setErrorLocal] = useState('');
  // Reimpresión ya registrada en el servidor (por si el ZIP falla y se reintenta: no se registra dos veces).
  const [registrada, setRegistrada] = useState<string | null>(null);

  const claveArchivo = (a: PedidoLab['archivosParaLaboratorio'][number], i: number) => `${i}-${a.nombreArchivoLab}`;

  const buscar = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorLocal('');
    setElegido(null);
    if (texto.trim().length < 3) return setErrorLocal('Escribí al menos 3 letras o números.');
    setBuscando(true);
    try {
      const r = await buscarPedidoParaReimprimir(texto.trim());
      setResultados(r.pedidos);
      const cuenta: Record<string, number> = {};
      for (const x of r.reimpresiones) cuenta[x.pedido_id] = (cuenta[x.pedido_id] || 0) + 1;
      setPrevias(cuenta);
      if (r.pedidos.length === 1) elegir(r.pedidos[0]);
    } catch (err) {
      if (err instanceof SesionLabVencida) onError(err);
      else setErrorLocal(err instanceof Error ? err.message : 'No se pudo buscar el pedido.');
    } finally {
      setBuscando(false);
    }
  };

  const elegir = (p: PedidoLab) => {
    setElegido(p);
    // Por defecto todas las fotos que se pueden imprimir (las que tienen la foto real).
    setMarcadas(new Set(p.archivosParaLaboratorio.map((a, i) => (a.sinFotoReal ? '' : claveArchivo(a, i))).filter(Boolean)));
    setMotivo('');
    setDetalle('');
    setErrorLocal('');
    setRegistrada(null);
  };

  const alternar = (clave: string) =>
    setMarcadas((prev) => {
      const nuevo = new Set(prev);
      if (nuevo.has(clave)) nuevo.delete(clave);
      else nuevo.add(clave);
      return nuevo;
    });

  const archivosElegidos = elegido ? elegido.archivosParaLaboratorio.filter((a, i) => marcadas.has(claveArchivo(a, i))) : [];
  const faltaDetalle = motivo !== '' && motivo !== 'falla_laboratorio' && detalle.trim().length < 3;
  const puedeDescargar = Boolean(elegido) && archivosElegidos.length > 0 && motivo !== '' && !faltaDetalle && !descargando;

  const descargar = async () => {
    if (!elegido || !motivo) return;
    setDescargando(true);
    setErrorLocal('');
    // Clave de lo pedido: si cambian las fotos o el motivo después de registrar, es otra reimpresión.
    const clave = `${elegido.supabaseId}|${motivo}|${archivosElegidos.map((a) => a.nombreArchivoLab).join(',')}`;
    let registradaAhora = registrada === clave;
    try {
      await reimprimirPedidoLab(elegido, archivosElegidos, motivo, detalle.trim(), estructura, registradaAhora, () => {
        registradaAhora = true;
        setRegistrada(clave);
      });
      setRegistrada(null);
      onAviso(`Reimpresión de ${elegido.alumnoNombre} (${elegido.id}) descargada: ${archivosElegidos.length} foto(s). Le avisamos al fotógrafo.`);
      setPrevias((prev) => ({ ...prev, [elegido.supabaseId || '']: (prev[elegido.supabaseId || ''] || 0) + 1 }));
      setElegido(null);
      setResultados(null);
      setTexto('');
    } catch (err) {
      if (err instanceof SesionLabVencida) onError(err);
      else setErrorLocal(err instanceof Error ? err.message : 'No se pudo descargar la reimpresión.');
    } finally {
      setDescargando(false);
    }
  };

  return (
    <section className="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm sm:p-6">
      <div className="flex items-center gap-2">
        <RotateCcw className="h-5 w-5 text-slate-500" />
        <h2 className="font-['Outfit'] text-lg font-extrabold text-slate-900">Reimprimir un pedido</h2>
      </div>
      <p className="mt-1 text-xs text-slate-600">
        Si unas fotos salieron mal, buscá el pedido por su número (por ejemplo IFS-2026-4266 o sólo 4266), el código del alumno o su nombre.
      </p>

      <form onSubmit={buscar} className="mt-3 flex gap-2">
        <input
          value={texto}
          onChange={(e) => setTexto(e.target.value)}
          placeholder="Número de pedido, código o nombre"
          className="min-w-0 flex-1 rounded-xl border border-slate-300 px-3 py-2.5 text-sm"
          maxLength={60}
        />
        <button type="submit" disabled={buscando} className="flex items-center gap-1.5 rounded-xl bg-slate-900 px-4 py-2.5 text-sm font-bold text-white hover:bg-slate-800 disabled:opacity-50">
          {buscando ? <Loader2 className="h-4 w-4 animate-spin" /> : <Search className="h-4 w-4" />} Buscar
        </button>
      </form>
      {errorLocal && <p className="mt-2 text-xs font-semibold text-red-600">{errorLocal}</p>}

      {resultados && resultados.length === 0 && <p className="mt-3 text-sm text-slate-500">No encontramos pedidos con impresión con ese dato.</p>}

      {resultados && resultados.length > 1 && !elegido && (
        <ul className="mt-3 divide-y divide-slate-100 rounded-2xl border border-slate-200">
          {resultados.map((p) => (
            <li key={p.supabaseId}>
              <button type="button" onClick={() => elegir(p)} className="flex w-full items-center justify-between gap-3 px-4 py-2.5 text-left text-sm hover:bg-slate-50">
                <span>
                  <span className="font-bold">{p.alumnoNombre}</span>
                  <span className="block text-xs text-slate-500">
                    {p.colegioNombre} · {p.grado} "{p.division}"
                  </span>
                </span>
                <span className="font-mono text-xs text-slate-600">{p.id}</span>
              </button>
            </li>
          ))}
        </ul>
      )}

      {elegido && (
        <div className="mt-4 space-y-4 rounded-2xl border border-amber-200 bg-amber-50/50 p-4">
          <div className="flex flex-wrap items-start justify-between gap-2">
            <div>
              <p className="font-['Outfit'] text-base font-extrabold text-slate-900">{elegido.alumnoNombre}</p>
              <p className="text-xs text-slate-600">
                {elegido.colegioNombre} · {elegido.grado} "{elegido.division}" · <span className="font-mono">{elegido.id}</span>
              </p>
              {(previas[elegido.supabaseId || ''] || 0) > 0 && (
                <p className="mt-1 text-xs font-bold text-amber-800">Ya se reimprimió {previas[elegido.supabaseId || '']} vez/veces.</p>
              )}
            </div>
            {resultados && resultados.length > 1 && (
              <button type="button" onClick={() => setElegido(null)} className="text-xs font-bold text-slate-600 underline">
                Elegir otro
              </button>
            )}
          </div>

          <div>
            <p className="text-xs font-bold uppercase tracking-wider text-slate-600">1. Qué fotos reimprimir</p>
            <ul className="mt-2 space-y-1.5">
              {elegido.archivosParaLaboratorio.map((a, i) => {
                const clave = claveArchivo(a, i);
                return (
                  <li key={clave}>
                    <label className={`flex items-center gap-2 rounded-xl bg-white px-3 py-2 text-sm ${a.sinFotoReal ? 'opacity-50' : ''}`}>
                      <input
                        type="checkbox"
                        className="h-4 w-4 accent-amber-500"
                        checked={marcadas.has(clave)}
                        disabled={a.sinFotoReal}
                        onChange={() => alternar(clave)}
                      />
                      <span className="min-w-0 flex-1 truncate font-mono text-xs">{a.nombreArchivoLab}</span>
                      <span className="whitespace-nowrap rounded-full bg-slate-100 px-2 py-0.5 text-[11px] font-bold text-slate-700">{a.tamanoImpresion}</span>
                      {a.sinFotoReal && <span className="text-[11px] font-bold text-red-600">Falta la foto</span>}
                    </label>
                  </li>
                );
              })}
            </ul>
          </div>

          <div>
            <p className="text-xs font-bold uppercase tracking-wider text-slate-600">2. Por qué se reimprime</p>
            <div className="mt-2 grid gap-2 sm:grid-cols-3">
              {MOTIVOS_REIMPRESION.map((m) => (
                <button
                  key={m.valor}
                  type="button"
                  aria-pressed={motivo === m.valor}
                  onClick={() => setMotivo(m.valor)}
                  className={`rounded-xl border-2 bg-white p-2.5 text-left ${motivo === m.valor ? 'border-amber-500 shadow-sm' : 'border-transparent hover:border-slate-200'}`}
                >
                  <span className="block text-sm font-extrabold text-slate-900">{m.texto}</span>
                  <span className="block text-[11px] text-slate-600">{m.detalle}</span>
                </button>
              ))}
            </div>
            <input
              value={detalle}
              onChange={(e) => setDetalle(e.target.value)}
              placeholder={motivo === 'falla_laboratorio' ? 'Detalle (opcional): ej. salió con franjas' : 'Contanos qué pasó'}
              className="mt-2 w-full rounded-xl border border-slate-300 bg-white px-3 py-2 text-sm"
              maxLength={600}
            />
          </div>

          <button
            type="button"
            onClick={() => void descargar()}
            disabled={!puedeDescargar}
            className="flex w-full items-center justify-center gap-2 rounded-2xl bg-slate-900 px-5 py-3 text-sm font-extrabold text-white hover:bg-slate-800 disabled:bg-slate-300 disabled:text-slate-500"
          >
            {descargando ? <Loader2 className="h-4 w-4 animate-spin" /> : <FolderDown className="h-4 w-4 text-amber-400" />}
            {descargando ? 'Armando el ZIP…' : `Descargar ZIP de reimpresión · ${archivosElegidos.length} foto(s)`}
          </button>
          <p className="text-center text-[11px] text-slate-500">Las carpetas del ZIP siguen la opción elegida arriba ("Por tamaño" o "Por alumno").</p>
        </div>
      )}
    </section>
  );
}
