import { useRef, useState } from 'react';
import { RefreshCw, Send, Square } from 'lucide-react';
import { publicarFotosAdmin, type FotoRegistrada } from '../services/fotosSubidasService';

// 25/10/2026 (Pablo): «Publicar todos los cursos» en «Cursos con Fotos Subidas». Publica curso por curso (cada uno
// manda su aviso «¡Las fotos ya están online!»), de a uno, esperando que termine cada curso y con una pausa entre
// cursos: cada publicación es un solo pedido a Resend por cada 100 familias, así que no se pasa del límite de
// ~2 pedidos por segundo y deja lugar a los demás emails (pagos, descargas). Va aparte para no agrandar AdminLoteFotosTab.
export const PAUSA_ENTRE_CURSOS_MS = 1500;

export interface FilaCursoPublicable {
  clave: string;
  grado: string;
  turno: string;
  division: string;
  individual: number;
  sinPublicar: number;
}

export function nombreCurso(fila: Pick<FilaCursoPublicable, 'grado' | 'division' | 'turno'>): string {
  return [fila.grado, fila.division, fila.turno].filter(Boolean).join(' · ');
}

/** Fotos sin publicar de un curso: el mismo filtro que el botón «Publicar» de cada fila. */
export function idsSinPublicarDelCurso(fotos: FotoRegistrada[], fila: FilaCursoPublicable, colegioId: string): string[] {
  return fotos
    .filter((f) => !f.publicada && (!f.colegioId || f.colegioId === colegioId) &&
      (f.grado || '') === fila.grado && (f.turno || '') === fila.turno && (f.division || '') === fila.division)
    .map((f) => f.id);
}

interface Props {
  filas: FilaCursoPublicable[];
  fotos: FotoRegistrada[];
  colegioId: string;
  deshabilitado: boolean;
  alTerminar: () => Promise<void>;
}

export default function PublicarTodosCursos({ filas, fotos, colegioId, deshabilitado, alTerminar }: Props) {
  const [progreso, setProgreso] = useState<string | null>(null);
  const [resultado, setResultado] = useState<{ ok: boolean; texto: string } | null>(null);
  const detener = useRef(false);
  const pendientes = filas.filter((f) => f.sinPublicar > 0);
  if (!colegioId || pendientes.length < 2) return null;

  const publicarTodos = async () => {
    if (progreso) return;
    const totalFotos = pendientes.reduce((n, f) => n + f.sinPublicar, 0);
    if (!window.confirm(
      `¿Publicar ${totalFotos} foto(s) de ${pendientes.length} cursos?\n\nSe publican de a uno. Las familias de cada curso empiezan a ver sus fotos y, si el curso todavía no fue avisado, les llega el email «¡Las fotos ya están online!».\n\nNo cierres esta pestaña hasta que termine.`
    )) return;
    let lista = pendientes;
    const sinIndividuales = pendientes.filter((f) => f.individual === 0);
    if (sinIndividuales.length > 0) {
      const incluir = window.confirm(
        `${sinIndividuales.length} curso(s) no tienen fotos individuales:\n\n${sinIndividuales.map((f) => `• ${nombreCurso(f)}`).join('\n')}\n\nA esas familias les llega el email y no van a encontrar la individual.\n\nAceptar = publicarlos igual · Cancelar = dejarlos sin publicar`
      );
      if (!incluir) lista = pendientes.filter((f) => f.individual > 0);
    }
    if (lista.length === 0) return;

    detener.current = false;
    setResultado(null);
    let publicadas = 0;
    let emails = 0;
    let hechos = 0;
    const errores: string[] = [];
    for (let i = 0; i < lista.length; i++) {
      if (detener.current) break;
      const fila = lista[i];
      setProgreso(`Publicando ${i + 1} de ${lista.length}: ${nombreCurso(fila)}…`);
      const ids = idsSinPublicarDelCurso(fotos, fila, colegioId);
      if (ids.length > 0) {
        const r = await publicarFotosAdmin({ ids });
        publicadas += r.publicadas || 0;
        emails += r.emailsEnviados || 0;
        if (!r.success) errores.push(`${nombreCurso(fila)}: ${r.error || 'no se pudo publicar'}`);
        else if (r.warning) errores.push(`${nombreCurso(fila)}: ${r.warning}`);
      }
      hechos++;
      if (i + 1 < lista.length && !detener.current) await new Promise((ok) => setTimeout(ok, PAUSA_ENTRE_CURSOS_MS));
    }
    setProgreso(null);
    const cortado = hechos < lista.length;
    setResultado({
      ok: errores.length === 0 && !cortado,
      texto:
        `${cortado ? `Detenido: se procesaron ${hechos} de ${lista.length} cursos. ` : `Listo: ${hechos} cursos. `}` +
        `${publicadas} foto(s) publicadas, se avisó por email a ${emails} familia(s).` +
        (errores.length > 0 ? ` Revisá: ${errores.join(' · ')}` : ''),
    });
    await alTerminar();
  };

  return (
    <div className="flex flex-wrap items-center gap-2">
      {progreso ? (
        <>
          <span role="status" className="text-[11px] font-semibold text-amber-800 flex items-center gap-1.5">
            <RefreshCw className="w-3 h-3 animate-spin" aria-hidden="true" /> {progreso}
          </span>
          <button
            type="button"
            onClick={() => { detener.current = true; }}
            className="px-2.5 py-1 bg-white hover:bg-slate-100 text-[11px] font-bold text-slate-700 rounded-lg border border-slate-300 transition-colors flex items-center gap-1.5 cursor-pointer"
          >
            <Square className="w-3 h-3" aria-hidden="true" /> Detener después de este curso
          </button>
        </>
      ) : (
        <button
          type="button"
          onClick={() => void publicarTodos()}
          disabled={deshabilitado}
          className="px-2.5 py-1 bg-amber-400 hover:bg-amber-300 disabled:opacity-50 text-[11px] font-extrabold text-slate-950 rounded-lg border border-amber-500 transition-colors flex items-center gap-1.5 cursor-pointer"
          title="Publica uno por uno todos los cursos con fotos sin publicar y avisa a sus familias"
        >
          <Send className="w-3 h-3" aria-hidden="true" /> Publicar todos los cursos ({pendientes.length})
        </button>
      )}
      {resultado && (
        <span role="status" className={`text-[11px] font-semibold ${resultado.ok ? 'text-emerald-700' : 'text-rose-700'}`}>{resultado.texto}</span>
      )}
    </div>
  );
}
