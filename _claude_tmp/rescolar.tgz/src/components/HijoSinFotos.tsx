import { useCallback, useEffect, useState } from 'react';
import { Undo2, UserMinus } from 'lucide-react';

/**
 * 26/10/2026 (Pablo, caso Cristina Villar: «cargué a mis 2 hijos pero de uno no quiero las fotos»): la galería exigía
 * elegir las fotos de TODOS los hermanos para poder pagar. Ahora la familia puede marcar «No quiero las fotos de este
 * hijo/a»: ese chico no se suma a la compra y no se le piden fotos. Se guarda sólo en este navegador (sessionStorage)
 * y se puede deshacer. El servidor no cambia: cobra sólo los chicos que vienen en la compra.
 */
const clave = (familiaId: string) => `hijos_sin_fotos_v1:${familiaId}`;

export function useHijosSinFotos(familiaId: string | null | undefined) {
  const [ids, setIds] = useState<string[]>([]);
  useEffect(() => {
    if (!familiaId) return setIds([]);
    try {
      const guardado = sessionStorage.getItem(clave(familiaId));
      setIds(guardado ? (JSON.parse(guardado) as string[]).filter((x) => typeof x === 'string') : []);
    } catch {
      setIds([]);
    }
  }, [familiaId]);
  const excluido = useCallback((id: string) => ids.includes(id), [ids]);
  const marcar = useCallback(
    (id: string, noQuiere: boolean) => {
      setIds((prev) => {
        const nuevo = noQuiere ? [...prev.filter((x) => x !== id), id] : prev.filter((x) => x !== id);
        try {
          if (familiaId) sessionStorage.setItem(clave(familiaId), JSON.stringify(nuevo));
        } catch {
          /* sin sessionStorage: queda sólo en memoria */
        }
        return nuevo;
      });
    },
    [familiaId]
  );
  return { excluido, marcar };
}

const BOTON = 'shrink-0 inline-flex items-center gap-1.5 rounded-lg border px-3 py-2 sm:py-1.5 text-xs font-bold cursor-pointer';

/** Arriba de la galería del hijo activo (sólo con más de un hijo). */
export function AvisoHijoSinFotos({ nombre, excluido, puedeExcluir, onCambiar }: { nombre: string; excluido: boolean; puedeExcluir: boolean; onCambiar: (noQuiere: boolean) => void }) {
  if (excluido) {
    return (
      <div role="status" className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-amber-300 bg-amber-50 px-3 py-2.5 text-left">
        <p className="text-xs text-amber-900">
          <strong>Marcaste que no querés las fotos de {nombre}.</strong> No se suma a esta compra.
        </p>
        <button type="button" onClick={() => onCambiar(false)} className={`${BOTON} border-amber-400 bg-white text-amber-900 hover:bg-amber-100`}>
          <Undo2 className="w-3.5 h-3.5" aria-hidden="true" />
          Sí, quiero sus fotos
        </button>
      </div>
    );
  }
  if (!puedeExcluir) return null;
  return (
    <div className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-left">
      <p className="text-xs text-slate-600">¿No querés las fotos de {nombre}? Podés comprar sólo las de tus otros hijos.</p>
      <button type="button" onClick={() => onCambiar(true)} className={`${BOTON} border-slate-300 bg-white text-slate-700 hover:bg-slate-100`}>
        <UserMinus className="w-3.5 h-3.5" aria-hidden="true" />
        No quiero sus fotos
      </button>
    </div>
  );
}
