import { Fragment, useCallback, useEffect, useRef, useState } from 'react';
import { MessageCircle, Loader2, Trash2, CheckCircle2, Mail, School, RefreshCw, Filter, X, Send, KeyRound, AlertTriangle } from 'lucide-react';
import {
  SolicitudCodigo,
  obtenerSolicitudesCodigoAdmin,
  marcarSolicitudCodigoAtendidaAdmin,
  eliminarSolicitudCodigoAdmin,
  responderSolicitudCodigoAdmin,
  reenviarCodigoSolicitudAdmin,
} from '../services/solicitudesCodigoService';
import { asegurarCodigoSeccionAdmin } from '../services/codigosSeccionService';
import { useClaveEnvio } from '../utils/claveEnvio';
import { useBorradorAdmin } from '../utils/useBorradorAdmin';

/**
 * Auditoría 03/10 noche (M12): toda solicitud que llega acá es de un email que NO coincide con una
 * inscripción aprobada (si coincidiera, el portal le manda el código solo). Antes, al tocar
 * "Responder", se precargaba el código REAL del curso: cualquiera que inventara un pedido con el
 * colegio y el curso recibía el código. Ahora la respuesta por defecto invita a inscribirse, y el
 * código sólo se carga si Pablo lo pide a propósito (botón aparte, con confirmación).
 */
export const AVISO_EMAIL_NO_VERIFICADO = 'Email no verificado: no coincide con ninguna inscripción aprobada.';

export function respuestaInvitandoAInscribirse(): string {
  return (
    'Recibimos tu pedido del código de acceso. El email que nos dejaste no coincide con ninguna inscripción aprobada, ' +
    'así que por seguridad no podemos mandarte el código por este medio.\n\n' +
    'Para recibirlo, inscribí a tu hijo/a en retratoescolar.com.ar con el botón "Inscribirme" (es gratis), usando este mismo email. ' +
    'Apenas revisemos la inscripción te llega el código de acceso al curso.'
  );
}

export default function AdminSolicitudesCodigoTab() {
  const [filtro, setFiltro] = useState<'pendiente' | 'todas'>('pendiente');
  const [solicitudes, setSolicitudes] = useState<SolicitudCodigo[]>([]);
  const [cargando, setCargando] = useState(true);
  const [procesandoId, setProcesandoId] = useState<string | null>(null);
  // Auditoría 2026-09-16 (pedido de Pablo: "quiero que haya un botón para responder por email
  // del sistema" — el cartel de arriba ya sugería "por WhatsApp o email" pero el email había que
  // mandarlo a mano desde afuera): mismo patrón inline que ya usa AdminConsultasFamiliasTab.tsx,
  // adaptado a una fila de tabla en vez de una tarjeta.
  const [respondiendoId, setRespondiendoId] = useState<string | null>(null);
  // 14/10/2026: la respuesta a medio escribir se guarda sola (borrador «solicitud-<id>»).
  const [respuesta, setRespuesta, borradorRespuesta] = useBorradorAdmin(respondiendoId ? `solicitud-${respondiendoId}` : null, '');
  const [respuestaEnviadaId, setRespuestaEnviadaId] = useState<string | null>(null);
  const [errorRespuesta, setErrorRespuesta] = useState<string | null>(null);
  // Auditoría 2026-09-16, segunda vuelta (pedido de Pablo: "no puede ser automática la entrega
  // del mensaje con el código?"): al abrir "Responder", si la familia dejó colegio+grado+turno+
  // división al pedirlo, se busca (o se crea, si esa sección todavía no tenía uno) el Código de
  // Acceso real de esa sección con el mismo mecanismo que ya usa la pestaña "Códigos y difusión"
  // — así Pablo no tiene que escribirlo a mano, solo revisar y enviar. Si la familia no dejó esos
  // datos, se sigue pidiendo el texto a mano como antes.
  const [buscandoCodigo, setBuscandoCodigo] = useState(false);
  const [codigoEncontrado, setCodigoEncontrado] = useState<string | null>(null);
  const [avisoSinCodigo, setAvisoSinCodigo] = useState<string | null>(null);
  // Auditoría 03/10 noche (M12): solicitud con la respuesta abierta ahora (para descartar la búsqueda
  // del código de otra solicitud que termine tarde).
  const respondiendoRef = useRef<string | null>(null);
  const { claveParaEnviar, reiniciar: reiniciarClave } = useClaveEnvio();
  respondiendoRef.current = respondiendoId;

  const cargar = useCallback(async () => {
    setCargando(true);
    const data = await obtenerSolicitudesCodigoAdmin(filtro);
    setSolicitudes(data);
    setCargando(false);
  }, [filtro]);

  useEffect(() => {
    void cargar();
  }, [cargar]);

  const handleAtender = async (id: string) => {
    setProcesandoId(id);
    try {
      const resultado = await marcarSolicitudCodigoAtendidaAdmin(id);
      if (resultado.success) {
        if (filtro === 'pendiente') {
          setSolicitudes((prev) => prev.filter((s) => s.id !== id));
        } else {
          setSolicitudes((prev) => prev.map((s) => (s.id === id ? { ...s, estado: 'atendido' } : s)));
        }
      } else {
        window.alert(resultado.error || 'No se pudo marcar como atendida.');
      }
    } finally {
      setProcesandoId(null);
    }
  };

  // 28/10/2026: reenvío del código con un clic cuando el email ya tiene una inscripción aprobada
  // (antes había que ir a Inscriptos, buscar a la familia, «Reenviar Email» y volver a marcar ✓ acá).
  const [avisoReenvio, setAvisoReenvio] = useState<{ tipo: 'ok' | 'error'; texto: string } | null>(null);
  const [reenviandoTodas, setReenviandoTodas] = useState(false);

  const quitarAtendidas = (ids: string[]) => {
    const atendidas = new Set(ids);
    if (filtro === 'pendiente') {
      setSolicitudes((prev) => prev.filter((s) => !atendidas.has(s.id)));
    } else {
      setSolicitudes((prev) => prev.map((s) => (atendidas.has(s.id) ? { ...s, estado: 'atendido' } : s)));
    }
  };

  const handleReenviarCodigo = async (s: SolicitudCodigo) => {
    setProcesandoId(s.id);
    setAvisoReenvio(null);
    try {
      const r = await reenviarCodigoSolicitudAdmin(s.id);
      if (r.success) {
        if (respondiendoId === s.id) setRespondiendoId(null);
        quitarAtendidas(r.atendidas || [s.id]);
        setAvisoReenvio({ tipo: 'ok', texto: `Código reenviado a ${r.email || s.contacto}.` });
      } else {
        setAvisoReenvio({ tipo: 'error', texto: `${s.contacto}: ${r.error || 'no se pudo reenviar el código.'}` });
      }
    } finally {
      setProcesandoId(null);
    }
  };

  const pendientesAprobadas = solicitudes.filter((s) => s.estado !== 'atendido' && s.inscripcionAprobada);
  const emailsAprobados = [...new Set(pendientesAprobadas.map((s) => s.contacto.trim().toLowerCase()))];

  const handleReenviarTodas = async () => {
    if (emailsAprobados.length === 0) return;
    if (!window.confirm(`¿Reenviar el código a ${emailsAprobados.length} ${emailsAprobados.length === 1 ? 'familia' : 'familias'} que ya tienen la inscripción aprobada?\n\nLes llega el mismo email de «Reenviar Email» de Inscriptos y las solicitudes quedan atendidas.`)) return;
    setReenviandoTodas(true);
    setAvisoReenvio(null);
    let enviados = 0;
    const fallidos: string[] = [];
    const vistos = new Set<string>();
    try {
      for (const s of pendientesAprobadas) {
        const email = s.contacto.trim().toLowerCase();
        if (vistos.has(email)) continue; // las repetidas se cierran con la primera
        vistos.add(email);
        const r = await reenviarCodigoSolicitudAdmin(s.id);
        if (r.success) {
          enviados += 1;
          quitarAtendidas(r.atendidas || [s.id]);
        } else {
          fallidos.push(`${s.contacto} (${r.error || 'error'})`);
        }
      }
    } finally {
      setReenviandoTodas(false);
      setAvisoReenvio(
        fallidos.length
          ? { tipo: 'error', texto: `Enviados: ${enviados}. No se pudo con: ${fallidos.join(', ')}.` }
          : { tipo: 'ok', texto: `Listo: código reenviado a ${enviados} ${enviados === 1 ? 'familia' : 'familias'}.` }
      );
    }
  };

  const handleEliminar = async (id: string) => {
    const confirmado = window.confirm('¿Eliminar esta solicitud de la lista?');
    if (!confirmado) return;
    setProcesandoId(id);
    try {
      const resultado = await eliminarSolicitudCodigoAdmin(id);
      if (resultado.success) {
        setSolicitudes((prev) => prev.filter((s) => s.id !== id));
      } else {
        window.alert(resultado.error || 'No se pudo eliminar la solicitud.');
      }
    } finally {
      setProcesandoId(null);
    }
  };

  const handleAbrirRespuesta = (s: SolicitudCodigo) => {
    respondiendoRef.current = s.id;
    setRespondiendoId(s.id);
    // Auditoría 03/10 noche (M12): por defecto NO se carga el código: se invita a inscribirse.
    borradorRespuesta.fijarSinGuardar(s.inscripcionAprobada ? '' : respuestaInvitandoAInscribirse());
    setErrorRespuesta(null);
    setRespuestaEnviadaId(null);
    setCodigoEncontrado(null);
    setAvisoSinCodigo(null);
    setBuscandoCodigo(false);
  };

  /** Sólo a pedido explícito de Pablo y con confirmación (el email no está verificado). */
  const handleCargarCodigoIgual = async (s: SolicitudCodigo) => {
    if (!s.colegioId || !s.grado || !s.turno || !s.division) return;
    const curso = [s.grado, s.division, s.turno].filter(Boolean).join(' · ');
    const ok = window.confirm(
      `${AVISO_EMAIL_NO_VERIFICADO}\n\n¿Mandarle IGUAL a ${s.contacto} el código de ${curso}${s.colegioNombre ? ` (${s.colegioNombre})` : ''}?\n\n` +
        'Con ese código se ven las fotos de todo el curso. Hacelo sólo si confirmaste por otro medio (WhatsApp, la seño, el colegio) que es una familia de ese curso.'
    );
    if (!ok) return;
    setAvisoSinCodigo(null);
    setBuscandoCodigo(true);
    try {
      const resultado = await asegurarCodigoSeccionAdmin(s.colegioId, s.grado, s.turno, s.division);
      if (respondiendoRef.current !== s.id) return; // se abrió otra solicitud mientras tanto
      if (resultado.success && resultado.codigo) {
        setCodigoEncontrado(resultado.codigo);
        setRespuesta('');
      } else {
        setAvisoSinCodigo(
          resultado.error || 'No pudimos ubicar el código de esa sección automáticamente — escribí la respuesta a mano.'
        );
      }
    } finally {
      if (respondiendoRef.current === s.id) setBuscandoCodigo(false);
    }
  };

  const handleEnviarRespuesta = async (s: SolicitudCodigo) => {
    if (!codigoEncontrado && respuesta.trim().length < 2) return;
    setProcesandoId(s.id);
    setErrorRespuesta(null);
    try {
      // 14/10: misma clave para el mismo texto: un reintento tras un corte no le duplica el email a la familia.
      const clave = claveParaEnviar(`${s.id}|${codigoEncontrado || ''}|${respuesta.trim()}`);
      const resultado = await responderSolicitudCodigoAdmin(s.id, respuesta.trim(), codigoEncontrado || undefined, clave);
      if (resultado.success) {
        reiniciarClave();
        void borradorRespuesta.borrar(`solicitud-${s.id}`);
        setRespondiendoId(null);
        borradorRespuesta.fijarSinGuardar('');
        setRespuestaEnviadaId(s.id);
        // El servidor ya marcó la solicitud como atendida al enviar el email — se refleja acá
        // sin esperar un refresco manual, igual que hace handleAtender.
        if (filtro === 'pendiente') {
          setSolicitudes((prev) => prev.filter((item) => item.id !== s.id));
        } else {
          setSolicitudes((prev) => prev.map((item) => (item.id === s.id ? { ...item, estado: 'atendido' } : item)));
        }
      } else {
        setErrorRespuesta(resultado.error || 'No se pudo enviar la respuesta.');
      }
    } finally {
      setProcesandoId(null);
    }
  };

  return (
    <div className="space-y-4 animate-in fade-in duration-200">
      <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-2xl text-xs text-emerald-900 flex items-start gap-2.5">
        <MessageCircle className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
        <p>
          Acá caen las familias que tocaron <strong>"Solicitar mi Código"</strong> en el portal porque no encontraron
          su código de curso. Tocá <strong>"Responder"</strong> para mandarles el código por email directo desde el
          sistema (queda registrada como atendida automáticamente), o marcala como atendida a mano si preferís
          resolverlo por WhatsApp.
        </p>
      </div>

      <div className="flex items-center justify-between gap-2">
        <div className="flex items-center gap-1.5 bg-slate-100 rounded-xl p-1">
          <button
            type="button"
            onClick={() => setFiltro('pendiente')}
            className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-colors cursor-pointer flex items-center gap-1.5 ${
              filtro === 'pendiente' ? 'bg-white text-slate-900 shadow-2xs' : 'text-slate-500 hover:text-slate-700'
            }`}
          >
            <Filter className="w-3.5 h-3.5" />
            <span>Pendientes</span>
          </button>
          <button
            type="button"
            onClick={() => setFiltro('todas')}
            className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-colors cursor-pointer ${
              filtro === 'todas' ? 'bg-white text-slate-900 shadow-2xs' : 'text-slate-500 hover:text-slate-700'
            }`}
          >
            Todas
          </button>
        </div>
        <div className="flex items-center gap-2">
        {emailsAprobados.length > 0 && (
          <button
            type="button"
            onClick={() => void handleReenviarTodas()}
            disabled={reenviandoTodas || procesandoId !== null}
            className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold rounded-xl shadow-2xs transition-colors flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
          >
            {reenviandoTodas ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <KeyRound className="w-3.5 h-3.5" />}
            <span>Reenviar código a las aprobadas ({emailsAprobados.length})</span>
          </button>
        )}
        <button
          type="button"
          onClick={cargar}
          className="px-3 py-1.5 bg-white hover:bg-slate-100 text-slate-600 border border-slate-200 text-xs font-bold rounded-xl shadow-2xs transition-colors flex items-center gap-1.5 cursor-pointer"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${cargando ? 'animate-spin' : ''}`} />
          <span>Actualizar</span>
        </button>
        </div>
      </div>

      {avisoReenvio && (
        <div
          role="status"
          className={`flex items-start gap-2 px-3 py-2 rounded-xl text-[11px] border ${
            avisoReenvio.tipo === 'ok' ? 'bg-emerald-50 border-emerald-200 text-emerald-900' : 'bg-red-50 border-red-200 text-red-900'
          }`}
        >
          {avisoReenvio.tipo === 'ok' ? (
            <CheckCircle2 className="h-4 w-4 text-emerald-600 shrink-0 mt-0.5" />
          ) : (
            <AlertTriangle className="h-4 w-4 text-red-600 shrink-0 mt-0.5" />
          )}
          <p className="flex-1">{avisoReenvio.texto}</p>
          <button type="button" onClick={() => setAvisoReenvio(null)} className="shrink-0 cursor-pointer" aria-label="Cerrar aviso">
            <X className="h-3.5 w-3.5" />
          </button>
        </div>
      )}

      <div className="overflow-x-auto rounded-2xl border border-slate-200 bg-white shadow-2xs">
        <table className="w-full text-xs">
          <thead className="bg-slate-50 text-slate-500 uppercase font-semibold border-b border-slate-200 text-[10px] tracking-wider">
            <tr>
              <th className="py-2.5 px-3">Familia</th>
              <th className="py-2.5 px-3">Contacto</th>
              <th className="py-2.5 px-3">Alumno / Curso</th>
              <th className="py-2.5 px-3">Colegio</th>
              <th className="py-2.5 px-3">Estado</th>
              <th className="py-2.5 px-3 text-right">Acciones</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {cargando ? (
              <tr>
                <td colSpan={6} className="py-8 text-center text-slate-400">
                  <Loader2 className="w-5 h-5 mx-auto animate-spin" />
                </td>
              </tr>
            ) : solicitudes.length === 0 ? (
              <tr>
                <td colSpan={6} className="py-8 text-center text-slate-400 text-xs">
                  {filtro === 'pendiente' ? 'No hay solicitudes pendientes. 🎉' : 'Todavía no hay solicitudes.'}
                </td>
              </tr>
            ) : (
              solicitudes.map((s) => (
                <Fragment key={s.id}>
                <tr className="hover:bg-slate-50/70">
                  <td className="py-2.5 px-3 font-semibold text-slate-800">{s.nombreSolicitante}</td>
                  <td className="py-2.5 px-3">
                    <span className="flex items-center gap-1 text-slate-600 font-mono">
                      <Mail className="w-3 h-3 text-emerald-500 shrink-0" /> {s.contacto}
                    </span>
                  </td>
                  <td className="py-2.5 px-3 text-slate-600">
                    {s.alumnoNombre || '—'}
                    {(s.grado || s.division || s.turno) && (
                      <div className="text-[10px] text-slate-400">
                        {[s.grado, s.division, s.turno].filter(Boolean).join(' · ')}
                      </div>
                    )}
                  </td>
                  <td className="py-2.5 px-3 text-slate-600">
                    {s.colegioNombre ? (
                      <span className="flex items-center gap-1">
                        <School className="w-3 h-3 text-slate-400 shrink-0" /> {s.colegioNombre}
                      </span>
                    ) : (
                      '—'
                    )}
                  </td>
                  <td className="py-2.5 px-3">
                    {s.estado === 'atendido' ? (
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">
                        Atendido
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-800 border border-amber-200">
                        Pendiente
                      </span>
                    )}
                  </td>
                  <td className="py-2.5 px-3 text-right">
                    <div className="flex items-center justify-end gap-1">
                      {s.inscripcionAprobada && s.estado !== 'atendido' && (
                        <button
                          type="button"
                          onClick={() => void handleReenviarCodigo(s)}
                          disabled={procesandoId === s.id || reenviandoTodas}
                          title="Le reenvía el email con el código de su inscripción aprobada y marca la solicitud como atendida"
                          className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-[10px] font-bold inline-flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
                        >
                          {procesandoId === s.id ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <KeyRound className="w-3.5 h-3.5" />}
                          Reenviar código
                        </button>
                      )}
                      <button
                        type="button"
                        onClick={() => (respondiendoId === s.id ? setRespondiendoId(null) : handleAbrirRespuesta(s))}
                        disabled={procesandoId === s.id}
                        className="px-3 py-1.5 bg-sky-600 hover:bg-sky-500 text-white rounded-xl text-[10px] font-bold inline-flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
                      >
                        <Mail className="w-3.5 h-3.5" />
                        Responder
                      </button>
                      {s.estado !== 'atendido' && (
                        <button
                          type="button"
                          onClick={() => handleAtender(s.id)}
                          disabled={procesandoId === s.id}
                          className="p-1.5 text-slate-400 hover:text-emerald-600 hover:bg-emerald-50 rounded-lg transition-colors cursor-pointer disabled:opacity-50"
                          title="Marcar como atendida"
                        >
                          {procesandoId === s.id ? (
                            <Loader2 className="w-3.5 h-3.5 animate-spin" />
                          ) : (
                            <CheckCircle2 className="w-3.5 h-3.5" />
                          )}
                        </button>
                      )}
                      <button
                        type="button"
                        onClick={() => handleEliminar(s.id)}
                        disabled={procesandoId === s.id}
                        className="p-1.5 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors cursor-pointer disabled:opacity-50"
                        title="Eliminar solicitud"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </td>
                </tr>
                {respondiendoId === s.id && (
                  <tr>
                    <td colSpan={6} className="py-3 px-3 bg-sky-50/60 border-t border-sky-100">
                      <div className="flex flex-col gap-2">
                        {/* 25/10: el email ya coincide con una inscripción aprobada (se corrigió después del pedido). */}
                        {s.inscripcionAprobada ? (
                          <div role="status" className="flex items-start gap-2 px-3 py-2 rounded-xl bg-emerald-50 border border-emerald-200 text-[11px] text-emerald-900">
                            <CheckCircle2 className="h-4 w-4 text-emerald-600 shrink-0 mt-0.5" />
                            <p>
                              <strong>Este email ya tiene una inscripción aprobada.</strong> Tocá «Reenviar código»: le llega el email con su código
                              (el mismo de Inscriptos) y la solicitud queda atendida. No hace falta escribir nada.
                            </p>
                          </div>
                        ) : (
                        <div role="alert" className="flex items-start gap-2 px-3 py-2 rounded-xl bg-red-50 border border-red-200">
                          <AlertTriangle className="h-4 w-4 text-red-600 shrink-0 mt-0.5" />
                          <div className="text-[11px] text-red-900 space-y-1">
                            <p className="font-bold">{AVISO_EMAIL_NO_VERIFICADO}</p>
                            <p>
                              La respuesta de abajo lo invita a inscribirse en el formulario. Mandale el código del curso sólo si confirmaste
                              por otro medio que es una familia de ese curso.
                            </p>
                            {!codigoEncontrado && !buscandoCodigo && s.colegioId && s.grado && s.turno && s.division && (
                              <button
                                type="button"
                                onClick={() => void handleCargarCodigoIgual(s)}
                                className="mt-1 px-2.5 py-1 bg-white hover:bg-red-100 text-red-700 border border-red-300 rounded-lg text-[10px] font-bold inline-flex items-center gap-1 cursor-pointer"
                              >
                                <KeyRound className="w-3.5 h-3.5" />
                                Cargar código del curso igual
                              </button>
                            )}
                          </div>
                        </div>
                        )}
                        {buscandoCodigo && (
                          <p className="flex items-center gap-1.5 text-[11px] font-semibold text-slate-500">
                            <Loader2 className="h-3.5 w-3.5 animate-spin" />
                            Buscando el código de acceso de esa sección...
                          </p>
                        )}
                        {codigoEncontrado && (
                          <div className="flex items-center gap-2 px-3 py-2 rounded-xl bg-emerald-50 border border-emerald-200">
                            <KeyRound className="h-4 w-4 text-emerald-600 shrink-0" />
                            <p className="text-[11px] text-emerald-900">
                              Encontramos el código de <strong>{[s.grado, s.division, s.turno].filter(Boolean).join(' · ')}</strong>:{' '}
                              <span className="font-mono font-extrabold tracking-wider">{codigoEncontrado}</span> — se manda
                              destacado en el email, no hace falta que lo escribas.
                            </p>
                            <button
                              type="button"
                              onClick={() => { setCodigoEncontrado(null); setRespuesta(respuestaInvitandoAInscribirse()); }}
                              className="ml-auto shrink-0 px-2 py-1 bg-white hover:bg-slate-100 text-slate-600 border border-slate-200 rounded-lg text-[10px] font-bold cursor-pointer"
                            >
                              No mandar el código
                            </button>
                          </div>
                        )}
                        {avisoSinCodigo && (
                          <div className="flex items-start gap-2 px-3 py-2 rounded-xl bg-amber-50 border border-amber-200">
                            <AlertTriangle className="h-4 w-4 text-amber-600 shrink-0 mt-0.5" />
                            <p className="text-[11px] text-amber-900">{avisoSinCodigo}</p>
                          </div>
                        )}
                        <textarea
                          value={respuesta}
                          onChange={(e) => setRespuesta(e.target.value)}
                          minLength={codigoEncontrado ? 0 : 2}
                          maxLength={5000}
                          rows={3}
                          autoFocus
                          placeholder={
                            codigoEncontrado
                              ? 'Aclaración opcional (el código ya se agrega solo, no hace falta escribirlo)...'
                              : `Escribí la respuesta que le va a llegar por email a ${s.contacto}...`
                          }
                          className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-sky-400"
                        />
                        {errorRespuesta && (
                          <p className="text-[11px] font-semibold text-red-600">{errorRespuesta}</p>
                        )}
                        <div className="flex items-center justify-end gap-2">
                          <button
                            type="button"
                            onClick={() => setRespondiendoId(null)}
                            className="px-3 py-1.5 bg-white hover:bg-slate-100 text-slate-500 border border-slate-200 rounded-xl text-[10px] font-bold inline-flex items-center gap-1 cursor-pointer"
                          >
                            <X className="w-3.5 h-3.5" />
                            Cancelar
                          </button>
                          <button
                            type="button"
                            onClick={() => handleEnviarRespuesta(s)}
                            disabled={procesandoId === s.id || buscandoCodigo || (!codigoEncontrado && respuesta.trim().length < 2)}
                            className="px-3 py-1.5 bg-sky-600 hover:bg-sky-500 text-white rounded-xl text-[10px] font-bold inline-flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
                          >
                            {procesandoId === s.id ? (
                              <Loader2 className="w-3.5 h-3.5 animate-spin" />
                            ) : (
                              <Send className="w-3.5 h-3.5" />
                            )}
                            Enviar respuesta
                          </button>
                        </div>
                      </div>
                    </td>
                  </tr>
                )}
                {respuestaEnviadaId === s.id && respondiendoId !== s.id && (
                  <tr>
                    <td colSpan={6} className="py-2 px-3 bg-emerald-50/60 border-t border-emerald-100">
                      <p className="flex items-center gap-1.5 text-[11px] font-semibold text-emerald-700">
                        <CheckCircle2 className="h-3.5 w-3.5" />
                        Respuesta enviada correctamente.
                      </p>
                    </td>
                  </tr>
                )}
                </Fragment>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
