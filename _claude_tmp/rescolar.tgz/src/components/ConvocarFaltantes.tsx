import { useState, type FormEvent } from 'react';
import { CalendarClock, Loader2, Send } from 'lucide-react';
import { convocarFaltantesAdmin, diaConvocatoria, type SolicitudFaltanteAdmin } from '../services/fotosFaltantesService';

// 25/10/2026 (Pablo): en «Faltantes solicitadas» se tildan pedidos pendientes y se les manda a las familias un mail
// con el día, la hora y el lugar para sacar la foto que falta (la grupal no se convoca). Un mail por familia.
// Servidor: servidor/familias/convocatoriaFaltantes.ts. Va aparte para no agrandar AdminFaltantesTab.

/** Se puede convocar: pendiente, no grupal y con email. */
export const esConvocable = (s: SolicitudFaltanteAdmin) => s.estado === 'pendiente' && s.lugar !== 'grupal' && /\S+@\S+\.\S+/.test(String(s.contacto_email || ''));

export function textoConvocada(s: SolicitudFaltanteAdmin): string {
  if (!s.convocatoria_dia) return '';
  return `Convocada: ${diaConvocatoria(s.convocatoria_dia)}${s.convocatoria_hora ? ` ${s.convocatoria_hora}` : ''}${s.convocatoria_lugar ? ` · ${s.convocatoria_lugar}` : ''}`;
}

const hoy = () => new Date().toLocaleDateString('en-CA', { timeZone: 'America/Argentina/Buenos_Aires' });

interface Props {
  elegidas: SolicitudFaltanteAdmin[];
  alTerminar: (mensaje: string, ok: boolean) => void;
}

export default function ConvocarFaltantes({ elegidas, alTerminar }: Props) {
  const [dia, setDia] = useState('');
  const [hora, setHora] = useState('');
  const [lugar, setLugar] = useState('');
  const [nota, setNota] = useState('');
  const [enviando, setEnviando] = useState(false);
  const [error, setError] = useState('');
  if (elegidas.length === 0) return null;

  const familias = new Set(elegidas.map((s) => String(s.contacto_email || '').trim().toLowerCase())).size;
  const yaConvocadas = elegidas.filter((s) => s.convocatoria_dia).length;

  const enviar = async (e: FormEvent) => {
    e.preventDefault();
    if (enviando) return;
    if (!dia || !hora.trim() || lugar.trim().length < 2) return setError('Completá día, hora y lugar.');
    if (!window.confirm(
      `¿Mandar la convocatoria a ${familias} familia(s) (${elegidas.length} pedido(s))?\n\n${diaConvocatoria(dia)} · ${hora} · ${lugar}` +
      (yaConvocadas > 0 ? `\n\n${yaConvocadas} de estos pedidos ya estaban convocados: les llega el mail nuevo con estos datos.` : '')
    )) return;
    setEnviando(true);
    setError('');
    const r = await convocarFaltantesAdmin(elegidas.map((s) => s.id), { dia, hora: hora.trim(), lugar: lugar.trim(), nota: nota.trim() });
    setEnviando(false);
    if (!r.success) return setError(r.error || 'No se pudo mandar la convocatoria.');
    const problemas = [
      r.fallidos && r.fallidos.length > 0 ? `No salió el mail de: ${r.fallidos.join(', ')}.` : '',
      r.sinEmail && r.sinEmail.length > 0 ? `Sin email: ${r.sinEmail.join(', ')}.` : '',
      r.omitidos ? `${r.omitidos} pedido(s) ya no estaban pendientes o eran de grupal: no se convocaron.` : '',
    ].filter(Boolean).join(' ');
    alTerminar(`Convocatoria enviada a ${r.familiasConvocadas || 0} familia(s) (${r.pedidosConvocados || 0} pedido(s)).${problemas ? ` ${problemas}` : ''}`, !problemas);
  };

  return (
    <form onSubmit={(e) => void enviar(e)} className="rounded-2xl border border-amber-300 bg-amber-50 p-3 space-y-2">
      <p className="text-xs font-bold text-amber-950 flex items-center gap-1.5">
        <CalendarClock className="w-4 h-4" aria-hidden="true" /> Convocar a {familias} familia(s) ({elegidas.length} pedido(s) elegidos) para sacar la foto
      </p>
      <div className="flex flex-wrap items-end gap-2">
        <label className="text-xs font-semibold text-slate-700">
          Día
          <input type="date" required min={hoy()} value={dia} onChange={(e) => setDia(e.target.value)} className="mt-1 block rounded-xl border border-slate-300 px-3 py-2 text-sm font-normal bg-white" />
        </label>
        <label className="text-xs font-semibold text-slate-700">
          Hora
          <input type="text" required maxLength={40} placeholder="Ej.: 9:30 a 11 hs" value={hora} onChange={(e) => setHora(e.target.value)} className="mt-1 block w-36 rounded-xl border border-slate-300 px-3 py-2 text-sm font-normal bg-white" />
        </label>
        <label className="text-xs font-semibold text-slate-700 grow min-w-[12rem]">
          Lugar
          <input type="text" required maxLength={200} placeholder="Ej.: En el colegio, salón de actos" value={lugar} onChange={(e) => setLugar(e.target.value)} className="mt-1 block w-full rounded-xl border border-slate-300 px-3 py-2 text-sm font-normal bg-white" />
        </label>
      </div>
      <label className="block text-xs font-semibold text-slate-700">
        Nota para las familias (opcional)
        <textarea maxLength={500} rows={2} placeholder="Ej.: Que venga con el uniforme del colegio." value={nota} onChange={(e) => setNota(e.target.value)} className="mt-1 block w-full rounded-xl border border-slate-300 px-3 py-2 text-sm font-normal bg-white" />
      </label>
      <div className="flex flex-wrap items-center gap-2">
        <button type="submit" disabled={enviando} className="inline-flex items-center gap-1.5 rounded-xl bg-amber-400 hover:bg-amber-300 border border-amber-500 px-3 py-2 text-xs font-extrabold text-slate-950 disabled:opacity-50 cursor-pointer">
          {enviando ? <Loader2 className="w-3.5 h-3.5 animate-spin" aria-hidden="true" /> : <Send className="w-3.5 h-3.5" aria-hidden="true" />} Mandar convocatoria por email
        </button>
        {error && <p role="alert" className="text-xs font-semibold text-rose-700">{error}</p>}
      </div>
    </form>
  );
}
