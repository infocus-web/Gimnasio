import React, { useState } from 'react';
import { Camera, CheckCircle2, Loader2 } from 'lucide-react';
import { guardarFotoHermanosFamilia, type InscripcionFamilia } from '../services/inscripcionesService';

// 14/10/2026 (pedido de Pablo: «agreguemos esa opción como producto a elegir en cualquier momento»): la foto de
// hermanos juntos se saca en el colegio, un día que Pablo elige y avisa a los anotados. Desde el portal la familia
// se anota (o se baja) cuando quiera; la paga después, al elegirla publicada, como un pedido nuevo (evento).
// Sólo se muestra a familias con hermanos anotados. «Anotada» = eligió que sí (con fecha de confirmación): una
// marca vieja sin confirmar (las que dejó el error del 08/10) no cuenta.

interface Props {
  familia: InscripcionFamilia;
  onActualizada: (familia: InscripcionFamilia) => void;
}

export default function TarjetaFotoHermanos({ familia, onActualizada }: Props) {
  const anotada = Boolean(familia.solicitaFotoHermanos && familia.fotoHermanosConfirmadaAt);
  const [abierta, setAbierta] = useState(false);
  const [email, setEmail] = useState(familia.email || '');
  const [whatsapp, setWhatsapp] = useState(familia.telefonoWhatsApp || '');
  const [guardando, setGuardando] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!Array.isArray(familia.hermanos) || familia.hermanos.length === 0 || !familia.accesoGaleria) return null;

  const guardar = async (quiere: boolean) => {
    if (guardando) return;
    setGuardando(true);
    setError(null);
    const r = await guardarFotoHermanosFamilia({ familiaId: familia.id, acceso: familia.accesoGaleria || '', quiere, email: email.trim(), whatsapp: whatsapp.trim() });
    setGuardando(false);
    if (!r.success) {
      setError(r.error || 'No pudimos guardar tu respuesta.');
      return;
    }
    setAbierta(false);
    onActualizada({ ...familia, solicitaFotoHermanos: quiere, fotoHermanosConfirmadaAt: r.fotoHermanosConfirmadaAt || new Date().toISOString() });
  };

  return (
    <div className="mt-3 rounded-xl border border-amber-200 bg-amber-50/60 px-3.5 py-3 space-y-2">
      <p className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
        {anotada ? <CheckCircle2 className="w-4 h-4 text-emerald-600" /> : <Camera className="w-4 h-4 text-amber-600" />}
        Foto de hermanos juntos
      </p>
      {anotada ? (
        <p className="text-[11px] text-slate-700 leading-relaxed">
          Ya están anotados. La sacamos en el colegio: te avisamos el día por email y WhatsApp. Cuando esté publicada, la elegís y la pagás como un pedido nuevo (no está incluida en el kit).{' '}
          <button type="button" onClick={() => void guardar(false)} disabled={guardando} className="font-semibold text-slate-500 underline hover:text-slate-800 cursor-pointer disabled:opacity-50">
            {guardando ? 'Guardando…' : 'Ya no la quiero'}
          </button>
        </p>
      ) : (
        <>
          <p className="text-[11px] text-slate-700 leading-relaxed">
            La sacamos en el colegio, un día que te avisamos por email y WhatsApp. Tiene un costo aparte (no está incluida en el kit): cuando esté publicada, la elegís y la pagás como un pedido nuevo.
          </p>
          {!abierta ? (
            <button
              type="button"
              onClick={() => setAbierta(true)}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold bg-amber-500 text-slate-950 hover:bg-amber-400 cursor-pointer"
            >
              Quiero la foto de hermanos
            </button>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              <label className="text-[11px] font-semibold text-slate-600">
                Email para el aviso
                <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} disabled={guardando} autoComplete="email" className="mt-1 w-full rounded-lg border border-slate-300 bg-white px-2.5 py-1.5 text-xs font-normal" />
              </label>
              <label className="text-[11px] font-semibold text-slate-600">
                WhatsApp (con código de área)
                <input type="tel" value={whatsapp} onChange={(e) => setWhatsapp(e.target.value)} disabled={guardando} autoComplete="tel" className="mt-1 w-full rounded-lg border border-slate-300 bg-white px-2.5 py-1.5 text-xs font-normal" />
              </label>
              <div className="sm:col-span-2 flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  onClick={() => void guardar(true)}
                  disabled={guardando}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold bg-amber-500 text-slate-950 hover:bg-amber-400 disabled:opacity-50 cursor-pointer"
                >
                  {guardando && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
                  Anotarme
                </button>
                <button type="button" onClick={() => setAbierta(false)} disabled={guardando} className="px-3 py-1.5 rounded-xl text-xs font-semibold text-slate-600 hover:bg-white cursor-pointer">
                  Cancelar
                </button>
              </div>
            </div>
          )}
        </>
      )}
      {error && <p role="alert" className="text-[11px] font-semibold text-rose-700">{error}</p>}
    </div>
  );
}
