import React, { useCallback, useMemo, useState } from 'react';
import { ArrowRightLeft, CheckCircle2, Loader2, Mail, X } from 'lucide-react';
import { cambiarCursoAlumnoAdmin, type AlumnoNominaReal, type ResultadoCambioCursoAlumno } from '../services/colegiosService';
import { enviarEmailAprobacionAdmin } from '../services/inscripcionesService';

// Nómina del panel: pasar a un alumno mal cargado a otro curso (pedido de Pablo, 13/10/2026).
// Sólo ofrece cursos que ya existen en la nómina del mismo colegio; el servidor vuelve a controlarlo.
// Está fuera de AdminModal.tsx a propósito (ese archivo tiene techo de líneas): la Nómina sólo usa
// `useCambioCursoNomina` y `NombreConCambioCurso`.

export interface CursoDeLaNominaPanel {
  clave: string;
  grado: string;
  division: string;
  turno: string | null;
  totalAlumnos: number;
}

export const etiquetaCursoNomina = (c: { grado: string; division: string; turno: string | null }) =>
  `${c.grado} "${c.division}" (${c.turno || 'sin turno'})`;

interface Props {
  alumno: AlumnoNominaReal;
  cursos: CursoDeLaNominaPanel[];
  onCerrar: () => void;
  onGuardado: (alumno: AlumnoNominaReal) => void;
}

const claveCurso = (a: { grado: string; division: string; turno: string | null }) => `${a.grado}__${a.division}__${a.turno || ''}`;

/** Cursos de la nómina por colegio (los únicos destinos posibles), el modal y la función para abrirlo. */
export function useCambioCursoNomina(
  alumnos: AlumnoNominaReal[],
  setAlumnos: React.Dispatch<React.SetStateAction<AlumnoNominaReal[]>>
) {
  const [alumno, setAlumno] = useState<AlumnoNominaReal | null>(null);
  const cursosPorColegio = useMemo(() => {
    const porColegio = new Map<string, Map<string, CursoDeLaNominaPanel>>();
    alumnos.forEach((a) => {
      const colegio = a.colegio_id || '';
      if (!porColegio.has(colegio)) porColegio.set(colegio, new Map());
      const cursos = porColegio.get(colegio)!;
      const clave = claveCurso(a);
      const existente = cursos.get(clave);
      if (existente) existente.totalAlumnos += 1;
      else cursos.set(clave, { clave, grado: a.grado, division: a.division, turno: a.turno, totalAlumnos: 1 });
    });
    const resultado = new Map<string, CursoDeLaNominaPanel[]>();
    porColegio.forEach((cursos, colegio) => {
      const texto = (c: CursoDeLaNominaPanel) => `${c.grado} ${c.division} ${c.turno || ''}`;
      resultado.set(colegio, [...cursos.values()].sort((x, y) => texto(x).localeCompare(texto(y), 'es', { numeric: true })));
    });
    return resultado;
  }, [alumnos]);

  const abrirCambioCurso = useCallback((a: AlumnoNominaReal) => setAlumno(a), []);
  const modalCambioCurso = alumno ? (
    <ModalCambiarCursoAlumno
      alumno={alumno}
      cursos={cursosPorColegio.get(alumno.colegio_id || '') || []}
      onCerrar={() => setAlumno(null)}
      onGuardado={(actualizado) => {
        setAlumnos((prev) => prev.map((a) => (a.id === actualizado.id ? { ...a, ...actualizado } : a)));
      }}
    />
  ) : null;
  return { abrirCambioCurso, modalCambioCurso };
}

/** Celda de nombre de la Nómina con el botón «Curso» (no marca la fila como fotografiada). */
export function NombreConCambioCurso({ alumno, onCambiar }: { alumno: AlumnoNominaReal; onCambiar: (a: AlumnoNominaReal) => void }) {
  return (
    <div className="flex items-center justify-between gap-2">
      <span className="min-w-0 truncate">{alumno.nombre}</span>
      <button
        type="button"
        onClick={(event) => {
          event.stopPropagation();
          onCambiar(alumno);
        }}
        title="Cambiar de curso"
        aria-label={`Cambiar de curso a ${alumno.nombre}`}
        className="shrink-0 inline-flex items-center gap-1 rounded-md border border-slate-200 px-1.5 py-0.5 text-[10px] font-semibold text-slate-500 hover:border-amber-400 hover:text-amber-700 hover:bg-amber-50 cursor-pointer"
      >
        <ArrowRightLeft className="w-3 h-3" /> <span className="hidden sm:inline">Curso</span>
      </button>
    </div>
  );
}

export default function ModalCambiarCursoAlumno({ alumno, cursos, onCerrar, onGuardado }: Props) {
  const claveActual = claveCurso(alumno);
  const opciones = useMemo(() => cursos.filter((c) => c.clave !== claveActual), [cursos, claveActual]);
  const [elegido, setElegido] = useState('');
  const [guardando, setGuardando] = useState(false);
  const [error, setError] = useState<string | null>(null);
  // 14/10/2026: después de mover, qué inscripciones de familias se movieron (y el código nuevo para mandarles).
  const [resultado, setResultado] = useState<ResultadoCambioCursoAlumno | null>(null);
  const [envios, setEnvios] = useState<Record<string, 'enviando' | 'enviado' | string>>({});
  const destino = opciones.find((c) => c.clave === elegido) || null;

  const guardar = async () => {
    if (!destino || guardando) return;
    setGuardando(true);
    setError(null);
    const r = await cambiarCursoAlumnoAdmin(alumno.id, { grado: destino.grado, division: destino.division, turno: destino.turno });
    setGuardando(false);
    if (!r.success || !r.alumno) {
      setError(r.error || 'No se pudo cambiar de curso al alumno.');
      return;
    }
    onGuardado(r.alumno);
    if ((r.inscripciones?.length ?? 0) === 0 && !r.cursoSinCodigo && !r.errorInscripciones) {
      onCerrar();
      return;
    }
    setResultado(r);
  };

  const mandarCodigo = async (id: string) => {
    if (envios[id] === 'enviando' || envios[id] === 'enviado') return;
    setEnvios((prev) => ({ ...prev, [id]: 'enviando' }));
    const r = await enviarEmailAprobacionAdmin(id, { reenviar: true });
    setEnvios((prev) => ({ ...prev, [id]: r.success ? 'enviado' : r.error || 'No se pudo enviar el email.' }));
  };

  if (resultado) {
    return (
      <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4" onClick={onCerrar}>
        <div
          role="dialog"
          aria-modal="true"
          aria-labelledby="titulo-cambiar-curso"
          className="bg-white rounded-2xl p-5 w-full max-w-md shadow-xl space-y-4"
          onClick={(e) => e.stopPropagation()}
        >
          <div className="flex items-start justify-between gap-3">
            <div className="min-w-0">
              <p id="titulo-cambiar-curso" className="font-bold text-slate-900 text-sm flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" /> Curso cambiado
              </p>
              <p className="text-xs text-slate-700 mt-1 font-semibold truncate">{alumno.nombre}</p>
              {resultado.alumno && <p className="text-[11px] text-slate-500">Ahora: {etiquetaCursoNomina(resultado.alumno)}</p>}
            </div>
            <button type="button" onClick={onCerrar} className="p-1 text-slate-400 hover:text-slate-700 cursor-pointer" aria-label="Cerrar">
              <X className="w-5 h-5" />
            </button>
          </div>

          {(resultado.inscripciones || []).map((insc) => {
            const envio = envios[insc.id];
            return (
              <div key={insc.id} className="rounded-xl border border-slate-200 p-3 space-y-2">
                <p className="text-[11px] text-slate-700">
                  También se movió la inscripción de <span className="font-semibold">{insc.padre || 'la familia'}</span>
                  {insc.email ? ` (${insc.email})` : ''}.
                </p>
                {insc.esHermano || !insc.codigoNuevo ? (
                  <p className="text-[11px] text-slate-500">Está anotado como hermano: el código de la familia no cambia.</p>
                ) : (
                  <>
                    <p className="text-[11px] text-slate-700">
                      Código nuevo del curso: <span className="font-mono font-bold text-slate-900 select-all">{insc.codigoNuevo}</span>
                      <span className="block text-slate-500">El código anterior ya no le sirve: hay que mandarle este.</span>
                    </p>
                    {insc.email && (
                      <div className="flex items-center gap-2 flex-wrap">
                        <button
                          type="button"
                          onClick={() => void mandarCodigo(insc.id)}
                          disabled={envio === 'enviando' || envio === 'enviado'}
                          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold bg-amber-500 text-white hover:bg-amber-600 disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer"
                        >
                          {envio === 'enviando' ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Mail className="w-3.5 h-3.5" />}
                          {envio === 'enviado' ? 'Email enviado' : 'Mandarle el código por email'}
                        </button>
                        {envio && envio !== 'enviando' && envio !== 'enviado' && (
                          <span role="alert" className="text-[11px] font-semibold text-rose-700">{envio}</span>
                        )}
                      </div>
                    )}
                  </>
                )}
              </div>
            );
          })}

          {resultado.cursoSinCodigo && (
            <p role="alert" className="text-[11px] font-semibold text-amber-700">
              El curso nuevo todavía no tiene código, así que la inscripción de la familia quedó en el curso viejo: corregila a mano.
            </p>
          )}
          {resultado.errorInscripciones && <p role="alert" className="text-[11px] font-semibold text-rose-700">{resultado.errorInscripciones}</p>}

          <div className="flex justify-end">
            <button type="button" onClick={onCerrar} className="px-3 py-2 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100 cursor-pointer">
              Listo
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4" onClick={() => !guardando && onCerrar()}>
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby="titulo-cambiar-curso"
        className="bg-white rounded-2xl p-5 w-full max-w-md shadow-xl space-y-4"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-start justify-between gap-3">
          <div className="min-w-0">
            <p id="titulo-cambiar-curso" className="font-bold text-slate-900 text-sm flex items-center gap-2">
              <ArrowRightLeft className="w-4 h-4 text-amber-600" /> Cambiar de curso
            </p>
            <p className="text-xs text-slate-700 mt-1 font-semibold truncate">{alumno.nombre}</p>
            <p className="text-[11px] text-slate-500">Hoy: {etiquetaCursoNomina(alumno)}</p>
          </div>
          <button type="button" onClick={onCerrar} disabled={guardando} className="p-1 text-slate-400 hover:text-slate-700 cursor-pointer" aria-label="Cerrar">
            <X className="w-5 h-5" />
          </button>
        </div>

        <label className="block text-[11px] font-semibold text-slate-700">
          Curso correcto
          <select
            value={elegido}
            onChange={(e) => setElegido(e.target.value)}
            disabled={guardando}
            autoFocus
            className="mt-1 w-full rounded-xl border border-slate-300 px-3 py-2 text-xs font-normal bg-white"
          >
            <option value="">Elegí el curso…</option>
            {opciones.map((c) => (
              <option key={c.clave} value={c.clave}>
                {etiquetaCursoNomina(c)} · {c.totalAlumnos} alumnos
              </option>
            ))}
          </select>
        </label>

        <p className="text-[10px] text-slate-500 leading-relaxed">
          Queda último en la lista del curso nuevo. Si la familia ya está inscripta en el curso viejo, su inscripción también
          se mueve y te mostramos el código nuevo para mandárselo.
        </p>

        {error && <p role="alert" className="text-[11px] font-semibold text-rose-700">{error}</p>}

        <div className="flex justify-end gap-2">
          <button type="button" onClick={onCerrar} disabled={guardando} className="px-3 py-2 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100 cursor-pointer">
            Cancelar
          </button>
          <button
            type="button"
            onClick={() => void guardar()}
            disabled={!destino || guardando}
            className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold bg-amber-500 text-white hover:bg-amber-600 disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer"
          >
            {guardando && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
            Mover a este curso
          </button>
        </div>
      </div>
    </div>
  );
}
