import { useEffect, useState } from 'react';
import { Check, Copy, FileSignature, Loader2, School } from 'lucide-react';
import { obtenerLinksConvenioAdmin, useColegiosLista, type LinkConvenioColegio } from '../services/colegiosService';
import { copiarAlPortapapeles } from '../utils/portapapeles';

/**
 * Convenio con cada colegio (27/9): link para que la secretaría lo complete y lo firme online
 * (/convenio.html?c=CODIGO), haciéndose cargo de las autorizaciones de familias y docentes. Es un
 * link distinto del de padrón (ese se reenvía a las familias; este es sólo para el colegio).
 */
export default function AdminConvenioColegios() {
  const { colegios } = useColegiosLista();
  const [links, setLinks] = useState<Record<string, LinkConvenioColegio>>({});
  const [cargando, setCargando] = useState(true);
  const [copiadoId, setCopiadoId] = useState<string | null>(null);

  useEffect(() => {
    obtenerLinksConvenioAdmin().then((l) => {
      setLinks(l);
      setCargando(false);
    });
  }, []);

  const linkDe = (id: string) => (links[id] ? `${window.location.origin}/convenio.html?c=${encodeURIComponent(links[id].codigo)}` : '');

  const copiar = async (id: string) => {
    const link = linkDe(id);
    if (!link) return;
    if (await copiarAlPortapapeles(link)) {
      setCopiadoId(id);
      setTimeout(() => setCopiadoId((a) => (a === id ? null : a)), 2000);
    } else {
      window.prompt('Copiá el link manualmente:', link);
    }
  };

  return (
    <div className="bg-white rounded-2xl border border-slate-200 p-4 sm:p-5 space-y-3">
      <h4 className="text-xs font-extrabold text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
        <FileSignature className="w-4 h-4 text-slate-500" />
        <span>Convenio para que firme el colegio (sólo para la dirección, no para las familias)</span>
      </h4>
      <p className="text-[11px] text-slate-500">
        El colegio completa sus datos, carga los alumnos que no deben ser fotografiados y firma. Les llega una copia por email a ellos y a vos.
      </p>
      {cargando ? (
        <div className="py-4 text-center text-slate-400">
          <Loader2 className="w-5 h-5 mx-auto animate-spin" />
        </div>
      ) : colegios.length === 0 ? (
        <p className="text-xs text-slate-400 py-2 text-center">Todavía no cargaste ningún colegio.</p>
      ) : (
        <div className="space-y-2">
          {colegios.map((c) => (
            <div key={c.id} className="p-3 rounded-xl border border-slate-200 bg-slate-50 flex flex-col sm:flex-row sm:items-center gap-2">
              <span className="text-xs font-bold text-slate-800 flex items-center gap-1.5 sm:w-52 shrink-0">
                <School className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                <span className="truncate">{c.nombre}</span>
              </span>
              {links[c.id] ? (
                <div className="flex items-center gap-1.5 flex-1 min-w-0">
                  <input readOnly value={linkDe(c.id)} onFocus={(e) => e.target.select()} className="flex-1 min-w-0 px-2.5 py-1.5 rounded-lg border border-slate-200 bg-white text-[11px] font-mono text-slate-600" />
                  <button type="button" onClick={() => void copiar(c.id)} title="Copiar link" className="p-1.5 rounded-lg text-slate-400 hover:text-amber-600 hover:bg-amber-100 shrink-0">
                    {copiadoId === c.id ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                  </button>
                  <span className={`shrink-0 rounded-full px-2 py-0.5 text-[10px] font-bold ${links[c.id].firmadoAt ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'}`} title={links[c.id].firmante || ''}>
                    {links[c.id].firmadoAt ? `Firmado ${new Date(links[c.id].firmadoAt!).toLocaleDateString('es-AR')}` : 'Sin firmar'}
                  </span>
                </div>
              ) : (
                <p className="text-[11px] text-slate-400">No se pudo generar el link.</p>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
