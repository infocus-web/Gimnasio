import { act, render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { afterEach, describe, expect, it, vi } from 'vitest';
import AdminLiquidacionColegios from '../AdminLiquidacionColegios';
import AdminConsultasFamiliasTab from '../AdminConsultasFamiliasTab';

// Auditoría 03/10 noche (R8 y R9): respuestas viejas del servidor que pisaban la pantalla.

function diferido<T>() {
  let resolver!: (v: T) => void;
  const promesa = new Promise<T>((r) => {
    resolver = r;
  });
  return { promesa, resolver };
}

const mocks = vi.hoisted(() => ({
  obtenerLiquidacionColegio: vi.fn(),
  guardarPorcentajeColegio: vi.fn(),
  obtenerConsultasFamiliasAdmin: vi.fn(),
  sugerirRespuestaConsultaFamiliaAdmin: vi.fn(),
}));

vi.mock('../../services/colegiosService', () => ({
  useColegiosLista: () => ({ colegios: [{ id: 'c1', nombre: 'Colegio Uno' }, { id: 'c2', nombre: 'Colegio Dos' }] }),
  obtenerCostosLiquidacion: async () => null,
  guardarCostosLiquidacion: async () => ({ success: true }),
  actualizarComisionesReales: async () => ({ success: true, pendientes: 0 }),
  obtenerLiquidacionColegio: mocks.obtenerLiquidacionColegio,
  guardarPorcentajeColegio: mocks.guardarPorcentajeColegio,
}));

vi.mock('../../services/consultasFamiliasService', () => ({
  obtenerConsultasFamiliasAdmin: mocks.obtenerConsultasFamiliasAdmin,
  sugerirRespuestaConsultaFamiliaAdmin: mocks.sugerirRespuestaConsultaFamiliaAdmin,
  actualizarEstadoConsultaFamiliaAdmin: async () => undefined,
  eliminarConsultaFamiliaAdmin: async () => undefined,
  responderConsultaFamiliaAdmin: async () => undefined,
}));

afterEach(() => {
  vi.clearAllMocks();
});

const anio = new Date().getFullYear();
const liquidacion = (id: string, nombre: string, porcentaje: number) => ({
  success: true,
  liquidacion: {
    colegio: { id, nombre },
    porcentaje,
    porcentajeDelConvenio: false,
    convenioFirmado: null,
    costos: { costo_carpeta: 0, costo_foto_20x30: 0, costo_foto_15x21: 0, comision_mercadopago_pct: 0, comision_nave_pct: 0, impuestos_pct: 0 },
    topesAnexoIV: null,
    periodo: { desde: `${anio}-01-01`, hasta: `${anio}-12-31` },
    filas: [],
    totales: { pedidos: 0, venta: 0, costoLaboratorio: 0, comision: 0, impuestos: 0, ganancia: 0 },
    resumenPorMedio: [],
    participacion: 0,
    pedidosConFotosPendientes: 0,
    comisionesEstimadas: 0,
    comisionesPorActualizar: 0,
  },
});

describe('Liquidación al colegio (R8)', () => {
  it('descarta la respuesta vieja del colegio anterior y "Guardar %" graba en el colegio elegido', async () => {
    const delUno = diferido<unknown>();
    const delDos = diferido<unknown>();
    mocks.obtenerLiquidacionColegio.mockImplementation((id: string) => (id === 'c1' ? delUno.promesa : delDos.promesa));
    mocks.guardarPorcentajeColegio.mockResolvedValue({ success: true });

    render(<AdminLiquidacionColegios />);
    await waitFor(() => expect(mocks.obtenerLiquidacionColegio).toHaveBeenCalledWith('c1', expect.any(String), expect.any(String)));
    // Se cambia de colegio antes de que conteste el primero.
    await userEvent.selectOptions(screen.getAllByRole('combobox')[0], 'c2');
    await waitFor(() => expect(mocks.obtenerLiquidacionColegio).toHaveBeenCalledWith('c2', expect.any(String), expect.any(String)));

    await act(async () => delDos.resolver(liquidacion('c2', 'Colegio Dos', 40)));
    expect(await screen.findByText(/Para el colegio \(40%\)/)).toBeInTheDocument();
    // La del colegio anterior llega tarde: no tiene que pisar nada.
    await act(async () => delUno.resolver(liquidacion('c1', 'Colegio Uno', 25)));
    expect(screen.getByText(/Para el colegio \(40%\)/)).toBeInTheDocument();
    expect(screen.queryByText(/Para el colegio \(25%\)/)).not.toBeInTheDocument();
    expect(screen.getByLabelText(/% para el colegio/)).toHaveValue(40);

    await userEvent.click(screen.getByRole('button', { name: 'Guardar %' }));
    await waitFor(() => expect(mocks.guardarPorcentajeColegio).toHaveBeenCalledWith('c2', '40'));
    expect(mocks.guardarPorcentajeColegio).not.toHaveBeenCalledWith('c1', expect.anything());
  });
});

const consulta = (id: string, nombre: string, borradorIa: string) => ({
  id,
  nombre,
  email: `${id}@familia.com`,
  asunto: `Consulta de ${nombre}`,
  mensaje: 'Hola',
  estado: 'nueva',
  origen: 'web',
  createdAt: new Date().toISOString(),
  updatedAt: new Date().toISOString(),
  mensajes: [],
  borradorIa,
});

describe('Consultas de familias (R9)', () => {
  it('la sugerencia de la IA para A no cae en la respuesta que se está escribiendo para B', async () => {
    mocks.obtenerConsultasFamiliasAdmin.mockResolvedValue([consulta('a', 'Ana', 'borrador A'), consulta('b', 'Beto', 'borrador B')]);
    const sugerenciaA = diferido<{ sugerencia: string; aviso?: string }>();
    mocks.sugerirRespuestaConsultaFamiliaAdmin.mockImplementation(() => sugerenciaA.promesa);

    render(<AdminConsultasFamiliasTab />);
    await userEvent.click(await screen.findByRole('button', { name: /Ana/ }));
    await userEvent.click(screen.getByRole('button', { name: /^Responder$/ }));
    await userEvent.click(screen.getByRole('button', { name: /Sugerir con IA/ }));

    // Mientras la IA piensa, Pablo pasa a la consulta de Beto y empieza a escribir.
    await userEvent.click(screen.getByRole('button', { name: /Beto/ }));
    await userEvent.click(screen.getByRole('button', { name: /^Responder$/ }));
    const cuadro = screen.getByPlaceholderText(/Escribí la respuesta para la familia/) as HTMLTextAreaElement;
    expect(screen.getByText('Responder a b@familia.com')).toBeInTheDocument();
    await userEvent.type(cuadro, ' y algo más');

    await act(async () => sugerenciaA.resolver({ sugerencia: 'Sugerencia para Ana' }));
    expect((screen.getByPlaceholderText(/Escribí la respuesta para la familia/) as HTMLTextAreaElement).value).toBe('borrador B y algo más');
  });

  it('si sigue abierta la misma consulta, la sugerencia sí se aplica', async () => {
    mocks.obtenerConsultasFamiliasAdmin.mockResolvedValue([consulta('a', 'Ana', '')]);
    mocks.sugerirRespuestaConsultaFamiliaAdmin.mockResolvedValue({ sugerencia: 'Sugerencia para Ana' });

    render(<AdminConsultasFamiliasTab />);
    await userEvent.click(await screen.findByRole('button', { name: /Ana/ }));
    await userEvent.click(screen.getByRole('button', { name: /^Responder$/ }));
    await userEvent.click(screen.getByRole('button', { name: /Sugerir con IA/ }));
    await waitFor(() =>
      expect((screen.getByPlaceholderText(/Escribí la respuesta para la familia/) as HTMLTextAreaElement).value).toBe('Sugerencia para Ana')
    );
  });
});
