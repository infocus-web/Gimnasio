// 10/10/2026 (Pablo: «debo hacer que firmen el convenio antes de mostrarles esto»): en el panel de Pablo,
// el bloque «Panel del colegio» avisa si el colegio todavía no firmó el convenio y el mensaje con el PIN
// le pide primero firmarlo.
import { describe, expect, it, vi } from 'vitest';
import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';

const h = vi.hoisted(() => ({ copiado: [] as string[], firmado: false }));

vi.mock('../../utils/portapapeles', () => ({
  copiarAlPortapapeles: vi.fn(async (texto: string) => {
    h.copiado.push(texto);
    return true;
  }),
}));

vi.mock('../../services/panelColegioService', () => {
  const panel = () => ({
    convenio: h.firmado
      ? { firmado: true, fecha: '2026-10-12T15:00:00Z', link: 'https://www.retratoescolar.com.ar/convenio.html?c=CVPRUEBA' }
      : { firmado: false, fecha: null, link: 'https://www.retratoescolar.com.ar/convenio.html?c=CVPRUEBA' },
    activo: true,
    link: 'https://www.retratoescolar.com.ar/colegio?c=PC0123',
    tienePin: false,
    pinActualizadoAt: null,
    fechas: { tomaFotos: null, cierrePedidos: null, entregaKits: null },
  });
  return {
    obtenerPanelColegioAdmin: vi.fn(async () => panel()),
    generarPinColegioAdmin: vi.fn(async () => ({ pin: '482913', panel: { ...panel(), tienePin: true } })),
    guardarPanelColegioAdmin: vi.fn(async () => panel()),
    abrirVistaPreviaColegioAdmin: vi.fn(async () => ({ token: 'colegiovista.x', codigo: '', colegioNombre: 'Colegio de Prueba', venceAt: Date.now() + 7200_000, vistaPrevia: true })),
  };
});

import AdminPanelColegioAcceso from '../AdminPanelColegioAcceso';

describe('panel del colegio en el panel de Pablo: convenio', () => {
  it('sin convenio firmado: avisa, deja copiar el link del convenio y el mensaje con el PIN pide firmarlo primero', async () => {
    h.firmado = false;
    h.copiado = [];
    const user = userEvent.setup();
    render(<AdminPanelColegioAcceso colegioId="c1" colegioNombre="Colegio de Prueba" />);
    await user.click(screen.getByRole('button', { name: /Panel del colegio/ }));
    expect(await screen.findByText(/Todavía no firmó el convenio/)).toBeInTheDocument();

    await user.click(screen.getByRole('button', { name: /Copiar link del convenio/ }));
    expect(h.copiado.at(-1)).toBe('https://www.retratoescolar.com.ar/convenio.html?c=CVPRUEBA');

    await user.click(screen.getByRole('button', { name: /Generar PIN/ }));
    await user.click(await screen.findByRole('button', { name: /Copiar mensaje con link y PIN/ }));
    const mensaje = h.copiado.at(-1) || '';
    expect(mensaje).toContain('se habilita cuando el colegio firma el convenio');
    expect(mensaje.indexOf('convenio.html?c=CVPRUEBA')).toBeLessThan(mensaje.indexOf('colegio?c=PC0123'));
    expect(mensaje).toContain('PIN: 482913');
  });

  it('«Ver cómo lo ve el colegio» abre la vista previa en otra pestaña (aunque no haya firmado ni tenga PIN)', async () => {
    h.firmado = false;
    const pestana = { location: { href: '' }, close: vi.fn() };
    const abrir = vi.spyOn(window, 'open').mockReturnValue(pestana as unknown as Window);
    const user = userEvent.setup();
    render(<AdminPanelColegioAcceso colegioId="c1" colegioNombre="Colegio de Prueba" />);
    await user.click(screen.getByRole('button', { name: /Panel del colegio/ }));
    await user.click(await screen.findByRole('button', { name: /Ver cómo lo ve el colegio/ }));
    expect(abrir).toHaveBeenCalled();
    await vi.waitFor(() => expect(pestana.location.href).toBe('/colegio?vista=1'));
    abrir.mockRestore();
  });

  it('con convenio firmado: lo muestra y el mensaje va directo al panel', async () => {
    h.firmado = true;
    h.copiado = [];
    const user = userEvent.setup();
    render(<AdminPanelColegioAcceso colegioId="c1" colegioNombre="Colegio de Prueba" />);
    await user.click(screen.getByRole('button', { name: /Panel del colegio/ }));
    expect(await screen.findByText(/Convenio firmado el 12\/10\/2026/)).toBeInTheDocument();
    expect(screen.queryByText(/Todavía no firmó el convenio/)).toBeNull();
    await user.click(screen.getByRole('button', { name: /Generar PIN/ }));
    await user.click(await screen.findByRole('button', { name: /Copiar mensaje con link y PIN/ }));
    const mensaje = h.copiado.at(-1) || '';
    expect(mensaje).not.toContain('convenio.html');
    expect(mensaje).toContain('PIN: 482913');
  });
});
