import { render, screen, waitFor, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { beforeEach, describe, expect, it, vi } from 'vitest';
import PortalFamiliasModal from '../PortalFamiliasModal';
import { familiaActivaMellizos, fotosSeccionCompartida, mockearFetchFamiliaYGaleria } from '../../test/fixtures/familiaMellizos';

// 22/10/2026 (Pablo: «si un alumno le falta una foto … no podrá terminar el pedido»): en cada lugar del pack la
// familia puede avisar «Mi hijo/a no tiene esta foto» y elegir otra foto del curso en su lugar.
// 26/10/2026 (Pablo): «el kit sí o sí lleva 3 fotos» (ya no se sigue sin ella) y, en la grupal, la familia nos avisa.

type Implementacion = (input: RequestInfo | URL, init?: RequestInit) => Promise<Response>;
const json = (status: number, cuerpo: unknown) => ({ ok: status >= 200 && status < 300, status, json: async () => cuerpo }) as Response;
const urlDe = (input: RequestInfo | URL) => (typeof input === 'string' ? input : input.toString());
function sobreescribirFetch(coincide: (url: string) => boolean, respuesta: (url: string, init?: RequestInit) => Response) {
  const fetchBase = global.fetch as unknown as ReturnType<typeof vi.fn>;
  const base = fetchBase.getMockImplementation() as Implementacion | undefined;
  fetchBase.mockImplementation(async (input: RequestInfo | URL, init?: RequestInit) => {
    const url = urlDe(input);
    if (coincide(url)) return respuesta(url, init);
    return base ? base(input, init) : json(404, { success: false });
  });
}
const llamadas = (fragmento: string) =>
  (global.fetch as unknown as ReturnType<typeof vi.fn>).mock.calls.filter((c) => urlDe(c[0] as RequestInfo).includes(fragmento));

const SLOTS = { grupal: /^1\/3 grupal$/i, individual: /^2\/3 retrato$/i, docente: /^3\/3 con seño$/i };
async function irAlLugar(user: ReturnType<typeof userEvent.setup>, lugar: keyof typeof SLOTS) {
  await user.click(screen.getByText(SLOTS[lugar]).closest('div')!.parentElement!);
}
/** Toca «Elegir» en la tarjeta cuya miniatura es la de esa foto. */
async function elegirTarjeta(user: ReturnType<typeof userEvent.setup>, thumb: string) {
  const img = await waitFor(() => {
    const encontrada = Array.from(document.querySelectorAll('img.pointer-events-none')).find((i) => i.getAttribute('src')?.includes(thumb));
    expect(encontrada).toBeTruthy();
    return encontrada!;
  });
  const tarjeta = img.closest('div.relative.bg-white') as HTMLElement;
  await user.click(within(tarjeta).getByRole('button', { name: /^(elegir|elegida|usar en su lugar|quitar)$/i }));
}

describe('«Mi hijo/a no tiene esta foto» (reserva ya pagada)', () => {
  beforeEach(() => {
    localStorage.setItem('infocus_familia_activa_v1', JSON.stringify(familiaActivaMellizos));
    mockearFetchFamiliaYGaleria();
    sobreescribirFetch((url) => url.includes('/api/precios'), () => json(200, { success: true, precios: { kitClasico: 30000, kitDigital: 15000, carpetaExtra: 15000, fotoEvento: 5000 } }));
    sobreescribirFetch(
      (url) => url.includes('/api/fotos'),
      () => json(200, { success: true, seccion: { colegioId: 'col', grado: '1° grado', turno: 'Tarde', division: 'A' }, fotos: [...fotosSeccionCompartida, { id: 'foto-grupal-2', categoria: 'grupal', thumb_path: '/img/grupal-2.jpg' }] })
    );
    sobreescribirFetch(
      (url) => url.includes('/api/reservas/pendiente') && decodeURIComponent(url).includes('Pablo'),
      () => json(200, { success: true, fotosDisponibles: true, tienePedidoPagado: false, reserva: { id: 'reserva-1', pedidoFriendlyId: 'IFS-2026-7777', kitNombre: 'Kit Impreso + Digital', total: 30000, pagada: true } })
    );
    sobreescribirFetch((url) => url.includes('/api/reservas/reserva-1/elegir-fotos'), () => json(200, { success: true, pedidoFriendlyId: 'IFS-2026-7777' }));
  });

  async function abrir() {
    const user = userEvent.setup();
    render(<PortalFamiliasModal isOpen={true} onClose={() => {}} />);
    await user.click(await screen.findByRole('button', { name: /abrir galería de fotos/i }));
    expect(await screen.findByText(/ya pagaste el kit impreso \+ digital de pablo alder/i)).toBeInTheDocument();
    return user;
  }
  async function confirmar(user: ReturnType<typeof userEvent.setup>) {
    await user.click(document.getElementById('chk-confirma-personalizacion') as HTMLElement);
    await user.click(screen.getByRole('button', { name: /confirmar mis fotos/i }));
    expect(await screen.findByText(/guardamos tus fotos del pedido IFS-2026-7777/i)).toBeInTheDocument();
    const [llamada] = llamadas('/api/reservas/reserva-1/elegir-fotos');
    return JSON.parse(String((llamada[1] as RequestInit).body)).fotos;
  }

  it('26/10: sin individual y sin otra foto en su lugar, no se puede confirmar (el kit lleva 3 fotos)', async () => {
    const user = await abrir();
    await irAlLugar(user, 'grupal');
    await elegirTarjeta(user, 'grupal-1');
    await irAlLugar(user, 'individual');
    await user.click(screen.getByRole('button', { name: /mi hijo\/a no tiene esta foto/i }));
    expect(screen.getByText(/ahora tocá «usar en su lugar»/i)).toBeInTheDocument();
    expect(screen.queryByText(/seguir sin ella|va a quedar sin esa foto/i)).not.toBeInTheDocument();
    await irAlLugar(user, 'docente');
    await elegirTarjeta(user, 'docente-1');
    await user.click(document.getElementById('chk-confirma-personalizacion') as HTMLElement);
    await user.click(screen.getByRole('button', { name: /elegí las 3 fotos|confirmar mis fotos/i }));
    expect(llamadas('/api/reservas/reserva-1/elegir-fotos')).toHaveLength(0);
  });

  it('en el lugar de la individual elige otra foto del curso; la misma foto no va en dos lugares; «Deshacer» la saca', async () => {
    const user = await abrir();
    await irAlLugar(user, 'grupal');
    await elegirTarjeta(user, 'grupal-1');
    await irAlLugar(user, 'individual');
    await user.click(screen.getByRole('button', { name: /mi hijo\/a no tiene esta foto/i }));
    // 29/10: la ya elegida como grupal no se ofrece de nuevo (dice «Ya elegida» y no se puede tocar).
    const yaElegida = screen.getByRole('button', { name: /^ya elegida$/i });
    expect(yaElegida).toBeDisabled();
    expect(screen.getByText(/ya la elegiste como grupal/i)).toBeInTheDocument();
    await elegirTarjeta(user, 'grupal-2');
    expect(await screen.findByText(/en su lugar va/i)).toBeInTheDocument();
    // Deshacer: la grupal-2 no es una individual, se saca; y se vuelve a pedir la individual.
    await user.click(screen.getByRole('button', { name: /deshacer: sí tiene esta foto/i }));
    expect(screen.getByRole('button', { name: /mi hijo\/a no tiene esta foto/i })).toBeInTheDocument();
    await user.click(screen.getByRole('button', { name: /mi hijo\/a no tiene esta foto/i }));
    await elegirTarjeta(user, 'grupal-2');
    await irAlLugar(user, 'docente');
    await elegirTarjeta(user, 'docente-1');
    expect(await confirmar(user)).toEqual({ grupalId: 'foto-grupal-1', individualId: 'foto-grupal-2', docenteId: 'foto-docente-1', sinFoto: ['individual'] });
  });

  it('26/10: en la grupal no hay «no tiene esta foto»: la familia nos avisa y llega a Consultas', async () => {
    sobreescribirFetch((url) => url.includes('/api/consultas-familias'), () => json(200, { success: true }));
    const user = await abrir();
    await irAlLugar(user, 'grupal');
    expect(screen.queryByRole('button', { name: /mi hijo\/a no tiene esta foto/i })).not.toBeInTheDocument();
    await user.click(screen.getByRole('button', { name: /no está en la grupal: avisar/i }));
    await user.click(screen.getByRole('button', { name: /enviar aviso/i }));
    expect(await screen.findByText(/recibimos tu aviso/i)).toBeInTheDocument();
    const [aviso] = llamadas('/api/consultas-familias');
    const cuerpo = JSON.parse(String((aviso[1] as RequestInit).body));
    expect(cuerpo.asunto).toMatch(/no aparece en la foto grupal: pablo alder/i);
    expect(cuerpo.email).toBe(familiaActivaMellizos.email);
    // Sin grupal no se confirma.
    await user.click(document.getElementById('chk-confirma-personalizacion') as HTMLElement);
    await user.click(screen.getByRole('button', { name: /elegí las 3 fotos|confirmar mis fotos/i }));
    expect(llamadas('/api/reservas/reserva-1/elegir-fotos')).toHaveLength(0);
  });

  it('«Faltantes solicitadas»: pide la foto (con el motivo) y el kit queda en espera hasta cancelarla', async () => {
    sobreescribirFetch((url) => url.includes('/api/fotos-faltantes/estado'), () => json(200, { success: true, abierto: true, solicitudes: [] }));
    sobreescribirFetch(
      (url) => url.includes('/api/fotos-faltantes/solicitar'),
      (_url, init) => json(200, { success: true, solicitud: { id: 'sol-1', alumno_nombre: 'Pablo Alder', lugar: JSON.parse(String(init?.body)).lugar, motivo: 'ausente', estado: 'pendiente', created_at: '2026-10-22T12:00:00Z' } })
    );
    sobreescribirFetch((url) => url.includes('/api/fotos-faltantes/sol-1/cancelar'), () => json(200, { success: true }));
    const user = await abrir();
    await irAlLugar(user, 'grupal');
    await elegirTarjeta(user, 'grupal-1');
    await irAlLugar(user, 'docente');
    await elegirTarjeta(user, 'docente-1');
    await irAlLugar(user, 'individual');
    await user.click(screen.getByRole('button', { name: /mi hijo\/a no tiene esta foto/i }));
    await user.click(await screen.findByRole('button', { name: /quiero que le saquen esta foto/i }));
    // Sin motivo no se manda.
    await user.click(screen.getByRole('button', { name: /^pedir la foto$/i }));
    expect(await screen.findByText(/contanos qué pasó/i)).toBeInTheDocument();
    expect(screen.queryByText(/no les gustó|nueva toma/i)).not.toBeInTheDocument(); // Pablo: ni se menciona
    await user.click(screen.getByLabelText(/no estuvo el día de la foto/i));
    await user.click(screen.getByRole('button', { name: /^pedir la foto$/i }));
    expect(await screen.findByText(/pediste que le saquemos la foto individual/i)).toBeInTheDocument();
    const [pedido] = llamadas('/api/fotos-faltantes/solicitar');
    expect(JSON.parse(String((pedido[1] as RequestInit).body))).toMatchObject({ lugar: 'individual', motivo: 'ausente', email: familiaActivaMellizos.email, familia: familiaActivaMellizos.id, alumnoNombre: 'Pablo Alder' });
    // En espera: no se puede confirmar.
    await user.click(document.getElementById('chk-confirma-personalizacion') as HTMLElement);
    await user.click(screen.getByRole('button', { name: /elegí las 3 fotos|confirmar mis fotos/i }));
    expect(llamadas('/api/reservas/reserva-1/elegir-fotos')).toHaveLength(0);
    // Cancela el pedido de foto: tiene que elegir otra en su lugar (el kit lleva 3 fotos).
    await user.click(screen.getByRole('button', { name: /cancelar el pedido de esta foto/i }));
    expect(await screen.findByText(/ahora tocá «usar en su lugar»/i)).toBeInTheDocument();
    await elegirTarjeta(user, 'grupal-2');
    await user.click(screen.getByRole('button', { name: /confirmar mis fotos/i }));
    expect(await screen.findByText(/guardamos tus fotos del pedido IFS-2026-7777/i)).toBeInTheDocument();
  });

  it('29/10: curso sin individuales (secundaria): tras la grupal pasa solo al retrato y deja elegir otra foto en su lugar', async () => {
    sobreescribirFetch(
      (url) => url.includes('/api/fotos'),
      () => json(200, { success: true, seccion: { colegioId: 'col', grado: '5° año', turno: 'Mañana', division: 'A' }, fotos: [{ id: 'foto-grupal-1', categoria: 'grupal', thumb_path: '/img/grupal-1.jpg' }, { id: 'foto-grupal-2', categoria: 'grupal', thumb_path: '/img/grupal-2.jpg' }] })
    );
    const user = await abrir();
    await elegirTarjeta(user, 'grupal-1');
    // Antes se quedaba en «1/2» sin decir nada: ahora pasa solo a la pestaña del retrato y explica qué hacer.
    expect(await screen.findByText(/todavía no está la foto individual de tu hijo\/a/i, {}, { timeout: 3000 })).toBeInTheDocument();
    expect(screen.getAllByText(/falta elegir la foto individual/i).length).toBeGreaterThan(0);
    await user.click(screen.getByRole('button', { name: /elegir otra foto en su lugar/i }));
    expect(screen.getByRole('button', { name: /^ya elegida$/i })).toBeDisabled();
    await elegirTarjeta(user, 'grupal-2');
    expect(await screen.findByText(/en su lugar va/i)).toBeInTheDocument();
    expect(await confirmar(user)).toEqual({ grupalId: 'foto-grupal-1', individualId: 'foto-grupal-2', docenteId: '', sinFoto: ['individual'] });
  });

  it('sin avisar, sigue exigiendo la individual (nada cambia para el resto)', async () => {
    const user = await abrir();
    await irAlLugar(user, 'grupal');
    await elegirTarjeta(user, 'grupal-1');
    await irAlLugar(user, 'docente');
    await elegirTarjeta(user, 'docente-1');
    await user.click(document.getElementById('chk-confirma-personalizacion') as HTMLElement);
    await user.click(screen.getByRole('button', { name: /elegí las 3 fotos|confirmar mis fotos/i }));
    expect(llamadas('/api/reservas/reserva-1/elegir-fotos')).toHaveLength(0);
  });
});
