// 13/10/2026 (Pablo: «los alumnos que fotografiamos hoy, y tildamos, no están»): la marca de «fotografiado» de
// la Nómina se guarda en el servidor; si no se pudo guardar, vuelve atrás y avisa.
import React, { useState } from 'react';
import { beforeEach, describe, expect, it, vi } from 'vitest';
import { render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { compararAlumnosNomina, filtrarPorFoto, fotosQueLeFaltan, useFotografiadosNomina } from '../fotografiadosNomina';
import FiltroFotografiadoNomina, { BotonesChequeoNomina, EstadoFotoNomina } from '../FiltroFotografiadoNomina';
import type { AlumnoNominaReal } from '../../services/colegiosService';

const marcar = vi.fn();
vi.mock('../../services/colegiosService', () => ({
  marcarFotografiadosAdmin: (...args: unknown[]) => marcar(...args),
}));

const fila = (id: string, nombre: string, fotografiado_at: string | null = null): AlumnoNominaReal => ({
  id, nombre, grado: '4° grado', division: 'C', turno: 'Tarde', colegio_id: 'col-1', numero_lista: 1, dni: null, origen: null, fotografiado_at,
});

function Nomina() {
  const [alumnos, setAlumnos] = useState([fila('a1', 'PEREZ, ANA'), fila('a2', 'GOMEZ, LUZ'), fila('a3', 'DIAZ, SOL', '2026-10-13T12:00:00Z')]);
  const { marcados, alternarFotografiado, alternarVarios, errorFotografiados } = useFotografiadosNomina(alumnos, setAlumnos);
  return (
    <div>
      {alumnos.map((a) => (
        <label key={a.id}>
          <input type="checkbox" checked={!!marcados[a.id]} onChange={() => alternarFotografiado(a.id, a.nombre)} />
          {a.nombre}
        </label>
      ))}
      <button type="button" onClick={() => alternarVarios(alumnos)}>Chequear filtrados</button>
      {errorFotografiados && <p role="alert">{errorFotografiados}</p>}
    </div>
  );
}

beforeEach(() => {
  marcar.mockReset();
  vi.restoreAllMocks();
});

describe('Nómina: marca de fotografiado', () => {
  it('viene marcada desde el servidor y al tildar se guarda', async () => {
    marcar.mockResolvedValue({ success: true, alumnos: [{ id: 'a1', fotografiado_at: '2026-10-13T15:00:00Z' }] });
    const u = userEvent.setup();
    render(<Nomina />);
    expect(screen.getByRole('checkbox', { name: 'DIAZ, SOL' })).toBeChecked();
    await u.click(screen.getByRole('checkbox', { name: 'PEREZ, ANA' }));
    expect(marcar).toHaveBeenCalledWith(['a1'], true, 'fotografiado');
    expect(screen.getByRole('checkbox', { name: 'PEREZ, ANA' })).toBeChecked();
  });

  it('si el servidor no la guarda, se destilda y avisa', async () => {
    marcar.mockResolvedValue({ success: false, error: 'Sin conexión.' });
    const u = userEvent.setup();
    render(<Nomina />);
    await u.click(screen.getByRole('checkbox', { name: 'GOMEZ, LUZ' }));
    expect(await screen.findByRole('alert')).toHaveTextContent('Sin conexión.');
    await waitFor(() => expect(screen.getByRole('checkbox', { name: 'GOMEZ, LUZ' })).not.toBeChecked());
  });

  it('«Chequear filtrados» marca sólo los que faltaban; destildar uno pide confirmación', async () => {
    marcar.mockResolvedValue({ success: true, alumnos: [] });
    const u = userEvent.setup();
    render(<Nomina />);
    await u.click(screen.getByRole('button', { name: 'Chequear filtrados' }));
    expect(marcar).toHaveBeenCalledWith(['a1', 'a2'], true, 'fotografiado');
    vi.spyOn(window, 'confirm').mockReturnValue(false);
    await u.click(screen.getByRole('checkbox', { name: 'DIAZ, SOL' }));
    expect(marcar).toHaveBeenCalledTimes(1);
    expect(screen.getByRole('checkbox', { name: 'DIAZ, SOL' })).toBeChecked();
  });
});

// 14/10/2026 (Pablo: «el listado está desordenado, no alfabéticamente por apellido y nombre»).
describe('Nómina: orden', () => {
  // 19/10/2026: alfabético puro por apellido y nombre aunque haya varios cursos; el curso sólo desempata.
  it('alfabético por apellido y nombre; el curso (grado, turno, división) sólo desempata', () => {
    const a = (nombre: string, grado: string, turno: string, division: string, n: number): AlumnoNominaReal => ({
      ...fila(nombre, nombre), grado, turno, division, numero_lista: n,
    });
    const lista = [
      a('ZAPATA, ANA', '4° grado', 'Mañana', 'B', 1),
      a('ÁLVAREZ, JUAN', '4° grado', 'Mañana', 'B', 40),
      a('DI GIORGIO, FRANCESCA', '4° grado', 'Mañana', 'B', 26),
      a('ABAD, LUZ', '4° grado', 'Tarde', 'B', 1),
      a('BENITEZ, SOL', '10° grado', 'Mañana', 'A', 1),
      a('CASTRO, EVA', '2° grado', 'Mañana', 'A', 1),
      a('PEREZ, ANA', '4° grado', 'Tarde', 'B', 2),
      a('PEREZ, ANA', '2° grado', 'Mañana', 'A', 2),
    ];
    expect([...lista].sort(compararAlumnosNomina).map((x) => `${x.nombre} ${x.grado}`)).toEqual([
      'ABAD, LUZ 4° grado', 'ÁLVAREZ, JUAN 4° grado', 'BENITEZ, SOL 10° grado', 'CASTRO, EVA 2° grado',
      'DI GIORGIO, FRANCESCA 4° grado', 'PEREZ, ANA 2° grado', 'PEREZ, ANA 4° grado', 'ZAPATA, ANA 4° grado',
    ]);
  });
});

// 14/10/2026 (Pablo: «voy a necesitar ver los alumnos que no pude fotografiar»).
describe('Nómina: filtro «Sin fotografiar»', () => {
  const lista = [fila('a1', 'PEREZ, ANA', '2026-10-13T12:00:00Z'), fila('a2', 'GOMEZ, LUZ'), fila('a3', 'DIAZ, SOL')];
  it('separa los que les falta la individual y cuenta cada estado', () => {
    expect(filtrarPorFoto(lista, 'pendientes')).toMatchObject({ total: 3, pendientes: 2, faltaAlguna: 3, completos: 0 });
    expect(filtrarPorFoto(lista, 'pendientes').visibles.map((a) => a.id)).toEqual(['a2', 'a3']);
    expect(filtrarPorFoto(lista, 'todos').visibles).toHaveLength(3);
  });
  it('el selector muestra las cantidades y avisa el cambio', async () => {
    const cambiar = vi.fn();
    const u = userEvent.setup();
    render(<FiltroFotografiadoNomina valor="todos" onCambiar={cambiar} cuentas={{ total: 3, faltaAlguna: 3, pendientes: 2, sinSeno: 1, sinGrupal: 3, completos: 0 }} />);
    expect(screen.getByRole('option', { name: 'Falta individual (2)' })).toBeInTheDocument();
    expect(screen.getByRole('option', { name: 'Falta con la seño (1)' })).toBeInTheDocument();
    expect(screen.getByRole('option', { name: 'Falta alguna foto (3)' })).toBeInTheDocument();
    await u.selectOptions(screen.getByRole('combobox', { name: 'Filtrar por estado de la foto' }), 'pendientes');
    expect(cambiar).toHaveBeenCalledWith('pendientes');
  });
});

// 14/10/2026 (noche, Pablo: «les hicimos las individuales y con la seño, faltan las grupales, se las haremos la
// próxima semana»): la grupal se marca aparte y se puede filtrar «Falta grupal».
describe('Nómina: foto grupal aparte', () => {
  it('el filtro «Falta grupal» muestra a los que no tienen la grupal (aunque estén fotografiados)', () => {
    const lista = [
      { ...fila('a1', 'PEREZ, ANA', '2026-10-14T15:00:00Z'), foto_grupal_at: null },
      { ...fila('a2', 'GOMEZ, LUZ', '2026-10-13T12:00:00Z'), foto_grupal_at: '2026-10-13T12:00:00Z' },
      fila('a3', 'DIAZ, SOL'),
    ];
    const r = filtrarPorFoto(lista, 'sin-grupal');
    expect(r.visibles.map((a) => a.id)).toEqual(['a1', 'a3']);
    expect(r).toMatchObject({ sinGrupal: 2, pendientes: 1 });
  });

  function NominaGrupal() {
    const [alumnos, setAlumnos] = useState([fila('a1', 'PEREZ, ANA', '2026-10-14T15:00:00Z'), fila('a2', 'GOMEZ, LUZ', '2026-10-14T15:00:00Z')]);
    const { marcados, conSeno, conGrupal, alternarSeno, alternarGrupal, alternarSenoVarios, alternarGrupalVarios } = useFotografiadosNomina(alumnos, setAlumnos);
    return (
      <div>
        {alumnos.map((a) => (
          <div key={a.id}>
            <EstadoFotoNomina fotografiado={!!marcados[a.id]} seno={!!conSeno[a.id]} grupal={!!conGrupal[a.id]} onSeno={() => alternarSeno(a.id, a.nombre)} onGrupal={() => alternarGrupal(a.id, a.nombre)} />
          </div>
        ))}
        <BotonesChequeoNomina onFotografiados={() => undefined} onSeno={() => alternarSenoVarios(alumnos)} onGrupal={() => alternarGrupalVarios(alumnos)} />
      </div>
    );
  }

  it('«Falta grupal» de un alumno se marca y se guarda como grupal, sin tocar el fotografiado', async () => {
    marcar.mockResolvedValue({ success: true, alumnos: [{ id: 'a1', fotografiado_at: '2026-10-14T15:00:00Z', foto_grupal_at: '2026-10-21T15:00:00Z' }] });
    const u = userEvent.setup();
    render(<NominaGrupal />);
    expect(screen.getAllByRole('button', { name: 'Falta grupal' })).toHaveLength(2);
    await u.click(screen.getAllByRole('button', { name: 'Falta grupal' })[0]);
    expect(marcar).toHaveBeenCalledWith(['a1'], true, 'grupal');
    expect(await screen.findAllByRole('button', { name: 'Grupal' })).toHaveLength(1);
    expect(screen.getAllByText('Individual')).toHaveLength(2);
  });

  it('«Grupal a filtrados» marca la grupal a todos los de la lista', async () => {
    marcar.mockResolvedValue({ success: true, alumnos: [] });
    const u = userEvent.setup();
    render(<NominaGrupal />);
    await u.click(screen.getByRole('button', { name: 'Grupal a filtrados' }));
    expect(marcar).toHaveBeenCalledWith(['a1', 'a2'], true, 'grupal');
  });
});

// 21/10/2026 (Pablo: «¿cómo tildo si falta la foto individual y/o con la seño?»): la de la seño se marca aparte.
describe('Nómina: foto con la seño aparte', () => {
  const lista = [
    { ...fila('a1', 'PEREZ, ANA', '2026-10-14T15:00:00Z'), foto_seno_at: null, foto_grupal_at: 'x' },
    { ...fila('a2', 'GOMEZ, LUZ', '2026-10-14T15:00:00Z'), foto_seno_at: 'x', foto_grupal_at: 'x' },
    { ...fila('a3', 'DIAZ, SOL'), foto_seno_at: 'x', foto_grupal_at: null },
  ];
  it('filtra «Falta con la seño», «Falta alguna foto» y «Completos»', () => {
    expect(filtrarPorFoto(lista, 'sin-seno').visibles.map((a) => a.id)).toEqual(['a1']);
    expect(filtrarPorFoto(lista, 'alguna').visibles.map((a) => a.id)).toEqual(['a1', 'a3']);
    expect(filtrarPorFoto(lista, 'fotografiados').visibles.map((a) => a.id)).toEqual(['a2']);
    expect(filtrarPorFoto(lista, 'todos')).toMatchObject({ total: 3, faltaAlguna: 2, pendientes: 1, sinSeno: 1, sinGrupal: 1, completos: 1 });
  });
  it('dice qué fotos le faltan a cada uno (para el Excel)', () => {
    expect(lista.map(fotosQueLeFaltan)).toEqual(['Seño', '—', 'Individual, Grupal']);
    expect(fotosQueLeFaltan(fila('a4', 'X'))).toBe('Individual, Seño, Grupal');
  });
  it('«Falta seño» de un alumno se guarda como seño, sin tocar la individual ni la grupal', async () => {
    marcar.mockResolvedValue({ success: true, alumnos: [{ id: 'a1', fotografiado_at: '2026-10-14T15:00:00Z', foto_seno_at: '2026-10-21T15:00:00Z', foto_grupal_at: null }] });
    function NominaSeno() {
      const [alumnos, setAlumnos] = useState([fila('a1', 'PEREZ, ANA', '2026-10-14T15:00:00Z')]);
      const { marcados, conSeno, conGrupal, alternarSeno, alternarGrupal } = useFotografiadosNomina(alumnos, setAlumnos);
      return <EstadoFotoNomina fotografiado={!!marcados.a1} seno={!!conSeno.a1} grupal={!!conGrupal.a1} onSeno={() => alternarSeno('a1', 'PEREZ, ANA')} onGrupal={() => alternarGrupal('a1', 'PEREZ, ANA')} />;
    }
    const u = userEvent.setup();
    render(<NominaSeno />);
    await u.click(screen.getByRole('button', { name: 'Falta seño' }));
    expect(marcar).toHaveBeenCalledWith(['a1'], true, 'seno');
    expect(await screen.findByRole('button', { name: 'Seño' })).toBeInTheDocument();
    expect(screen.getByRole('button', { name: 'Falta grupal' })).toBeInTheDocument();
    expect(screen.getByText('Individual')).toBeInTheDocument();
  });
});

// 15/10/2026 (Pablo: «aprieto "Grupal a filtrados" y se tilda y se destilda sola»): con la Nómina en «todas»
// (1.314 alumnos) el servidor rechazaba la lista (máximo 1.000) y la marca volvía atrás.
describe('Nómina: muchos alumnos a la vez', () => {
  function NominaGrande({ cantidad }: { cantidad: number }) {
    const [alumnos, setAlumnos] = useState(Array.from({ length: cantidad }, (_, i) => fila(`a${i}`, `ALUMNO ${i}`, '2026-10-14T15:00:00Z')));
    const { conGrupal, alternarGrupalVarios, errorFotografiados } = useFotografiadosNomina(alumnos, setAlumnos);
    return (
      <div>
        <p>con grupal: {Object.keys(conGrupal).length}</p>
        <button type="button" onClick={() => alternarGrupalVarios(alumnos)}>Grupal a filtrados</button>
        {errorFotografiados && <p role="alert">{errorFotografiados}</p>}
      </div>
    );
  }

  it('manda la lista en tandas de 500 y pide confirmación antes de marcar a muchos', async () => {
    marcar.mockImplementation(async (ids: string[]) => ({ success: true, alumnos: ids.map((id) => ({ id, fotografiado_at: '2026-10-14T15:00:00Z', foto_grupal_at: '2026-10-21T15:00:00Z' })) }));
    const confirmar = vi.spyOn(window, 'confirm').mockReturnValue(true);
    const u = userEvent.setup();
    render(<NominaGrande cantidad={1314} />);
    await u.click(screen.getByRole('button', { name: 'Grupal a filtrados' }));
    expect(confirmar).toHaveBeenCalledTimes(1);
    expect(marcar).toHaveBeenCalledTimes(3);
    expect(marcar.mock.calls.map((c) => (c[0] as string[]).length)).toEqual([500, 500, 314]);
    expect(await screen.findByText('con grupal: 1314')).toBeInTheDocument();
  });

  it('si no confirma, no marca nada', async () => {
    vi.spyOn(window, 'confirm').mockReturnValue(false);
    const u = userEvent.setup();
    render(<NominaGrande cantidad={100} />);
    await u.click(screen.getByRole('button', { name: 'Grupal a filtrados' }));
    expect(marcar).not.toHaveBeenCalled();
    expect(screen.getByText('con grupal: 0')).toBeInTheDocument();
  });

  it('si falla una tanda, quedan las guardadas y vuelven atrás sólo las demás', async () => {
    marcar
      .mockImplementationOnce(async (ids: string[]) => ({ success: true, alumnos: ids.map((id) => ({ id, fotografiado_at: '2026-10-14T15:00:00Z', foto_grupal_at: '2026-10-21T15:00:00Z' })) }))
      .mockResolvedValueOnce({ success: false, error: 'Sin conexión.' });
    vi.spyOn(window, 'confirm').mockReturnValue(true);
    const u = userEvent.setup();
    render(<NominaGrande cantidad={800} />);
    await u.click(screen.getByRole('button', { name: 'Grupal a filtrados' }));
    expect(await screen.findByRole('alert')).toHaveTextContent('Se guardaron 500 de 800');
    await waitFor(() => expect(screen.getByText('con grupal: 500')).toBeInTheDocument());
  });
});
