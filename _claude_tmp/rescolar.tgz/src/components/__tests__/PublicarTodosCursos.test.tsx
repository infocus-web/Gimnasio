import { render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { afterEach, describe, expect, it, vi } from 'vitest';

import PublicarTodosCursos, { idsSinPublicarDelCurso, type FilaCursoPublicable } from '../PublicarTodosCursos';
import { publicarFotosAdmin, type FotoRegistrada } from '../../services/fotosSubidasService';

// 25/10/2026 (Pablo): «Publicar todos los cursos», de a uno y con pausa entre cursos (límite de Resend).
vi.mock('../../services/fotosSubidasService', () => ({ publicarFotosAdmin: vi.fn() }));
const publicar = vi.mocked(publicarFotosAdmin);

const fila = (division: string, individual: number, sinPublicar: number): FilaCursoPublicable => ({
  clave: `1__Mañana__${division}`, grado: '1', turno: 'Mañana', division, individual, sinPublicar,
});
const foto = (id: string, division: string, publicada = false) =>
  ({ id, colegioId: 'col', grado: '1', turno: 'Mañana', division, categoria: 'individual', publicada } as unknown as FotoRegistrada);

const filas = [fila('A', 2, 2), fila('B', 1, 1), fila('C', 0, 1)];
const fotos = [foto('a1', 'A'), foto('a2', 'A'), foto('a3', 'A', true), foto('b1', 'B'), foto('c1', 'C')];

afterEach(() => { vi.restoreAllMocks(); publicar.mockReset(); });

describe('PublicarTodosCursos', () => {
  it('toma sólo las fotos sin publicar del curso', () => {
    expect(idsSinPublicarDelCurso(fotos, filas[0], 'col')).toEqual(['a1', 'a2']);
  });

  it('publica de a un curso, en orden, y deja afuera los cursos sin individuales si se elige Cancelar', async () => {
    publicar.mockResolvedValue({ success: true, publicadas: 1, emailsEnviados: 3 } as any);
    const respuestas = [true, false];
    vi.spyOn(window, 'confirm').mockImplementation(() => respuestas.shift() ?? false);
    const alTerminar = vi.fn(async () => {});
    render(<PublicarTodosCursos filas={filas} fotos={fotos} colegioId="col" deshabilitado={false} alTerminar={alTerminar} />);

    await userEvent.click(screen.getByRole('button', { name: /Publicar todos los cursos \(3\)/ }));
    await waitFor(() => expect(alTerminar).toHaveBeenCalled(), { timeout: 5000 });

    expect(publicar.mock.calls.map((c) => c[0])).toEqual([{ ids: ['a1', 'a2'] }, { ids: ['b1'] }]);
    expect(screen.getByRole('status').textContent).toContain('Listo: 2 cursos');
    expect(screen.getByRole('status').textContent).toContain('se avisó por email a 6 familia(s)');
  });

  it('no aparece con menos de dos cursos para publicar', () => {
    const { container } = render(<PublicarTodosCursos filas={[fila('A', 2, 2)]} fotos={fotos} colegioId="col" deshabilitado={false} alTerminar={async () => {}} />);
    expect(container.textContent).toBe('');
  });
});
