import fs from 'fs';
import path from 'path';
import { render, screen, waitFor, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import PortalFamiliasModal from '../PortalFamiliasModal';
import { familiaActivaMellizos, mockearFetchFamiliaYGaleria } from '../../test/fixtures/familiaMellizos';

// 14/10/2026 — portal de familias: comprobante en revisión (no invitar a pagar dos veces), pagar un pedido
// pendiente desde otro dispositivo, ids del checkout que sobreviven a una recarga y el texto del hermano
// cuya reserva no se pudo sumar.

type Implementacion = (input: RequestInfo | URL, init?: RequestInit) => Promise<Response>;
const UUID = '99999999-9999-4999-8999-999999999999';

function json(status: number, cuerpo: unknown): Response {
  return { ok: status >= 200 && status < 300, status, json: async () => cuerpo } as Response;
}
const urlDe = (input: RequestInfo | URL) => (typeof input === 'string' ? input : input.toString());
function sobreescribirFetch(coincide: (url: string, init?: RequestInit) => boolean, respuesta: (url: string, init?: RequestInit) => Response) {
  const fetchBase = global.fetch as unknown as ReturnType<typeof vi.fn>;
  const base = fetchBase.getMockImplementation() as Implementacion | undefined;
  fetchBase.mockImplementation(async (input: RequestInfo | URL, init?: RequestInit) => {
    const url = urlDe(input);
    if (coincide(url, init)) return respuesta(url, init);
    return base ? base(input, init) : json(404, { success: false });
  });
}
function llamadas(fragmento: string) {
  const fetchBase = global.fetch as unknown as ReturnType<typeof vi.fn>;
  return fetchBase.mock.calls.filter((c) => urlDe(c[0] as RequestInfo).includes(fragmento));
}
const cuerpoDe = (llamada: unknown[]) => JSON.parse(String((llamada[1] as RequestInit).body));

async function elegirFoto(user: ReturnType<typeof userEvent.setup>, categoria: 'grupal' | 'individual' | 'docente', titulo: RegExp) {
  const slotLabels: Record<typeof categoria, RegExp> = { grupal: /^1\/3 grupal$/i, individual: /^2\/3 retrato$/i, docente: /^3\/3 con seño$/i };
  const slot = screen.getByText(slotLabels[categoria]).closest('div')!.parentElement!;
  await user.click(slot);
  const tarjeta = (await screen.findAllByText(titulo))[0].closest('div.relative')!;
  await user.click(within(tarjeta as HTMLElement).getByRole('button', { name: /^elegir$/i }));
}
async function elegirLasTres(user: ReturnType<typeof userEvent.setup>) {
  await elegirFoto(user, 'grupal', /foto grupal/i);
  await elegirFoto(user, 'individual', /foto individual/i);
  await elegirFoto(user, 'docente', /foto.*seño|foto docente/i);
}
const grupo = () => screen.getByRole('group', { name: /tus hijos\/as en este colegio/i });

beforeEach(() => {
  sessionStorage.clear();
  localStorage.setItem('infocus_familia_activa_v1', JSON.stringify(familiaActivaMellizos));
  mockearFetchFamiliaYGaleria();
  sobreescribirFetch((url) => url.includes('/api/precios'), () => json(200, { success: true, precios: { kitClasico: 30000, kitDigital: 15000, carpetaExtra: 15000, fotoEvento: 5000 } }));
});
afterEach(() => {
  window.history.replaceState(null, '', '/');
  sessionStorage.clear();
});

describe('checkout: los ids sobreviven a una recarga (no se duplica el pedido)', () => {
  async function armarCarritoYPagar() {
    const user = userEvent.setup();
    const vista = render(<PortalFamiliasModal isOpen={true} onClose={() => {}} />);
    await user.click(await screen.findByRole('button', { name: /abrir galería de fotos/i }));
    await screen.findByRole('group', { name: /tus hijos\/as en este colegio/i });
    await user.click(within(grupo()).getByRole('button', { name: /sofia/i }));
    await elegirLasTres(user);
    await user.click(within(grupo()).getByRole('button', { name: /pablo/i }));
    await elegirLasTres(user);
    await user.click(screen.getByRole('button', { name: /elegir kit y formato/i }));
    await user.click(await screen.findByRole('button', { name: /ir a datos y pago/i }));
    await user.click(screen.getByRole('checkbox', { name: /leí y acepto/i }));
    await user.click(document.getElementById('btn-confirmar-pagar') as HTMLElement);
    return vista;
  }

  it('respuesta perdida + recarga: el reintento manda los MISMOS ids y la misma clave', async () => {
    sobreescribirFetch((url) => url.includes('/api/pedidos/existente'), () => json(200, { success: true, existe: false }));
    sobreescribirFetch((url) => url.includes('/api/pedidos/crear-multiple'), () => json(500, { success: false, error: 'se cortó' }));
    const vista = await armarCarritoYPagar();
    await waitFor(() => expect(llamadas('/api/pedidos/crear-multiple')).toHaveLength(1));
    const primero = cuerpoDe(llamadas('/api/pedidos/crear-multiple')[0]);
    expect(sessionStorage.getItem('retrato_checkout_en_curso')).not.toContain(familiaActivaMellizos.email);

    vista.unmount(); // «recarga»: la memoria del portal se pierde, la pestaña conserva sessionStorage
    await armarCarritoYPagar();
    await waitFor(() => expect(llamadas('/api/pedidos/crear-multiple')).toHaveLength(2));
    const segundo = cuerpoDe(llamadas('/api/pedidos/crear-multiple')[1]);
    expect(segundo.claveCheckout).toBe(primero.claveCheckout);
    expect(segundo.items.map((i: { pedidoId: string }) => i.pedidoId)).toEqual(primero.items.map((i: { pedidoId: string }) => i.pedidoId));
  });
});

describe('pedido pendiente hecho en otro dispositivo', () => {
  const pedidoPendiente = (extra: Record<string, unknown> = {}) => ({
    id: 'IFS-2026-5555', kit: 'Kit Impreso + Digital', total: 30000, estado: 'pendiente_pago', fecha: '2026-10-14', pedidoUuid: UUID, requiereLlave: false,
    metodoPago: 'mercadopago', grupoPagoId: null, accesoToken: 'llave-del-pedido', comprobanteSubido: false, ...extra,
  });
  const estado = (comprobanteSubido: boolean) =>
    sobreescribirFetch((url) => url.includes(`/api/pedidos/${UUID}/status`), () => json(200, { success: true, pedidoId: UUID, estado: 'pendiente_pago', estadoPago: 'pendiente', total: 30000, metodoPago: 'mercadopago', comprobanteSubido }));

  it('«Pagar ahora»: guarda la llave que dio el servidor y abre el pago con ella', async () => {
    sobreescribirFetch((url) => url.includes('/api/pedidos/existente'), () => json(200, { success: true, existe: true, pedido: pedidoPendiente() }));
    estado(false);
    sobreescribirFetch((url) => url.includes('/api/mercadopago/crear-preferencia'), () => json(200, { success: true, initPoint: 'https://mp/link-1' }));
    const user = userEvent.setup();
    render(<PortalFamiliasModal isOpen={true} onClose={() => {}} />);
    await user.click(await screen.findByRole('button', { name: /pagar ahora o cambiar el medio de pago/i }));
    expect(JSON.parse(localStorage.getItem('retrato_llaves_pedidos') || '{}')[UUID]).toBe('llave-del-pedido');
    await waitFor(() => expect(llamadas('/api/mercadopago/crear-preferencia')).toHaveLength(1));
    expect(cuerpoDe(llamadas('/api/mercadopago/crear-preferencia')[0])).toMatchObject({ pedidoId: UUID, t: 'llave-del-pedido' });
    expect(await screen.findByText(/¿preferís pagar de otra forma\?/i)).toBeInTheDocument();
  });

  it('con el comprobante de una transferencia ya subido: «Comprobante en revisión», sin link ni otros medios hasta confirmar', async () => {
    sobreescribirFetch((url) => url.includes('/api/pedidos/existente'), () => json(200, { success: true, existe: true, pedido: pedidoPendiente() }));
    estado(true);
    sobreescribirFetch(
      (url) => url.includes('/api/mercadopago/crear-preferencia'),
      (_url, init) =>
        JSON.parse(String(init?.body)).confirmarIgual === true
          ? json(200, { success: true, initPoint: 'https://mp/link-2' })
          : json(409, { success: false, codigo: 'COMPROBANTE_YA_SUBIDO', error: 'ya subiste el comprobante' })
    );
    const user = userEvent.setup();
    render(<PortalFamiliasModal isOpen={true} onClose={() => {}} />);
    await user.click(await screen.findByRole('button', { name: /pagar ahora o cambiar el medio de pago/i }));
    expect(await screen.findByText('Comprobante en revisión')).toBeInTheDocument();
    expect(screen.queryByText(/¿preferís pagar de otra forma\?/i)).not.toBeInTheDocument();
    expect(screen.queryByText(/ya subiste el comprobante/i)).not.toBeInTheDocument();

    await user.click(screen.getByRole('button', { name: /quiero pagar de otra forma/i }));
    expect(screen.getByText(/puede generar un cobro doble/i)).toBeInTheDocument();
    await user.click(screen.getByRole('button', { name: /ya transferí pero quiero pagar con tarjeta igual/i }));
    await waitFor(() => expect(llamadas('/api/mercadopago/crear-preferencia').some((c) => cuerpoDe(c).confirmarIgual === true)).toBe(true));
  });

  it('tarjeta del Paso 1: transferencia con comprobante subido no ofrece pagar y pide confirmar «otro pedido»', async () => {
    sobreescribirFetch((url) => url.includes('/api/pedidos/existente'), () => json(200, { success: true, existe: true, pedido: pedidoPendiente({ metodoPago: 'transferencia', comprobanteSubido: true }) }));
    const user = userEvent.setup();
    render(<PortalFamiliasModal isOpen={true} onClose={() => {}} />);
    expect(await screen.findByText('Comprobante en revisión')).toBeInTheDocument();
    expect(screen.queryByRole('button', { name: /pagar ahora/i })).not.toBeInTheDocument();
    await user.click(screen.getByRole('button', { name: /quiero hacer otro pedido igual/i }));
    expect(screen.getByRole('alert')).toHaveTextContent(/otra compra aparte/i);
    expect(screen.queryByRole('group', { name: /tus hijos\/as en este colegio/i })).not.toBeInTheDocument();
    await user.click(screen.getByRole('button', { name: /sí, es otra compra aparte/i }));
    expect(await screen.findByRole('group', { name: /tus hijos\/as en este colegio/i })).toBeInTheDocument();
  });
});

describe('hermano cuya reserva no se pudo sumar', () => {
  it('el aviso ya no dice «reservalo aparte»: primero se paga esta compra', () => {
    const fuente = fs.readFileSync(path.resolve(__dirname, '../PortalFamiliasModal.tsx'), 'utf8');
    expect(fuente).toContain('después de pagar esta compra podés reservar el kit de');
    expect(fuente).not.toMatch(/lo podés reservar aparte/);
  });
});
