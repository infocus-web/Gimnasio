import { act, render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { afterEach, describe, expect, it, vi } from 'vitest';
import AdminConsultasFamiliasTab from '../AdminConsultasFamiliasTab';

// 13/10/2026: la revisión automática se hace cuando llega la consulta y puede quedar vieja (caso real: el
// borrador para la familia Paludi decía «pendiente» cuando Pablo ya la había aprobado). Se muestra cuándo se
// revisó y «Revisar de nuevo» la rehace con los datos de ahora, sin enviar nada.

function diferido<T>() {
  let resolver!: (v: T) => void;
  const promesa = new Promise<T>((r) => {
    resolver = r;
  });
  return { promesa, resolver };
}

const mocks = vi.hoisted(() => ({
  obtenerConsultasFamiliasAdmin: vi.fn(),
  sugerirRespuestaConsultaFamiliaAdmin: vi.fn(),
  responderConsultaFamiliaAdmin: vi.fn(),
}));

vi.mock('../../services/consultasFamiliasService', () => ({
  obtenerConsultasFamiliasAdmin: mocks.obtenerConsultasFamiliasAdmin,
  sugerirRespuestaConsultaFamiliaAdmin: mocks.sugerirRespuestaConsultaFamiliaAdmin,
  responderConsultaFamiliaAdmin: mocks.responderConsultaFamiliaAdmin,
  actualizarEstadoConsultaFamiliaAdmin: async () => undefined,
  eliminarConsultaFamiliaAdmin: async () => undefined,
}));

afterEach(() => {
  vi.clearAllMocks();
});

const consulta = {
  id: 'p1',
  nombre: 'Alejandra',
  email: 'paludi@familia.com',
  asunto: 'Curso de Tomás',
  mensaje: 'Hola, ¿está bien la inscripción?',
  estado: 'nueva',
  origen: 'web',
  createdAt: '2026-10-12T20:00:00.000Z',
  updatedAt: '2026-10-12T20:00:00.000Z',
  mensajes: [],
  borradorIa: 'Tu inscripción está pendiente.',
  procesadaIaAt: '2026-10-12T20:05:00.000Z',
  verificacionIa: {
    encontrada: true, todoOk: false, tema: 'otro', enviadaAutomaticamente: false,
    chequeos: [{ ok: false, texto: 'La inscripción de Alejandra está "pendiente" (todavía no aprobada).' }],
    datos: [],
  },
};

describe('Consultas de familias: revisar de nuevo (13/10)', () => {
  it('muestra cuándo se revisó y rehace el borrador con los datos de ahora (sin enviar)', async () => {
    mocks.obtenerConsultasFamiliasAdmin.mockResolvedValue([consulta]);
    const sugerencia = diferido<{ sugerencia: string; aviso?: string }>();
    mocks.sugerirRespuestaConsultaFamiliaAdmin.mockImplementation(() => sugerencia.promesa);

    render(<AdminConsultasFamiliasTab />);
    await userEvent.click(await screen.findByRole('button', { name: /Alejandra/ }));
    const fecha = new Date(consulta.procesadaIaAt).toLocaleString('es-AR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit', hourCycle: 'h23' });
    // 25/10: la revisión va plegada en una línea de resumen que dice cuándo se revisó.
    expect(screen.getByText(new RegExp(`revisado ${fecha}`))).toBeInTheDocument();

    await userEvent.click(screen.getByRole('button', { name: 'Revisar de nuevo' }));
    expect(mocks.sugerirRespuestaConsultaFamiliaAdmin).toHaveBeenCalledWith('p1');
    // Mientras revisa, el borrador viejo no queda listo para enviar.
    const cuadro = screen.getByPlaceholderText(/Escribí la respuesta para la familia/) as HTMLTextAreaElement;
    expect(cuadro.value).toBe('');
    expect(screen.getByRole('button', { name: /Revisando/ })).toBeDisabled();
    expect(screen.getByRole('button', { name: /Enviar respuesta/ })).toBeDisabled();

    await act(async () => sugerencia.resolver({ sugerencia: 'Ya está aprobada: Tomás figura en Sala 4 C Tarde.' }));
    await waitFor(() => expect(cuadro.value).toBe('Ya está aprobada: Tomás figura en Sala 4 C Tarde.'));
    expect(mocks.responderConsultaFamiliaAdmin).not.toHaveBeenCalled();
    // Vuelve a traer la bandeja para mostrar la revisión nueva.
    expect(mocks.obtenerConsultasFamiliasAdmin).toHaveBeenCalledTimes(2);
  });
});
