// 10/10/2026 (pedido de Pablo): panel propio del colegio (retratoescolar.com.ar/colegio?c=<codigo>).
import { describe, expect, it, vi } from 'vitest';
import { render, screen, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import PanelColegio from '../PanelColegio';
import { fechaCortaColegio, linkCompartirWhatsApp, mensajeColegio } from '../../utils/mensajesColegio';

const CODIGO = 'PC0123456789ABCDEF0123';

const RESUMEN = {
  success: true,
  colegio: { nombre: 'Instituto de Prueba', eventoActual: 'Temporada 2026' },
  fechas: { tomaFotos: '2026-10-20', cierrePedidos: '2026-11-05', entregaKits: null },
  convenio: { firmado: true, fecha: '2026-03-01T12:00:00Z', porcentaje: 30 },
  comision: {
    periodo: { desde: '2026-01-01', hasta: '2026-12-31' },
    participacion: 13500,
  },
  cursos: [{ clave: 'GRADO5-CTM', grado: '5° grado', division: 'C', turno: 'Mañana', etiqueta: '5° grado "C" · Mañana', nomina: 25, inscriptos: 18, compraron: 12, impresos: 9 }],
  difusion: { urlSitio: 'https://www.retratoescolar.com.ar', urlInscripcion: 'https://www.retratoescolar.com.ar/?inscribirme=1' },
};

const ENTREGAS = {
  success: true,
  entregas: [
    { pedido: 'IFS-2026-0001', alumno: 'Alumno Uno', numeroLista: 1, codigoSobre: 'GRADO5-CTM_01_UNO', curso: 'GRADO5-CTM', cursoEtiqueta: '5° grado "C" · Mañana', grado: '5° grado', division: 'C', turno: 'Mañana', kit: 'Kit Impreso', carpetas: 1, estado: 'listo', entregadoAt: null, entregadoPor: null },
    { pedido: 'IFS-2026-0002', alumno: 'Alumno Dos', numeroLista: 2, codigoSobre: 'GRADO5-CTM_02_DOS', curso: 'GRADO5-CTM', cursoEtiqueta: '5° grado "C" · Mañana', grado: '5° grado', division: 'C', turno: 'Mañana', kit: 'Kit Impreso', carpetas: 1, estado: 'en_laboratorio', entregadoAt: null, entregadoPor: null },
  ],
};

const DETALLE_COMISION = {
  periodo: { desde: '2026-01-01', hasta: '2026-12-31' },
  porcentaje: 30,
  pedidos: 2,
  venta: 60000,
  costoLaboratorio: 10000,
  comisionesCobro: 3000,
  impuestos: 2000,
  gananciaNeta: 45000,
  participacion: 13500,
  pedidosConFotosPendientes: 0,
  detalle: [{ pedido: 'IFS-2026-0001', curso: '5° grado C Mañana', pagado: '2026-06-15T15:00:00Z', venta: 30000, gananciaNeta: 22500 }],
};

function servidorFalso() {
  const llamadas: string[] = [];
  const fetchFalso = vi.fn(async (url: string, init?: RequestInit) => {
    llamadas.push(`${init?.method || 'GET'} ${url}`);
    const responder = (status: number, body: unknown) => new Response(JSON.stringify(body), { status, headers: { 'Content-Type': 'application/json' } });
    if (url === '/api/colegio/login') {
      const { pin } = JSON.parse(String(init?.body || '{}'));
      if (pin === '222222') return responder(403, { success: false, codigo: 'CONVENIO_SIN_FIRMAR', error: 'Para entrar al panel, el colegio primero tiene que firmar el convenio con Retrato Escolar.', linkConvenio: 'https://www.retratoescolar.com.ar/convenio.html?c=CVPRUEBA' });
      return pin === '123456' ? responder(200, { success: true, token: 'colegio.token', colegio: { nombre: 'Instituto de Prueba' }, expiraEn: 604800 }) : responder(401, { success: false, error: 'PIN incorrecto.' });
    }
    if (url === '/api/colegio/resumen') return responder(200, RESUMEN);
    if (url === '/api/colegio/comision/detalle') return responder(200, { success: true, comision: DETALLE_COMISION });
    if (url === '/api/colegio/entregas') return responder(200, ENTREGAS);
    if (url === '/api/colegio/entregas/IFS-2026-0001/entregado') return responder(200, { success: true, entregadoAt: '2026-10-21T13:00:00Z' });
    return responder(404, { success: false });
  });
  vi.stubGlobal('fetch', fetchFalso);
  return llamadas;
}

describe('mensajes de difusión del colegio', () => {
  const datos = {
    colegioNombre: 'Instituto de Prueba',
    curso: '5° grado "C" · Mañana',
    fechas: { tomaFotos: '2026-10-20', cierrePedidos: '2026-11-05', entregaKits: null },
    urlSitio: 'https://www.retratoescolar.com.ar',
    urlInscripcion: 'https://www.retratoescolar.com.ar/?inscribirme=1',
    anio: 2026,
  };

  it('la fecha se lee en Argentina, sin correrse de día', () => {
    expect(fechaCortaColegio('2026-10-20')).toBe('martes 20/10');
    expect(fechaCortaColegio(null)).toBeNull();
    expect(fechaCortaColegio('20/10/2026')).toBeNull();
  });

  it('cada mensaje lleva el colegio, el curso, el link y la fecha que corresponde; nunca un código', () => {
    const inscripcion = mensajeColegio('inscripcion', datos);
    expect(inscripcion).toContain('Instituto de Prueba');
    expect(inscripcion).toContain('*5° grado "C" · Mañana*');
    expect(inscripcion).toContain('martes 20/10');
    expect(inscripcion).toContain(datos.urlInscripcion);
    expect(mensajeColegio('fotos', datos)).toContain('jueves 5/11');
    expect(mensajeColegio('cierre', datos)).toContain('Los pedidos cierran el *jueves 5/11*');
    expect(mensajeColegio('entrega', datos)).toContain('se entregan en estos días'); // sin fecha cargada
    for (const tipo of ['inscripcion', 'fotos', 'cierre', 'entrega'] as const) {
      expect(mensajeColegio(tipo, datos)).not.toMatch(/c[óo]digo de acceso exclusivo|[A-Z0-9]{6,}-[A-Z0-9]+/);
    }
  });

  it('el link de WhatsApp lleva el texto ya escrito', () => {
    expect(linkCompartirWhatsApp('Hola *familias*')).toBe('https://wa.me/?text=Hola%20*familias*');
  });
});

describe('panel del colegio', () => {
  it('sin el código en el link avisa que está incompleto', () => {
    window.history.pushState({}, '', '/colegio');
    render(<PanelColegio />);
    expect(screen.getByText(/link está incompleto/i)).toBeInTheDocument();
  });

  it('vista previa de Pablo: entra sin PIN, avisa que es vista previa y no deja marcar entregas', async () => {
    window.history.pushState({}, '', '/colegio?vista=1');
    const llamadas = servidorFalso();
    localStorage.setItem('colegio_vista_previa_v1', JSON.stringify({ token: 'colegiovista.token', codigo: '', colegioNombre: 'Instituto de Prueba', venceAt: Date.now() + 3600_000 }));
    const user = userEvent.setup();
    render(<PanelColegio />);
    expect(await screen.findByText(/Vista previa \(sólo la ves vos\)/)).toBeInTheDocument();
    expect(screen.queryByLabelText('PIN del colegio')).toBeNull();
    await user.click(screen.getByRole('tab', { name: /Entregas/ }));
    await user.click(screen.getByRole('button', { name: /Marcar entregado/ }));
    expect(screen.getByText(/Es la vista previa: desde acá no se marcan entregas/)).toBeInTheDocument();
    expect(llamadas.some((l) => l.startsWith('POST'))).toBe(false);
    localStorage.removeItem('colegio_vista_previa_v1');
  });

  it('vista previa vencida o abierta a mano: explica cómo abrirla desde el panel', () => {
    window.history.pushState({}, '', '/colegio?vista=1');
    localStorage.removeItem('colegio_vista_previa_v1');
    render(<PanelColegio />);
    expect(screen.getByText(/Abrila desde tu panel/)).toBeInTheDocument();
    expect(screen.queryByLabelText('PIN del colegio')).toBeNull();
  });

  it('sin convenio firmado no entra: muestra el botón para leer y firmar el convenio', async () => {
    window.history.pushState({}, '', `/colegio?c=${CODIGO}`);
    servidorFalso();
    const user = userEvent.setup();
    render(<PanelColegio />);
    await user.type(screen.getByLabelText('PIN del colegio'), '222222');
    await user.click(screen.getByRole('button', { name: 'Ingresar' }));
    expect(await screen.findByText(/primero tiene que firmar el convenio/)).toBeInTheDocument();
    expect(screen.getByRole('link', { name: /Leer y firmar el convenio/ }).getAttribute('href')).toBe('https://www.retratoescolar.com.ar/convenio.html?c=CVPRUEBA');
    expect(screen.queryByRole('tab', { name: /Comisión/ })).toBeNull();
  });

  it('entra con el PIN y muestra comisión, cursos, difusión y entregas; marca un kit como entregado', async () => {
    window.history.pushState({}, '', `/colegio?c=${CODIGO}`);
    const llamadas = servidorFalso();
    vi.stubGlobal('confirm', vi.fn(() => true));
    const user = userEvent.setup();
    render(<PanelColegio />);

    await user.type(screen.getByLabelText('PIN del colegio'), '000000');
    await user.click(screen.getByRole('button', { name: 'Ingresar' }));
    expect(await screen.findByText('PIN incorrecto.')).toBeInTheDocument();

    await user.clear(screen.getByLabelText('PIN del colegio'));
    await user.type(screen.getByLabelText('PIN del colegio'), '123456');
    await user.click(screen.getByRole('button', { name: 'Ingresar' }));

    // Comisión
    expect(await screen.findByText('$13.500')).toBeInTheDocument();
    expect(screen.getByText(/Comisión del colegio · temporada 2026/)).toBeInTheDocument();
    expect(screen.queryByText(/Ganancia neta|Cobrado a las familias|Impresión del laboratorio/i)).toBeNull();
    expect(llamadas).not.toContain('GET /api/colegio/comision/detalle');

    // El detalle, sólo si lo piden desde los 3 puntitos de la esquina
    await user.click(screen.getByRole('button', { name: 'Más opciones' }));
    await user.click(screen.getByRole('menuitem', { name: /Ver el detalle del cálculo/ }));
    expect(await screen.findByText('Ganancia neta')).toBeInTheDocument();
    expect(llamadas).toContain('GET /api/colegio/comision/detalle');
    expect(screen.getByText('Comisión del colegio (30%)')).toBeInTheDocument();
    await user.click(screen.getByRole('button', { name: 'Ver los pedidos (1)' }));
    expect(screen.getByText('IFS-2026-0001')).toBeInTheDocument();
    await user.click(screen.getByRole('button', { name: 'Más opciones' }));
    await user.click(screen.getByRole('menuitem', { name: /Ocultar el detalle/ }));
    expect(screen.queryByText('Ganancia neta')).toBeNull();
    expect(screen.getByText(/Firmado el/)).toBeInTheDocument();

    // Cursos
    await user.click(screen.getByRole('tab', { name: /Cursos/ }));
    const fila = screen.getByText('5° grado "C" · Mañana').closest('li') as HTMLElement;
    expect(within(fila).getByText('25')).toBeInTheDocument();
    expect(within(fila).getByText('(72%)')).toBeInTheDocument();

    // Difusión: el mensaje con el link y el botón de WhatsApp
    await user.click(screen.getByRole('tab', { name: /Difusión/ }));
    expect(screen.getByText(/inscríbanse en la web/)).toBeInTheDocument();
    expect(screen.getByRole('link', { name: /Compartir por WhatsApp/ }).getAttribute('href')).toMatch(/^https:\/\/wa\.me\/\?text=/);

    // Entregas
    await user.click(screen.getByRole('tab', { name: /Entregas/ }));
    expect(screen.getAllByText('Alumno Uno').length).toBeGreaterThan(0);
    expect(screen.getAllByText('En el laboratorio').length).toBeGreaterThan(0);
    const botones = screen.getAllByRole('button', { name: /Marcar entregado/ });
    expect(botones).toHaveLength(1); // sólo el que está «listo para entregar»
    await user.click(botones[0]);
    expect(llamadas).toContain('POST /api/colegio/entregas/IFS-2026-0001/entregado');
    expect(await screen.findByText(/por el colegio/)).toBeInTheDocument();
    expect(screen.queryAllByRole('button', { name: /Marcar entregado/ })).toHaveLength(0);
  });
});
