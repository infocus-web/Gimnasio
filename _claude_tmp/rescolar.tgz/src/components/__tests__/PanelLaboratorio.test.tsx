import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { beforeEach, describe, expect, it, vi } from 'vitest';
import PanelLaboratorio from '../PanelLaboratorio';

// Panel del laboratorio (27/9): ingreso con PIN, pedidos nuevos y lotes, sin datos de contacto.
const filaPedido = (id: string, lote: string | null) => ({
  id,
  pedido_friendly_id: `IFS-2026-${id.slice(-4)}`,
  created_at: '2026-09-27T10:00:00Z',
  colegio_id: 'c1',
  colegio_nombre: 'Instituto',
  curso_codigo: 'GRADO1-ATM',
  grado: '1° grado',
  division: 'A',
  turno: 'Mañana',
  alumno_nombre: `Alumno ${id.slice(-4)}`,
  alumno_numero_lista: 1,
  codigo_alumno: '',
  tipo_kit: 'impreso_digital',
  kit_nombre: 'Kit Impreso + Digital',
  carpetas_impresas: 1,
  copias_extras: {},
  fotos_seleccionadas: { grupalId: 'f1', individualId: 'f2', docenteId: 'f3' },
  estado: 'pagado',
  estado_lab: null,
  seleccion_pendiente: false,
  lote_lab_id: lote,
});

describe('PanelLaboratorio', () => {
  beforeEach(() => {
    localStorage.clear();
    global.fetch = vi.fn(async (url: RequestInfo | URL) => {
      const u = String(url);
      if (u === '/api/lab/login') return { ok: true, status: 200, json: async () => ({ success: true, token: 'lab.1.2.3' }) } as Response;
      if (u === '/api/lab/pedidos')
        return {
          ok: true,
          status: 200,
          json: async () => ({
            success: true,
            pedidos: [filaPedido('00000000-0000-0000-0000-000000000001', null), filaPedido('00000000-0000-0000-0000-000000000002', 'l1')],
            fotos: [],
            lotes: [{ id: 'l1', numero: 1, created_at: '2026-09-27T09:00:00Z', cantidad: 1, en_produccion_at: null }],
          }),
        } as Response;
      return { ok: false, status: 404, json: async () => ({}) } as Response;
    }) as unknown as typeof fetch;
  });

  it('pide el PIN, muestra los pedidos nuevos y los lotes', async () => {
    render(<PanelLaboratorio />);
    await userEvent.type(screen.getByPlaceholderText(/pin del laboratorio/i), '1234');
    await userEvent.click(screen.getByRole('button', { name: /ingresar/i }));
    expect(await screen.findByRole('button', { name: /descargar pedidos nuevos/i })).toBeEnabled();
    expect(screen.getByRole('heading', { name: 'Pedidos nuevos' })).toBeInTheDocument();
    // Pestañas (2/10): los lotes están en su propia pestaña.
    await userEvent.click(screen.getByRole('tab', { name: /lotes/i }));
    expect(await screen.findByText(/Lote N° 1/)).toBeInTheDocument();
    expect(screen.getByText('Alumno 0002')).toBeInTheDocument(); // el lote se ve desplegado
    expect(screen.getByText(/Resumen para facturar/)).toBeInTheDocument();
    expect(screen.getByRole('button', { name: /marcar en producción/i })).toBeInTheDocument();
  });

  it('refresca la lista antes de armar el lote y no baja nada si el lote trae pedidos que no están en el ZIP', async () => {
    // Auditoría 03/10 (alto 19).
    const llamadas: string[] = [];
    const fetchBase = global.fetch;
    global.fetch = vi.fn(async (url: RequestInfo | URL, init?: RequestInit) => {
      const u = String(url);
      llamadas.push(`${init?.method || 'GET'} ${u}`);
      if (u === '/api/lab/lotes')
        return {
          ok: true,
          status: 200,
          json: async () => ({
            success: true,
            lote: { id: 'l2', numero: 2, created_at: '2026-10-03T10:00:00Z', cantidad: 2, en_produccion_at: null },
            pedidoIds: ['00000000-0000-0000-0000-000000000001', '00000000-0000-0000-0000-000000000099'],
          }),
        } as Response;
      return fetchBase(url, init);
    }) as unknown as typeof fetch;
    render(<PanelLaboratorio />);
    await userEvent.type(screen.getByPlaceholderText(/pin del laboratorio/i), '1234');
    await userEvent.click(screen.getByRole('button', { name: /ingresar/i }));
    await userEvent.click(await screen.findByRole('button', { name: /descargar pedidos nuevos/i }));
    expect(await screen.findByText(/No se bajó nada para no dejar pedidos afuera/)).toBeInTheDocument();
    const iLote = llamadas.indexOf('POST /api/lab/lotes');
    expect(iLote).toBeGreaterThan(-1);
    // Se pidió la lista otra vez justo antes de armar el lote (además de la carga inicial).
    expect(llamadas.slice(0, iLote).filter((l) => l === 'GET /api/lab/pedidos').length).toBeGreaterThanOrEqual(2);
  });
});
