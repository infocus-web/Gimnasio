import { useState } from 'react';
import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { describe, expect, it } from 'vitest';
import CampoPin from '../CampoPin';

// 08/10/2026 (pedido de Pablo: «no puedo ver la clave que estoy colocando»): los campos de PIN
// tienen un ojito para mostrar u ocultar lo escrito.

function Envoltorio() {
  const [pin, setPin] = useState('');
  return <CampoPin value={pin} onChange={e => setPin(e.target.value)} placeholder="PIN de fotógrafo" />;
}

describe('CampoPin', () => {
  it('arranca oculto y el ojito alterna entre mostrar y ocultar lo escrito', async () => {
    const usuario = userEvent.setup();
    render(<Envoltorio />);

    const campo = screen.getByPlaceholderText('PIN de fotógrafo') as HTMLInputElement;
    expect(campo.type).toBe('password');

    await usuario.type(campo, '1234');
    await usuario.click(screen.getByRole('button', { name: 'Mostrar PIN' }));
    expect(campo.type).toBe('text');
    expect(campo.value).toBe('1234');

    await usuario.click(screen.getByRole('button', { name: 'Ocultar PIN' }));
    expect(campo.type).toBe('password');
  });

  it('el ojito no envía el formulario', async () => {
    const usuario = userEvent.setup();
    let envios = 0;
    render(
      <form onSubmit={e => { e.preventDefault(); envios++; }}>
        <CampoPin defaultValue="" placeholder="PIN" />
      </form>
    );
    await usuario.click(screen.getByRole('button', { name: 'Mostrar PIN' }));
    expect(envios).toBe(0);
  });
});
