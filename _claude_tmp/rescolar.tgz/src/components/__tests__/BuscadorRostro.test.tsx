// Buscador por rostro en el portal (24/10/2026): sin llave de la familia no aparece; sin foto y sin la casilla de
// consentimiento no se puede buscar; al encontrar fotos avisa y recarga la galería.
import { fireEvent, render, screen, waitFor } from '@testing-library/react';
import { afterEach, describe, expect, it, vi } from 'vitest';
import BuscadorRostro from '../BuscadorRostro';

const disponible = vi.hoisted(() => ({ si: true }));
vi.mock('../../services/buscadorRostroService', () => ({
  buscadorRostroDisponible: vi.fn(async () => disponible.si),
  prepararImagenRostro: vi.fn(async () => 'base64'),
  buscarPorRostro: vi.fn(async () => ({ success: true, nuevas: 2, yaEnGaleria: 0 })),
}));

const acceso = { codigo: 'SA5C-0001', familia: 'f', acceso: 'a', alumnoNombre: 'Lola Paz' };
afterEach(() => vi.clearAllMocks());

describe('BuscadorRostro', () => {
  it('sin la llave de la familia no se muestra', () => {
    const { container } = render(<BuscadorRostro acceso={null} onEncontradas={() => {}} />);
    expect(container.textContent).toBe('');
  });

  it('en un colegio sin buscador no se muestra', async () => {
    disponible.si = false;
    const { container } = render(<BuscadorRostro acceso={acceso} onEncontradas={() => {}} />);
    await new Promise((r) => setTimeout(r, 20));
    expect(container.textContent).toBe('');
    disponible.si = true;
  });

  it('pide foto y consentimiento; al encontrar avisa y recarga la galería', async () => {
    const onEncontradas = vi.fn();
    const { container } = render(<BuscadorRostro acceso={acceso} onEncontradas={onEncontradas} />);
    fireEvent.click(await screen.findByRole('button', { name: /buscar por rostro/i }));
    expect(screen.getByText(/no se usan para entrenar inteligencia artificial/i)).toBeTruthy();
    const boton = screen.getByRole('button', { name: /buscar sus fotos/i }) as HTMLButtonElement;
    expect(boton.disabled).toBe(true);
    const input = container.querySelector('input[type="file"]') as HTMLInputElement;
    fireEvent.change(input, { target: { files: [new File(['x'], 'cara.jpg', { type: 'image/jpeg' })] } });
    expect(boton.disabled).toBe(true); // falta la casilla
    fireEvent.click(screen.getByRole('checkbox'));
    expect(boton.disabled).toBe(false);
    fireEvent.click(boton);
    await waitFor(() => expect(onEncontradas).toHaveBeenCalledTimes(1));
    expect(screen.getByRole('status').textContent).toMatch(/Encontramos 2 fotos/);
  });
});
