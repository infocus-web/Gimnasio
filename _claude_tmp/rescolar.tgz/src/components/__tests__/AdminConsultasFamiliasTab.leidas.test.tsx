import { render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { afterEach, describe, expect, it, vi } from 'vitest';
import AdminConsultasFamiliasTab from '../AdminConsultasFamiliasTab';

// 25/10/2026 (Pablo: «no puedo saber cuál ya leí y cuál no»): abrir una consulta «Nueva» la marca leída
// (pasa a «En proceso»), sin sacarla de la lista mientras se lee.
const mocks = vi.hoisted(() => ({ obtener: vi.fn(), actualizar: vi.fn(), especial: vi.fn() }));
vi.mock('../../services/consultasFamiliasService', () => ({
  obtenerConsultasFamiliasAdmin: mocks.obtener,
  sugerirRespuestaConsultaFamiliaAdmin: vi.fn(),
  responderConsultaFamiliaAdmin: vi.fn(),
  actualizarEstadoConsultaFamiliaAdmin: mocks.actualizar,
  eliminarConsultaFamiliaAdmin: async () => undefined,
  marcarAtencionEspecialAdmin: mocks.especial,
}));
afterEach(() => vi.clearAllMocks());

const base = { email: 'f@familia.com', asunto: 'Fotos', mensaje: 'Hola', origen: 'web', createdAt: '2026-10-25T17:00:00.000Z', updatedAt: '2026-10-25T17:00:00.000Z', mensajes: [] };

describe('Consultas: leídas', () => {
  it('al abrir una consulta nueva la pasa a «En proceso»; una ya leída no se toca', async () => {
    mocks.obtener.mockResolvedValue([
      { ...base, id: 'n1', nombre: 'Nueva Familia', estado: 'nueva' },
      { ...base, id: 'e1', nombre: 'Leida Familia', estado: 'en_proceso' },
    ]);
    mocks.actualizar.mockResolvedValue(undefined);
    render(<AdminConsultasFamiliasTab />);
    await userEvent.click(await screen.findByRole('button', { name: /Nueva Familia/ }));
    await waitFor(() => expect(mocks.actualizar).toHaveBeenCalledWith('n1', 'en_proceso', 'nueva'));
    expect(screen.getByRole('button', { name: /Nueva Familia/ })).toBeTruthy();
    await userEvent.click(screen.getByRole('button', { name: /Leida Familia/ }));
    expect(mocks.actualizar).toHaveBeenCalledTimes(1);
  });

  it('al recargar la lista (o «Revisar de nuevo»), la consulta abierta no desaparece aunque ya no sea «Nueva»', async () => {
    const nueva = { ...base, id: 'n1', nombre: 'Nueva Familia', estado: 'nueva' };
    mocks.obtener.mockImplementation(async (estado: string) => (estado === 'todas' ? [{ ...nueva, estado: 'en_proceso' }] : mocks.obtener.mock.calls.length <= 1 ? [nueva] : []));
    mocks.actualizar.mockResolvedValue(undefined);
    render(<AdminConsultasFamiliasTab />);
    await userEvent.click(await screen.findByRole('button', { name: /Nueva Familia/ }));
    await userEvent.click(screen.getByRole('button', { name: /actualizar|recargar/i }));
    await waitFor(() => expect(mocks.obtener).toHaveBeenCalledWith('todas'));
    expect(screen.getByRole('button', { name: /Nueva Familia/ })).toBeTruthy();
  });

  it('«Atención especial»: marca la consulta con la bandera y tiene su pestaña', async () => {
    mocks.obtener.mockResolvedValue([{ ...base, id: 'n1', nombre: 'Nueva Familia', estado: 'nueva' }]);
    mocks.especial.mockResolvedValue(undefined);
    render(<AdminConsultasFamiliasTab />);
    await userEvent.click(await screen.findByRole('button', { name: 'Mandar a Atención especial' }));
    await waitFor(() => expect(mocks.especial).toHaveBeenCalledWith('n1', true));
    expect(await screen.findByRole('button', { name: 'Quitar de Atención especial' })).toBeTruthy();
    await userEvent.click(screen.getByRole('button', { name: 'Atención especial' }));
    await waitFor(() => expect(mocks.obtener).toHaveBeenCalledWith('especial'));
  });
});
