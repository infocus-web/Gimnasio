// 20/10/2026 (Pablo: «no me queda claro qué curso ya fue fotografiado y cuál no»): resumen por curso de la Nómina.
// 21/10/2026 (Pablo: «prefiero un listado, verde, amarillo y rojo»): lista por curso con color según el avance.
import { describe, expect, it, vi } from 'vitest';
import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import ResumenCursosNomina, { avancePorCurso } from '../ResumenCursosNomina';
import type { AlumnoNominaReal } from '../../services/colegiosService';

const alu = (id: string, grado: string, ind: boolean, seno: boolean, grupal: boolean): AlumnoNominaReal => ({
  id, nombre: id, grado, division: 'A', turno: 'Mañana', colegio_id: 'c', numero_lista: 1, dni: null, origen: null,
  fotografiado_at: ind ? 'x' : null, foto_seno_at: seno ? 'x' : null, foto_grupal_at: grupal ? 'x' : null,
});
const idDe = (a: AlumnoNominaReal) => a.grado;
const secciones = [
  { id: '1° grado', nombreCompleto: '1° grado "A"', esSecundaria: false },
  { id: '2° grado', nombreCompleto: '2° grado "A"', esSecundaria: false },
  { id: '1° año', nombreCompleto: '1° año "A"', esSecundaria: true },
];
const alumnos = [
  alu('a', '1° grado', true, true, true), alu('b', '1° grado', true, true, true),
  alu('c', '2° grado', true, true, false), alu('d', '2° grado', false, false, false),
  alu('e', '1° año', false, false, false),
];

describe('Avance por curso de la Nómina', () => {
  it('cuenta cada foto por curso y le da el color: completo, faltan o sin fotos', () => {
    const r = avancePorCurso(alumnos, secciones, idDe);
    expect(r.map((c) => [c.total, c.conIndividual, c.conSeno, c.conGrupal, c.completos, c.estado])).toEqual([
      [2, 2, 2, 2, 2, 'completo'],
      [2, 1, 1, 0, 0, 'faltan'],
      [1, 0, 0, 0, 0, 'sin-empezar'],
    ]);
  });

  it('un curso con todas las individuales pero sin la grupal no está completo', () => {
    const r = avancePorCurso([alu('a', '1° grado', true, true, false)], secciones, idDe);
    expect(r[0].estado).toBe('faltan');
  });

  it('muestra los tres botones con los totales, abre los cursos de ese color y elige el curso al tocarlo', async () => {
    const onElegir = vi.fn();
    const u = userEvent.setup();
    render(<ResumenCursosNomina alumnos={alumnos} secciones={secciones} idDe={idDe} seleccionada="todas" onElegir={onElegir} />);
    expect(screen.queryByText(/2° grado "A"/)).toBeNull();
    await u.click(screen.getByRole('button', { name: /1\s*con faltantes/ }));
    expect(screen.queryByText('1° grado "A"')).toBeNull();
    const curso = screen.getByRole('button', { name: /2° grado "A".*faltan 2/ });
    await u.click(curso);
    expect(onElegir).toHaveBeenCalledWith('2° grado');
    expect(screen.queryByText(/2° grado "A"/)).toBeNull();
    await u.click(screen.getByRole('button', { name: /1\s*completos/ }));
    expect(screen.getByRole('button', { name: /1° grado "A"/ })).toBeTruthy();
  });
});
