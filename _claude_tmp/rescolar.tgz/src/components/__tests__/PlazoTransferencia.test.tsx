import { describe, expect, it, vi, afterEach } from 'vitest';
import { render, screen } from '@testing-library/react';
import SubirComprobante from '../SubirComprobante';
import { formatearVencimiento } from '../../utils/plazoTransferencia';

afterEach(() => vi.unstubAllGlobals());

describe('Plazo de 48 hs de la transferencia', () => {
  it('formatea el vencimiento en hora de Argentina', () => {
    expect(formatearVencimiento('2026-10-01T18:30:00.000Z')).toMatch(/1\/10 a las 15:30/);
    expect(formatearVencimiento(null)).toBeNull();
  });

  it('muestra hasta cuándo hay tiempo de subir el comprobante', async () => {
    vi.stubGlobal('fetch', vi.fn(async () => new Response(JSON.stringify({ success: true, subido: false, venceAt: '2026-10-01T18:30:00.000Z' }))));
    render(<SubirComprobante pedidoId="11111111-1111-1111-1111-111111111111" numeros="IFS-2026-1234" />);
    expect(await screen.findByText(/1\/10 a las 15:30/)).toBeInTheDocument();
    expect(screen.getByText(/se cancela automáticamente/i)).toBeInTheDocument();
  });

  it('avisa si el pedido ya se canceló por vencer el plazo', async () => {
    vi.stubGlobal('fetch', vi.fn(async () => new Response(JSON.stringify({ success: false, vencido: true, error: 'Este pedido se canceló porque pasaron 48 horas.' }), { status: 410 })));
    render(<SubirComprobante pedidoId="11111111-1111-1111-1111-111111111111" />);
    expect(await screen.findByText('Este pedido se canceló')).toBeInTheDocument();
    expect(screen.queryByRole('button', { name: /subir comprobante/i })).not.toBeInTheDocument();
  });
});
