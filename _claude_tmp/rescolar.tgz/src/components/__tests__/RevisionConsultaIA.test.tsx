import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { describe, expect, it, vi } from 'vitest';
import RevisionConsultaIA, { resumenPedidos } from '../RevisionConsultaIA';

// 25/10/2026 (Pablo): la revisión automática ocupaba la mayor parte del mensaje. Va plegada; los problemas se ven siempre.
const base = { id: 'c1', nombre: 'F', email: 'f@f.com', asunto: 'a', mensaje: 'm', estado: 'nueva', origen: 'web', createdAt: '', updatedAt: '', mensajes: [] } as any;

describe('RevisionConsultaIA', () => {
  it('todo en orden: una línea de resumen y el detalle oculto hasta tocarla', async () => {
    render(<RevisionConsultaIA revisando={false} onRevisar={vi.fn()} consulta={{ ...base, verificacionIa: { encontrada: true, todoOk: true, chequeos: [{ ok: true, texto: 'Juan: 1° A, coincide con la nómina.' }], datos: ['Fotos cargadas del curso de Juan: 90.', 'Pedido IFS-1 de Juan: kit, total $1, pago "pagado" (mp), laboratorio "sin estado".'] } }} />);
    expect(screen.getByText(/Datos de la familia en orden/)).toBeTruthy();
    expect(screen.getByText(/1 chico · 1 pedido pagado/)).toBeTruthy();
    expect(screen.queryByText(/Fotos cargadas/)).toBeNull();
    await userEvent.click(screen.getByRole('button', { name: /Datos de la familia en orden/ }));
    expect(screen.getByText(/Fotos cargadas/)).toBeTruthy();
  });

  it('con problemas: los muestra siempre, sin abrir el detalle', () => {
    render(<RevisionConsultaIA revisando={false} onRevisar={vi.fn()} consulta={{ ...base, verificacionIa: { encontrada: false, todoOk: false, chequeos: [{ ok: false, texto: 'No hay ninguna inscripción con el email f@f.com.' }], datos: [] } }} />);
    expect(screen.getByText(/1 cosa para revisar/)).toBeTruthy();
    expect(screen.getByText(/No hay ninguna inscripción/)).toBeTruthy();
  });

  it('resume los pedidos', () => {
    expect(resumenPedidos([])).toBe('sin pedidos');
    expect(resumenPedidos(['Pedido A: pago "pagado"', 'Pedido B: pago "pendiente"'])).toBe('2 pedidos (1 pagado)');
  });
});
