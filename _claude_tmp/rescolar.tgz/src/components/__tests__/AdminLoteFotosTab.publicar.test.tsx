import { readFileSync } from 'fs';
import path from 'path';
import { render, screen, waitFor, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { describe, expect, it, vi } from 'vitest';

import { fuenteServidor } from '../../test/fuenteServidor';
import AdminLoteFotosTab from '../AdminLoteFotosTab';
import { COLEGIO_POR_DEFECTO } from '../../services/colegiosService';
import { listarFotosActivasAdmin, publicarFotosAdmin } from '../../services/fotosSubidasService';

// 06/10/2026 (pedido de Pablo: «si cargo por error unas fotos, que no se publiquen hasta que lo
// apruebe»): las fotos se suben SIN PUBLICAR y el panel tiene el botón «Publicar».

const server = fuenteServidor();
const migracion = readFileSync(path.resolve(__dirname, '../../../supabase/migrations/20261006020000_fotos_publicar.sql'), 'utf8');

function respuesta(status: number, cuerpo: unknown): Response {
  return { ok: status >= 200 && status < 300, status, json: async () => cuerpo, headers: new Headers() } as unknown as Response;
}
function urlDe(input: RequestInfo | URL) {
  return typeof input === 'string' ? input : input.toString();
}
function bloque(inicio: string, largo = 5000) {
  const i = server.indexOf(inicio);
  if (i < 0) throw new Error(`No encontré ${inicio}`);
  return server.slice(i, i + largo);
}

describe('servidor: fotos sin publicar (contratos)', () => {
  it('al subir, las fotos se registran sin publicar y NO se avisa a las familias', () => {
    const registro = bloque("app.post('/api/admin/fotos', requireAdminAuth", 9000);
    const hastaPublicar = registro.slice(0, registro.indexOf("app.post('/api/admin/fotos/publicar'"));
    expect(hastaPublicar).toContain('publicada_at: null');
    expect(hastaPublicar).not.toContain('avisarFotosDisponiblesASeccion(');
  });
  it('«Publicar» sólo toca las que siguen sin publicar y avisa sólo a los cursos sin aviso confirmado (14/10)', () => {
    const ruta = bloque("app.post('/api/admin/fotos/publicar'", 5000);
    expect(ruta).toContain('requireAdminAuth');
    expect(ruta).toContain(".update({ publicada_at: marca }).in('id', grupo).is('publicada_at', null)");
    expect(ruta).toContain('avisarCursosPublicados(supabase, [...secciones.values()], marca)');
  });
  it('las familias sólo ven y eligen fotos publicadas (galería, lupa, selección, reservas, IA y campaña)', () => {
    expect(bloque("app.get('/api/fotos',", 2500)).toContain(".not('publicada_at', 'is', null)");
    const lupa = bloque('async function accesoLupaFoto(', 3000);
    expect(lupa).toContain('if (!foto.publicada_at) return null;');
    expect(bloque('async function validarSeleccionFotos(', 1200)).toContain(".not('publicada_at', 'is', null)");
    expect(bloque('async function cursoTieneFotosDelPack(', 600)).toContain(".not('publicada_at', 'is', null)");
    const elegir = bloque("app.post('/api/reservas/:id/elegir-fotos'", 9000);
    // 22/10: confirmar las fotos de una reserva usa la misma validación que la compra (sólo publicadas).
    expect(elegir).toContain('await validarSeleccionFotos(');
    expect(bloque('async function armarDestinatariosPagoAnticipado(', 800)).toContain(".not('publicada_at', 'is', null)");
    expect(bloque('async function armarFichaFamilia(', 8000)).toContain(".not('publicada_at', 'is', null)");
  });
  it('el panel recibe publicada_at y la migración deja publicadas las fotos que ya existían', () => {
    expect(server).toMatch(/const COLUMNAS_FOTO_PANEL = '[^']*publicada_at[^']*'/);
    expect(migracion).toContain('add column if not exists publicada_at timestamptz default now()');
    expect(migracion).toContain('update public.fotos set publicada_at = coalesce(created_at, now()) where publicada_at is null');
  });
});

describe('servicio del panel', () => {
  it('lee el estado de publicación (sin la columna = publicada, como antes)', async () => {
    vi.stubGlobal('fetch', vi.fn(async () => respuesta(200, { success: true, fotos: [
      { id: 'a', categoria: 'grupal', publicada_at: null },
      { id: 'b', categoria: 'grupal', publicada_at: '2026-10-06T10:00:00Z' },
      { id: 'c', categoria: 'grupal' },
    ] })));
    const r = await listarFotosActivasAdmin({ colegioId: 'x' });
    expect(r.fotos.map((f) => f.publicada)).toEqual([false, true, true]);
  });
  it('publica por ids en tandas de 2000', async () => {
    const fetchMock = vi.fn(async () => respuesta(200, { success: true, publicadas: 2, emailsEnviados: 1 }));
    vi.stubGlobal('fetch', fetchMock);
    const ids = Array.from({ length: 2001 }, (_, i) => `id-${i}`);
    const r = await publicarFotosAdmin({ ids });
    expect(fetchMock).toHaveBeenCalledTimes(2);
    const [url, init] = fetchMock.mock.calls[0] as unknown as [string, RequestInit];
    expect(url).toBe('/api/admin/fotos/publicar');
    expect(JSON.parse(String(init.body)).ids).toHaveLength(2000);
    expect(r).toMatchObject({ success: true, publicadas: 4, emailsEnviados: 2 });
  });
});

describe('panel «Cargar fotos»: botón Publicar', () => {
  it('muestra las fotos sin publicar y las publica al confirmar', async () => {
    const curso = { grado: COLEGIO_POR_DEFECTO.grados[0], turno: COLEGIO_POR_DEFECTO.turnos[0], division: COLEGIO_POR_DEFECTO.divisiones[0] };
    const fila = (id: string, publicada: boolean) => ({
      id, colegio_id: COLEGIO_POR_DEFECTO.id, codigo_curso: 'X', ...curso, categoria: 'grupal', alumno_nombre: null,
      preview_path: `/m/${id}.jpg`, thumb_path: `/t/${id}.jpg`, storage_path: `2026/x/${id}.jpg`, created_at: '2026-10-06T10:00:00Z',
      publicada_at: publicada ? '2026-10-06T10:00:00Z' : null,
    });
    let publicadas = false;
    const fetchMock = vi.fn(async (input: RequestInfo | URL, _init?: RequestInit) => {
      const url = urlDe(input);
      if (url.startsWith('/api/admin/fotos/publicar')) {
        publicadas = true;
        return respuesta(200, { success: true, publicadas: 2, emailsEnviados: 5 });
      }
      if (url.startsWith('/api/admin/fotos?')) {
        return respuesta(200, { success: true, fotos: [fila('f1', publicadas), fila('f2', publicadas), fila('f3', true)] });
      }
      return respuesta(404, { success: false });
    });
    vi.stubGlobal('fetch', fetchMock);
    vi.spyOn(window, 'confirm').mockReturnValue(true);
    const user = userEvent.setup();
    render(<AdminLoteFotosTab />);

    const boton = await screen.findByRole('button', { name: /publicar 2 foto\(s\) sin publicar/i });
    expect(screen.getAllByText(/^sin publicar$/i).length).toBeGreaterThan(0);
    expect(screen.getByText(/1 publicadas \(a la venta\)/i)).toBeInTheDocument();
    await user.click(boton);

    await waitFor(() => expect(fetchMock.mock.calls.some((c) => urlDe(c[0] as RequestInfo) === '/api/admin/fotos/publicar')).toBe(true));
    const llamada = fetchMock.mock.calls.find((c) => urlDe(c[0] as RequestInfo) === '/api/admin/fotos/publicar')!;
    expect(JSON.parse(String((llamada[1] as RequestInit).body)).ids.sort()).toEqual(['f1', 'f2']);
    expect(await screen.findByText(/se avisó por email a 5 familia/i)).toBeInTheDocument();
    await waitFor(() => expect(screen.queryByRole('button', { name: /sin publicar/i })).not.toBeInTheDocument());
    expect(within(document.body).getByText(/3 publicadas \(a la venta\)/i)).toBeInTheDocument();
  });

  it('si se cancela la confirmación no publica nada', async () => {
    const fetchMock = vi.fn(async (input: RequestInfo | URL) => {
      const url = urlDe(input);
      if (url.startsWith('/api/admin/fotos?')) {
        return respuesta(200, { success: true, fotos: [{
          id: 'f1', colegio_id: COLEGIO_POR_DEFECTO.id, codigo_curso: 'X', grado: COLEGIO_POR_DEFECTO.grados[0], turno: COLEGIO_POR_DEFECTO.turnos[0],
          division: COLEGIO_POR_DEFECTO.divisiones[0], categoria: 'individual', alumno_nombre: 'Ana Perez', preview_path: '/m.jpg', thumb_path: '/t.jpg',
          storage_path: '2026/x/f1.jpg', created_at: '2026-10-06T10:00:00Z', publicada_at: null,
        }] });
      }
      return respuesta(404, { success: false });
    });
    vi.stubGlobal('fetch', fetchMock);
    vi.spyOn(window, 'confirm').mockReturnValue(false);
    const user = userEvent.setup();
    render(<AdminLoteFotosTab />);
    await user.click(await screen.findByRole('button', { name: /publicar 1 foto\(s\) sin publicar/i }));
    expect(fetchMock.mock.calls.some((c) => urlDe(c[0] as RequestInfo).startsWith('/api/admin/fotos/publicar'))).toBe(false);
  });
});
