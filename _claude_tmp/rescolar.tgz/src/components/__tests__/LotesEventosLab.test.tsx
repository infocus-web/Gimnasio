import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { beforeEach, describe, expect, it, vi } from 'vitest';
import LotesEventosLab from '../LotesEventosLab';

// Lotes de eventos dentro del panel del laboratorio (2/10): usan la misma sesión del laboratorio.
const lote = {
  id: 'l1', numero: 1, estado: 'en_laboratorio', creado_en: '2026-10-05T10:00:00Z', fecha_terminado: null,
  evento: { nombre: 'Confirmaciones', codigo: 'CONFIRMACION-0309' }, pedidos: 3, copias15x21: 4, copias20x30: 1,
};
const json = (d: unknown, status = 200) => ({ ok: status < 400, status, json: async () => d } as Response);

describe('LotesEventosLab', () => {
  let llamadas: string[];
  beforeEach(() => {
    llamadas = [];
    localStorage.setItem('lab_token_v1', 'lab.1.2.3');
  });

  it('no muestra nada si no hay lotes de eventos', async () => {
    global.fetch = vi.fn(async () => json({ success: true, lotes: [] })) as any;
    const { container } = render(<LotesEventosLab onError={() => {}} />);
    await new Promise((r) => setTimeout(r, 0));
    expect(container.innerHTML).toBe('');
  });

  it('lista los lotes con la sesión del laboratorio y permite marcarlos terminados', async () => {
    let estado = 'en_laboratorio';
    global.fetch = vi.fn(async (url: RequestInfo | URL, init?: RequestInit) => {
      const u = String(url);
      llamadas.push(`${init?.method || 'GET'} ${u} ${(init?.headers as any)?.Authorization || ''}`);
      if (u === '/api/eventos/lab/lotes') return json({ success: true, lotes: [{ ...lote, estado }] });
      if (u.endsWith('/estado')) { estado = 'terminado'; return json({ success: true }); }
      return json({ success: false }, 404);
    }) as any;
    vi.spyOn(window, 'confirm').mockReturnValue(true);
    render(<LotesEventosLab onError={() => {}} />);
    expect(await screen.findByText(/Confirmaciones — Lote 1/)).toBeTruthy();
    expect(screen.getByText(/15x21: 4/)).toBeTruthy();
    expect(llamadas[0]).toContain('Bearer lab.1.2.3');
    await userEvent.click(screen.getByRole('button', { name: /Marcar terminado/ }));
    // Al terminarlo pasa al archivo (plegado): se despliega para verlo.
    await userEvent.click(await screen.findByRole('button', { name: /Archivados \(1\)/ }));
    expect(await screen.findByText('Terminado')).toBeTruthy();
    expect(llamadas.some((l) => l.startsWith('POST /api/eventos/lab/lotes/l1/estado'))).toBe(true);
  });

  it('un lote grande se baja en partes y recién al final se marca descargado', async () => {
    const archivos = Array.from({ length: 90 }, (_, i) => ({ carpeta: '15x21', nombre: `F${i}.jpg`, url: `https://x/f${i}.jpg` }));
    global.fetch = vi.fn(async (url: RequestInfo | URL, init?: RequestInit) => {
      const u = String(url);
      llamadas.push(`${init?.method || 'GET'} ${u}`);
      if (u === '/api/eventos/lab/lotes') return json({ success: true, lotes: [{ ...lote, estado: 'armado' }] });
      if (u.endsWith('/manifiesto')) return json({ success: true, archivos });
      if (u.endsWith('/estado')) return json({ success: true });
      return { ok: true, status: 200, arrayBuffer: async () => new ArrayBuffer(4) } as Response;
    }) as any;
    (URL as any).createObjectURL = vi.fn(() => 'blob:x');
    (URL as any).revokeObjectURL = vi.fn();
    render(<LotesEventosLab onError={() => {}} />);
    await userEvent.click(await screen.findByRole('button', { name: /Descargar ZIP/ }));
    expect(await screen.findByRole('button', { name: /Bajar parte 2 de 2/ }, { timeout: 5000 })).toBeTruthy();
    expect(llamadas.some((l) => l.includes('/estado'))).toBe(false);
    await userEvent.click(screen.getByRole('button', { name: /Bajar parte 2 de 2/ }));
    expect(await screen.findByText(/Lote descargado completo/, {}, { timeout: 5000 })).toBeTruthy();
    expect(llamadas.some((l) => l.startsWith('POST /api/eventos/lab/lotes/l1/estado'))).toBe(true);
  });
});
