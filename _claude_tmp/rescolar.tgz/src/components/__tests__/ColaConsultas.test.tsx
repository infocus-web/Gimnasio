import { render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { afterEach, describe, expect, it, vi } from 'vitest';
import ColaConsultas from '../ColaConsultas';
import { armarCola, esEsperandoFamilia, esPorResponder, haceCuanto } from '../../utils/colaConsultas';

// 25/10/2026 «Atender consultas»: una consulta por vez, primero la que más espera, y al enviar pasa sola a la siguiente.
const mocks = vi.hoisted(() => ({ obtener: vi.fn(), actualizar: vi.fn(), especial: vi.fn(), responder: vi.fn(), sugerir: vi.fn() }));
vi.mock('../../services/consultasFamiliasService', () => ({
  obtenerConsultasFamiliasAdmin: mocks.obtener,
  actualizarEstadoConsultaFamiliaAdmin: mocks.actualizar,
  marcarAtencionEspecialAdmin: mocks.especial,
  responderConsultaFamiliaAdmin: mocks.responder,
  sugerirRespuestaConsultaFamiliaAdmin: mocks.sugerir,
  ConsultaCambiadaError: class extends Error {},
}));
vi.mock('../../utils/useBorradorAdmin', async () => {
  const { useState } = await import('react');
  return {
    useBorradorAdmin: (_clave: string | null, inicial: string) => {
      const [valor, setValor] = useState(inicial);
      return [valor, setValor, { fijarSinGuardar: setValor, borrar: async () => undefined }];
    },
  };
});
vi.mock('../ModalFichaCliente', () => ({ default: () => null }));
afterEach(() => vi.clearAllMocks());

const base = { email: 'f@familia.com', asunto: 'Fotos', origen: 'web', updatedAt: '2026-10-25T17:00:00.000Z', mensajes: [] as any[] };
const vieja = { ...base, id: 'a', nombre: 'Familia Vieja', mensaje: 'Primera', estado: 'nueva', createdAt: '2026-10-20T10:00:00.000Z', borradorIa: 'Respuesta A' };
const reciente = { ...base, id: 'b', nombre: 'Familia Reciente', mensaje: 'Segunda', estado: 'en_proceso', createdAt: '2026-10-25T10:00:00.000Z', borradorIa: 'Respuesta B' };
const respondida = {
  ...base, id: 'c', nombre: 'Ya Respondida', mensaje: 'Hola', estado: 'en_proceso', createdAt: '2026-10-19T10:00:00.000Z',
  mensajes: [{ id: 'm1', direccion: 'saliente', remitente: '', destinatario: '', contenido: 'Listo', createdAt: '2026-10-19T11:00:00.000Z' }],
};
const especial = { ...base, id: 'd', nombre: 'Para Pablo', mensaje: 'Reclamo', estado: 'en_proceso', createdAt: '2026-10-18T10:00:00.000Z', atencionEspecial: true };

describe('reglas de la cola', () => {
  it('por responder / esperando a la familia según el último mensaje; la cola va de la más vieja a la más nueva y sin «Atención especial»', () => {
    expect(esPorResponder(vieja as any)).toBe(true);
    expect(esPorResponder(respondida as any)).toBe(false);
    expect(esEsperandoFamilia(respondida as any)).toBe(true);
    expect(esPorResponder({ ...vieja, estado: 'archivada' } as any)).toBe(false);
    expect(armarCola([reciente, especial, respondida, vieja] as any).map((c) => c.id)).toEqual(['a', 'b']);
    // Si la familia vuelve a escribir, vuelve a «por responder».
    const volvio = { ...respondida, mensajes: [...respondida.mensajes, { ...respondida.mensajes[0], id: 'm2', direccion: 'entrante', createdAt: '2026-10-25T12:00:00.000Z' }] };
    expect(esPorResponder(volvio as any)).toBe(true);
  });

  it('haceCuanto en palabras', () => {
    const ahora = Date.parse('2026-10-25T12:00:00Z');
    expect(haceCuanto(ahora - 5 * 60000, ahora)).toBe('hace 5 min');
    expect(haceCuanto(ahora - 3 * 3600000, ahora)).toBe('hace 3 h');
    expect(haceCuanto(ahora - 2 * 86400000, ahora)).toBe('hace 2 días');
  });
});

describe('Atender consultas', () => {
  it('muestra de a una con el borrador; «Enviar y siguiente» responde y pasa a la próxima; al final, el resumen', async () => {
    mocks.obtener.mockResolvedValue([reciente, vieja, respondida, especial]);
    mocks.actualizar.mockResolvedValue(undefined);
    mocks.responder.mockResolvedValue(undefined);
    render(<ColaConsultas onCerrar={() => undefined} />);
    expect(await screen.findByRole('heading', { name: 'Familia Vieja' })).toBeTruthy();
    expect(screen.getByText('Consulta 1 de 2')).toBeTruthy();
    await waitFor(() => expect((screen.getByLabelText(/Respuesta para/) as HTMLTextAreaElement).value).toBe('Respuesta A'));
    await waitFor(() => expect(mocks.actualizar).toHaveBeenCalledWith('a', 'en_proceso', 'nueva')); // queda leída
    await userEvent.click(screen.getByRole('button', { name: /Enviar y siguiente/ }));
    await waitFor(() => expect(mocks.responder).toHaveBeenCalledWith('a', 'Respuesta A', expect.any(String)));
    expect(await screen.findByRole('heading', { name: 'Familia Reciente' })).toBeTruthy();
    await userEvent.click(screen.getByRole('button', { name: /Mandar a Pablo/ }));
    await waitFor(() => expect(mocks.especial).toHaveBeenCalledWith('b', true));
    expect(await screen.findByText('¡Listo!')).toBeTruthy();
    expect(screen.getByText(/mandadas a Pablo/)).toBeTruthy();
  });

  it('«Saltear» no toca nada y la deja para «Ver las salteadas»', async () => {
    mocks.obtener.mockResolvedValue([vieja]);
    mocks.actualizar.mockResolvedValue(undefined);
    render(<ColaConsultas onCerrar={() => undefined} />);
    await screen.findByRole('heading', { name: 'Familia Vieja' });
    await userEvent.click(screen.getByRole('button', { name: /Saltear/ }));
    expect(mocks.responder).not.toHaveBeenCalled();
    await userEvent.click(await screen.findByRole('button', { name: 'Ver las salteadas' }));
    expect(await screen.findByRole('heading', { name: 'Familia Vieja' })).toBeTruthy();
  });
});
