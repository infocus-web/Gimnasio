// 13/10/2026 (pedido de Pablo): en la Nómina, «Curso» pasa a un alumno mal cargado a otro curso de la nómina.
import React, { useState } from 'react';
import { describe, expect, it, vi } from 'vitest';
import { render, screen, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { NombreConCambioCurso, useCambioCursoNomina } from '../ModalCambiarCursoAlumno';
import type { AlumnoNominaReal } from '../../services/colegiosService';

const cambiar = vi.fn();
vi.mock('../../services/colegiosService', () => ({
  cambiarCursoAlumnoAdmin: (...args: unknown[]) => cambiar(...args),
}));

const JE = 'Jornada Extendida / Completa';
const fila = (id: string, nombre: string, grado: string, division: string, turno: string | null, colegio = 'col-1'): AlumnoNominaReal => ({
  id, nombre, grado, division, turno, colegio_id: colegio, numero_lista: 1, dni: null, origen: null,
});
const INICIAL = [
  fila('a1', 'PEREZ, ANA', 'Sala 4 años', 'C', 'Tarde'),
  fila('a2', 'GOMEZ, LUZ', 'Sala 4 años', 'C', JE),
  fila('a3', 'DIAZ, SOL', 'Sala 4 años', 'C', JE),
  fila('b1', 'RUIZ, EVA', '1° grado', 'A', 'Mañana', 'col-2'),
];

function Nomina({ alFilaClick }: { alFilaClick: () => void }) {
  const [alumnos, setAlumnos] = useState(INICIAL);
  const { abrirCambioCurso, modalCambioCurso } = useCambioCursoNomina(alumnos, setAlumnos);
  return (
    <div>
      <ul>
        {alumnos.map((a) => (
          <li key={a.id} onClick={alFilaClick} data-testid={`fila-${a.id}`}>
            <NombreConCambioCurso alumno={a} onCambiar={abrirCambioCurso} /> <span>{`${a.grado}|${a.division}|${a.turno}`}</span>
          </li>
        ))}
      </ul>
      {modalCambioCurso}
    </div>
  );
}

describe('Nómina: cambiar de curso', () => {
  it('ofrece sólo otros cursos del mismo colegio, no marca la fila y actualiza la lista al guardar', async () => {
    const alFilaClick = vi.fn();
    cambiar.mockResolvedValue({ success: true, alumno: { ...INICIAL[0], turno: JE, numero_lista: 3 } });
    render(<Nomina alFilaClick={alFilaClick} />);

    await userEvent.click(screen.getByRole('button', { name: 'Cambiar de curso a PEREZ, ANA' }));
    expect(alFilaClick).not.toHaveBeenCalled();

    const dialogo = screen.getByRole('dialog');
    const opciones = within(dialogo).getAllByRole('option').map((o) => o.textContent);
    expect(opciones).toEqual(['Elegí el curso…', `Sala 4 años "C" (${JE}) · 2 alumnos`]);

    await userEvent.selectOptions(within(dialogo).getByRole('combobox'), `Sala 4 años__C__${JE}`);
    await userEvent.click(within(dialogo).getByRole('button', { name: 'Mover a este curso' }));

    expect(cambiar).toHaveBeenCalledWith('a1', { grado: 'Sala 4 años', division: 'C', turno: JE });
    expect(screen.queryByRole('dialog')).toBeNull();
    expect(within(screen.getByTestId('fila-a1')).getByText(`Sala 4 años|C|${JE}`)).toBeTruthy();
  });

  it('si el servidor lo rechaza, muestra el error y no cambia nada', async () => {
    cambiar.mockResolvedValue({ success: false, error: 'Ese curso no existe en la nómina de este colegio.' });
    render(<Nomina alFilaClick={() => {}} />);
    await userEvent.click(screen.getByRole('button', { name: 'Cambiar de curso a PEREZ, ANA' }));
    await userEvent.selectOptions(screen.getByRole('combobox'), `Sala 4 años__C__${JE}`);
    await userEvent.click(screen.getByRole('button', { name: 'Mover a este curso' }));
    expect(screen.getByRole('alert').textContent).toContain('no existe');
    expect(within(screen.getByTestId('fila-a1')).getByText('Sala 4 años|C|Tarde')).toBeTruthy();
  });
});
