// 30/10/2026: panel → Configuración (fechas límite de la temporada).
import { afterEach, describe, expect, it, vi } from 'vitest';
import { fireEvent, render, screen, waitFor } from '@testing-library/react';
import AdminConfiguracionTab from '../AdminConfiguracionTab';
import { aplicarPlazos, PLAZOS_POR_DEFECTO, plazosVigentes } from '../../utils/plazosTemporada';

const json = (status: number, cuerpo: unknown) => new Response(JSON.stringify(cuerpo), { status, headers: { 'Content-Type': 'application/json' } });

describe('AdminConfiguracionTab', () => {
  afterEach(() => {
    vi.unstubAllGlobals();
    aplicarPlazos({ ...PLAZOS_POR_DEFECTO });
  });

  it('muestra las fechas del servidor, guarda sólo si cambió algo y aplica lo guardado', async () => {
    const enviados: any[] = [];
    vi.stubGlobal('fetch', vi.fn(async (url: string, init?: RequestInit) => {
      if (String(url).includes('/api/admin/plazos')) {
        const cuerpo = JSON.parse(String(init?.body));
        enviados.push(cuerpo);
        return json(200, { success: true, plazos: cuerpo.plazos });
      }
      if (String(url).includes('/api/plazos')) return json(200, { success: true, plazos: { kitImpreso: '2026-11-15', faltantes: '2026-11-10' } });
      return json(404, {});
    }));

    render(<AdminConfiguracionTab />);
    const kit = (await screen.findByLabelText('Kit Impreso y fotos extra')) as HTMLInputElement;
    const faltantes = screen.getByLabelText('Pedido de fotos faltantes') as HTMLInputElement;
    await waitFor(() => expect(faltantes.value).toBe('2026-11-10'));
    expect(kit.value).toBe('2026-11-15');

    const guardar = screen.getByRole('button', { name: /Guardar fechas/ });
    expect(guardar).toBeDisabled();

    fireEvent.change(kit, { target: { value: '2026-11-22' } });
    expect(guardar).not.toBeDisabled();
    fireEvent.click(guardar);

    await screen.findByText(/Fechas guardadas/);
    expect(enviados).toEqual([{ plazos: { kitImpreso: '2026-11-22', faltantes: '2026-11-10' } }]);
    expect(plazosVigentes()).toEqual({ kitImpreso: '2026-11-22', faltantes: '2026-11-10' });
  });

  it('si no puede leer las fechas del servidor (página recién abierta), no deja guardar', async () => {
    vi.resetModules(); // estado limpio: todavía no se leyó nada del servidor
    const { default: TabNueva } = await import('../AdminConfiguracionTab');
    vi.stubGlobal('fetch', vi.fn(async () => json(500, {})));
    render(<TabNueva />);
    await screen.findByRole('alert');
    expect(screen.getByRole('button', { name: /Guardar fechas/ })).toBeDisabled();
  });
});
