import { render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { afterEach, describe, expect, it, vi } from 'vitest';
import ReservaRetorno from '../ReservaRetorno';

vi.mock('../../services/mediosPagoService', () => ({ useNaveHabilitado: () => false }));

// Pedido de Pablo (28/9): "Elegir otro medio de pago" muestra los medios sobre la misma reserva,
// sin volver a elegir el kit.
describe('ReservaRetorno — elegir otro medio de pago', () => {
  afterEach(() => vi.unstubAllGlobals());

  it('muestra los medios con sus botones y pasa la reserva a transferencia', async () => {
    const fetchMock = vi.fn(async (url: string) => {
      if (String(url).includes('/cambiar-metodo-pago')) return new Response(JSON.stringify({ success: true, metodoPago: 'transferencia' }));
      if (String(url).includes('/api/pagos/comprobante')) return new Response(JSON.stringify({ success: true, subido: false }));
      return new Response(JSON.stringify({ success: true, pedidoId: 'p-1', pedidoFriendlyId: 'IFS-2026-1234', estadoPago: 'rechazado', metodoPago: 'mercadopago', total: 15000 }));
    });
    vi.stubGlobal('fetch', fetchMock);
    const onElegirOtroMedio = vi.fn();
    render(<ReservaRetorno grupoPagoId="g-1" onCerrar={() => {}} onElegirOtroMedio={onElegirOtroMedio} />);
    await userEvent.click(await screen.findByRole('button', { name: /elegir otro medio de pago/i }));
    expect(screen.getByRole('button', { name: /pagar con mercado pago/i })).toBeInTheDocument();
    await userEvent.click(screen.getByRole('button', { name: /pagar con transferencia/i }));
    // 11/10 (POR-12): pasar a transferencia exige tildar el plazo de 48 h.
    await userEvent.click(document.getElementById('chk-plazo-transferencia-retorno') as HTMLElement);
    await userEvent.click(screen.getByRole('button', { name: /confirmar el pago por transferencia/i }));
    expect(await screen.findByText('RETRATO.ESCOLAR')).toBeInTheDocument();
    expect(onElegirOtroMedio).not.toHaveBeenCalled();
    await waitFor(() => expect(fetchMock.mock.calls.some((c) => String(c[0]).includes('/api/pedidos/p-1/cambiar-metodo-pago'))).toBe(true));
  });
});

// Pedido de Pablo (28/9): el email de recordatorio (12 hs sin comprobante) abre esta pantalla con
// ?pago_pendiente=1. Si es transferencia, se muestran directo los datos y la subida del comprobante.
describe('ReservaRetorno — link del recordatorio de pago', () => {
  afterEach(() => vi.unstubAllGlobals());

  it('pedido suelto por transferencia: muestra enseguida los datos y el comprobante', async () => {
    const fetchMock = vi.fn(async (url: string) => {
      if (String(url).includes('/api/pagos/comprobante')) return new Response(JSON.stringify({ success: true, subido: false }));
      return new Response(JSON.stringify({ success: true, pedidoId: 'p-9', pedidoFriendlyId: 'IFS-2026-9999', estadoPago: 'pendiente', metodoPago: 'transferencia', total: 30000, reservaAnticipada: false }));
    });
    vi.stubGlobal('fetch', fetchMock);
    render(<ReservaRetorno pedidoIdSuelto="p-9" recordatorio onCerrar={() => {}} />);
    expect(await screen.findByText(/está pendiente de pago/i)).toBeInTheDocument();
    expect(screen.getByText('RETRATO.ESCOLAR')).toBeInTheDocument();
    await waitFor(() => expect(fetchMock.mock.calls.some((c) => String(c[0]).includes('/api/pagos/comprobante?pedidoId=p-9'))).toBe(true));
  });

  it('Mercado Pago pendiente: ofrece completar el pago sin esperar', async () => {
    vi.stubGlobal('fetch', vi.fn(async () => new Response(JSON.stringify({ success: true, pedidoId: 'p-1', pedidoFriendlyId: 'IFS-2026-4681', estadoPago: 'pendiente', metodoPago: 'mercadopago', total: 30000, reservaAnticipada: true }))));
    render(<ReservaRetorno grupoPagoId="g-1" recordatorio onCerrar={() => {}} />);
    expect(await screen.findByRole('button', { name: /volver a intentar con mercado pago/i })).toBeInTheDocument();
    expect(screen.getByRole('button', { name: /elegir otro medio de pago/i })).toBeInTheDocument();
  });
});
