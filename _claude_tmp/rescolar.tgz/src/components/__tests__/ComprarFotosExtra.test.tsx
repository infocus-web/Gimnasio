// 29/10/2026 (Pablo): «muchos padres quieren comprar fotos extra de sus hijos, fuera del kit».
import React from 'react';
import { beforeEach, describe, expect, it, vi } from 'vitest';
import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import ComprarFotosExtra from '../ComprarFotosExtra';
import { planillaEnsobrado } from '../LotesFotosExtraLab';

const galeria = vi.fn();
const preparar = vi.fn();
const preferencia = vi.fn();
vi.mock('../../services/fotosSubidasService', () => ({ obtenerGaleriaPublica: (...a: unknown[]) => galeria(...a) }));
vi.mock('../../services/fotosExtraService', () => ({ prepararFotosExtra: (...a: unknown[]) => preparar(...a) }));
vi.mock('../../services/mercadoPagoService', () => ({ crearPreferenciaMercadoPago: (...a: unknown[]) => preferencia(...a) }));
const intencionNave = vi.fn();
vi.mock('../../services/naveService', () => ({ crearIntencionPagoNave: (...a: unknown[]) => intencionNave(...a) }));
vi.mock('../../services/mediosPagoService', () => ({ useNaveHabilitado: () => true }));
vi.mock('../SubirComprobante', () => ({ default: (p: { pedidoId: string; numeros: string }) => <p>Subir comprobante de {p.numeros} ({p.pedidoId})</p> }));

const fotos = [
  { id: 'g1', thumbnail: '/g1.jpg', categoria: 'grupal' },
  { id: 'i1', thumbnail: '/i1.jpg', categoria: 'individual', alumnoNombre: 'Juan Pérez' },
  { id: 'i2', thumbnail: '/i2.jpg', categoria: 'individual', alumnoNombre: 'Martina Gómez' },
];

beforeEach(() => {
  galeria.mockReset().mockResolvedValue({ estado: 'ok', fotos, seccion: null });
  preparar.mockReset().mockResolvedValue({ success: true, pedidoId: 'p-extra', total: 13000 });
  preferencia.mockReset().mockResolvedValue({ success: false, error: 'MP caído' });
  intencionNave.mockReset().mockResolvedValue({ success: false, error: 'Nave caído' });
});

const montar = () =>
  render(
    <ComprarFotosExtra
      kitPedidoUuid="kit-1"
      codigoSeccion="AB12-CD34"
      nombreAlumno="Juan Pérez"
      precios={{ extra15x21: 5000, extra20x30: 8000 }}
      datos={{ familia: 'f1', acceso: 'llave', tutorNombre: 'Pablo', tutorEmail: 'p@x.com' }}
    />
  );

describe('ComprarFotosExtra', () => {
  it('muestra sólo las fotos que puede ver la familia, arma el pedido y lo manda a cobrar', async () => {
    const u = userEvent.setup();
    montar();
    expect(screen.getByText(/15x21 a/)).toBeTruthy();
    await u.click(screen.getByRole('button', { name: /elegir fotos extra/i }));
    expect(galeria).toHaveBeenCalledWith({ codigo: 'AB12-CD34', familiaId: 'f1', acceso: 'llave' });
    const mosaicos = await screen.findAllByRole('button', { pressed: false, name: /grupal|individual/i });
    // La individual de otra chica no aparece.
    expect(mosaicos).toHaveLength(2);
    await u.click(screen.getByRole('button', { name: /^grupal/i }));
    await u.click(screen.getByRole('button', { name: /^individual/i }));
    // La individual pasa a 20x30 y la grupal a 1 copia más: 2 × 5.000 + 8.000.
    await u.click(screen.getAllByRole('button', { name: '20x30' })[1]);
    await u.click(screen.getAllByRole('button', { name: /una copia más/i })[0]);
    const pagar = screen.getByRole('button', { name: /pagar \$18\.000 · 3 copias/i });
    await u.click(pagar);
    expect(preparar).toHaveBeenCalledWith(
      'kit-1',
      'AB12-CD34',
      [
        { fotoId: 'g1', tamano: '15x21', cantidad: 2 },
        { fotoId: 'i1', tamano: '20x30', cantidad: 1 },
      ],
      { familia: 'f1', acceso: 'llave' },
      'mercadopago'
    );
    expect(preferencia).toHaveBeenCalledWith(expect.objectContaining({ pedidoId: 'p-extra', kitId: 'fotos-extra', tutorEmail: 'p@x.com' }));
    expect((await screen.findByRole('alert')).textContent).toContain('MP caído');
  });

  it('si el servidor rechaza el pedido, muestra el motivo y no va a la pasarela', async () => {
    preparar.mockResolvedValue({ success: false, error: 'Alguna de las fotos elegidas ya no está disponible.' });
    const u = userEvent.setup();
    montar();
    await u.click(screen.getByRole('button', { name: /elegir fotos extra/i }));
    await u.click(await screen.findByRole('button', { name: /^grupal/i }));
    await u.click(screen.getByRole('button', { name: /pagar/i }));
    expect((await screen.findByRole('alert')).textContent).toContain('ya no está disponible');
    expect(preferencia).not.toHaveBeenCalled();
  });
});

describe('ComprarFotosExtra: los 3 medios de pago, como el kit (29/10)', () => {
  const elegirGrupal = async (u: ReturnType<typeof userEvent.setup>) => {
    montar();
    await u.click(screen.getByRole('button', { name: /elegir fotos extra/i }));
    await u.click(await screen.findByRole('button', { name: /^grupal/i }));
  };

  it('por transferencia: pide la casilla de 48 h, registra el pedido y muestra los datos de la cuenta y la subida del comprobante', async () => {
    preparar.mockResolvedValue({ success: true, pedidoId: 'p-extra', pedidoFriendlyId: 'IFS-2026-9999', total: 5000 });
    const u = userEvent.setup();
    await elegirGrupal(u);
    await u.click(screen.getByRole('button', { name: /transferencia/i }));
    await u.click(screen.getByRole('button', { name: /confirmar por transferencia/i }));
    expect(preparar).not.toHaveBeenCalled();
    await u.click(screen.getByRole('checkbox'));
    await u.click(screen.getByRole('button', { name: /confirmar por transferencia/i }));
    expect(preparar).toHaveBeenCalledWith('kit-1', 'AB12-CD34', [{ fotoId: 'g1', tamano: '15x21', cantidad: 1 }], { familia: 'f1', acceso: 'llave' }, 'transferencia');
    expect(await screen.findByText('RETRATO.ESCOLAR')).toBeTruthy();
    expect(screen.getByText('Subir comprobante de IFS-2026-9999 (p-extra)')).toBeTruthy();
    expect(preferencia).not.toHaveBeenCalled();
    expect(intencionNave).not.toHaveBeenCalled();
  });

  it('con Nave: crea el pedido con «nave» y pide la intención de pago a Nave', async () => {
    const u = userEvent.setup();
    await elegirGrupal(u);
    await u.click(screen.getByRole('button', { name: /^nave/i }));
    await u.click(screen.getByRole('button', { name: /pagar \$5\.000/i }));
    expect(preparar).toHaveBeenLastCalledWith('kit-1', 'AB12-CD34', expect.any(Array), expect.any(Object), 'nave');
    expect(intencionNave).toHaveBeenCalledWith(expect.objectContaining({ pedidoId: 'p-extra', kitId: 'fotos-extra' }));
    expect((await screen.findByRole('alert')).textContent).toContain('Nave caído');
  });
});

describe('planilla de ensobrado de las fotos extra (laboratorio)', () => {
  it('una fila por foto y tamaño, con las copias y los archivos; CSV con «;» y BOM', () => {
    const base = { url: 'u', pedido: 'IFS-1', alumno: 'Juan Pérez', curso: '1AM', numeroLista: 7 };
    const csv = planillaEnsobrado([
      { ...base, carpeta: '20x30', nombre: '1AM_07_JUAN_IFS_1_F1_1de2.jpg', copia: 1, copias: 2 },
      { ...base, carpeta: '20x30', nombre: '1AM_07_JUAN_IFS_1_F1_2de2.jpg', copia: 2, copias: 2 },
      { ...base, carpeta: '15x21', nombre: '1AM_07_JUAN_IFS_1_F2_1de1.jpg', copia: 1, copias: 1, alumno: '=HACK()' },
    ]);
    expect(csv.startsWith('﻿Curso;')).toBe(true);
    const lineas = csv.trim().split('\r\n');
    expect(lineas).toHaveLength(3);
    expect(lineas[1]).toBe('1AM;7;Juan Pérez;IFS-1;20x30;2;1AM_07_JUAN_IFS_1_F1_1de2.jpg | 1AM_07_JUAN_IFS_1_F1_2de2.jpg;');
    // Un nombre que empieza con «=» no se ejecuta como fórmula en Excel.
    expect(lineas[2]).toContain(";'=HACK();");
  });
});
