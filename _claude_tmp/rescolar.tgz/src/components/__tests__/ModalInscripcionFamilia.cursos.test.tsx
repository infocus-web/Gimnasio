// 12/10/2026 (error real: una familia de Sala 4 eligió la división «Jornada Extendida», que en ese grado
// no existe): el formulario ofrece en División y Turno sólo los cursos de la nómina del grado elegido.
import { describe, expect, it, vi } from 'vitest';
import { render, screen, waitFor, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import ModalInscripcionFamilia from '../ModalInscripcionFamilia';

const COLEGIO = '11111111-1111-4111-8111-111111111111';
const JE = 'Jornada Extendida / Completa';

function servidorFalso() {
  const fetchFalso = vi.fn(async (url: string) => {
    const responder = (body: unknown) => new Response(JSON.stringify(body), { status: 200, headers: { 'Content-Type': 'application/json' } });
    if (url === '/api/colegios') {
      return responder({
        success: true,
        colegios: [{ id: COLEGIO, slug: 'colegio', nombre: 'Colegio de Prueba', localidad: 'Pilar', grados: ['Sala 4 años', '5° grado', '7° grado'], divisiones: ['A', 'B', 'C', 'Jornada Extendida'], turnos: ['Mañana', 'Tarde', JE] }],
      });
    }
    if (url === `/api/colegios/${COLEGIO}/cursos`) {
      return responder({
        success: true,
        cursos: [
          { grado: 'Sala 4 años', division: 'A', turno: 'Mañana' },
          { grado: 'Sala 4 años', division: 'A', turno: JE },
          { grado: 'Sala 4 años', division: 'B', turno: 'Tarde' },
          { grado: 'Sala 4 años', division: 'C', turno: JE },
          { grado: '5° grado', division: 'Jornada Extendida', turno: JE },
        ],
      });
    }
    return responder({ success: false });
  });
  vi.stubGlobal('fetch', fetchFalso);
  return fetchFalso;
}

const opciones = (select: HTMLElement) => within(select).getAllByRole('option').map((o) => o.textContent);

describe('inscripción: sólo cursos que existen en la nómina', () => {
  it('Sala 4 no ofrece la división «Jornada Extendida»; la B sólo tiene turno tarde (se elige solo)', async () => {
    servidorFalso();
    const user = userEvent.setup();
    render(<ModalInscripcionFamilia isOpen onClose={() => undefined} onInscripcionExitosa={() => undefined} />);

    const grado = await screen.findByDisplayValue('Elegí el grado o sala');
    await waitFor(() => expect(opciones(grado)).toContain('Sala 4 años'));
    const division = screen.getByDisplayValue('Elegí la división');
    const turno = screen.getByDisplayValue('Elegí el turno');

    await user.selectOptions(grado, 'Sala 4 años');
    await waitFor(() => expect(opciones(division)).toEqual(['Elegí la división', 'División A', 'División B', 'División C']));

    await user.selectOptions(division, 'B');
    await waitFor(() => expect((turno as HTMLSelectElement).value).toBe('Tarde'));
    expect(opciones(turno)).toEqual(['Elegí el turno', 'Tarde']);

    await user.selectOptions(division, 'A');
    await waitFor(() => expect(opciones(turno)).toEqual(['Elegí el turno', 'Mañana', JE]));
  });

  it('donde «Jornada Extendida» sí es división (5° grado) se ofrece; un grado sin nómina ofrece todo', async () => {
    servidorFalso();
    const user = userEvent.setup();
    render(<ModalInscripcionFamilia isOpen onClose={() => undefined} onInscripcionExitosa={() => undefined} />);
    const grado = await screen.findByDisplayValue('Elegí el grado o sala');
    await waitFor(() => expect(opciones(grado)).toContain('5° grado'));
    const division = screen.getByDisplayValue('Elegí la división');

    await user.selectOptions(grado, '5° grado');
    await waitFor(() => expect(opciones(division)).toEqual(['Elegí la división', 'Jornada Extendida']));
    await user.selectOptions(grado, '7° grado');
    await waitFor(() => expect(opciones(division)).toEqual(['Elegí la división', 'División A', 'División B', 'División C', 'Jornada Extendida']));
  });
});
