import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { beforeEach, describe, expect, it, vi } from 'vitest';
import ReimprimirPedidoLab from '../ReimprimirPedidoLab';

// Reimprimir un pedido (2/10): el laboratorio lo busca, elige fotos y motivo, y el pedido queda registrado.
const fila = {
  id: '00000000-0000-0000-0000-000000000009',
  pedido_friendly_id: 'IFS-2026-4266',
  created_at: '2026-09-27T10:00:00Z',
  colegio_id: 'c1',
  colegio_nombre: 'Instituto',
  curso_codigo: 'GRADO1-ATM',
  grado: '1° grado',
  division: 'A',
  turno: 'Mañana',
  alumno_nombre: 'Renato Delgado',
  alumno_numero_lista: 3,
  codigo_alumno: 'GRADO1_ATM_03_RENATO_DELGADO',
  tipo_kit: 'impreso_digital',
  kit_nombre: 'Kit Impreso + Digital',
  carpetas_impresas: 1,
  copias_extras: {},
  fotos_seleccionadas: { grupalId: 'f1', individualId: 'f2' },
  estado: 'entregado',
  estado_lab: 'entregado',
  seleccion_pendiente: false,
  lote_lab_id: 'l1',
};

describe('ReimprimirPedidoLab', () => {
  let llamadas: string[];
  beforeEach(() => {
    llamadas = [];
    localStorage.setItem('lab_token_v1', 'lab.1.2.3');
    global.fetch = vi.fn(async (url: RequestInfo | URL, init?: RequestInit) => {
      const u = String(url);
      llamadas.push(`${init?.method || 'GET'} ${u}`);
      if (u.startsWith('/api/lab/buscar'))
        return {
          ok: true,
          status: 200,
          json: async () => ({
            success: true,
            pedidos: [fila],
            fotos: [
              { id: 'f1', categoria: 'grupal', alumno_nombre: null, thumb_path: 't1' },
              { id: 'f2', categoria: 'individual', alumno_nombre: 'Renato Delgado', thumb_path: 't2' },
            ],
            reimpresiones: [],
          }),
        } as Response;
      if (u.includes('/reimpresion')) return { ok: false, status: 500, json: async () => ({ success: false, error: 'Falla de prueba' }) } as Response;
      return { ok: false, status: 404, json: async () => ({}) } as Response;
    }) as unknown as typeof fetch;
  });

  it('busca por número, muestra las fotos y exige motivo antes de descargar', async () => {
    render(<ReimprimirPedidoLab estructura="por_alumno" onError={() => {}} onAviso={() => {}} />);
    await userEvent.type(screen.getByPlaceholderText(/número de pedido/i), '4266');
    await userEvent.click(screen.getByRole('button', { name: /buscar/i }));
    expect(await screen.findByText('Renato Delgado')).toBeInTheDocument();
    expect(llamadas.some((l) => l.startsWith('GET /api/lab/buscar?q=4266'))).toBe(true);
    const descargar = screen.getByRole('button', { name: /descargar zip de reimpresión/i });
    expect(descargar).toBeDisabled(); // falta el motivo
    await userEvent.click(screen.getByRole('button', { name: /salió mal la impresión/i }));
    expect(descargar).toBeEnabled();
    await userEvent.click(descargar);
    expect(await screen.findByText('Falla de prueba')).toBeInTheDocument();
    expect(llamadas.some((l) => l.startsWith('POST /api/lab/pedidos/00000000-0000-0000-0000-000000000009/reimpresion'))).toBe(true);
  });
});
