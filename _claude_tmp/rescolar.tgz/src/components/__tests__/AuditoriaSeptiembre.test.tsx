import { render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { afterEach, describe, expect, it, vi } from 'vitest';

import { fuenteServidor } from '../../test/fuenteServidor';
import FaqSection from '../FaqSection';
import AdminCancelacionesTab from '../AdminCancelacionesTab';
import { KITS_DISPONIBLES } from '../../data/colegiosData';
import { KITS_RESERVA } from '../../services/reservasService';

// Auditoría 28/9: precios en un solo lugar, FAQ sin eventos, cancelaciones desde el panel y galería por familia.
vi.mock('../../services/adminAuthService', () => ({
  fetchAdminAutenticado: (url: string, init?: RequestInit) => fetch(url, init),
}));

afterEach(() => {
  vi.unstubAllGlobals();
  vi.resetModules();
});

describe('Precios en un solo lugar', () => {
  it('los precios del servidor se aplican al catálogo, a la reserva y al FAQ', async () => {
    vi.stubGlobal('fetch', vi.fn(async () => new Response(JSON.stringify({ success: true, precios: { kitClasico: 33000, kitDigital: 17000, carpetaExtra: 16000, fotoEvento: 6000 } }))));
    const { cargarPrecios, PRECIOS } = await import('../../services/preciosService');
    await cargarPrecios();
    expect(PRECIOS.kitClasico).toBe(33000);
    const kits = (await import('../../data/colegiosData')).KITS_DISPONIBLES;
    expect(kits.find((k) => k.id === 'kit-digital')?.precio).toBe(17000);
    const reserva = (await import('../../services/reservasService')).KITS_RESERVA;
    expect(reserva.find((k) => k.id === 'kit-clasico')?.precio).toBe(33000);
  });

  it('el FAQ no ofrece galerías de eventos y muestra el precio vigente', () => {
    render(<FaqSection />);
    expect(screen.queryByText(/sueltas de actos/i)).not.toBeInTheDocument();
    expect(screen.getByText('Toqué "Pagar" y no avanzó, ¿qué hago?')).toBeInTheDocument();
    expect(KITS_DISPONIBLES.length).toBeGreaterThan(0);
    expect(KITS_RESERVA.length).toBe(2);
  });

  it('el servidor lee los precios de un solo lugar y los usa en la IA', () => {
    const server = fuenteServidor();
    expect(server).toContain("app.get('/api/precios'");
    expect(server).toContain('function contextoNegocioConsultas(eventoHermanos = \'\'): string');
    expect(server).not.toContain('CONTEXTO_NEGOCIO_CONSULTAS');
    expect(server).not.toMatch(/Kit Impreso \+ Digital \(\$30\.000\)/);
  });
});

describe('Galería por familia', () => {
  it('el servidor filtra las fotos individuales según la llave de la familia', () => {
    const server = fuenteServidor();
    expect(server).toContain('hijosDeFamiliaConAcceso(supabase, req.query.familia, req.query.acceso)');
    expect(server).toContain('acceso_galeria: tokenAccesoGaleria(fila?.id)');
  });
});

describe('Cancelaciones en el panel', () => {
  it('lista las pendientes y aprueba con devolución por Mercado Pago', async () => {
    const solicitud = {
      id: 's1',
      created_at: new Date().toISOString(),
      codigo: 'ARR-2026-AAA111',
      pedido_ref: 'IFS-2026-1234',
      nombre: 'Ana Pérez',
      email: 'ana@x.com',
      motivo: null,
      estado: 'nueva',
      nota_admin: null,
      atendida_at: null,
      pedidos: {
        id: 'p1',
        pedido_friendly_id: 'IFS-2026-1234',
        estado: 'pagado',
        total: 15000,
        metodo_pago: 'mercadopago',
        mp_payment_id: '999',
        kit_nombre: 'Solo Digital HD',
        alumno_nombre: 'Sofi',
        colegio_nombre: 'Colegio',
        seleccion_pendiente: true,
        email_enviado: false,
        created_at: new Date().toISOString(),
      },
    };
    const fetchMock = vi.fn(async (url: string) =>
      url.endsWith('/resolver')
        ? new Response(JSON.stringify({ success: true, devolucion: { hecha: true, monto: 15000 } }))
        : new Response(JSON.stringify({ success: true, solicitudes: [solicitud] }))
    );
    vi.stubGlobal('fetch', fetchMock);
    vi.spyOn(window, 'confirm').mockReturnValue(true);
    render(<AdminCancelacionesTab />);
    expect(await screen.findByText('ARR-2026-AAA111')).toBeInTheDocument();
    expect(screen.getByText('Corresponde devolver el total')).toBeInTheDocument();
    await userEvent.click(screen.getByRole('button', { name: /aprobar y devolver por mercado pago/i }));
    await waitFor(() => expect(fetchMock.mock.calls.some(([u]) => String(u).endsWith('/api/admin/cancelaciones/s1/resolver'))).toBe(true));
    const [, init] = fetchMock.mock.calls.find(([u]) => String(u).endsWith('/resolver')) as unknown as [string, RequestInit];
    expect(JSON.parse(String(init.body))).toMatchObject({ accion: 'aprobar', devolverPorMercadoPago: true });
  });

  it('no deja rechazar sin escribir el motivo', async () => {
    const fetchMock = vi.fn(async () =>
      new Response(JSON.stringify({ success: true, solicitudes: [{ id: 's2', created_at: new Date().toISOString(), codigo: 'ARR-2026-BBB222', pedido_ref: 'X', nombre: 'B', email: 'b@x.com', motivo: null, estado: 'nueva', nota_admin: null, atendida_at: null, pedidos: null }] }))
    );
    vi.stubGlobal('fetch', fetchMock);
    render(<AdminCancelacionesTab />);
    await userEvent.click(await screen.findByRole('button', { name: /rechazar con motivo/i }));
    expect(screen.getByText(/escribí el motivo/i)).toBeInTheDocument();
    // 14/10: además de la lista se pide el borrador de las notas; lo que importa es que no se resolvió nada.
    expect((fetchMock.mock.calls as unknown as [string][]).filter(([u]) => !String(u).includes('/api/admin/borradores/'))).toHaveLength(1);
  });
});
