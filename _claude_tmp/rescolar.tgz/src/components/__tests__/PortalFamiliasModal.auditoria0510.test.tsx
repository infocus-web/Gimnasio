import { render, screen, waitFor, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import PortalFamiliasModal from '../PortalFamiliasModal';
import { familiaActivaMellizos, mockearFetchFamiliaYGaleria } from '../../test/fixtures/familiaMellizos';

// Auditoría 05/10 — portal de familias: bugs 1, 3, 4 y 6 (regresión).

type Implementacion = (input: RequestInfo | URL, init?: RequestInit) => Promise<Response>;

function json(status: number, cuerpo: unknown): Response {
  return { ok: status >= 200 && status < 300, status, json: async () => cuerpo } as Response;
}
function urlDe(input: RequestInfo | URL) {
  return typeof input === 'string' ? input : input.toString();
}
function sobreescribirFetch(coincide: (url: string, init?: RequestInit) => boolean, respuesta: (url: string, init?: RequestInit) => Response) {
  const fetchBase = global.fetch as unknown as ReturnType<typeof vi.fn>;
  const base = fetchBase.getMockImplementation() as Implementacion | undefined;
  fetchBase.mockImplementation(async (input: RequestInfo | URL, init?: RequestInit) => {
    const url = urlDe(input);
    if (coincide(url, init)) return respuesta(url, init);
    return base ? base(input, init) : json(404, { success: false });
  });
}
function llamadas(fragmento: string) {
  const fetchBase = global.fetch as unknown as ReturnType<typeof vi.fn>;
  return fetchBase.mock.calls.filter((c) => urlDe(c[0] as RequestInfo).includes(fragmento));
}

async function elegirFoto(user: ReturnType<typeof userEvent.setup>, categoria: 'grupal' | 'individual' | 'docente', titulo: RegExp) {
  const slotLabels: Record<typeof categoria, RegExp> = {
    grupal: /^1\/3 grupal$/i,
    individual: /^2\/3 retrato$/i,
    docente: /^3\/3 con seño$/i,
  };
  const slot = screen.getByText(slotLabels[categoria]).closest('div')!.parentElement!;
  await user.click(slot);
  const tarjeta = (await screen.findAllByText(titulo))[0].closest('div.relative')!;
  await user.click(within(tarjeta as HTMLElement).getByRole('button', { name: /^elegir$/i }));
}
async function elegirLasTres(user: ReturnType<typeof userEvent.setup>) {
  await elegirFoto(user, 'grupal', /foto grupal/i);
  await elegirFoto(user, 'individual', /foto individual/i);
  await elegirFoto(user, 'docente', /foto.*seño|foto docente/i);
}
const grupo = () => screen.getByRole('group', { name: /tus hijos\/as en este colegio/i });
async function cambiarAHijo(user: ReturnType<typeof userEvent.setup>, nombre: string) {
  await user.click(within(grupo()).getByRole('button', { name: new RegExp(nombre, 'i') }));
}

afterEach(() => {
  window.history.replaceState(null, '', '/');
});

describe('hermanos (auditoría 05/10)', () => {
  beforeEach(() => {
    localStorage.setItem('infocus_familia_activa_v1', JSON.stringify(familiaActivaMellizos));
    mockearFetchFamiliaYGaleria();
    sobreescribirFetch((url) => url.includes('/api/pedidos/existente'), () => json(200, { success: true, existe: false }));
    // 11/10 (POR-5): el Paso 4 sólo deja pagar con los precios del servidor cargados.
    sobreescribirFetch((url) => url.includes('/api/precios'), () => json(200, { success: true, precios: { kitClasico: 30000, kitDigital: 15000, carpetaExtra: 15000, fotoEvento: 5000 } }));
  });

  async function abrirGaleria() {
    const user = userEvent.setup();
    const vista = render(<PortalFamiliasModal isOpen={true} onClose={() => {}} />);
    await user.click(await screen.findByRole('button', { name: /abrir galería de fotos/i }));
    await screen.findByRole('group', { name: /tus hijos\/as en este colegio/i });
    return { user, vista };
  }

  it('bug 1: cerrar y reabrir el portal con un hermano activo no mezcla la identidad del hijo', async () => {
    sobreescribirFetch((url) => url.includes('/api/pedidos/crear-multiple'), () => json(500, { success: false, error: 'se cortó' }));
    const { user, vista } = await abrirGaleria();
    await cambiarAHijo(user, 'Sofia');
    await elegirLasTres(user);

    // Se cierra y se reabre el portal (App.tsx lo deja montado): Sofia tiene que seguir activa.
    vista.rerender(<PortalFamiliasModal isOpen={false} onClose={() => {}} />);
    vista.rerender(<PortalFamiliasModal isOpen={true} onClose={() => {}} />);
    await screen.findByRole('group', { name: /tus hijos\/as en este colegio/i });
    // Antes: el efecto de apertura volvía a poner "Pablo Alder" como nombre con Sofia todavía activa.
    const botonSofia = within(grupo()).getByRole('button', { name: /sofia/i });
    expect(botonSofia).toHaveAttribute('aria-pressed', 'true'); // 25/10: el activo se marca con aria-pressed (antes, color ámbar)
    expect(within(botonSofia).getByText(/3 fotos elegidas/i)).toBeInTheDocument();

    await cambiarAHijo(user, 'Pablo');
    await elegirLasTres(user);
    await user.click(screen.getByRole('button', { name: /elegir kit y formato/i }));
    await user.click(await screen.findByRole('button', { name: /ir a datos y pago/i }));
    // El desglose del Paso 4 muestra a los DOS hermanos (antes: "Pablo Alder" dos veces y Sofia no aparecía).
    expect(screen.getAllByText('Sofia Alder').length).toBeGreaterThan(0);
    await user.click(screen.getByRole('checkbox', { name: /leí y acepto/i }));
    await user.click(document.getElementById('btn-confirmar-pagar') as HTMLElement);
    await waitFor(() => expect(llamadas('/api/pedidos/crear-multiple')).toHaveLength(1));
    const cuerpo = JSON.parse(String((llamadas('/api/pedidos/crear-multiple')[0][1] as RequestInit).body));
    expect(cuerpo.items.map((it: { alumnoNombre: string }) => it.alumnoNombre).sort()).toEqual(['Pablo Alder', 'Sofia Alder']);
  });

  it('bug 4: después de "Confirmar mis fotos" de una reserva pagada no vuelve a ofrecer "Elegir Kit y Formato"', async () => {
    let confirmaciones = 0;
    sobreescribirFetch(
      (url) => url.includes('/api/reservas/pendiente') && decodeURIComponent(url).includes('Pablo'),
      () => json(200, { success: true, fotosDisponibles: true, tienePedidoPagado: confirmaciones > 0, reserva: confirmaciones > 0 ? null : { id: 'reserva-1', pedidoFriendlyId: 'IFS-2026-7777', kitNombre: 'Kit Impreso + Digital', total: 30000, pagada: true } })
    );
    sobreescribirFetch(
      (url) => url.includes('/api/reservas/reserva-1/elegir-fotos'),
      () => {
        confirmaciones += 1;
        // bug 9: la segunda confirmación responde 409 "ya fueron elegidas".
        return confirmaciones === 1 ? json(200, { success: true, pedidoFriendlyId: 'IFS-2026-7777' }) : json(409, { success: false, error: 'Las fotos de este kit ya fueron elegidas.' });
      }
    );
    const { user } = await abrirGaleria();
    expect(await screen.findByText(/ya pagaste el kit impreso \+ digital de pablo alder/i)).toBeInTheDocument();
    await elegirLasTres(user);
    await user.click(document.getElementById('chk-confirma-personalizacion') as HTMLElement);
    await user.click(screen.getByRole('button', { name: /confirmar mis fotos/i }));
    expect(await screen.findByText(/guardamos tus fotos del pedido IFS-2026-7777/i)).toBeInTheDocument();
    // Antes: al limpiar `reservaActiva` reaparecía "Elegir Kit y Formato" y se podía pagar otra vez.
    expect(screen.queryByRole('button', { name: /elegir kit y formato/i })).not.toBeInTheDocument();
    expect(screen.queryByRole('button', { name: /confirmar mis fotos/i })).not.toBeInTheDocument();
    expect(screen.getByRole('button', { name: /fotos confirmadas · ver mi pedido/i })).toBeInTheDocument();
    // Se volvió a consultar el estado del hijo (ahora con pedido pagado).
    await waitFor(() => expect(llamadas('/api/reservas/pendiente').filter((c) => decodeURIComponent(urlDe(c[0] as RequestInfo)).includes('Pablo')).length).toBeGreaterThan(1));
    expect(screen.getByText(/guardamos tus fotos del pedido IFS-2026-7777/i)).toBeInTheDocument();
    expect(screen.queryByRole('button', { name: /elegir kit y formato/i })).not.toBeInTheDocument();
    expect(llamadas('/api/pedidos/crear')).toHaveLength(0);
  });

  it('bug 6: el hermano con kit pagado que eligió sus 3 fotos sin confirmar frena la compra del otro hijo', async () => {
    sobreescribirFetch(
      (url) => url.includes('/api/reservas/pendiente') && decodeURIComponent(url).includes('Sofia'),
      () => json(200, { success: true, fotosDisponibles: true, tienePedidoPagado: false, reserva: { id: 'reserva-sofia', pedidoFriendlyId: 'IFS-2026-8888', kitNombre: 'Kit Impreso + Digital', total: 30000, pagada: true } })
    );
    sobreescribirFetch((url) => url.includes('/api/reservas/reserva-sofia/elegir-fotos'), () => json(200, { success: true, pedidoFriendlyId: 'IFS-2026-8888' }));
    sobreescribirFetch((url) => url.includes('/api/pedidos/crear'), () => json(500, { success: false, error: 'no debería llamarse' }));
    const { user } = await abrirGaleria();
    // Sofia (kit pagado): elige las 3 fotos pero NO toca "Confirmar mis fotos" y cambia de hijo.
    await cambiarAHijo(user, 'Sofia');
    expect(await screen.findByText(/ya pagaste el kit impreso \+ digital de sofia alder/i)).toBeInTheDocument();
    await elegirLasTres(user);
    await cambiarAHijo(user, 'Pablo');
    await elegirLasTres(user);
    await user.click(screen.getByRole('button', { name: /elegir kit y formato/i }));
    // Antes: pasaba al kit, se pagaba a Pablo y la elección de Sofia se borraba sin llegar al servidor.
    expect(await screen.findByText(/confirmá primero las fotos de sofia alder/i)).toBeInTheDocument();
    expect(screen.queryByText(/elegí tu kit fotográfico/i)).not.toBeInTheDocument();
    // Lo llevó a Sofia, con sus fotos restauradas y el botón de confirmar listo.
    expect(within(grupo()).getByRole('button', { name: /sofia/i })).toHaveAttribute('aria-pressed', 'true');
    expect(await screen.findByRole('button', { name: /confirmar mis fotos/i })).toBeInTheDocument();
    await user.click(document.getElementById('chk-confirma-personalizacion') as HTMLElement);
    await user.click(screen.getByRole('button', { name: /confirmar mis fotos/i }));
    expect(await screen.findByText(/guardamos tus fotos del pedido IFS-2026-8888/i)).toBeInTheDocument();
    expect(llamadas('/api/reservas/reserva-sofia/elegir-fotos')).toHaveLength(1);
    // Confirmadas las de Sofia, Pablo sí puede seguir al kit.
    await cambiarAHijo(user, 'Pablo');
    await user.click(await screen.findByRole('button', { name: /elegir kit y formato/i }));
    expect(await screen.findByText(/elegí tu kit fotográfico/i)).toBeInTheDocument();
    expect(llamadas('/api/pedidos/crear')).toHaveLength(0);
  });
});

describe('volver de Nave (bug 3, auditoría 05/10)', () => {
  it('nave_status=vuelta: espera la confirmación del servidor, no genera otro link de Nave ni ofrece pagar de nuevo', async () => {
    window.history.replaceState(null, '', '/?nave_status=vuelta&pedido_id=pedido-9');
    localStorage.setItem(
      'infocus_pedidos_escolares_v1',
      JSON.stringify([{ id: 'IFS-2026-0009', supabaseId: 'pedido-9', metodoPago: 'nave', estadoPago: 'pendiente', total: 30000, alumnoNombre: 'Pablo Alder', kitId: 'kit-clasico', kitNombre: 'Kit', tutorEmail: 'a@b.com' }])
    );
    sobreescribirFetch(
      (url) => url.includes('/api/pedidos/pedido-9/status'),
      () => json(200, { success: true, estadoPago: 'pendiente', total: 30000, metodoPago: 'nave' })
    );
    sobreescribirFetch((url) => url.includes('/api/nave/crear-intencion'), () => json(200, { success: true, checkoutUrl: 'https://nave.test/pagar' }));
    const user = userEvent.setup();
    render(<PortalFamiliasModal isOpen={true} onClose={() => {}} />);
    expect((await screen.findAllByText(/estamos confirmando tu pago/i)).length).toBeGreaterThan(0);
    await waitFor(() => expect(llamadas('/api/pedidos/pedido-9/status').length).toBeGreaterThan(0));
    // Antes: se regeneraba el link de Nave solo y se ofrecían los otros medios de pago.
    expect(llamadas('/api/nave/crear-intencion')).toHaveLength(0);
    expect(screen.queryByText(/todavía no completaste el pago/i)).not.toBeInTheDocument();
    expect(screen.queryByRole('button', { name: /pagar con transferencia/i })).not.toBeInTheDocument();

    // Pagar de otra forma sigue siendo posible, pero sólo con confirmación explícita.
    await user.click(screen.getByRole('button', { name: /quiero pagar de otra forma/i }));
    await user.click(screen.getByRole('button', { name: /sí, quiero pagar de otra forma/i }));
    await waitFor(() => expect(llamadas('/api/nave/crear-intencion').length).toBeGreaterThan(0));
    expect(await screen.findByRole('button', { name: /pagar con transferencia/i })).toBeInTheDocument();
  });
});
