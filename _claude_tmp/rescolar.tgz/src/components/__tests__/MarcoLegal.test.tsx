import { act, render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { readFileSync } from 'fs';
import path from 'path';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { fuenteServidor } from '../../test/fuenteServidor';
import ReservaKitAnticipada from '../ReservaKitAnticipada';
import LegalModal from '../legal/LegalModal';
import { abrirLegal, datosAceptacion, marcarTerminosAceptados } from '../../legal/aceptacion';
import { VERSION_TERMINOS } from '../../legal/textosLegales';
import { CONSENTIMIENTOS_VACIOS, faltanConsentimientosObligatorios } from '../legal/ConsentimientosInscripcion';

// Marco legal (27/9): casilla obligatoria antes de pagar, Botón de arrepentimiento y consentimientos.
vi.mock('../../services/reservasService', async (original) => {
  const real = await original<typeof import('../../services/reservasService')>();
  return {
    ...real,
    obtenerEstadoReserva: vi.fn(async () => ({ ok: true, reserva: null, fotosDisponibles: false, tienePedidoPagado: false })),
    crearReserva: vi.fn(async () => ({ success: true, grupoPagoId: 'g1', total: 15000, pedidoFriendlyIds: ['IFS-2026-1111'] })),
  };
});
vi.mock('../../services/mediosPagoService', () => ({ useNaveHabilitado: () => false }));

describe('Marco legal', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    marcarTerminosAceptados(false);
  });
  afterEach(() => vi.unstubAllGlobals());

  it('la versión de los términos del sitio y del servidor coinciden', () => {
    const server = fuenteServidor();
    const version = server.match(/const VERSION_TERMINOS_SERVIDOR = '([^']+)'/)?.[1];
    expect(version).toBe(VERSION_TERMINOS);
  });

  it('sólo manda la aceptación al servidor si se tildó la casilla', () => {
    expect(datosAceptacion()).toEqual({});
    marcarTerminosAceptados(true);
    expect(datosAceptacion()).toEqual({ aceptaTerminos: true, versionTerminos: VERSION_TERMINOS });
  });

  it('no deja pagar la reserva sin tildar "Leí y acepto" y avisa qué falta', async () => {
    const { crearReserva } = await import('../../services/reservasService');
    render(<ReservaKitAnticipada hijos={[{ id: 's', nombreCompleto: 'Sofia', codigoSeccion: 'BBBB-2222' }]} tutorNombre="Pablo" tutorEmail="p@x.com" />);
    await userEvent.click(await screen.findByText('Solo Digital HD'));
    await userEvent.click(screen.getByRole('button', { name: /transferencia/i }));
    const pagar = screen.getByRole('button', { name: /pagar reserva/i });
    expect(screen.getByText(/todavía no elegiste las fotos, sí: tenés 10 días corridos/i)).toBeInTheDocument();
    // Sin tildar: el botón responde y avisa qué falta (antes quedaba gris y parecía roto).
    await userEvent.click(pagar);
    expect(await screen.findByText('Tildá esta casilla para continuar con el pago.')).toBeInTheDocument();
    expect(crearReserva).not.toHaveBeenCalled();
    await userEvent.click(screen.getByRole('checkbox', { name: /leí y acepto/i }));
    // Por transferencia también hay que tildar el plazo de 48 hs para el comprobante (29/9).
    expect(screen.getByText(/tenés 48 horas para subir el comprobante/i)).toBeInTheDocument();
    await userEvent.click(pagar);
    expect(await screen.findByText('Tildá esta casilla para confirmar el pedido por transferencia.')).toBeInTheDocument();
    expect(crearReserva).not.toHaveBeenCalled();
    await userEvent.click(screen.getByRole('checkbox', { name: /el pedido se cancela/i }));
    await userEvent.click(pagar);
    await waitFor(() => expect(crearReserva).toHaveBeenCalledTimes(1));
    expect(datosAceptacion()).toMatchObject({ aceptaTerminos: true });
  });

  it('el Botón de arrepentimiento registra la solicitud y muestra el código', async () => {
    const fetchMock = vi.fn(async () => new Response(JSON.stringify({ success: true, codigo: 'ARR-2026-ABC123', pedidoEncontrado: true }), { status: 201 }));
    vi.stubGlobal('fetch', fetchMock);
    render(<LegalModal />);
    act(() => abrirLegal('arrepentimiento'));
    await userEvent.type(screen.getByPlaceholderText('IFS-2026-1234'), 'IFS-2026-1234');
    await userEvent.type(screen.getByLabelText(/nombre y apellido/i), 'Ana Pérez');
    await userEvent.type(screen.getByLabelText(/email con el que compraste/i), 'ana@x.com');
    await userEvent.click(screen.getByRole('button', { name: /enviar solicitud de cancelación/i }));
    expect(await screen.findByText('ARR-2026-ABC123')).toBeInTheDocument();
    const [url, init] = fetchMock.mock.calls[0] as unknown as [string, RequestInit];
    expect(url).toBe('/api/arrepentimiento');
    expect(JSON.parse(String(init.body))).toMatchObject({ pedido: 'IFS-2026-1234', email: 'ana@x.com' });
  });

  it('muestra los términos con el derecho de arrepentimiento y la política de cambios', async () => {
    render(<LegalModal />);
    act(() => abrirLegal('terminos'));
    expect(screen.getByText('5. Cancelación de la compra')).toBeInTheDocument();
    expect(screen.getByText('6. Cambios de kit')).toBeInTheDocument();
  });

  it('las tres autorizaciones de la inscripción son obligatorias y la promocional no', () => {
    expect(faltanConsentimientosObligatorios(CONSENTIMIENTOS_VACIOS)).toBe(true);
    expect(faltanConsentimientosObligatorios({ toma: true, grupal: true, transferencia: true, promocional: false })).toBe(false);
    expect(faltanConsentimientosObligatorios({ toma: true, grupal: false, transferencia: true, promocional: true })).toBe(true);
  });
});

describe('Convenio con el colegio', () => {
  it('la versión del convenio de la página y del servidor coinciden', () => {
    const server = fuenteServidor();
    const html = readFileSync(path.resolve(__dirname, '../../../public/convenio.html'), 'utf8');
    expect(html.match(/const VERSION_CONVENIO = '([^']+)'/)?.[1]).toBe(server.match(/const VERSION_CONVENIO_SERVIDOR = '([^']+)'/)?.[1]);
  });
});

describe('Registro de fallas al pagar', () => {
  it('manda la falla al servidor una sola vez por mensaje y paso', async () => {
    const fetchMock = vi.fn(async () => new Response(JSON.stringify({ success: true, codigo: 'ERR-1' }), { status: 201 }));
    vi.stubGlobal('fetch', fetchMock);
    const { registrarFallaDePago } = await import('../../services/reporteErrores');
    registrarFallaDePago('prueba', 'No se pudo iniciar el pago', { email: 'a@b.com' });
    registrarFallaDePago('prueba', 'No se pudo iniciar el pago', { email: 'a@b.com' });
    await waitFor(() => expect(fetchMock).toHaveBeenCalledTimes(1));
    const [url, init] = fetchMock.mock.calls[0] as unknown as [string, RequestInit];
    expect(url).toBe('/api/errores/reportar');
    expect(JSON.parse(String(init.body))).toMatchObject({ email: 'a@b.com', detalle: { tipo: 'pago_fallido', paso: 'prueba' } });
    vi.unstubAllGlobals();
  });
});
