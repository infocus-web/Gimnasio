import { render, screen, waitFor, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import PortalFamiliasModal from '../PortalFamiliasModal';
import { familiaActivaMellizos, mockearFetchFamiliaYGaleria } from '../../test/fixtures/familiaMellizos';

// Auditoría 03/10 noche — portal de familias (equipo PORTAL).

type Implementacion = (input: RequestInfo | URL, init?: RequestInit) => Promise<Response>;

function json(status: number, cuerpo: unknown): Response {
  return { ok: status >= 200 && status < 300, status, json: async () => cuerpo } as Response;
}
function urlDe(input: RequestInfo | URL) {
  return typeof input === 'string' ? input : input.toString();
}
/** Agrega una ruta al fetch mockeado, manteniendo las anteriores. */
function sobreescribirFetch(coincide: (url: string, init?: RequestInit) => boolean, respuesta: (url: string, init?: RequestInit) => Response) {
  const fetchBase = global.fetch as unknown as ReturnType<typeof vi.fn>;
  const base = fetchBase.getMockImplementation() as Implementacion | undefined;
  fetchBase.mockImplementation(async (input: RequestInfo | URL, init?: RequestInit) => {
    const url = urlDe(input);
    if (coincide(url, init)) return respuesta(url, init);
    return base ? base(input, init) : json(404, { success: false });
  });
}
function llamadas(fragmento: string) {
  const fetchBase = global.fetch as unknown as ReturnType<typeof vi.fn>;
  return fetchBase.mock.calls.filter((c) => urlDe(c[0] as RequestInfo).includes(fragmento));
}

async function elegirFoto(user: ReturnType<typeof userEvent.setup>, categoria: 'grupal' | 'individual' | 'docente', titulo: RegExp) {
  const slotLabels: Record<typeof categoria, RegExp> = {
    grupal: /^1\/3 grupal$/i,
    individual: /^2\/3 retrato$/i,
    docente: /^3\/3 con seño$/i,
  };
  const slot = screen.getByText(slotLabels[categoria]).closest('div')!.parentElement!;
  await user.click(slot);
  const tarjeta = (await screen.findAllByText(titulo))[0].closest('div.relative')!;
  await user.click(within(tarjeta as HTMLElement).getByRole('button', { name: /^elegir$/i }));
}

afterEach(() => {
  window.history.replaceState(null, '', '/');
});

describe('volver de Mercado Pago (M9a/R6 y M9b/R7)', () => {
  beforeEach(() => {
    (global.fetch as unknown as ReturnType<typeof vi.fn>).mockImplementation(async () => json(404, { success: false }));
  });

  it('mp_status=approved NO muestra "¡Pago Aprobado!" si el servidor dice pendiente, y usa el total del servidor', async () => {
    window.history.replaceState(null, '', '/?mp_status=approved&pedido_id=pedido-1');
    // Copia local con un total "inflado": se tiene que ver el del servidor.
    localStorage.setItem(
      'infocus_pedidos_escolares_v1',
      JSON.stringify([{ id: 'IFS-2026-1111', supabaseId: 'pedido-1', total: 99999, metodoPago: 'mercadopago', estadoPago: 'pendiente', kitNombre: 'Kit', archivosParaLaboratorio: [] }])
    );
    sobreescribirFetch(
      (url) => url.includes('/api/pedidos/pedido-1/status'),
      () => json(200, { success: true, estadoPago: 'pendiente', total: 30000, metodoPago: 'mercadopago' })
    );
    render(<PortalFamiliasModal isOpen={true} onClose={() => {}} />);
    expect((await screen.findAllByText(/estamos confirmando tu pago/i)).length).toBeGreaterThan(0);
    await waitFor(() => expect(llamadas('/api/pedidos/pedido-1/status').length).toBeGreaterThan(0));
    expect(screen.queryByText(/pago aprobado con éxito/i)).not.toBeInTheDocument();
    await waitFor(() => expect(screen.getByText(/\$30\.000/)).toBeInTheDocument());
    expect(screen.queryByText(/99\.999/)).not.toBeInTheDocument();
    // No se genera un link nuevo solo (no hay que volver a pagar).
    expect(llamadas('/api/mercadopago/crear-preferencia')).toHaveLength(0);
  });

  it('sin el pedido guardado en este navegador (respaldo), mp_status=approved tampoco alcanza para "aprobado"', async () => {
    window.history.replaceState(null, '', '/?mp_status=approved&pedido_id=pedido-9');
    sobreescribirFetch(
      (url) => url.includes('/api/pedidos/pedido-9/status'),
      () => json(200, { success: true, estadoPago: 'pendiente', total: 15000, metodoPago: 'mercadopago' })
    );
    render(<PortalFamiliasModal isOpen={true} onClose={() => {}} />);
    expect((await screen.findAllByText(/estamos confirmando tu pago/i)).length).toBeGreaterThan(0);
    await waitFor(() => expect(llamadas('/api/pedidos/pedido-9/status').length).toBeGreaterThan(0));
    await waitFor(() => expect(screen.getByText(/\$15\.000/)).toBeInTheDocument());
    expect(screen.queryByText(/pago aprobado con éxito/i)).not.toBeInTheDocument();
    expect(screen.queryByText(/^aprobado$/i)).not.toBeInTheDocument();
  });

  it('muestra "aprobado" recién cuando lo dice el servidor', async () => {
    window.history.replaceState(null, '', '/?mp_status=approved&pedido_id=pedido-2');
    sobreescribirFetch(
      (url) => url.includes('/api/pedidos/pedido-2/status'),
      () => json(200, { success: true, estadoPago: 'aprobado', total: 15000, metodoPago: 'mercadopago' })
    );
    render(<PortalFamiliasModal isOpen={true} onClose={() => {}} />);
    expect(await screen.findByText(/pago aprobado con éxito/i)).toBeInTheDocument();
  });

  it('mp_status=pending: avisa del pago en proceso, no genera un link solo y pide confirmación para pagar de otra forma', async () => {
    window.history.replaceState(null, '', '/?mp_status=pending&pedido_id=pedido-3');
    sobreescribirFetch(
      (url) => url.includes('/api/pedidos/pedido-3/status'),
      () => json(200, { success: true, estadoPago: 'pendiente', total: 30000, metodoPago: 'mercadopago' })
    );
    sobreescribirFetch(
      (url) => url.includes('/api/mercadopago/crear-preferencia'),
      () => json(200, { success: true, initPoint: 'https://mp.test/pagar' })
    );
    const user = userEvent.setup();
    render(<PortalFamiliasModal isOpen={true} onClose={() => {}} />);
    expect((await screen.findAllByText(/tenés un pago en proceso/i)).length).toBeGreaterThan(0);
    expect(screen.queryByText(/todavía no completaste el pago/i)).not.toBeInTheDocument();
    await waitFor(() => expect(llamadas('/api/pedidos/pedido-3/status').length).toBeGreaterThan(0));
    expect(llamadas('/api/mercadopago/crear-preferencia')).toHaveLength(0);
    expect(screen.queryByRole('button', { name: /pagar con transferencia/i })).not.toBeInTheDocument();

    // Pagar de otra forma exige una confirmación explícita.
    await user.click(screen.getByRole('button', { name: /quiero pagar de otra forma/i }));
    expect(llamadas('/api/mercadopago/crear-preferencia')).toHaveLength(0);
    await user.click(screen.getByRole('button', { name: /sí, quiero pagar de otra forma/i }));
    await waitFor(() => expect(llamadas('/api/mercadopago/crear-preferencia').length).toBeGreaterThan(0));
    expect(await screen.findByRole('button', { name: /pagar con transferencia/i })).toBeInTheDocument();
  });
});

describe('ingreso (contratos 2 y 3)', () => {
  beforeEach(() => {
    (global.fetch as unknown as ReturnType<typeof vi.fn>).mockImplementation(async () => json(404, { success: false }));
  });

  it('confirmar-acceso por URL: NO llama solo; pide el DNI, confirma, precarga el código y saca el parámetro', async () => {
    window.history.replaceState(null, '', '/?confirmar-acceso=insc-9.token-secreto');
    sobreescribirFetch(
      (url) => url.includes('/api/inscripciones/confirmar-acceso'),
      () => json(200, { success: true, codigo: 'ABCD-1234' })
    );
    const user = userEvent.setup();
    render(<PortalFamiliasModal isOpen={true} onClose={() => {}} />);
    const dialogo = await screen.findByRole('dialog', { name: /confirmá tu inscripción: escribí el dni de la persona que hizo la inscripción/i });
    await new Promise((r) => setTimeout(r, 30));
    expect(llamadas('/api/inscripciones/confirmar-acceso')).toHaveLength(0);
    const campo = within(dialogo).getByRole('textbox', { name: /dni/i });
    await user.type(campo, '30.111a222');
    expect(campo).toHaveValue('30111222');
    await user.click(within(dialogo).getByRole('button', { name: /^confirmar$/i }));
    expect(await screen.findByText(/¡listo! confirmaste tu email\. ingresá con tu nombre y dni\./i)).toBeInTheDocument();
    expect(screen.getByRole('textbox', { name: /código de acceso del curso/i })).toHaveValue('ABCD-1234');
    const [llamada] = llamadas('/api/inscripciones/confirmar-acceso');
    expect(JSON.parse(String((llamada[1] as RequestInit).body))).toEqual({ id: 'insc-9', token: 'token-secreto', dni: '30111222' });
    expect(screen.queryByRole('dialog')).not.toBeInTheDocument();
    await waitFor(() => expect(window.location.search).not.toContain('confirmar-acceso'));
  });

  it('confirmar-acceso con DNI que no coincide: muestra el error del servidor en rojo y deja reintentar', async () => {
    window.history.replaceState(null, '', '/?confirmar-acceso=insc-9.token-secreto');
    sobreescribirFetch(
      (url) => url.includes('/api/inscripciones/confirmar-acceso'),
      (_url, init) =>
        JSON.parse(String(init?.body)).dni === '30111222'
          ? json(200, { success: true, codigo: 'ABCD-1234' })
          : json(409, { success: false, dniNoCoincide: true, error: 'El DNI no coincide con el de la inscripción. Revisalo.' })
    );
    const user = userEvent.setup();
    render(<PortalFamiliasModal isOpen={true} onClose={() => {}} />);
    const dialogo = await screen.findByRole('dialog');
    const campo = within(dialogo).getByRole('textbox', { name: /dni/i });
    await user.type(campo, '99999999');
    await user.click(within(dialogo).getByRole('button', { name: /^confirmar$/i }));
    expect(await within(dialogo).findByRole('alert')).toHaveTextContent('El DNI no coincide con el de la inscripción. Revisalo.');
    // El error no se pierde aunque el portal vuelva a correr su efecto de apertura (B4).
    await new Promise((r) => setTimeout(r, 50));
    expect(within(dialogo).getByRole('alert')).toBeInTheDocument();
    await user.clear(campo);
    await user.type(campo, '30111222');
    await user.click(within(dialogo).getByRole('button', { name: /^confirmar$/i }));
    expect(await screen.findByText(/¡listo! confirmaste tu email/i)).toBeInTheDocument();
    expect(llamadas('/api/inscripciones/confirmar-acceso')).toHaveLength(2);
  });

  it('cerrar la pantallita de confirmar-acceso saca el parámetro de la URL sin llamar al servidor', async () => {
    window.history.replaceState(null, '', '/?confirmar-acceso=insc-9.token-secreto');
    const user = userEvent.setup();
    render(<PortalFamiliasModal isOpen={true} onClose={() => {}} />);
    const dialogo = await screen.findByRole('dialog');
    await user.click(within(dialogo).getByRole('button', { name: /^cerrar$/i }));
    expect(screen.queryByRole('dialog')).not.toBeInTheDocument();
    expect(window.location.search).not.toContain('confirmar-acceso');
    expect(llamadas('/api/inscripciones/confirmar-acceso')).toHaveLength(0);
  });

  it('email sin confirmar: muestra el aviso del servidor y no reintenta solo', async () => {
    sobreescribirFetch(
      (url) => url.includes('/api/inscripciones/buscar'),
      () => json(200, { success: false, requiereConfirmacion: true, error: 'Primero confirmá tu email con el botón del correo.' })
    );
    const user = userEvent.setup();
    render(<PortalFamiliasModal isOpen={true} onClose={() => {}} />);
    await user.type(screen.getByPlaceholderText(/nombre y apellido del tutor/i), 'Ana Pérez');
    await user.type(screen.getByPlaceholderText(/dni del tutor/i), '30111222');
    await user.type(screen.getByRole('textbox', { name: /código de acceso del curso/i }), 'ABCD-1234');
    await user.click(screen.getByRole('button', { name: /validar/i }));
    expect(await screen.findByText('Primero confirmá tu email con el botón del correo.')).toBeInTheDocument();
    expect(screen.queryByText(/no encontrado/i)).not.toBeInTheDocument();
    await new Promise((r) => setTimeout(r, 50));
    expect(llamadas('/api/inscripciones/buscar')).toHaveLength(1);
  });
});

describe('cerrar sesión (M11/R5)', () => {
  it('borra nombre y DNI del tutor, las llaves HD, la copia local de pedidos y el ?t= de la URL', async () => {
    mockearFetchFamiliaYGaleria();
    sobreescribirFetch(
      (url) => url.includes('/api/inscripciones/buscar'),
      () =>
        json(200, {
          success: true,
          inscripcion: {
            id: familiaActivaMellizos.id,
            padre_nombre: familiaActivaMellizos.padreNombre,
            padre_dni: familiaActivaMellizos.padreDni,
            email: familiaActivaMellizos.email,
            telefono_whatsapp: familiaActivaMellizos.telefonoWhatsApp,
            alumno_nombre: familiaActivaMellizos.alumnoNombre,
            alumno_apellido: familiaActivaMellizos.alumnoApellido,
            grado: familiaActivaMellizos.grado,
            division: familiaActivaMellizos.division,
            turno: familiaActivaMellizos.turno,
            colegio_id: familiaActivaMellizos.colegioId,
            colegio_nombre: familiaActivaMellizos.colegioNombre,
            estado: 'aceptado',
            codigo_asignado: familiaActivaMellizos.codigoAsignado,
            codigo_familiar: familiaActivaMellizos.codigoFamiliar,
            acceso_galeria: familiaActivaMellizos.accesoGaleria,
          },
        })
    );
    window.history.replaceState(null, '', '/?t=llave-secreta&pedido_id=p-1');
    localStorage.setItem('retrato_llaves_pedidos', JSON.stringify({ 'p-1': 'llave-secreta' }));
    localStorage.setItem('infocus_pedidos_escolares_v1', JSON.stringify([{ id: 'IFS-2026-1', supabaseId: 'p-1', tutorNombre: 'Pablo Alder', archivosParaLaboratorio: [] }]));

    const user = userEvent.setup();
    render(<PortalFamiliasModal isOpen={true} onClose={() => {}} />);
    await user.type(screen.getByPlaceholderText(/nombre y apellido del tutor/i), 'Pablo Alder');
    await user.type(screen.getByPlaceholderText(/dni del tutor/i), '20111222');
    await user.type(screen.getByRole('textbox', { name: /código de acceso del curso/i }), familiaActivaMellizos.codigoAsignado!);
    await user.click(screen.getByRole('button', { name: /validar/i }));

    // Entró (Paso 2 o "Acceso validado"): vuelve al inicio y cierra sesión.
    if (!screen.queryByRole('button', { name: /cerrar sesión/i })) {
      await user.click(await screen.findByRole('button', { name: /cambiar datos/i }));
    }
    await user.click(await screen.findByRole('button', { name: /cerrar sesión/i }));

    expect(await screen.findByPlaceholderText(/nombre y apellido del tutor/i)).toHaveValue('');
    expect(screen.getByPlaceholderText(/dni del tutor/i)).toHaveValue('');
    expect(screen.getByRole('textbox', { name: /código de acceso del curso/i })).toHaveValue('');
    expect(localStorage.getItem('retrato_llaves_pedidos')).toBeNull();
    expect(localStorage.getItem('infocus_pedidos_escolares_v1')).toBeNull();
    expect(localStorage.getItem('infocus_familia_activa_v1')).toBeNull();
    expect(window.location.search).not.toContain('t=');
    expect(window.location.search).not.toContain('pedido_id');
  });
});

describe('hermanos (M8a/R3 y R12)', () => {
  beforeEach(() => {
    localStorage.setItem('infocus_familia_activa_v1', JSON.stringify(familiaActivaMellizos));
    mockearFetchFamiliaYGaleria();
    // 11/10 (POR-5): el Paso 4 sólo deja pagar con los precios del servidor cargados.
    sobreescribirFetch((url) => url.includes('/api/precios'), () => json(200, { success: true, precios: { kitClasico: 30000, kitDigital: 15000, carpetaExtra: 15000, fotoEvento: 5000 } }));
  });

  async function abrirGaleria() {
    const user = userEvent.setup();
    render(<PortalFamiliasModal isOpen={true} onClose={() => {}} />);
    await user.click(await screen.findByRole('button', { name: /abrir galería de fotos/i }));
    await screen.findByRole('group', { name: /tus hijos\/as en este colegio/i });
    return user;
  }

  it('un hermano con un pedido esperando el pago no obliga a elegir sus fotos ni entra solo al carrito', async () => {
    sobreescribirFetch(
      (url) => url.includes('/api/reservas/pendiente') && decodeURIComponent(url).includes('Sofia'),
      () => json(200, { success: true, reserva: null, fotosDisponibles: true, tienePedidoPagado: false, tienePedidoPendiente: true })
    );
    const user = await abrirGaleria();
    // La consulta va con la llave de la familia (contrato 5).
    await waitFor(() => expect(llamadas('/api/reservas/pendiente').some((c) => urlDe(c[0] as RequestInfo).includes('acceso=llave-galeria-test'))).toBe(true));
    expect(await screen.findByText(/ya tiene un pedido esperando el pago/i)).toBeInTheDocument();

    await elegirFoto(user, 'grupal', /foto grupal/i);
    await elegirFoto(user, 'individual', /foto individual/i);
    await elegirFoto(user, 'docente', /foto.*seño|foto docente/i);
    await user.click(screen.getByRole('button', { name: /elegir kit y formato/i }));
    expect(await screen.findByText(/elegí tu kit fotográfico/i)).toBeInTheDocument();
    expect(screen.queryByText(/tenés que elegir las 3 fotos de sofia/i)).not.toBeInTheDocument();
  });

  it('incluir al hermano con pedido pendiente exige confirmación y después sí pide sus fotos', async () => {
    sobreescribirFetch(
      (url) => url.includes('/api/reservas/pendiente') && decodeURIComponent(url).includes('Sofia'),
      () => json(200, { success: true, reserva: null, fotosDisponibles: true, tienePedidoPagado: false, tienePedidoPendiente: true })
    );
    const user = await abrirGaleria();
    await user.click(await screen.findByRole('button', { name: /incluirlo igual en esta compra/i }));
    await user.click(screen.getByRole('button', { name: /sí, incluir a sofia alder/i }));
    await elegirFoto(user, 'grupal', /foto grupal/i);
    await elegirFoto(user, 'individual', /foto individual/i);
    await elegirFoto(user, 'docente', /foto.*seño|foto docente/i);
    await user.click(screen.getByRole('button', { name: /elegir kit y formato/i }));
    expect(await screen.findByText(/tenés que elegir las 3 fotos de sofia alder/i)).toBeInTheDocument();
  });

  it('reserva ya PAGADA: se eligen las 3 fotos y se confirman sin volver a pagar (flujo de las reservas reales)', async () => {
    sobreescribirFetch(
      (url) => url.includes('/api/reservas/pendiente') && decodeURIComponent(url).includes('Pablo'),
      () => json(200, { success: true, fotosDisponibles: true, tienePedidoPagado: false, reserva: { id: 'reserva-1', pedidoFriendlyId: 'IFS-2026-7777', kitNombre: 'Kit Impreso + Digital', total: 30000, pagada: true } })
    );
    sobreescribirFetch(
      (url) => url.includes('/api/reservas/reserva-1/elegir-fotos'),
      () => json(200, { success: true, pedidoFriendlyId: 'IFS-2026-7777' })
    );
    const user = await abrirGaleria();
    expect(await screen.findByText(/ya pagaste el kit impreso \+ digital de pablo alder/i)).toBeInTheDocument();
    await elegirFoto(user, 'grupal', /foto grupal/i);
    await elegirFoto(user, 'individual', /foto individual/i);
    await elegirFoto(user, 'docente', /foto.*seño|foto docente/i);
    await user.click(document.getElementById('chk-confirma-personalizacion') as HTMLElement);
    await user.click(screen.getByRole('button', { name: /confirmar mis fotos/i }));
    expect(await screen.findByText(/guardamos tus fotos del pedido IFS-2026-7777/i)).toBeInTheDocument();
    const [llamada] = llamadas('/api/reservas/reserva-1/elegir-fotos');
    const cuerpo = JSON.parse(String((llamada[1] as RequestInit).body));
    expect(cuerpo.codigo).toBe(familiaActivaMellizos.codigoAsignado);
    expect(cuerpo.fotos).toEqual({ grupalId: 'foto-grupal-1', individualId: 'foto-individual-1', docenteId: 'foto-docente-1' });
    // Revisión: con la llave de la familia, para validar la foto individual del hijo.
    expect(cuerpo.familia).toBe(familiaActivaMellizos.id);
    expect(cuerpo.acceso).toBe(familiaActivaMellizos.accesoGaleria);
    // No se creó ningún pedido ni pago nuevo.
    expect(llamadas('/api/pedidos/crear')).toHaveLength(0);
    expect(llamadas('/api/mercadopago')).toHaveLength(0);
  });

  it('M1: si al hermano con pedido pendiente ya se le eligieron fotos, no se deja seguir hasta decidir (incluir / seguir sin él)', async () => {
    sobreescribirFetch(
      (url) => url.includes('/api/reservas/pendiente') && decodeURIComponent(url).includes('Sofia'),
      () => json(200, { success: true, reserva: null, fotosDisponibles: true, tienePedidoPagado: false, tienePedidoPendiente: true })
    );
    const user = await abrirGaleria();
    const grupo = () => screen.getByRole('group', { name: /tus hijos\/as en este colegio/i });
    await user.click(within(grupo()).getByRole('button', { name: /sofia/i }));
    await elegirFoto(user, 'grupal', /foto grupal/i);
    await elegirFoto(user, 'individual', /foto individual/i);
    await elegirFoto(user, 'docente', /foto.*seño|foto docente/i);
    await user.click(within(grupo()).getByRole('button', { name: /pablo/i }));
    await elegirFoto(user, 'grupal', /foto grupal/i);
    await elegirFoto(user, 'individual', /foto individual/i);
    await elegirFoto(user, 'docente', /foto.*seño|foto docente/i);
    expect(within(grupo()).getByText(/pedido esperando el pago · ¿lo incluís\?/i)).toBeInTheDocument();
    await user.click(screen.getByRole('button', { name: /elegir kit y formato/i }));
    expect(await screen.findByText(/ya elegiste las fotos de sofia alder, que tiene un pedido esperando el pago/i)).toBeInTheDocument();
    expect(screen.queryByText(/elegí tu kit fotográfico/i)).not.toBeInTheDocument();

    await user.click(screen.getByRole('button', { name: /^seguir sin sofia alder$/i }));
    expect(within(grupo()).getByText(/pedido esperando el pago \(no se incluye\)/i)).toBeInTheDocument();
    await user.click(screen.getByRole('button', { name: /elegir kit y formato/i }));
    expect(await screen.findByText(/elegí tu kit fotográfico/i)).toBeInTheDocument();
  });

  it('M1 variante: si el servidor ya registró el carrito y al re-consultar el hermano figura "pendiente", el reintento lo sigue incluyendo con los mismos ids', async () => {
    let sofiaPendiente = false;
    let existenteFalla = false;
    sobreescribirFetch(
      (url) => url.includes('/api/reservas/pendiente') && decodeURIComponent(url).includes('Sofia'),
      () => json(200, { success: true, reserva: null, fotosDisponibles: true, tienePedidoPagado: false, tienePedidoPendiente: sofiaPendiente })
    );
    sobreescribirFetch(
      (url) => url.includes('/api/pedidos/existente'),
      () => (existenteFalla ? json(503, { success: false }) : json(200, { success: true, existe: false }))
    );
    // El primer intento llega al servidor (que crea las filas) pero la respuesta falla.
    sobreescribirFetch(
      (url) => url.includes('/api/pedidos/crear-multiple'),
      () => json(500, { success: false, error: 'se cortó' })
    );
    const user = await abrirGaleria();
    const grupo = () => screen.getByRole('group', { name: /tus hijos\/as en este colegio/i });
    for (const nombre of ['Sofia', 'Pablo']) {
      await user.click(within(grupo()).getByRole('button', { name: new RegExp(nombre, 'i') }));
      await elegirFoto(user, 'grupal', /foto grupal/i);
      await elegirFoto(user, 'individual', /foto individual/i);
      await elegirFoto(user, 'docente', /foto.*seño|foto docente/i);
    }
    await user.click(screen.getByRole('button', { name: /elegir kit y formato/i }));
    await user.click(await screen.findByRole('button', { name: /ir a datos y pago/i }));
    await user.click(screen.getByRole('checkbox', { name: /leí y acepto/i }));
    await user.click(document.getElementById('btn-confirmar-pagar') as HTMLElement);
    await waitFor(() => expect(llamadas('/api/pedidos/crear-multiple')).toHaveLength(1));
    const primero = JSON.parse(String((llamadas('/api/pedidos/crear-multiple')[0][1] as RequestInit).body));
    expect(primero.items).toHaveLength(2);

    // Ahora el servidor dice que Sofia "tiene un pedido pendiente" (el recién creado). Se fuerza la
    // re-consulta: volver a la galería, cambiar de hijo (falla "ya tenés pedido") y Reintentar.
    sofiaPendiente = true;
    existenteFalla = true;
    await user.click(screen.getByRole('button', { name: /volver a cambiar kit/i }));
    await user.click(await screen.findByRole('button', { name: /volver a fotos/i }));
    await user.click(within(grupo()).getByRole('button', { name: /sofia/i }));
    await user.click(within(grupo()).getByRole('button', { name: /pablo/i }));
    existenteFalla = false;
    const aviso = (await screen.findByText(/no pudimos verificar si ya hiciste un pedido/i)).closest('[role="alert"]') as HTMLElement;
    await user.click(within(aviso).getByRole('button', { name: /reintentar/i }));
    await waitFor(() =>
      expect(llamadas('/api/reservas/pendiente').filter((c) => decodeURIComponent(urlDe(c[0] as RequestInfo)).includes('Sofia')).length).toBeGreaterThan(1)
    );
    await waitFor(() => expect(screen.queryByText(/no pudimos verificar si ya hiciste un pedido/i)).not.toBeInTheDocument());
    // Sofia NO queda excluida (no aparece "no se incluye") y el reintento manda los mismos ids.
    expect(within(grupo()).queryByText(/no se incluye/i)).not.toBeInTheDocument();
    await user.click(screen.getByRole('button', { name: /elegir kit y formato/i }));
    await user.click(await screen.findByRole('button', { name: /ir a datos y pago/i }));
    await user.click(document.getElementById('btn-confirmar-pagar') as HTMLElement);
    await waitFor(() => expect(llamadas('/api/pedidos/crear-multiple')).toHaveLength(2));
    const segundo = JSON.parse(String((llamadas('/api/pedidos/crear-multiple')[1][1] as RequestInit).body));
    expect(segundo.items.map((it: { pedidoId: string }) => it.pedidoId)).toEqual(primero.items.map((it: { pedidoId: string }) => it.pedidoId));
    expect(segundo.claveCheckout).toBe(primero.claveCheckout);
  });

  it('si no se pudo cargar la lista de hijos, avisa con Reintentar en vez de seguir como hijo único', async () => {
    let fallar = true;
    sobreescribirFetch(
      (url) => url.includes('/api/familia/hijos') && fallar,
      () => json(503, { success: false })
    );
    const user = userEvent.setup();
    render(<PortalFamiliasModal isOpen={true} onClose={() => {}} />);
    expect(await screen.findByText(/no pudimos cargar a tus otros hijos/i)).toBeInTheDocument();
    fallar = false;
    const aviso = screen.getByText(/no pudimos cargar a tus otros hijos/i).closest('[role="alert"]') as HTMLElement;
    await user.click(within(aviso).getByRole('button', { name: /reintentar/i }));
    await waitFor(() => expect(screen.queryByText(/no pudimos cargar a tus otros hijos/i)).not.toBeInTheDocument());
    expect(await screen.findByText('Sofia Alder')).toBeInTheDocument();
  });
});
