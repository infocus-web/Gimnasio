import { render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { afterEach, describe, expect, it, vi } from 'vitest';
import ColaConsultas from '../ColaConsultas';

// 28/10/2026: la cuenta no tiene el disparador por API de las rutinas → «Pedirle a Claude» copia el caso y abre
// Claude en el proyecto Retrato Escolar para pegarlo.
const mocks = vi.hoisted(() => ({ obtener: vi.fn(), actualizar: vi.fn(), pedir: vi.fn() }));
vi.mock('../../services/consultasFamiliasService', () => ({
  obtenerConsultasFamiliasAdmin: mocks.obtener,
  actualizarEstadoConsultaFamiliaAdmin: mocks.actualizar,
  marcarAtencionEspecialAdmin: vi.fn(),
  responderConsultaFamiliaAdmin: vi.fn(),
  sugerirRespuestaConsultaFamiliaAdmin: vi.fn(),
  pedirAClaudeAdmin: mocks.pedir,
  ConsultaCambiadaError: class extends Error {},
}));
vi.mock('../../utils/useBorradorAdmin', async () => {
  const { useState } = await import('react');
  return {
    useBorradorAdmin: (_clave: string | null, inicial: string) => {
      const [valor, setValor] = useState(inicial);
      return [valor, setValor, { fijarSinGuardar: setValor, borrar: async () => undefined }];
    },
  };
});
vi.mock('../ModalFichaCliente', () => ({ default: () => null }));
afterEach(() => { vi.clearAllMocks(); vi.restoreAllMocks(); });

const consulta = {
  id: 'a', nombre: 'Familia Vieja', email: 'f@familia.com', asunto: 'Fotos', origen: 'web', mensaje: 'Hola', estado: 'en_proceso',
  createdAt: '2026-10-20T10:00:00.000Z', updatedAt: '2026-10-25T17:00:00.000Z', mensajes: [] as any[],
};

describe('«Pedirle a Claude» sin rutina', () => {
  it('copia el caso, abre el proyecto de Claude y deja «Copiar el caso de nuevo»', async () => {
    mocks.obtener.mockResolvedValue([consulta]);
    mocks.actualizar.mockResolvedValue(undefined);
    mocks.pedir.mockResolvedValue({ texto: 'CASO COMPLETO' });
    const abrir = vi.spyOn(window, 'open').mockReturnValue(null);
    const user = userEvent.setup();
    const escribir = vi.spyOn(navigator.clipboard, 'writeText').mockResolvedValue(undefined);
    render(<ColaConsultas onCerrar={() => undefined} />);
    await screen.findByRole('heading', { name: 'Familia Vieja' });
    await user.click(screen.getByRole('button', { name: /Pedirle a Claude/ }));
    await waitFor(() => expect(escribir).toHaveBeenCalledWith('CASO COMPLETO'));
    expect(abrir).toHaveBeenCalledWith('https://claude.ai/project/01a0db4a-0eb9-7142-8c5b-4dedc30f25d0', '_blank', 'noopener');
    expect(await screen.findByText(/pegalo con Ctrl\+V/)).toBeTruthy();
    await user.click(screen.getByRole('button', { name: /Copiar el caso de nuevo/ }));
    expect(escribir).toHaveBeenCalledTimes(2);
  });

  it('si el navegador no deja copiar, lo avisa y ofrece «Copiar el caso»', async () => {
    mocks.obtener.mockResolvedValue([consulta]);
    mocks.actualizar.mockResolvedValue(undefined);
    mocks.pedir.mockResolvedValue({ texto: 'CASO' });
    vi.spyOn(window, 'open').mockReturnValue(null);
    const user = userEvent.setup();
    vi.spyOn(navigator.clipboard, 'writeText').mockRejectedValue(new Error('sin foco'));
    render(<ColaConsultas onCerrar={() => undefined} />);
    await screen.findByRole('heading', { name: 'Familia Vieja' });
    await user.click(screen.getByRole('button', { name: /Pedirle a Claude/ }));
    expect(await screen.findByText(/No pudimos copiar el caso solo/)).toBeTruthy();
    expect(screen.getByRole('button', { name: 'Copiar el caso' })).toBeTruthy();
  });
});
