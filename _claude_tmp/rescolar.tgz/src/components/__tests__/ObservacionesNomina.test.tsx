// 14/10/2026 (pedido de Pablo): «Observaciones» en cada alumno de la Nómina, para agregar notas.
import React, { useState } from 'react';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { render, screen, waitFor, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { CeldaObservacionesNomina, useObservacionesNomina } from '../ObservacionesNomina';
import type { AlumnoNominaReal } from '../../services/colegiosService';

const obtener = vi.fn();
const crear = vi.fn();
const borrar = vi.fn();
vi.mock('../../services/observacionesService', async (importOriginal) => {
  const real = await importOriginal<typeof import('../../services/observacionesService')>();
  return {
    ...real,
    obtenerObservacionesAdmin: (...a: unknown[]) => obtener(...a),
    crearObservacionAdmin: (...a: unknown[]) => crear(...a),
    borrarObservacionAdmin: (...a: unknown[]) => borrar(...a),
  };
});
// El borrador del servidor no se prueba acá (tiene sus propias pruebas): se reemplaza por un estado común.
vi.mock('../../utils/useBorradorAdmin', () => ({
  useBorradorAdmin: <T,>(_clave: string | null, inicial: T) => {
    const [valor, setValor] = React.useState(inicial);
    return [valor, setValor, { fijarSinGuardar: setValor, borrar: async () => {}, cargado: true, recuperado: false }] as const;
  },
}));

const fila = (id: string, nombre: string, colegio: string): AlumnoNominaReal => ({
  id, nombre, grado: '1° grado', division: 'A', turno: 'Mañana', colegio_id: colegio, numero_lista: 1, dni: null, origen: null,
});
const ALUMNOS = [fila('a1', 'PEREZ, ANA', 'col-1'), fila('a2', 'GOMEZ, LUZ', 'col-1'), fila('b1', 'RUIZ, EVA', 'col-2')];
const obs = (id: string, alumno: string, colegio: string, detalle: string, fecha = '2026-10-14T12:00:00Z') => ({
  id, colegio_id: colegio, alumno_id: alumno, alumno_nombre: 'X', grado: '1° grado', division: 'A', turno: 'Mañana', tipo: 'otra', detalle, created_at: fecha,
});

function Nomina({ alFilaClick }: { alFilaClick: () => void }) {
  const [alumnos] = useState(ALUMNOS);
  const { observacionesDe, abrirObservaciones, modalObservaciones, errorObservaciones } = useObservacionesNomina(alumnos);
  return (
    <div>
      <ul>
        {alumnos.map((a) => (
          <li key={a.id} onClick={alFilaClick} data-testid={`fila-${a.id}`}>
            {a.nombre} <CeldaObservacionesNomina alumno={a} observaciones={observacionesDe(a.id)} onAbrir={abrirObservaciones} />
          </li>
        ))}
      </ul>
      {errorObservaciones && <p data-testid="error">{errorObservaciones}</p>}
      {modalObservaciones}
    </div>
  );
}

beforeEach(() => {
  obtener.mockImplementation(async (colegioId: string) => ({
    success: true,
    observaciones: colegioId === 'col-1' ? [obs('o1', 'a1', 'col-1', 'Usa anteojos', '2026-10-13T10:00:00Z'), obs('o2', 'a1', 'col-1', 'Foto con la hermana')] : [],
  }));
});
afterEach(() => vi.clearAllMocks());

describe('Observaciones en la Nómina', () => {
  it('trae las observaciones de cada colegio y muestra en la fila cuántas hay y la última', async () => {
    render(<Nomina alFilaClick={() => {}} />);
    await waitFor(() => expect(within(screen.getByTestId('fila-a1')).getByText('Foto con la hermana')).toBeTruthy());
    expect(within(screen.getByTestId('fila-a1')).getByText('2')).toBeTruthy();
    expect(within(screen.getByTestId('fila-a2')).getByText('Nota')).toBeTruthy();
    expect(obtener.mock.calls.map((c) => c[0]).sort()).toEqual(['col-1', 'col-2']);
  });

  it('agrega una nota desde la fila sin marcar al alumno como fotografiado', async () => {
    const alFilaClick = vi.fn();
    crear.mockResolvedValue({ success: true, observacion: obs('o3', 'a2', 'col-1', 'Ausente, viene el jueves') });
    render(<Nomina alFilaClick={alFilaClick} />);
    await userEvent.click(within(screen.getByTestId('fila-a2')).getByRole('button', { name: /agregar una observación a gomez/i }));
    expect(alFilaClick).not.toHaveBeenCalled();
    const ventana = screen.getByRole('dialog');
    expect(within(ventana).getByText('Todavía no tiene observaciones.')).toBeTruthy();
    expect((within(ventana).getByRole('button', { name: 'Agregar observación' }) as HTMLButtonElement).disabled).toBe(true);
    await userEvent.type(within(ventana).getByLabelText('Nota'), '  Ausente, viene el jueves ');
    await userEvent.click(within(ventana).getByRole('button', { name: 'Agregar observación' }));
    expect(crear).toHaveBeenCalledWith('a2', 'otra', 'Ausente, viene el jueves', expect.any(String));
    await waitFor(() => expect(within(ventana).getByText('Ausente, viene el jueves')).toBeTruthy());
    expect(within(screen.getByTestId('fila-a2')).getByText('1')).toBeTruthy();
  });

  it('si el servidor no la guarda, avisa y no la muestra', async () => {
    crear.mockResolvedValue({ success: false, error: 'Sesión vencida' });
    render(<Nomina alFilaClick={() => {}} />);
    await userEvent.click(within(screen.getByTestId('fila-a2')).getByRole('button'));
    const ventana = screen.getByRole('dialog');
    await userEvent.type(within(ventana).getByLabelText('Nota'), 'Algo');
    await userEvent.click(within(ventana).getByRole('button', { name: 'Agregar observación' }));
    expect((await within(ventana).findByRole('alert')).textContent).toContain('Sesión vencida');
    expect(within(screen.getByTestId('fila-a2')).getByText('Nota')).toBeTruthy();
  });

  it('borra una observación después de confirmar', async () => {
    borrar.mockResolvedValue({ success: true });
    const confirmar = vi.spyOn(window, 'confirm').mockReturnValue(true);
    render(<Nomina alFilaClick={() => {}} />);
    await waitFor(() => expect(within(screen.getByTestId('fila-a1')).getByText('2')).toBeTruthy());
    await userEvent.click(within(screen.getByTestId('fila-a1')).getByRole('button'));
    const ventana = screen.getByRole('dialog');
    await waitFor(() => expect(within(ventana).getAllByRole('button', { name: 'Borrar observación' })).toHaveLength(2));
    await userEvent.click(within(ventana).getAllByRole('button', { name: 'Borrar observación' })[0]);
    expect(confirmar).toHaveBeenCalled();
    expect(borrar).toHaveBeenCalledWith('o2');
    await waitFor(() => expect(within(screen.getByTestId('fila-a1')).getByText('1')).toBeTruthy());
    expect(within(screen.getByTestId('fila-a1')).getByText('Usa anteojos')).toBeTruthy();
    confirmar.mockRestore();
  });

  it('muestra el error si no se pueden cargar', async () => {
    obtener.mockResolvedValue({ success: false, observaciones: [], error: 'Sin conexión' });
    render(<Nomina alFilaClick={() => {}} />);
    expect((await screen.findByTestId('error')).textContent).toBe('Sin conexión');
  });
});
