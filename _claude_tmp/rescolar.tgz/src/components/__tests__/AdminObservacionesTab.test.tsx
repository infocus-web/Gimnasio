// 13/10/2026 (pedido de Pablo): pestaña «Observaciones» del panel para anotar lo que pasó en la toma de fotos.
import { describe, expect, it, vi, beforeEach } from 'vitest';
import { render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import AdminObservacionesTab from '../AdminObservacionesTab';

const crear = vi.fn();
const borrar = vi.fn();
vi.mock('../../services/colegiosService', () => ({
  useColegiosLista: () => ({ colegios: [{ id: 'col-1', nombre: 'Divino Pastor' }] }),
  obtenerAlumnosNominaAdmin: async () => [
    { id: 'a1', nombre: 'PÉREZ, ANA LUZ', grado: 'Sala 4 años', division: 'C', turno: 'Tarde', colegio_id: 'col-1' },
    { id: 'a2', nombre: 'GOMEZ, SOL', grado: '1° grado', division: 'A', turno: 'Mañana', colegio_id: 'col-1' },
  ],
}));
vi.mock('../../services/observacionesService', async (original) => {
  const real: any = await original();
  return {
    ...real,
    obtenerObservacionesAdmin: async () => ({
      success: true,
      observaciones: [
        { id: 'o1', colegio_id: 'col-1', alumno_id: 'a2', alumno_nombre: 'GOMEZ, SOL', grado: '1° grado', division: 'A', turno: 'Mañana', tipo: 'ausente', detalle: null, created_at: '2026-10-13T12:00:00Z' },
      ],
    }),
    crearObservacionAdmin: (...a: unknown[]) => crear(...a),
    borrarObservacionAdmin: (...a: unknown[]) => borrar(...a),
  };
});

beforeEach(() => {
  crear.mockReset();
  borrar.mockReset();
});

describe('AdminObservacionesTab', () => {
  it('busca al alumno sin tildes, guarda la observación y la muestra arriba', async () => {
    crear.mockResolvedValue({
      success: true,
      observacion: { id: 'o2', colegio_id: 'col-1', alumno_id: 'a1', alumno_nombre: 'PÉREZ, ANA LUZ', grado: 'Sala 4 años', division: 'C', turno: 'Tarde', tipo: 'sin_foto_individual', detalle: 'No quiso', created_at: '2026-10-13T13:00:00Z' },
    });
    const u = userEvent.setup();
    render(<AdminObservacionesTab />);
    expect(await screen.findByText('GOMEZ, SOL')).toBeInTheDocument();
    expect(screen.getByRole('button', { name: /guardar observación/i })).toBeDisabled();

    await u.type(screen.getByLabelText('Alumno'), 'perez ana');
    await u.click(await screen.findByRole('option', { name: /PÉREZ, ANA LUZ/ }));
    await u.type(screen.getByRole('textbox', { name: /detalle/i }), 'No quiso');
    await u.click(screen.getByRole('button', { name: /guardar observación/i }));

    // 14/10: con la clave del envío (un reintento no la anota dos veces).
    expect(crear).toHaveBeenCalledWith('a1', 'sin_foto_individual', 'No quiso', expect.stringMatching(/^[A-Za-z0-9-]{8,64}$/));
    expect(await screen.findByRole('status')).toHaveTextContent('PÉREZ, ANA LUZ');
  });

  it('«Otra» sin detalle no se manda', async () => {
    const u = userEvent.setup();
    render(<AdminObservacionesTab />);
    await screen.findByText('GOMEZ, SOL');
    await u.type(screen.getByLabelText('Alumno'), 'gomez');
    await u.click(await screen.findByRole('option', { name: /GOMEZ, SOL/ }));
    await u.click(screen.getByRole('radio', { name: /otra/i }));
    await u.click(screen.getByRole('button', { name: /guardar observación/i }));
    expect(crear).not.toHaveBeenCalled();
    expect(screen.getByRole('alert')).toHaveTextContent(/detalle/i);
  });

  it('borra una observación después de confirmar', async () => {
    borrar.mockResolvedValue({ success: true });
    vi.spyOn(window, 'confirm').mockReturnValue(true);
    const u = userEvent.setup();
    render(<AdminObservacionesTab />);
    await u.click(await screen.findByRole('button', { name: 'Borrar la observación de GOMEZ, SOL' }));
    expect(borrar).toHaveBeenCalledWith('o1');
    await waitFor(() => expect(screen.queryByText('GOMEZ, SOL')).not.toBeInTheDocument());
  });
});
