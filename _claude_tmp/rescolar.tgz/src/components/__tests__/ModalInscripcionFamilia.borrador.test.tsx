// 14/10/2026: formulario de inscripción — (1) si el servidor avisa que la inscripción ya estaba aprobada y no
// cambió nada (`congelada`), no se muestra «¡Ya podés ver las fotos! … y 1 hermano más»; (2) el borrador
// sobrevive a una recarga SIN ningún DNI y se borra al inscribirse.
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import ModalInscripcionFamilia from '../ModalInscripcionFamilia';

const COLEGIO = '11111111-1111-4111-8111-111111111111';
const CLAVE_BORRADOR = 'retrato_borrador_inscripcion';

function servidorFalso(respuestaValidar: () => unknown) {
  const fetchFalso = vi.fn(async (url: string) => {
    const responder = (body: unknown) => new Response(JSON.stringify(body), { status: 200, headers: { 'Content-Type': 'application/json' } });
    if (url === '/api/colegios') {
      return responder({ success: true, colegios: [{ id: COLEGIO, slug: 'colegio', nombre: 'Colegio de Prueba', localidad: 'Pilar', grados: ['Sala 4 años'], divisiones: ['A'], turnos: ['Mañana'] }] });
    }
    if (url === `/api/colegios/${COLEGIO}/cursos`) return responder({ success: true, cursos: [{ grado: 'Sala 4 años', division: 'A', turno: 'Mañana' }] });
    if (url === '/api/inscripciones/validar') return responder(respuestaValidar());
    return responder({ success: false });
  });
  vi.stubGlobal('fetch', fetchFalso);
  return fetchFalso;
}

const filaAprobada = {
  id: 'insc-1', estado: 'aceptado', padre_nombre: 'Mariana Gómez', email: 'mariana@prueba.test', alumno_nombre: 'Benjamín', alumno_apellido: 'Gómez',
  colegio_id: COLEGIO, colegio_nombre: 'Colegio de Prueba', grado: 'Sala 4 años', division: 'A', turno: 'Mañana',
  hermanos: [{ id: 'h1', alumnoNombre: 'Sofía', alumnoApellido: 'Gómez', grado: 'Sala 4 años', division: 'A', turno: 'Mañana' }],
};

async function completarFormulario(user: ReturnType<typeof userEvent.setup>) {
  await user.type(screen.getByPlaceholderText('Ej: Mariana Gómez'), 'Mariana Gómez');
  await user.type(screen.getByPlaceholderText('Sin puntos, ej: 30456789'), '30456789');
  await user.type(screen.getByPlaceholderText('Ej: 11 5489-3210'), '11 5489-3210');
  await user.type(screen.getByPlaceholderText('Ej: mariana.gomez@gmail.com'), 'mariana@prueba.test');
  await user.type(screen.getByPlaceholderText('Ej: Benjamín'), 'Benjamín');
  await user.type(screen.getByPlaceholderText('Ej: Gómez'), 'Gómez');
  await user.type(screen.getByPlaceholderText('Ej: 45123456 (sin puntos)'), '45123456');
}

async function elegirCurso(user: ReturnType<typeof userEvent.setup>) {
  const grado = await screen.findByDisplayValue('Elegí el grado o sala');
  await waitFor(() => expect(grado.querySelectorAll('option').length).toBeGreaterThan(1));
  await user.selectOptions(grado, 'Sala 4 años');
  await user.selectOptions(screen.getByDisplayValue('Elegí la división'), 'A');
  await waitFor(() => expect((screen.getByDisplayValue('Mañana') as HTMLSelectElement).value).toBe('Mañana'));
}

beforeEach(() => {
  sessionStorage.clear();
  localStorage.clear();
});
afterEach(() => {
  vi.unstubAllGlobals();
});

describe('inscripción ya aprobada sin cambios (congelada)', () => {
  it('muestra «ya estaba aprobada; no cambiamos nada» y no «Ya podés ver las fotos … 1 hermano más»; borra el borrador', async () => {
    servidorFalso(() => ({ success: true, estado: 'aceptado', congelada: true, emailEnviado: false, inscripcion: filaAprobada }));
    const user = userEvent.setup();
    render(<ModalInscripcionFamilia isOpen onClose={() => undefined} onInscripcionExitosa={() => undefined} />);
    await elegirCurso(user);
    await completarFormulario(user);
    for (const id of ['toma', 'grupal', 'transferencia']) await user.click(document.getElementById(`consentimiento-${id}`) as HTMLElement);
    expect(sessionStorage.getItem(CLAVE_BORRADOR)).toContain('Mariana');
    await user.click(document.getElementById('btn-confirmar-inscripcion') as HTMLElement);

    expect(await screen.findByText(/tu inscripción ya estaba aprobada; no cambiamos nada/i)).toBeInTheDocument();
    expect(screen.getByText(/para sumar un hermano o corregir datos, escribinos/i)).toBeInTheDocument();
    expect(screen.queryByText(/ya podés ver las fotos/i)).not.toBeInTheDocument();
    expect(screen.queryByText(/1 hermano más/i)).not.toBeInTheDocument();
    expect(sessionStorage.getItem(CLAVE_BORRADOR)).toBeNull();
  });

  it('control: sin `congelada`, la aprobación se muestra como siempre', async () => {
    servidorFalso(() => ({ success: true, estado: 'aceptado', emailEnviado: true, emailDestino: 'm***@prueba.test', inscripcion: filaAprobada }));
    const user = userEvent.setup();
    render(<ModalInscripcionFamilia isOpen onClose={() => undefined} onInscripcionExitosa={() => undefined} />);
    await elegirCurso(user);
    await completarFormulario(user);
    for (const id of ['toma', 'grupal', 'transferencia']) await user.click(document.getElementById(`consentimiento-${id}`) as HTMLElement);
    await user.click(document.getElementById('btn-confirmar-inscripcion') as HTMLElement);
    expect(await screen.findByText(/ya podés ver las fotos/i)).toBeInTheDocument();
    expect(screen.queryByText(/no cambiamos nada/i)).not.toBeInTheDocument();
  });
});

describe('borrador del formulario', () => {
  it('sobrevive a una recarga sin guardar ningún DNI', async () => {
    servidorFalso(() => ({ success: false }));
    const user = userEvent.setup();
    const vista = render(<ModalInscripcionFamilia isOpen onClose={() => undefined} onInscripcionExitosa={() => undefined} />);
    await completarFormulario(user);
    await user.click(screen.getByRole('button', { name: /agregar (otro )?hermano/i }));
    await user.type(screen.getByPlaceholderText('Ej: Sofía'), 'Sofía');
    const dnis = screen.getAllByPlaceholderText('Ej: 45123456 (sin puntos)');
    await user.type(dnis[dnis.length - 1], '47111222');

    const guardado = sessionStorage.getItem(CLAVE_BORRADOR) || '';
    expect(guardado).toContain('Mariana Gómez');
    expect(guardado).toContain('Sofía');
    for (const dni of ['30456789', '45123456', '47111222']) expect(guardado).not.toContain(dni);
    expect(guardado).not.toMatch(/dni/i);

    // «Recarga»: se desmonta y se vuelve a montar (sessionStorage sigue, la memoria no).
    vista.unmount();
    render(<ModalInscripcionFamilia isOpen onClose={() => undefined} onInscripcionExitosa={() => undefined} />);
    expect(await screen.findByDisplayValue('Mariana Gómez')).toBeInTheDocument();
    expect(screen.getByDisplayValue('mariana@prueba.test')).toBeInTheDocument();
    expect(screen.getByDisplayValue('Benjamín')).toBeInTheDocument();
    expect(screen.getByDisplayValue('Sofía')).toBeInTheDocument();
    expect((screen.getByPlaceholderText('Sin puntos, ej: 30456789') as HTMLInputElement).value).toBe('');
    for (const campo of screen.getAllByPlaceholderText('Ej: 45123456 (sin puntos)')) expect((campo as HTMLInputElement).value).toBe('');
  });
});
