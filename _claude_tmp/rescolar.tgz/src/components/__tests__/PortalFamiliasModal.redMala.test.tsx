import { render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { beforeEach, describe, expect, it, vi } from 'vitest';
import PortalFamiliasModal from '../PortalFamiliasModal';
import { familiaActivaMellizos, mockearFetchFamiliaYGaleria } from '../../test/fixtures/familiaMellizos';

// Auditoría de tráfico 03/10 — portal de familias con red mala / servidor saturado.

type Implementacion = (input: RequestInfo | URL, init?: RequestInit) => Promise<Response>;

function sobreescribirFetch(ruta: string, respuesta: () => Response) {
  const fetchBase = global.fetch as unknown as ReturnType<typeof vi.fn>;
  const base = fetchBase.getMockImplementation() as Implementacion;
  fetchBase.mockImplementation(async (input: RequestInfo | URL, init?: RequestInit) => {
    const url = typeof input === 'string' ? input : input.toString();
    if (url.includes(ruta)) return respuesta();
    return base(input, init);
  });
}

describe('PortalFamiliasModal — red mala (auditoría 03/10)', () => {
  beforeEach(() => {
    localStorage.setItem('infocus_familia_activa_v1', JSON.stringify(familiaActivaMellizos));
    mockearFetchFamiliaYGaleria();
  });

  it('si falla la consulta de "ya tenés pedido" (503) no deja abrir la galería y ofrece reintentar (alto 6)', async () => {
    let fallar = true;
    sobreescribirFetch('/api/pedidos/existente', () =>
      fallar
        ? ({ ok: false, status: 503, json: async () => ({ success: false }) } as Response)
        : ({ ok: true, status: 200, json: async () => ({ success: true, existe: false }) } as Response)
    );
    const user = userEvent.setup();
    render(<PortalFamiliasModal isOpen={true} onClose={() => {}} />);
    expect(await screen.findByText(/no pudimos verificar si ya hiciste un pedido/i)).toBeInTheDocument();
    expect(screen.queryByRole('button', { name: /abrir galería de fotos/i })).not.toBeInTheDocument();

    fallar = false;
    await user.click(screen.getByRole('button', { name: /reintentar/i }));
    expect(await screen.findByRole('button', { name: /abrir galería de fotos/i })).toBeInTheDocument();
  });

  it('la galería muestra el error con "Reintentar" en vez de "todavía no fueron ingresadas" (alto 23)', async () => {
    sobreescribirFetch('/api/fotos', () => ({ ok: false, status: 500, json: async () => ({ success: false }) } as Response));
    const user = userEvent.setup();
    render(<PortalFamiliasModal isOpen={true} onClose={() => {}} />);
    await user.click(await screen.findByRole('button', { name: /abrir galería de fotos/i }));
    expect(await screen.findByRole('heading', { name: /no pudimos cargar las fotos/i })).toBeInTheDocument();
    expect(screen.getByRole('button', { name: /reintentar/i })).toBeInTheDocument();
    expect(screen.queryByText(/todavía no fueron ingresadas/i)).not.toBeInTheDocument();
  });

  it('un código vencido se informa como tal (alto 23)', async () => {
    sobreescribirFetch('/api/fotos', () => ({ ok: false, status: 401, json: async () => ({ success: false, error: 'Código de acceso incorrecto o vencido' }) } as Response));
    const user = userEvent.setup();
    render(<PortalFamiliasModal isOpen={true} onClose={() => {}} />);
    await user.click(await screen.findByRole('button', { name: /abrir galería de fotos/i }));
    await waitFor(() => expect(screen.getByText(/tu código de acceso venció o cambió/i)).toBeInTheDocument());
  });
});
