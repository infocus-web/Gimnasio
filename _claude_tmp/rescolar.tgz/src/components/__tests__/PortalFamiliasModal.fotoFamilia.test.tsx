import { render, screen, waitFor, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import PortalFamiliasModal from '../PortalFamiliasModal';
import { COLEGIO_ID, familiaActivaMellizos, mockearFetchFamiliaYGaleria } from '../../test/fixtures/familiaMellizos';

// 06/10/2026 (pedido de Pablo, consulta real de una familia de secundaria): en secundaria no se sacan
// fotos con el docente; la 3ª foto del kit es «con familia y/o amigos» (categoría 'familia'), la ve
// todo el curso y va en el lugar `docenteId` del pedido.

type Implementacion = (input: RequestInfo | URL, init?: RequestInit) => Promise<Response>;

function json(status: number, cuerpo: unknown): Response {
  return { ok: status >= 200 && status < 300, status, json: async () => cuerpo } as Response;
}
function urlDe(input: RequestInfo | URL) {
  return typeof input === 'string' ? input : input.toString();
}
function sobreescribirFetch(coincide: (url: string, init?: RequestInit) => boolean, respuesta: (url: string, init?: RequestInit) => Response) {
  const fetchBase = global.fetch as unknown as ReturnType<typeof vi.fn>;
  const base = fetchBase.getMockImplementation() as Implementacion | undefined;
  fetchBase.mockImplementation(async (input: RequestInfo | URL, init?: RequestInit) => {
    const url = urlDe(input);
    if (coincide(url, init)) return respuesta(url, init);
    return base ? base(input, init) : json(404, { success: false });
  });
}
function llamadas(fragmento: string) {
  const fetchBase = global.fetch as unknown as ReturnType<typeof vi.fn>;
  return fetchBase.mock.calls.filter((c) => urlDe(c[0] as RequestInfo).includes(fragmento));
}
function galeria(fotos: Array<{ id: string; categoria: string; thumb_path: string }>) {
  sobreescribirFetch(
    (url) => url.includes('/api/fotos'),
    () => json(200, { success: true, seccion: { colegioId: COLEGIO_ID, grado: '1° grado', turno: 'Tarde', division: 'A' }, fotos })
  );
}

async function elegir(user: ReturnType<typeof userEvent.setup>, slot: RegExp, titulo: RegExp) {
  await user.click(screen.getByText(slot).closest('div')!.parentElement!);
  const tarjeta = (await screen.findAllByText(titulo))[0].closest('div.relative')!;
  await user.click(within(tarjeta as HTMLElement).getByRole('button', { name: /^elegir$/i }));
}
const grupo = () => screen.getByRole('group', { name: /tus hijos\/as en este colegio/i });

afterEach(() => {
  window.history.replaceState(null, '', '/');
});

describe('3ª foto con familia y/o amigos (06/10)', () => {
  beforeEach(() => {
    localStorage.setItem('infocus_familia_activa_v1', JSON.stringify(familiaActivaMellizos));
    mockearFetchFamiliaYGaleria();
    sobreescribirFetch((url) => url.includes('/api/pedidos/existente'), () => json(200, { success: true, existe: false }));
    // 11/10 (POR-5): el Paso 4 sólo deja pagar con los precios del servidor cargados.
    sobreescribirFetch((url) => url.includes('/api/precios'), () => json(200, { success: true, precios: { kitClasico: 30000, kitDigital: 15000, carpetaExtra: 15000, fotoEvento: 5000 } }));
  });

  async function abrirGaleria() {
    const user = userEvent.setup();
    render(<PortalFamiliasModal isOpen={true} onClose={() => {}} />);
    await user.click(await screen.findByRole('button', { name: /abrir galería de fotos/i }));
    await screen.findByRole('group', { name: /tus hijos\/as en este colegio/i });
    return { user };
  }

  it('un curso sin foto con la seño pero con fotos con familia/amigos se completa con esa y se manda en docenteId', async () => {
    galeria([
      { id: 'foto-individual-1', categoria: 'individual', thumb_path: '/img/individual-1.jpg' },
      { id: 'foto-grupal-1', categoria: 'grupal', thumb_path: '/img/grupal-1.jpg' },
      { id: 'foto-familia-1', categoria: 'familia', thumb_path: '/img/familia-1.jpg' },
    ]);
    sobreescribirFetch((url) => url.includes('/api/pedidos/crear-multiple'), () => json(500, { success: false, error: 'se cortó' }));
    const { user } = await abrirGaleria();
    expect(await screen.findByText(/^3\/3 familia\/amigos$/i)).toBeInTheDocument();
    expect(screen.queryByText(/^3\/3 con seño$/i)).not.toBeInTheDocument();

    for (const hijo of ['Sofia', 'Pablo']) {
      await user.click(within(grupo()).getByRole('button', { name: new RegExp(hijo, 'i') }));
      await elegir(user, /^1\/3 grupal$/i, /foto grupal/i);
      await elegir(user, /^2\/3 retrato$/i, /foto individual/i);
      await elegir(user, /^3\/3 familia\/amigos$/i, /foto con familia\/amigos/i);
    }
    expect(screen.getByText(/3 de 3 fotos seleccionadas/i)).toBeInTheDocument();
    await user.click(screen.getByRole('button', { name: /elegir kit y formato/i }));
    await user.click(await screen.findByRole('button', { name: /ir a datos y pago/i }));
    await user.click(screen.getByRole('checkbox', { name: /leí y acepto/i }));
    await user.click(document.getElementById('btn-confirmar-pagar') as HTMLElement);
    await waitFor(() => expect(llamadas('/api/pedidos/crear-multiple')).toHaveLength(1));
    const cuerpo = JSON.parse(String((llamadas('/api/pedidos/crear-multiple')[0][1] as RequestInit).body));
    const terceras = cuerpo.items.map((it: { fotosSeleccionadas: { docenteId?: string } }) => it.fotosSeleccionadas.docenteId);
    expect(terceras).toEqual(['foto-familia-1', 'foto-familia-1']);
  });

  it('si el curso tiene las dos, la 3ª foto se elige de cualquiera (con la seño o con familia/amigos)', async () => {
    galeria([
      { id: 'foto-individual-1', categoria: 'individual', thumb_path: '/img/individual-1.jpg' },
      { id: 'foto-grupal-1', categoria: 'grupal', thumb_path: '/img/grupal-1.jpg' },
      { id: 'foto-docente-1', categoria: 'docente', thumb_path: '/img/docente-1.jpg' },
      { id: 'foto-familia-1', categoria: 'familia', thumb_path: '/img/familia-1.jpg' },
    ]);
    const { user } = await abrirGaleria();
    await user.click((await screen.findByText(/^3\/3 seño o amigos$/i)).closest('div')!.parentElement!);
    expect(await screen.findAllByText(/foto con familia\/amigos/i)).not.toHaveLength(0);
    expect(screen.getAllByText(/foto docente/i)).not.toHaveLength(0);
  });

  it('una reserva pagada de un curso sin 3ª foto se confirma con la grupal y la individual', async () => {
    galeria([
      { id: 'foto-individual-1', categoria: 'individual', thumb_path: '/img/individual-1.jpg' },
      { id: 'foto-grupal-1', categoria: 'grupal', thumb_path: '/img/grupal-1.jpg' },
    ]);
    sobreescribirFetch(
      (url) => url.includes('/api/reservas/pendiente') && decodeURIComponent(url).includes('Pablo'),
      () => json(200, { success: true, fotosDisponibles: true, tienePedidoPagado: false, reserva: { id: 'reserva-1', pedidoFriendlyId: 'IFS-2026-7777', kitNombre: 'Kit Impreso + Digital', total: 30000, pagada: true } })
    );
    sobreescribirFetch((url) => url.includes('/api/reservas/reserva-1/elegir-fotos'), () => json(200, { success: true, pedidoFriendlyId: 'IFS-2026-7777' }));
    const { user } = await abrirGaleria();
    expect(await screen.findByText(/ya pagaste el kit impreso \+ digital de pablo alder/i)).toBeInTheDocument();
    expect(screen.getByText(/elegí las 2 fotos \(1 grupal, 1 individual\)/i)).toBeInTheDocument();
    await elegir(user, /^1\/3 grupal$/i, /foto grupal/i);
    await elegir(user, /^2\/3 retrato$/i, /foto individual/i);
    await user.click(document.getElementById('chk-confirma-personalizacion') as HTMLElement);
    await user.click(screen.getByRole('button', { name: /confirmar mis fotos/i }));
    expect(await screen.findByText(/guardamos tus fotos del pedido IFS-2026-7777/i)).toBeInTheDocument();
    const cuerpo = JSON.parse(String((llamadas('/api/reservas/reserva-1/elegir-fotos')[0][1] as RequestInit).body));
    expect(cuerpo.fotos).toMatchObject({ grupalId: 'foto-grupal-1', individualId: 'foto-individual-1' });
    expect(cuerpo.fotos.docenteId || '').toBe('');
  });
});
