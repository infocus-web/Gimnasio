// 10/10/2026 (pedido de Pablo): pedidos por transferencia vencidos sin comprobante. No se pierden:
// el panel los muestra aparte («Vencidos sin comprobante») para aprobarlos o reabrirles el plazo.
import { readFileSync } from 'fs';
import path from 'path';
import { describe, expect, it } from 'vitest';
import { construirPedidoCompletoDesdeFila } from '../../services/pedidosLabService';
import { AVISO_PREVIO_VENCIMIENTO_HORAS, pedidoVencidoRecuperable, venceTransferencia } from '../../utils/plazoTransferencia';

describe('vencidos sin comprobante (panel)', () => {
  it('el vencimiento es 48 h después de elegir transferencia', () => {
    expect(venceTransferencia('2026-10-09T16:50:46.263Z')).toBe('2026-10-11T16:50:46.263Z');
    expect(venceTransferencia(null)).toBeNull();
    expect(venceTransferencia('cualquier cosa')).toBeNull();
    expect(AVISO_PREVIO_VENCIMIENTO_HORAS).toBe(12);
  });

  it('sólo es recuperable lo que se canceló por vencer el plazo (no los definitivos ni los archivados)', () => {
    const base = { estadoPago: 'rechazado', transferenciaVencidaAt: '2026-10-11T17:00:00Z', canceladoDefinitivo: false, archivado: false };
    expect(pedidoVencidoRecuperable(base)).toBe(true);
    expect(pedidoVencidoRecuperable({ ...base, transferenciaVencidaAt: null })).toBe(false);
    expect(pedidoVencidoRecuperable({ ...base, canceladoDefinitivo: true })).toBe(false);
    expect(pedidoVencidoRecuperable({ ...base, archivado: true })).toBe(false);
    expect(pedidoVencidoRecuperable({ ...base, estadoPago: 'pendiente' })).toBe(false);
    expect(pedidoVencidoRecuperable({ ...base, estadoPago: 'aprobado' })).toBe(false);
  });

  it('el panel recibe del servidor las fechas del plazo y si el cancelado es definitivo', () => {
    const pedido = construirPedidoCompletoDesdeFila({
      id: '11111111-1111-1111-1111-111111111111',
      pedido_friendly_id: 'IFS-2026-0001',
      estado: 'cancelado',
      metodo_pago: 'transferencia',
      total: 30000,
      transferencia_desde: '2026-10-09T16:50:46Z',
      transferencia_vencida_at: '2026-10-11T17:00:00Z',
      aviso_vencimiento_at: '2026-10-11T05:00:00Z',
      cancelado_definitivo: false,
    });
    expect(pedido.estadoPago).toBe('rechazado');
    expect(pedido.transferenciaDesde).toBe('2026-10-09T16:50:46Z');
    expect(pedido.transferenciaVencidaAt).toBe('2026-10-11T17:00:00Z');
    expect(pedido.avisoVencimientoAt).toBe('2026-10-11T05:00:00Z');
    expect(pedido.canceladoDefinitivo).toBe(false);
    expect(pedidoVencidoRecuperable(pedido)).toBe(true);
  });

  it('el panel tiene la lista aparte con «Aprobar Pago» y «Reabrir plazo»', () => {
    const panel = readFileSync(path.resolve(__dirname, '../AdminModal.tsx'), 'utf8').replace(/\r\n/g, '\n');
    expect(panel).toContain('Vencidos sin comprobante (${cantidadVencidos})');
    expect(panel).toContain('? pedidoVencidoRecuperable(p)');
    // Los vencidos no se mezclan con los cancelados comunes.
    expect(panel).toContain("p.estadoPago === 'rechazado' && !p.archivado && !pedidoVencidoRecuperable(p)");
    // Reabrir: vuelve a pendiente sólo si sigue cancelado (cambio condicional en el servidor).
    expect(panel).toContain("{ estadoPago: 'pendiente', estadoAnterior: 'cancelado' }");
    expect(panel).toContain('Reabrir plazo (48 h)');
  });
});
