// 19/10/2026 (pedido de Pablo): «Ficha del cliente» desde Consultas: hijos, kit y si pagó, en un solo lugar.
import { describe, expect, it, vi, beforeEach } from 'vitest';
import { render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import ModalFichaCliente from '../ModalFichaCliente';

const obtener = vi.fn();
vi.mock('../../services/fichaClienteService', () => ({ obtenerFichaClienteAdmin: (...a: unknown[]) => obtener(...a) }));

const ficha = {
  encontrado: true,
  buscado: { email: 'laura@mail.com', telefono: null, pedido: null },
  inscripciones: [{ id: 'i1', tutor: 'Laura Gómez', dniTutor: null, email: 'laura@mail.com', telefono: '1155551234', colegio: 'Divino Pastor', estado: 'aceptado', codigo: 'ABC123', emailCodigoEnviado: true, accesoConfirmadoAt: null, fotoHermanos: false, fechaAprobacion: null, createdAt: '2026-09-20T10:00:00Z' }],
  familias: [],
  hijos: [
    { nombre: 'Tomás Paz', dni: null, colegio: 'Divino Pastor', inscripcionId: 'i1', curso: { grado: 'Sala 4 años', division: 'C', turno: 'Tarde' }, cursoNomina: { grado: 'Sala 4 años', division: 'C', turno: 'Tarde' }, enNomina: true, coincideConNomina: true, fotosPublicadas: 12, pagado: true, pedidos: 1 },
    { nombre: 'Sofía Paz', dni: null, colegio: 'Divino Pastor', inscripcionId: 'i1', curso: { grado: '3° grado', division: 'A', turno: 'Mañana' }, cursoNomina: { grado: '3° grado', division: 'B', turno: 'Mañana' }, enNomina: true, coincideConNomina: false, fotosPublicadas: 0, pagado: false, pedidos: 0 },
  ],
  pedidos: [{ id: 'p1', numero: 'IFS-2026-1111', alumno: 'Tomás Paz', colegio: 'Divino Pastor', curso: 'Sala 4 años · C · Tarde', kit: 'Kit Impreso', carpetasImpresas: 1, copiasExtras: 0, fotosElegidas: 3, seleccionPendiente: false, total: 30000, estado: 'pagado', metodoPago: 'mercadopago', createdAt: '2026-10-01T10:00:00Z', pagadoAt: '2026-10-01T10:05:00Z', aprobadoManual: false, comprobante: false, transferenciaVencida: false, canceladoDefinitivo: false, estadoLab: 'en_produccion', entregadoAt: null, hdEnviado: true, hdEnviadoAt: '2026-10-01T10:06:00Z', descargasHd: 2, archivado: false, enEspera: false, notaEspera: null, esMejora: false, soloPorNumero: false }],
  pedidoMencionado: null,
  pedidosEventos: [],
  observaciones: [],
  consultas: [],
};

beforeEach(() => obtener.mockReset());

describe('ModalFichaCliente', () => {
  it('busca con los datos de la consulta y muestra hijos, kit y pago', async () => {
    obtener.mockResolvedValue(ficha);
    render(<ModalFichaCliente inicial={{ nombre: 'Laura', email: 'laura@mail.com', telefono: '', pedido: '' }} onCerrar={() => {}} />);
    expect(obtener).toHaveBeenCalledWith({ email: 'laura@mail.com', telefono: '', pedido: '' });
    expect((await screen.findAllByText('Tomás Paz', { exact: false })).length).toBeGreaterThan(0);
    expect(screen.getByText('Kit Impreso')).toBeTruthy();
    expect(screen.getByText('Pagó')).toBeTruthy();
    expect(screen.getByText('En la nómina figura en 3° grado · B · Mañana')).toBeTruthy();
    expect(screen.getByText('$30.000', { selector: 'dd' })).toBeTruthy();
  });

  it('permite buscar con otro email y avisa si no encuentra nada', async () => {
    obtener.mockResolvedValueOnce(ficha).mockResolvedValueOnce({ ...ficha, encontrado: false, inscripciones: [], hijos: [], pedidos: [] });
    render(<ModalFichaCliente inicial={{ email: 'laura@mail.com' }} onCerrar={() => {}} />);
    await screen.findByText('Kit Impreso');
    const email = screen.getByLabelText('Email');
    await userEvent.clear(email);
    await userEvent.type(email, 'otro@mail.com');
    await userEvent.click(screen.getByRole('button', { name: /Buscar/ }));
    await waitFor(() => expect(obtener).toHaveBeenLastCalledWith({ email: 'otro@mail.com', telefono: '', pedido: '' }));
    expect(await screen.findByText(/No hay inscripciones, compras ni pedidos/)).toBeTruthy();
  });
});
