import { render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { beforeEach, describe, expect, it, vi } from 'vitest';
import ReservaKitAnticipada from '../ReservaKitAnticipada';

// Pedido de Pablo (27/9): con un hermano con fotos (Benjamin) y otro sin fotos (Sofia),
// 1) el kit de Sofia no viene preelegido: hay que elegir sí o sí una de las 3 opciones;
// 2) si las fotos de Benjamin ya están elegidas, el botón va directo al pago (no a su galería).
vi.mock('../../services/reservasService', async (original) => {
  const real = await original<typeof import('../../services/reservasService')>();
  return {
    ...real,
    obtenerEstadoReserva: vi.fn(async (_codigo: string, nombre: string) => ({
      ok: true,
      reserva: null,
      fotosDisponibles: nombre === 'Benjamin',
      tienePedidoPagado: false,
    })),
  };
});
vi.mock('../../services/mediosPagoService', () => ({ useNaveHabilitado: () => false }));

const hijos = [
  { id: 'b', nombreCompleto: 'Benjamin', codigoSeccion: 'AAAA-1111' },
  { id: 's', nombreCompleto: 'Sofia', codigoSeccion: 'BBBB-2222' },
];

describe('ReservaKitAnticipada — hermano con fotos + hermano sin fotos', () => {
  beforeEach(() => vi.clearAllMocks());

  it('exige elegir una opción para el kit del hermano sin fotos', async () => {
    const onSumar = vi.fn();
    render(<ReservaKitAnticipada hijos={hijos} tutorNombre="Pablo" tutorEmail="p@x.com" onSumarALaCompra={onSumar} />);
    const boton = await screen.findByRole('button', { name: /elegí una opción para sofia/i });
    expect(boton).toBeDisabled();
    await userEvent.click(screen.getByText('Ahora no'));
    const continuar = await screen.findByRole('button', { name: /continuar con las fotos de benjamin/i });
    await userEvent.click(continuar);
    expect(onSumar).toHaveBeenCalledWith([], 'b', ['s']);
  });

  it('con las fotos del hermano ya elegidas, suma el kit y va directo al pago', async () => {
    const onSumar = vi.fn();
    render(
      <ReservaKitAnticipada hijos={hijos} tutorNombre="Pablo" tutorEmail="p@x.com" onSumarALaCompra={onSumar} hijosConFotosElegidas={['b']} />
    );
    await screen.findByRole('button', { name: /elegí una opción para sofia/i });
    await userEvent.click(screen.getByText('Solo Digital HD'));
    const boton = await screen.findByRole('button', { name: /sumar a la compra e ir a pagar/i });
    await userEvent.click(boton);
    await waitFor(() => expect(onSumar).toHaveBeenCalledTimes(1));
    const [reservas, destino, decididos] = onSumar.mock.calls[0];
    expect(reservas).toHaveLength(1);
    expect(reservas[0]).toMatchObject({ hijoId: 's', kitId: 'kit-digital' });
    expect(destino).toBe('b');
    expect(decididos).toEqual(['s']);
  });

  it('suma copias extra de la carpeta al Kit Impreso por adelantado (27/9)', async () => {
    const onSumar = vi.fn();
    render(
      <ReservaKitAnticipada hijos={hijos} tutorNombre="Pablo" tutorEmail="p@x.com" onSumarALaCompra={onSumar} hijosConFotosElegidas={['b']} />
    );
    await screen.findByRole('button', { name: /elegí una opción para sofia/i });
    await userEvent.click(screen.getByText('Kit Impreso + Digital'));
    await userEvent.click(screen.getByRole('button', { name: /sumar carpeta extra de sofia/i }));
    await userEvent.click(await screen.findByRole('button', { name: /sumar a la compra e ir a pagar · \$45\.000/i }));
    expect(onSumar.mock.calls[0][0][0]).toMatchObject({ hijoId: 's', kitId: 'kit-clasico', carpetasExtras: 1, precio: 45000 });
  });
});
