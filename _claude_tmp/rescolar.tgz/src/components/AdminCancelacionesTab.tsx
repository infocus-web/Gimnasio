import { useCallback, useEffect, useState } from 'react';
import { CheckCircle2, Loader2, RefreshCw, RotateCcw, XCircle } from 'lucide-react';
import { fetchAdminAutenticado } from '../services/adminAuthService';
import { useBorradorAdmin } from '../utils/useBorradorAdmin';

interface PedidoCancelacion {
  id: string;
  pedido_friendly_id: string;
  estado: string;
  total: number | string;
  metodo_pago: string | null;
  mp_payment_id: string | null;
  kit_nombre: string | null;
  alumno_nombre: string | null;
  colegio_nombre: string | null;
  seleccion_pendiente: boolean | null;
  email_enviado: boolean | null;
  created_at: string;
  pagado_at?: string | null;
}

interface Solicitud {
  id: string;
  created_at: string;
  codigo: string;
  pedido_ref: string;
  nombre: string;
  email: string;
  motivo: string | null;
  estado: 'nueva' | 'aceptada' | 'rechazada_excepcion' | 'resuelta';
  nota_admin: string | null;
  atendida_at: string | null;
  pedidos: PedidoCancelacion | null;
}

const DIA = 24 * 60 * 60 * 1000;
const fecha = (iso: string) => new Date(iso).toLocaleDateString('es-AR', { day: '2-digit', month: '2-digit', year: '2-digit' });
const monto = (v: unknown) => `$${Math.round(Number(v) || 0).toLocaleString('es-AR')}`;

/**
 * Pestaña "Cancelaciones" (auditoría 28/9): solicitudes hechas desde el link del pie de la web.
 * Muestra el pedido, si ya está dentro de los 10 días y si aplica alguna excepción (fotos
 * confirmadas del kit impreso o descarga digital ya enviada), y permite responder desde acá.
 */
export default function AdminCancelacionesTab() {
  const [solicitudes, setSolicitudes] = useState<Solicitud[]>([]);
  const [cargando, setCargando] = useState(true);
  const [error, setError] = useState('');
  const [verResueltas, setVerResueltas] = useState(false);
  const [trabajando, setTrabajando] = useState<string | null>(null);
  // 14/10/2026: las notas a medio escribir se guardan solas (borrador «cancelaciones-notas»).
  const [notas, setNotas] = useBorradorAdmin<Record<string, string>>('cancelaciones-notas', {});
  const [mensaje, setMensaje] = useState('');

  const cargar = useCallback(async () => {
    setCargando(true);
    setError('');
    try {
      const res = await fetchAdminAutenticado('/api/admin/cancelaciones');
      const data = await res.json();
      if (!data?.success) throw new Error(data?.error || 'No se pudieron traer las cancelaciones.');
      setSolicitudes(data.solicitudes || []);
    } catch (e: any) {
      setError(e?.message || 'Error de conexión.');
    }
    setCargando(false);
  }, []);

  useEffect(() => {
    void cargar();
  }, [cargar]);

  const resolver = async (s: Solicitud, accion: 'aprobar' | 'rechazar', devolverPorMercadoPago = false) => {
    const nota = (notas[s.id] || '').trim();
    if (accion === 'rechazar' && nota.length < 5) {
      setMensaje('Para rechazar, escribí el motivo en el cuadro: se lo mandamos a la familia.');
      return;
    }
    if (devolverPorMercadoPago && !window.confirm(`¿Devolver ${monto(s.pedidos?.total)} por Mercado Pago y cancelar el pedido ${s.pedido_ref}?`)) return;
    // Auditoría 03/10 noche: aprobar sin devolución automática también cancela el pedido para
    // siempre (no vuelve solo a pagado): antes se hacía con un solo toque, sin confirmar.
    if (
      accion === 'aprobar' &&
      !devolverPorMercadoPago &&
      !window.confirm(
        `¿Aprobar la cancelación ${s.codigo} y cancelar DEFINITIVAMENTE el pedido ${s.pedido_ref}?\n\n` +
          `El sistema NO devuelve la plata: la devolución de ${monto(s.pedidos?.total)} la hacés vos a mano. ` +
          `La familia recibe el email de aprobación y el pedido ya no se puede reactivar solo.`
      )
    )
      return;
    setTrabajando(s.id);
    setMensaje('');
    try {
      const res = await fetchAdminAutenticado(`/api/admin/cancelaciones/${encodeURIComponent(s.id)}/resolver`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ accion, nota, devolverPorMercadoPago }),
      });
      const data = await res.json();
      if (!data?.success) throw new Error(data?.error || 'No se pudo resolver.');
      setNotas((actuales) => Object.fromEntries(Object.entries(actuales).filter(([id]) => id !== s.id))); // ya se usó: sale del borrador
      // 14/10/2026 (auditoría): «la familia recibió el email» sólo si el servidor lo confirmó (`emailEnviado`).
      const avisoEmail = data.emailEnviado === true
        ? (accion === 'aprobar' ? ' La familia recibió el email.' : ' La familia recibió el motivo por email.')
        : ' Quedó registrado; el email a la familia no se pudo confirmar (escribile por otro medio).';
      setMensaje(
        accion === 'aprobar'
          ? `Listo: ${s.codigo} aprobada${data.devolucion?.hecha ? ` y devueltos ${monto(data.devolucion.monto)} por Mercado Pago` : ''}.${avisoEmail}`
          : `Listo: ${s.codigo} respondida.${avisoEmail}`
      );
      await cargar();
    } catch (e: any) {
      setMensaje(e?.message || 'Error de conexión.');
    }
    setTrabajando(null);
  };

  const nuevas = solicitudes.filter((s) => s.estado === 'nueva');
  const visibles = verResueltas ? solicitudes : nuevas;

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div>
          <h3 className="text-lg font-extrabold text-slate-900 font-['Outfit']">Cancelaciones</h3>
          <p className="text-xs text-slate-500">Solicitudes del link del pie de la web. Tenés que responder cada una dentro de los 10 días.</p>
        </div>
        <div className="flex items-center gap-2">
          <label className="flex items-center gap-1.5 text-xs text-slate-600">
            <input type="checkbox" checked={verResueltas} onChange={(e) => setVerResueltas(e.target.checked)} /> Ver también las resueltas
          </label>
          <button type="button" onClick={() => void cargar()} className="inline-flex items-center gap-1.5 rounded-lg border border-slate-200 px-3 py-1.5 text-xs font-bold text-slate-700 hover:bg-slate-50">
            <RefreshCw className="h-3.5 w-3.5" /> Actualizar
          </button>
        </div>
      </div>

      {mensaje && <p className="rounded-xl bg-slate-900 px-4 py-2.5 text-xs font-semibold text-white">{mensaje}</p>}
      {error && <p className="rounded-xl bg-red-50 px-4 py-2.5 text-xs font-semibold text-red-700">{error}</p>}

      {cargando ? (
        <div className="py-10 text-center text-slate-400">
          <Loader2 className="mx-auto h-6 w-6 animate-spin" />
        </div>
      ) : visibles.length === 0 ? (
        <p className="rounded-2xl border border-dashed border-slate-200 py-10 text-center text-sm text-slate-400">
          {verResueltas ? 'Todavía no hubo solicitudes.' : 'No hay solicitudes pendientes.'}
        </p>
      ) : (
        <div className="space-y-3">
          {visibles.map((s) => {
            const p = s.pedidos;
            // Auditoría 11/10: el plazo corre desde el pago hasta el día de la SOLICITUD (no hasta hoy).
            const diasDesdeCompra = p ? Math.floor((new Date(s.created_at).getTime() - new Date(p.pagado_at || p.created_at).getTime()) / DIA) : null;
            const fueraDePlazo = diasDesdeCompra !== null && diasDesdeCompra > 10;
            const fotosConfirmadas = Boolean(p && p.seleccion_pendiente === false && (p.kit_nombre || '').toLowerCase().includes('impreso'));
            const digitalEnviado = Boolean(p?.email_enviado && p?.seleccion_pendiente === false);
            const puedeDevolverMP = Boolean(p && p.estado === 'pagado' && p.metodo_pago === 'mercadopago' && p.mp_payment_id);
            const vencimiento = new Date(new Date(s.created_at).getTime() + 10 * DIA);
            return (
              <div key={s.id} className={`rounded-2xl border p-4 text-xs ${s.estado === 'nueva' ? 'border-amber-300 bg-amber-50/40' : 'border-slate-200 bg-white'}`}>
                <div className="flex flex-wrap items-start justify-between gap-2">
                  <div>
                    <p className="font-mono text-sm font-black text-slate-900">{s.codigo}</p>
                    <p className="text-slate-600">
                      {s.nombre} · {s.email} · pedida el {fecha(s.created_at)}
                    </p>
                  </div>
                  {s.estado === 'nueva' ? (
                    <span className="rounded-full bg-amber-200 px-2.5 py-1 text-[10px] font-bold text-amber-900">Responder antes del {fecha(vencimiento.toISOString())}</span>
                  ) : (
                    <span className={`rounded-full px-2.5 py-1 text-[10px] font-bold ${s.estado === 'aceptada' ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-200 text-slate-700'}`}>
                      {s.estado === 'aceptada' ? 'Aprobada' : 'Rechazada'} {s.atendida_at ? `el ${fecha(s.atendida_at)}` : ''}
                    </span>
                  )}
                </div>

                <div className="mt-2 rounded-xl bg-white p-3 ring-1 ring-slate-200">
                  {p ? (
                    <>
                      <p className="font-bold text-slate-800">
                        Pedido {p.pedido_friendly_id} · {p.alumno_nombre} · {p.kit_nombre} · {monto(p.total)}
                      </p>
                      <p className="text-slate-500">
                        {p.colegio_nombre} · {p.pagado_at ? 'pagado' : 'comprado'} el {fecha(p.pagado_at || p.created_at)} (pidió la cancelación {diasDesdeCompra} días después) · estado: {p.estado} · pago: {p.metodo_pago || '—'}
                      </p>
                      <div className="mt-1.5 flex flex-wrap gap-1.5">
                        {fueraDePlazo && <span className="rounded-full bg-red-100 px-2 py-0.5 text-[10px] font-bold text-red-700">La pidió pasados los 10 días del pago</span>}
                        {fotosConfirmadas && <span className="rounded-full bg-red-100 px-2 py-0.5 text-[10px] font-bold text-red-700">Kit impreso con fotos confirmadas (personalizado)</span>}
                        {digitalEnviado && <span className="rounded-full bg-red-100 px-2 py-0.5 text-[10px] font-bold text-red-700">Descarga digital ya enviada</span>}
                        {!fueraDePlazo && !fotosConfirmadas && !digitalEnviado && (
                          <span className="rounded-full bg-emerald-100 px-2 py-0.5 text-[10px] font-bold text-emerald-800">Corresponde devolver el total</span>
                        )}
                      </div>
                    </>
                  ) : (
                    <p className="font-semibold text-red-700">
                      No encontramos el pedido "{s.pedido_ref}" con ese email. Revisalo a mano antes de responder.
                    </p>
                  )}
                  {s.motivo && <p className="mt-1.5 italic text-slate-600">"{s.motivo}"</p>}
                  {s.nota_admin && s.estado !== 'nueva' && <p className="mt-1.5 text-slate-600">Tu respuesta: {s.nota_admin}</p>}
                </div>

                {s.estado === 'nueva' && (
                  <div className="mt-3 space-y-2">
                    <textarea
                      value={notas[s.id] || ''}
                      onChange={(e) => setNotas((n) => ({ ...n, [s.id]: e.target.value }))}
                      rows={2}
                      placeholder="Mensaje para la familia (obligatorio si rechazás, opcional si aprobás)"
                      className="w-full rounded-xl border border-slate-300 px-3 py-2 text-xs"
                    />
                    <div className="flex flex-wrap gap-2">
                      {puedeDevolverMP && (
                        <button
                          type="button"
                          disabled={trabajando === s.id}
                          onClick={() => void resolver(s, 'aprobar', true)}
                          className="inline-flex items-center gap-1.5 rounded-lg bg-[#009EE3] px-3 py-2 font-bold text-white hover:brightness-110 disabled:opacity-60"
                        >
                          {trabajando === s.id ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <RotateCcw className="h-3.5 w-3.5" />}
                          Aprobar y devolver por Mercado Pago
                        </button>
                      )}
                      <button
                        type="button"
                        disabled={trabajando === s.id}
                        onClick={() => void resolver(s, 'aprobar')}
                        className="inline-flex items-center gap-1.5 rounded-lg bg-emerald-600 px-3 py-2 font-bold text-white hover:bg-emerald-500 disabled:opacity-60"
                      >
                        <CheckCircle2 className="h-3.5 w-3.5" /> {puedeDevolverMP ? 'Aprobar (devuelvo yo a mano)' : 'Aprobar (devuelvo por transferencia)'}
                      </button>
                      <button
                        type="button"
                        disabled={trabajando === s.id}
                        onClick={() => void resolver(s, 'rechazar')}
                        className="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3 py-2 font-bold text-slate-700 hover:bg-slate-50 disabled:opacity-60"
                      >
                        <XCircle className="h-3.5 w-3.5" /> Rechazar con motivo
                      </button>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
