import { useState } from 'react';
import { AlertTriangle, Bot, CheckCircle2, ChevronDown, RefreshCw } from 'lucide-react';
import type { ConsultaFamilia } from '../services/consultasFamiliasService';

// 25/10/2026 (Pablo: «todo ese panel en verde ocupa la mayor parte del mensaje»). La revisión automática de los datos
// de la familia va plegada en una línea de resumen; lo que hay que revisar (chequeos en rojo) se ve siempre, y el
// detalle (fotos, pedidos, aviso, buscador) se abre con un clic. «Revisar de nuevo» queda en la misma línea.

/** «2 pedidos pagados», «1 pedido» … a partir de las líneas de datos de la ficha. */
export function resumenPedidos(datos: string[]): string {
  const pedidos = datos.filter((d) => /^Pedido /.test(d));
  if (pedidos.length === 0) return 'sin pedidos';
  const pagados = pedidos.filter((d) => /pago "pagado"/.test(d)).length;
  return `${pedidos.length} pedido${pedidos.length === 1 ? '' : 's'}${pagados === pedidos.length ? (pedidos.length === 1 ? ' pagado' : ' pagados') : pagados > 0 ? ` (${pagados} pagado${pagados === 1 ? '' : 's'})` : ''}`;
}

interface Props {
  consulta: ConsultaFamilia;
  revisando: boolean;
  onRevisar: () => void;
}

export default function RevisionConsultaIA({ consulta, revisando, onRevisar }: Props) {
  const [abierta, setAbierta] = useState(false);
  const v = consulta.verificacionIa;
  if (!v) return null;
  const problemas = v.chequeos.filter((c) => !c.ok);
  const chicos = v.chequeos.filter((c) => /coincide con la nómina|no figura en la nómina|figura en .* nómina/.test(c.texto)).length;
  const estadoEnvio = v.enviadaAutomaticamente
    ? '✅ Se respondió automáticamente.'
    : consulta.borradorIa
      ? `✍️ Borrador listo para revisar — tocá "Responder". ${v.motivoNoEnvio || ''}`
      : v.motivoNoEnvio || v.motivo || '';

  return (
    <div className={`mt-3 rounded-xl border px-3 py-2 ${problemas.length === 0 ? 'border-emerald-200 bg-emerald-50/50' : 'border-amber-300 bg-amber-50/70'}`}>
      <div className="flex flex-wrap items-center justify-between gap-2">
        <button type="button" onClick={() => setAbierta(!abierta)} aria-expanded={abierta} className="flex min-w-0 flex-1 items-center gap-1.5 text-left text-[11px] font-bold text-slate-800 cursor-pointer">
          <Bot className="h-3.5 w-3.5 shrink-0" />
          {problemas.length === 0
            ? <span className="text-emerald-800">✓ Datos de la familia en orden</span>
            : <span className="text-amber-900">⚠ {problemas.length} cosa{problemas.length === 1 ? '' : 's'} para revisar</span>}
          <span className="font-normal text-slate-500 truncate">
            {!v.encontrada ? '· no encontramos inscripción con este email' : `· ${chicos > 0 ? `${chicos} chico${chicos === 1 ? '' : 's'} · ` : ''}${resumenPedidos(v.datos)}`}
            {consulta.procesadaIaAt && ` · revisado ${new Date(consulta.procesadaIaAt).toLocaleString('es-AR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit', hourCycle: 'h23' })}`}
          </span>
          <ChevronDown className={`h-3.5 w-3.5 shrink-0 text-slate-400 transition-transform ${abierta ? 'rotate-180' : ''}`} />
          <span className="sr-only">{abierta ? 'Ocultar detalle' : 'Ver detalle'}</span>
        </button>
        <button type="button" disabled={revisando} onClick={onRevisar} title="Vuelve a mirar la inscripción, el curso y los pedidos de la familia y redacta un borrador nuevo (reemplaza el que hay). No envía nada." className="inline-flex items-center gap-1 rounded-lg border border-slate-300 bg-white px-2 py-1 text-[11px] font-bold text-slate-700 hover:bg-slate-50 disabled:cursor-not-allowed disabled:opacity-50 cursor-pointer">
          <RefreshCw className={`h-3 w-3 ${revisando ? 'animate-spin' : ''}`} />
          {revisando ? 'Revisando...' : 'Revisar de nuevo'}
        </button>
      </div>
      {problemas.length > 0 && (
        <ul className="mt-1.5 space-y-1">
          {problemas.map((chequeo, i) => (
            <li key={i} className="flex items-start gap-1.5 text-[11px] text-slate-800">
              <AlertTriangle className="h-3.5 w-3.5 text-amber-600 shrink-0 mt-px" />
              <span>{chequeo.texto}</span>
            </li>
          ))}
        </ul>
      )}
      {abierta && (
        <div className="mt-2 border-t border-black/5 pt-2">
          <ul className="space-y-1">
            {v.chequeos.filter((c) => c.ok).map((chequeo, i) => (
              <li key={i} className="flex items-start gap-1.5 text-[11px] text-slate-700">
                <CheckCircle2 className="h-3.5 w-3.5 text-emerald-600 shrink-0 mt-px" />
                <span>{chequeo.texto}</span>
              </li>
            ))}
          </ul>
          {v.datos.length > 0 && (
            <ul className="mt-1.5 space-y-0.5">
              {v.datos.map((dato, i) => (
                <li key={i} className="text-[11px] text-slate-500">• {dato}</li>
              ))}
            </ul>
          )}
          {estadoEnvio && <p className="mt-1.5 text-[11px] font-semibold text-slate-700">{estadoEnvio}</p>}
        </div>
      )}
    </div>
  );
}
