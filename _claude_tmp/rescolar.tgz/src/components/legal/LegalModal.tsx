import { useEffect, useState, type FormEvent } from 'react';
import { CheckCircle2, Loader2, RotateCcw, X } from 'lucide-react';
import { DOCUMENTOS_LEGALES, PROVEEDOR, VERSION_TERMINOS } from '../../legal/textosLegales';
import { EVENTO_ABRIR_LEGAL, type PestanaLegal } from '../../legal/aceptacion';
import { enviarSolicitudArrepentimiento } from '../../services/arrepentimientoService';

const PESTANAS: { id: PestanaLegal; nombre: string }[] = [
  { id: 'arrepentimiento', nombre: 'Cancelar una compra' },
  { id: 'terminos', nombre: 'Términos y Condiciones' },
  { id: 'privacidad', nombre: 'Privacidad' },
  { id: 'licencia', nombre: 'Licencia de uso' },
];

const esPestana = (v: unknown): v is PestanaLegal => PESTANAS.some((p) => p.id === v);

/**
 * Ventana con los textos legales y el Botón de arrepentimiento (marco legal 27/9). Se abre desde el
 * header, el footer, los avisos antes de pagar (abrirLegal) o con "?legal=<pestaña>" en la URL, así
 * los emails pueden enlazar directo (ej. retratoescolar.com.ar/?legal=arrepentimiento).
 */
export default function LegalModal() {
  const [pestana, setPestana] = useState<PestanaLegal | null>(() => {
    if (typeof window === 'undefined') return null;
    const valor = new URLSearchParams(window.location.search).get('legal');
    return esPestana(valor) ? valor : null;
  });

  useEffect(() => {
    const abrir = (e: Event) => {
      const detalle = (e as CustomEvent<PestanaLegal>).detail;
      setPestana(esPestana(detalle) ? detalle : 'terminos');
    };
    window.addEventListener(EVENTO_ABRIR_LEGAL, abrir);
    return () => window.removeEventListener(EVENTO_ABRIR_LEGAL, abrir);
  }, []);

  useEffect(() => {
    if (!pestana) return;
    const cerrarConEsc = (e: KeyboardEvent) => e.key === 'Escape' && setPestana(null);
    window.addEventListener('keydown', cerrarConEsc);
    return () => window.removeEventListener('keydown', cerrarConEsc);
  }, [pestana]);

  if (!pestana) return null;
  const documento = DOCUMENTOS_LEGALES.find((d) => d.id === pestana);

  return (
    // z por encima del portal de familias (que también es un modal): se abre desde el paso de pago.
    <div className="fixed inset-0 z-[150] flex items-center justify-center bg-slate-950/70 p-0 sm:p-4" role="dialog" aria-modal="true" aria-labelledby="legal-titulo" onClick={() => setPestana(null)}>
      <div className="flex h-full w-full max-w-3xl flex-col overflow-hidden bg-white shadow-2xl sm:h-auto sm:max-h-[92vh] sm:rounded-3xl" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between gap-3 border-b border-slate-200 px-5 py-3">
          <p id="legal-titulo" className="font-['Outfit'] text-lg font-extrabold text-slate-900">
            {documento ? documento.titulo : 'Cancelar una compra'}
          </p>
          <button type="button" onClick={() => setPestana(null)} aria-label="Cerrar" className="rounded-lg p-2 text-slate-500 hover:bg-slate-100">
            <X className="h-5 w-5" />
          </button>
        </div>
        <div className="flex shrink-0 flex-wrap items-center gap-1 border-b border-slate-200 px-3 py-2">
          {PESTANAS.map((p) => (
            <button
              key={p.id}
              type="button"
              onClick={() => setPestana(p.id)}
              className={`inline-flex h-8 shrink-0 items-center whitespace-nowrap rounded-lg px-3 text-xs font-bold leading-none ${pestana === p.id ? 'bg-slate-900 text-white' : 'text-slate-600 hover:bg-slate-100'}`}
            >
              {p.nombre}
            </button>
          ))}
        </div>
        <div className="flex-1 overflow-y-auto px-5 py-4 text-left text-sm leading-relaxed text-slate-700">
          {documento ? (
            <>
              <p className="mb-4 rounded-xl bg-slate-50 p-3 text-xs text-slate-600">{documento.resumen}</p>
              {documento.secciones.map((s) => (
                <section key={s.titulo} className="mb-4">
                  <h3 className="mb-1 font-bold text-slate-900">{s.titulo}</h3>
                  {s.parrafos.map((texto, i) => (
                    <p key={i} className="mb-1.5">{texto}</p>
                  ))}
                </section>
              ))}
              <p className="mt-6 border-t border-slate-200 pt-3 text-[11px] text-slate-500">
                Versión {VERSION_TERMINOS} · {PROVEEDOR.empresa} ({PROVEEDOR.marca}) · {PROVEEDOR.email}
              </p>
            </>
          ) : (
            <FormularioArrepentimiento />
          )}
        </div>
      </div>
    </div>
  );
}

function FormularioArrepentimiento() {
  const [pedido, setPedido] = useState('');
  const [nombre, setNombre] = useState('');
  const [email, setEmail] = useState('');
  const [motivo, setMotivo] = useState('');
  const [enviando, setEnviando] = useState(false);
  const [error, setError] = useState('');
  const [resultado, setResultado] = useState<{ codigo: string; pedidoEncontrado: boolean; emailEnviado: boolean } | null>(null);

  const enviar = async (e: FormEvent) => {
    e.preventDefault();
    setError('');
    setEnviando(true);
    const r = await enviarSolicitudArrepentimiento({ pedido, nombre, email, motivo });
    setEnviando(false);
    if (r.success && r.codigo) setResultado({ codigo: r.codigo, pedidoEncontrado: Boolean(r.pedidoEncontrado), emailEnviado: r.emailEnviado === true });
    else setError(r.error || 'No pudimos registrar tu solicitud.');
  };

  if (resultado) {
    return (
      <div className="space-y-3">
        <p className="flex items-center gap-2 font-bold text-emerald-700">
          <CheckCircle2 className="h-5 w-5" /> Registramos tu solicitud
        </p>
        <p className="rounded-xl border-2 border-emerald-300 bg-emerald-50 p-4 text-center">
          <span className="block text-xs text-emerald-800">Código de tu solicitud</span>
          <span className="block font-mono text-2xl font-black text-emerald-900">{resultado.codigo}</span>
        </p>
        {/* Auditoría 03/10: sólo se dice "te lo mandamos por email" si el servidor confirma el envío. */}
        {resultado.emailEnviado ? (
          <p className="text-xs">
            Guardalo: identifica tu trámite. También te lo mandamos por email a <strong>{email}</strong>. Vamos a revisar tu pedido y te respondemos por ese
            medio. Si corresponde, te devolvemos el dinero por el mismo medio con el que pagaste.
          </p>
        ) : (
          <p className="text-xs">
            Guardalo: identifica tu trámite. Tu solicitud quedó registrada; vamos a revisar tu pedido y nos comunicamos con vos por el email del pedido. Si
            corresponde, te devolvemos el dinero por el mismo medio con el que pagaste.
          </p>
        )}
        {!resultado.pedidoEncontrado && (
          <p className="rounded-xl bg-amber-50 p-3 text-xs text-amber-900">
            No encontramos un pedido con ese número y ese email. Igual quedó registrada: la revisamos a mano y, si hace falta, te pedimos algún dato por email.
          </p>
        )}
      </div>
    );
  }

  const campo = 'mt-1 w-full rounded-xl border border-slate-300 px-3 py-2 text-sm';
  return (
    <form onSubmit={(e) => void enviar(e)} className="space-y-3">
      <div className="flex items-start gap-2 rounded-xl bg-slate-50 p-3 text-xs">
        <RotateCcw className="mt-0.5 h-4 w-4 shrink-0 text-slate-500" />
        <span>
          Si pagaste por adelantado y <strong>todavía no elegiste tus fotos</strong>, tenés <strong>10 días corridos</strong> para cancelar sin dar explicaciones y te
          devolvemos todo (Ley 24.240, art. 34). Una vez elegidas las fotos, el kit se arma con ellas y los archivos se envían al instante, así que ya no se puede
          cancelar (Código Civil y Comercial, art. 1116). No hace falta registrarse: completá estos datos y te damos un código de solicitud en el momento.
        </span>
      </div>
      <label className="block text-xs font-bold text-slate-700">
        Número de pedido
        <input value={pedido} onChange={(e) => setPedido(e.target.value)} className={`${campo} font-mono uppercase`} placeholder="IFS-2026-1234" required />
        <span className="font-normal text-slate-500">Está en el email de confirmación de tu compra.</span>
      </label>
      <label className="block text-xs font-bold text-slate-700">
        Nombre y apellido
        <input value={nombre} onChange={(e) => setNombre(e.target.value)} className={campo} required />
      </label>
      <label className="block text-xs font-bold text-slate-700">
        Email con el que compraste
        <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} className={campo} required />
      </label>
      <label className="block text-xs font-bold text-slate-700">
        Comentario (opcional)
        <textarea value={motivo} onChange={(e) => setMotivo(e.target.value)} rows={2} maxLength={1000} className={campo} />
      </label>
      {error && <p className="text-xs font-semibold text-red-600">{error}</p>}
      <button type="submit" disabled={enviando} className="inline-flex w-full items-center justify-center gap-2 rounded-xl bg-slate-900 px-5 py-3 text-sm font-bold text-white hover:bg-slate-800 disabled:opacity-60">
        {enviando ? <Loader2 className="h-4 w-4 animate-spin" /> : <RotateCcw className="h-4 w-4" />}
        Enviar solicitud de cancelación
      </button>
    </form>
  );
}
