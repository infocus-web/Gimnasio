import { Scale } from 'lucide-react';
import { AVISO_ANTES_DE_PAGAR, AVISO_COMPRA_CON_FOTOS } from '../../legal/textosLegales';
import { abrirLegal, marcarTerminosAceptados } from '../../legal/aceptacion';

interface Props {
  aceptado: boolean;
  onCambiar: (aceptado: boolean) => void;
  /** Compra normal con las fotos ya elegidas (no pago anticipado): suma el aviso del art. 1116. */
  conFotosElegidas?: boolean;
  variante?: 'claro' | 'oscuro';
  id?: string;
  /** Se tocó pagar sin tildar la casilla: se resalta en rojo con un aviso. */
  resaltar?: boolean;
}

/**
 * Recuadro destacado inmediatamente antes del botón de pago (CCyC art. 1111: el derecho de
 * revocación se informa "en caracteres destacados" antes de la aceptación) + casilla obligatoria,
 * sin premarcar. Ver src/legal/textosLegales.ts.
 */
export default function AceptacionTerminos({ aceptado, onCambiar, conFotosElegidas, variante = 'claro', id = 'chk-acepta-terminos', resaltar = false }: Props) {
  const marcarRojo = resaltar && !aceptado;
  const oscuro = variante === 'oscuro';
  const link = oscuro ? 'font-bold text-amber-300 underline' : 'font-bold text-amber-800 underline';
  return (
    <div
      className={`rounded-xl border-2 p-3 text-left text-[11px] leading-relaxed ${
        oscuro ? 'border-amber-400/70 bg-slate-800 text-slate-200' : 'border-amber-400 bg-amber-50 text-slate-800'
      }`}
    >
      <p className={`mb-1 flex items-center gap-1.5 text-xs font-extrabold ${oscuro ? 'text-amber-300' : 'text-amber-900'}`}>
        <Scale className="h-4 w-4 shrink-0" aria-hidden="true" />
        Condiciones de tu compra
      </p>
      {/* 2/10: primero, sin vueltas, si se puede cancelar o no (según haya fotos elegidas). */}
      <p>
        <strong>¿Puedo cancelar?</strong> {conFotosElegidas ? AVISO_COMPRA_CON_FOTOS : AVISO_ANTES_DE_PAGAR.arrepentimiento}
      </p>
      <p className="mt-1.5">
        <strong>Cambios de kit.</strong> {AVISO_ANTES_DE_PAGAR.cambios}
      </p>
      <p className="mt-1.5">
        <strong>Entrega.</strong> {AVISO_ANTES_DE_PAGAR.entrega}
      </p>
      <label htmlFor={id} className={`mt-2.5 flex cursor-pointer items-start gap-2 rounded-lg p-2 ${oscuro ? 'bg-slate-900/60' : 'bg-white'} ${marcarRojo ? 'ring-2 ring-red-500' : ''}`}>
        <input
          id={id}
          type="checkbox"
          checked={aceptado}
          onChange={(e) => {
            marcarTerminosAceptados(e.target.checked);
            onCambiar(e.target.checked);
          }}
          className="mt-0.5 h-4 w-4 shrink-0 cursor-pointer rounded accent-amber-500"
        />
        <span className={`font-semibold ${oscuro ? 'text-white' : 'text-slate-900'}`}>
          Leí y acepto los{' '}
          <button type="button" onClick={(e) => { e.preventDefault(); abrirLegal('terminos'); }} className={link}>Términos y Condiciones</button>, la{' '}
          <button type="button" onClick={(e) => { e.preventDefault(); abrirLegal('privacidad'); }} className={link}>Política de Privacidad</button> y la{' '}
          <button type="button" onClick={(e) => { e.preventDefault(); abrirLegal('licencia'); }} className={link}>Licencia de uso de las fotos</button>.
        </span>
      </label>
      {marcarRojo && (
        <p role="alert" className={`mt-1.5 text-xs font-bold ${oscuro ? 'text-red-300' : 'text-red-600'}`}>
          Tildá esta casilla para continuar con el pago.
        </p>
      )}
    </div>
  );
}
