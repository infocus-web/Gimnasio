import { ShieldCheck } from 'lucide-react';
import { CONSENTIMIENTOS_INSCRIPCION, type IdConsentimiento } from '../../legal/textosLegales';
import { abrirLegal } from '../../legal/aceptacion';

export type EstadoConsentimientos = Record<IdConsentimiento, boolean>;

export const CONSENTIMIENTOS_VACIOS: EstadoConsentimientos = { toma: false, grupal: false, transferencia: false, promocional: false };

export const faltanConsentimientosObligatorios = (c: EstadoConsentimientos) =>
  CONSENTIMIENTOS_INSCRIPCION.some((item) => item.obligatorio && !c[item.id]);

/**
 * Autorizaciones de imagen y datos en la inscripción (marco legal 27/9): una casilla por cada
 * cosa, ninguna premarcada. CCyC art. 53 y Ley 11.723 art. 31 (imagen), Ley 25.326 arts. 5, 6 y 12
 * (datos y transferencia internacional). La promocional es opcional y revocable.
 */
export default function ConsentimientosInscripcion({ valor, onCambiar }: { valor: EstadoConsentimientos; onCambiar: (v: EstadoConsentimientos) => void }) {
  return (
    <fieldset className="space-y-2 rounded-xl border-2 border-amber-300 bg-amber-50/60 p-3 text-left">
      <legend className="flex items-center gap-1.5 px-1 text-xs font-extrabold text-slate-900">
        <ShieldCheck className="h-4 w-4 text-emerald-600" aria-hidden="true" />
        Autorizaciones (fotos de tu hijo/a y tus datos)
      </legend>
      {CONSENTIMIENTOS_INSCRIPCION.map((item) => (
        <label key={item.id} htmlFor={`consentimiento-${item.id}`} className="flex cursor-pointer items-start gap-2 rounded-lg bg-white p-2 text-[11px] leading-snug text-slate-800">
          <input
            id={`consentimiento-${item.id}`}
            type="checkbox"
            checked={valor[item.id]}
            onChange={(e) => onCambiar({ ...valor, [item.id]: e.target.checked })}
            className="mt-0.5 h-4 w-4 shrink-0 cursor-pointer rounded accent-amber-500"
          />
          <span>
            {item.texto}
            {item.obligatorio && <span className="ml-1 font-bold text-amber-800">(obligatoria)</span>}
          </span>
        </label>
      ))}
      <p className="text-[11px] text-slate-600">
        Detalle en la{' '}
        <button type="button" onClick={() => abrirLegal('privacidad')} className="font-bold text-amber-800 underline">
          Política de Privacidad y Protección de Menores
        </button>{' '}
        y la{' '}
        <button type="button" onClick={() => abrirLegal('licencia')} className="font-bold text-amber-800 underline">
          Licencia de uso de las fotos
        </button>
        . Podés retirar las autorizaciones hacia el futuro escribiendo a contacto@retratoescolar.com.ar.
      </p>
    </fieldset>
  );
}
