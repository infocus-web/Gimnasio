import { useState } from 'react';
import { numeroDeFoto } from '../utils/numeroFoto';
import { Check, ImageOff, Loader2, Replace, X } from 'lucide-react';
import { listarFotosActivasAdmin, type FotoRegistrada } from '../services/fotosSubidasService';
import { fetchAdminAutenticado } from '../services/adminAuthService';
import type { PedidoEscolarCompleto } from '../services/pedidosLabService';

// 25/10/2026 (Pablo: «cambio hasta laboratorio»). Botón en cada pedido de Laboratorio: si la familia ya confirmó y
// pide cambiar una foto, acá se eligen las nuevas mientras el pedido no entró al laboratorio. El servidor
// (servidor/panel/cambiarFotosPedido.ts) valida con las mismas reglas que la familia, rearma el HD y le manda el mail.
// Va aparte para no agrandar AdminLaboratorioTab.

type Lugar = 'individual' | 'grupal' | 'docente';
const TITULO: Record<Lugar, string> = { individual: 'Individual', grupal: 'Grupal', docente: '3ª foto (con la seño o con familia/amigos)' };
const CATEGORIAS: Record<Lugar, string[]> = { individual: ['individual'], grupal: ['grupal'], docente: ['docente', 'familia'] };

/** Se ofrece el botón: pagado, ya eligió, no es mejora ni está cancelado, y todavía no tiene estado de laboratorio. */
export function puedeCambiarFotos(p: PedidoEscolarCompleto): boolean {
  return Boolean(p.supabaseId) && p.estadoPago === 'aprobado' && !p.seleccionPendiente && !p.mejoraDePedidoId && p.kitId !== 'fotos-extra' && !p.canceladoDefinitivo && !p.estadoLab;
}

/** 25/10/2026: «Cambiar fotos» de un pedido ya confirmado, mientras no entró al laboratorio. Rearma el HD y manda el mail. */
async function cambiarFotosPedidoAdmin(
  pedidoSupabaseId: string,
  fotos: { individualId?: string; grupalId?: string; docenteId?: string; sinFoto?: string[] },
  aunqueDescargo = false,
  soloImpresa = false
): Promise<{ success: boolean; zipListo?: boolean; mailEnviado?: boolean; soloImpresa?: boolean; error?: string }> {
  try {
    const res = await fetchAdminAutenticado(`/api/admin/pedidos/${encodeURIComponent(pedidoSupabaseId)}/cambiar-fotos`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ fotos, aunqueDescargo, soloImpresa }),
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok || !data.success) return { success: false, error: data?.error || 'No se pudieron cambiar las fotos.' };
    return data;
  } catch (err: any) {
    return { success: false, error: err?.message || 'Error de conexión.' };
  }
}

export default function CambiarFotosPedido({ pedido }: { pedido: PedidoEscolarCompleto }) {
  const [abierto, setAbierto] = useState(false);
  const [fotos, setFotos] = useState<FotoRegistrada[] | null>(null);
  const [eleccion, setEleccion] = useState<Record<Lugar, string>>({ individual: '', grupal: '', docente: '' });
  const [trabajando, setTrabajando] = useState(false);
  const [mensaje, setMensaje] = useState<{ ok: boolean; texto: string } | null>(null);
  if (!puedeCambiarFotos(pedido)) return null;
  const sinFoto = (pedido.fotosSeleccionadas?.sinFoto || []) as string[];

  const abrir = async () => {
    setAbierto(true);
    setMensaje(null);
    setEleccion({
      individual: pedido.fotosSeleccionadas?.individualId || '',
      grupal: pedido.fotosSeleccionadas?.grupalId || '',
      docente: pedido.fotosSeleccionadas?.docenteId || '',
    });
    setFotos(null);
    const r = await listarFotosActivasAdmin({ colegioId: pedido.colegioId, grado: pedido.grado, turno: pedido.turno, division: pedido.division });
    if (!r.success) return setMensaje({ ok: false, texto: r.error || 'No se pudieron leer las fotos del curso.' });
    setFotos(r.fotos.filter((f) => f.publicada && (!f.codigoCurso || f.codigoCurso === pedido.cursoCodigo)));
  };

  const opciones = (lugar: Lugar) => (fotos || []).filter((f) => sinFoto.includes(lugar) || CATEGORIAS[lugar].includes(f.categoria));
  const lugares = (['individual', 'grupal', 'docente'] as Lugar[]).filter((l) => l !== 'docente' || sinFoto.includes('docente') || (fotos || []).some((f) => CATEGORIAS.docente.includes(f.categoria)) || eleccion.docente);

  const guardar = async (soloImpresa = false) => {
    if (!pedido.supabaseId || trabajando) return;
    const yaDescargo = (pedido.descargasHd || 0) > 0;
    const aviso = soloImpresa
      ? `¿Cambiar sólo la copia IMPRESA del pedido ${pedido.id} (${pedido.alumnoNombre})?\n\nSe imprime la foto nueva. La descarga digital queda como está y NO se le manda ningún mail.`
      : yaDescargo
      ? `ATENCIÓN: la familia YA DESCARGÓ las fotos en HD (${pedido.descargasHd} ${pedido.descargasHd === 1 ? 'vez' : 'veces'}). Si cambiás, se queda con la foto anterior Y con la nueva.\n\n¿Cambiar igual las fotos del pedido ${pedido.id} (${pedido.alumnoNombre})?`
      : `¿Cambiar las fotos del pedido ${pedido.id} (${pedido.alumnoNombre})?\n\nSe rearma la descarga HD y le llega a la familia un mail nuevo con el link.`;
    if (!window.confirm(aviso)) return;
    setTrabajando(true);
    setMensaje(null);
    const r = await cambiarFotosPedidoAdmin(pedido.supabaseId, {
      individualId: eleccion.individual || undefined,
      grupalId: eleccion.grupal || undefined,
      docenteId: eleccion.docente || undefined,
      sinFoto: sinFoto.length > 0 ? sinFoto : undefined,
    }, yaDescargo && !soloImpresa, soloImpresa);
    setTrabajando(false);
    if (!r.success) return setMensaje({ ok: false, texto: r.error || 'No se pudieron cambiar las fotos.' });
    if (r.soloImpresa) return setMensaje({ ok: true, texto: 'Listo: se imprime la foto nueva. La descarga digital quedó como estaba y no se mandó ningún mail. Recargá el panel para ver el cambio.' });
    setMensaje({
      ok: Boolean(r.mailEnviado && r.zipListo),
      texto: `Listo: fotos cambiadas.${r.zipListo ? ' Se rearmó el HD.' : ' El HD se termina de armar en el reintento automático.'}${r.mailEnviado ? ' Le mandamos el mail a la familia.' : ' El mail no salió: usá «Reenviar enlace Ultra HD».'} Recargá el panel para ver el cambio.`,
    });
  };

  return (
    <>
      <button
        type="button"
        onClick={() => void abrir()}
        className="p-1.5 bg-amber-50 hover:bg-amber-100 text-amber-800 rounded-lg transition-colors cursor-pointer"
        title="Cambiar fotos (la familia pidió otra foto; se puede hasta que entra al laboratorio)"
        aria-label={`Cambiar fotos del pedido ${pedido.id}`}
      >
        <Replace className="w-4 h-4" />
      </button>
      {abierto && (
        <div className="fixed inset-0 z-50 bg-black/60 flex items-center justify-center p-4" onClick={() => !trabajando && setAbierto(false)}>
          <div role="dialog" aria-modal="true" aria-label="Cambiar fotos del pedido" className="bg-white rounded-2xl max-w-4xl w-full max-h-[90vh] overflow-y-auto p-5 space-y-4 text-left text-slate-900" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-start justify-between gap-3">
              <div>
                <h3 className="text-base font-bold">Cambiar fotos · {pedido.alumnoNombre}</h3>
                <p className="text-xs text-slate-600">{pedido.id} · {pedido.kitNombre} · {pedido.grado} "{pedido.division}" {pedido.turno}. Tocá la foto nueva en cada lugar (la actual está marcada).</p>
              </div>
              <button type="button" onClick={() => setAbierto(false)} disabled={trabajando} className="p-1.5 rounded-lg hover:bg-slate-100 cursor-pointer" aria-label="Cerrar"><X className="w-4 h-4" /></button>
            </div>
            {(pedido.descargasHd || 0) > 0 && (
              <p role="alert" className="p-3 rounded-xl bg-rose-50 border border-rose-300 text-rose-900 text-xs leading-relaxed">
                <strong>La familia ya descargó las fotos en HD ({pedido.descargasHd} {pedido.descargasHd === 1 ? 'vez' : 'veces'}).</strong> Ya tiene la foto que eligió en digital. Si sólo querés que se imprima otra, usá «Cambiar sólo la impresa» (no se le manda nada). Si le mandás el HD nuevo, se queda con las dos.
              </p>
            )}
            {!fotos && !mensaje && <p className="text-xs text-slate-500 flex items-center gap-1.5"><Loader2 className="w-3.5 h-3.5 animate-spin" /> Cargando las fotos del curso…</p>}
            {fotos && lugares.map((lugar) => (
              <section key={lugar} className="space-y-1.5">
                <h4 className="text-xs font-bold uppercase tracking-wide text-slate-600">{TITULO[lugar]}{sinFoto.includes(lugar) ? ' · la familia marcó «no tiene esta foto»' : ''}</h4>
                <div className="grid grid-cols-3 sm:grid-cols-5 md:grid-cols-6 gap-2">
                  {sinFoto.includes(lugar) && (
                    <button type="button" onClick={() => setEleccion((e) => ({ ...e, [lugar]: '' }))} className={`aspect-[3/4] rounded-xl border-2 flex flex-col items-center justify-center gap-1 text-[11px] font-semibold cursor-pointer ${!eleccion[lugar] ? 'border-amber-500 bg-amber-50' : 'border-slate-200 text-slate-500'}`}>
                      <ImageOff className="w-5 h-5" /> Sin foto
                    </button>
                  )}
                  {opciones(lugar).map((f) => {
                    const elegida = eleccion[lugar] === f.id;
                    return (
                      <button key={f.id} type="button" onClick={() => setEleccion((e) => ({ ...e, [lugar]: f.id }))} className={`relative rounded-xl border-2 overflow-hidden cursor-pointer ${elegida ? 'border-amber-500 ring-2 ring-amber-300' : 'border-slate-200 hover:border-slate-400'}`} title={f.nombreOriginal || f.id}>
                        <img src={f.urlWeb} alt={f.alumnoNombre || f.nombreOriginal || 'Foto del curso'} loading="lazy" className="w-full aspect-[3/4] object-cover bg-slate-100" />
                        {elegida && <span className="absolute top-1 right-1 bg-amber-500 text-white rounded-full p-0.5"><Check className="w-3 h-3" /></span>}
                        <span className="block truncate px-1 py-0.5 text-[10px] text-slate-600">{numeroDeFoto(f.nombreOriginal) ? <strong className="text-slate-900">N° {numeroDeFoto(f.nombreOriginal)} </strong> : null}{f.alumnoNombre || ''}</span>
                      </button>
                    );
                  })}
                </div>
              </section>
            ))}
            {mensaje && <p role={mensaje.ok ? 'status' : 'alert'} className={`text-xs font-semibold ${mensaje.ok ? 'text-emerald-700' : 'text-rose-700'}`}>{mensaje.texto}</p>}
            <div className="flex justify-end gap-2">
              <button type="button" onClick={() => setAbierto(false)} disabled={trabajando} className="rounded-xl border border-slate-300 px-3 py-2 text-xs font-bold text-slate-700 hover:bg-slate-50 cursor-pointer">Cerrar</button>
              {!/digital/i.test(pedido.kitId || '') && (
                <button type="button" onClick={() => void guardar(true)} disabled={!fotos || trabajando} title="Se imprime la foto nueva; la descarga digital queda como está y no se manda mail" className={`inline-flex items-center gap-1.5 rounded-xl px-3 py-2 text-xs font-extrabold disabled:opacity-50 cursor-pointer ${(pedido.descargasHd || 0) > 0 ? 'bg-amber-400 hover:bg-amber-300 border border-amber-500 text-slate-950' : 'border border-slate-300 bg-white text-slate-700 hover:bg-slate-50'}`}>
                  {trabajando ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Replace className="w-3.5 h-3.5" />} Cambiar sólo la impresa
                </button>
              )}
              <button type="button" onClick={() => void guardar()} disabled={!fotos || trabajando} className={`inline-flex items-center gap-1.5 rounded-xl px-3 py-2 text-xs font-extrabold disabled:opacity-50 cursor-pointer ${(pedido.descargasHd || 0) > 0 ? 'border border-rose-300 bg-white text-rose-700 hover:bg-rose-50' : 'bg-amber-400 hover:bg-amber-300 border border-amber-500 text-slate-950'}`}>
                {trabajando ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Replace className="w-3.5 h-3.5" />} {(pedido.descargasHd || 0) > 0 ? 'Cambiar igual (manda HD nuevo)' : 'Guardar y mandar HD nuevo'}
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
