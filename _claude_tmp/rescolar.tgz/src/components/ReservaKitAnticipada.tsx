import { useEffect, useMemo, useRef, useState } from 'react';
import { CheckCircle2, CreditCard, Loader2, Minus, Plus, Sparkles } from 'lucide-react';
import { crearReserva, KITS_RESERVA, obtenerEstadoReserva, type KitReserva, type ReservaParaSumar, type ReservaPendiente } from '../services/reservasService';
import { kitsParaGrados } from '../utils/kitsSecundaria';
import { crearPreferenciaMercadoPagoMultiple } from '../services/mercadoPagoService';
import { crearIntencionPagoNaveMultiple } from '../services/naveService';
import { useNaveHabilitado } from '../services/mediosPagoService';
import SubirComprobante from './SubirComprobante';
import AceptacionTerminos from './legal/AceptacionTerminos';
import AvisoPlazoTransferencia from './AvisoPlazoTransferencia';
import { registrarFallaDePago } from '../services/reporteErrores';
import { marcarTerminosAceptados } from '../legal/aceptacion';
import { PRECIOS, usePrecios } from '../services/preciosService';
import { CODIGO_KIT_YA_PAGADO, nuevoNumeroPedido, nuevoUuidPedido, totalDelServidor } from '../services/pedidosLabService';
import { firmaDeCheckout, idsParaCheckout, type IdsCheckout } from '../utils/checkoutEstable';

interface HijoReserva {
  id: string;
  nombreCompleto: string;
  codigoSeccion: string;
  /** 14/10: en secundaria no se ofrece el Solo Digital (ver utils/kitsSecundaria.ts). */
  grado?: string;
}

interface Props {
  hijos: HijoReserva[];
  tutorNombre: string;
  tutorEmail: string;
  tutorTelefono?: string;
  /** Pasar a la galería de un hijo cuyo curso ya tiene fotos (ahí se elige y se compra normal). */
  onVerFotosHijo?: (hijoId: string) => void;
  /**
   * Pedido de Pablo (25/9): si un hermano ya tiene fotos y todavía no las compró, la reserva no se
   * paga sola — se suma a la compra de ese hermano (un solo pago). Recibe los kits elegidos y el
   * hermano con fotos al que hay que ir a elegir.
   */
  onSumarALaCompra?: (reservas: ReservaParaSumar[], hijoConFotosId: string, hijosDecididos: string[]) => void;
  /** Reservas que ya se sumaron a la compra (para mostrarlas como tales). */
  reservasSumadas?: ReservaParaSumar[];
  /** Hermanos con fotos que ya tienen sus 3 fotos elegidas (se va directo al pago). */
  hijosConFotosElegidas?: string[];
  /** Aviso cuando el portal mandó a la familia acá porque falta decidir el kit de este hijo/a. */
  aviso?: string;
  /**
   * Auditoría 03/10 noche (contrato 5): llave de galería de la familia (`familiaActiva.id` y
   * `familiaActiva.accesoGaleria`). Sin ella el servidor no devuelve las reservas SIN pagar (la que
   * quedó al volver de Mercado Pago sin pagar, o la que espera la transferencia) ni si un hermano ya
   * tiene un pedido esperando el pago.
   */
  familiaId?: string | null;
  accesoGaleria?: string | null;
}

type Metodo = 'mercadopago' | 'nave' | 'transferencia';

// Cada medio con el color de su marca (Mercado Pago celeste #009EE3, Nave violeta).
const MEDIOS_PAGO: { id: Metodo; nombre: string; detalle: string; normal: string; elegido: string; anillo: string }[] = [
  { id: 'mercadopago', nombre: 'Mercado Pago', detalle: 'Débito, crédito o dinero en cuenta', normal: 'border-[#009EE3] bg-white text-[#0074a8]', elegido: 'border-[#009EE3] bg-[#009EE3] text-white', anillo: 'ring-[#009EE3]/40' },
  { id: 'nave', nombre: 'Nave', detalle: 'Tarjetas y QR', normal: 'border-violet-500 bg-white text-violet-700', elegido: 'border-violet-600 bg-violet-600 text-white', anillo: 'ring-violet-300' },
  { id: 'transferencia', nombre: 'Transferencia', detalle: 'Alias / CBU', normal: 'border-slate-300 bg-white text-slate-800', elegido: 'border-slate-800 bg-slate-800 text-white', anillo: 'ring-slate-300' },
];

const MAX_CARPETAS_EXTRA = 20;

/**
 * Pago anticipado (pedido de Pablo, 24/9: "muchos padres están acostumbrados a pagar por
 * adelantado"). Se muestra mientras el curso todavía no tiene fotos: la familia elige el kit de
 * cada hijo y lo paga ya; cuando se suben las fotos, las elige sin volver a pagar.
 */
export default function ReservaKitAnticipada({ hijos, tutorNombre, tutorEmail, tutorTelefono, onVerFotosHijo, onSumarALaCompra, reservasSumadas = [], hijosConFotosElegidas = [], aviso, familiaId, accesoGaleria }: Props) {
  usePrecios(); // re-renderiza cuando llegan los precios vigentes
  const [kits, setKits] = useState<Record<string, KitReserva | ''>>({});
  // Copias extra de la carpeta (sólo Kit Impreso), pedido de Pablo 27/9.
  const [extras, setExtras] = useState<Record<string, number>>({});
  const extrasDe = (id: string) => (kits[id] === 'kit-clasico' ? extras[id] || 0 : 0);
  const precioDe = (id: string) => (KITS_RESERVA.find((k) => k.id === kits[id])?.precio || 0) + extrasDe(id) * PRECIOS.carpetaExtra;
  const [reservas, setReservas] = useState<Record<string, ReservaPendiente | null>>({});
  // Hijos cuyo curso YA tiene fotos: no se reservan (caso real 25/9, se cobraba igual por adelantado).
  const [conFotos, setConFotos] = useState<Record<string, boolean>>({});
  const [conPedidoPagado, setConPedidoPagado] = useState<Record<string, boolean>>({});
  // Auditoría 03/10 noche (M8a/R3): hermanos con fotos que ya tienen un pedido esperando el pago
  // (por ejemplo una transferencia sin aprobar): no obligan a "elegir sus fotos y pagar todo junto".
  const [conPedidoPendiente, setConPedidoPendiente] = useState<Record<string, boolean>>({});
  const [cargando, setCargando] = useState(true);
  const [email, setEmail] = useState(tutorEmail);
  const [metodo, setMetodo] = useState<Metodo>('mercadopago');
  const naveHabilitado = useNaveHabilitado();
  const [enviando, setEnviando] = useState(false);
  // Auditoría 03/10: ids de reserva estables por intento (ver checkoutEstable.ts): un reintento con
  // la misma selección reusa los mismos ids y el servidor devuelve la reserva ya registrada.
  const reservaIdsRef = useRef<IdsCheckout | null>(null);
  // Marco legal (27/9): casilla obligatoria antes de pagar la reserva.
  const [aceptaTerminos, setAceptaTerminos] = useState(false);
  const [faltaAceptar, setFaltaAceptar] = useState(false);
  // Pedido de Pablo (29/9): por transferencia hay que tildar que se entiende el plazo de 48 hs.
  const [aceptaPlazo, setAceptaPlazo] = useState(false);
  const [faltaAceptarPlazo, setFaltaAceptarPlazo] = useState(false);
  const [error, setError] = useState('');
  // Auditoría 03/10 (2ª vuelta): el servidor respondió 409 KIT_YA_PAGADO (algún chico ya tiene un kit
  // pagado). Se pregunta antes de seguir; si confirma, se reintenta con los mismos ids.
  const [confirmacionOtroKit, setConfirmacionOtroKit] = useState<{ alumnos: string[]; mensaje: string } | null>(null);
  // Auditoría 03/10 noche (M7/contrato 7): `total` es el que devolvió el servidor (null si no vino).
  const [transferencia, setTransferencia] = useState<{ total: number | null; pedidos: string[]; grupoPagoId: string; codigoSeccion: string } | null>(null);

  useEffect(() => setEmail((actual) => actual || tutorEmail), [tutorEmail]);

  // Pedido de Pablo (28/9): todo error que se le muestra a la familia al reservar queda registrado solo.
  useEffect(() => {
    if (error) registrarFallaDePago('reserva anticipada', error, { email: email.trim(), metodo, hijos: hijos.map((h) => h.nombreCompleto), kits });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [error]);

  // Clave estable: el portal re-renderiza seguido y arma un array nuevo cada vez.
  const claveHijos = hijos.map((h) => `${h.id}|${h.codigoSeccion}|${h.nombreCompleto}`).join(';');
  useEffect(() => {
    let cancelado = false;
    setCargando(true);
    Promise.all(
      hijos.map(async (h) => [h.id, await obtenerEstadoReserva(h.codigoSeccion, h.nombreCompleto, { familia: familiaId, acceso: accesoGaleria })] as const)
    ).then((pares) => {
      if (cancelado) return;
      setReservas(Object.fromEntries(pares.map(([id, e]) => [id, e.reserva])));
      setConFotos(Object.fromEntries(pares.map(([id, e]) => [id, e.fotosDisponibles])));
      setConPedidoPagado(Object.fromEntries(pares.map(([id, e]) => [id, e.tienePedidoPagado])));
      setConPedidoPendiente(Object.fromEntries(pares.map(([id, e]) => [id, Boolean(e.tienePedidoPendiente)])));
      setKits((prev) => {
        const nuevo = { ...prev };
        // Pedido de Pablo (27/9): nada preseleccionado — la familia tiene que elegir sí o sí una de
        // las 3 opciones. Si ya la había sumado a la compra, se muestra lo que eligió.
        for (const [id, e] of pares) {
          const sumada = reservasSumadas.find((r) => r.hijoId === id);
          if (!e.reserva?.pagada && !e.fotosDisponibles && nuevo[id] === undefined && sumada) nuevo[id] = sumada.kitId;
          // Pedido de Pablo (28/9): si ya había una reserva sin pagar (volvió de Mercado Pago sin
          // pagar), el kit viene elegido: sólo falta el medio de pago.
          if (e.reserva && !e.reserva.pagada && !e.fotosDisponibles && nuevo[id] === undefined) {
            const kitPrevio = KITS_RESERVA.find((k) => k.nombre === e.reserva!.kitNombre);
            if (kitPrevio) nuevo[id] = kitPrevio.id;
          }
        }
        return nuevo;
      });
      setExtras((prev) => {
        const nuevo = { ...prev };
        for (const r of reservasSumadas) if (nuevo[r.hijoId] === undefined && r.carpetasExtras) nuevo[r.hijoId] = r.carpetasExtras;
        return nuevo;
      });
      setCargando(false);
    });
    return () => {
      cancelado = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [claveHijos, familiaId, accesoGaleria]);

  // Reserva por transferencia todavía sin confirmar: se muestra como "esperando tu transferencia"
  // (para que no la paguen dos veces), con la opción de pagarla con otro medio.
  const [reabiertos, setReabiertos] = useState<Record<string, boolean>>({});
  const esperandoTransferencia = (id: string) => {
    const r = reservas[id];
    return Boolean(r && !r.pagada && r.metodoPago === 'transferencia' && !reabiertos[id]);
  };
  const hijosSinReservaPagada = hijos.filter((h) => !conFotos[h.id] && !reservas[h.id]?.pagada && !esperandoTransferencia(h.id));
  const elegidos = hijosSinReservaPagada.filter((h) => kits[h.id]);
  const sinDecidir = hijosSinReservaPagada.filter((h) => kits[h.id] === undefined);
  const total = useMemo(
    () => elegidos.reduce((acc, h) => acc + precioDe(h.id), 0),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [elegidos, kits, extras]
  );
  // Hermanos con fotos online que todavía no compraron: primero se eligen sus fotos y la reserva se
  // suma a esa compra (un solo pago). No se puede pagar la reserva sola mientras falten.
  // Auditoría 03/10 noche (M8a/R3): un hermano que ya tiene un pedido esperando el pago tampoco cuenta.
  const hermanosConFotosPendientes = hijos.filter((h) => conFotos[h.id] && !conPedidoPagado[h.id] && !conPedidoPendiente[h.id] && !reservas[h.id]?.pagada);
  const debeSumarseALaCompra = hermanosConFotosPendientes.length > 0 && Boolean(onSumarALaCompra);
  const nombresPendientes = hermanosConFotosPendientes.map((h) => h.nombreCompleto).join(' y ');
  // Pedido de Pablo (27/9): si las fotos del hermano ya están elegidas, se va directo al pago en vez
  // de volver a mandarlo a su galería.
  const hermanoPorElegir = hermanosConFotosPendientes.find((h) => !hijosConFotosElegidas.includes(h.id));
  const hermanoDestino = hermanoPorElegir || hermanosConFotosPendientes[0];
  const nombresSinDecidir = sinDecidir.map((h) => h.nombreCompleto).join(' y ');
  const sumarALaCompra = () => {
    setError('');
    if (sinDecidir.length > 0) return setError(`Elegí una opción para el kit de ${nombresSinDecidir}.`);
    onSumarALaCompra?.(
      elegidos.map((h) => {
        const kit = KITS_RESERVA.find((k) => k.id === kits[h.id])!;
        return { hijoId: h.id, nombreCompleto: h.nombreCompleto, codigoSeccion: h.codigoSeccion, kitId: kit.id, kitNombre: kit.nombre, precio: precioDe(h.id), carpetasExtras: extrasDe(h.id) };
      }),
      hermanoDestino.id,
      hijosSinReservaPagada.map((h) => h.id)
    );
  };
  const textoBotonSumar =
    sinDecidir.length > 0
      ? `Elegí una opción para ${nombresSinDecidir}`
      : hermanoPorElegir
      ? elegidos.length > 0
        ? `Elegir las fotos de ${hermanoPorElegir.nombreCompleto} y pagar todo junto`
        : `Continuar con las fotos de ${hermanoPorElegir.nombreCompleto}`
      : elegidos.length > 0
      ? `Sumar a la compra e ir a pagar · $${total.toLocaleString('es-AR')}`
      : 'Continuar al pago'

  const pagar = async (opciones: { confirmarOtroKit?: boolean } = {}) => {
    setError('');
    setConfirmacionOtroKit(null);
    if (sinDecidir.length > 0) return setError(`Elegí una opción para el kit de ${nombresSinDecidir}.`);
    if (elegidos.length === 0) return setError('Elegí el kit de al menos uno de los chicos.');
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) return setError('Ingresá un email válido para recibir la confirmación.');
    if (!aceptaTerminos) {
      // No es una falla: es un paso que falta. Se marca la casilla en rojo (sin registrar un error).
      setFaltaAceptar(true);
      return;
    }
    if (metodo === 'transferencia' && !aceptaPlazo) {
      setFaltaAceptarPlazo(true);
      return;
    }
    marcarTerminosAceptados(true);
    setEnviando(true);
    const itemsReserva = elegidos.map((h) => ({ codigoSeccion: h.codigoSeccion, alumnoNombre: h.nombreCompleto, kitId: kits[h.id] as KitReserva, carpetasExtras: extrasDe(h.id) }));
    // El medio de pago y el email entran en la firma: si cambian, es otra reserva (ids nuevos).
    const firma = firmaDeCheckout({ items: itemsReserva, metodo }, email);
    const ids = idsParaCheckout(reservaIdsRef.current, firma, 0, nuevoUuidPedido, nuevoNumeroPedido, itemsReserva.length);
    reservaIdsRef.current = ids;
    const reserva = await crearReserva({
      tutorNombre,
      tutorEmail: email.trim(),
      tutorTelefono,
      metodoPago: metodo,
      items: itemsReserva.map((item, i) => ({ ...item, reservaId: ids.reservaIds[i] })),
      confirmarOtroKit: opciones.confirmarOtroKit === true,
      // Auditoría 03/10 noche (A1): misma clave en los reintentos de esta reserva.
      claveCheckout: ids.claveCheckout,
    });
    if (reserva.codigo === CODIGO_KIT_YA_PAGADO) {
      setEnviando(false);
      setConfirmacionOtroKit({ alumnos: reserva.alumnos || [], mensaje: reserva.error || '' });
      return;
    }
    if (!reserva.success || !reserva.grupoPagoId) {
      setEnviando(false);
      return setError(reserva.error || 'No se pudo registrar la reserva.');
    }
    if (metodo === 'transferencia') {
      setEnviando(false);
      // Auditoría 03/10 noche (contrato 7): se muestra el total que devolvió el servidor, no el local.
      setTransferencia({
        total: totalDelServidor(reserva.total),
        pedidos: reserva.pedidoFriendlyIds || [],
        grupoPagoId: reserva.grupoPagoId,
        codigoSeccion: elegidos[0]?.codigoSeccion || '',
      });
      return;
    }
    const datosPago = { grupoPagoId: reserva.grupoPagoId, items: [], tutorNombre, tutorEmail: email.trim(), tutorTelefono };
    const pago = metodo === 'nave' ? await crearIntencionPagoNaveMultiple(datosPago) : await crearPreferenciaMercadoPagoMultiple(datosPago);
    const url = 'checkoutUrl' in pago ? pago.checkoutUrl : 'initPoint' in pago ? pago.initPoint : undefined;
    if (pago.success && url) {
      window.location.href = url;
      return;
    }
    setEnviando(false);
    setError(pago.error || 'No se pudo iniciar el pago. Intentá de nuevo o elegí otro medio.');
  };

  if (transferencia) {
    return (
      <div className="mt-6 rounded-2xl border border-emerald-200 bg-white p-5 text-left shadow-xs">
        <p className="flex items-center gap-2 font-bold text-slate-900"><CheckCircle2 className="h-5 w-5 text-emerald-600" />¡Reserva registrada!</p>
        <p className="mt-2 text-sm text-slate-600">
          Transferí {transferencia.total !== null ? <strong>${transferencia.total.toLocaleString('es-AR')}</strong> : 'el total de la reserva'} ({transferencia.pedidos.length > 1 ? 'pedidos' : 'pedido'}{' '}
          <strong>{transferencia.pedidos.join(', ')}</strong>) y subí el comprobante acá abajo. Cuando lo confirmemos te llega un email.
        </p>
        <div className="mt-3 space-y-0.5 rounded-xl bg-slate-50 p-3 text-xs text-slate-700">
          <p><strong>Titular:</strong> Alderete Pablo Gabriel</p>
          <p><strong>CUIT:</strong> 20-28306117-6</p>
          <p><strong>Alias:</strong> <span className="font-mono font-bold">RETRATO.ESCOLAR</span></p>
          <p><strong>CBU:</strong> <span className="font-mono">0070313830004052956749</span></p>
        </div>
        <div className="mt-3">
          <SubirComprobante grupoPagoId={transferencia.grupoPagoId} numeros={transferencia.pedidos.join(', ')} codigo={transferencia.codigoSeccion || undefined} />
        </div>
      </div>
    );
  }

  // Pedido de Pablo (27/9): si ya no queda nada por reservar (todos pagos), no se ofrece "reservá tu
  // kit": se muestra el estado de cada hijo/a y cómo sigue.
  const todoPago = !cargando && hijosSinReservaPagada.length === 0 && !hijos.some((h) => esperandoTransferencia(h.id));
  return (
    <div className="mt-6 rounded-2xl border border-amber-300 bg-white p-5 text-left shadow-xs">
      {todoPago ? (
        <>
          <p className="flex items-center gap-2 font-['Outfit'] text-base font-extrabold text-slate-900">
            <CheckCircle2 className="h-5 w-5 text-emerald-600" />
            Ya está todo pago
          </p>
          <p className="mt-1 text-xs text-slate-600">
            Cuando se carguen las fotos que faltan te avisamos por email para que las elijas, sin volver a pagar.
          </p>
        </>
      ) : (
        <>
          <p className="flex items-center gap-2 font-['Outfit'] text-base font-extrabold text-slate-900">
            <Sparkles className="h-5 w-5 text-amber-500" />
            ¿Querés dejarlo pago? Reservá tu kit ahora
          </p>
          <p className="mt-1 text-xs text-slate-600">
            Pagás hoy y, cuando estén las fotos, elegís las que más te gusten <strong>sin volver a pagar</strong>. Apenas las confirmes te llega la descarga en alta resolución.
          </p>
        </>
      )}

      {aviso && (
        <p className="mt-3 rounded-xl border border-red-200 bg-red-50 p-3 text-xs font-semibold text-red-700">{aviso}</p>
      )}

      <div className="mt-4 space-y-3">
        {cargando && <p className="text-xs text-slate-500">Cargando…</p>}
        {!cargando && hijos.map((h) => {
          const reserva = reservas[h.id];
          if (conFotos[h.id] && !reserva?.pagada) {
            return (
              <div key={h.id} className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 rounded-xl border border-sky-200 bg-sky-50 p-3 text-xs text-sky-950">
                <span>
                  <strong>{h.nombreCompleto}:</strong>{' '}
                  {conPedidoPagado[h.id]
                    ? 'sus fotos ya están online y su pedido ya está pago.'
                    : conPedidoPendiente[h.id]
                    ? 'ya tiene un pedido esperando el pago. Si querés, podés ver sus fotos y hacer otro.'
                    : debeSumarseALaCompra
                    ? 'sus fotos ya están online. Primero elegí sus fotos: el kit de sus hermanos se suma a esa compra y pagás todo junto.'
                    : 'sus fotos ya están online, así que no hace falta reservar. Elegilas en su galería y comprá desde ahí.'}
                </span>
                {onVerFotosHijo && (
                  <button
                    type="button"
                    onClick={() => onVerFotosHijo(h.id)}
                    className={`shrink-0 rounded-lg px-3 py-1.5 font-bold ${conPedidoPagado[h.id] ? 'border border-sky-300 bg-white text-sky-800 hover:bg-sky-100' : 'bg-sky-600 text-white hover:bg-sky-500'}`}
                  >
                    {conPedidoPagado[h.id] ? 'Ver sus fotos / hacer otro pedido' : 'Ver sus fotos'}
                  </button>
                )}
              </div>
            );
          }
          if (reserva && esperandoTransferencia(h.id)) {
            return (
              <div key={h.id} className="rounded-xl border border-amber-200 bg-amber-50 p-3 text-xs text-amber-950">
                <p>
                  <strong>{h.nombreCompleto}:</strong> tu reserva del {reserva.kitNombre} ({reserva.pedidoFriendlyId}) está registrada y
                  esperamos tu transferencia de <strong>${reserva.total.toLocaleString('es-AR')}</strong> (Alias RETRATO.ESCOLAR). Cuando lo
                  confirmemos te llega un email.
                </p>
                <div className="mt-2">
                  <SubirComprobante pedidoId={reserva.id} numeros={reserva.pedidoFriendlyId} codigo={h.codigoSeccion} />
                </div>
                <button type="button" onClick={() => setReabiertos((r) => ({ ...r, [h.id]: true }))} className="mt-2 font-bold text-amber-800 underline">
                  Prefiero pagar con otro medio
                </button>
              </div>
            );
          }
          if (reserva?.pagada) {
            return (
              <div key={h.id} className="flex items-center gap-2 rounded-xl border border-emerald-200 bg-emerald-50 p-3 text-xs text-emerald-900">
                <CheckCircle2 className="h-4 w-4 shrink-0 text-emerald-600" />
                <span><strong>{h.nombreCompleto}:</strong> {reserva.kitNombre} ya pagado ({reserva.pedidoFriendlyId}). Vas a poder elegir sus fotos cuando estén disponibles.</span>
              </div>
            );
          }
          return (
            <div key={h.id} className={`rounded-xl border p-3 ${kits[h.id] === undefined ? 'border-amber-300 bg-amber-50/40' : 'border-slate-200'}`}>
              <p className="mb-2 text-xs font-bold text-slate-800">
                {h.nombreCompleto}
                {kits[h.id] === undefined && <span className="ml-2 font-semibold text-amber-700">· Elegí una opción</span>}
              </p>
              <div className="grid gap-2 sm:grid-cols-3">
                {/* Pedido de Pablo (25/9): "Ahora no" elegido casi no se distinguía del fondo. Toda
                    opción elegida lleva ahora borde grueso de color y un ✓ arriba a la derecha. */}
                {kitsParaGrados(KITS_RESERVA, [h.grado]).map((kit) => (
                  <label key={kit.id} className={`relative cursor-pointer rounded-lg border-2 p-2 text-xs ${kits[h.id] === kit.id ? 'border-amber-500 bg-amber-50 ring-2 ring-amber-200' : 'border-slate-200 hover:bg-slate-50'}`}>
                    <input type="radio" className="sr-only" name={`kit-${h.id}`} checked={kits[h.id] === kit.id} onChange={() => setKits((k) => ({ ...k, [h.id]: kit.id }))} />
                    {kits[h.id] === kit.id && <CheckCircle2 className="absolute right-2 top-2 h-4 w-4 text-amber-600" aria-hidden="true" />}
                    <span className="block font-bold text-slate-900">{kit.nombre}</span>
                    <span className="block font-extrabold text-amber-700">${kit.precio.toLocaleString('es-AR')}</span>
                    <span className="block text-[10px] text-slate-500">{kit.detalle}</span>
                  </label>
                ))}
                <label className={`relative cursor-pointer rounded-lg border-2 p-2 text-xs ${kits[h.id] === '' ? 'border-slate-700 bg-slate-100 ring-2 ring-slate-300' : 'border-slate-200 hover:bg-slate-50'}`}>
                  <input type="radio" className="sr-only" name={`kit-${h.id}`} checked={kits[h.id] === ''} onChange={() => setKits((k) => ({ ...k, [h.id]: '' }))} />
                  {kits[h.id] === '' && <CheckCircle2 className="absolute right-2 top-2 h-4 w-4 text-slate-700" aria-hidden="true" />}
                  <span className={`block font-bold ${kits[h.id] === '' ? 'text-slate-900' : 'text-slate-700'}`}>Ahora no</span>
                  <span className="block text-[10px] text-slate-500">
                    {kits[h.id] === '' ? 'Elegido: pagás cuando estén las fotos' : 'Elijo y pago cuando estén las fotos'}
                  </span>
                </label>
              </div>
              {kits[h.id] === 'kit-clasico' && (
                <div className="mt-2 flex items-center justify-between gap-3 rounded-lg bg-amber-50 px-3 py-2 text-xs">
                  <span className="text-slate-700">
                    <strong>Copia extra de la carpeta</strong> (para abuelos o familiares) · +${PRECIOS.carpetaExtra.toLocaleString('es-AR')} c/u
                  </span>
                  <span className="flex shrink-0 items-center gap-2">
                    <button type="button" aria-label={`Restar carpeta extra de ${h.nombreCompleto}`} disabled={extrasDe(h.id) === 0} onClick={() => setExtras((e) => ({ ...e, [h.id]: Math.max(0, (e[h.id] || 0) - 1) }))} className="flex h-7 w-7 items-center justify-center rounded-md border border-slate-300 bg-white disabled:opacity-30">
                      <Minus className="h-3.5 w-3.5" />
                    </button>
                    <span className="w-5 text-center font-mono font-bold">{extrasDe(h.id)}</span>
                    <button type="button" aria-label={`Sumar carpeta extra de ${h.nombreCompleto}`} disabled={extrasDe(h.id) >= MAX_CARPETAS_EXTRA} onClick={() => setExtras((e) => ({ ...e, [h.id]: Math.min(MAX_CARPETAS_EXTRA, (e[h.id] || 0) + 1) }))} className="flex h-7 w-7 items-center justify-center rounded-md bg-amber-400 disabled:opacity-30">
                      <Plus className="h-3.5 w-3.5" />
                    </button>
                  </span>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {!cargando && hijosSinReservaPagada.length > 0 && debeSumarseALaCompra && (
        <div className="mt-4 space-y-2">
          {reservasSumadas.length > 0 && (
            <p className="text-xs font-semibold text-emerald-700">
              Ya sumaste {reservasSumadas.map((r) => `${r.kitNombre} de ${r.nombreCompleto}`).join(' y ')} a tu compra.
            </p>
          )}
          {error && <p className="text-xs font-semibold text-red-600">{error}</p>}
          <button
            type="button"
            onClick={sumarALaCompra}
            disabled={sinDecidir.length > 0}
            className="inline-flex w-full items-center justify-center gap-2 rounded-xl bg-amber-400 px-5 py-3 text-sm font-bold text-slate-950 shadow-md hover:bg-amber-300 disabled:cursor-not-allowed disabled:opacity-50 sm:w-auto"
          >
            <CreditCard className="h-4 w-4" />
            {textoBotonSumar}
          </button>
          <p className="text-[11px] text-slate-500">
            {elegidos.length > 0
              ? `El kit de ${elegidos.map((h) => h.nombreCompleto).join(' y ')} ($${total.toLocaleString('es-AR')}) se suma a la compra de ${nombresPendientes} y se paga en el mismo pago.`
              : `Sin kit por ahora: pagás sólo lo de ${nombresPendientes}. Cuando estén las fotos lo podés comprar.`}
          </p>
        </div>
      )}

      {!cargando && hijosSinReservaPagada.length > 0 && !debeSumarseALaCompra && (
        <>
          <div className="mt-4 space-y-3">
            <label className="block text-xs font-semibold text-slate-700">
              Email para la confirmación
              <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} className="mt-1 w-full rounded-xl border border-slate-300 px-3 py-2 text-xs font-normal sm:max-w-sm" placeholder="tu@email.com" />
            </label>
            {/* Pedido de Pablo (28/9): botones con el color de cada medio en vez de un desplegable. */}
            <div>
              <p className="mb-1.5 text-xs font-semibold text-slate-700">Medio de pago</p>
              <div className={`grid gap-2 ${naveHabilitado ? 'sm:grid-cols-3' : 'sm:grid-cols-2'}`}>
                {MEDIOS_PAGO.filter((m) => m.id !== 'nave' || naveHabilitado).map((m) => {
                  const elegido = metodo === m.id;
                  return (
                    <button
                      key={m.id}
                      type="button"
                      aria-pressed={elegido}
                      onClick={() => setMetodo(m.id)}
                      className={`relative rounded-xl border-2 px-3 py-2.5 text-left text-xs transition-all ${
                        elegido ? `${m.elegido} ring-2 ring-offset-1 ${m.anillo}` : `${m.normal} opacity-80 hover:opacity-100`
                      }`}
                    >
                      {elegido && <CheckCircle2 className="absolute right-2 top-2 h-4 w-4" aria-hidden="true" />}
                      <span className="block font-extrabold">{m.nombre}</span>
                      <span className="block text-[10px] opacity-90">{m.detalle}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
          {metodo === 'transferencia' && (
            <div className="mt-4">
              <AvisoPlazoTransferencia
                id="chk-plazo-transferencia-reserva"
                aceptado={aceptaPlazo}
                onCambiar={(v) => {
                  setAceptaPlazo(v);
                  if (v) setFaltaAceptarPlazo(false);
                }}
                resaltar={faltaAceptarPlazo}
              />
            </div>
          )}
          <div className="mt-4">
            <AceptacionTerminos id="chk-acepta-terminos-reserva" aceptado={aceptaTerminos} onCambiar={(v) => { setAceptaTerminos(v); if (v) setError(''); }} resaltar={faltaAceptar} />
          </div>
          {error && <p className="mt-3 text-xs font-semibold text-red-600">{error}</p>}
          {confirmacionOtroKit && (
            <div className="mt-3 rounded-xl border border-amber-300 bg-amber-50 p-3 text-xs text-amber-950" role="alert">
              <p className="font-bold">
                Ya hay un kit pagado para {confirmacionOtroKit.alumnos.length ? confirmacionOtroKit.alumnos.join(', ') : 'este alumno/a'}
              </p>
              <p className="mt-1">
                {confirmacionOtroKit.mensaje ? `${confirmacionOtroKit.mensaje} ` : ''}¿Querés pagar otro kit igual? Si no estás seguro/a, revisá primero el pedido que ya está pago (puede haberlo hecho otro familiar).
              </p>
              <div className="mt-2 flex flex-col gap-2 sm:flex-row">
                <button type="button" onClick={() => setConfirmacionOtroKit(null)} className="rounded-lg border border-slate-300 bg-white px-3 py-1.5 font-bold text-slate-800 hover:bg-slate-50">
                  No, no comprar
                </button>
                <button type="button" onClick={() => void pagar({ confirmarOtroKit: true })} disabled={enviando} className="rounded-lg bg-amber-400 px-3 py-1.5 font-extrabold text-slate-950 hover:bg-amber-300 disabled:opacity-50">
                  Sí, pagar otro kit
                </button>
              </div>
            </div>
          )}
          <button
            type="button"
            onClick={() => void pagar()}
            disabled={enviando || elegidos.length === 0 || sinDecidir.length > 0}
            className="mt-4 inline-flex w-full items-center justify-center gap-2 rounded-xl bg-amber-400 px-5 py-3 text-sm font-bold text-slate-950 shadow-md hover:bg-amber-300 disabled:cursor-not-allowed disabled:opacity-50 sm:w-auto"
          >
            {enviando ? <Loader2 className="h-4 w-4 animate-spin" /> : <CreditCard className="h-4 w-4" />}
            {sinDecidir.length > 0 ? `Elegí una opción para ${nombresSinDecidir}` : elegidos.length === 0 ? 'Elegí un kit' : `Pagar reserva · $${total.toLocaleString('es-AR')}`}
          </button>
        </>
      )}
    </div>
  );
}
