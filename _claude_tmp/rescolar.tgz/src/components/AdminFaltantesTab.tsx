import { useCallback, useEffect, useMemo, useState } from 'react';
import * as XLSX from 'xlsx';
import { CameraOff, CheckCircle2, Download, Loader2, MessageCircle, XCircle } from 'lucide-react';
import { useColegiosLista } from '../services/colegiosService';
import { celdaSegura, descargarLibroExcel } from '../services/excelDownloadHelper';
import { MOTIVOS_FALTANTE, accionFaltanteAdmin, obtenerFaltantesAdmin, type SolicitudFaltanteAdmin } from '../services/fotosFaltantesService';
import BusquedasRostroPanel from './BusquedasRostroPanel';
import ConvocarFaltantes, { esConvocable, textoConvocada } from './ConvocarFaltantes';
import { solicitudFaltanteAbierta } from '../utils/fotosFaltantes';
import { textoFechaCorta, usePlazosTemporada } from '../utils/plazosTemporada';

/**
 * Pestaña «Faltantes» del panel (22/10/2026, pedido de Pablo: «quiero un panel "faltantes solicitadas" donde pueda
 * ver el curso, turno y división de quien solicita la foto»). Lista los pedidos de foto que hicieron las familias
 * desde la galería (hasta el 15/11). «Ya está la foto» la marca resuelta y le manda un mail a la familia; «Descartar»
 * la cancela. Mientras está pendiente, el kit de ese chico queda en espera. Servidor: servidor/familias/solicitudesFaltantes.ts.
 */

const LUGAR: Record<string, string> = { individual: 'Individual', grupal: 'Grupal', docente: '3ª foto' };
const ESTADO: Record<string, string> = { pendiente: 'Pendiente', resuelta: 'Ya está', cancelada: 'Cancelada' };
const motivoPanel = (m: string) => MOTIVOS_FALTANTE.find((x) => x.valor === m)?.panel || m;
const cursoDe = (s: SolicitudFaltanteAdmin) => `${s.grado || ''} "${s.division || '-'}"${s.turno ? ` · ${s.turno}` : ''}`;
const fecha = (iso: string | null) => (iso ? new Date(iso).toLocaleString('es-AR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' }) : '');
const soloDigitos = (t: string | null) => String(t || '').replace(/\D/g, '');
const linkWhatsApp = (t: string | null) => {
  const d = soloDigitos(t);
  return `https://wa.me/${d.startsWith('54') ? d : `549${d.replace(/^0/, '')}`}`;
};

export default function AdminFaltantesTab() {
  const { colegios } = useColegiosLista();
  const plazos = usePlazosTemporada(); // 30/10: fecha límite del panel → Configuración
  const [colegioId, setColegioId] = useState(() => colegios[0]?.id || '');
  const [solicitudes, setSolicitudes] = useState<SolicitudFaltanteAdmin[]>([]);
  const [cargando, setCargando] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [aviso, setAviso] = useState<string | null>(null);
  const [filtroEstado, setFiltroEstado] = useState<'pendiente' | 'resuelta' | 'cancelada' | 'todas'>('pendiente');
  const [filtroCurso, setFiltroCurso] = useState('');
  const [trabajando, setTrabajando] = useState<string | null>(null);
  const [elegidos, setElegidos] = useState<Set<string>>(new Set());

  useEffect(() => {
    if (colegios.length > 0 && (!colegioId || !colegios.some((c) => c.id === colegioId))) setColegioId(colegios[0].id);
  }, [colegios, colegioId]);

  const cargar = useCallback(async () => {
    if (!colegioId) return;
    setCargando(true);
    setError(null);
    const r = await obtenerFaltantesAdmin(colegioId);
    if (r.success) setSolicitudes(r.solicitudes);
    else setError(r.error || 'No se pudieron cargar las fotos faltantes.');
    setCargando(false);
  }, [colegioId]);

  useEffect(() => {
    setSolicitudes([]);
    setElegidos(new Set());
    void cargar();
  }, [cargar]);

  const cursos = useMemo(() => Array.from(new Set(solicitudes.map(cursoDe))).sort((a, b) => a.localeCompare(b, 'es', { numeric: true })), [solicitudes]);
  const visibles = useMemo(
    () =>
      solicitudes
        .filter((s) => (filtroEstado === 'todas' || s.estado === filtroEstado) && (!filtroCurso || cursoDe(s) === filtroCurso))
        .sort((a, b) => cursoDe(a).localeCompare(cursoDe(b), 'es', { numeric: true }) || a.alumno_nombre.localeCompare(b.alumno_nombre, 'es')),
    [solicitudes, filtroEstado, filtroCurso]
  );
  const pendientes = solicitudes.filter((s) => s.estado === 'pendiente').length;
  // 25/10: convocar (no grupal, pendiente y con email). Sólo cuentan las elegidas que se ven con el filtro actual.
  const convocablesVisibles = visibles.filter(esConvocable);
  const elegidas = convocablesVisibles.filter((s) => elegidos.has(s.id));
  const alternar = (id: string) => setElegidos((prev) => { const n = new Set(prev); if (n.has(id)) n.delete(id); else n.add(id); return n; });

  const accion = async (s: SolicitudFaltanteAdmin, tipo: 'resolver' | 'descartar') => {
    const texto =
      tipo === 'resolver'
        ? `¿Ya subiste y publicaste ${LUGAR[s.lugar]?.toLowerCase() || 'la foto'} de ${s.alumno_nombre}? Le llega un mail a la familia para que la elija.`
        : `¿Descartar el pedido de foto de ${s.alumno_nombre}? Su kit deja de estar en espera y le llega un mail a la familia para que lo cierre.`;
    if (!window.confirm(texto)) return;
    setTrabajando(s.id);
    setAviso(null);
    setError(null);
    let r = await accionFaltanteAdmin(s.id, tipo);
    // 25/10: sin una foto de ese tipo publicada después del pedido, el servidor pregunta antes de mandar «ya publicamos».
    if (!r.success && r.codigo === 'SIN_FOTO_PUBLICADA' && window.confirm(`${r.error}\n\n¿Avisar igual a la familia?`)) {
      r = await accionFaltanteAdmin(s.id, tipo, { forzar: true });
    }
    setTrabajando(null);
    if (!r.success || !r.solicitud) return setError(r.error || 'No se pudo completar la acción.');
    setSolicitudes((prev) => prev.map((x) => (x.id === s.id ? r.solicitud! : x)));
    setAviso(
      tipo === 'descartar'
        ? `Descartado el pedido de ${s.alumno_nombre}.${r.avisoEnviado ? ' Le avisamos por mail que ya puede cerrar el kit.' : ' El mail a la familia no salió: avisale por WhatsApp.'}`
        : r.avisoEnviado
          ? `Listo: le avisamos por mail a la familia de ${s.alumno_nombre}.`
          : `Marcado como resuelto, pero el mail a la familia de ${s.alumno_nombre} no salió: avisale por WhatsApp.`
    );
  };

  const exportar = () => {
    const colegio = colegios.find((c) => c.id === colegioId);
    const datos = visibles.map((s) => ({
      Alumno: celdaSegura(s.alumno_nombre),
      Curso: celdaSegura(s.grado),
      División: celdaSegura(s.division),
      Turno: celdaSegura(s.turno),
      Foto: LUGAR[s.lugar] || s.lugar,
      Motivo: motivoPanel(s.motivo),
      'Nómina dice': s.nomina_tiene_foto === true ? 'Tiene la foto tildada' : s.nomina_tiene_foto === false ? 'Sin tildar' : 'No encontrado',
      Tutor: celdaSegura(s.tutor_nombre),
      Email: celdaSegura(s.contacto_email),
      WhatsApp: celdaSegura(s.contacto_whatsapp),
      Pedida: fecha(s.created_at),
      Estado: ESTADO[s.estado] || s.estado,
      Convocada: celdaSegura(textoConvocada(s).replace(/^Convocada: /, '')),
    }));
    const wb = XLSX.utils.book_new();
    const ws = XLSX.utils.json_to_sheet(datos);
    ws['!cols'] = [{ wch: 30 }, { wch: 14 }, { wch: 10 }, { wch: 10 }, { wch: 10 }, { wch: 16 }, { wch: 20 }, { wch: 24 }, { wch: 28 }, { wch: 16 }, { wch: 14 }, { wch: 10 }, { wch: 36 }];
    XLSX.utils.book_append_sheet(wb, ws, 'Faltantes');
    descargarLibroExcel(wb, `FALTANTES_${(colegio?.nombre || 'colegio').replace(/\s+/g, '_')}.xlsx`);
  };

  return (
    <div className="space-y-4 text-left text-slate-900">
      <div className="flex items-start gap-3">
        <CameraOff className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" aria-hidden="true" />
        <div>
          <h2 className="text-base font-bold">Faltantes solicitadas</h2>
          <p className="text-xs text-slate-600">
            Fotos que las familias pidieron desde la galería porque al chico le falta (hasta el {textoFechaCorta(plazos.faltantes)}). Mientras están
            pendientes, el kit de ese chico queda en espera. Subí y publicá la foto y después tocá «Ya está la foto»: le
            llega un mail a la familia para que la elija.
          </p>
        </div>
      </div>

      {/* 25/10 (auditoría): pasado el plazo, los pendientes siguen frenando el kit de esos chicos. */}
      {!solicitudFaltanteAbierta() && pendientes > 0 && (
        <p role="alert" className="rounded-xl border border-rose-300 bg-rose-50 px-3 py-2 text-xs font-semibold text-rose-800">
          Ya pasó el {textoFechaCorta(plazos.faltantes)} y quedan {pendientes} pedido(s) pendiente(s): esas familias no pueden cerrar el kit hasta que los resuelvas o los descartes.
        </p>
      )}

      <div className="flex flex-wrap items-end gap-2">
        <label className="text-xs font-semibold text-slate-700">
          Colegio
          <select value={colegioId} onChange={(e) => { setColegioId(e.target.value); setFiltroCurso(''); }} className="mt-1 block rounded-xl border border-slate-300 px-3 py-2 text-sm font-normal bg-white">
            {colegios.map((c) => (
              <option key={c.id} value={c.id}>{c.nombre}</option>
            ))}
          </select>
        </label>
        <label className="text-xs font-semibold text-slate-700">
          Estado
          <select value={filtroEstado} onChange={(e) => setFiltroEstado(e.target.value as typeof filtroEstado)} className="mt-1 block rounded-xl border border-slate-300 px-3 py-2 text-sm font-normal bg-white">
            <option value="pendiente">Pendientes ({pendientes})</option>
            <option value="resuelta">Ya están</option>
            <option value="cancelada">Canceladas</option>
            <option value="todas">Todas</option>
          </select>
        </label>
        <label className="text-xs font-semibold text-slate-700">
          Curso
          <select value={filtroCurso} onChange={(e) => setFiltroCurso(e.target.value)} className="mt-1 block rounded-xl border border-slate-300 px-3 py-2 text-sm font-normal bg-white">
            <option value="">Todos</option>
            {cursos.map((c) => (
              <option key={c} value={c}>{c}</option>
            ))}
          </select>
        </label>
        <button type="button" onClick={exportar} disabled={visibles.length === 0} className="inline-flex items-center gap-1.5 rounded-xl border border-slate-300 bg-white px-3 py-2 text-xs font-bold text-slate-700 hover:bg-slate-50 disabled:opacity-50 cursor-pointer">
          <Download className="w-3.5 h-3.5" aria-hidden="true" /> Excel
        </button>
      </div>

      <ConvocarFaltantes elegidas={elegidas} alTerminar={(mensaje) => { setAviso(mensaje); setElegidos(new Set()); void cargar(); }} />

      {aviso && <p role="status" className="text-xs font-semibold text-emerald-700">{aviso}</p>}
      {error && <p role="alert" className="text-xs font-semibold text-rose-700">{error}</p>}

      {cargando ? (
        <p className="text-xs text-slate-500">Cargando…</p>
      ) : visibles.length === 0 ? (
        <p className="text-xs text-slate-500">{solicitudes.length === 0 ? 'Todavía no hay pedidos de foto en este colegio.' : 'No hay pedidos con ese filtro.'}</p>
      ) : (
        <div className="overflow-x-auto rounded-2xl border border-slate-200 bg-white">
          <table className="w-full text-xs">
            <thead className="bg-slate-50 text-[11px] uppercase tracking-wide text-slate-500">
              <tr>
                <th className="py-2.5 pl-3 text-left">
                  {convocablesVisibles.length > 0 && (
                    <input type="checkbox" aria-label="Elegir todos los pedidos para convocar" title="Elegir todos para convocar (no incluye la grupal)" checked={elegidas.length === convocablesVisibles.length} onChange={(e) => setElegidos(e.target.checked ? new Set(convocablesVisibles.map((s) => s.id)) : new Set())} />
                  )}
                </th>
                <th className="py-2.5 px-3 text-left">Alumno</th>
                <th className="py-2.5 px-3 text-left">Curso</th>
                <th className="py-2.5 px-3 text-left">División</th>
                <th className="py-2.5 px-3 text-left">Turno</th>
                <th className="py-2.5 px-3 text-left">Foto</th>
                <th className="py-2.5 px-3 text-left">Motivo</th>
                <th className="py-2.5 px-3 text-left">Contacto</th>
                <th className="py-2.5 px-3 text-left">Pedida</th>
                <th className="py-2.5 px-3 text-left">Estado</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {visibles.map((s) => (
                <tr key={s.id} className="align-top">
                  <td className="py-2.5 pl-3">
                    {esConvocable(s) && <input type="checkbox" aria-label={`Elegir a ${s.alumno_nombre} para convocar`} checked={elegidos.has(s.id)} onChange={() => alternar(s.id)} />}
                  </td>
                  <td className="py-2.5 px-3">
                    <p className="font-bold text-sm">{s.alumno_nombre}</p>
                    {s.nomina_tiene_foto && <p className="mt-0.5 inline-block rounded-full bg-rose-100 px-2 py-0.5 text-[10px] font-bold text-rose-800">La nómina dice que ya tiene esta foto</p>}
                  </td>
                  <td className="py-2.5 px-3">{s.grado}</td>
                  <td className="py-2.5 px-3">{s.division}</td>
                  <td className="py-2.5 px-3">{s.turno}</td>
                  <td className="py-2.5 px-3 font-semibold">{LUGAR[s.lugar] || s.lugar}</td>
                  <td className="py-2.5 px-3">
                    <span className={`inline-block rounded-full px-2 py-0.5 text-[11px] font-semibold ${s.motivo === 'no_encontrada' ? 'bg-sky-100 text-sky-900' : 'bg-amber-100 text-amber-900'}`}>{motivoPanel(s.motivo)}</span>
                  </td>
                  <td className="py-2.5 px-3">
                    <p>{s.tutor_nombre}</p>
                    {s.contacto_email && <a href={`mailto:${s.contacto_email}`} className="block text-sky-700 hover:underline break-all">{s.contacto_email}</a>}
                    {soloDigitos(s.contacto_whatsapp).length >= 8 && (
                      <a href={linkWhatsApp(s.contacto_whatsapp)} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1 text-emerald-700 hover:underline">
                        <MessageCircle className="w-3 h-3" aria-hidden="true" /> {s.contacto_whatsapp}
                      </a>
                    )}
                  </td>
                  <td className="py-2.5 px-3">
                    <p className="whitespace-nowrap">{fecha(s.created_at)}</p>
                    {s.convocatoria_dia && <p className="mt-1 inline-block rounded-full bg-amber-100 px-2 py-0.5 text-[10px] font-bold text-amber-900">{textoConvocada(s)}</p>}
                  </td>
                  <td className="py-2.5 px-3">
                    {s.estado === 'pendiente' ? (
                      <div className="flex flex-col gap-1.5">
                        <button type="button" disabled={trabajando === s.id} onClick={() => void accion(s, 'resolver')} className="inline-flex items-center gap-1 rounded-lg bg-emerald-600 px-2.5 py-1.5 text-[11px] font-bold text-white hover:bg-emerald-700 disabled:opacity-50 cursor-pointer whitespace-nowrap">
                          {trabajando === s.id ? <Loader2 className="w-3 h-3 animate-spin" aria-hidden="true" /> : <CheckCircle2 className="w-3 h-3" aria-hidden="true" />} Ya está la foto
                        </button>
                        <button type="button" disabled={trabajando === s.id} onClick={() => void accion(s, 'descartar')} className="inline-flex items-center gap-1 rounded-lg border border-slate-300 px-2.5 py-1.5 text-[11px] font-bold text-slate-600 hover:bg-slate-50 disabled:opacity-50 cursor-pointer">
                          <XCircle className="w-3 h-3" aria-hidden="true" /> Descartar
                        </button>
                      </div>
                    ) : (
                      <p className="text-[11px] text-slate-600">
                        {ESTADO[s.estado]} {fecha(s.resuelta_at || s.cancelada_at)}
                        {s.estado === 'cancelada' && s.cancelada_por ? ` (por ${s.cancelada_por === 'familia' ? 'la familia' : 'vos'})` : ''}
                        {s.estado === 'resuelta' ? (s.aviso_enviado_at ? ' · mail enviado' : ' · sin mail') : ''}
                        {s.estado === 'resuelta' && !s.aviso_enviado_at && s.contacto_email && (
                          <button type="button" disabled={trabajando === s.id} onClick={() => void accion(s, 'resolver')} className="mt-1 block rounded-lg border border-slate-300 px-2 py-1 text-[11px] font-bold text-slate-700 hover:bg-slate-50 disabled:opacity-50 cursor-pointer">
                            Reenviar mail
                          </button>
                        )}
                      </p>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      <BusquedasRostroPanel colegioId={colegioId} />
    </div>
  );
}
