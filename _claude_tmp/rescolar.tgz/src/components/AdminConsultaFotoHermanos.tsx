import { useCallback, useEffect, useState } from 'react';
import { Camera, Download, Loader2, RefreshCw, Send } from 'lucide-react';
import { fetchAdminAutenticado } from '../services/adminAuthService';

/**
 * Consulta «foto de hermanos» (pedido de Pablo 08/10). Hasta el 08/10 la inscripción marcaba la foto
 * de hermanos a TODA familia que anotaba hermanos, aunque no tildara la casilla. Desde acá se les
 * manda un email con dos opciones (Sí / No); la familia confirma en /foto-hermanos.html y su
 * respuesta actualiza la marca sola. Servidor: sección CONSULTA «FOTO DE HERMANOS» de server.ts.
 * La foto de hermanos no tiene día fijo: los que dicen que sí dejan email y WhatsApp, y desde acá se
 * baja la lista para avisarles el día y el lugar.
 */
export interface ResumenConsultaFotoHermanos {
  conHermanos: number;
  confirmaronSi: number;
  confirmaronNo: number;
  sinConfirmar: number;
  porEnviar: number;
  enviadasSinRespuesta: number;
  paraRecordar: number;
  sinEmail: number;
}

type TipoEnvio = 'consulta' | 'recordatorio';

interface FamiliaFotoHermanos {
  tutor: string;
  chicos: string[];
  email: string;
  whatsapp: string;
  contactoDeLaConsulta: boolean;
  colegio: string;
  confirmo: string | null;
}

async function leerLista(): Promise<{ familias?: FamiliaFotoHermanos[]; error?: string }> {
  try {
    const res = await fetchAdminAutenticado('/api/admin/foto-hermanos/lista');
    const data = await res.json().catch(() => null);
    if (!res.ok || !data?.success || !Array.isArray(data.familias)) return { error: data?.error || 'No se pudo bajar la lista.' };
    return { familias: data.familias as FamiliaFotoHermanos[] };
  } catch {
    return { error: 'Error de conexión.' };
  }
}

async function leerResumen(): Promise<{ resumen?: ResumenConsultaFotoHermanos; error?: string }> {
  try {
    const res = await fetchAdminAutenticado('/api/admin/foto-hermanos/consulta');
    const data = await res.json().catch(() => null);
    if (!res.ok || !data?.success) return { error: data?.error || 'No se pudo leer la consulta.' };
    return { resumen: data as ResumenConsultaFotoHermanos };
  } catch {
    return { error: 'Error de conexión.' };
  }
}

async function enviarLote(recordatorio: boolean): Promise<{ ok: boolean; enviados: number; errores: number; restantes: number; resumen?: ResumenConsultaFotoHermanos; error?: string }> {
  try {
    const res = await fetchAdminAutenticado('/api/admin/foto-hermanos/consulta/enviar', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ recordatorio }),
    });
    const data = await res.json().catch(() => null);
    if (!res.ok || !data?.success) return { ok: false, enviados: 0, errores: 0, restantes: 0, error: data?.error || 'No se pudo enviar.' };
    return { ok: true, enviados: data.enviados || 0, errores: data.errores || 0, restantes: data.restantes || 0, resumen: data as ResumenConsultaFotoHermanos };
  } catch {
    return { ok: false, enviados: 0, errores: 0, restantes: 0, error: 'Error de conexión.' };
  }
}

export default function AdminConsultaFotoHermanos() {
  const [resumen, setResumen] = useState<ResumenConsultaFotoHermanos | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [cargando, setCargando] = useState(true);
  const [confirmando, setConfirmando] = useState<TipoEnvio | null>(null);
  const [enviando, setEnviando] = useState<TipoEnvio | null>(null);
  const [mensaje, setMensaje] = useState<string | null>(null);
  const [bajando, setBajando] = useState(false);

  const cargar = useCallback(async () => {
    setCargando(true);
    const r = await leerResumen();
    setCargando(false);
    if (r.resumen) {
      setResumen(r.resumen);
      setError(null);
    } else {
      setError(r.error || 'No se pudo leer la consulta.');
    }
  }, []);

  useEffect(() => {
    void cargar();
  }, [cargar]);

  const enviar = async (tipo: TipoEnvio) => {
    setConfirmando(null);
    setEnviando(tipo);
    setMensaje(null);
    let enviados = 0;
    let errores = 0;
    let restantes = 0;
    let fallo: string | null = null;
    // De a un lote de Resend (hasta 100) por llamada, hasta que no quede nadie.
    for (let vuelta = 0; vuelta < 10; vuelta++) {
      const r = await enviarLote(tipo === 'recordatorio');
      if (!r.ok) {
        fallo = r.error || 'No se pudo enviar.';
        break;
      }
      enviados += r.enviados;
      errores += r.errores;
      restantes = r.restantes;
      if (r.resumen) setResumen(r.resumen);
      if (!r.restantes || r.enviados === 0) break;
    }
    setEnviando(null);
    const partes = [`${enviados} email(s) enviados`];
    if (errores) partes.push(`${errores} rechazados por Resend (email mal escrito)`);
    if (restantes) partes.push(`quedan ${restantes}: volvé a tocar el botón`);
    setMensaje(fallo ? `${fallo}${enviados ? ` (antes de cortar se enviaron ${enviados})` : ''}` : `Listo: ${partes.join(', ')}.`);
  };

  // Lista de los que quieren la foto, con email y WhatsApp para avisarles el día y el lugar.
  const bajarLista = async () => {
    setBajando(true);
    setMensaje(null);
    const r = await leerLista();
    setBajando(false);
    if (!r.familias) return setMensaje(r.error || 'No se pudo bajar la lista.');
    if (r.familias.length === 0) return setMensaje('Todavía nadie confirmó que quiere la foto de hermanos.');
    // 21/10: Excel con formato (antes CSV: sin anchos y con los WhatsApp en notación científica).
    try {
      const { descargarExcelFotoHermanos } = await import('../services/excelLaboratorioEstilado');
      const ok = await descargarExcelFotoHermanos(r.familias, `foto-de-hermanos-${new Date().toISOString().slice(0, 10)}`);
      if (!ok) setMensaje('No se pudo generar el Excel. Probá de nuevo.');
    } catch (err) {
      console.error('[Foto de hermanos] Error al generar el Excel:', err);
      setMensaje('No se pudo generar el Excel. Probá de nuevo.');
    }
  };

  if (cargando && !resumen) {
    return (
      <div className="bg-white rounded-2xl border border-slate-200 p-4 text-xs text-slate-500 flex items-center gap-2">
        <Loader2 className="w-3.5 h-3.5 animate-spin" /> Cargando la consulta de foto de hermanos…
      </div>
    );
  }
  if (!resumen) {
    return error ? (
      <div className="bg-white rounded-2xl border border-slate-200 p-4 text-xs text-red-700 flex items-center justify-between gap-2">
        <span>Consulta de foto de hermanos: {error}</span>
        <button type="button" onClick={() => void cargar()} className="font-bold underline cursor-pointer">Reintentar</button>
      </div>
    ) : null;
  }
  if (resumen.conHermanos === 0) return null;

  const tarjetas: { etiqueta: string; valor: number; clase: string; titulo: string }[] = [
    { etiqueta: 'Sí', valor: resumen.confirmaronSi, clase: 'bg-emerald-50 border-emerald-200 text-emerald-900', titulo: 'Confirmaron que quieren la foto (en la consulta o en el formulario corregido)' },
    { etiqueta: 'No', valor: resumen.confirmaronNo, clase: 'bg-slate-50 border-slate-200 text-slate-800', titulo: 'Confirmaron que no la quieren: ya se les sacó la marca' },
    { etiqueta: 'Esperando', valor: resumen.enviadasSinRespuesta, clase: 'bg-amber-50 border-amber-200 text-amber-900', titulo: 'Les llegó el email y todavía no respondieron' },
    { etiqueta: 'Sin consultar', valor: resumen.porEnviar, clase: 'bg-white border-slate-200 text-slate-800', titulo: 'Marcadas por defecto y todavía no se les mandó el email' },
  ];
  const ocupado = enviando !== null;

  const botonEnvio = (tipo: TipoEnvio, cantidad: number, texto: string, primario: boolean) => {
    if (cantidad === 0) return null;
    if (confirmando === tipo) {
      return (
        <div className="flex flex-wrap items-center gap-2 text-[11px] bg-amber-50 border border-amber-300 rounded-lg px-2.5 py-1.5">
          <span className="font-bold text-amber-900">¿Mandar {cantidad} email(s) ahora?</span>
          <button type="button" onClick={() => void enviar(tipo)} className="px-2.5 py-1 rounded-md bg-amber-500 text-slate-950 font-extrabold cursor-pointer">Sí, enviar</button>
          <button type="button" onClick={() => setConfirmando(null)} className="px-2 py-1 rounded-md text-slate-600 font-bold cursor-pointer">Cancelar</button>
        </div>
      );
    }
    return (
      <button
        type="button"
        disabled={ocupado}
        onClick={() => setConfirmando(tipo)}
        className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-[11px] font-extrabold cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed ${
          primario ? 'bg-slate-900 text-white hover:bg-slate-800' : 'bg-white border border-slate-300 text-slate-800 hover:bg-slate-50'
        }`}
      >
        {enviando === tipo ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Send className="w-3.5 h-3.5" />}
        {texto} ({cantidad})
      </button>
    );
  };

  return (
    // 14/10/2026 (Pablo: el encabezado de Inscriptos ocupaba 2/3 de la pantalla): todo en una línea; la explicación
    // queda en el cartelito del título y de cada número.
    <div className="bg-white rounded-xl border border-slate-200 px-3 py-1.5 space-y-1 text-left">
      <div className="flex flex-wrap items-center gap-x-2 gap-y-1">
        <span
          className="text-xs font-bold text-slate-800 flex items-center gap-1.5"
          title="Hasta el 08/10 el sistema marcaba la foto de hermanos a todas las familias con hermanos, aunque no la pidieran. Mandales el email: cada familia elige Sí o No y su respuesta saca o deja la marca sola. Los que dicen que sí dejan email y WhatsApp para avisarles el día y el lugar."
        >
          <Camera className="w-3.5 h-3.5 text-slate-500" />
          Foto de hermanos:
        </span>
        {tarjetas.map((t) => (
          <span key={t.etiqueta} title={t.titulo} className={`rounded-full border px-2 py-0.5 text-[11px] font-semibold ${t.clase}`}>
            {t.etiqueta} <strong className="font-black">{t.valor}</strong>
          </span>
        ))}
        {botonEnvio('consulta', resumen.porEnviar, 'Enviar consulta', true)}
        {botonEnvio('recordatorio', resumen.paraRecordar, 'Recordatorio a los que no respondieron', false)}
        {resumen.porEnviar === 0 && resumen.paraRecordar === 0 && resumen.sinConfirmar > 0 && (
          <span className="text-[11px] text-slate-500" title="El recordatorio se habilita 20 h después del último envío.">Recordatorio en espera</span>
        )}
        {resumen.confirmaronSi > 0 && (
          <button
            type="button"
            onClick={() => void bajarLista()}
            disabled={bajando}
            className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-[11px] font-extrabold cursor-pointer bg-emerald-600 text-white hover:bg-emerald-700 disabled:opacity-50"
          >
            {bajando ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Download className="w-3.5 h-3.5" />}
            Bajar lista ({resumen.confirmaronSi})
          </button>
        )}
        {resumen.sinConfirmar === 0 && <span className="text-[11px] font-bold text-emerald-700">Todas ya confirmaron.</span>}
        <button type="button" onClick={() => void cargar()} disabled={cargando} title="Actualizar" aria-label="Actualizar la consulta de foto de hermanos" className="ml-auto p-1 rounded-lg text-slate-500 hover:bg-slate-100 cursor-pointer disabled:opacity-50">
          <RefreshCw className={`w-3.5 h-3.5 ${cargando ? 'animate-spin' : ''}`} />
        </button>
      </div>
      {resumen.sinEmail > 0 && (
        <p className="text-[11px] text-red-700">{resumen.sinEmail} familia(s) marcadas sin un email válido: consultales por WhatsApp.</p>
      )}
      {mensaje && <p className="text-[11px] text-slate-700 bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5">{mensaje}</p>}
    </div>
  );
}
