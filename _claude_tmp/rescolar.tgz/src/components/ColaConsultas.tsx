import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Archive, Bot, CheckCircle2, Clock3, ExternalLink, Flag, Loader2, Send, SkipForward, Sparkles, UserSearch, X } from 'lucide-react';
import {
  actualizarEstadoConsultaFamiliaAdmin,
  ConsultaCambiadaError,
  ConsultaFamilia,
  marcarAtencionEspecialAdmin,
  obtenerConsultasFamiliasAdmin,
  pedirAClaudeAdmin,
  responderConsultaFamiliaAdmin,
  sugerirRespuestaConsultaFamiliaAdmin,
  type AnalisisRespuestaIA as AnalisisRespuesta,
} from '../services/consultasFamiliasService';
import { useClaveEnvio } from '../utils/claveEnvio';
import { useBorradorAdmin } from '../utils/useBorradorAdmin';
import { armarCola, esperaDesde, haceCuanto, textoSinCita } from '../utils/colaConsultas';
import RevisionConsultaIA from './RevisionConsultaIA';
import AnalisisRespuestaIA, { hayAnalisis } from './AnalisisRespuestaIA';
import ModalFichaCliente from './ModalFichaCliente';

/**
 * 25/10/2026 «Atender consultas» (Pablo: que alguien con poca experiencia responda muchas consultas rápido).
 * Una consulta por vez, como una caja: arriba qué pide y la revisión de los datos; abajo la respuesta ya
 * escrita y cuatro botones fijos. Al enviar, pasa sola a la siguiente; nunca hay que volver a la lista.
 * La cola se arma al abrir (primero la que más espera) y no se reordena mientras se trabaja.
 */
type Resultado = 'respondida' | 'pablo' | 'archivada' | 'salteada';

// 28/10/2026: «Pedirle a Claude» sin rutina: el proyecto Retrato Escolar en claude.ai (ahí se pega el caso).
const URL_CLAUDE_PROYECTO = 'https://claude.ai/project/01a0db4a-0eb9-7142-8c5b-4dedc30f25d0';

async function copiarTexto(texto: string): Promise<boolean> {
  try {
    await navigator.clipboard.writeText(texto);
    return true;
  } catch {
    return false;
  }
}

export default function ColaConsultas({ onCerrar }: { onCerrar: () => void }) {
  const [cola, setCola] = useState<ConsultaFamilia[]>([]);
  const [indice, setIndice] = useState(0);
  const [cargando, setCargando] = useState(true);
  const [ocupado, setOcupado] = useState(false);
  const [generando, setGenerando] = useState(false);
  const [error, setError] = useState('');
  const [aviso, setAviso] = useState('');
  const [resultados, setResultados] = useState<Record<string, Resultado>>({});
  const [ficha, setFicha] = useState(false);
  const [idea, setIdea] = useState(''); // 26/10: idea para que la IA arme la respuesta
  // 27/10: «Pedirle a Claude» (sesión de Claude Code que investiga el caso): link de la sesión abierta para esta consulta.
  const [llamandoClaude, setLlamandoClaude] = useState(false);
  // 28/10: sin rutina, `texto` = el caso copiado para pegar en Claude (y `copiado` si el portapapeles funcionó).
  const [sesionClaude, setSesionClaude] = useState<{ id: string; url: string; texto?: string; copiado?: boolean } | null>(null);
  const [analisis, setAnalisis] = useState<AnalisisRespuesta | null>(null); // 26/10: qué entendió la IA, dudas y decisiones
  const actual = cola[indice] as ConsultaFamilia | undefined;
  const [respuesta, setRespuesta, borrador] = useBorradorAdmin(actual ? `consulta-${actual.id}` : null, '');
  const { claveParaEnviar, reiniciar } = useClaveEnvio();
  const textoRef = useRef<HTMLTextAreaElement | null>(null);

  const armar = useCallback(async (soloIds?: string[]) => {
    setCargando(true);
    setError('');
    try {
      const todas = await obtenerConsultasFamiliasAdmin('todas');
      const lista = armarCola(todas);
      setCola(soloIds ? lista.filter((c) => soloIds.includes(c.id)) : lista);
      setIndice(0);
    } catch (err: any) {
      setError(err?.message || 'No se pudieron cargar las consultas.');
    } finally {
      setCargando(false);
    }
  }, []);

  useEffect(() => { void armar(); }, [armar]);

  // Al mostrar una consulta: la respuesta arranca con el borrador de la IA y queda marcada como leída.
  useEffect(() => {
    if (!actual) return;
    borrador.fijarSinGuardar(actual.borradorIa || '');
    setIdea('');
    setAnalisis(actual.verificacionIa || null);
    setAviso('');
    setError('');
    setSesionClaude(null);
    if (actual.estado === 'nueva') void actualizarEstadoConsultaFamiliaAdmin(actual.id, 'en_proceso', 'nueva').catch(() => undefined);
    window.scrollTo?.({ top: 0 });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [actual?.id]);

  const siguiente = (id: string, resultado: Resultado) => {
    setResultados((prev) => ({ ...prev, [id]: resultado }));
    setFicha(false);
    setIndice((i) => i + 1);
  };

  const conManejo = async (accion: () => Promise<void>) => {
    if (!actual || ocupado) return;
    setOcupado(true);
    setError('');
    try {
      await accion();
    } catch (err: any) {
      setError(err instanceof ConsultaCambiadaError
        ? 'La familia escribió de nuevo mientras tanto: tocá «Saltear» y la vas a encontrar al final con su mensaje nuevo.'
        : err?.message || 'No se pudo completar. Probá de nuevo.');
    } finally {
      setOcupado(false);
    }
  };

  const enviar = () => conManejo(async () => {
    const c = actual as ConsultaFamilia;
    const texto = respuesta.trim();
    if (texto.length < 2) { setError('Escribí la respuesta antes de enviar.'); return; }
    await responderConsultaFamiliaAdmin(c.id, texto, claveParaEnviar(`${c.id}|${texto}`));
    reiniciar();
    void borrador.borrar(`consulta-${c.id}`);
    siguiente(c.id, 'respondida');
  });

  const mandarAPablo = () => conManejo(async () => {
    const c = actual as ConsultaFamilia;
    await marcarAtencionEspecialAdmin(c.id, true);
    siguiente(c.id, 'pablo');
  });

  const archivar = () => conManejo(async () => {
    const c = actual as ConsultaFamilia;
    // Si recién se abrió (estaba «nueva»), primero se asegura la marca de leída, así el control de «la familia
    // escribió de nuevo» compara contra el estado real.
    if (c.estado === 'nueva') await actualizarEstadoConsultaFamiliaAdmin(c.id, 'en_proceso', 'nueva').catch(() => undefined);
    await actualizarEstadoConsultaFamiliaAdmin(c.id, 'archivada', c.estado === 'nueva' ? 'en_proceso' : c.estado);
    siguiente(c.id, 'archivada');
  });

  // 27/10/2026: la pestaña se abre ANTES del pedido (si no, el navegador la bloquea por no venir del clic) y
  // después se le carga el link de la sesión de Claude. Si falla, se cierra y se muestra el error.
  // 28/10/2026: la cuenta no tiene el disparador por API de las rutinas → el servidor devuelve el caso como texto: se
  // copia al portapapeles (antes de abrir la pestaña, porque sin foco el navegador no deja copiar) y se abre Claude en
  // el proyecto Retrato Escolar para pegarlo. Si el navegador bloquea la pestaña o el copiado, quedan el link y «Copiar».
  const pedirAClaude = async () => {
    if (!actual || llamandoClaude) return;
    const c = actual;
    setLlamandoClaude(true);
    setError('');
    try {
      const r = await pedirAClaudeAdmin(c.id, idea);
      if (r.texto) {
        const copiado = await copiarTexto(r.texto);
        window.open(URL_CLAUDE_PROYECTO, '_blank', 'noopener');
        setSesionClaude({ id: c.id, url: URL_CLAUDE_PROYECTO, texto: r.texto, copiado });
      } else if (r.url) {
        window.open(r.url, '_blank', 'noopener');
        setSesionClaude({ id: c.id, url: r.url });
      }
    } catch (err: any) {
      setError(err?.message || 'No pudimos pedirle el caso a Claude.');
    } finally {
      setLlamandoClaude(false);
    }
  };

  const copiarDeNuevo = async () => {
    if (!sesionClaude?.texto) return;
    const copiado = await copiarTexto(sesionClaude.texto);
    setSesionClaude((s) => (s ? { ...s, copiado } : s));
  };

  const saltear = () => { if (actual && !ocupado) siguiente(actual.id, 'salteada'); };

  const pedirALaIA = async () => {
    if (!actual || generando) return;
    const id = actual.id;
    setGenerando(true);
    setAviso('');
    try {
      const { sugerencia, aviso: motivo, analisis: nuevo } = await sugerirRespuestaConsultaFamiliaAdmin(id, idea);
      if (cola[indice]?.id !== id) return;
      setRespuesta(sugerencia);
      setAnalisis(nuevo || null);
      if (!sugerencia) setAviso(motivo || 'La IA considera que no hace falta responder.');
    } catch (err: any) {
      setError(err?.message || 'La IA no pudo armar la respuesta. Escribila a mano.');
    } finally {
      setGenerando(false);
    }
  };

  // Ctrl/Cmd + Enter = «Enviar y siguiente». Escape cierra.
  useEffect(() => {
    const alTeclear = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') { e.preventDefault(); void enviar(); }
      if (e.key === 'Escape' && !ficha) onCerrar();
    };
    window.addEventListener('keydown', alTeclear);
    return () => window.removeEventListener('keydown', alTeclear);
  });

  const cuenta = useMemo(() => {
    const valores = Object.values(resultados);
    const n = (r: Resultado) => valores.filter((v) => v === r).length;
    return { respondida: n('respondida'), pablo: n('pablo'), archivada: n('archivada'), salteada: n('salteada') };
  }, [resultados]);
  const salteadas = Object.entries(resultados).filter(([, r]) => r === 'salteada').map(([id]) => id);
  const total = cola.length;
  const terminado = !cargando && indice >= total;

  return (
    <div className="fixed inset-0 z-50 bg-slate-100 overflow-y-auto" role="dialog" aria-modal="true" aria-label="Atender consultas">
      <header className="sticky top-0 z-10 bg-white border-b border-slate-200">
        <div className="max-w-3xl mx-auto px-4 py-3 flex items-center gap-3">
          <div className="min-w-0 flex-1">
            <p className="text-sm font-extrabold text-slate-900">Atender consultas</p>
            {!cargando && total > 0 && (
              <p className="text-xs text-slate-500">{terminado ? `${total} de ${total}` : `Consulta ${indice + 1} de ${total}`}</p>
            )}
          </div>
          <button type="button" onClick={onCerrar} className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl border border-slate-300 text-xs font-bold text-slate-700 hover:bg-slate-50 cursor-pointer">
            <X className="w-4 h-4" />Salir
          </button>
        </div>
        {total > 0 && (
          <div className="h-1 bg-slate-100" aria-hidden="true">
            <div className="h-1 bg-emerald-500 transition-all" style={{ width: `${Math.min(100, (indice / total) * 100)}%` }} />
          </div>
        )}
      </header>

      <main className="max-w-3xl mx-auto px-4 py-5 pb-40">
        {cargando ? (
          <div className="py-20 text-center text-slate-400"><Loader2 className="w-6 h-6 animate-spin mx-auto" /></div>
        ) : error && !actual ? (
          <p className="p-4 rounded-2xl border border-red-200 bg-red-50 text-red-700 text-sm">{error}</p>
        ) : terminado ? (
          <section className="mt-10 p-8 rounded-3xl bg-white border border-slate-200 text-center space-y-4">
            <CheckCircle2 className="w-12 h-12 text-emerald-500 mx-auto" />
            <h2 className="text-xl font-extrabold text-slate-900">{total === 0 ? 'No hay consultas por responder' : '¡Listo!'}</h2>
            {total > 0 && (
              <ul className="text-sm text-slate-600 space-y-1">
                <li><strong>{cuenta.respondida}</strong> respondidas</li>
                {cuenta.pablo > 0 && <li><strong>{cuenta.pablo}</strong> mandadas a Pablo (están en «Atención especial»)</li>}
                {cuenta.archivada > 0 && <li><strong>{cuenta.archivada}</strong> archivadas sin responder</li>}
                {cuenta.salteada > 0 && <li><strong>{cuenta.salteada}</strong> salteadas</li>}
              </ul>
            )}
            <div className="flex flex-wrap justify-center gap-2 pt-2">
              {salteadas.length > 0 && (
                <button type="button" onClick={() => { setResultados({}); void armar(salteadas); }} className="px-4 py-2.5 rounded-xl bg-slate-900 text-white text-sm font-bold hover:bg-slate-800 cursor-pointer">Ver las salteadas</button>
              )}
              <button type="button" onClick={() => { setResultados({}); void armar(); }} className="px-4 py-2.5 rounded-xl border border-slate-300 bg-white text-sm font-bold text-slate-700 hover:bg-slate-50 cursor-pointer">Buscar consultas nuevas</button>
              <button type="button" onClick={onCerrar} className="px-4 py-2.5 rounded-xl border border-slate-300 bg-white text-sm font-bold text-slate-700 hover:bg-slate-50 cursor-pointer">Volver a la bandeja</button>
            </div>
          </section>
        ) : actual ? (
          <div className="space-y-4">
            <section className="p-4 sm:p-5 rounded-2xl bg-white border border-slate-200 space-y-3">
              <div className="flex flex-wrap items-start justify-between gap-2">
                <div className="min-w-0">
                  <h2 className="text-lg font-extrabold text-slate-900 truncate">{actual.nombre}</h2>
                  <p className="text-xs text-slate-500 break-all">{actual.email}{actual.colegio ? ` · ${actual.colegio}` : ''}{actual.numeroPedido ? ` · Pedido ${actual.numeroPedido}` : ''}</p>
                </div>
                <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-amber-50 text-amber-800 text-xs font-bold"><Clock3 className="w-3.5 h-3.5" />Espera {haceCuanto(esperaDesde(actual))}</span>
              </div>
              <p className="text-sm font-bold text-slate-800">{actual.asunto}</p>
              <Conversacion consulta={actual} />
              <div className="flex flex-wrap gap-2">
                <button type="button" onClick={() => setFicha(true)} className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl border border-slate-300 bg-white text-xs font-bold text-slate-700 hover:bg-slate-50 cursor-pointer"><UserSearch className="w-3.5 h-3.5" />Ficha del cliente</button>
                <button type="button" disabled={llamandoClaude} onClick={() => void pedirAClaude()} title="Copia este caso y abre Claude en el proyecto Retrato Escolar para que lo pegues" className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl border border-violet-300 bg-violet-50 text-xs font-bold text-violet-800 hover:bg-violet-100 disabled:opacity-50 cursor-pointer">
                  {llamandoClaude ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Bot className="w-3.5 h-3.5" />}
                  {llamandoClaude ? 'Llamando a Claude…' : 'Pedirle a Claude'}
                </button>
              </div>
              {sesionClaude?.id === actual.id && (sesionClaude.texto ? (
                <div role="status" className="text-xs text-violet-800 space-y-1">
                  <p>
                    {sesionClaude.copiado
                      ? 'Copiamos el caso. En la pestaña de Claude pegalo con Ctrl+V y tocá Enter.'
                      : 'No pudimos copiar el caso solo: tocá «Copiar el caso» y pegalo en Claude con Ctrl+V.'}
                  </p>
                  <p className="flex flex-wrap items-center gap-3">
                    <a href={sesionClaude.url} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1 font-bold underline">Abrir Claude<ExternalLink className="w-3 h-3" /></a>
                    <button type="button" onClick={() => void copiarDeNuevo()} className="font-bold underline cursor-pointer">Copiar el caso{sesionClaude.copiado ? ' de nuevo' : ''}</button>
                  </p>
                </div>
              ) : (
                <p role="status" className="text-xs text-violet-800">
                  Claude está revisando el caso en otra pestaña.{' '}
                  <a href={sesionClaude.url} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1 font-bold underline">Abrir la sesión<ExternalLink className="w-3 h-3" /></a>
                </p>
              ))}
            </section>

            <RevisionConsultaIA consulta={actual} revisando={generando} onRevisar={() => void pedirALaIA()} />

            <section className="p-4 sm:p-5 rounded-2xl bg-white border border-sky-200 space-y-2">
              <div className="flex items-center justify-between gap-2">
                <label htmlFor="respuesta-cola" className="text-sm font-bold text-slate-900">Respuesta para {actual.nombre}</label>
                <button type="button" disabled={generando} onClick={() => void pedirALaIA()} className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-sky-300 bg-white text-xs font-bold text-sky-700 hover:bg-sky-50 disabled:opacity-50 cursor-pointer">
                  {generando ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Sparkles className="w-3.5 h-3.5" />}
                  {generando ? 'Investigando…' : idea.trim() ? 'Armar con mi idea' : respuesta.trim() ? 'Pedir otra a la IA' : 'Pedir respuesta a la IA'}
                </button>
              </div>
              {generando && <p role="status" className="text-xs text-sky-800">La IA está investigando la consulta (familia, nómina, fotos del curso, pedidos, conversaciones anteriores). Puede tardar hasta un minuto y medio.</p>}
              {hayAnalisis(analisis) && <AnalisisRespuestaIA analisis={analisis} onUsarOpcion={(o) => { setIdea(o); document.getElementById('idea-cola')?.focus(); }} />}
              <div className="space-y-1">
                <label htmlFor="idea-cola" className="text-xs font-bold text-slate-700">Tu idea para la IA <span className="font-normal text-slate-500">(opcional)</span></label>
                <input id="idea-cola" type="text" value={idea} onChange={(e) => setIdea(e.target.value)} onKeyDown={(e) => { if (e.key === 'Enter' && !e.ctrlKey && !e.metaKey) { e.preventDefault(); void pedirALaIA(); } }} maxLength={1500} placeholder="Ej.: decile que las fotos se suben el viernes y que el código le llega por mail" className="w-full rounded-xl border border-slate-300 bg-white px-3 py-2 text-sm outline-none focus:border-sky-500 focus:ring-2 focus:ring-sky-200" />
                <p className="text-[11px] text-slate-500">Escribí en pocas palabras qué querés contestar y tocá «Armar con mi idea» (o Enter): la IA lo redacta abajo.</p>
              </div>
              <textarea id="respuesta-cola" ref={textoRef} value={respuesta} onChange={(e) => setRespuesta(e.target.value)} rows={9} maxLength={5000} placeholder="Escribí la respuesta, o tocá «Pedir respuesta a la IA»." className="w-full resize-y rounded-xl border border-slate-300 bg-white p-3 text-sm leading-relaxed outline-none focus:border-sky-500 focus:ring-2 focus:ring-sky-200" />
              {aviso && <p className="text-xs font-semibold text-amber-700">{aviso}</p>}
              <p className="text-[11px] text-slate-500">Leela antes de enviar. Si no estás seguro/a de qué responder, tocá «Mandar a Pablo».</p>
            </section>
            {error && <p role="alert" className="p-3 rounded-xl border border-red-200 bg-red-50 text-red-700 text-sm">{error}</p>}
          </div>
        ) : null}
      </main>

      {actual && !terminado && (
        <footer className="fixed bottom-0 inset-x-0 z-10 bg-white border-t border-slate-200 shadow-[0_-4px_12px_rgba(15,23,42,0.06)]">
          <div className="max-w-3xl mx-auto px-4 py-3 grid grid-cols-2 sm:grid-cols-4 gap-2">
            <button type="button" disabled={ocupado || respuesta.trim().length < 2} onClick={() => void enviar()} className="col-span-2 sm:col-span-1 sm:order-4 inline-flex items-center justify-center gap-2 px-4 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-sm font-extrabold disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer" title="Ctrl + Enter">
              {ocupado ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}Enviar y siguiente
            </button>
            <button type="button" disabled={ocupado} onClick={saltear} className="inline-flex items-center justify-center gap-1.5 px-3 py-3 rounded-xl border border-slate-300 bg-white text-xs font-bold text-slate-700 hover:bg-slate-50 disabled:opacity-50 cursor-pointer"><SkipForward className="w-4 h-4" />Saltear</button>
            <button type="button" disabled={ocupado} onClick={() => void mandarAPablo()} className="inline-flex items-center justify-center gap-1.5 px-3 py-3 rounded-xl border border-rose-300 bg-rose-50 text-xs font-bold text-rose-700 hover:bg-rose-100 disabled:opacity-50 cursor-pointer"><Flag className="w-4 h-4" />Mandar a Pablo</button>
            <button type="button" disabled={ocupado} onClick={() => void archivar()} className="col-span-2 sm:col-span-1 inline-flex items-center justify-center gap-1.5 px-3 py-3 rounded-xl border border-slate-300 bg-white text-xs font-bold text-slate-700 hover:bg-slate-50 disabled:opacity-50 cursor-pointer"><Archive className="w-4 h-4" />No necesita respuesta</button>
          </div>
        </footer>
      )}

      {ficha && actual && (
        <ModalFichaCliente inicial={{ nombre: actual.nombre, email: actual.email, telefono: actual.telefono, pedido: actual.numeroPedido }} onCerrar={() => setFicha(false)} />
      )}
    </div>
  );
}

/** El mensaje original y lo que se habló después, en orden. Lo último de la familia, resaltado. */
function Conversacion({ consulta }: { consulta: ConsultaFamilia }) {
  const items = [
    { id: 'original', deFamilia: true, texto: consulta.mensaje, fecha: consulta.createdAt, automatica: false },
    ...[...consulta.mensajes]
      .sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime())
      .map((m) => ({ id: m.id, deFamilia: m.direccion === 'entrante', texto: m.contenido, fecha: m.createdAt, automatica: Boolean(m.automatica) })),
  ];
  const [verTodo, setVerTodo] = useState(false);
  const [completos, setCompletos] = useState<Record<string, boolean>>({}); // 28/10: mensajes con la cita a la vista
  const visibles = verTodo ? items : items.slice(-3);
  return (
    <div className="space-y-2">
      {items.length > visibles.length && (
        <button type="button" onClick={() => setVerTodo(true)} className="text-xs font-bold text-sky-700 hover:underline cursor-pointer">Ver los {items.length - visibles.length} mensajes anteriores</button>
      )}
      {visibles.map((m, i) => {
        const ultimo = i === visibles.length - 1;
        const corto = textoSinCita(m.texto);
        const recortado = corto !== String(m.texto ?? '').replace(/\r/g, '').trim();
        return (
          <div key={m.id} className={`p-3 rounded-xl text-sm whitespace-pre-wrap leading-relaxed ${m.deFamilia ? (ultimo ? 'bg-amber-50 border border-amber-200 text-slate-900' : 'bg-slate-50 border border-slate-200 text-slate-700') : 'bg-sky-50 border border-sky-100 text-slate-700 ml-6'}`}>
            <p className="text-[11px] font-bold mb-1 text-slate-500">
              {m.deFamilia ? 'Familia' : m.automatica ? 'Respuesta automática' : 'Nosotros'} · {new Date(m.fecha).toLocaleString('es-AR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' })}
            </p>
            {completos[m.id] ? m.texto : corto}
            {recortado && (
              <button type="button" onClick={() => setCompletos((c) => ({ ...c, [m.id]: !c[m.id] }))} className="block mt-1 text-[11px] font-bold text-sky-700 hover:underline cursor-pointer">
                {completos[m.id] ? 'Ocultar el mail citado' : 'Ver completo (mail citado)'}
              </button>
            )}
          </div>
        );
      })}
    </div>
  );
}
