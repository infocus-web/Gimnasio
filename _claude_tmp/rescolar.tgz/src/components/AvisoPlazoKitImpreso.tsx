import { CalendarX } from 'lucide-react';
import { textoFechaLarga, usePlazosTemporada } from '../utils/plazosTemporada';

/** 26/10/2026: aviso en el paso «Elegí tu Kit» cuando ya pasó el plazo del Kit Impreso (utils/plazoKitImpreso.ts). */
export default function AvisoPlazoKitImpreso({ esSecundaria }: { esSecundaria: boolean }) {
  const plazos = usePlazosTemporada(); // 30/10: la fecha sale del panel → Configuración
  return (
    <div role="status" className="max-w-3xl mx-auto rounded-xl border border-amber-300 bg-amber-50 px-4 py-3 text-left text-sm text-amber-950 flex items-start gap-2">
      <CalendarX className="w-5 h-5 shrink-0 text-amber-700" aria-hidden="true" />
      <p>
        <strong>El plazo para elegir las fotos del Kit Impreso terminó el {textoFechaLarga(plazos.kitImpreso)}.</strong>{' '}
        {esSecundaria
          ? 'Si necesitás el kit de tu hijo/a, escribinos desde «Consultas» y te ayudamos.'
          : 'Podés elegir el kit Solo Digital, que no tiene límite de tiempo. Si ya pagaste el Kit Impreso, escribinos desde «Consultas».'}
      </p>
    </div>
  );
}
