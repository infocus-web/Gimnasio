import { useState } from 'react';
import { Loader2, Tag, X } from 'lucide-react';
import { TOPE_DESCUENTO_IMPRESO, validarCodigoDescuento, type CodigoDescuentoAplicado } from '../services/descuentosService';

/**
 * Paso 4 del portal (22/10/2026, Pablo): campo «¿Tenés un código de descuento?». Valida el código con el servidor y
 * muestra el descuento (sólo sobre el kit). El monto que se cobra lo recalcula el servidor al crear el pedido.
 */
interface Props {
  aplicado: CodigoDescuentoAplicado | null;
  /** Lo que se descuenta en esta compra (todos los kits), para mostrarlo. */
  montoDescontado: number;
  onCambiar: (descuento: CodigoDescuentoAplicado | null) => void;
  deshabilitado?: boolean;
}

export default function CampoCodigoDescuento({ aplicado, montoDescontado, onCambiar, deshabilitado }: Props) {
  const [abierto, setAbierto] = useState(false);
  const [texto, setTexto] = useState('');
  const [validando, setValidando] = useState(false);
  const [error, setError] = useState('');

  if (aplicado) {
    return (
      <div className="mt-2 flex items-center justify-between gap-2 rounded-lg border border-emerald-500/40 bg-emerald-950/40 px-2.5 py-1.5 text-[11px] text-emerald-200" role="status">
        <span className="flex items-center gap-1.5 min-w-0">
          <Tag className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
          <span className="truncate">Código {aplicado.codigo} ({aplicado.porcentaje > TOPE_DESCUENTO_IMPRESO && !aplicado.sinTopeImpreso ? `${aplicado.porcentaje}% en el kit digital, ${TOPE_DESCUENTO_IMPRESO}% en el impreso` : `${aplicado.porcentaje}% en el kit`})</span>
        </span>
        <span className="flex items-center gap-2 shrink-0">
          <strong>-${montoDescontado.toLocaleString('es-AR')}</strong>
          <button type="button" disabled={deshabilitado} onClick={() => onCambiar(null)} aria-label="Quitar el código de descuento" className="rounded p-0.5 text-emerald-300 hover:bg-emerald-900 cursor-pointer disabled:opacity-50">
            <X className="w-3.5 h-3.5" />
          </button>
        </span>
      </div>
    );
  }
  if (!abierto) {
    return (
      <button type="button" disabled={deshabilitado} onClick={() => setAbierto(true)} className="mt-2 text-[11px] font-semibold text-amber-300 underline underline-offset-2 hover:text-amber-200 cursor-pointer disabled:opacity-50">
        ¿Tenés un código de descuento?
      </button>
    );
  }
  const aplicar = async () => {
    const codigo = texto.trim();
    if (!codigo) return setError('Escribí el código.');
    setValidando(true);
    setError('');
    const r = await validarCodigoDescuento(codigo);
    setValidando(false);
    if (!r.success || !r.descuento) return setError(r.error || 'El código de descuento no es válido.');
    onCambiar(r.descuento);
    setAbierto(false);
    setTexto('');
  };
  return (
    <div className="mt-2 space-y-1">
      <div className="flex gap-2">
        <label htmlFor="codigo-descuento" className="sr-only">Código de descuento</label>
        <input
          id="codigo-descuento"
          value={texto}
          onChange={(e) => setTexto(e.target.value.toUpperCase())}
          onKeyDown={(e) => { if (e.key === 'Enter') { e.preventDefault(); void aplicar(); } }}
          placeholder="Código de descuento"
          autoComplete="off"
          className="min-w-0 flex-1 rounded-lg border border-slate-600 bg-slate-900 px-2.5 py-1.5 text-xs text-white placeholder:text-slate-500"
        />
        <button type="button" disabled={validando || deshabilitado} onClick={() => void aplicar()} className="inline-flex items-center gap-1 rounded-lg bg-slate-700 px-3 py-1.5 text-xs font-bold text-white hover:bg-slate-600 cursor-pointer disabled:opacity-50">
          {validando && <Loader2 className="w-3 h-3 animate-spin" aria-hidden="true" />} Aplicar
        </button>
      </div>
      {error && <p role="alert" className="text-[11px] font-semibold text-rose-300">{error}</p>}
    </div>
  );
}
