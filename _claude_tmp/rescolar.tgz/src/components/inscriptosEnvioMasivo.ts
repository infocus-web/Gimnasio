import { enviarEmailAprobacionAdmin, type InscripcionFamilia } from '../services/inscripcionesService';
import { iniciarProceso } from '../utils/procesoEnCurso';

// 14/10/2026 (auditoría): «Enviar todos los emails pendientes» seguía mandando aunque se cerrara la pestaña
// de Inscriptos, y dos clics (o dos pestañas) arrancaban dos bucles a la vez. El bucle vive acá (fuera de
// AdminInscriptosTab, que está en su techo de líneas): corta cuando `seguir()` da false y queda anotado como
// proceso en curso (el navegador pregunta antes de cerrar y la recarga por versión nueva espera). El servidor,
// además, no repite un email que ya salió.
// 14/10/2026: `yaEnviado` del servidor (la marca ya estaba en true: otro envío, otra pestaña o un intento que
// se cortó entre la marca y Resend; la tabla no tiene una columna con la hora de la marca para liberarla
// sola) se cuenta aparte, como «ya figuraba enviado», no como un email que salió ahora.
export interface ResultadoEnvioMasivo { enviados: number; yaFiguraban: number; fallidos: string[]; cortado: boolean }

/** Título, texto y tipo del aviso al terminar el envío masivo. */
export function resumenEnvioMasivo({ enviados, yaFiguraban, fallidos }: ResultadoEnvioMasivo, total: number) {
  const ya = yaFiguraban > 0 ? ` ${yaFiguraban} ya figuraba${yaFiguraban === 1 ? '' : 'n'} enviado${yaFiguraban === 1 ? '' : 's'} (no se mandaron de nuevo; si una familia no lo tiene, usá «Reenviar» en su ficha).` : '';
  if (fallidos.length === 0) {
    return { titulo: yaFiguraban > 0 ? 'Envío masivo terminado' : '¡Todos los emails fueron enviados!', mensaje: `Se mandó el código de acceso a ${enviados} de ${total} familias.${ya}`, tipo: 'success' as const };
  }
  const lista = `${fallidos.slice(0, 5).join('; ')}${fallidos.length > 5 ? ` y ${fallidos.length - 5} más` : ''}`;
  return { titulo: 'Envío masivo terminado con algunos errores', mensaje: `Se enviaron ${enviados} de ${total}.${ya} No se pudieron enviar: ${lista}.`, tipo: 'error' as const };
}

export async function enviarCodigosEnSerie(
  lista: InscripcionFamilia[],
  opciones: { seguir: () => boolean; onProgreso?: (hechos: number, total: number) => void; pausaMs?: number }
): Promise<ResultadoEnvioMasivo> {
  const fin = iniciarProceso('Envío de códigos de acceso por email');
  let enviados = 0;
  let yaFiguraban = 0;
  const fallidos: string[] = [];
  try {
    for (let i = 0; i < lista.length; i++) {
      if (!opciones.seguir()) return { enviados, yaFiguraban, fallidos, cortado: true };
      const item = lista[i];
      if (!item.email) {
        fallidos.push(`${item.alumnoNombre} ${item.alumnoApellido} (no tiene email cargado)`);
      } else {
        const resultado = await enviarEmailAprobacionAdmin(item.id);
        if (resultado.success && resultado.yaEnviado) yaFiguraban++;
        else if (resultado.success) enviados++;
        else fallidos.push(`${item.alumnoNombre} ${item.alumnoApellido} (${resultado.error || 'error desconocido'})`);
      }
      opciones.onProgreso?.(i + 1, lista.length);
      // Pausa entre envíos (no en el último) para no mandar todas las llamadas a Resend a la vez.
      if (i < lista.length - 1) await new Promise((resolve) => setTimeout(resolve, opciones.pausaMs ?? 600));
    }
    return { enviados, yaFiguraban, fallidos, cortado: false };
  } finally {
    fin();
  }
}
