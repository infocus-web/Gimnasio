import { useCallback, useEffect, useRef, useState } from 'react';
import { cancelarFaltante, estadoFaltantes, solicitarFaltante, type SolicitudFaltanteFamilia } from '../services/fotosFaltantesService';
import { nuevaClaveEnvio } from '../utils/claveEnvio';
import { solicitudFaltanteAbierta, type LugarPack, type MotivoFaltante } from '../utils/fotosFaltantes';

/**
 * «Faltantes solicitadas» en el portal (22/10/2026): pedidos de foto pendientes del chico que está en pantalla,
 * y las acciones para pedir / cancelar. Sin la llave de galería de la familia no se ofrece (el servidor la exige).
 */
export interface FaltantesSolicitadas {
  disponible: boolean;
  abierto: boolean;
  pendiente: (lugar: LugarPack) => SolicitudFaltanteFamilia | undefined;
  solicitar: (lugar: LugarPack, motivo: MotivoFaltante, email: string, whatsapp: string) => Promise<string | null>;
  cancelar: (lugar: LugarPack) => Promise<string | null>;
}

export function useFaltantesSolicitadas(datos: { codigo: string | null; familia?: string; acceso?: string; alumnoNombre: string; tutorNombre?: string }): FaltantesSolicitadas {
  const { codigo, familia, acceso, alumnoNombre, tutorNombre } = datos;
  const disponible = Boolean(codigo && familia && acceso && alumnoNombre);
  const [solicitudes, setSolicitudes] = useState<SolicitudFaltanteFamilia[]>([]);
  const [abierto, setAbierto] = useState(solicitudFaltanteAbierta());
  const generacion = useRef(0);
  const credenciales = useCallback(
    () => ({ codigo: String(codigo || ''), familia: String(familia || ''), acceso: String(acceso || ''), alumnoNombre }),
    [codigo, familia, acceso, alumnoNombre]
  );

  useEffect(() => {
    const yo = ++generacion.current;
    setSolicitudes([]);
    if (!disponible) return;
    void estadoFaltantes(credenciales()).then((r) => {
      if (yo !== generacion.current || !r.success) return;
      setSolicitudes(r.solicitudes || []);
      if (typeof r.abierto === 'boolean') setAbierto(r.abierto);
    });
  }, [disponible, credenciales]);

  const pendiente = useCallback((lugar: LugarPack) => solicitudes.find((s) => s.lugar === lugar && s.estado === 'pendiente'), [solicitudes]);

  const solicitar = useCallback(
    async (lugar: LugarPack, motivo: MotivoFaltante, email: string, whatsapp: string) => {
      const yo = generacion.current; // si cambia de hijo mientras se envía, no se mezcla con el hermano
      const r = await solicitarFaltante(credenciales(), { lugar, motivo, email, whatsapp, tutorNombre: tutorNombre || '', clave: nuevaClaveEnvio() });
      if (!r.success || !r.solicitud) return r.error || 'No pudimos guardar el pedido de foto.';
      if (yo !== generacion.current) return null;
      const nueva = r.solicitud;
      setSolicitudes((prev) => [...prev.filter((s) => s.id !== nueva.id), nueva]);
      return null;
    },
    [credenciales, tutorNombre]
  );

  const cancelar = useCallback(
    async (lugar: LugarPack) => {
      const actual = solicitudes.find((s) => s.lugar === lugar && s.estado === 'pendiente');
      if (!actual) return null;
      const yo = generacion.current;
      const r = await cancelarFaltante(credenciales(), actual.id);
      if (!r.success) return r.error || 'No pudimos cancelar el pedido de foto.';
      if (yo !== generacion.current) return null;
      setSolicitudes((prev) => prev.filter((s) => s.id !== actual.id));
      return null;
    },
    [credenciales, solicitudes]
  );

  return { disponible, abierto, pendiente, solicitar, cancelar };
}
