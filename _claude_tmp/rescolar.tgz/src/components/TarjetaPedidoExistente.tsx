import { useState } from 'react';
import { ArrowRight, Clock, CreditCard, Package, PackageCheck } from 'lucide-react';
import SubirComprobante from './SubirComprobante';
import ComprarFotosExtra, { type DatosCompraFotosExtra } from './ComprarFotosExtra';
import PagoPedidoAdicional from './PagoPedidoAdicional';
import { prepararMejoraAImpreso } from '../services/pedidosLabService';
import type { PedidoExistenteResumen } from '../services/pedidosLabService';

/**
 * Cartel "ya tiene un pedido registrado" del Paso 1 del portal (sacado de PortalFamiliasModal.tsx el
 * 14/10/2026, mismo contenido). Además, desde el 14/10/2026:
 * - Transferencia con el comprobante ya subido: «Comprobante en revisión» y "hacer otro pedido" sólo con
 *   una confirmación expresa (antes invitaba a comprar de nuevo → cobro doble).
 * - Pedido pendiente con tarjeta: «Pagar ahora / cambiar el medio de pago» también desde otro dispositivo
 *   (el servidor le da la llave del pedido a la familia identificada; ver /api/pedidos/existente).
 */
interface Props {
  pedido: PedidoExistenteResumen;
  nombreAlumno: string;
  codigoSeccion: string | null;
  onReingresar: () => void;
  onVerPedido: () => void;
  onOtroPedido: () => void;
  onPagarAhora: () => void;
  /** 29/10/2026: datos para pedir fotos extra (familia identificada y tutor, para Mercado Pago). */
  datosCompra?: DatosCompraFotosExtra;
}

export default function TarjetaPedidoExistente({ pedido, nombreAlumno, codigoSeccion, onReingresar, onVerPedido, onOtroPedido, onPagarAhora, datosCompra }: Props) {
  const [confirmandoOtro, setConfirmandoOtro] = useState(false);
  const pendiente = pedido.estado === 'pendiente_pago';
  const esTransferencia = pedido.metodoPago === 'transferencia';
  const comprobanteEnRevision = pendiente && Boolean(pedido.comprobanteSubido);
  const puedePagarAhora = pendiente && !esTransferencia && !comprobanteEnRevision && Boolean(pedido.pedidoUuid);
  return (
    <div className="p-4 sm:p-5 bg-amber-50 border-2 border-amber-300 rounded-xl text-left space-y-3 animate-in fade-in duration-150">
      <div className="flex items-start gap-2.5">
        <PackageCheck className="w-5 h-5 text-amber-700 shrink-0 mt-0.5" />
        <div>
          <p className="text-sm font-extrabold text-amber-950">{nombreAlumno} ya tiene un pedido registrado</p>
          <p className="text-[11px] text-amber-800 mt-0.5">
            Pedido <strong>{pedido.id}</strong> · {pedido.kit} · ${(Number(pedido.total) || 0).toLocaleString('es-AR')} ·{' '}
            {pedido.estado === 'entregado' ? 'Entregado' : pedido.estado === 'pagado' ? 'Pagado' : comprobanteEnRevision ? 'Comprobante en revisión' : 'Pendiente de pago'}
          </p>
        </div>
      </div>
      {comprobanteEnRevision && (
        <div role="status" className="rounded-lg border border-sky-300 bg-sky-50 p-3 text-[11px] text-sky-950">
          <p className="flex items-center gap-1.5 font-bold text-sky-900">
            <Clock className="w-4 h-4 text-sky-600" /> Comprobante en revisión
          </p>
          <p className="mt-0.5">Recibimos el comprobante de tu transferencia: lo confirmamos en el día y te llega un email con las fotos. No hace falta pagar de nuevo.</p>
        </div>
      )}
      {pendiente && esTransferencia && pedido.pedidoUuid && (
        <SubirComprobante pedidoId={pedido.pedidoUuid} numeros={pedido.id} codigo={codigoSeccion} />
      )}
      {pedido.requiereLlave && (pedido.puedeMejorarAImpreso || pedido.puedeComprarFotosExtra || (pendiente && esTransferencia)) && (
        <p className="text-[11px] text-amber-900">
          Para subir el comprobante, pasar el kit a impreso o pedir fotos extra, volvé a ingresar con tu nombre y DNI (lo pedimos una sola vez).{' '}
          <button type="button" onClick={onReingresar} className="font-bold underline">Ingresar de nuevo</button>
        </p>
      )}
      {puedePagarAhora && (
        <button
          type="button"
          onClick={onPagarAhora}
          className="w-full px-4 py-2.5 bg-[#009EE3] hover:bg-[#0087c2] text-white font-bold text-xs rounded-xl shadow-xs cursor-pointer transition-colors flex items-center justify-center gap-1.5"
        >
          <CreditCard className="w-4 h-4" />
          <span>Pagar ahora o cambiar el medio de pago</span>
        </button>
      )}
      {pedido.mejoraAImpresoPagada && <p className="text-[11px] font-semibold text-emerald-800">✓ Ya lo pasaste a Kit Impreso: la carpeta se imprime con las mismas fotos.</p>}
      {pedido.puedeMejorarAImpreso && pedido.pedidoUuid && (
        <div className="rounded-lg border border-amber-300 bg-white p-3 space-y-2">
          <p className="text-[11px] text-slate-700">
            ¿Querés también la carpeta impresa? Pasá a <strong>Kit Impreso + Digital</strong> pagando sólo la diferencia
            {pedido.precioMejoraAImpreso ? <> (<strong>${pedido.precioMejoraAImpreso.toLocaleString('es-AR')}</strong>)</> : null}. Se imprimen las mismas 3 fotos que ya elegiste.
          </p>
          {/* 29/10/2026: con los mismos medios de pago que el kit (antes, sólo Mercado Pago). */}
          <PagoPedidoAdicional
            idUnico={`mejora-${pedido.pedidoUuid}`}
            textoBoton={`Pasar a Kit Impreso${pedido.precioMejoraAImpreso ? ` · $${pedido.precioMejoraAImpreso.toLocaleString('es-AR')}` : ''}`}
            preparar={(metodo) => prepararMejoraAImpreso(pedido.pedidoUuid!, codigoSeccion || '', { familia: datosCompra?.familia, acceso: datosCompra?.acceso, metodoPago: metodo })}
            codigoSeccion={codigoSeccion}
            colorBoton="bg-amber-400 hover:bg-amber-300 text-slate-950"
            datos={{ kitId: 'kit-clasico', kitNombre: 'Kit Impreso (mejora)', alumnoNombre: nombreAlumno, colegioNombre: datosCompra?.colegioNombre, tutorNombre: datosCompra?.tutorNombre, tutorEmail: datosCompra?.tutorEmail, tutorTelefono: datosCompra?.tutorTelefono }}
          />
        </div>
      )}
      {pedido.puedeComprarFotosExtra && pedido.pedidoUuid && codigoSeccion && (
        <ComprarFotosExtra
          kitPedidoUuid={pedido.pedidoUuid}
          codigoSeccion={codigoSeccion}
          nombreAlumno={nombreAlumno}
          precios={pedido.preciosFotosExtra}
          yaPedidas={pedido.fotosExtraPagadas}
          datos={datosCompra}
        />
      )}
      {comprobanteEnRevision && confirmandoOtro && (
        <p role="alert" className="rounded-lg border border-amber-400 bg-white p-2.5 text-[11px] text-amber-950">
          Ya transferiste este pedido: un pedido nuevo es <strong>otra compra aparte</strong> (no lo reemplaza) y se cobra de nuevo. ¿Seguro?
        </p>
      )}
      <div className="flex flex-col sm:flex-row gap-2 pt-1">
        <button
          type="button"
          onClick={onVerPedido}
          className="flex-1 px-4 py-2.5 bg-white hover:bg-amber-100 text-amber-900 border-2 border-amber-400 font-bold text-xs rounded-xl shadow-xs cursor-pointer transition-all flex items-center justify-center gap-1.5"
        >
          <Package className="w-4 h-4" />
          <span>Ver mi pedido</span>
        </button>
        <button
          type="button"
          onClick={() => (comprobanteEnRevision && !confirmandoOtro ? setConfirmandoOtro(true) : onOtroPedido())}
          className="flex-1 px-4 py-2.5 bg-slate-900 hover:bg-slate-800 text-amber-300 hover:text-white font-bold text-xs rounded-xl shadow-xs cursor-pointer transition-colors flex items-center justify-center gap-1.5"
        >
          <span>{comprobanteEnRevision ? (confirmandoOtro ? 'Sí, es otra compra aparte' : 'Quiero hacer otro pedido igual') : 'Sí, quiero hacer otro pedido'}</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}
