import { useMemo, useState } from 'react';
import { Check, ImagePlus, Loader2, Minus, Plus, X } from 'lucide-react';
import { obtenerGaleriaPublica } from '../services/fotosSubidasService';
import { prepararFotosExtra } from '../services/fotosExtraService';
import PagoPedidoAdicional, { type MetodoPago } from './PagoPedidoAdicional';
import { fotoVisibleParaAlumno } from '../utils/nombresAlumno';
import {
  contarCopias,
  MAX_COPIAS_POR_FOTO,
  MAX_ITEMS_FOTOS_EXTRA,
  precioCopiaExtra,
  PRECIOS_FOTOS_EXTRA_POR_DEFECTO,
  TAMANOS_FOTO_EXTRA,
  totalFotosExtra,
  type ItemFotoExtra,
  type PreciosFotosExtra,
  type TamanoFotoExtra,
} from '../utils/fotosExtra';

/**
 * «Comprar fotos extra» (29/10/2026, pedido de Pablo: «muchos padres quieren comprar fotos extra de sus hijos,
 * fuera del kit»). Aparece en la tarjeta del pedido ya pagado (TarjetaPedidoExistente): la familia elige cualquier
 * foto que ve en la galería, el tamaño (15x21 o 20x30) y las copias, y paga aparte con Mercado Pago. Es un pedido
 * propio que el laboratorio imprime en otro lote (no se mezcla con los kits). El total lo calcula el servidor.
 */
export interface DatosCompraFotosExtra {
  familia?: string | null;
  acceso?: string | null;
  tutorNombre?: string;
  tutorEmail?: string;
  tutorTelefono?: string;
  colegioNombre?: string;
}

interface FotoGaleria {
  id: string;
  thumbnail: string;
  categoria: string;
  alumnoNombre?: string;
}

interface Props {
  kitPedidoUuid: string;
  codigoSeccion: string;
  nombreAlumno: string;
  precios?: PreciosFotosExtra;
  yaPedidas?: number;
  datos?: DatosCompraFotosExtra;
}

const ORDEN_CATEGORIAS = ['individual', 'grupal', 'docente', 'familia', 'patio', 'varias'];
const ETIQUETA_CATEGORIA: Record<string, string> = {
  individual: 'Individual',
  grupal: 'Grupal',
  docente: 'Con la seño',
  familia: 'Familia/amigos',
  patio: 'Evento',
  varias: 'Varias',
};
const pesos = (n: number) => `$${n.toLocaleString('es-AR')}`;

export default function ComprarFotosExtra({ kitPedidoUuid, codigoSeccion, nombreAlumno, precios, yaPedidas = 0, datos }: Props) {
  const preciosVigentes = precios || PRECIOS_FOTOS_EXTRA_POR_DEFECTO;
  const [abierto, setAbierto] = useState(false);
  const [cargando, setCargando] = useState(false);
  const [fotos, setFotos] = useState<FotoGaleria[]>([]);
  const [items, setItems] = useState<ItemFotoExtra[]>([]);
  const [error, setError] = useState('');

  const abrir = async () => {
    setAbierto(true);
    setError('');
    if (fotos.length > 0) return;
    setCargando(true);
    const r = await obtenerGaleriaPublica({ codigo: codigoSeccion, familiaId: datos?.familia, acceso: datos?.acceso });
    setCargando(false);
    if (r.estado !== 'ok') {
      setError(r.error || 'No pudimos cargar las fotos. Probá de nuevo en unos segundos.');
      return;
    }
    const visibles = r.fotos
      .filter((f) => fotoVisibleParaAlumno({ categoria: f.categoria, alumnoNombre: f.alumnoNombre }, nombreAlumno))
      .map((f) => ({ id: f.id, thumbnail: f.thumbnail, categoria: String(f.categoria), alumnoNombre: f.alumnoNombre }));
    const orden = (c: string) => (ORDEN_CATEGORIAS.indexOf(c) + 1 || 99);
    setFotos(visibles.sort((a, b) => orden(a.categoria) - orden(b.categoria)));
  };

  const porId = useMemo(() => new Map(fotos.map((f) => [f.id, f])), [fotos]);
  const total = totalFotosExtra(items, preciosVigentes);
  const copias = contarCopias(items);

  const alternarFoto = (id: string) => {
    setError('');
    if (!items.some((it) => it.fotoId === id) && items.length >= MAX_ITEMS_FOTOS_EXTRA) {
      setError(`Se pueden pedir hasta ${MAX_ITEMS_FOTOS_EXTRA} fotos distintas por pedido. Pagá este y hacé otro para las demás.`);
      return;
    }
    setItems((actuales) => {
      if (actuales.some((it) => it.fotoId === id)) return actuales.filter((it) => it.fotoId !== id);
      if (actuales.length >= MAX_ITEMS_FOTOS_EXTRA) return actuales;
      return [...actuales, { fotoId: id, tamano: '15x21', cantidad: 1 }];
    });
  };
  const cambiar = (id: string, cambio: Partial<ItemFotoExtra>) =>
    setItems((actuales) => actuales.map((it) => (it.fotoId === id ? { ...it, ...cambio } : it)));
  const sumar = (id: string, delta: number) =>
    setItems((actuales) =>
      actuales.flatMap((it) => {
        if (it.fotoId !== id) return [it];
        const cantidad = it.cantidad + delta;
        if (cantidad < 1) return [];
        return [{ ...it, cantidad: Math.min(MAX_COPIAS_POR_FOTO, cantidad) }];
      })
    );

  // 29/10/2026: se paga con los mismos medios que el kit (PagoPedidoAdicional: Mercado Pago, Nave o transferencia).
  const preparar = (metodo: MetodoPago) => prepararFotosExtra(kitPedidoUuid, codigoSeccion, items, { familia: datos?.familia, acceso: datos?.acceso }, metodo);

  if (!abierto) {
    return (
      <div className="rounded-lg border border-sky-200 bg-white p-3 space-y-2">
        <p className="text-[11px] text-slate-700">
          ¿Querés más copias? Pedí <strong>fotos extra impresas</strong> de cualquier foto del curso: 15x21 a{' '}
          <strong>{pesos(preciosVigentes.extra15x21)}</strong> y 20x30 a <strong>{pesos(preciosVigentes.extra20x30)}</strong>. Se imprimen aparte y se
          entregan en el colegio.
        </p>
        {yaPedidas > 0 && <p className="text-[11px] font-semibold text-emerald-800">✓ Ya pediste fotos extra{yaPedidas > 1 ? ` (${yaPedidas} pedidos)` : ''}. Podés pedir más.</p>}
        <button
          type="button"
          onClick={() => void abrir()}
          className="w-full px-4 py-2.5 bg-sky-600 hover:bg-sky-500 text-white font-bold text-xs rounded-xl shadow-xs cursor-pointer transition-colors flex items-center justify-center gap-1.5"
        >
          <ImagePlus className="w-4 h-4" />
          <span>Elegir fotos extra</span>
        </button>
      </div>
    );
  }

  return (
    <section aria-label="Fotos extra" className="rounded-lg border border-sky-200 bg-white p-3 space-y-3">
      <div className="flex items-start justify-between gap-2">
        <div>
          <p className="text-sm font-extrabold text-slate-900">Fotos extra de {nombreAlumno}</p>
          <p className="text-[11px] text-slate-600">Tocá las fotos que querés, elegí el tamaño y cuántas copias.</p>
        </div>
        <button type="button" onClick={() => setAbierto(false)} aria-label="Cerrar fotos extra" className="p-1.5 rounded-lg text-slate-500 hover:bg-slate-100 cursor-pointer">
          <X className="w-4 h-4" />
        </button>
      </div>

      {cargando && (
        <p className="flex items-center gap-2 text-xs text-slate-600">
          <Loader2 className="w-4 h-4 animate-spin" /> Cargando las fotos del curso…
        </p>
      )}
      {!cargando && fotos.length === 0 && !error && <p className="text-xs text-slate-600">Todavía no hay fotos publicadas para este curso.</p>}

      {fotos.length > 0 && (
        <ul className="grid grid-cols-3 sm:grid-cols-4 gap-2 max-h-80 overflow-y-auto pr-1">
          {fotos.map((f) => {
            const elegida = items.some((it) => it.fotoId === f.id);
            return (
              <li key={f.id}>
                <button
                  type="button"
                  aria-pressed={elegida}
                  aria-label={`${ETIQUETA_CATEGORIA[f.categoria] || 'Foto'}${elegida ? ', elegida' : ''}`}
                  onClick={() => alternarFoto(f.id)}
                  className={`relative block w-full aspect-[3/4] overflow-hidden rounded-lg border-2 bg-slate-100 cursor-pointer transition-all ${elegida ? 'border-sky-500 ring-2 ring-sky-300' : 'border-transparent hover:border-slate-300'}`}
                >
                  <img src={f.thumbnail} alt="" loading="lazy" className="h-full w-full object-cover" />
                  <span className="absolute bottom-1 left-1 rounded bg-black/60 px-1.5 py-0.5 text-[9px] font-semibold text-white">{ETIQUETA_CATEGORIA[f.categoria] || 'Foto'}</span>
                  {elegida && (
                    <span className="absolute top-1 right-1 flex h-5 w-5 items-center justify-center rounded-full bg-sky-500 text-white">
                      <Check className="h-3.5 w-3.5" />
                    </span>
                  )}
                </button>
              </li>
            );
          })}
        </ul>
      )}

      {items.length > 0 && (
        <div className="space-y-2 border-t border-slate-200 pt-3">
          <p className="text-xs font-bold text-slate-900">Tu pedido de fotos extra</p>
          <ul className="space-y-2">
            {items.map((it) => {
              const foto = porId.get(it.fotoId);
              return (
                <li key={it.fotoId} className="flex flex-wrap items-center gap-2 rounded-lg bg-slate-50 p-2">
                  {foto && <img src={foto.thumbnail} alt="" className="h-12 w-9 rounded object-cover" />}
                  <div role="group" aria-label="Tamaño" className="flex rounded-lg border border-slate-300 bg-white p-0.5">
                    {TAMANOS_FOTO_EXTRA.map((t: TamanoFotoExtra) => (
                      <button
                        key={t}
                        type="button"
                        aria-pressed={it.tamano === t}
                        onClick={() => cambiar(it.fotoId, { tamano: t })}
                        className={`px-2 py-1 text-[11px] font-bold rounded-md cursor-pointer ${it.tamano === t ? 'bg-slate-900 text-white' : 'text-slate-700 hover:bg-slate-100'}`}
                      >
                        {t}
                      </button>
                    ))}
                  </div>
                  <div className="flex items-center gap-1">
                    <button type="button" onClick={() => sumar(it.fotoId, -1)} aria-label={it.cantidad === 1 ? 'Sacar esta foto' : 'Una copia menos'} className="flex h-7 w-7 items-center justify-center rounded-lg border border-slate-300 bg-white text-slate-700 hover:bg-slate-100 cursor-pointer">
                      <Minus className="h-3.5 w-3.5" />
                    </button>
                    <span className="w-6 text-center text-xs font-bold" aria-live="polite">{it.cantidad}</span>
                    <button type="button" onClick={() => sumar(it.fotoId, 1)} disabled={it.cantidad >= MAX_COPIAS_POR_FOTO} aria-label="Una copia más" className="flex h-7 w-7 items-center justify-center rounded-lg border border-slate-300 bg-white text-slate-700 hover:bg-slate-100 disabled:opacity-40 cursor-pointer">
                      <Plus className="h-3.5 w-3.5" />
                    </button>
                  </div>
                  <span className="ml-auto text-xs font-semibold text-slate-800">{pesos(it.cantidad * precioCopiaExtra(it.tamano, preciosVigentes))}</span>
                </li>
              );
            })}
          </ul>
          <p className="text-[11px] text-slate-600">
            Se imprimen aparte del kit y se entregan en el colegio, en un sobre aparte.
          </p>
        </div>
      )}

      {error && <p role="alert" className="text-[11px] font-semibold text-red-600">{error}</p>}

      {items.length > 0 && (
        <PagoPedidoAdicional
          idUnico={`fotos-extra-${kitPedidoUuid}`}
          textoBoton={`Pagar ${pesos(total)} · ${copias} ${copias === 1 ? 'copia' : 'copias'}`}
          preparar={preparar}
          codigoSeccion={codigoSeccion}
          colorBoton="bg-sky-600 hover:bg-sky-500 text-white"
          datos={{ kitId: 'fotos-extra', kitNombre: 'Fotos extra', alumnoNombre: nombreAlumno, colegioNombre: datos?.colegioNombre, tutorNombre: datos?.tutorNombre, tutorEmail: datos?.tutorEmail, tutorTelefono: datos?.tutorTelefono }}
        />
      )}
    </section>
  );
}
