import { useEffect, useRef, useState } from 'react';
import { CheckCircle2, Loader2, ScanFace, ShieldCheck, Upload, X } from 'lucide-react';
import type { Foto } from '../types';
import { buscadorRostroDisponible, buscarPorRostro, prepararImagenRostro, type AccesoBuscadorRostro } from '../services/buscadorRostroService';

/**
 * Buscador por reconocimiento facial (24/10/2026, Pablo): en la toma se mezclaron alumnos entre cursos. La familia
 * sube una foto del rostro de su hijo/a y el servidor busca sus individuales en todo el colegio; las que estaban en
 * otro curso se suman a la galería de esta familia (sólo ella las ve). La foto que sube no se guarda.
 * Va arriba de la grilla de «Individual» en el portal (PortalFamiliasModal). Servidor: servidor/familias/buscadorRostro.ts.
 */
export const TEXTO_PRIVACIDAD_ROSTRO =
  'La foto que subís se usa únicamente para encontrar las fotos de tu hijo/a en la galería de Retrato Escolar y no se guarda. ' +
  'Las imágenes no se usan para entrenar inteligencia artificial ni para ningún otro fin: el reconocimiento lo hace nuestro ' +
  'proveedor de infraestructura (Amazon Web Services) sólo para esta búsqueda, y toda la información se borra al finalizar el año escolar.';

interface Props {
  acceso: AccesoBuscadorRostro | null;
  /** Se llama cuando se sumaron fotos nuevas (el portal recarga la galería). */
  onEncontradas: () => void;
  /** 25/10: fotos de la galería (para mostrar en miniatura las que encontró el buscador) y abrirlas en grande. */
  fotosGaleria?: Foto[];
  onVerFoto?: (foto: Foto) => void;
}

/** Tope diario por familia: debe coincidir con BUSQUEDAS_POR_DIA de servidor/familias/buscadorRostro.ts. */
export const BUSQUEDAS_POR_DIA = 5;

const BOTON = 'inline-flex items-center justify-center gap-1.5 rounded-lg px-3 py-2 text-xs font-bold cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed';

export default function BuscadorRostro({ acceso, onEncontradas, fotosGaleria = [], onVerFoto }: Props) {
  const [encontradas, setEncontradas] = useState<string[]>([]);
  const [abierto, setAbierto] = useState(false);
  const [acepta, setAcepta] = useState(false);
  const [archivo, setArchivo] = useState<File | null>(null);
  const [buscando, setBuscando] = useState(false);
  const [mensaje, setMensaje] = useState<{ tipo: 'ok' | 'info' | 'error'; texto: string } | null>(null);
  const input = useRef<HTMLInputElement>(null);
  // Sólo en colegios que tienen el buscador (hoy, el Divino Pastor): si no, ni aparece.
  const [disponible, setDisponible] = useState(false);
  const codigo = acceso?.codigo || '';
  useEffect(() => {
    let vigente = true;
    setDisponible(false);
    if (codigo) void buscadorRostroDisponible(codigo).then((si) => vigente && setDisponible(si));
    return () => {
      vigente = false;
    };
  }, [codigo]);
  if (!acceso || !disponible) return null;

  const buscar = async () => {
    if (!archivo || !acepta || buscando) return;
    setBuscando(true);
    setMensaje(null);
    setEncontradas([]);
    try {
      const imagen = await prepararImagenRostro(archivo);
      const r = await buscarPorRostro(acceso, imagen);
      if (r.success) setEncontradas(r.fotos || []);
      if (!r.success) setMensaje({ tipo: 'error', texto: r.error || 'No pudimos hacer la búsqueda.' });
      else if ((r.nuevas || 0) > 0) {
        setMensaje({ tipo: 'ok', texto: `¡Listo! Encontramos ${r.nuevas} foto${r.nuevas === 1 ? '' : 's'} más de tu hijo/a y ya ${r.nuevas === 1 ? 'está' : 'están'} en esta galería, en «Individual».` });
        onEncontradas();
      } else if ((r.yaEnGaleria || 0) > 0) setMensaje({ tipo: 'info', texto: 'Las fotos de tu hijo/a que encontramos ya están en esta galería.' });
      else setMensaje({ tipo: 'info', texto: 'No encontramos otras fotos con esa cara. Probá con otra foto de frente y con buena luz. Si a tu hijo/a le faltó la foto porque no estuvo el día de la toma, avisanos con «Mi hijo/a no tiene esta foto» y la tomamos en los próximos días.' });
    } catch (err: any) {
      setMensaje({ tipo: 'error', texto: err?.message || 'No pudimos preparar la foto.' });
    } finally {
      setBuscando(false);
    }
  };

  if (!abierto) {
    return (
      <div className="rounded-xl border border-indigo-200 bg-indigo-50 p-3 flex flex-wrap items-center justify-between gap-2">
        <p className="text-xs text-indigo-900"><strong>¿No encontrás la foto de tu hijo/a?</strong> Buscala con nuestro reconocimiento facial de última generación. <span className="whitespace-nowrap">Tenés {BUSQUEDAS_POR_DIA} búsquedas por día.</span></p>
        <button type="button" onClick={() => setAbierto(true)} className={`${BOTON} bg-indigo-600 text-white hover:bg-indigo-700`}>
          <ScanFace className="w-4 h-4" aria-hidden="true" /> Buscar por rostro
        </button>
      </div>
    );
  }

  return (
    <div className="rounded-xl border border-indigo-200 bg-white p-4 space-y-3" role="region" aria-label="Buscador por reconocimiento facial">
      <div className="flex items-start justify-between gap-2">
        <h6 className="text-sm font-bold text-slate-800 flex items-center gap-1.5"><ScanFace className="w-4 h-4 text-indigo-600" aria-hidden="true" /> Buscar a tu hijo/a por su rostro</h6>
        <button type="button" onClick={() => setAbierto(false)} className="p-1 text-slate-400 hover:text-slate-700 cursor-pointer" aria-label="Cerrar el buscador"><X className="w-4 h-4" /></button>
      </div>
      <p className="text-xs text-slate-600">Subí una foto clara del rostro de tu hijo/a (de frente, con buena luz). En segundos buscamos sus fotos en todo el colegio y las sumamos a esta galería; sólo vos las vas a ver.</p>
      <p className="text-xs font-semibold text-indigo-900 bg-indigo-50 border border-indigo-200 rounded-lg px-2.5 py-1.5">Podés hacer hasta {BUSQUEDAS_POR_DIA} búsquedas por día: elegí bien la foto antes de buscar.</p>
      <p className="text-[11px] leading-relaxed text-slate-500 bg-slate-50 border border-slate-200 rounded-lg p-2.5 flex gap-2">
        <ShieldCheck className="w-4 h-4 shrink-0 text-emerald-600" aria-hidden="true" />
        <span><strong>Tu privacidad, primero.</strong> {TEXTO_PRIVACIDAD_ROSTRO}</span>
      </p>
      <input ref={input} type="file" accept="image/jpeg,image/png" className="hidden" onChange={(e) => { setArchivo(e.target.files?.[0] || null); setMensaje(null); e.target.value = ''; }} />
      <div className="flex flex-wrap items-center gap-2">
        <button type="button" onClick={() => input.current?.click()} className={`${BOTON} border border-slate-300 bg-white text-slate-700 hover:bg-slate-50`}>
          <Upload className="w-4 h-4" aria-hidden="true" /> {archivo ? 'Cambiar foto' : 'Elegir foto'}
        </button>
        {archivo && <span className="text-xs text-slate-600 truncate max-w-[14rem]">{archivo.name}</span>}
      </div>
      <label className="flex items-start gap-2 text-xs text-slate-700 cursor-pointer">
        <input type="checkbox" checked={acepta} onChange={(e) => setAcepta(e.target.checked)} className="mt-0.5" />
        <span>Soy madre, padre o tutor/a y autorizo usar esta foto sólo para buscar las fotos de mi hijo/a.</span>
      </label>
      <button type="button" onClick={buscar} disabled={!archivo || !acepta || buscando} className={`${BOTON} bg-indigo-600 text-white hover:bg-indigo-700`}>
        {buscando ? <Loader2 className="w-4 h-4 animate-spin" aria-hidden="true" /> : <ScanFace className="w-4 h-4" aria-hidden="true" />}
        {buscando ? 'Buscando…' : 'Buscar sus fotos'}
      </button>
      {mensaje && (
        <p role="status" className={`text-xs rounded-lg p-2.5 flex gap-2 ${mensaje.tipo === 'ok' ? 'bg-emerald-50 text-emerald-800 border border-emerald-200' : mensaje.tipo === 'error' ? 'bg-red-50 text-red-800 border border-red-200' : 'bg-amber-50 text-amber-900 border border-amber-200'}`}>
          {mensaje.tipo === 'ok' && <CheckCircle2 className="w-4 h-4 shrink-0" aria-hidden="true" />}
          {mensaje.texto}
        </p>
      )}
      {/* 25/10/2026: las fotos que encontró, en miniatura, para que la familia confirme que es su hijo/a (tocá para verla grande). */}
      {fotosGaleria.some((f) => encontradas.includes(f.id)) && (
        <div className="space-y-1.5">
          <p className="text-xs font-semibold text-slate-700">Estas son las fotos que encontramos. Tocá una para verla grande y fijate que sea tu hijo/a (si alguna no es, no la elijas):</p>
          <div className="flex flex-wrap gap-2">
            {fotosGaleria.filter((f) => encontradas.includes(f.id)).map((foto) => (
              <button key={foto.id} type="button" onClick={() => onVerFoto?.(foto)} className="w-20 h-24 sm:w-24 sm:h-28 rounded-lg overflow-hidden border-2 border-indigo-300 hover:border-indigo-600 cursor-pointer bg-slate-100" aria-label={`Ver en grande ${foto.titulo || 'la foto encontrada'}`}>
                <img src={foto.thumbnail || foto.url} alt="" loading="lazy" className="w-full h-full object-cover" />
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
