import { useCallback, useMemo, useState, type Dispatch, type SetStateAction } from 'react';
import { marcarFotografiadosAdmin, type AlumnoNominaReal } from '../services/colegiosService';

// Nómina del panel: la marca de «fotografiado» (13/10/2026, Pablo: «los alumnos que fotografiamos hoy, y
// tildamos, no están»). Antes vivía sólo en la memoria de la pestaña y se perdía al recargar. Ahora se guarda
// en el servidor (`alumnos.fotografiado_at`): se marca al instante en pantalla y, si el servidor no la pudo
// guardar, vuelve atrás y avisa. Fuera de AdminModal.tsx a propósito (ese archivo tiene techo de líneas).

const comparadorTexto = new Intl.Collator('es', { sensitivity: 'base', numeric: true });

/** Orden de la Nómina (14/10/2026, Pablo: «el listado está desordenado, no alfabéticamente por apellido y
 * nombre»): por curso (grado, turno, división) y, dentro del curso, por apellido y nombre («PEREZ, ANA»).
 * Antes salía por número de lista: los alumnos agregados o cambiados de curso quedaban al final.
 * 19/10/2026 (Pablo: «en "Sin fotografiar" me los coloca desordenados, no en orden alfabético»): con varios
 * cursos a la vista ("todas") se ordena alfabético puro por apellido y nombre; el curso sólo desempata.
 * Con un curso elegido el resultado es el mismo que antes. */
export function compararAlumnosNomina(a: AlumnoNominaReal, b: AlumnoNominaReal): number {
  return (
    comparadorTexto.compare((a.nombre || '').trim(), (b.nombre || '').trim()) ||
    comparadorTexto.compare(a.grado || '', b.grado || '') ||
    comparadorTexto.compare(a.turno || '', b.turno || '') ||
    comparadorTexto.compare(a.division || '', b.division || '')
  );
}

/** Filtro de la Nómina por estado de la foto (14/10/2026, Pablo: «voy a necesitar ver los alumnos que no pude
 * fotografiar»). Devuelve los visibles y cuántos hay de cada estado entre los de la sección y búsqueda elegidas.
 * 14/10 (noche): «Falta grupal» = sin la marca de la foto grupal (las grupales se pueden sacar otro día).
 * 21/10/2026 (Pablo: «¿cómo tildo si falta la foto individual y/o con la seño?»): la foto con la seño se marca
 * aparte. «pendientes» = falta la individual; «sin-seno» = falta con la seño; «alguna» = le falta cualquiera de
 * las tres; «fotografiados» = tiene las tres (completo). */
export type FiltroFoto = 'todos' | 'alguna' | 'pendientes' | 'sin-seno' | 'sin-grupal' | 'fotografiados';
const tieneLas3 = (a: AlumnoNominaReal) => !!a.fotografiado_at && !!a.foto_seno_at && !!a.foto_grupal_at;
const CRITERIO: Record<Exclude<FiltroFoto, 'todos'>, (a: AlumnoNominaReal) => boolean> = {
  alguna: (a) => !tieneLas3(a),
  pendientes: (a) => !a.fotografiado_at,
  'sin-seno': (a) => !a.foto_seno_at,
  'sin-grupal': (a) => !a.foto_grupal_at,
  fotografiados: tieneLas3,
};
export function filtrarPorFoto(lista: AlumnoNominaReal[], filtro: FiltroFoto) {
  const cuantos = (f: keyof typeof CRITERIO) => lista.filter(CRITERIO[f]).length;
  const visibles = filtro === 'todos' ? lista : lista.filter(CRITERIO[filtro]);
  return {
    visibles,
    total: lista.length,
    faltaAlguna: cuantos('alguna'),
    pendientes: cuantos('pendientes'),
    sinSeno: cuantos('sin-seno'),
    sinGrupal: cuantos('sin-grupal'),
    completos: cuantos('fotografiados'),
  };
}

/** Qué fotos le faltan a un alumno, para el Excel de la Nómina («Individual, Seño», «—» si tiene las tres). */
export function fotosQueLeFaltan(a: AlumnoNominaReal): string {
  const faltan = [!a.fotografiado_at && 'Individual', !a.foto_seno_at && 'Seño', !a.foto_grupal_at && 'Grupal'].filter(Boolean);
  return faltan.length ? faltan.join(', ') : '—';
}

type Foto = 'fotografiado' | 'seno' | 'grupal';
type CampoFoto = 'fotografiado_at' | 'foto_seno_at' | 'foto_grupal_at';
const CAMPO: Record<Foto, CampoFoto> = { fotografiado: 'fotografiado_at', seno: 'foto_seno_at', grupal: 'foto_grupal_at' };
const NOMBRE: Record<Foto, string> = { fotografiado: 'Individual', seno: 'Con la seño', grupal: 'Grupal' };
const TANDA = 500; // el servidor acepta hasta 1.000 alumnos por pedido
const CONFIRMAR_DESDE = 60; // marcar más que un curso de una vez pide confirmación

export function useFotografiadosNomina(
  alumnos: AlumnoNominaReal[],
  setAlumnos: Dispatch<SetStateAction<AlumnoNominaReal[]>>
) {
  const [errorFotografiados, setErrorFotografiados] = useState<string | null>(null);

  const marcadosDe = (campo: CampoFoto) => {
    const mapa: Record<string, boolean> = {};
    for (const a of alumnos) if (a[campo]) mapa[a.id] = true;
    return mapa;
  };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  const marcados = useMemo(() => marcadosDe('fotografiado_at'), [alumnos]);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  const conGrupal = useMemo(() => marcadosDe('foto_grupal_at'), [alumnos]);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  const conSeno = useMemo(() => marcadosDe('foto_seno_at'), [alumnos]);
  const mapaDe = (foto: Foto) => (foto === 'grupal' ? conGrupal : foto === 'seno' ? conSeno : marcados);

  const guardar = useCallback(
    async (ids: string[], valor: boolean, foto: Foto = 'fotografiado') => {
      if (ids.length === 0) return;
      const campo = CAMPO[foto];
      const elegidos = new Set(ids);
      const previos = new Map(alumnos.filter((a) => elegidos.has(a.id)).map((a) => [a.id, a[campo] ?? null]));
      const ahora = valor ? new Date().toISOString() : null;
      setErrorFotografiados(null);
      setAlumnos((prev) => prev.map((a) => (elegidos.has(a.id) ? { ...a, [campo]: ahora } : a)));
      // 15/10/2026 (Pablo: «aprieto "Grupal a filtrados" y se tilda y se destilda sola»): con la Nómina en «todas»
      // (1.314 alumnos) el servidor rechazaba la lista (máximo 1.000 por pedido) y la marca volvía atrás. Ahora
      // se manda en tandas de 500; si una tanda falla, sólo esa y las que faltaban vuelven atrás.
      const guardadosTodos: { id: string; fotografiado_at: string | null; foto_seno_at?: string | null; foto_grupal_at?: string | null }[] = [];
      for (let i = 0; i < ids.length; i += TANDA) {
        const r = await marcarFotografiadosAdmin(ids.slice(i, i + TANDA), valor, foto);
        if (!r.success) {
          const sinGuardar = new Set(ids.slice(i));
          setAlumnos((prev) => prev.map((a) => (sinGuardar.has(a.id) ? { ...a, [campo]: previos.get(a.id) ?? null } : a)));
          setErrorFotografiados(`${r.error || 'No se pudo guardar la marca.'} ${i > 0 ? `Se guardaron ${i} de ${ids.length}; los demás ` : ''}No quedó guardado: volvé a tildarlo.`);
          break;
        }
        guardadosTodos.push(...(r.alumnos || []));
      }
      const guardados = new Map(guardadosTodos.map((a) => [a.id, a]));
      setAlumnos((prev) =>
        prev.map((a) => {
          const g = guardados.get(a.id);
          return g ? { ...a, fotografiado_at: g.fotografiado_at ?? null, foto_seno_at: g.foto_seno_at ?? null, foto_grupal_at: g.foto_grupal_at ?? null } : a;
        })
      );
    },
    [alumnos, setAlumnos]
  );

  const alternarUno = (foto: Foto, id: string, nombreAlumno: string) => {
    const mapa = mapaDe(foto);
    if (mapa[id] && !window.confirm(`¿Querés quitar la marca de "${NOMBRE[foto]}" a ${nombreAlumno}?`)) return;
    void guardar([id], !mapa[id], foto);
  };

  /** «Chequear filtrados»: si ya están todos tildados los destilda (con confirmación); si no, tilda a todos. */
  const alternarLista = (foto: Foto, lista: AlumnoNominaReal[]) => {
    if (lista.length === 0) return;
    const mapa = mapaDe(foto);
    const todos = lista.every((a) => mapa[a.id]);
    if (todos && !window.confirm(`¿Querés quitar la marca de "${NOMBRE[foto]}" a los ${lista.length} alumnos filtrados?`)) return;
    const aMarcar = lista.filter((a) => !mapa[a.id]).length;
    if (!todos && aMarcar > CONFIRMAR_DESDE && !window.confirm(`Vas a marcar "${NOMBRE[foto]}" a ${aMarcar} alumnos (todos los de la lista). ¿Seguro? Para un solo curso, elegilo primero en el desplegable.`)) return;
    void guardar(
      lista.filter((a) => !!mapa[a.id] === todos).map((a) => a.id),
      !todos,
      foto
    );
  };

  return {
    marcados,
    conSeno,
    conGrupal,
    /** Tilda o destilda a un alumno (destildar pide confirmación). */
    alternarFotografiado: (id: string, nombre: string) => alternarUno('fotografiado', id, nombre),
    alternarSeno: (id: string, nombre: string) => alternarUno('seno', id, nombre),
    alternarGrupal: (id: string, nombre: string) => alternarUno('grupal', id, nombre),
    alternarVarios: (lista: AlumnoNominaReal[]) => alternarLista('fotografiado', lista),
    alternarSenoVarios: (lista: AlumnoNominaReal[]) => alternarLista('seno', lista),
    alternarGrupalVarios: (lista: AlumnoNominaReal[]) => alternarLista('grupal', lista),
    errorFotografiados,
  };
}
