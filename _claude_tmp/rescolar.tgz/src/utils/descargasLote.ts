/**
 * Auditoría 03/10 (críticos 3 y 5, altos 16 y 18): utilidades puras para trabajar con volumen
 * desde el navegador sin reventar la memoria ni el servidor — tandas, concurrencia limitada,
 * reintentos y división de un ZIP grande en partes. Sin dependencias de React ni de la red.
 */

/** Parte un arreglo en tandas de `tamano` elementos (la última puede ser más chica). */
export function enTandas<T>(items: readonly T[], tamano: number): T[][] {
  const n = Math.max(1, Math.floor(tamano) || 1);
  const tandas: T[][] = [];
  for (let i = 0; i < items.length; i += n) tandas.push(items.slice(i, i + n));
  return tandas;
}

/** Error que no vale la pena reintentar (401/403/404, foto inexistente…). */
export class ErrorSinReintento extends Error {
  readonly sinReintento = true;
}

export function esperar(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

/**
 * Ejecuta `fn` y, si falla, la reintenta hasta `intentos` veces en total con espera creciente.
 * No reintenta los `ErrorSinReintento` ni los que `esFatal` marque (esos se relanzan tal cual).
 */
export async function conReintentos<T>(
  fn: (intento: number) => Promise<T>,
  opciones: { intentos?: number; esperaBaseMs?: number; esFatal?: (e: unknown) => boolean } = {}
): Promise<T> {
  const intentos = Math.max(1, opciones.intentos ?? 3);
  const base = opciones.esperaBaseMs ?? 600;
  let ultimo: unknown;
  for (let i = 1; i <= intentos; i++) {
    try {
      return await fn(i);
    } catch (e) {
      ultimo = e;
      if (opciones.esFatal?.(e) || (e as { sinReintento?: boolean })?.sinReintento) throw e;
      if (i < intentos && base > 0) await esperar(base * 2 ** (i - 1));
    }
  }
  throw ultimo;
}

/**
 * Corre `fn` sobre cada elemento con, como mucho, `limite` tareas a la vez. Devuelve los
 * resultados en el mismo orden. Si una tarea tira un error, se corta todo (como Promise.all):
 * quien quiera seguir ante fallas tiene que atraparlas dentro de `fn`.
 * `debeParar` se consulta antes de arrancar cada elemento: los que no arrancaron quedan
 * `undefined` en el resultado (sirve para cortar una parte del ZIP que ya pesa demasiado).
 */
export async function ejecutarConConcurrencia<T, R>(
  items: readonly T[],
  limite: number,
  fn: (item: T, indice: number) => Promise<R>,
  opciones: { debeParar?: () => boolean; alTerminarUno?: (hechos: number, total: number) => void } = {}
): Promise<(R | undefined)[]> {
  const resultados: (R | undefined)[] = new Array(items.length).fill(undefined);
  let siguiente = 0;
  let hechos = 0;
  let fallo: unknown = null;
  const trabajador = async () => {
    while (fallo === null) {
      if (opciones.debeParar?.()) return;
      const indice = siguiente++;
      if (indice >= items.length) return;
      try {
        resultados[indice] = await fn(items[indice], indice);
      } catch (e) {
        fallo = e;
        return;
      }
      hechos++;
      opciones.alTerminarUno?.(hechos, items.length);
    }
  };
  const n = Math.max(1, Math.min(Math.floor(limite) || 1, items.length || 1));
  await Promise.all(Array.from({ length: n }, trabajador));
  if (fallo !== null) throw fallo;
  return resultados;
}

/** Divide en partes de `maxPorParte` elementos (para ZIPs que no entran en memoria de una vez). */
export function dividirEnPartes<T>(items: readonly T[], maxPorParte: number): T[][] {
  return items.length === 0 ? [] : enTandas(items, maxPorParte);
}

/**
 * Llama a `paso(pendientes)` mientras el servidor devuelva `restantes` (lo que no alcanzó a
 * procesar por tiempo), con un tope de vueltas. Suma lo que devuelve cada vuelta con `sumar`.
 * `restantes` puede ser una lista (ids) o un número (cantidad que falta).
 */
export async function repetirMientrasHayaRestantes<P, R extends { restantes?: P }>(
  inicial: P,
  paso: (pendientes: P, vuelta: number) => Promise<R>,
  opciones: { maxVueltas?: number; hayMas: (restantes: P | undefined) => boolean; alAvanzar?: (r: R, vuelta: number) => void }
): Promise<{ ultimas: R[]; restantes: P | undefined; cortadoPorTope: boolean }> {
  const max = Math.max(1, opciones.maxVueltas ?? 30);
  const respuestas: R[] = [];
  let pendientes: P = inicial;
  for (let vuelta = 1; vuelta <= max; vuelta++) {
    const r = await paso(pendientes, vuelta);
    respuestas.push(r);
    opciones.alAvanzar?.(r, vuelta);
    if (!opciones.hayMas(r.restantes)) return { ultimas: respuestas, restantes: r.restantes, cortadoPorTope: false };
    pendientes = r.restantes as P;
  }
  const ultima = respuestas[respuestas.length - 1];
  return { ultimas: respuestas, restantes: ultima?.restantes, cortadoPorTope: true };
}

/**
 * Nombre de archivo del laboratorio sin choques entre pedidos (auditoría 03/10, medio: "los
 * nombres chocan entre colegios"). Si el mismo nombre aparece en dos pedidos distintos, a cada
 * uno se le agrega el número de pedido corto (ej. 3ATT_JUAN_PEREZ_P4266.jpg). Los nombres únicos
 * no cambian, así el Excel y el ZIP siguen coincidiendo con lo de siempre.
 */
export function sufijoPedidoCorto(pedidoId: string): string {
  const limpio = String(pedidoId || '').trim();
  const ultimo = limpio.split('-').pop() || limpio;
  return (ultimo.replace(/[^A-Za-z0-9]/g, '') || limpio.replace(/[^A-Za-z0-9]/g, '')).slice(-8).toUpperCase();
}

export function desambiguarNombresArchivos<P extends { id: string; archivosParaLaboratorio: { nombreArchivoLab: string }[] }>(pedidos: P[]): P[] {
  const duenos = new Map<string, Set<string>>();
  for (const p of pedidos) {
    for (const a of p.archivosParaLaboratorio || []) {
      const clave = (a.nombreArchivoLab || '').toUpperCase();
      if (!clave) continue;
      if (!duenos.has(clave)) duenos.set(clave, new Set());
      duenos.get(clave)!.add(p.id);
    }
  }
  return pedidos.map((p) => {
    const choca = (p.archivosParaLaboratorio || []).some((a) => (duenos.get((a.nombreArchivoLab || '').toUpperCase())?.size || 0) > 1);
    if (!choca) return p;
    const sufijo = sufijoPedidoCorto(p.id);
    return {
      ...p,
      archivosParaLaboratorio: p.archivosParaLaboratorio.map((a) => {
        if ((duenos.get((a.nombreArchivoLab || '').toUpperCase())?.size || 0) <= 1) return a;
        const m = a.nombreArchivoLab.match(/^(.*?)(\.[^.]+)?$/);
        return { ...a, nombreArchivoLab: `${m?.[1] || a.nombreArchivoLab}_P${sufijo}${m?.[2] || ''}` };
      }),
    };
  });
}
