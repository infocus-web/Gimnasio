import { useCallback, useRef } from 'react';

/**
 * 14/10/2026 (auditoría): clave de envío para las respuestas del panel a las familias. Un reintento del
 * MISMO texto (corte de red, doble clic) lleva la misma clave y el servidor no lo vuelve a mandar; si Pablo
 * cambia el texto, sale con una clave nueva. Después de un envío exitoso hay que llamar a `reiniciar()`.
 */
export function nuevaClaveEnvio(): string {
  try {
    if (typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function') return crypto.randomUUID();
  } catch {
    // sin crypto.randomUUID (navegador viejo o http): se arma una igual de única
  }
  return `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 12)}-${Math.random().toString(36).slice(2, 12)}`;
}

export function useClaveEnvio() {
  const actual = useRef<{ contenido: string; clave: string } | null>(null);
  const claveParaEnviar = useCallback((contenido: string) => {
    if (!actual.current || actual.current.contenido !== contenido) actual.current = { contenido, clave: nuevaClaveEnvio() };
    return actual.current.clave;
  }, []);
  const reiniciar = useCallback(() => { actual.current = null; }, []);
  return { claveParaEnviar, reiniciar };
}
