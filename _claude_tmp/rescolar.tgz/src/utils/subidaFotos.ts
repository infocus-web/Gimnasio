import { useEffect } from 'react';
import { iniciarProceso } from './procesoEnCurso';

// Subida de fotos del panel (14/10/2026, Pablo: «nada de los datos que deban guardarse en Supabase
// puede vivir en el navegador»). Fuera de AdminLoteFotosTab.tsx a propósito (ese archivo tiene techo
// de líneas).

/** Clave de un archivo original: nombre + tamaño exacto. Las cámaras repiten nombres (IMG_1234.JPG),
 * así que el nombre solo no alcanza: nunca se tiene que saltear una foto distinta. */
export function claveArchivoOriginal(nombre: string | null | undefined, bytes: number | null | undefined): string | null {
  if (!nombre || !bytes || !Number.isFinite(bytes) || bytes <= 0) return null;
  return `${nombre.trim().toLowerCase()}|${bytes}`;
}

/** Separa los archivos elegidos en los que hay que subir y los que ya están (en el curso o en la cola). */
export function separarYaSubidas<T extends { name: string; size: number }>(
  archivos: T[],
  yaEstan: { nombreOriginal?: string | null; bytesOriginal?: number | null }[]
): { nuevos: T[]; repetidos: number } {
  const claves = new Set(yaEstan.map((f) => claveArchivoOriginal(f.nombreOriginal, f.bytesOriginal)).filter(Boolean));
  const nuevos: T[] = [];
  let repetidos = 0;
  for (const a of archivos) {
    const clave = claveArchivoOriginal(a.name, a.size);
    if (clave && claves.has(clave)) {
      repetidos++;
      continue;
    }
    if (clave) claves.add(clave); // el mismo archivo elegido dos veces en la misma tanda
    nuevos.push(a);
  }
  return { nuevos, repetidos };
}

/** Mientras haya fotos en la cola o subiendo, el navegador pregunta antes de cerrar o recargar la pestaña. */
export function useAvisoAlCerrar(activo: boolean) {
  // 14/10/2026: usa el registro de procesos en curso (pregunta antes de cerrar y frena la recarga por versión nueva).
  useEffect(() => (activo ? iniciarProceso('Subida de fotos') : undefined), [activo]);
}
