import { useEffect } from 'react';

/**
 * 14/10/2026 (Pablo: «los alumnos de secundaria sólo se sacan la foto grupal; si un padre compra el digital
 * se la reparten entre todos»): en secundaria NO se vende el Kit Solo Digital, sólo el Kit Impreso (que
 * sigue trayendo la descarga HD). Los pedidos ya pagados no se tocan. El servidor lo vuelve a controlar:
 * debe coincidir con `kitPermitidoParaGrado` de servidor/pagos/totales.ts.
 */
export function esGradoDeSecundaria(grado: string | null | undefined): boolean {
  const g = String(grado || '').toLowerCase();
  return !g.includes('sala') && /\d+\s*°?\s*a[ñn]o(?!s)/.test(g);
}

export function hayCursoDeSecundaria(grados: (string | null | undefined)[]): boolean {
  return grados.some(esGradoDeSecundaria);
}

// 29/10/2026 (Pablo): se vuelve a habilitar el Solo Digital en secundaria (ahora secundaria también tiene
// individual y foto con amigos). Las funciones quedan para no tocar a quienes las usan.
export const SOLO_DIGITAL_EN_SECUNDARIA = true;

export function kitPermitidoParaGrado(kitId: string, grado: string | null | undefined): boolean {
  if (SOLO_DIGITAL_EN_SECUNDARIA) return true;
  return !(kitId === 'kit-digital' && esGradoDeSecundaria(grado));
}

/** Kits que se muestran para esta compra: sin el Solo Digital si alguno de los chicos es de secundaria. */
export function kitsParaGrados<K extends { id: string }>(kits: K[], grados: (string | null | undefined)[]): K[] {
  if (SOLO_DIGITAL_EN_SECUNDARIA) return kits;
  return hayCursoDeSecundaria(grados) ? kits.filter((k) => k.id !== 'kit-digital') : kits;
}

/** Si quedó elegido el Solo Digital (preseleccionado desde la home) y la compra es de secundaria, pasa al Impreso. */
export function useSinSoloDigitalEnSecundaria<K extends { id: string }>(
  esSecundaria: boolean,
  kitElegido: K,
  kits: K[],
  elegir: (kit: K) => void
) {
  useEffect(() => {
    if (SOLO_DIGITAL_EN_SECUNDARIA || !esSecundaria || kitElegido.id !== 'kit-digital') return;
    const impreso = kits.find((k) => k.id === 'kit-clasico');
    if (impreso) elegir(impreso);
  }, [esSecundaria, kitElegido.id, kits, elegir]);
}
