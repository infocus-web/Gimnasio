/**
 * 14/10/2026: borrador del formulario de inscripción (ModalInscripcionFamilia). Si la familia recargaba
 * la página a mitad del formulario (o el celular la descartaba al ir a buscar un dato), perdía todo lo
 * que había escrito. Se guarda en sessionStorage (sólo esta pestaña; se borra al cerrarla) y se borra al
 * inscribirse bien.
 *
 * NUNCA se guarda ningún DNI (ni del tutor, ni del alumno, ni de los hermanos): `guardarBorradorInscripcion`
 * descarta esas claves aunque vengan en los datos, y `leerBorradorInscripcion` también las ignora.
 */
import { useEffect } from 'react';

const CLAVE = 'retrato_borrador_inscripcion';
const CAMPOS_DNI = new Set(['padreDni', 'alumnoDni', 'dni', 'tutorDni']);

export interface HermanoBorrador {
  id: string;
  alumnoNombre: string;
  alumnoApellido: string;
  turno: string;
  grado: string;
  division: string;
}

export interface BorradorInscripcion {
  colegioId?: string;
  padreNombre?: string;
  telefonoWhatsApp?: string;
  email?: string;
  alumnoNombre?: string;
  alumnoApellido?: string;
  turno?: string;
  grado?: string;
  division?: string;
  hermanos?: HermanoBorrador[];
  solicitaFotoHermanos?: boolean;
}

const texto = (v: unknown) => (typeof v === 'string' ? v.slice(0, 300) : undefined);

/** Copia sólo los campos conocidos y sin DNI. */
function limpiar(datos: Record<string, any>): BorradorInscripcion {
  const salida: Record<string, any> = {};
  for (const campo of ['colegioId', 'padreNombre', 'telefonoWhatsApp', 'email', 'alumnoNombre', 'alumnoApellido', 'turno', 'grado', 'division']) {
    if (!CAMPOS_DNI.has(campo) && texto(datos?.[campo]) !== undefined) salida[campo] = texto(datos[campo]);
  }
  if (Array.isArray(datos?.hermanos)) {
    salida.hermanos = datos.hermanos.slice(0, 10).map((h: any) => ({
      id: texto(h?.id) || '',
      alumnoNombre: texto(h?.alumnoNombre) || '',
      alumnoApellido: texto(h?.alumnoApellido) || '',
      turno: texto(h?.turno) || '',
      grado: texto(h?.grado) || '',
      division: texto(h?.division) || '',
    }));
  }
  if (typeof datos?.solicitaFotoHermanos === 'boolean') salida.solicitaFotoHermanos = datos.solicitaFotoHermanos;
  return salida;
}

/** Hay algo escrito que valga la pena guardar (no se guarda un formulario vacío). */
function tieneContenido(b: BorradorInscripcion): boolean {
  return Boolean(b.padreNombre || b.telefonoWhatsApp || b.email || b.alumnoNombre || b.alumnoApellido || (b.hermanos && b.hermanos.length > 0));
}

export function guardarBorradorInscripcion(datos: Record<string, any>): void {
  try {
    const borrador = limpiar(datos);
    if (tieneContenido(borrador)) window.sessionStorage.setItem(CLAVE, JSON.stringify(borrador));
  } catch {
    /* sin almacenamiento (modo privado, bloqueado): el formulario funciona igual */
  }
}

export function leerBorradorInscripcion(): BorradorInscripcion | null {
  try {
    const crudo = window.sessionStorage.getItem(CLAVE);
    if (!crudo) return null;
    const borrador = limpiar(JSON.parse(crudo));
    return tieneContenido(borrador) ? borrador : null;
  } catch {
    return null;
  }
}

export function borrarBorradorInscripcion(): void {
  try {
    window.sessionStorage.removeItem(CLAVE);
  } catch {
    /* nada que borrar */
  }
}

/**
 * Lo que el modal tiene que hacer con un borrador al abrirse: completa los campos escritos (nunca los
 * DNI). Los hermanos conservan el DNI que ya tuviera en pantalla el mismo hermano (por id), si lo hay.
 */
export function aplicarBorradorInscripcion(
  borrador: BorradorInscripcion | null,
  set: {
    colegioId: (v: string) => void;
    padreNombre: (v: string) => void;
    telefonoWhatsApp: (v: string) => void;
    email: (v: string) => void;
    alumnoNombre: (v: string) => void;
    alumnoApellido: (v: string) => void;
    turno: (v: string) => void;
    grado: (v: string) => void;
    division: (v: string) => void;
    hermanos: (f: (previos: Array<HermanoBorrador & { alumnoDni: string }>) => Array<HermanoBorrador & { alumnoDni: string }>) => void;
    solicitaFotoHermanos: (v: boolean) => void;
  }
): void {
  if (!borrador) return;
  for (const campo of ['colegioId', 'padreNombre', 'telefonoWhatsApp', 'email', 'alumnoNombre', 'alumnoApellido', 'turno', 'grado', 'division'] as const) {
    const valor = borrador[campo];
    if (valor) set[campo](valor);
  }
  const hermanos = borrador.hermanos;
  if (hermanos) set.hermanos((previos) => hermanos.map((h) => ({ ...h, alumnoDni: previos.find((p) => p.id === h.id)?.alumnoDni || '' })));
  if (typeof borrador.solicitaFotoHermanos === 'boolean') set.solicitaFotoHermanos(borrador.solicitaFotoHermanos);
}

/** Guarda el borrador (sin DNI) mientras el formulario de alta está en pantalla (`activo`). */
export function useGuardarBorradorInscripcion(activo: boolean, datos: Record<string, any>): void {
  const serializado = JSON.stringify(limpiar(datos));
  useEffect(() => {
    if (activo) guardarBorradorInscripcion(JSON.parse(serializado));
  }, [activo, serializado]);
}
