/**
 * Plazo para subir el comprobante de una transferencia (pedido de Pablo 29/9): si la familia elige
 * transferencia y no sube el comprobante dentro de este plazo, el pedido se cancela solo (lo hace
 * /api/cron/recordar-pagos-pendientes en server.ts, que corre cada hora). Tiene que coincidir con
 * PLAZO_TRANSFERENCIA_HORAS de server.ts.
 */
export const PLAZO_TRANSFERENCIA_HORAS = 48;

/** "miércoles 1/10 a las 15:30" (hora de Argentina). */
export function formatearVencimiento(fechaIso: string | null | undefined): string | null {
  if (!fechaIso) return null;
  const fecha = new Date(fechaIso);
  if (Number.isNaN(fecha.getTime())) return null;
  const partes = new Intl.DateTimeFormat('es-AR', {
    timeZone: 'America/Argentina/Buenos_Aires',
    weekday: 'long',
    day: 'numeric',
    month: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    hourCycle: 'h23',
  }).formatToParts(fecha);
  const p = (tipo: string) => partes.find((x) => x.type === tipo)?.value || '';
  return `${p('weekday')} ${p('day')}/${p('month')} a las ${p('hour')}:${p('minute')}`;
}

/** Último aviso antes de vencer (a la familia y a Pablo): coincide con AVISO_PREVIO_VENCIMIENTO_HORAS del servidor. */
export const AVISO_PREVIO_VENCIMIENTO_HORAS = 12;

/** Vencimiento del plazo para subir el comprobante (ISO), a partir de `transferencia_desde`. */
export function venceTransferencia(desdeIso: string | null | undefined): string | null {
  if (!desdeIso) return null;
  const desde = new Date(desdeIso).getTime();
  if (!Number.isFinite(desde)) return null;
  return new Date(desde + PLAZO_TRANSFERENCIA_HORAS * 60 * 60 * 1000).toISOString();
}

/**
 * 10/10 (pedido de Pablo): pedido cancelado SOLO porque venció el plazo sin comprobante, que se puede
 * recuperar desde el panel (Pedidos → «Vencidos sin comprobante»): aprobarlo si la plata entró, o
 * reabrirle el plazo. No incluye los cancelados definitivos (arrepentimiento, reembolso, a mano).
 */
export function pedidoVencidoRecuperable(p: {
  estadoPago: string;
  metodoPago?: string;
  transferenciaVencidaAt?: string | null;
  canceladoDefinitivo?: boolean;
  archivado?: boolean;
}): boolean {
  return p.estadoPago === 'rechazado' && Boolean(p.transferenciaVencidaAt) && !p.canceladoDefinitivo && !p.archivado;
}
