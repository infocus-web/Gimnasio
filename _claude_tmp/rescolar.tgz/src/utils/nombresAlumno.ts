/**
 * Auditoría 2026-09-26 (M6): una foto INDIVIDUAL etiquetada con el nombre de un alumno sólo se le
 * muestra (y se le vende) a la familia de ese alumno. Las fotos sin etiqueta se siguen mostrando a
 * todo el curso, como antes. La comparación es tolerante al orden y a que falte un segundo nombre:
 * "Juan Pérez" coincide con "PEREZ, Juan Martín". Debe coincidir con servidor/nucleo/nombres.ts.
 */
function palabras(nombre: unknown): string[] {
  return String(nombre || '')
    .normalize('NFD')
    .replace(/[̀-ͯ]/g, '')
    .toLowerCase()
    .replace(/[.,]/g, ' ')
    .split(/\s+/)
    .filter(Boolean);
}

/** 05/10 (bug 1): nombre normalizado (sin tildes, minúsculas, palabras ordenadas) para detectar el mismo alumno dos veces. */
export function normalizarNombreAlumno(nombre: unknown): string {
  return palabras(nombre).sort().join(' ');
}

// Auditoría 11/10 (INS-7): igual que el servidor (servidor/nucleo/nombres.ts): palabras sin repetir y el
// nombre más corto con 2 palabras como mínimo.
export function nombresCompatibles(a: unknown, b: unknown): boolean {
  const pa = Array.from(new Set(palabras(a)));
  const pb = Array.from(new Set(palabras(b)));
  if (pa.length === 0 || pb.length === 0) return false;
  const [corto, largo] = pa.length <= pb.length ? [pa, new Set(pb)] : [pb, new Set(pa)];
  if (corto.length < 2) return false;
  return corto.every((p) => largo.has(p));
}

// Revisión 11/10: etiqueta ⊇ nombre (la nómina suele tener segundo nombre) o, como mucho UNA palabra de más
// en lo que escribió la familia (segundo nombre/apellido que la nómina no tiene); sin contar partículas.
function puntajeEtiqueta(delNombre: string[], deLaEtiqueta: string[]): number | null {
  const et = new Set(deLaEtiqueta);
  if (delNombre.every((p) => et.has(p))) return et.size - delNombre.length;
  const nom = new Set(delNombre);
  if (et.size >= 2 && deLaEtiqueta.every((p) => nom.has(p)) && nom.size - et.size === 1) return 1;
  return null;
}

/** Copia exacta de etiquetasDelAlumno del servidor (auditoría 11/10, FAM-1): etiqueta ⊇ nombre; empate ambiguo = ninguna. */
export function etiquetasDelAlumno(nombre: unknown, etiquetas: unknown[]): Set<string> {
  const palabrasSin = (n: unknown) => Array.from(new Set(palabras(n).filter((p) => !PARTICULAS_NOMBRE.has(p))));
  const delNombre = palabrasSin(nombre);
  let mejor = Infinity;
  const elegidas = new Set<string>();
  if (delNombre.length < 2) return elegidas;
  const vistas = new Set<string>();
  for (const etiqueta of etiquetas) {
    const clave = normalizarNombreAlumno(etiqueta);
    if (!clave || vistas.has(clave)) continue;
    vistas.add(clave);
    const puntaje = puntajeEtiqueta(delNombre, palabrasSin(etiqueta));
    if (puntaje === null) continue;
    if (puntaje < mejor) {
      mejor = puntaje;
      elegidas.clear();
    }
    if (puntaje === mejor) elegidas.add(clave);
  }
  return mejor > 0 && elegidas.size > 1 ? new Set<string>() : elegidas;
}

/** ¿Esta foto se le puede mostrar a la familia de `alumnoNombre`? (mismo criterio que la galería del servidor) */
export function fotoVisibleParaAlumno(foto: { categoria: string; alumnoNombre?: string }, alumnoNombre: string): boolean {
  if (foto.categoria !== 'individual' || !foto.alumnoNombre) return true;
  if (!alumnoNombre.trim()) return true;
  return etiquetasDelAlumno(alumnoNombre, [foto.alumnoNombre]).size > 0;
}

// 10/10/2026 (pedido de Pablo, probando la inscripción: escribió «PABLITA Alderete»): los nombres que
// escribe la familia se guardan con mayúscula inicial. Sólo se corrigen las palabras escritas TODAS en
// mayúsculas o TODAS en minúsculas; una palabra con mezcla (McDonald, DeLuca) se respeta. Las partículas
// (de, del, la, los, y…) que no van primero quedan en minúscula: «MARÍA DE LOS ÁNGELES» → «María de los
// Ángeles». También después de guion o apóstrofo: «maría-josé d'angelo» → «María-José D'Angelo».
// Debe coincidir con nombrePropio de src/utils/nombresAlumno.ts / servidor/nucleo/nombres.ts.
const PARTICULAS_NOMBRE = new Set(['de', 'del', 'la', 'las', 'los', 'y', 'e', 'da', 'das', 'do', 'dos', 'di', 'van', 'von', 'der']);

export function nombrePropio(texto: string): string {
  return String(texto ?? '')
    .replace(/\s+/g, ' ')
    .trim()
    .split(' ')
    .map((palabra, i) => {
      const letras = palabra.replace(/[^\p{L}]/gu, '');
      if (!letras) return palabra;
      const todoMayusculas = letras === letras.toLocaleUpperCase('es');
      const todoMinusculas = letras === letras.toLocaleLowerCase('es');
      if (!todoMayusculas && !todoMinusculas) return palabra;
      const minusculas = palabra.toLocaleLowerCase('es');
      if (i > 0 && PARTICULAS_NOMBRE.has(minusculas)) return minusculas;
      return minusculas.replace(/(^|[-'’])(\p{L})/gu, (_m: string, separador: string, letra: string) => separador + letra.toLocaleUpperCase('es'));
    })
    .join(' ');
}
