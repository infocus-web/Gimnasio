/**
 * Auditoría 03/10 (crítico 2): "reintentar crear pedido duplica pedidos". El UUID del pedido se
 * generaba de nuevo en cada intento, así que si el primer POST /api/pedidos/crear llegaba al
 * servidor pero la respuesta se perdía (señal mala, timeout), el segundo intento creaba OTRO
 * pedido — con riesgo de doble cobro y de recordatorios por el duplicado.
 *
 * Ahora el portal pide los ids acá: se generan UNA vez por checkout y se reusan en cada reintento
 * mientras la selección (hijo, fotos, kit, extras, hermanos del carrito) sea la misma. El servidor
 * es idempotente por ese id. Sólo si la familia cambia lo que compra se generan ids nuevos.
 */
export interface IdsCheckout {
  firma: string;
  /** UUID del pedido (camino de un solo hijo). */
  pedidoId: string;
  pedidoFriendlyId: string;
  /** Un UUID y un número por hijo del carrito multi-hijo, en el mismo orden que los ítems. */
  itemIds: string[];
  itemFriendlyIds: string[];
  /** Número de lista sorteado una sola vez (se manda igual en cada reintento). */
  numLista: number;
  /**
   * Auditoría 03/10: un UUID por kit pagado por adelantado (`items[i].reservaId` de
   * /api/reservas/crear, que también es idempotente por ese id). Mismo orden que los ítems de la reserva.
   */
  reservaIds: string[];
  /**
   * 05/10 (bug 2a): firma propia de las reservas sumadas al carrito. Los ids del carrito NO dependen
   * de las reservas: si la familia quita o cambia el kit por adelantado de un hermano después de que
   * el carrito ya quedó registrado, se regeneran sólo los `reservaIds` (el carrito reusa los mismos
   * ids y la misma clave, y no se duplican pedidos). Sólo existe cuando se pasa `firmaReservas`.
   */
  firmaReservas?: string;
  /**
   * Auditoría 03/10 noche (A1): secreto al azar del checkout (32 hex). Viaja como `claveCheckout` en
   * /api/pedidos/crear, /crear-multiple y /api/reservas/crear; el servidor guarda su hash y sólo
   * acepta el reintento idempotente de un id si la clave coincide. Es la misma en los reintentos del
   * MISMO checkout y cambia cada vez que cambian los ids.
   */
  claveCheckout: string;
}

/** Auditoría 03/10 noche (A1): 32 caracteres hex con crypto.getRandomValues (16 bytes al azar). */
export function nuevaClaveCheckout(): string {
  const bytes = new Uint8Array(16);
  const cripto = typeof globalThis !== 'undefined' ? globalThis.crypto : undefined;
  if (cripto?.getRandomValues) {
    cripto.getRandomValues(bytes);
  } else {
    // Respaldo sólo para entornos sin Web Crypto (no debería pasar en navegadores actuales).
    for (let i = 0; i < bytes.length; i += 1) bytes[i] = Math.floor(Math.random() * 256);
  }
  return Array.from(bytes, (b) => b.toString(16).padStart(2, '0')).join('');
}

export function idsParaCheckout(
  previos: IdsCheckout | null,
  firma: string,
  cantidadItems: number,
  generarUuid: () => string,
  generarNumero: () => string,
  cantidadReservas = 0,
  generarClave: () => string = nuevaClaveCheckout,
  /**
   * 05/10 (bug 2a): firma de las reservas sumadas, aparte de la del carrito (`firma`). Si se pasa, un
   * cambio en las reservas regenera sólo `reservaIds`; si no se pasa (compra de reservas solas, ver
   * ReservaKitAnticipada), las reservas siguen formando parte de `firma` como hasta ahora.
   */
  firmaReservas?: string
): IdsCheckout {
  const carritoIgual =
    Boolean(previos) &&
    previos!.firma === firma &&
    previos!.itemIds.length === cantidadItems &&
    // Auditoría 03/10 noche: sin clave (no debería pasar) se arma un checkout nuevo completo.
    Boolean(previos!.claveCheckout);
  const reservasIguales =
    Boolean(previos) &&
    previos!.reservaIds?.length === cantidadReservas &&
    (firmaReservas === undefined || previos!.firmaReservas === firmaReservas);
  if (previos && carritoIgual && reservasIguales) return previos;
  if (previos && carritoIgual && firmaReservas !== undefined) {
    // Mismo carrito, otras reservas: se conservan los ids y la clave del carrito (el servidor es
    // idempotente por ellos) y sólo se sortean ids nuevos para las reservas.
    return {
      ...previos,
      reservaIds: Array.from({ length: cantidadReservas }, () => generarUuid()),
      firmaReservas,
    };
  }
  const itemIds = Array.from({ length: cantidadItems }, () => generarUuid());
  const itemFriendlyIds = Array.from({ length: cantidadItems }, () => generarNumero());
  return {
    firma,
    // El pedido de un solo hijo usa el mismo id que el último ítem (el hijo activo).
    pedidoId: itemIds[itemIds.length - 1] || generarUuid(),
    pedidoFriendlyId: itemFriendlyIds[itemFriendlyIds.length - 1] || generarNumero(),
    itemIds,
    itemFriendlyIds,
    numLista: Math.floor(1 + Math.random() * 25),
    reservaIds: Array.from({ length: cantidadReservas }, () => generarUuid()),
    ...(firmaReservas !== undefined ? { firmaReservas } : {}),
    // Auditoría 03/10 noche (A1): clave nueva junto con los ids nuevos.
    claveCheckout: generarClave(),
  };
}

/**
 * Firma estable de lo que se compra (sin el medio de pago). Auditoría 03/10 (2ª vuelta): incluye el
 * email del tutor (normalizado) — el servidor sólo acepta el reintento de un id si es del mismo
 * dueño (mismo email); si la familia corrige el email, el reintento con los ids viejos recibía 409
 * para siempre. Con el email en la firma, un email distinto genera ids nuevos.
 */
export function firmaDeCheckout(seleccion: unknown, emailTutor?: string): string {
  const email = String(emailTutor ?? '').trim().toLowerCase();
  return JSON.stringify(email ? { seleccion, email } : seleccion);
}

/**
 * 14/10/2026: los ids del checkout vivían sólo en memoria (useRef del portal). Si la respuesta de
 * /api/pedidos/crear se perdía y la familia RECARGABA la página, el reintento sorteaba ids nuevos y
 * quedaba un segundo pedido pendiente (con recordatorios y riesgo de doble cobro). Ahora se guardan en
 * sessionStorage (sólo esta pestaña; se borran al cerrarla) junto con un hash de la firma (lo que se
 * compra + email): si después de recargar la familia arma la MISMA compra, se reusan los mismos ids y la
 * misma `claveCheckout` (sin ella el servidor no acepta el reintento idempotente) y no se duplica nada.
 * La firma en sí no se guarda (tiene el email); la clave es un secreto de esta compra en esta pestaña,
 * igual que la llave del pedido que el portal ya guarda en este navegador.
 */
const CLAVE_SESION_CHECKOUT = 'retrato_checkout_en_curso';

/** Hash corto y estable (FNV-1a de 32 bits) para comparar firmas sin guardarlas. */
export function hashFirmaCheckout(firma: string): string {
  let h = 0x811c9dc5;
  for (let i = 0; i < firma.length; i += 1) {
    h ^= firma.charCodeAt(i);
    h = Math.imul(h, 0x01000193) >>> 0;
  }
  return `${firma.length}-${h.toString(16)}`;
}

export function guardarCheckoutEnSesion(ids: IdsCheckout): void {
  try {
    const { firma, ...resto } = ids;
    window.sessionStorage.setItem(CLAVE_SESION_CHECKOUT, JSON.stringify({ hash: hashFirmaCheckout(firma), ids: resto }));
  } catch {
    /* sin almacenamiento: sigue funcionando como antes (sólo en memoria) */
  }
}

/** Los ids guardados, sólo si son de la misma compra (`firma`); si no, null. */
export function leerCheckoutDeSesion(firma: string): IdsCheckout | null {
  try {
    const guardado = JSON.parse(window.sessionStorage.getItem(CLAVE_SESION_CHECKOUT) || 'null');
    if (!guardado || guardado.hash !== hashFirmaCheckout(firma) || !guardado.ids?.claveCheckout || !Array.isArray(guardado.ids.itemIds)) return null;
    return { ...guardado.ids, firma } as IdsCheckout;
  } catch {
    return null;
  }
}

export function borrarCheckoutDeSesion(): void {
  try {
    window.sessionStorage.removeItem(CLAVE_SESION_CHECKOUT);
  } catch {
    /* nada que borrar */
  }
}
