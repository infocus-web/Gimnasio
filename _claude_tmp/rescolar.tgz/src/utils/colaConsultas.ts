import type { ConsultaFamilia } from '../services/consultasFamiliasService';

/**
 * 25/10/2026 (Pablo: «el sistema de consultas es muy confuso… cuando actualicé la página lo perdí»).
 * Qué consulta le toca a quién, calculado con la conversación (no con el estado «nueva / en proceso»,
 * que sólo dice si se leyó):
 * - «Por responder»: el último mensaje es de la familia (o todavía no le respondimos nada).
 * - «Esperando a la familia»: el último mensaje es nuestro (a mano o automático).
 * Las archivadas y resueltas no entran en ninguna de las dos.
 */
function ms(fecha: string | undefined): number {
  const n = fecha ? new Date(fecha).getTime() : NaN;
  return Number.isNaN(n) ? 0 : n;
}

function ultimoMensaje(consulta: ConsultaFamilia) {
  return [...consulta.mensajes].sort((a, b) => ms(a.createdAt) - ms(b.createdAt)).pop();
}

export function estaAbierta(consulta: ConsultaFamilia): boolean {
  return consulta.estado !== 'archivada' && consulta.estado !== 'resuelta';
}

export function esPorResponder(consulta: ConsultaFamilia): boolean {
  if (!estaAbierta(consulta)) return false;
  const ultimo = ultimoMensaje(consulta);
  return !ultimo || ultimo.direccion === 'entrante';
}

export function esEsperandoFamilia(consulta: ConsultaFamilia): boolean {
  return estaAbierta(consulta) && !esPorResponder(consulta);
}

/** Desde cuándo espera la familia: su último mensaje (o la consulta misma). */
export function esperaDesde(consulta: ConsultaFamilia): number {
  const entrantes = consulta.mensajes.filter((m) => m.direccion === 'entrante').map((m) => ms(m.createdAt));
  return Math.max(ms(consulta.createdAt), ...entrantes);
}

/** «Por responder» en orden fijo: primero la que más espera. No cambia al abrirla ni al recargar. */
export function ordenarPorEspera(lista: ConsultaFamilia[]): ConsultaFamilia[] {
  return [...lista].sort((a, b) => esperaDesde(a) - esperaDesde(b) || a.id.localeCompare(b.id));
}

/** La cola de «Atender consultas»: por responder, sin las que están en «Atención especial» (esas son de Pablo). */
export function armarCola(lista: ConsultaFamilia[]): ConsultaFamilia[] {
  return ordenarPorEspera(lista.filter((c) => esPorResponder(c) && !c.atencionEspecial));
}

export function haceCuanto(desde: number, ahora = Date.now()): string {
  if (!desde) return '';
  const minutos = Math.max(0, Math.round((ahora - desde) / 60000));
  if (minutos < 1) return 'recién';
  if (minutos < 60) return `hace ${minutos} min`;
  const horas = Math.round(minutos / 60);
  if (horas < 24) return `hace ${horas} h`;
  const dias = Math.round(horas / 24);
  return `hace ${dias} ${dias === 1 ? 'día' : 'días'}`;
}

/**
 * 28/10/2026 (consulta de Susana Cabel: el mail de Yahoo se veía con un hueco enorme y el mail anterior pegado abajo).
 * El servidor sólo recorta las citas con «>» (Gmail); Yahoo, Outlook y el iPhone citan sin «>». Para MOSTRAR en el panel
 * se corta en la primera marca de cita o firma automática y se juntan las líneas vacías. No cambia lo guardado; si el
 * recorte deja el texto vacío, se muestra entero.
 */
const MARCAS_DE_CITA = [
  /^\s*>/, // Gmail
  /(escribi[oó]|wrote)\s*:\s*$/i, // «El mar, 27 de oct…, X escribió:» / «On …, X wrote:»
  /^\s*_{8,}\s*$/, // Outlook: línea de guiones bajos antes de «De: … Enviado: …»
  /^\s*-{2,}\s*(mensaje original|original message|forwarded message|mensaje reenviado)/i,
  /^\s*(yahoo mail: busca|obtener outlook para|get outlook for|enviado desde mi |sent from my )/i,
];

export function textoSinCita(texto: string | null | undefined): string {
  const original = String(texto ?? '').replace(/\r/g, '');
  const lineas = original.split('\n');
  let corte = lineas.findIndex((l) => MARCAS_DE_CITA.some((re) => re.test(l)));
  // «El …, X escribió:» puede venir partido en 2-3 líneas: se corta desde la que empieza con «El» / «On».
  if (corte > 0 && /(escribi[oó]|wrote)\s*:\s*$/i.test(lineas[corte])) {
    for (let i = corte; i >= Math.max(0, corte - 2); i--) {
      if (/^\s*(El|On)\s/i.test(lineas[i])) { corte = i; break; }
      if (i < corte && lineas[i].trim() === '') break;
    }
  }
  const util = corte === -1 ? lineas : lineas.slice(0, corte);
  const limpio = util.map((l) => l.replace(/\s+$/, '')).join('\n').replace(/\n{3,}/g, '\n\n').trim();
  return limpio || original.replace(/\n{3,}/g, '\n\n').trim();
}
