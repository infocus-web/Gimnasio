import { obtenerTokenAdmin } from '../services/adminAuthService';

/**
 * 20/10/2026 (Pablo: «cuando actualizo la página se sale del panel y tengo que loguearme nuevamente»).
 * El panel es una ventana encima de la home y que esté abierta vivía sólo en memoria: al recargar se
 * volvía a la home (la sesión seguía guardada 24 h, pero había que volver a abrir el panel). Se recuerda
 * en sessionStorage —de esta pestaña, sobrevive a la recarga y se borra al cerrar la pestaña— y sólo se
 * reabre si hay sesión guardada; el panel igual la verifica con el servidor y, si venció, pide el PIN.
 */
const CLAVE_PANEL_ABIERTO = 'infocus_panel_abierto';

export function panelQuedoAbierto(): boolean {
  try {
    return sessionStorage.getItem(CLAVE_PANEL_ABIERTO) === '1' && Boolean(obtenerTokenAdmin());
  } catch {
    return false;
  }
}

export function recordarPanelAbierto(abierto: boolean): void {
  try {
    if (abierto) sessionStorage.setItem(CLAVE_PANEL_ABIERTO, '1');
    else sessionStorage.removeItem(CLAVE_PANEL_ABIERTO);
  } catch {
    // sin sessionStorage: al recargar se vuelve a la home, como antes.
  }
}
