// 24/10/2026 (velocidad de subida): utilidades chicas para trabajar varias cosas a la vez sin perder el orden donde importa.

/**
 * Recorre `items` con hasta `limite` tareas a la vez. Antes de tomar cada ítem pregunta `debeParar()`:
 * si devuelve true no toma más (las que ya arrancaron terminan). Devuelve true si se paró antes de terminar.
 */
export async function recorrerConLimite<T>(
  items: T[],
  limite: number,
  tarea: (item: T) => Promise<void>,
  debeParar: () => boolean = () => false,
): Promise<boolean> {
  let siguiente = 0;
  let parado = false;
  const trabajador = async () => {
    while (siguiente < items.length) {
      if (debeParar()) {
        parado = true;
        return;
      }
      await tarea(items[siguiente++]);
    }
  };
  await Promise.all(Array.from({ length: Math.max(1, Math.min(limite, items.length)) }, trabajador));
  return parado;
}

/** Fila de a una: cada llamada espera a que termine la anterior (un error no corta la fila). */
export function crearFila() {
  let ultima: Promise<unknown> = Promise.resolve();
  return <R>(tarea: () => Promise<R>): Promise<R> => {
    const actual = ultima.then(tarea);
    ultima = actual.catch(() => undefined);
    return actual;
  };
}
