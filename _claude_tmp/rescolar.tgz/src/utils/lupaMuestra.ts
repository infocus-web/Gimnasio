// LUPA de las muestras (04/10/2026, pedido de Pablo). La muestra está apenas desenfocada y dice
// "PASÁ LA LUPA POR LA IMAGEN". Este módulo dibuja un círculo que, al pasar el mouse (o al mantener
// el dedo apretado en el celular), muestra la foto NÍTIDA en esa zona, sin agrandarla: es como si
// borrara el desenfoque. La parte nítida la manda el servidor de a pedacitos; la foto limpia nunca
// llega entera al navegador. Ver lupa/recorte.ts.
//
// Lo usan el portal de colegios (PortalFamiliasModal.tsx) y la galería de eventos
// (public/eventos/familias.js). La copia para eventos (public/eventos/lupa.js) se GENERA desde este
// archivo al compilar (npm run build); no editarla a mano.

export interface OpcionesLupa {
  /** URL del recorte para el centro (cx, cy) y el lado s, todo en fracciones de la foto (0 a 1). */
  urlRecorte: (cx: number, cy: number, s: number) => string | null;
  /** Diámetro del círculo con mouse (px). Pablo lo pidió de 360 px. */
  diametroCompu?: number;
  /** Diámetro máximo en el celular (px) y fracción del ancho de la foto que ocupa como mucho. */
  diametroCelular?: number;
  fraccionCelular?: number;
  /** Cartelito que explica cómo usarla (se esconde mientras la lupa está a la vista). */
  pista?: boolean;
}

export interface LupaMontada {
  /** Saca la lupa y libera todo. */
  destruir(): void;
  /** Esconde el círculo (por ejemplo al cambiar de foto). */
  ocultar(): void;
  /** Olvida los recortes de la foto anterior: llamarlo cuando el visor pasa a otra foto. */
  reiniciar(): void;
  /** true si la lupa se usó con el dedo hace menos de `ms` (para no tomar ese toque como "deslizar"). */
  usadaRecien(ms?: number): boolean;
}

interface Recorte {
  url: string;
  /** Región que cubre, en fracciones de la foto. */
  x: number;
  y: number;
  w: number;
  h: number;
}

interface RectFoto {
  x: number;
  y: number;
  w: number;
  h: number;
}

const BORDE = 3;
/**
 * Versión de los pedacitos: va en la URL para que el navegador no use los que guardó antes (se guardan
 * una hora). Subirla si cambia cómo se ven (04/10: v2 = sin sellos; 17/10: v3 = copia de 1600 px, nítida).
 */
const VERSION_RECORTES = 3;
const ESPERA_TOQUE_MS = 220;
const MAX_RECORTES = 24;
const TAM_MAXIMO = 0.75;

const redondear = (v: number) => Math.round(v * 10000) / 10000;

export function montarLupa(contenedor: HTMLElement, img: HTMLImageElement, opciones: OpcionesLupa): LupaMontada {
  const diametroCompu = opciones.diametroCompu ?? 360;
  const diametroCelular = opciones.diametroCelular ?? 255;
  const fraccionCelular = opciones.fraccionCelular ?? 0.45;
  const puedeHover = typeof window.matchMedia === 'function' && window.matchMedia('(hover: hover) and (pointer: fine)').matches;

  if (getComputedStyle(contenedor).position === 'static') contenedor.style.position = 'relative';

  const lente = document.createElement('div');
  lente.setAttribute('aria-hidden', 'true');
  lente.className = 'lupa-lente';
  Object.assign(lente.style, {
    position: 'absolute',
    display: 'none',
    boxSizing: 'border-box',
    borderRadius: '50%',
    border: `${BORDE}px solid rgba(255,255,255,0.92)`,
    boxShadow: '0 6px 24px rgba(0,0,0,0.45)',
    overflow: 'hidden',
    pointerEvents: 'none',
    zIndex: '40',
    background: 'rgba(255,255,255,0.06)',
  } as Partial<CSSStyleDeclaration>);
  const recorteImg = document.createElement('img');
  recorteImg.alt = '';
  recorteImg.draggable = false;
  Object.assign(recorteImg.style, {
    position: 'absolute',
    maxWidth: 'none',
    maxHeight: 'none',
    pointerEvents: 'none',
    userSelect: 'none',
    display: 'none',
  } as Partial<CSSStyleDeclaration>);
  lente.appendChild(recorteImg);
  contenedor.appendChild(lente);

  let pista: HTMLElement | null = null;
  if (opciones.pista !== false) {
    pista = document.createElement('div');
    pista.className = 'lupa-pista';
    pista.setAttribute('aria-hidden', 'true');
    pista.textContent = puedeHover ? 'Pasá el mouse por la foto para verla nítida' : 'Mantené el dedo apretado sobre la foto para verla nítida';
    Object.assign(pista.style, {
      position: 'absolute',
      left: '50%',
      bottom: '10px',
      transform: 'translateX(-50%)',
      background: 'rgba(15,23,42,0.72)',
      color: '#fff',
      font: '600 12px/1.3 system-ui, -apple-system, Segoe UI, Roboto, sans-serif',
      padding: '5px 12px',
      borderRadius: '999px',
      pointerEvents: 'none',
      whiteSpace: 'nowrap',
      maxWidth: '92%',
      overflow: 'hidden',
      textOverflow: 'ellipsis',
      zIndex: '39',
      transition: 'opacity .15s',
    } as Partial<CSSStyleDeclaration>);
    contenedor.appendChild(pista);
  }

  const recortes = new Map<string, Recorte>();
  const fallidos = new Set<string>();
  let enVuelo: AbortController | null = null;
  let errores = 0;
  let generacion = 0;
  let ultimo: { cx: number; cy: number; d: number } | null = null;
  let ultimoUsoTactil = 0;
  let mostrado: Recorte | null = null;

  /** Dónde está la foto dentro del contenedor (tiene en cuenta object-fit: contain). */
  function rectFoto(): RectFoto | null {
    const nw = img.naturalWidth;
    const nh = img.naturalHeight;
    if (!nw || !nh) return null;
    const rc = contenedor.getBoundingClientRect();
    const ri = img.getBoundingClientRect();
    if (!ri.width || !ri.height) return null;
    const escala = Math.min(ri.width / nw, ri.height / nh);
    const w = nw * escala;
    const h = nh * escala;
    return {
      x: ri.left - rc.left - contenedor.clientLeft + (ri.width - w) / 2,
      y: ri.top - rc.top - contenedor.clientTop + (ri.height - h) / 2,
      w,
      h,
    };
  }

  function ocultar() {
    lente.style.display = 'none';
    ultimo = null;
    if (pista) pista.style.opacity = '1';
  }

  function pintar(cx: number, cy: number, d: number, r: RectFoto) {
    lente.style.width = `${d}px`;
    lente.style.height = `${d}px`;
    lente.style.left = `${cx - d / 2}px`;
    lente.style.top = `${cy - d / 2}px`;
    lente.style.display = 'block';
    if (pista) pista.style.opacity = '0';
    ultimo = { cx, cy, d };

    // Zona del círculo, en fracciones de la foto.
    const zona = {
      x0: Math.max(0, (cx - d / 2 - r.x) / r.w),
      x1: Math.min(1, (cx + d / 2 - r.x) / r.w),
      y0: Math.max(0, (cy - d / 2 - r.y) / r.h),
      y1: Math.min(1, (cy + d / 2 - r.y) / r.h),
    };
    let elegido: Recorte | null = null;
    let mejor = 0;
    let cubre = false;
    for (const rec of recortes.values()) {
      const ix = Math.max(0, Math.min(zona.x1, rec.x + rec.w) - Math.max(zona.x0, rec.x));
      const iy = Math.max(0, Math.min(zona.y1, rec.y + rec.h) - Math.max(zona.y0, rec.y));
      const area = ix * iy;
      const completo = rec.x <= zona.x0 + 1e-3 && rec.x + rec.w >= zona.x1 - 1e-3 && rec.y <= zona.y0 + 1e-3 && rec.y + rec.h >= zona.y1 - 1e-3;
      if (completo && (!cubre || area >= mejor)) {
        elegido = rec;
        mejor = area;
        cubre = true;
      } else if (!cubre && area > mejor) {
        elegido = rec;
        mejor = area;
      }
    }
    if (elegido) {
      if (mostrado !== elegido) {
        // El que se mostraba antes pudo haber salido de la lista: recién ahora se libera.
        if (mostrado && !Array.from(recortes.values()).includes(mostrado)) URL.revokeObjectURL(mostrado.url);
        recorteImg.src = elegido.url;
        mostrado = elegido;
      }
      recorteImg.style.display = 'block';
      recorteImg.style.left = `${r.x + elegido.x * r.w - (cx - d / 2 + BORDE)}px`;
      recorteImg.style.top = `${r.y + elegido.y * r.h - (cy - d / 2 + BORDE)}px`;
      recorteImg.style.width = `${elegido.w * r.w}px`;
      recorteImg.style.height = `${elegido.h * r.h}px`;
    } else {
      recorteImg.style.display = 'none';
    }
    if (!cubre) pedir(cx, cy, d, r);
  }

  /** Pide al servidor un recorte un poco más grande que el círculo, centrado en una grilla (para reusarlo). */
  function pedir(cx: number, cy: number, d: number, r: RectFoto) {
    if (enVuelo || errores >= 4) return;
    // 09/10: se volvió a pedir 1,6 veces el círculo (con 1,25 la lupa pedía mucho más seguido y se
    // sentía trabada). El límite real lo pone el servidor: el pedacito nunca pasa el 80 % del lado
    // corto de la foto (lupa/recorte.ts, auditoría 08/10 A1).
    let s = Math.min(TAM_MAXIMO, Math.max(0.1, (1.6 * d) / r.w));
    s = Math.round(s * 20) / 20;
    const paso = s / 6;
    const pasoV = (paso * r.w) / r.h;
    const u = Math.min(1, Math.max(0, Math.round((cx - r.x) / r.w / paso) * paso));
    const v = Math.min(1, Math.max(0, Math.round((cy - r.y) / r.h / pasoV) * pasoV));
    const clave = `${redondear(u)}|${redondear(v)}|${s}`;
    if (recortes.has(clave) || fallidos.has(clave)) return;
    const base = opciones.urlRecorte(redondear(u), redondear(v), s);
    if (!base) return;
    const url = `${base}${base.includes('?') ? '&' : '?'}v=${VERSION_RECORTES}`;
    const ctrl = new AbortController();
    enVuelo = ctrl;
    const miGeneracion = generacion;
    fetch(url, { credentials: 'same-origin', signal: ctrl.signal })
      .then(async (resp) => {
        if (!resp.ok) throw new Error(String(resp.status));
        const region = String(resp.headers.get('X-Lupa-Region') || '').split(',').map(Number);
        if (region.length !== 6 || region.some((n) => !Number.isFinite(n)) || !region[4] || !region[5]) throw new Error('sin región');
        const blob = await resp.blob();
        if (miGeneracion !== generacion) return; // ya se pasó a otra foto
        const [left, top, ancho, alto, W, H] = region;
        recortes.set(clave, { url: URL.createObjectURL(blob), x: left / W, y: top / H, w: ancho / W, h: alto / H });
        errores = 0;
        while (recortes.size > MAX_RECORTES) {
          const viejo = recortes.keys().next().value;
          if (viejo === undefined) break;
          const rec = recortes.get(viejo);
          recortes.delete(viejo);
          if (rec && rec !== mostrado) URL.revokeObjectURL(rec.url);
        }
      })
      .catch((e) => {
        if (e && e.name === 'AbortError') return;
        fallidos.add(clave);
        errores++;
      })
      .finally(() => {
        if (enVuelo === ctrl) enVuelo = null;
        if (miGeneracion !== generacion) return;
        // Se vuelve a pintar con lo último (el círculo pudo haberse movido mientras bajaba).
        const r2 = rectFoto();
        if (ultimo && r2) pintar(ultimo.cx, ultimo.cy, ultimo.d, r2);
      });
  }

  function diametro(r: RectFoto, tactil: boolean): number {
    if (tactil) return Math.round(Math.min(diametroCelular, r.w * fraccionCelular));
    return Math.round(Math.min(diametroCompu, Math.min(r.w, r.h) * 0.8));
  }

  /** Muestra la lupa para un punto de la pantalla. Devuelve false si cae fuera de la foto. */
  function mostrarEn(clientX: number, clientY: number, tactil: boolean): boolean {
    const r = rectFoto();
    if (!r) {
      ocultar();
      return false;
    }
    const rc = contenedor.getBoundingClientRect();
    const px = clientX - rc.left - contenedor.clientLeft;
    const py = clientY - rc.top - contenedor.clientTop;
    if (px < r.x || py < r.y || px > r.x + r.w || py > r.y + r.h) {
      ocultar();
      return false;
    }
    const d = diametro(r, tactil);
    let cx = px;
    let cy = py;
    if (tactil) {
      // En el celular el círculo va ARRIBA del dedo (si no, el dedo tapa lo que se quiere ver).
      cy = Math.max(r.y, py - d / 2 - 24);
      cx = Math.min(Math.max(px, r.x), r.x + r.w);
    }
    pintar(cx, cy, d, r);
    return true;
  }

  // ---------------- Mouse ----------------
  const alMover = (e: MouseEvent) => {
    mostrarEn(e.clientX, e.clientY, false);
  };
  const alSalir = () => ocultar();
  if (puedeHover) {
    contenedor.addEventListener('mousemove', alMover);
    contenedor.addEventListener('mouseleave', alSalir);
  }

  // ---------------- Dedo: mantener apretado ----------------
  let temporizador: ReturnType<typeof setTimeout> | undefined;
  let inicio: { x: number; y: number } | null = null;
  let activa = false;
  const alTocar = (e: TouchEvent) => {
    if (e.touches.length !== 1) {
      cancelar();
      return;
    }
    const t = e.touches[0];
    inicio = { x: t.clientX, y: t.clientY };
    activa = false;
    clearTimeout(temporizador);
    temporizador = setTimeout(() => {
      if (inicio && mostrarEn(inicio.x, inicio.y, true)) {
        activa = true;
        ultimoUsoTactil = Date.now();
        try {
          navigator.vibrate?.(10);
        } catch {
          /* algunos navegadores no dejan vibrar */
        }
      }
    }, ESPERA_TOQUE_MS);
  };
  const alArrastrar = (e: TouchEvent) => {
    const t = e.touches[0];
    if (!inicio || !t) return;
    if (activa) {
      e.preventDefault(); // con la lupa a la vista, el dedo no mueve la página ni pasa de foto
      ultimoUsoTactil = Date.now();
      mostrarEn(t.clientX, t.clientY, true);
      return;
    }
    if (Math.abs(t.clientX - inicio.x) > 8 || Math.abs(t.clientY - inicio.y) > 8) {
      clearTimeout(temporizador);
      inicio = null;
    }
  };
  const alSoltar = (e: TouchEvent) => {
    clearTimeout(temporizador);
    if (activa) {
      if (e.cancelable) e.preventDefault();
      ultimoUsoTactil = Date.now();
      ocultar();
    }
    activa = false;
    inicio = null;
  };
  function cancelar() {
    clearTimeout(temporizador);
    if (activa) ultimoUsoTactil = Date.now();
    activa = false;
    inicio = null;
    ocultar();
  }
  const sinMenu = (e: Event) => e.preventDefault();
  contenedor.addEventListener('touchstart', alTocar, { passive: true });
  contenedor.addEventListener('touchmove', alArrastrar, { passive: false });
  contenedor.addEventListener('touchend', alSoltar, { passive: false });
  contenedor.addEventListener('touchcancel', cancelar);
  contenedor.addEventListener('contextmenu', sinMenu);
  window.addEventListener('resize', ocultar);

  function olvidarRecortes() {
    generacion++;
    enVuelo?.abort();
    enVuelo = null;
    for (const rec of recortes.values()) URL.revokeObjectURL(rec.url);
    if (mostrado && !Array.from(recortes.values()).includes(mostrado)) URL.revokeObjectURL(mostrado.url);
    recortes.clear();
    fallidos.clear();
    errores = 0;
    mostrado = null;
    recorteImg.removeAttribute('src');
    recorteImg.style.display = 'none';
  }

  /** Pide de entrada el centro de la foto: así el servidor ya tiene la copia nítida lista cuando se usa. */
  function precalentar() {
    const hacer = () => {
      const r = rectFoto();
      if (!r || ultimo) return;
      const d = diametro(r, !puedeHover);
      pedir(r.x + r.w / 2, r.y + r.h / 2, d, r);
    };
    if (img.complete && img.naturalWidth) hacer();
    else img.addEventListener('load', hacer, { once: true });
  }
  precalentar();

  return {
    destruir() {
      cancelar();
      olvidarRecortes();
      contenedor.removeEventListener('mousemove', alMover);
      contenedor.removeEventListener('mouseleave', alSalir);
      contenedor.removeEventListener('touchstart', alTocar);
      contenedor.removeEventListener('touchmove', alArrastrar);
      contenedor.removeEventListener('touchend', alSoltar);
      contenedor.removeEventListener('touchcancel', cancelar);
      contenedor.removeEventListener('contextmenu', sinMenu);
      window.removeEventListener('resize', ocultar);
      lente.remove();
      pista?.remove();
    },
    ocultar,
    reiniciar() {
      cancelar();
      olvidarRecortes();
      precalentar();
    },
    usadaRecien(ms = 400) {
      return activa || Date.now() - ultimoUsoTactil < ms;
    },
  };
}
