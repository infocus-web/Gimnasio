import type { PedidoEscolarCompleto } from '../services/pedidosLabService';

/** Auditoría 03/10 noche (M7/H6): monto del pedido para mostrar ("$30.000"), o '' si el servidor todavía no lo informó. */
export function montoDelPedido(pedido: Pick<PedidoEscolarCompleto, 'total'> | null | undefined): string {
  const total = Number(pedido?.total);
  return Number.isFinite(total) && total > 0 ? `$${total.toLocaleString('es-AR')}` : '';
}
