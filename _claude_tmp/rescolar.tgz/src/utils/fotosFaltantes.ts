/**
 * 22/10/2026 (Pablo): «si un alumno le falta una foto (no quiso o no estaba el día de la toma), no podrá
 * terminar el pedido». En la galería la familia puede avisar «Mi hijo/a no tiene esta foto» en un lugar del
 * pack (individual, grupal o la 3ª foto = `docente`) y, en ese lugar, elegir OTRA foto del curso o seguir
 * sin ella. El precio no cambia. Viaja en `fotosSeleccionadas.sinFoto`. Debe coincidir con
 * servidor/nucleo/fotosFaltantes.ts.
 */
import { esTerceraFoto } from './terceraFoto';
import { finDelDia, plazosVigentes } from './plazosTemporada';

export type LugarPack = 'individual' | 'grupal' | 'docente';
export const LUGARES_PACK: readonly LugarPack[] = ['individual', 'grupal', 'docente'];

/** Los lugares del pack que la familia marcó «no tiene esta foto» (sin repetidos, sólo valores válidos). */
export function lugaresSinFoto(seleccion: unknown): LugarPack[] {
  const lista = (seleccion as { sinFoto?: unknown } | null | undefined)?.sinFoto;
  if (!Array.isArray(lista)) return [];
  return LUGARES_PACK.filter((lugar) => lista.includes(lugar));
}

/** Si una foto de esta categoría puede ir en ese lugar del pack (en un lugar «sin foto», cualquiera del curso). */
export function categoriaValeEnLugar(categoria: unknown, lugar: LugarPack, sinFoto: readonly LugarPack[]): boolean {
  if (typeof categoria !== 'string' || !categoria) return false;
  if (sinFoto.includes(lugar)) return categoria !== 'patio'; // las sueltas se venden aparte
  if (lugar === 'docente') return esTerceraFoto(categoria);
  return categoria === lugar;
}

/** El id guardado para un lugar si sigue siendo válido en esta galería; si no, ''. */
export function idValidoEnLugar(
  fotos: readonly { id: string; categoria: string }[],
  id: string | undefined,
  lugar: LugarPack,
  sinFoto: readonly LugarPack[]
): string {
  return id && fotos.some((f) => f.id === id && categoriaValeEnLugar(f.categoria, lugar, sinFoto)) ? id : '';
}

/** Cómo se nombra cada lugar en los textos («la foto individual», …). */
export const NOMBRE_LUGAR: Record<LugarPack, string> = {
  individual: 'la foto individual',
  grupal: 'la foto grupal',
  docente: 'la 3ª foto',
};

/**
 * 29/10/2026 (Pablo: «es confuso, si ni yo lo supe, cómo podrían los padres»): qué falta del kit, dicho en palabras
 * (antes sólo se veía «Elegí las 2 fotos (1/2)»). `faltan` en orden del pack; `nombre` = cómo se llama cada lugar.
 */
export function textoFaltaEnElPack(faltan: readonly LugarPack[], sinFoto: readonly LugarPack[], activa: string, nombre: (l: LugarPack) => string): string {
  if (faltan.length === 0) return '';
  const partes = faltan.map((l) => (sinFoto.includes(l) ? `una foto en lugar de ${nombre(l)}` : nombre(l)));
  const aca = faltan.includes(activa as LugarPack) && sinFoto.includes(activa as LugarPack);
  return `Falta elegir ${partes.join(' y ')}.${aca ? ' Tocá «Usar en su lugar» en una de las fotos de arriba.' : ''}`;
}

/** 29/10: en qué lugar del kit está ya esta foto (para no ofrecerla de nuevo en otro lugar). */
export function lugarDeLaFoto(id: string, elegidas: Record<LugarPack, string>): LugarPack | undefined {
  return LUGARES_PACK_FRONT.find((l) => elegidas[l] === id);
}
const LUGARES_PACK_FRONT: readonly LugarPack[] = ['grupal', 'individual', 'docente'];

// 22/10/2026 (Pablo): «Faltantes solicitadas»: hasta el 15/11/2026 inclusive. Igual que servidor/nucleo/fotosFaltantes.ts.
// 30/10/2026: la fecha se edita desde el panel → Configuración (utils/plazosTemporada.ts).
export type MotivoFaltante = 'ausente' | 'no_quiso' | 'no_encontrada';
export function solicitudFaltanteAbierta(ahora: Date = new Date()): boolean {
  return ahora.getTime() <= finDelDia(plazosVigentes().faltantes);
}
