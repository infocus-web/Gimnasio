import { useEffect } from 'react';

/**
 * Tablas del panel en el celular (28/9/2026, pedido de Pablo: "la web para el celular no está
 * optimizada"). Debajo de 768px, las tablas dentro de `.tablas-apilables` se muestran como
 * tarjetas (CSS en src/index.css). Para que cada dato tenga su título, este hook copia el texto
 * de la cabecera (<th>) a cada celda como `data-etiqueta`, y lo mantiene al día si la tabla cambia.
 */
export function etiquetarTablas(raiz: ParentNode) {
  raiz.querySelectorAll<HTMLTableElement>('.tablas-apilables table').forEach((tabla) => {
    const titulos = Array.from(tabla.querySelectorAll<HTMLTableCellElement>('thead tr:first-child th')).map((th) => (th.textContent || '').trim());
    if (titulos.length === 0) return;
    tabla.querySelectorAll<HTMLTableRowElement>('tbody tr').forEach((fila) => {
      let col = 0;
      Array.from(fila.cells).forEach((celda) => {
        const titulo = celda.colSpan > 1 ? '' : titulos[col] || '';
        if (titulo) {
          if (celda.dataset.etiqueta !== titulo) celda.dataset.etiqueta = titulo;
        } else if (celda.dataset.etiqueta) {
          delete celda.dataset.etiqueta;
        }
        col += celda.colSpan || 1;
      });
    });
  });
}

export function useEtiquetasTablasMovil() {
  useEffect(() => {
    if (typeof document === 'undefined' || typeof MutationObserver === 'undefined') return;
    let pendiente = 0;
    const programar = () => {
      if (pendiente) return;
      pendiente = window.requestAnimationFrame(() => {
        pendiente = 0;
        etiquetarTablas(document);
      });
    };
    programar();
    // Sólo cambios de estructura (no de atributos), así poner data-etiqueta no dispara otra vuelta.
    const obs = new MutationObserver(programar);
    obs.observe(document.body, { childList: true, subtree: true, characterData: true });
    return () => {
      obs.disconnect();
      if (pendiente) window.cancelAnimationFrame(pendiente);
    };
  }, []);
}
