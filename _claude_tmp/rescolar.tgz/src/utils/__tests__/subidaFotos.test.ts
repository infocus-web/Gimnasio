// 14/10/2026: subida de fotos del panel. Al volver a elegir la carpeta (tras recargar o desde otro equipo) se
// saltean las fotos que ya están subidas al curso: sólo si coinciden nombre Y tamaño (las cámaras repiten nombres).
import { describe, expect, it } from 'vitest';
import { claveArchivoOriginal, separarYaSubidas } from '../subidaFotos';

const archivo = (name: string, size: number) => ({ name, size });

describe('separarYaSubidas', () => {
  it('saltea las que ya están (mismo nombre y tamaño, sin importar mayúsculas)', () => {
    const r = separarYaSubidas([archivo('IMG_1.JPG', 100), archivo('IMG_2.JPG', 200)], [{ nombreOriginal: 'img_1.jpg', bytesOriginal: 100 }]);
    expect(r.nuevos.map((a) => a.name)).toEqual(['IMG_2.JPG']);
    expect(r.repetidos).toBe(1);
  });

  it('mismo nombre pero otro tamaño = otra foto (contador de la cámara reiniciado): se sube', () => {
    const r = separarYaSubidas([archivo('IMG_1.JPG', 999)], [{ nombreOriginal: 'IMG_1.JPG', bytesOriginal: 100 }]);
    expect(r.nuevos).toHaveLength(1);
    expect(r.repetidos).toBe(0);
  });

  it('fotos viejas sin datos del original no frenan nada; el mismo archivo dos veces en la tanda va una sola vez', () => {
    const r = separarYaSubidas([archivo('A.jpg', 10), archivo('A.jpg', 10), archivo('B.jpg', 20)], [{ nombreOriginal: null, bytesOriginal: null }]);
    expect(r.nuevos.map((a) => a.name)).toEqual(['A.jpg', 'B.jpg']);
    expect(r.repetidos).toBe(1);
  });

  it('claveArchivoOriginal necesita nombre y tamaño válidos', () => {
    expect(claveArchivoOriginal('A.jpg', 0)).toBeNull();
    expect(claveArchivoOriginal('', 10)).toBeNull();
    expect(claveArchivoOriginal(' A.JPG ', 10)).toBe('a.jpg|10');
  });
});
