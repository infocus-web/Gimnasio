// 04/10: lupa de las muestras (pedido de Pablo): el círculo muestra la foto nítida que manda el servidor
// de a pedacitos, sin agrandar. jsdom no calcula tamaños: se fijan a mano.
import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import { montarLupa } from '../lupaMuestra';

function armar(hover: boolean) {
  vi.stubGlobal('matchMedia', vi.fn(() => ({ matches: hover })));
  const contenedor = document.createElement('div');
  const img = document.createElement('img');
  contenedor.appendChild(img);
  document.body.appendChild(contenedor);
  const caja = { left: 0, top: 0, right: 800, bottom: 600, width: 800, height: 600, x: 0, y: 0, toJSON: () => ({}) };
  contenedor.getBoundingClientRect = () => caja as DOMRect;
  img.getBoundingClientRect = () => caja as DOMRect;
  // Foto 800x533 dentro de una caja 800x600 con object-fit: contain → franjas de 33,5 px arriba y abajo.
  Object.defineProperty(img, 'naturalWidth', { value: 800 });
  Object.defineProperty(img, 'naturalHeight', { value: 533 });
  Object.defineProperty(img, 'complete', { value: true });
  return { contenedor, img };
}

function respuesta(region = '100,50,400,400,800,533') {
  return new Response(new Uint8Array([255, 216, 255]), { status: 200, headers: { 'X-Lupa-Region': region, 'Content-Type': 'image/jpeg' } });
}

const esperar = () => new Promise((ok) => setTimeout(ok, 0));

let fetchFalso: ReturnType<typeof vi.fn>;
beforeEach(() => {
  fetchFalso = vi.fn(async () => respuesta());
  vi.stubGlobal('fetch', fetchFalso);
  let n = 0;
  URL.createObjectURL = vi.fn(() => `blob:recorte-${++n}`) as any;
  URL.revokeObjectURL = vi.fn() as any;
});
afterEach(() => {
  document.body.innerHTML = '';
});

describe('lupa de las muestras', () => {
  it('al montarse pide un pedacito del centro (así el servidor ya tiene la copia nítida lista)', async () => {
    const { contenedor, img } = armar(true);
    const urlRecorte = vi.fn((cx: number, cy: number, s: number) => `/api/x/lupa?cx=${cx}&cy=${cy}&s=${s}`);
    montarLupa(contenedor, img, { urlRecorte });
    expect(urlRecorte).toHaveBeenCalledTimes(1);
    const [cx, cy, s] = urlRecorte.mock.calls[0];
    expect(s).toBe(0.7); // 1,6 × 360 / 800, redondeado
    expect(cx).toBeGreaterThan(0.4);
    expect(cx).toBeLessThan(0.6);
    expect(cy).toBeGreaterThan(0.4);
    expect(cy).toBeLessThan(0.6);
    // v=3: versión de los pedacitos (17/10: copia de 1600 px), para no usar los guardados de antes.
    expect(fetchFalso).toHaveBeenCalledWith('/api/x/lupa?cx=' + cx + '&cy=' + cy + '&s=0.7&v=3', expect.objectContaining({ credentials: 'same-origin' }));
  });

  it('con el mouse: círculo de 360 px centrado en el puntero que muestra el pedacito en su lugar (sin zoom)', async () => {
    const { contenedor, img } = armar(true);
    montarLupa(contenedor, img, { urlRecorte: (cx, cy, s) => `/l?cx=${cx}&cy=${cy}&s=${s}` });
    await esperar();
    await esperar();
    contenedor.dispatchEvent(new MouseEvent('mousemove', { clientX: 400, clientY: 300, bubbles: true }));
    const lente = contenedor.querySelector('.lupa-lente') as HTMLDivElement;
    expect(lente.style.display).toBe('block');
    expect(lente.style.width).toBe('360px');
    expect(lente.style.left).toBe('220px');
    expect(lente.style.top).toBe('120px');
    const recorte = lente.querySelector('img') as HTMLImageElement;
    expect(recorte.style.display).toBe('block');
    // Región 100,50 de 400x400 sobre una foto de 800x533 mostrada a 800x533 desde y=33,5: misma escala.
    expect(recorte.style.width).toBe('400px');
    expect(parseFloat(recorte.style.height)).toBeCloseTo(400, 0);
    expect(recorte.style.left).toBe(`${100 - (220 + 3)}px`);
    expect(parseFloat(recorte.style.top)).toBeCloseTo(33.5 + 50 - (120 + 3), 3);
    // La pista se esconde mientras la lupa está a la vista.
    expect((contenedor.querySelector('.lupa-pista') as HTMLElement).style.opacity).toBe('0');
  });

  it('fuera de la foto (en la franja negra) no muestra nada', () => {
    const { contenedor, img } = armar(true);
    montarLupa(contenedor, img, { urlRecorte: () => '/l' });
    contenedor.dispatchEvent(new MouseEvent('mousemove', { clientX: 400, clientY: 10, bubbles: true }));
    expect((contenedor.querySelector('.lupa-lente') as HTMLElement).style.display).toBe('none');
  });

  it('si el servidor falla varias veces deja de pedir (no insiste para siempre)', async () => {
    fetchFalso.mockImplementation(async () => new Response('x', { status: 500 }));
    const { contenedor, img } = armar(true);
    montarLupa(contenedor, img, { urlRecorte: (cx, cy, s) => `/l?cx=${cx}&cy=${cy}&s=${s}` });
    for (let x = 100; x <= 700; x += 100) {
      contenedor.dispatchEvent(new MouseEvent('mousemove', { clientX: x, clientY: 300, bubbles: true }));
      await esperar();
      await esperar();
    }
    expect(fetchFalso.mock.calls.length).toBeLessThanOrEqual(4);
  });

  it('en el celular: mantener apretado muestra un círculo más chico ARRIBA del dedo', async () => {
    vi.useFakeTimers();
    try {
      const { contenedor, img } = armar(false);
      const lupa = montarLupa(contenedor, img, { urlRecorte: () => null });
      const toque = (tipo: string, x: number, y: number) => {
        const ev = new Event(tipo, { bubbles: true, cancelable: true });
        const lista = tipo === 'touchend' ? [] : [{ clientX: x, clientY: y }];
        Object.defineProperty(ev, 'touches', { value: lista });
        Object.defineProperty(ev, 'changedTouches', { value: [{ clientX: x, clientY: y }] });
        contenedor.dispatchEvent(ev);
        return ev;
      };
      toque('touchstart', 400, 400);
      vi.advanceTimersByTime(250);
      const lente = contenedor.querySelector('.lupa-lente') as HTMLElement;
      expect(lente.style.display).toBe('block');
      expect(lente.style.width).toBe('255px');
      // Centro 24 px por encima del borde de arriba del dedo: 400 - 127,5 - 24.
      expect(parseFloat(lente.style.top) + 127.5).toBeCloseTo(400 - 127.5 - 24, 3);
      const mover = toque('touchmove', 420, 380);
      expect(mover.defaultPrevented).toBe(true); // el dedo no mueve la página
      toque('touchend', 420, 380);
      expect(lente.style.display).toBe('none');
      expect(lupa.usadaRecien()).toBe(true); // el visor no lo toma como "deslizar para pasar de foto"
    } finally {
      vi.useRealTimers();
    }
  });

  it('un toque corto no muestra la lupa', () => {
    vi.useFakeTimers();
    try {
      const { contenedor, img } = armar(false);
      const lupa = montarLupa(contenedor, img, { urlRecorte: () => null });
      const ev = new Event('touchstart', { bubbles: true });
      Object.defineProperty(ev, 'touches', { value: [{ clientX: 400, clientY: 300 }] });
      contenedor.dispatchEvent(ev);
      vi.advanceTimersByTime(100);
      const fin = new Event('touchend', { bubbles: true, cancelable: true });
      Object.defineProperty(fin, 'touches', { value: [] });
      contenedor.dispatchEvent(fin);
      vi.advanceTimersByTime(300);
      expect((contenedor.querySelector('.lupa-lente') as HTMLElement).style.display).toBe('none');
      expect(lupa.usadaRecien()).toBe(false);
    } finally {
      vi.useRealTimers();
    }
  });

  it('destruir saca el círculo y la pista y libera los pedacitos', async () => {
    const { contenedor, img } = armar(true);
    const lupa = montarLupa(contenedor, img, { urlRecorte: (cx, cy, s) => `/l?cx=${cx}&cy=${cy}&s=${s}` });
    await esperar();
    await esperar();
    lupa.destruir();
    expect(contenedor.querySelector('.lupa-lente')).toBeNull();
    expect(contenedor.querySelector('.lupa-pista')).toBeNull();
    expect(URL.revokeObjectURL).toHaveBeenCalled();
  });
});
