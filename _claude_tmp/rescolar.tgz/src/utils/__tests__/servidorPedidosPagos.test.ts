import ts from 'typescript';
import { describe, expect, it } from 'vitest';
import { fuenteServidor } from '../../test/fuenteServidor';

// Auditoría 03/10 (pedidos y pagos): server.ts no se puede importar en las pruebas (arranca el
// servidor), así que se extraen del archivo las funciones puras nuevas, se transpilan y se prueban.
const server = fuenteServidor();

function extraerFuncion(nombre: string): string {
  const inicio = server.search(new RegExp(`^(async )?function ${nombre}\\b`, 'm'));
  if (inicio < 0) throw new Error(`No encontré ${nombre} en server.ts`);
  const fin = server.indexOf('\n}\n', inicio);
  return server.slice(inicio, fin + 2);
}

function cargar<T>(nombres: string[]): T {
  const fuente = nombres.map(extraerFuncion).join('\n\n');
  const js = ts.transpileModule(fuente, { compilerOptions: { target: ts.ScriptTarget.ES2020 } }).outputText;
  // eslint-disable-next-line @typescript-eslint/no-implied-eval
  return new Function(`${js}\nreturn { ${nombres.join(', ')} };`)() as T;
}

const { mismoDuenoDePedido, respuestaKitYaPagado, mapConLimite } = cargar<{
  mismoDuenoDePedido: (fila: any, datos: any) => boolean;
  respuestaKitYaPagado: (alumnos: string[]) => any;
  mapConLimite: <T, R>(items: T[], limite: number, fn: (item: T, i: number) => Promise<R>) => Promise<R[]>;
}>(['normalizarNombreComparable', 'normalizarNombrePorPalabras', 'mismoDuenoDePedido', 'respuestaKitYaPagado', 'mapConLimite']);

describe('crear pedido idempotente: mismo dueño', () => {
  const fila = { alumno_nombre: 'García, María José', familias: { email: 'Mama@Mail.com', nombre: 'Ana', whatsapp: '11 5555-1234' } };

  it('mismo chico (en otro orden) y mismo email: es un reintento', () => {
    expect(mismoDuenoDePedido(fila, { email: 'mama@mail.com ', alumno: 'María José García', nombre: 'Otro', telefono: '' })).toBe(true);
  });

  it('otro email u otro chico: no es del mismo dueño', () => {
    expect(mismoDuenoDePedido(fila, { email: 'otro@mail.com', alumno: 'María José García' })).toBe(false);
    expect(mismoDuenoDePedido(fila, { email: 'mama@mail.com', alumno: 'Juan García' })).toBe(false);
    expect(mismoDuenoDePedido(fila, { email: '', alumno: 'María José García', telefono: '1155551234', nombre: 'Ana' })).toBe(false);
  });

  it('sin email en ninguno de los dos: exige mismo teléfono y mismo tutor', () => {
    const sinEmail = { alumno_nombre: 'Lola Pérez', familias: [{ email: null, nombre: 'Ana Pérez', whatsapp: '11 5555-1234' }] };
    expect(mismoDuenoDePedido(sinEmail, { email: '', alumno: 'lola perez', telefono: '1155551234', nombre: 'Pérez Ana' })).toBe(true);
    expect(mismoDuenoDePedido(sinEmail, { email: '', alumno: 'lola perez', telefono: '', nombre: 'Ana Pérez' })).toBe(false);
  });
});

describe('contrato KIT_YA_PAGADO', () => {
  it('devuelve código, chicos y mensaje en español', () => {
    const r = respuestaKitYaPagado(['Lola Pérez']);
    expect(r).toMatchObject({ success: false, codigo: 'KIT_YA_PAGADO', alumnos: ['Lola Pérez'] });
    expect(r.error).toContain('Lola Pérez ya tiene un kit pagado');
    expect(respuestaKitYaPagado(['A', 'B']).error).toContain('A, B ya tienen un kit pagado');
  });

  it('crear, crear-multiple y reservas aceptan confirmarOtroKit', () => {
    expect(server.match(/confirmarOtroKit !== true/g)?.length).toBeGreaterThanOrEqual(3);
  });
});

describe('descargas del .zip con concurrencia limitada', () => {
  it('nunca corre más de N a la vez y conserva el orden', async () => {
    let activos = 0;
    let maximo = 0;
    const r = await mapConLimite([1, 2, 3, 4, 5, 6, 7, 8, 9], 4, async (n) => {
      activos += 1;
      maximo = Math.max(maximo, activos);
      await new Promise((resolve) => setTimeout(resolve, 5 + (n % 3)));
      activos -= 1;
      return n * 10;
    });
    expect(maximo).toBe(4);
    expect(r).toEqual([10, 20, 30, 40, 50, 60, 70, 80, 90]);
  });
});

describe('reembolsos y cancelaciones definitivas', () => {
  it('reembolso / contracargo dejan cancelado_definitivo y CHARGEBACK_REVIEW sólo avisa', () => {
    expect(server).toContain("update({ estado: 'cancelado', cancelado_definitivo: true, updated_at: new Date().toISOString() })\n            .eq('mp_payment_id', String(paymentId))");
    expect(server).toContain("const esReversion = ['PURCHASE_REVERSED', 'CHARGED_BACK', 'REFUNDED'].includes(estadoNave || '');");
    expect(server).toContain('contracargo-revision-nave:');
  });

  it('resolver cancelación reclama la solicitud y manda clave de idempotencia a Mercado Pago', () => {
    expect(server).toContain("idempotencyKey: `arrepentimiento-${sol.id}`");
    expect(server.indexOf(".eq('estado', 'nueva')\n      .select('id');")).toBeLessThan(server.indexOf('const reintegros = new PaymentRefund(mpConfig);'));
  });
});
