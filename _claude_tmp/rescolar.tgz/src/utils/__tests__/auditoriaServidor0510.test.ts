// Auditoría 05/10 (pagos, entrega HD y selección): contratos del servidor que el portal da por
// hechos. server.ts no se puede importar en las pruebas (arranca Express, sharp, etc.), así que se
// revisa el código fuente de cada ruta: si alguien saca una de estas reglas, esta prueba lo avisa.
import { describe, expect, it } from 'vitest';

import { fuenteServidor } from '../../test/fuenteServidor';

const fuente = fuenteServidor();

function bloqueDesde(marca: string, largo = 6000): string {
  const inicio = fuente.indexOf(marca);
  if (inicio < 0) throw new Error(`No se encontró "${marca}" en server.ts`);
  return fuente.slice(inicio, inicio + largo);
}

describe('auditoría 05/10: reservas pagadas (elegir fotos)', () => {
  // 06/10: la ruta creció (3ª foto con la seño o con familia/amigos): se mira un tramo más largo.
  const ruta = bloqueDesde("app.post('/api/reservas/:id/elegir-fotos'", 9000);
  it('exige la llave de la familia o la del pedido antes de aceptar la selección', () => {
    expect(ruta).toContain("codigo: 'LLAVE_REQUERIDA'");
    expect(ruta).toContain('hijosDeFamiliaConAcceso(supabase, req.body?.familia, req.body?.acceso)');
    expect(ruta).toContain('tokenAccesoValido(llaveRecibida(req), [pedido.id, pedido.grupo_pago_id])');
  });
  it('reinicia email_enviado al confirmar las fotos (el reintento horario del HD lo vuelve a tomar)', () => {
    expect(ruta).toMatch(/seleccion_pendiente: false, email_enviado: false, fecha_envio_email: null/);
  });
  it('responde 409 "ya fueron elegidas" en la carrera de dos confirmaciones (el portal lo toma como éxito)', () => {
    expect(ruta).toContain("error: 'Las fotos de este kit ya fueron elegidas.'");
  });
  it('/api/reservas/pendiente no entrega el id de una reserva pagada sin la llave de la familia', () => {
    const pendiente = bloqueDesde("app.get('/api/reservas/pendiente'");
    expect(pendiente).toContain("const idVisible = esDeLaFamilia || elegida.estado !== 'pagado'");
    expect(pendiente).toContain('id: idVisible ? elegida.id : null');
  });
});

describe('auditoría 05/10: entrega HD', () => {
  const fn = bloqueDesde('async function generarYSubirZipHDParaPedido(', 8000); // 25/10: + control de peso antes de bajar
  it('no arma un .zip incompleto si una foto elegida ya no existe y avisa al admin', () => {
    expect(fn).toContain("avisarAdminEntregaHD(pedido, 'fotos-faltantes'");
    expect(fn).toContain('if (idsEsperados.length > 0 && (idsPerdidos.length > 0 || sinArchivo > 0)) {');
  });
  it('avisa cuando el .zip supera el límite del bucket en vez de reintentar en silencio', () => {
    expect(fn).toContain('zipBuffer.length > TAMANO_MAX_ZIP_HD');
    expect(fn).toContain("avisarAdminEntregaHD(pedido, 'zip-grande'");
  });
  it('el aviso al admin se repite como mucho una vez por día y por motivo', () => {
    const aviso = bloqueDesde('async function avisarAdminEntregaHD(', 1500);
    expect(aviso).toContain('tocaTurnoDistribuido(`alerta-hd:${pedido?.id}:${motivo}`, 24 * 3600)');
  });
  it('borrar una foto elegida en un pedido sin pagar también pide confirmación', () => {
    const borrar = bloqueDesde("app.delete('/api/admin/fotos/:id'", 2500);
    expect(borrar).toContain(".in('estado', ['pagado', 'entregado', 'pendiente_pago'])");
  });
});

describe('auditoría 05/10: pagos', () => {
  it('un rechazo de tarjeta ("cancelado" cobrable) deja cambiar el medio de pago y vuelve a pendiente', () => {
    const fn = bloqueDesde('async function aplicarMetodoPagoPendiente(', 800);
    expect(fn).toContain(".in('estado', ESTADOS_COBRABLES)");
    expect(fn).toContain("estado: 'pendiente_pago'");
    const ruta = bloqueDesde("app.post('/api/pedidos/:id/cambiar-metodo-pago'", 3000);
    expect(ruta).toContain('!ESTADOS_COBRABLES.includes(String(pedidoActual.estado))');
  });
  it('marcarReferenciaComoPagada guarda el medio con el que se cobró de verdad', () => {
    const fn = bloqueDesde('async function marcarReferenciaComoPagada(');
    expect(fn).toContain("const metodoReal = extras.mp_payment_id ? 'mercadopago' : extras.nave_payment_id ? 'nave' : null;");
  });
  it('un pedido de un carrito de hermanos no se cobra suelto por su id', () => {
    const fn = bloqueDesde('async function obtenerPedidosPendientesParaCobro(');
    expect(fn).toContain("columna === 'id' && cobrables[0]?.grupo_pago_id");
  });
  it('la aprobación a mano de una mejora a impreso manda el correo de la mejora (no arma .zip)', () => {
    const ruta = bloqueDesde("app.post('/api/admin/pedidos/:id/estado'", 9000);
    expect(ruta).toContain('data[0].seleccion_pendiente || esPedidoAdicional(data[0])'); // 29/10: mejora o fotos extra
  });
  it('/status informa esMejora y el total del carrito incluye las filas rechazadas (cobrables)', () => {
    const ruta = bloqueDesde("app.get('/api/pedidos/:id/status'", 9000);
    expect(ruta).toContain('esMejora: esPedidoAdicional(data)'); // 29/10: mejora o fotos extra (sin .zip)
    expect(ruta).toContain('const vivasGrupo = (filasGrupo || []).filter((f: any) => !f.cancelado_definitivo);');
  });
  it('el control automático alterna el orden para cubrir toda la ventana', () => {
    const ruta = bloqueDesde("app.all('/api/cron/conciliar-pagos'", 3000);
    expect(ruta).toContain(".order('link_pago_at', { ascending: masViejosPrimero })");
  });
  it('un reintento sobre un pedido cancelado definitivo responde 409 PEDIDO_CANCELADO', () => {
    expect(fuente.split("codigo: 'PEDIDO_CANCELADO'").length - 1).toBe(3);
  });
});

describe('auditoría 05/10: selección y mejora', () => {
  it('no se aceptan más fotos sueltas que las que se cobran', () => {
    const fn = bloqueDesde('async function validarSeleccionFotos(');
    expect(fn).toContain('otrasIds.length > MAX_FOTOS_SUELTAS');
  });
  it('el nombre del kit sale del id validado', () => {
    expect(fuente).toContain("kit_nombre: NOMBRES_KITS_RESERVA[String(kitId)] || acotar(kitNombre, 120) || null");
    expect(fuente).toContain("kit_nombre: NOMBRES_KITS_RESERVA[String(item?.kitId)] || acotar(item?.kitNombre, 120) || null");
  });
  it('pasar a impreso y el UUID de /existente exigen la llave de la familia o del pedido', () => {
    const mejora = bloqueDesde("app.post('/api/pedidos/:id/mejorar-a-impreso'", 3000);
    expect(mejora).toContain("codigo: 'LLAVE_REQUERIDA'");
    // 14/10/2026: la ruta creció (llave para pagar desde otro dispositivo): se mira un tramo más largo.
    const existente = bloqueDesde("app.get('/api/pedidos/existente'", 8000);
    expect(existente).toContain('pedidoUuid: conLlave ? encontrado.id : null');
  });
});
