import { describe, expect, it } from 'vitest';
import { pedidoEstaEntregado } from '../../services/pedidosLabService';

// Pedido de Pablo (28/9): lista "Entregados" en el panel de pedidos.
describe('pedidoEstaEntregado', () => {
  const base = { estadoPago: 'aprobado' as const, kitId: 'kit-digital', emailEnviado: true, seleccionPendiente: false, estadoEntrega: 'en_laboratorio' as const };

  it('kit digital pagado con el email HD enviado', () => {
    expect(pedidoEstaEntregado(base)).toBe(true);
  });
  it('no si el email HD todavía no salió o faltan elegir las fotos', () => {
    expect(pedidoEstaEntregado({ ...base, emailEnviado: false })).toBe(false);
    expect(pedidoEstaEntregado({ ...base, seleccionPendiente: true })).toBe(false);
  });
  it('kit impreso: sólo cuando el laboratorio lo marcó retirado', () => {
    expect(pedidoEstaEntregado({ ...base, kitId: 'kit-clasico' })).toBe(false);
    expect(pedidoEstaEntregado({ ...base, kitId: 'kit-clasico', estadoEntrega: 'entregado' })).toBe(true);
  });
  it('nunca si no está pagado', () => {
    expect(pedidoEstaEntregado({ ...base, estadoPago: 'pendiente' })).toBe(false);
  });
});
