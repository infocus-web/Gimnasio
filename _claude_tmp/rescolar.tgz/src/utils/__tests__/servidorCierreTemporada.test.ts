// Auditoría 03/10 (alto 21): prueba la regla pura del cierre de temporada (analizarPedidosParaCierre
// en server.ts). server.ts no se puede importar en las pruebas (arranca Express, sharp, etc.), así que
// se extrae sólo esa función del archivo y se transpila.
import ts from 'typescript';
import { describe, expect, it } from 'vitest';
import { fuenteServidor } from '../../test/fuenteServidor';

function cargarFuncion(nombre: string): (...args: any[]) => any {
  const fuente = fuenteServidor();
  const inicio = fuente.indexOf(`function ${nombre}(`);
  if (inicio < 0) throw new Error(`No se encontró ${nombre} en server.ts`);
  const fin = fuente.indexOf('\n}\n', inicio);
  const codigo = ts.transpileModule(fuente.slice(inicio, fin + 2), { compilerOptions: { target: ts.ScriptTarget.ES2022 } }).outputText;
  // eslint-disable-next-line no-new-func
  return new Function(`${codigo}; return ${nombre};`)();
}

const analizar = cargarFuncion('analizarPedidosParaCierre');
const AHORA = Date.parse('2026-12-20T12:00:00Z');
const base = {
  familia_id: null, alumno_id: null, pedido_friendly_id: 'P1', alumno_nombre: 'Ana', tipo_kit: 'impreso_digital',
  estado_lab: null, link_descarga_hd: null, seleccion_pendiente: false, archivado: false, cancelado_definitivo: false,
  created_at: '2026-10-01T00:00:00Z', updated_at: '2026-10-01T00:00:00Z', transferencia_desde: null,
};

describe('cierre de temporada: analizarPedidosParaCierre', () => {
  it('conserva los cobrados (liquidación) y sólo borra el resto', () => {
    const r = analizar([
      { ...base, id: 'a', estado: 'pagado', estado_lab: 'entregado', link_descarga_hd: 'x' },
      { ...base, id: 'b', estado: 'cancelado' },
    ], AHORA);
    expect(r.preservar.map((p: any) => p.id)).toEqual(['a']);
    expect(r.aBorrar.map((p: any) => p.id)).toEqual(['b']);
    expect(r.pagadosSinEntregar).toHaveLength(0);
  });

  it('frena con pagados sin imprimir/entregar (impreso sin retirar, digital sin link, reserva sin fotos)', () => {
    const r = analizar([
      { ...base, id: 'imp', estado: 'pagado', estado_lab: 'listo_retiro' },
      { ...base, id: 'dig', estado: 'pagado', tipo_kit: 'solo_digital' },
      { ...base, id: 'res', estado: 'pagado', tipo_kit: 'solo_digital', link_descarga_hd: 'x', seleccion_pendiente: true },
      { ...base, id: 'ok', estado: 'pagado', tipo_kit: 'solo_digital', link_descarga_hd: 'x' },
      { ...base, id: 'arch', estado: 'pagado', archivado: true },
    ], AHORA);
    expect(r.pagadosSinEntregar.map((p: any) => p.id).sort()).toEqual(['dig', 'imp', 'res']);
  });

  // Auditoría 05/10: un Kit Impreso ya retirado pero sin .zip HD también frena; una mejora a Kit
  // Impreso (mejora_de_pedido_id) retirada no frena aunque no tenga link (el HD es del pedido original).
  it('frena con un impreso retirado sin .zip HD, pero no con una mejora retirada sin link', () => {
    const r = analizar([
      { ...base, id: 'sinzip', estado: 'pagado', estado_lab: 'entregado' },
      { ...base, id: 'conzip', estado: 'pagado', estado_lab: 'entregado', link_descarga_hd: 'x' },
      { ...base, id: 'mejora', estado: 'pagado', estado_lab: 'entregado', mejora_de_pedido_id: 'orig' },
      { ...base, id: 'mejoraPend', estado: 'pagado', estado_lab: 'listo_retiro', mejora_de_pedido_id: 'orig' },
    ], AHORA);
    expect(r.pagadosSinEntregar.map((p: any) => p.id).sort()).toEqual(['mejoraPend', 'sinzip']);
  });

  it('frena con pendientes con movimiento en las últimas 48 h, no con los viejos ni los cancelados definitivos', () => {
    const r = analizar([
      { ...base, id: 'nuevo', estado: 'pendiente_pago', updated_at: '2026-12-19T12:00:00Z' },
      { ...base, id: 'transf', estado: 'pendiente_pago', transferencia_desde: '2026-12-20T00:00:00Z' },
      { ...base, id: 'viejo', estado: 'pendiente_pago' },
      { ...base, id: 'cd', estado: 'pendiente_pago', cancelado_definitivo: true, updated_at: '2026-12-20T00:00:00Z' },
    ], AHORA);
    expect(r.pendientesRecientes.map((p: any) => p.id).sort()).toEqual(['nuevo', 'transf']);
  });
});
