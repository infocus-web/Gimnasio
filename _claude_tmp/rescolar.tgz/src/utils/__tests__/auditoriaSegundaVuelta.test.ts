import ts from 'typescript';
import { afterEach, describe, expect, it, vi } from 'vitest';
import { fuenteServidor } from '../../test/fuenteServidor';
import { firmaDeCheckout, idsParaCheckout } from '../checkoutEstable';
import { registrarFotosAdmin } from '../../services/fotosSubidasService';
import { crearReserva } from '../../services/reservasService';
import { SesionAdminVencida, armarParteZipLaboratorio, type PlanZipLab } from '../../services/zipLaboratorio';

// Auditoría 03/10 (2ª vuelta): pruebas chicas de la lógica nueva.

const server = fuenteServidor();
function extraerFuncion(nombre: string): string {
  const inicio = server.search(new RegExp(`^(async )?function ${nombre}\\b`, 'm'));
  if (inicio < 0) throw new Error(`No encontré ${nombre} en server.ts`);
  return server.slice(inicio, server.indexOf('\n}\n', inicio) + 2);
}
const fuente = ['estadoPagoNave', 'intencionNaveRevertida'].map(extraerFuncion).join('\n\n');
const js = ts.transpileModule(fuente, { compilerOptions: { target: ts.ScriptTarget.ES2020 } }).outputText;
// eslint-disable-next-line @typescript-eslint/no-implied-eval
const { estadoPagoNave, intencionNaveRevertida } = new Function(`${js}\nreturn { estadoPagoNave, intencionNaveRevertida };`)() as {
  estadoPagoNave: (p: unknown) => string;
  intencionNaveRevertida: (intentos: unknown[]) => boolean;
};

function respuesta(status: number, cuerpo: unknown): Response {
  return { ok: status >= 200 && status < 300, status, json: async () => cuerpo, headers: new Headers() } as unknown as Response;
}

afterEach(() => vi.unstubAllGlobals());

describe('estado de pagos de Nave (objeto o texto)', () => {
  it('lee status.name y status plano', () => {
    expect(estadoPagoNave({ status: { name: 'approved' } })).toBe('APPROVED');
    expect(estadoPagoNave({ status: 'APPROVED' })).toBe('APPROVED');
    expect(estadoPagoNave(null)).toBe('');
  });

  it('sólo una reversión explícita y sin aprobado marca la intención como revertida', () => {
    expect(intencionNaveRevertida([{ status: 'APPROVED' }])).toBe(false);
    expect(intencionNaveRevertida([{ status: { name: 'REFUNDED' } }])).toBe(true);
    expect(intencionNaveRevertida([{ status: 'REJECTED' }, { status: { name: 'APPROVED' } }])).toBe(false);
    expect(intencionNaveRevertida([{ status: 'ALGO_NUEVO' }])).toBe(false);
    expect(intencionNaveRevertida([])).toBe(false);
  });
});

describe('firma del checkout con el email del tutor', () => {
  it('otro email genera ids nuevos; el mismo (con mayúsculas/espacios) los reusa', () => {
    let n = 0;
    const uuid = () => `u-${++n}`;
    const a = idsParaCheckout(null, firmaDeCheckout({ kit: 'k' }, 'Mama@Mail.com '), 1, uuid, () => 'IFS');
    expect(idsParaCheckout(a, firmaDeCheckout({ kit: 'k' }, 'mama@mail.com'), 1, uuid, () => 'IFS')).toBe(a);
    expect(idsParaCheckout(a, firmaDeCheckout({ kit: 'k' }, 'papa@mail.com'), 1, uuid, () => 'IFS').pedidoId).not.toBe(a.pedidoId);
  });
});

describe('registro de fotos por tandas', () => {
  it('manda avisar y subidaDesde, y devuelve la marca de la primera tanda', async () => {
    const fetchMock = vi.fn(async () => respuesta(200, { success: true, registradas: 1, marcaSubida: '2026-10-03T10:00:00.000Z' }));
    vi.stubGlobal('fetch', fetchMock);
    const foto = { colegioId: 'c', categoria: 'individual' as const, grado: 'G', turno: 'M', division: 'A', storagePathHD: 'h', storagePathWeb: 'w' };
    const r1 = await registrarFotosAdmin([foto], { avisar: false });
    expect(r1.marcaSubida).toBe('2026-10-03T10:00:00.000Z');
    const cuerpo1 = JSON.parse(String((fetchMock.mock.calls[0] as unknown as [string, RequestInit])[1].body));
    expect(cuerpo1.avisar).toBe(false);
    expect(cuerpo1.subidaDesde).toBeUndefined();
    await registrarFotosAdmin([foto], { avisar: true, subidaDesde: r1.marcaSubida });
    const cuerpo2 = JSON.parse(String((fetchMock.mock.calls[1] as unknown as [string, RequestInit])[1].body));
    expect(cuerpo2.avisar).toBe(true);
    expect(cuerpo2.subidaDesde).toBe('2026-10-03T10:00:00.000Z');
  });
});

describe('reservas: KIT_YA_PAGADO', () => {
  it('devuelve el código y los alumnos, y reenvía confirmarOtroKit', async () => {
    const fetchMock = vi.fn(async () => respuesta(409, { success: false, codigo: 'KIT_YA_PAGADO', error: 'Ya pagado', alumnos: ['Ana'] }));
    vi.stubGlobal('fetch', fetchMock);
    const r = await crearReserva({ tutorNombre: 'T', tutorEmail: 't@m.com', metodoPago: 'mercadopago', items: [], confirmarOtroKit: true });
    expect(r.codigo).toBe('KIT_YA_PAGADO');
    expect(r.alumnos).toEqual(['Ana']);
    expect(JSON.parse(String((fetchMock.mock.calls[0] as unknown as [string, RequestInit])[1].body)).confirmarOtroKit).toBe(true);
  });
});

describe('ZIP del panel: sesión vencida', () => {
  it('un 401 corta todo con SesionAdminVencida (no genera tarjetas FALTA)', async () => {
    vi.stubGlobal('fetch', vi.fn(async () => respuesta(401, { success: false })));
    const plan: PlanZipLab = {
      partes: [[{ ruta: '15x21/A.jpg', alumno: 'A', pedido: 'P1', foto: { urlOriginalHD: '/api/admin/fotos/abc/original', tamanoImpresion: '15x21', tipo: 'individual', nombreArchivoLab: 'A.jpg' } as never }]],
      textos: [],
      pedidosIncluidos: [],
      pedidosExcluidos: [],
      totalFotos: 1,
    };
    await expect(armarParteZipLaboratorio(plan, 0)).rejects.toBeInstanceOf(SesionAdminVencida);
  });
});
