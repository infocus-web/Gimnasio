import { describe, expect, it } from 'vitest';
import { generarArchivosParaLaboratorio } from '../../services/pedidosLabService';

// Bug real (27/9): la carpeta extra se guarda como carpetasExtras + individual15x21/grupal20x30/
// docente15x21 con el mismo número, y se sumaban las dos cosas (el doble de copias en el ZIP).
const fotos = [
  { id: 'g', categoria: 'grupal', url: '/g', thumbnail: '', titulo: 'g' },
  { id: 'i', categoria: 'individual', url: '/i', thumbnail: '', titulo: 'i' },
  { id: 'd', categoria: 'docente', url: '/d', thumbnail: '', titulo: 'd' },
] as any;
const seleccion = { grupalId: 'g', individualId: 'i', docenteId: 'd' };

describe('generarArchivosParaLaboratorio', () => {
  it('una carpeta extra suma exactamente un juego más (3 fotos), no dos', () => {
    const archivos = generarArchivosParaLaboratorio('GRADO1-ATM', 1, 'Ana Perez', seleccion, { carpetasExtras: 1, individual15x21: 1, grupal20x30: 1, docente15x21: 1, otras15x21: 0 }, fotos);
    expect(archivos).toHaveLength(6);
    expect(archivos.filter((a) => a.tamanoImpresion === '20x30')).toHaveLength(2);
    expect(archivos.filter((a) => a.tamanoImpresion === '15x21')).toHaveLength(4);
  });

  it('sin carpeta extra, una copia suelta 15x21 se suma una sola vez', () => {
    const archivos = generarArchivosParaLaboratorio('GRADO1-ATM', 1, 'Ana Perez', seleccion, { individual15x21: 1 }, fotos);
    expect(archivos).toHaveLength(4);
  });
});
