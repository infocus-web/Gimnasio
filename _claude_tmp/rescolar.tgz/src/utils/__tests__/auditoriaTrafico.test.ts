import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { firmaDeCheckout, idsParaCheckout } from '../checkoutEstable';
import { ErrorTiempoAgotado, fetchConTimeout } from '../fetchConTimeout';
import { registrarFallaDePago, reiniciarReportesAutomaticos } from '../../services/reporteErrores';
import {
  CODIGO_KIT_YA_PAGADO,
  nombresAlumnosDeRespuesta,
  recortarPedidosParaStorage,
  registrarPedidoDesdePortal,
  type PedidoEscolarCompleto,
} from '../../services/pedidosLabService';
import { consultarPedidoExistente } from '../../services/verificacionesCompraService';
import { obtenerEstadoReserva } from '../../services/reservasService';
import { obtenerGaleriaPublica } from '../../services/fotosSubidasService';
import { buscarMiInscripcion } from '../../services/inscripcionesService';

// Auditoría de tráfico 03/10: frontend de familias con red mala.

function respuesta(status: number, cuerpo: unknown): Response {
  return { ok: status >= 200 && status < 300, status, json: async () => cuerpo } as Response;
}

describe('ids estables por checkout (crítico 2)', () => {
  let n = 0;
  const uuid = () => `uuid-${++n}`;
  const numero = () => `IFS-2026-${1000 + n}`;

  it('reusa los mismos ids mientras no cambie la selección', () => {
    const firma = firmaDeCheckout({ kit: 'kit-clasico', fotos: ['a', 'b', 'c'] });
    const primero = idsParaCheckout(null, firma, 1, uuid, numero);
    const reintento = idsParaCheckout(primero, firmaDeCheckout({ kit: 'kit-clasico', fotos: ['a', 'b', 'c'] }), 1, uuid, numero);
    expect(reintento).toBe(primero);
    expect(reintento.pedidoId).toBe(primero.itemIds[0]);
  });

  it('genera ids nuevos si cambia el kit o la cantidad de hijos', () => {
    const primero = idsParaCheckout(null, firmaDeCheckout({ kit: 'kit-clasico' }), 1, uuid, numero);
    const otroKit = idsParaCheckout(primero, firmaDeCheckout({ kit: 'kit-digital' }), 1, uuid, numero);
    expect(otroKit.pedidoId).not.toBe(primero.pedidoId);
    const dosHijos = idsParaCheckout(otroKit, otroKit.firma, 2, uuid, numero);
    expect(dosHijos.itemIds).toHaveLength(2);
    expect(new Set(dosHijos.itemIds).size).toBe(2);
  });

  it('los ids de las reservas (pago anticipado) también se reusan en el reintento', () => {
    let n = 0;
    const uuid = () => `r-${++n}`;
    const primero = idsParaCheckout(null, firmaDeCheckout({ reservas: ['h1', 'h2'] }), 0, uuid, () => 'IFS-2026-0001', 2);
    expect(primero.reservaIds).toHaveLength(2);
    expect(new Set(primero.reservaIds).size).toBe(2);
    const reintento = idsParaCheckout(primero, primero.firma, 0, uuid, () => 'IFS-2026-0001', 2);
    expect(reintento.reservaIds).toEqual(primero.reservaIds);
    const otra = idsParaCheckout(primero, firmaDeCheckout({ reservas: ['h1'] }), 0, uuid, () => 'IFS-2026-0001', 1);
    expect(otra.reservaIds[0]).not.toBe(primero.reservaIds[0]);
  });
});

describe('fetchConTimeout (alto 22)', () => {
  afterEach(() => vi.useRealTimers());

  it('corta el pedido colgado con un error claro', async () => {
    vi.useFakeTimers();
    vi.stubGlobal(
      'fetch',
      vi.fn((_url: RequestInfo | URL, init?: RequestInit) =>
        new Promise<Response>((_resolve, reject) => {
          init?.signal?.addEventListener('abort', () => reject(new DOMException('aborted', 'AbortError')));
        })
      )
    );
    const promesa = fetchConTimeout('/api/lento', {}, 1000);
    const verificacion = expect(promesa).rejects.toBeInstanceOf(ErrorTiempoAgotado);
    await vi.advanceTimersByTimeAsync(1001);
    await verificacion;
  });
});

describe('consultas de "ya pagaste" que fallan (alto 6)', () => {
  it('un 429 o 5xx de /api/pedidos/existente NO es "no hay pedido"', async () => {
    vi.stubGlobal('fetch', vi.fn(async () => respuesta(429, { success: false })));
    const r1 = await consultarPedidoExistente({ codigo: 'X', alumnoNombre: 'Ana' });
    expect(r1.ok).toBe(false);
    vi.stubGlobal('fetch', vi.fn(async () => respuesta(503, { success: false })));
    expect((await consultarPedidoExistente({ codigo: 'X', alumnoNombre: 'Ana' })).ok).toBe(false);
    vi.stubGlobal('fetch', vi.fn(async () => respuesta(200, { success: true, existe: false })));
    expect(await consultarPedidoExistente({ codigo: 'X', alumnoNombre: 'Ana' })).toEqual({ ok: true, pedido: null });
  });

  it('la reserva marca la falla pasajera', async () => {
    vi.stubGlobal('fetch', vi.fn(async () => { throw new TypeError('Failed to fetch'); }));
    const estado = await obtenerEstadoReserva('X', 'Ana');
    expect(estado.falloTransitorio).toBe(true);
  });
});

describe('galería y código (altos 22 y 23)', () => {
  it('distingue código vencido, error y curso sin fotos', async () => {
    vi.stubGlobal('fetch', vi.fn(async () => respuesta(401, { success: false, error: 'Código de acceso incorrecto o vencido' })));
    expect((await obtenerGaleriaPublica({ codigo: 'X' })).estado).toBe('codigo_invalido');
    vi.stubGlobal('fetch', vi.fn(async () => respuesta(500, { success: false })));
    expect((await obtenerGaleriaPublica({ codigo: 'X' })).estado).toBe('error');
    vi.stubGlobal('fetch', vi.fn(async () => respuesta(200, { success: true, fotos: [], seccion: null })));
    expect((await obtenerGaleriaPublica({ codigo: 'X' })).estado).toBe('vacia');
  });

  it('un 429 al validar el código no se muestra como "código no encontrado"', async () => {
    vi.stubGlobal('fetch', vi.fn(async () => respuesta(429, { success: false })));
    const r = await buscarMiInscripcion('ABCD-1234', 'Ana Pérez', '30111222');
    expect(r.limiteAlcanzado).toBe(true);
    expect(r.errorConexion).toMatch(/demasiados intentos/i);
  });
});

describe('crear pedido (crítico 2 y alto 8)', () => {
  const params = {
    colegioId: 'c1',
    colegioNombre: 'Colegio',
    cursoCodigo: 'GRADO1-A',
    grado: '1°',
    division: 'A',
    turno: 'Mañana',
    alumnoNombre: 'Ana Pérez',
    tutorNombre: 'Tutor',
    tutorTelefono: '11',
    tutorEmail: 't@x.com',
    kitId: 'kit-clasico',
    kitNombre: 'Kit',
    total: 1,
    metodoPago: 'mercadopago' as const,
    fotosSeleccionadas: { individualId: 'i', grupalId: 'g', docenteId: 'd' },
  };

  it('manda el id estable y no guarda el pedido si el servidor no lo confirmó', async () => {
    const fetchMock = vi.fn(async () => respuesta(500, { success: false, error: 'caído' }));
    vi.stubGlobal('fetch', fetchMock);
    const r = await registrarPedidoDesdePortal({ ...params, pedidoId: '11111111-1111-4111-8111-111111111111', pedidoFriendlyId: 'IFS-2026-1234' });
    expect(r.sincronizado).toBe(false);
    const cuerpo = JSON.parse(String((fetchMock.mock.calls[0] as unknown as [string, RequestInit])[1].body));
    expect(cuerpo.pedidoId).toBe('11111111-1111-4111-8111-111111111111');
    expect(cuerpo.pedidoFriendlyId).toBe('IFS-2026-1234');
    expect(localStorage.getItem('infocus_pedidos_escolares_v1')).toBeNull();
  });

  it('devuelve KIT_YA_PAGADO con los alumnos y reenvía confirmarOtroKit', async () => {
    const fetchMock = vi.fn(async () => respuesta(409, { success: false, codigo: 'KIT_YA_PAGADO', error: 'Ya pagado', alumnos: ['Ana Pérez'] }));
    vi.stubGlobal('fetch', fetchMock);
    const r = await registrarPedidoDesdePortal({ ...params, confirmarOtroKit: true });
    expect(r.codigo).toBe(CODIGO_KIT_YA_PAGADO);
    expect(r.alumnos).toEqual(['Ana Pérez']);
    expect(JSON.parse(String((fetchMock.mock.calls[0] as unknown as [string, RequestInit])[1].body)).confirmarOtroKit).toBe(true);
    expect(nombresAlumnosDeRespuesta([{ alumnoNombre: 'Leo' }, 'Sofi', null])).toEqual(['Leo', 'Sofi']);
  });

  it('el localStorage de pedidos tiene tope y sólo el más reciente (y su mismo pago) guarda los archivos', () => {
    const muchos = Array.from({ length: 30 }, (_, i) => ({ id: `P${i}`, grupoPagoId: i < 2 ? 'g1' : undefined, archivosParaLaboratorio: [{}] }) as unknown as PedidoEscolarCompleto);
    const recortados = recortarPedidosParaStorage(muchos);
    expect(recortados).toHaveLength(20);
    expect(recortados[0].archivosParaLaboratorio).toHaveLength(1);
    expect(recortados[1].archivosParaLaboratorio).toHaveLength(1);
    expect(recortados[2].archivosParaLaboratorio).toEqual([]);
  });
});

describe('registrarFallaDePago (medio)', () => {
  beforeEach(() => reiniciarReportesAutomaticos());

  it('una vez por pedido + motivo (sin importar números) y con tope por visita', async () => {
    const fetchMock = vi.fn(async () => respuesta(201, { success: true, codigo: 'ERR-1' }));
    vi.stubGlobal('fetch', fetchMock);
    registrarFallaDePago('portal', 'Error HTTP 500 al crear', { pedido: 'p1' });
    registrarFallaDePago('portal', 'Error HTTP 502 al crear', { pedido: 'p1' });
    expect(fetchMock).toHaveBeenCalledTimes(1);
    registrarFallaDePago('portal', 'Error HTTP 500 al crear', { pedido: 'p2' });
    expect(fetchMock).toHaveBeenCalledTimes(2);
    for (let i = 0; i < 10; i++) registrarFallaDePago('portal', `Motivo ${'x'.repeat(i)}`, { pedido: 'p3' });
    expect(fetchMock).toHaveBeenCalledTimes(5);
  });
});
