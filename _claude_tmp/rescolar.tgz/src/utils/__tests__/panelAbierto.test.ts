// 20/10/2026: al recargar la página, el panel se reabre solo si estaba abierto y hay sesión guardada.
import { beforeEach, describe, expect, it } from 'vitest';
import { panelQuedoAbierto, recordarPanelAbierto } from '../panelAbierto';

beforeEach(() => {
  sessionStorage.clear();
  localStorage.clear();
});

describe('panelAbierto', () => {
  it('se reabre sólo si estaba abierto y hay sesión del panel', () => {
    recordarPanelAbierto(true);
    expect(panelQuedoAbierto()).toBe(false); // sin sesión guardada
    localStorage.setItem('infocus_admin_session_token', 'token');
    expect(panelQuedoAbierto()).toBe(true);
  });

  it('al cerrar el panel ya no se reabre', () => {
    localStorage.setItem('infocus_admin_session_token', 'token');
    recordarPanelAbierto(true);
    recordarPanelAbierto(false);
    expect(panelQuedoAbierto()).toBe(false);
  });
});
