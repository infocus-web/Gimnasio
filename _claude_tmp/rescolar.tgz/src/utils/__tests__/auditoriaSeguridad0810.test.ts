import { readFileSync } from 'fs';
import path from 'path';
import ts from 'typescript';
import { describe, expect, it } from 'vitest';

import { fuenteServidor } from '../../test/fuenteServidor';
import { calcularRegion } from '../../../lupa/recorte';

// 08/10/2026: auditoría de seguridad (claude/auditoria-seguridad-2026-10-08.md), primera tanda:
// A1 lupa, A2 primer ingreso sin DNI, A3 individuales sin nombre, M3 inscripciones rechazadas,
// M5 nombres parecidos en reservas/mejora/pedido existente, M6 rechazo sobre pedidos entregados.
// server.ts no se puede importar en las pruebas (arranca el servidor): se extraen las funciones y se
// verifica el texto de las rutas, como en unicos0810.test.ts.
const raiz = path.resolve(__dirname, '../../..');
const leer = (archivo: string) => readFileSync(path.join(raiz, archivo), 'utf8').replace(/\r\n/g, '\n');
const server = fuenteServidor();
const eventos = leer('eventos/servidor.ts');

function extraerFuncion(nombre: string): string {
  const inicio = server.search(new RegExp(`^(async )?function ${nombre}\\b`, 'm'));
  if (inicio < 0) throw new Error(`No encontré ${nombre} en server.ts`);
  const fin = server.indexOf('\n}\n', inicio);
  return server.slice(inicio, fin + 2);
}

function cargar<T>(nombres: string[]): T {
  // 11/10: etiquetasDelAlumno usa además la lista de partículas (constante de nombres.ts).
  const fuente = [server.match(/^const PARTICULAS_NOMBRE = .*$/m)?.[0] ?? '', ...nombres.map(extraerFuncion)].join('\n\n');
  const js = ts.transpileModule(fuente, { compilerOptions: { target: ts.ScriptTarget.ES2020 } }).outputText;
  // eslint-disable-next-line @typescript-eslint/no-implied-eval
  return new Function(`${js}\nreturn { ${nombres.join(', ')} };`)() as T;
}

function bloqueDesde(inicio: string, largo: number): string {
  const a = server.indexOf(inicio);
  if (a < 0) throw new Error(`No encontré ${inicio}`);
  return server.slice(a, a + largo);
}

const { hijosQueSonElAlumno } = cargar<{
  hijosQueSonElAlumno: (sb: any, familiaId: unknown, hijos: string[] | null, alumno: unknown, colegioId: string, cursoCodigo: string) => Promise<string[]>;
}>([
  'normalizarNombreComparable',
  'normalizarNombrePorPalabras',
  'puntajeNombres',
  'nombresCompatibles',
  'puntajeEtiqueta',
  'etiquetasDelAlumno',
  'determinarCodigoCursoServidor',
  'hijosQueSonElAlumno',
]);

const CURSO = 'GRADO3-ATM';
function supabaseConInscripciones(filas: any[] | null, falla = false) {
  return {
    from: () => ({
      select: () => ({
        eq: () => ({
          limit: async () => (falla ? { data: null, error: new Error('caída') } : { data: filas, error: null }),
        }),
      }),
    }),
  };
}
const fila = (id: string, nombre: string, apellido: string) => ({ id, alumno_nombre: nombre, alumno_apellido: apellido, grado: '3° Grado', turno: 'Mañana', division: 'A', hermanos: [] });

describe('M5: la llave de una familia no sirve para el pedido de un chico de nombre parecido', () => {
  it('el curso calculado en la prueba es el esperado', () => {
    const { determinarCodigoCursoServidor } = cargar<any>(['determinarCodigoCursoServidor']);
    expect(determinarCodigoCursoServidor('3° Grado', 'Mañana', 'A')).toBe(CURSO);
  });

  it('mismo nombre: vale sin mirar el curso', async () => {
    const sb = supabaseConInscripciones(null, true);
    expect(await hijosQueSonElAlumno(sb, 'fam-1', ['Juan Pérez'], 'juan perez', 'col', CURSO)).toEqual(['Juan Pérez']);
  });

  it('"Juan Pérez" NO llega a la reserva de "Juan Ignacio Pérez" si ese chico está inscripto en el curso', async () => {
    const sb = supabaseConInscripciones([fila('fam-1', 'Juan', 'Pérez'), fila('fam-2', 'Juan Ignacio', 'Pérez')]);
    expect(await hijosQueSonElAlumno(sb, 'fam-1', ['Juan Pérez'], 'Juan Ignacio Pérez', 'col', CURSO)).toEqual([]);
  });

  // 11/10 (FAM-1 + revisión): una palabra de más en cualquiera de los dos lados sigue valiendo (segundo nombre).
  it('compatible y sin otro chico parecido en el curso: vale (segundo nombre de más en la reserva o en el hijo)', async () => {
    const sb = supabaseConInscripciones([fila('fam-1', 'Juan', 'Pérez'), fila('fam-3', 'Ana', 'Gómez')]);
    expect(await hijosQueSonElAlumno(sb, 'fam-1', ['Juan Pérez'], 'Juan Ignacio Pérez', 'col', CURSO)).toEqual(['Juan Pérez']);
    expect(await hijosQueSonElAlumno(sb, 'fam-1', ['Juan Ignacio Pérez'], 'Juan Pérez', 'col', CURSO)).toEqual(['Juan Ignacio Pérez']);
  });

  it('un hermano inscripto en la fila de otra familia también cuenta', async () => {
    const otra = { ...fila('fam-2', 'Ana', 'Gómez'), hermanos: [{ alumnoNombre: 'Juan Ignacio', alumnoApellido: 'Pérez', grado: '3° Grado', turno: 'Mañana', division: 'A' }] };
    const sb = supabaseConInscripciones([fila('fam-1', 'Juan', 'Pérez'), otra]);
    expect(await hijosQueSonElAlumno(sb, 'fam-1', ['Juan Pérez'], 'Juan Ignacio Pérez', 'col', CURSO)).toEqual([]);
  });

  it('si la base falla, sólo valen las coincidencias exactas (falla cerrado)', async () => {
    const sb = supabaseConInscripciones(null, true);
    expect(await hijosQueSonElAlumno(sb, 'fam-1', ['Juan Pérez'], 'Juan Ignacio Pérez', 'col', CURSO)).toEqual([]);
  });

  it('sin llave no hay hijos', async () => {
    expect(await hijosQueSonElAlumno(supabaseConInscripciones([]), 'x', null, 'Juan Pérez', 'col', CURSO)).toEqual([]);
  });

  it('las 4 rutas usan la comparación nueva', () => {
    expect(server.match(/hijosQueSonElAlumno\(supabase,/g)?.length).toBe(6); // 22/10: + pedidos de foto faltante; 29/10: + fotos extra
    expect(server).not.toMatch(/nombresCompatibles\(n, (pedido|original)\.alumno_nombre\)/);
    expect(server).not.toMatch(/nombresCompatibles\(n, alumnoNombre\)/);
  });
});

describe('A1: lupa', () => {
  it('el pedacito no pasa el 80 % del lado corto: ya no alcanzan 2 pedidos para una apaisada', () => {
    const fuente = { ancho: 800, alto: 533 };
    const r = calcularRegion(fuente, { cx: 0, cy: 0.5, s: 0.75 });
    expect(r.ancho).toBe(426);
    expect(2 * r.ancho).toBeLessThan(fuente.ancho + 60);
    const vertical = calcularRegion({ ancho: 533, alto: 800 }, { cx: 0.5, cy: 0.5, s: 0.75 });
    expect(vertical.ancho).toBe(400);
  });

  it('las dos lupas tienen además un tope persistente por hora (09/10: sin hacer esperar el pedido)', () => {
    expect(server).toContain("limitarFrecuenciaPersistenteSinEspera('fotos-lupa-hora', 2000, 60 * 60 * 1000)");
    expect(eventos).toContain("limitarPersistenteSinEspera('ev-lupa-hora', 2000, 60 * 60 * 1000)");
  });
});

describe('A2 + M3: ingreso de familias', () => {
  const buscar = bloqueDesde("app.post('/api/inscripciones/buscar'", 9000);
  it('el primer ingreso sin DNI ya no fija el DNI escrito: manda el link al email', () => {
    expect(buscar).not.toContain('.update({ padre_dni: dniInput })');
    expect(buscar).toContain('respuestaFaltaConfirmar(supabase, porNombre[0], { primerIngreso: true })');
  });

  it('sólo entran inscripciones aceptadas', () => {
    expect(buscar).toContain("const aceptadas = candidatos.filter((c: any) => c.estado === 'aceptado');");
    expect(buscar).toContain('let match = aceptadas.find(');
    expect(buscar).toContain('let porNombre = aceptadas.filter(');
    expect(buscar).toContain('porNombre = aceptadas.filter((c: any) => !c.padre_dni && contiene(c));');
    expect(extraerFuncion('hijosDeFamiliaConAcceso')).toContain("if (data.estado !== 'aceptado') return null;");
  });

  it('confirmar-acceso fija el DNI sólo si la fila no tenía (update condicional)', () => {
    const confirmar = bloqueDesde("app.post('/api/inscripciones/confirmar-acceso'", 4000);
    expect(confirmar).toMatch(/update\(\{ padre_dni: dniEscrito[\s\S]*?\.is\('padre_dni', null\)/);
  });

  it('el email de primer ingreso tiene su propio texto', () => {
    expect(server).toContain('Para tu primer ingreso, confirmá que sos vos.');
  });
});

// 11/10 (Pablo, «opción 3»): las individuales se suben por curso, sin nombre. Una individual SIN nombre la ve,
// amplía y compra todo el curso; una CON nombre sigue siendo sólo de su familia. Prueba de comportamiento en
// src/test/auditoria1110/familias/familias.test.ts («individuales sin nombre»).
describe('individuales sin nombre (11/10)', () => {
  it('ya no las frenan galería, lupa, compra, reservas ni «Publicar»', () => {
    expect(server).toContain("(f: any) => f.categoria !== 'individual' || !f.alumno_nombre || clavesVisibles.has(");
    expect(server).not.toContain("if (foto.categoria === 'individual' && !foto.alumno_nombre) return null;");
    expect(server).toContain("f.categoria === 'individual' && f.alumno_nombre && !esDelAlumno(f.alumno_nombre)"); // 22/10
    expect(server).not.toContain('if (individualElegida && !individualElegida.alumno_nombre) {');
    expect(server).not.toContain('individualSinNombre');
  });
});

describe('M6: un aviso de rechazo sólo cancela pedidos pendientes', () => {
  it('ninguna cancelación por rechazo usa .neq(estado, pagado)', () => {
    expect(server).not.toContain(".neq('estado', 'pagado')");
    const cancelaciones = server.match(/\.eq\('estado', 'pendiente_pago'\) \/\/ Auditoría 08\/10 \(M6\)[^\n]*\n\s*\.eq\('cancelado_definitivo', false\)/g) || [];
    expect(cancelaciones.length).toBe(5);
  });
});
