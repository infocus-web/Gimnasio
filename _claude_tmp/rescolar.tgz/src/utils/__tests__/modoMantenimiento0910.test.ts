import path from 'path';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { fuenteServidor } from '../../test/fuenteServidor';
import {
  COOKIE_MANTENIMIENTO,
  crearLlaveMantenimiento,
  leerCookie,
  llaveMantenimientoValida,
  paginaMantenimiento,
  rutaLibreEnMantenimiento,
  TEXTO_MANTENIMIENTO,
} from '../../../mantenimiento/llave';

// 09/10/2026: modo mantenimiento (pedido de Pablo). La pantalla la arma middleware.ts; la llave que deja
// pasar a Pablo la firma el servidor (mantenimiento/llave.ts, Web Crypto en los dos lados).
const server = fuenteServidor();

describe('llave de mantenimiento', () => {
  it('la que arma el servidor es válida 24 h y después no', async () => {
    const ahora = Date.UTC(2026, 9, 9, 5, 0, 0);
    const llave = await crearLlaveMantenimiento('secreto-de-prueba', ahora);
    expect(await llaveMantenimientoValida('secreto-de-prueba', llave, ahora)).toBe(true);
    expect(await llaveMantenimientoValida('secreto-de-prueba', llave, ahora + 23 * 3600 * 1000)).toBe(true);
    expect(await llaveMantenimientoValida('secreto-de-prueba', llave, ahora + 25 * 3600 * 1000)).toBe(false);
  });

  it('con otro secreto, alterada, sin secreto o con vencimiento inventado no vale', async () => {
    const ahora = Date.now();
    const llave = await crearLlaveMantenimiento('secreto-de-prueba', ahora);
    expect(await llaveMantenimientoValida('otro-secreto', llave, ahora)).toBe(false);
    expect(await llaveMantenimientoValida('secreto-de-prueba', llave.slice(0, -2) + 'xx', ahora)).toBe(false);
    expect(await llaveMantenimientoValida(null, llave, ahora)).toBe(false);
    expect(await llaveMantenimientoValida('secreto-de-prueba', null, ahora)).toBe(false);
    const [, firma] = llave.split('.');
    const lejana = `${Math.floor(ahora / 1000) + 30 * 24 * 3600}.${firma}`;
    expect(await llaveMantenimientoValida('secreto-de-prueba', lejana, ahora)).toBe(false);
  });

  it('lee la cookie entre otras', () => {
    expect(leerCookie(`a=1; ${COOKIE_MANTENIMIENTO}=123.abc; b=2`, COOKIE_MANTENIMIENTO)).toBe('123.abc');
    expect(leerCookie('a=1', COOKIE_MANTENIMIENTO)).toBeNull();
    expect(leerCookie(null, COOKIE_MANTENIMIENTO)).toBeNull();
  });
});

describe('rutas que siguen andando durante el mantenimiento', () => {
  it('avisos de pago, correo entrante, tareas automáticas e ingreso de Pablo', () => {
    for (const p of [
      '/api/mercadopago/webhook',
      '/mercadopago/webhook',
      '/api/nave/webhook',
      '/api/nave/webhook-sandbox',
      '/api/eventos/webhook-mp',
      '/api/webhooks/resend-inbound',
      '/api/cron/conciliar-pagos',
      '/api/cron/reintentar-hd',
      '/api/mantenimiento/acceso',
    ]) {
      expect(rutaLibreEnMantenimiento(p)).toBe(true);
    }
  });

  it('todo lo demás queda en mantenimiento (también el panel y la compra)', () => {
    for (const p of ['/', '/eventos', '/laboratorio', '/padron.html', '/api/fotos', '/api/pedidos/crear', '/api/admin/login', '/api/mercadopago/crear-preferencia', '/api/cronica']) {
      expect(rutaLibreEnMantenimiento(p)).toBe(false);
    }
  });

  it('las rutas libres coinciden con las que existen en el servidor', () => {
    for (const ruta of ["'/api/mercadopago/webhook'", "'/api/nave/webhook'", "'/api/webhooks/resend-inbound'", "'/api/mantenimiento/acceso'"]) {
      expect(server).toContain(ruta);
    }
  });
});

describe('pantalla de mantenimiento', () => {
  it('tiene el texto de Pablo, el ingreso del fotógrafo y ningún script', () => {
    const html = paginaMantenimiento();
    expect(html).toContain(TEXTO_MANTENIMIENTO);
    expect(TEXTO_MANTENIMIENTO).toBe('Estamos realizando mantenimiento a la plataforma, en unas horas estará nuevamente online');
    expect(html).toContain('action="/api/mantenimiento/acceso"');
    // 09/10: el acceso dice «Administrador» y va en la esquina de abajo a la derecha.
    expect(html).toContain('<summary>Administrador</summary>');
    expect(html).toContain('position:fixed;right:16px;bottom:14px');
    expect(html).not.toMatch(/<script/i);
    expect(paginaMantenimiento('pin')).toContain('PIN incorrecto');
  });
});

describe('middleware', () => {
  const fetchReal = globalThis.fetch;
  let valor = 'activo';
  let falla = false;
  beforeEach(() => {
    valor = 'activo';
    falla = false;
    vi.stubEnv('ADMIN_SESSION_SECRET', 'secreto-de-prueba');
    globalThis.fetch = vi.fn(async () => {
      if (falla) throw new Error('sin base');
      return new Response(JSON.stringify([{ valor }]), { status: 200 });
    }) as any;
  });
  afterEach(() => {
    globalThis.fetch = fetchReal;
    vi.unstubAllEnvs();
    vi.resetModules();
  });
  const cargar = async () => (await import('../../../middleware')).default;

  it('prendido: la portada muestra el cartel (503) y /api responde 503 en JSON', async () => {
    const middleware = await cargar();
    const pagina = await middleware(new Request('https://www.retratoescolar.com.ar/'));
    expect(pagina.status).toBe(503);
    expect(await pagina.text()).toContain(TEXTO_MANTENIMIENTO);
    const api = await middleware(new Request('https://www.retratoescolar.com.ar/api/fotos?codigo=X'));
    expect(api.status).toBe(503);
    expect((await api.json()).mantenimiento).toBe(true);
  });

  it('prendido: el webhook de Mercado Pago pasa igual', async () => {
    const middleware = await cargar();
    const r = await middleware(new Request('https://www.retratoescolar.com.ar/api/mercadopago/webhook', { method: 'POST' }));
    expect(r.headers.get('x-middleware-next')).toBe('1');
  });

  it('prendido: con la llave de Pablo pasa', async () => {
    const middleware = await cargar();
    const llave = await crearLlaveMantenimiento('secreto-de-prueba');
    const r = await middleware(new Request('https://www.retratoescolar.com.ar/', { headers: { cookie: `${COOKIE_MANTENIMIENTO}=${llave}` } }));
    expect(r.headers.get('x-middleware-next')).toBe('1');
  });

  it('apagado, o si la base no responde: la web anda normal', async () => {
    valor = 'inactivo';
    let middleware = await cargar();
    expect((await middleware(new Request('https://www.retratoescolar.com.ar/'))).headers.get('x-middleware-next')).toBe('1');
    vi.resetModules();
    falla = true;
    middleware = await cargar();
    expect((await middleware(new Request('https://www.retratoescolar.com.ar/'))).headers.get('x-middleware-next')).toBe('1');
  });
});

describe('servidor', () => {
  it('el ingreso comparte el tope del login del panel y la cookie es HttpOnly + Secure', () => {
    const bloque = server.slice(server.indexOf("app.post('/api/mantenimiento/acceso'"), server.indexOf("app.post('/api/mantenimiento/acceso'") + 1200);
    expect(bloque).toContain("hayCupoPorClave(`admin-login:${req.ip || 'desconocida'}`, 8, 15 * 60)");
    expect(bloque).toContain('HttpOnly; Secure; SameSite=Lax');
  });
  it('el interruptor del panel exige sesión de admin', () => {
    expect(server).toContain("app.get('/api/admin/mantenimiento', requireAdminAuth,");
    expect(server).toContain("app.post('/api/admin/mantenimiento', requireAdminAuth,");
  });
});
