// 14/10/2026: ids del checkout guardados en la pestaña (recarga sin pedido duplicado) y confirmación de
// las fotos de una reserva que se corta (se reintenta una vez; «ya fueron elegidas» = ya se guardó).
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { borrarCheckoutDeSesion, firmaDeCheckout, guardarCheckoutEnSesion, idsParaCheckout, leerCheckoutDeSesion } from '../checkoutEstable';
import { elegirFotosDeReserva } from '../../services/reservasService';

describe('checkout guardado en sessionStorage', () => {
  beforeEach(() => sessionStorage.clear());
  let n = 0;
  const uuid = () => `uuid-${++n}`;
  const numero = () => `IFS-2026-${1000 + n}`;

  it('misma compra → mismos ids y clave; otra compra u otro email → nada', () => {
    const firma = firmaDeCheckout({ hijo: 'principal', kit: 'kit-clasico' }, 'Mama@Prueba.test');
    const ids = idsParaCheckout(null, firma, 2, uuid, numero, 1);
    guardarCheckoutEnSesion(ids);
    const crudo = sessionStorage.getItem('retrato_checkout_en_curso') || '';
    expect(crudo).not.toContain('mama@prueba.test'); // la firma (con el email) no se guarda
    expect(leerCheckoutDeSesion(firma)).toEqual(ids);
    expect(idsParaCheckout(leerCheckoutDeSesion(firma), firma, 2, uuid, numero, 1)).toEqual(ids);
    expect(leerCheckoutDeSesion(firmaDeCheckout({ hijo: 'principal', kit: 'kit-digital' }, 'mama@prueba.test'))).toBeNull();
    expect(leerCheckoutDeSesion(firmaDeCheckout({ hijo: 'principal', kit: 'kit-clasico' }, 'papa@prueba.test'))).toBeNull();
    borrarCheckoutDeSesion();
    expect(leerCheckoutDeSesion(firma)).toBeNull();
  });

  it('sin almacenamiento disponible no rompe (vuelve a sólo memoria)', () => {
    const espia = vi.spyOn(Storage.prototype, 'setItem').mockImplementation(() => {
      throw new Error('bloqueado');
    });
    const firma = firmaDeCheckout({ a: 1 }, 'x@y.z');
    expect(() => guardarCheckoutEnSesion(idsParaCheckout(null, firma, 1, uuid, numero))).not.toThrow();
    espia.mockRestore();
    expect(leerCheckoutDeSesion(firma)).toBeNull();
  });
});

describe('elegirFotosDeReserva: corte de conexión', () => {
  afterEach(() => vi.unstubAllGlobals());

  it('si la primera respuesta se pierde, reintenta una vez y «ya fueron elegidas» vuelve al portal (lo toma como éxito)', async () => {
    const fetchFalso = vi
      .fn()
      .mockRejectedValueOnce(new TypeError('Failed to fetch'))
      .mockResolvedValueOnce(new Response(JSON.stringify({ success: false, error: 'Las fotos de este kit ya fueron elegidas.' }), { status: 409 }));
    vi.stubGlobal('fetch', fetchFalso);
    const r = await elegirFotosDeReserva('reserva-1', 'AB12-CD34', { grupalId: 'g', individualId: 'i', docenteId: 'd' }, true);
    expect(fetchFalso).toHaveBeenCalledTimes(2);
    expect(r.success).toBe(false);
    expect(r.error).toMatch(/ya fueron elegidas/i);
  });

  it('si los dos intentos fallan, avisa error de conexión (sin tercer intento)', async () => {
    const fetchFalso = vi.fn().mockRejectedValue(new TypeError('Failed to fetch'));
    vi.stubGlobal('fetch', fetchFalso);
    const r = await elegirFotosDeReserva('reserva-1', 'AB12-CD34', { grupalId: 'g', individualId: 'i', docenteId: 'd' }, true);
    expect(fetchFalso).toHaveBeenCalledTimes(2);
    expect(r).toMatchObject({ success: false, error: expect.stringMatching(/conexión/i) });
  });
});
