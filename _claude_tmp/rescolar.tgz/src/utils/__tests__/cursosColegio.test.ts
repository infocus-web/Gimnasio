// 12/10/2026: el formulario de inscripción ofrece sólo los cursos que existen en la nómina del grado.
import { describe, expect, it } from 'vitest';
import { etiquetaDivision, opcionesDeCurso, type CursoColegio } from '../cursosColegio';

const JE = 'Jornada Extendida / Completa';
const BASE = { divisiones: ['A', 'B', 'C', 'Jornada Extendida'], turnos: ['Mañana', 'Tarde', JE] };
const CURSOS: CursoColegio[] = [
  { grado: 'Sala 4 años', division: 'A', turno: JE },
  { grado: 'Sala 4 años', division: 'A', turno: 'Mañana' },
  { grado: 'Sala 4 años', division: 'B', turno: 'Tarde' },
  { grado: 'Sala 4 años', division: 'C', turno: JE },
  { grado: 'Sala 4 años', division: 'C', turno: 'Tarde' },
  { grado: '5° grado', division: 'Jornada Extendida', turno: JE },
  { grado: '5° grado', division: 'A', turno: 'Mañana' },
  { grado: '1° año', division: 'B', turno: null },
];

describe('opcionesDeCurso', () => {
  it('Sala 4: sin la división «Jornada Extendida» (ahí es un turno)', () => {
    expect(opcionesDeCurso(CURSOS, BASE, 'Sala 4 años', '').divisiones).toEqual(['A', 'B', 'C']);
  });
  it('los turnos dependen de la división elegida', () => {
    expect(opcionesDeCurso(CURSOS, BASE, 'Sala 4 años', 'A').turnos).toEqual(['Mañana', JE]);
    expect(opcionesDeCurso(CURSOS, BASE, 'Sala 4 años', 'B').turnos).toEqual(['Tarde']);
    expect(opcionesDeCurso(CURSOS, BASE, 'Sala 4 años', '').turnos).toEqual(['Mañana', 'Tarde', JE]);
  });
  it('donde «Jornada Extendida» sí es división, se ofrece', () => {
    expect(opcionesDeCurso(CURSOS, BASE, '5° grado', '').divisiones).toEqual(['A', 'Jornada Extendida']);
  });
  it('sin turno en la nómina (secundaria) se ofrecen todos los turnos', () => {
    expect(opcionesDeCurso(CURSOS, BASE, '1° año', 'B').turnos).toEqual(BASE.turnos);
  });
  it('sin nómina para el grado, sin grado elegido o sin lista: todo, como antes', () => {
    expect(opcionesDeCurso(CURSOS, BASE, '7° grado', '')).toEqual(BASE);
    expect(opcionesDeCurso(CURSOS, BASE, '', '')).toEqual(BASE);
    expect(opcionesDeCurso(null, BASE, 'Sala 4 años', 'B')).toEqual(BASE);
  });
  it('compara sin mayúsculas ni tildes y devuelve el texto de la lista del colegio', () => {
    const cursos = [{ grado: 'SALA 4 AÑOS', division: 'c', turno: 'jornada extendida / completa' }];
    expect(opcionesDeCurso(cursos, BASE, 'Sala 4 años', 'C')).toEqual({ divisiones: ['C'], turnos: [JE] });
  });
});

describe('etiquetaDivision', () => {
  it('«División C», y las que tienen nombre propio tal cual', () => {
    expect(etiquetaDivision('C')).toBe('División C');
    expect(etiquetaDivision('Jornada Extendida')).toBe('Jornada Extendida');
  });
});
