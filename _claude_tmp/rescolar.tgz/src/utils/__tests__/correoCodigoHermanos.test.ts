// 10/10/2026 (prueba de Pablo): el email con el código de acceso que sale al tocar «Verificar si ya fue
// aprobada» (y en los otros reenvíos y en la aprobación automática) nombraba sólo al primer hijo. Ahora
// todos los envíos listan al principal y a sus hermanos, como ya hacía el envío desde el panel.
import { describe, expect, it } from 'vitest';
import { fuenteServidor } from '../../test/fuenteServidor';

describe('email del código de acceso: alumnos vinculados', () => {
  const codigo = fuenteServidor();
  const llamadas: string[] = [];
  let desde = 0;
  while ((desde = codigo.indexOf('enviarCorreoCodigoAcceso({', desde)) !== -1) {
    llamadas.push(codigo.slice(desde, codigo.indexOf('});', desde)));
    desde += 10;
  }

  it('hay envíos para revisar', () => {
    expect(llamadas.length).toBeGreaterThanOrEqual(4);
  });

  it('ningún envío arma la lista con un solo alumno a mano', () => {
    for (const llamada of llamadas) expect(llamada).not.toContain('alumnos: [{');
  });

  it('la aprobación automática también suma a los hermanos', () => {
    expect(codigo).toMatch(/alumnos: alumnosParaCorreo\(\s*\{ nombre: String\(alumnoNombre\)\.trim\(\)[^]*?hermanosReconciliados\s*\)/);
  });
});
