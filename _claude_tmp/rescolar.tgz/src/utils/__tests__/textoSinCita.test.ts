import { describe, expect, it } from 'vitest';
import { textoSinCita } from '../colaConsultas';

// 28/10/2026: en «Atender consultas» se muestra sólo lo que escribió la familia (Yahoo, Outlook y iPhone citan sin «>»).
describe('textoSinCita', () => {
  it('Yahoo: corta en «Yahoo Mail: busca…» y junta el hueco de líneas vacías', () => {
    const t = 'Buenas noches\nNo me aparece el Kit.\nHice captura: \nY solo me deja elegir la grupal.\n\n \n\n\n\n\n\n\n\nYahoo Mail: busca, organiza, toma el control de tu buzón \n \n  El mar, 27 de oct de 2026 a la(s) 22:46, Retrato Escolar<fotos@x.com> escribió:   \nHola';
    expect(textoSinCita(t)).toBe('Buenas noches\nNo me aparece el Kit.\nHice captura:\nY solo me deja elegir la grupal.');
  });

  it('iPhone y Outlook: «Enviado desde mi iPhone», «El 25 oct…, X escribió:» y la línea de guiones bajos', () => {
    expect(textoSinCita('No encuentro la foto\nGracias\nEnviado desde mi iPhone\nEl 25 oct 2026, a la(s) 2:22 p. m., Retrato <f@x.com> escribió:\n﻿ Hola')).toBe('No encuentro la foto\nGracias');
    expect(textoSinCita('Muchas gracias\nObtener Outlook para iOS<https://aka.ms/x>\n________________________________\nDe: Retrato <f@x.com>\nEnviado: hoy')).toBe('Muchas gracias');
    expect(textoSinCita('Mateo está en 5to C\n________________________________\nFrom: Retrato\nSent: Tuesday')).toBe('Mateo está en 5to C');
  });

  it('encabezado partido en dos líneas y cita con «>» (Gmail)', () => {
    expect(textoSinCita('Dale, gracias\n\nEl mar, 27 oct 2026 a las 21:26, Retrato Escolar (<fotos@x.com>)\nescribió:\n> Hola')).toBe('Dale, gracias');
    expect(textoSinCita('Perfecto\n> Hola\n> chau')).toBe('Perfecto');
  });

  it('sin cita queda igual; si todo es cita, se muestra entero', () => {
    expect(textoSinCita('Hola, ¿cuándo llegan las fotos?')).toBe('Hola, ¿cuándo llegan las fotos?');
    expect(textoSinCita(null)).toBe('');
    expect(textoSinCita('> sólo cita')).toBe('> sólo cita');
  });
});
