import { describe, expect, it } from 'vitest';
import { crearFila, recorrerConLimite } from '../concurrencia';

const esperar = (ms: number) => new Promise((r) => setTimeout(r, ms));

describe('recorrerConLimite (24/10, subida en paralelo)', () => {
  it('procesa todos los ítems sin pasar el límite de tareas a la vez', async () => {
    let enCurso = 0;
    let maximo = 0;
    const hechos: number[] = [];
    const parado = await recorrerConLimite([1, 2, 3, 4, 5, 6, 7], 3, async (n) => {
      enCurso++;
      maximo = Math.max(maximo, enCurso);
      await esperar(5 + (n % 3));
      hechos.push(n);
      enCurso--;
    });
    expect(parado).toBe(false);
    expect(maximo).toBe(3);
    expect(hechos.sort()).toEqual([1, 2, 3, 4, 5, 6, 7]);
  });

  it('al cancelar no toma ítems nuevos y avisa que se paró', async () => {
    let cancelar = false;
    const hechos: number[] = [];
    const parado = await recorrerConLimite([1, 2, 3, 4, 5, 6], 2, async (n) => {
      await esperar(5);
      hechos.push(n);
      if (n === 2) cancelar = true;
    }, () => cancelar);
    expect(parado).toBe(true);
    expect(hechos.length).toBeLessThan(6);
  });
});

describe('crearFila', () => {
  it('corre las tareas de a una y en orden, aunque una falle', async () => {
    const fila = crearFila();
    const orden: string[] = [];
    let enCurso = 0;
    const tarea = (id: string, ms: number, falla = false) => fila(async () => {
      enCurso++;
      expect(enCurso).toBe(1);
      await esperar(ms);
      orden.push(id);
      enCurso--;
      if (falla) throw new Error('falla');
      return id;
    });
    const resultados = await Promise.allSettled([tarea('a', 10), tarea('b', 1, true), tarea('c', 1)]);
    expect(orden).toEqual(['a', 'b', 'c']);
    expect(resultados.map((r) => r.status)).toEqual(['fulfilled', 'rejected', 'fulfilled']);
  });
});
