import crypto from 'crypto';
import ts from 'typescript';
import { describe, expect, it, vi } from 'vitest';
import { fuenteServidor } from '../../test/fuenteServidor';
import { traerTodasLasFilas } from '../../../servidor/nucleo/utilidades';

// 04/10: lupa de la galería de colegios (pedido de Pablo). server.ts no se puede importar en las pruebas
// (arranca el servidor): se extrae accesoLupaFoto y se prueba con una base falsa, igual que en
// servidorPedidosPagos.test.ts.
const server = fuenteServidor();

function extraerFuncion(nombre: string): string {
  const inicio = server.search(new RegExp(`^(async )?function ${nombre}\\b`, 'm'));
  if (inicio < 0) throw new Error(`No encontré ${nombre} en server.ts`);
  const fin = server.indexOf('\n}\n', inicio);
  return server.slice(inicio, fin + 2);
}

const SECCION = { colegioId: 'col-1', grado: '3° grado', turno: 'Mañana', division: 'A' };
const COLEGIOS: any[] = [
  { id: 'col-1', muestras_lupa: true },
  { id: 'col-sin', muestras_lupa: false },
];
const FOTOS: any[] = [
  { id: 'f-grupal', categoria: 'grupal', alumno_nombre: null, storage_path: '2026/x/originales/g.jpg', colegio_id: 'col-1', codigo_curso: '3A-M' },
  { id: 'f-lola', categoria: 'individual', alumno_nombre: 'Lola Pérez', storage_path: '2026/x/originales/l.jpg', colegio_id: 'col-1', codigo_curso: '3A-M' },
  { id: 'f-juan', categoria: 'individual', alumno_nombre: 'Juan Gómez', storage_path: '2026/x/originales/j.jpg', colegio_id: 'col-1', codigo_curso: '3A-M' },
  { id: 'f-otro', categoria: 'grupal', alumno_nombre: null, storage_path: '2026/y/originales/o.jpg', colegio_id: 'col-1', codigo_curso: '5B-T' },
  // 06/10: subida pero SIN PUBLICAR (botón «Publicar» del panel): ninguna familia la ve.
  { id: 'f-borrador', categoria: 'grupal', alumno_nombre: null, storage_path: '2026/x/originales/b.jpg', colegio_id: 'col-1', codigo_curso: '3A-M', publicada_at: null },
].map((f) => ('publicada_at' in f ? f : { ...f, publicada_at: '2026-10-04T10:00:00Z' }));

function baseFalsa() {
  const consultas: any[][] = [];
  const cliente = {
    from: (tabla: string) => {
      const ops: any[][] = [];
      const b: any = new Proxy({}, {
        get(_o, prop) {
          if (prop === 'then') {
            return (ok: any, mal: any) => Promise.resolve().then(() => {
              consultas.push([tabla, ...ops]);
              const fuente = tabla === 'colegios' ? COLEGIOS : FOTOS;
              let filas = fuente.filter((f) => ops.every(([op, campo, valor]) => (op === 'eq' ? f[campo] === valor : op === 'not' ? f[campo] != null : true)));
              const rango = ops.find(([op]) => op === 'range'); // como PostgREST: respeta .range(desde, hasta)
              if (rango) filas = filas.slice(rango[1], rango[2] + 1);
              const unica = ops.some(([op]) => op === 'maybeSingle');
              return { data: unica ? filas[0] ?? null : filas, error: null };
            }).then(ok, mal);
          }
          return (...args: any[]) => { ops.push([prop, ...args]); return b; };
        },
      });
      return b;
    },
  };
  return { cliente, consultas };
}

function cargarAcceso() {
  const fuente = `const accesoLupaGaleria = new Map();\nconst MS_ACCESO_LUPA = 5 * 60 * 1000;\n${extraerFuncion('accesoLupaFoto')}`;
  const js = ts.transpileModule(fuente, { compilerOptions: { target: ts.ScriptTarget.ES2020 } }).outputText;
  const normalizar = (n: unknown) => String(n || '').toLowerCase().trim();
  const deps = {
    crypto,
    buscarSeccionPorCodigoSecreto: vi.fn(async (_sb: any, codigo: string) =>
      codigo === 'AB12-CD34' ? SECCION : codigo === 'SIN-LUPA' ? { ...SECCION, colegioId: 'col-sin' } : null),
    determinarCodigoCursoServidor: () => '3A-M',
    // Familia "fam-lola" (llave "ok") tiene a Lola; cualquier otra llave no vale.
    hijosDeFamiliaConAcceso: vi.fn(async (_sb: any, familia: string, acceso: string) => (acceso === 'ok' ? (familia === 'fam-lola' ? ['Lola Pérez'] : ['Otro Chico']) : null)),
    etiquetasDelAlumno: (nombre: unknown, etiquetas: unknown[]) => new Set(etiquetas.map(normalizar).filter((e) => e === normalizar(nombre))),
    normalizarNombrePorPalabras: normalizar,
    codigoCorto: (s: string) => `H${s.length}`,
    traerTodasLasFilas, // 11/10 (FAM-6): la lupa pagina las etiquetas del curso
  };
  const crear = new Function(...Object.keys(deps), `${js}\nreturn accesoLupaFoto;`);
  return { acceso: crear(...Object.values(deps)) as (sb: any, id: string, q: Record<string, unknown>) => Promise<any>, deps };
}

describe('lupa de colegios: mismas reglas de acceso que la galería', () => {
  it('06/10: una foto sin publicar no se ve con la lupa, ni con el código del curso', async () => {
    const { acceso } = cargarAcceso();
    const { cliente } = baseFalsa();
    expect(await acceso(cliente, 'f-borrador', { codigo: 'AB12-CD34' })).toBeNull();
    expect(await acceso(cliente, 'f-grupal', { codigo: 'AB12-CD34' })).not.toBeNull();
  });

  it('sin código, o con un código incorrecto, no hay lupa', async () => {
    const { acceso } = cargarAcceso();
    const { cliente } = baseFalsa();
    expect(await acceso(cliente, 'f-grupal', {})).toBeNull();
    expect(await acceso(cliente, 'f-grupal', { codigo: 'MAL' })).toBeNull();
  });

  it('si el colegio tiene apagado «Muestras con lupa», no hay lupa', async () => {
    const { acceso } = cargarAcceso();
    FOTOS.push({ id: 'f-sin', categoria: 'grupal', alumno_nombre: null, storage_path: 'z.jpg', colegio_id: 'col-sin', codigo_curso: '3A-M' });
    try {
      expect(await acceso(baseFalsa().cliente, 'f-sin', { codigo: 'SIN-LUPA' })).toBeNull();
    } finally {
      FOTOS.pop();
    }
  });

  it('una foto de otro curso no se muestra aunque el código sea válido', async () => {
    const { acceso } = cargarAcceso();
    expect(await acceso(baseFalsa().cliente, 'f-otro', { codigo: 'AB12-CD34' })).toBeNull();
  });

  it('una grupal se ve con el código del curso (sello del curso)', async () => {
    const { acceso } = cargarAcceso();
    const r = await acceso(baseFalsa().cliente, 'f-grupal', { codigo: 'AB12-CD34' });
    expect(r).toMatchObject({ storagePath: '2026/x/originales/g.jpg', sello: 'CUR-H10' });
  });

  it('una individual etiquetada sólo la ve la familia dueña (sello de la familia)', async () => {
    const { acceso } = cargarAcceso();
    const sb = baseFalsa().cliente;
    expect(await acceso(sb, 'f-lola', { codigo: 'AB12-CD34' })).toBeNull();
    expect(await acceso(sb, 'f-lola', { codigo: 'AB12-CD34', familia: 'fam-lola', acceso: 'mala' })).toBeNull();
    expect(await acceso(sb, 'f-lola', { codigo: 'AB12-CD34', familia: 'fam-otra', acceso: 'ok' })).toBeNull();
    expect(await acceso(sb, 'f-juan', { codigo: 'AB12-CD34', familia: 'fam-lola', acceso: 'ok' })).toBeNull();
    const r = await acceso(sb, 'f-lola', { codigo: 'AB12-CD34', familia: 'fam-lola', acceso: 'ok' });
    expect(r).toMatchObject({ storagePath: '2026/x/originales/l.jpg', sello: 'FAM-H8' });
  });

  it('recuerda el permiso unos minutos (la lupa pide muchos pedacitos seguidos)', async () => {
    const { acceso, deps } = cargarAcceso();
    const { cliente, consultas } = baseFalsa();
    await acceso(cliente, 'f-grupal', { codigo: 'AB12-CD34' });
    const antes = consultas.length;
    await acceso(cliente, 'f-grupal', { codigo: 'AB12-CD34' });
    expect(consultas.length).toBe(antes);
    expect(deps.buscarSeccionPorCodigoSecreto).toHaveBeenCalledTimes(1);
  });

  it('la galería avisa si el colegio tiene la lupa prendida', () => {
    const galeria = server.slice(server.indexOf("app.get('/api/fotos', "), server.indexOf('// LUPA de la galería (04/10'));
    expect(galeria).toContain(".from('colegios').select('muestras_lupa').eq('id', seccion.colegioId)");
    expect(galeria).toContain("lupa: colegioLupa?.muestras_lupa === true");
  });

  it('la ruta tiene límite por IP y nunca devuelve la ruta del original', () => {
    expect(server).toContain("app.get('/api/fotos/:id/lupa', limitarFrecuencia('fotos-lupa', 3000, 10 * 60 * 1000)");
    const ruta = server.slice(server.indexOf("app.get('/api/fotos/:id/lupa'"), server.indexOf('// 4A. COLEGIOS: PERFIL'));
    expect(ruta).toContain('res.send(recorte)');
    expect(ruta).not.toMatch(/res\.json\([^)]*storagePath/);
  });
});
