import { readFileSync } from 'fs';
import path from 'path';
import ts from 'typescript';
import { describe, expect, it } from 'vitest';
import { fuenteServidor } from '../../test/fuenteServidor';

// 08/10/2026: índices únicos en la base (migración 20261008030000_unicos_pedidos_fotos.sql) y el
// manejo del error 23505 en server.ts. server.ts no se puede importar en las pruebas (arranca el
// servidor): se extraen las funciones y se verifica el texto de las rutas, como en
// auditoriaPanelFotos.test.ts.
const raiz = path.resolve(__dirname, '../../..');
const leer = (archivo: string) => readFileSync(path.join(raiz, archivo), 'utf8').replace(/\r\n/g, '\n'); // la carpeta real usa CRLF
const server = fuenteServidor();
const migracion = leer('supabase/migrations/20261008030000_unicos_pedidos_fotos.sql');
const panel = leer('src/components/AdminModal.tsx');

function extraerFuncion(nombre: string): string {
  const inicio = server.search(new RegExp(`^(async )?function ${nombre}\\b`, 'm'));
  if (inicio < 0) throw new Error(`No encontré ${nombre} en server.ts`);
  const fin = server.indexOf('\n}\n', inicio);
  return server.slice(inicio, fin + 2);
}

function cargar<T>(nombres: string[]): T {
  const fuente = nombres.map(extraerFuncion).join('\n\n');
  const js = ts.transpileModule(fuente, { compilerOptions: { target: ts.ScriptTarget.ES2020 } }).outputText;
  // eslint-disable-next-line @typescript-eslint/no-implied-eval
  return new Function(`${js}\nreturn { ${nombres.join(', ')} };`)() as T;
}

function bloqueDesde(inicio: string, largo: number): string {
  const a = server.indexOf(inicio);
  if (a < 0) throw new Error(`No encontré ${inicio}`);
  return server.slice(a, a + largo);
}

const { tipoChoqueUnicoPedido, renumerarFilasPorCurso, insertarPedidosConReintento } = cargar<{
  tipoChoqueUnicoPedido: (error: any) => 'friendly' | 'numero_lista' | 'mejora' | null;
  renumerarFilasPorCurso: (filas: Record<string, any>[], ultimos: Map<string, number>) => void;
  insertarPedidosConReintento: (supabase: any, filas: Record<string, any>[], columnas?: string) => Promise<{ data: any[] | null; error: any }>;
}>([
  'sanitizarParaMinilabServidor',
  'calcularCodigoAlumnoServidor',
  'claveCursoNumeroLista',
  'renumerarFilasPorCurso',
  'tipoChoqueUnicoPedido',
  'ultimoNumeroLista',
  'insertarPedidosConReintento',
]);

const choque = (indice: string) => ({
  code: '23505',
  message: `duplicate key value violates unique constraint "${indice}"`,
  details: 'Key (...) already exists.',
});

// Supabase de mentira: guarda los pedidos en memoria y responde 23505 como lo haría el índice
// pedidos_numero_lista_unico (colegio + curso + número, sin contar las mejoras).
function supabaseFalso(existentes: Record<string, any>[]) {
  const intentos: Record<string, any>[][] = [];
  const mismoNumero = (a: Record<string, any>, b: Record<string, any>) =>
    !a.mejora_de_pedido_id && !b.mejora_de_pedido_id &&
    a.colegio_id === b.colegio_id && a.curso_codigo === b.curso_codigo && a.alumno_numero_lista === b.alumno_numero_lista;
  return {
    intentos,
    from: () => ({
      insert: (filas: Record<string, any>[]) => ({
        select: async () => {
          intentos.push(filas.map((f) => ({ ...f })));
          if (filas.some((f) => existentes.some((e) => mismoNumero(e, f)))) return { data: null, error: choque('pedidos_numero_lista_unico') };
          existentes.push(...filas.map((f) => ({ ...f })));
          return { data: filas.map((f) => ({ id: f.id })), error: null };
        },
      }),
      select: () => {
        const filtros: Record<string, unknown> = {};
        const consulta: any = {
          eq: (columna: string, valor: unknown) => { filtros[columna] = valor; return consulta; },
          is: (columna: string, valor: unknown) => { filtros[`is:${columna}`] = valor; return consulta; },
          not: () => consulta,
          order: () => consulta,
          limit: async () => {
            const numeros = existentes
              .filter((e) => e.curso_codigo === filtros.curso_codigo && (filtros.colegio_id === undefined || e.colegio_id === filtros.colegio_id))
              .filter((e) => !(filtros['is:mejora_de_pedido_id'] === null && e.mejora_de_pedido_id))
              .map((e) => Number(e.alumno_numero_lista))
              .sort((a, b) => b - a);
            return { data: numeros.length ? [{ alumno_numero_lista: numeros[0] }] : [], error: null };
          },
        };
        return consulta;
      },
    }),
  };
}

describe('08/10: qué índice único frenó el insert', () => {
  it('distingue número amigable, número de lista y mejora viva', () => {
    expect(tipoChoqueUnicoPedido(choque('pedidos_pedido_friendly_id_unico'))).toBe('friendly');
    expect(tipoChoqueUnicoPedido(choque('pedidos_numero_lista_unico'))).toBe('numero_lista');
    expect(tipoChoqueUnicoPedido(choque('pedidos_mejora_viva_unica'))).toBe('mejora');
  });

  it('la clave primaria (reintento con el mismo id) y otros errores no se tocan acá', () => {
    expect(tipoChoqueUnicoPedido(choque('pedidos_pkey'))).toBeNull();
    expect(tipoChoqueUnicoPedido({ code: '23503', message: 'pedidos_numero_lista_unico' })).toBeNull();
    expect(tipoChoqueUnicoPedido(null)).toBeNull();
  });
});

describe('08/10: número de lista único por colegio y curso', () => {
  it('renumera desde el último usado, por colegio + curso, y rehace el código de minilab', () => {
    const filas: Record<string, any>[] = [
      { colegio_id: 'A', curso_codigo: 'GRADO1-ATM', alumno_nombre: 'Ana Pérez', alumno_numero_lista: 3, codigo_alumno: 'viejo' },
      { colegio_id: 'A', curso_codigo: 'GRADO1-ATM', alumno_nombre: 'Leo Pérez', alumno_numero_lista: 4, codigo_alumno: 'viejo' },
      { colegio_id: 'B', curso_codigo: 'GRADO1-ATM', alumno_nombre: 'Sol Díaz', alumno_numero_lista: 3, codigo_alumno: 'viejo' },
    ];
    renumerarFilasPorCurso(filas, new Map([['A|GRADO1-ATM', 7]]));
    expect(filas.map((f) => f.alumno_numero_lista)).toEqual([8, 9, 1]);
    expect(filas[0].codigo_alumno).toBe('GRADO1_ATM_08_ANA_PEREZ');
    expect(filas[2].codigo_alumno).toBe('GRADO1_ATM_01_SOL_DIAZ');
  });

  it('una mejora a Kit Impreso conserva el número del pedido original', () => {
    const mejora = { colegio_id: 'A', curso_codigo: 'GRADO1-ATM', alumno_nombre: 'Ana', alumno_numero_lista: 3, codigo_alumno: 'GRADO1_ATM_03_ANA', mejora_de_pedido_id: 'p1' };
    renumerarFilasPorCurso([mejora], new Map([['A|GRADO1-ATM', 7]]));
    expect(mejora.alumno_numero_lista).toBe(3);
    expect(mejora.codigo_alumno).toBe('GRADO1_ATM_03_ANA');
  });

  it('si otra compra tomó el número en el medio, se renumera y se reintenta', async () => {
    const supabase = supabaseFalso([
      { colegio_id: 'A', curso_codigo: 'GRADO1-ATM', alumno_numero_lista: 1 },
      { colegio_id: 'A', curso_codigo: 'GRADO1-ATM', alumno_numero_lista: 2 },
      { colegio_id: 'A', curso_codigo: 'GRADO1-ATM', alumno_numero_lista: 5 }, // la compra simultánea
      { colegio_id: 'A', curso_codigo: 'GRADO1-ATM', alumno_numero_lista: 9, mejora_de_pedido_id: 'x' }, // no cuenta
    ]);
    const filas = [
      { id: 'h1', colegio_id: 'A', curso_codigo: 'GRADO1-ATM', alumno_nombre: 'Mellizo Uno', alumno_numero_lista: 5 },
      { id: 'h2', colegio_id: 'A', curso_codigo: 'GRADO1-ATM', alumno_nombre: 'Mellizo Dos', alumno_numero_lista: 6 },
    ];
    const r = await insertarPedidosConReintento(supabase, filas);
    expect(r.error).toBeNull();
    expect(supabase.intentos).toHaveLength(2);
    expect(filas.map((f) => f.alumno_numero_lista)).toEqual([6, 7]);
    expect((filas[0] as any).codigo_alumno).toBe('GRADO1_ATM_06_MELLIZO_UNO');
  });

  it('el siguiente número sale del más alto usado (no de la cantidad de pedidos) y sin contar mejoras', () => {
    const fn = extraerFuncion('ultimoNumeroLista');
    expect(fn).toContain(".is('mejora_de_pedido_id', null)");
    expect(fn).toContain(".order('alumno_numero_lista', { ascending: false }).limit(1)");
    expect(extraerFuncion('obtenerNumeroListaSecuencial')).not.toContain("count: 'exact'");
  });

  it('carrito de hermanos y reservas cuentan por colegio + curso', () => {
    const usos = server.match(/numeroListaBasePorCurso\[claveNumero\]/g) || [];
    expect(usos.length).toBe(6); // 3 en crear-multiple + 3 en reservas
    expect(server).not.toContain('numeroListaBasePorCurso[cursoCodigoServidor]');
    expect(server).not.toContain('numeroListaBasePorCurso[r.cursoCodigo]');
  });
});

describe('08/10: una sola mejora a Kit Impreso viva por pedido', () => {
  it('si la base frena una segunda mejora, se devuelve la existente en vez de un error', () => {
    const ruta = bloqueDesde("app.post('/api/pedidos/:id/mejorar-a-impreso'", 9000);
    const manejo = ruta.indexOf("tipoChoqueUnicoPedido(errInsert) === 'mejora'");
    expect(manejo).toBeGreaterThan(0);
    expect(manejo).toBeLessThan(ruta.indexOf('throw errInsert'));
    expect(ruta.slice(manejo, ruta.indexOf('throw errInsert'))).toContain('responderMejora(existente)');
  });

  it('reactivar desde el panel una mejora que choca avisa claro', () => {
    expect(server).toContain("codigo: 'MEJORA_DUPLICADA'");
    expect(panel).toContain("resultadoEstado.codigo === 'MEJORA_DUPLICADA'");
  });
});

describe('08/10: migración de índices únicos', () => {
  it('crea los tres índices con los nombres que espera server.ts', () => {
    expect(migracion).toMatch(/create unique index if not exists pedidos_numero_lista_unico\s+on public\.pedidos \(colegio_id, curso_codigo, alumno_numero_lista\)\s+where mejora_de_pedido_id is null/);
    expect(migracion).toMatch(/create unique index if not exists pedidos_mejora_viva_unica\s+on public\.pedidos \(mejora_de_pedido_id\)\s+where mejora_de_pedido_id is not null and cancelado_definitivo = false/);
    // Completo (sin where): lo necesita el "on conflict (storage_path)" del registro de fotos.
    expect(migracion).toMatch(/create unique index if not exists fotos_storage_path_unico on public\.fotos \(storage_path\);/);
  });

  it('no agrega UNIQUE en inscripciones (una familia puede reinscribirse con otro email)', () => {
    expect(migracion).not.toMatch(/create unique index[^;]*inscripciones/i);
  });
});
