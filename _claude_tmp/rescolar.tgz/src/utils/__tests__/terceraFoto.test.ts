import { readFileSync } from 'fs';
import path from 'path';
import { describe, expect, it } from 'vitest';

import { fuenteServidor } from '../../test/fuenteServidor';
import { esTerceraFoto, etiquetaTerceraFoto, pasoDelPack, textosTerceraFoto } from '../terceraFoto';
import { generarArchivosParaLaboratorio } from '../../services/pedidosLabService';
import { fotoVisibleParaAlumno } from '../nombresAlumno';

// 06/10/2026 (pedido de Pablo): en secundaria la 3ª foto del kit es «con familia y/o amigos»
// (categoría 'familia'), la ve todo el curso y va en el lugar `docenteId` del pedido.

const raiz = path.resolve(__dirname, '../../..');
const servidor = fuenteServidor();

describe('utils/terceraFoto', () => {
  it('la 3ª foto puede ser con la seño o con familia/amigos, y las dos van en el mismo paso del pack', () => {
    expect(esTerceraFoto('docente')).toBe(true);
    expect(esTerceraFoto('familia')).toBe(true);
    expect(esTerceraFoto('individual')).toBe(false);
    expect(pasoDelPack('familia')).toBe('docente');
    expect(pasoDelPack('grupal')).toBe('grupal');
  });
  it('el nombre de la 3ª foto depende de lo que tenga el curso', () => {
    expect(textosTerceraFoto(['grupal', 'individual', 'docente']).corto).toBe('Con Seño');
    expect(textosTerceraFoto(['grupal', 'individual', 'familia']).una).toBe('una foto con familia y/o amigos');
    expect(textosTerceraFoto(['docente', 'familia']).titulo).toBe('Con la seño o con familia/amigos');
    expect(textosTerceraFoto([]).corto).toBe('Con Seño');
    expect(etiquetaTerceraFoto('familia')).toBe('Con familia/amigos');
    expect(etiquetaTerceraFoto('docente')).toBe('Con docente');
  });
  it('la foto con familia/amigos la ve todo el curso (aunque esté etiquetada con un chico)', () => {
    expect(fotoVisibleParaAlumno({ categoria: 'familia', alumnoNombre: 'Guadalupe Garcia' }, 'Martina Lopez')).toBe(true);
  });
});

describe('laboratorio: 3ª foto con familia/amigos', () => {
  const fotos = [
    { id: 'g', categoria: 'grupal', url: '/g', thumbnail: '', titulo: 'g' },
    { id: 'i', categoria: 'individual', url: '/i', thumbnail: '', titulo: 'i' },
    { id: 'f', categoria: 'familia', url: '/f', thumbnail: '', titulo: 'f' },
  ] as any;
  const seleccion = { grupalId: 'g', individualId: 'i', docenteId: 'f' };

  it('sale como _FAMILIA (no _DOCENTE), con su foto real, también en las copias de la carpeta extra', () => {
    const archivos = generarArchivosParaLaboratorio('3ANIO-ATM', 1, 'Guadalupe Garcia', seleccion, { carpetasExtras: 1, individual15x21: 1, grupal20x30: 1, docente15x21: 1, otras15x21: 0 }, fotos);
    const terceras = archivos.filter((a) => a.tipo === 'docente');
    expect(terceras).toHaveLength(2);
    for (const a of terceras) {
      expect(a.nombreArchivoOriginal).toBe('FAMILIA_HD.jpg');
      expect(a.nombreArchivoLab).toMatch(/_FAMILIA(_COPIA2)?\.jpg$/);
      expect(a.urlOriginalHD).toBe('/f');
      expect(a.sinFotoReal).toBeFalsy();
      expect(a.tamanoImpresion).toBe('15x21');
    }
  });
  it('la de la seño sigue saliendo como _DOCENTE', () => {
    const conDocente = fotos.map((f: any) => (f.id === 'f' ? { ...f, categoria: 'docente' } : f));
    const archivos = generarArchivosParaLaboratorio('3ANIO-ATM', 1, 'Guadalupe Garcia', seleccion, undefined, conDocente);
    expect(archivos.find((a) => a.tipo === 'docente')?.nombreArchivoLab).toMatch(/_DOCENTE\.jpg$/);
  });
});

describe('servidor: 3ª foto con familia/amigos (contratos)', () => {
  it('validarSeleccionFotos acepta la de la seño o la de familia/amigos, y la exige sólo si el curso tiene alguna', () => {
    const i = servidor.indexOf('async function validarSeleccionFotos(');
    const bloque = servidor.slice(i, i + 4000);
    expect(bloque).toContain('esCategoriaTerceraFoto(f.categoria)');
    expect(bloque).toContain('categoriaValeEnLugar(foto.categoria, lugar, sinFoto)'); // 22/10: servidor/nucleo/fotosFaltantes.ts
    expect(bloque).not.toContain("deCategoria(sel.docenteId, 'docente')");
  });
  it('confirmar las fotos de una reserva pagada ya no exige siempre una «con la seño»', () => {
    const i = servidor.indexOf("app.post('/api/reservas/:id/elegir-fotos'");
    const bloque = servidor.slice(i, i + 9000);
    expect(bloque).not.toContain("categoriaDe(ids.docenteId) !== 'docente'");
    expect(bloque).toContain('await validarSeleccionFotos('); // 22/10: misma validación que la compra
  });
  it('el .zip HD incluye la foto con familia/amigos con su propio nombre', () => {
    expect(servidor).toContain("'Con_familia_y_amigos.jpg'");
  });
  it('la galería no manda a las demás familias el nombre del chico de una foto con familia/amigos', () => {
    expect(servidor).toMatch(/f\.categoria === 'familia' && f\.alumno_nombre \? \{ \.\.\.f, alumno_nombre: null \}/);
  });
  it('la migración permite la categoría familia', () => {
    const sql = readFileSync(path.join(raiz, 'supabase/migrations/20261006010000_foto_familia_amigos.sql'), 'utf8');
    expect(sql).toContain("'familia'::text");
  });
});
