// 08/10 (pedido de Pablo): consulta «foto de hermanos». Hasta ese día la inscripción marcaba la foto
// de hermanos a TODA familia que anotaba hermanos, aunque no tildara la casilla. Estas pruebas cuidan
// (1) que la inscripción guarde la casilla real, (2) el email de consulta, (3) las reglas de las rutas
// y (4) la página public/foto-hermanos.html (dos casillas, se guarda sólo al confirmar).
import { readFileSync } from 'fs';
import path from 'path';
import ts from 'typescript';
import { JSDOM } from 'jsdom';
import { describe, expect, it, vi } from 'vitest';
import { fuenteServidor } from '../../test/fuenteServidor';

const raiz = path.resolve(__dirname, '../../..');
const fuente = fuenteServidor();
const pagina = readFileSync(path.join(raiz, 'public/foto-hermanos.html'), 'utf8');

function bloqueEntre(desde: string, hasta: string): string {
  const inicio = fuente.indexOf(desde);
  const fin = fuente.indexOf(hasta, inicio);
  if (inicio < 0 || fin < 0) throw new Error(`No se encontró el tramo "${desde}" … "${hasta}" en server.ts`);
  return fuente.slice(inicio, fin);
}

// Las funciones puras del email se sacan de server.ts (no se puede importar: arranca Express).
function cargarFuncionesEmail() {
  const escape = bloqueEntre('function escapeHtml(', '\n}\n') + '\n}\n';
  const funciones = bloqueEntre('function nombrePropioFotoHermanos(', 'const MENSAJE_LINK_FOTO_HERMANOS_INVALIDO');
  const js = ts.transpileModule(`${escape}\n${funciones}`, { compilerOptions: { target: ts.ScriptTarget.ES2020 } }).outputText;
  // eslint-disable-next-line no-new-func
  return new Function(`${js}\nreturn { nombrePropioFotoHermanos, unirNombresFotoHermanos, chicosDeInscripcionFotoHermanos, correoConsultaFotoHermanos };`)() as {
    nombrePropioFotoHermanos: (t: unknown) => string;
    unirNombresFotoHermanos: (n: string[]) => string;
    chicosDeInscripcionFotoHermanos: (fila: any) => string[];
    correoConsultaFotoHermanos: (d: { chicos: string[]; colegio: string; linkSi: string; linkNo: string; recordatorio?: boolean }) => { asunto: string; html: string; texto: string };
  };
}

describe('inscripción: la foto de hermanos se guarda como la eligió la familia', () => {
  it('ya no se marca sola por tener hermanos', () => {
    expect(fuente).not.toContain('Boolean(solicitaFotoHermanos || (hermanos && hermanos.length > 0))');
    expect(fuente).toContain('const pideFotoHermanos = solicitaFotoHermanos === true && hermanos.length > 0;');
    expect(fuente).toContain('solicita_foto_hermanos: pideFotoHermanos,');
  });
  it('con hermanos anotados queda confirmada (no entra en la consulta)', () => {
    expect(fuente).toContain('foto_hermanos_confirmada_at: hermanos.length > 0 ? new Date().toISOString() : null,');
  });
});

describe('email de la consulta', () => {
  const f = cargarFuncionesEmail();
  it('arma el saludo con los nombres de los chicos bien escritos', () => {
    expect(f.nombrePropioFotoHermanos('  CIRO   gabriel ')).toBe('Ciro Gabriel');
    expect(f.unirNombresFotoHermanos(['Ana', 'Inés'])).toBe('Ana e Inés');
    expect(f.unirNombresFotoHermanos(['Ana', 'Luz', 'Pía'])).toBe('Ana, Luz y Pía');
    expect(f.chicosDeInscripcionFotoHermanos({ alumno_nombre: 'renata', hermanos: [{ alumnoNombre: 'EMMA' }] })).toEqual(['Renata', 'Emma']);
  });
  it('lleva los dos botones (Sí / No) con su link y escapa los datos de la familia', () => {
    const correo = f.correoConsultaFotoHermanos({
      chicos: ['Renata', '<b>Emma</b>'],
      colegio: 'Instituto Madre del Divino Pastor',
      linkSi: 'https://www.retratoescolar.com.ar/foto-hermanos.html?f=x.y&r=si',
      linkNo: 'https://www.retratoescolar.com.ar/foto-hermanos.html?f=x.y&r=no',
    });
    expect(correo.asunto).toBe('¿Quieren la foto de hermanos juntos?');
    expect(correo.html).toContain('href="https://www.retratoescolar.com.ar/foto-hermanos.html?f=x.y&amp;r=si"');
    expect(correo.html).toContain('href="https://www.retratoescolar.com.ar/foto-hermanos.html?f=x.y&amp;r=no"');
    expect(correo.html).toContain('Sí, queremos la foto de hermanos');
    expect(correo.html).toContain('No, no la pedimos');
    expect(correo.html).toContain('&lt;b&gt;Emma&lt;/b&gt;');
    expect(correo.html).not.toContain('<b>Emma</b>');
    expect(correo.texto).toContain('&r=si');
  });
  it('aclara que la foto no tiene día fijo y que se pide un email y un WhatsApp para avisar', () => {
    const correo = f.correoConsultaFotoHermanos({ chicos: ['Ana', 'Luz'], colegio: 'X', linkSi: 'a', linkNo: 'b' });
    expect(correo.html).toContain('en un día y lugar que todavía vamos a definir');
    expect(correo.html).toContain('te vamos a pedir un email y un WhatsApp para avisarte cuándo y dónde');
    expect(correo.html).not.toContain('el día de la sesión en el colegio');
  });
  it('aclara que la foto de hermanos tiene un costo aparte (08/10: se vende como un evento)', () => {
    const correo = f.correoConsultaFotoHermanos({ chicos: ['Ana', 'Luz'], colegio: 'X', linkSi: 'a', linkNo: 'b' });
    expect(correo.html).toContain('Tiene un costo aparte</strong> (no está incluida en el kit)');
    expect(correo.texto).toContain('Tiene un costo aparte (no está incluida en el kit)');
    expect(pagina).toContain('Tiene un costo aparte</strong> (no está incluida en el kit)');
  });
  it('el recordatorio cambia el asunto', () => {
    const correo = f.correoConsultaFotoHermanos({ chicos: ['Ana'], colegio: '', linkSi: 'a', linkNo: 'b', recordatorio: true });
    expect(correo.asunto).toBe('Recordatorio: ¿quieren la foto de hermanos juntos?');
  });
});

describe('rutas de la consulta', () => {
  const get = bloqueEntre("app.get('/api/foto-hermanos/:llave'", "app.post('/api/foto-hermanos/:llave'");
  const post = bloqueEntre("app.post('/api/foto-hermanos/:llave'", 'async function filasConsultaFotoHermanos(');
  // Etapa 5 de la división de server.ts (10/10): la ruta quedó al final de servidor/familias/fotoHermanos.ts,
  // así que el tramo termina donde termina la ruta (`});` sin sangría) y no en la sección siguiente.
  const enviar = bloqueEntre("app.post('/api/admin/foto-hermanos/consulta/enviar'", '\n});\n');
  it('abrir el link (GET) nunca guarda una respuesta: los antivirus de correo abren los links', () => {
    expect(get).not.toContain('.update(');
    expect(get).toContain('inscripcionDeLlaveFotoHermanos(req.params.llave)');
  });
  it('guardar exige la llave firmada y un Sí/No explícito', () => {
    expect(post).toContain('inscripcionDeLlaveFotoHermanos(req.params.llave)');
    expect(post).toContain("if (typeof quiere !== 'boolean')");
    expect(post).toContain('solicita_foto_hermanos: quiere,');
    expect(post).toContain('foto_hermanos_confirmada_at: new Date().toISOString(),');
  });
  it('si quiere la foto, exige un email y un WhatsApp válidos y los guarda; si no, los borra', () => {
    expect(post).toContain('if (quiere && !emailValidoFotoHermanos(emailAviso))');
    expect(post).toContain('if (quiere && !whatsappValidoFotoHermanos(whatsappAviso))');
    expect(post).toContain('foto_hermanos_email: quiere ? emailAviso : null,');
    expect(post).toContain('foto_hermanos_whatsapp: quiere ? whatsappAviso : null,');
  });
  it('la lista de los que quieren la foto es sólo para el admin y trae el contacto para avisarles', () => {
    const lista = bloqueEntre("app.get('/api/admin/foto-hermanos/lista'", "app.post('/api/admin/foto-hermanos/consulta/enviar'");
    expect(lista).toContain('requireAdminAuth');
    expect(lista).toContain('.filter((f) => f.solicita_foto_hermanos && f.foto_hermanos_confirmada_at)');
    expect(lista).toContain("email: f.foto_hermanos_email || f.email || '',");
    expect(lista).toContain("whatsapp: f.foto_hermanos_whatsapp || f.telefono_whatsapp || '',");
  });
  it('la llave se compara en tiempo constante', () => {
    expect(bloqueEntre('function inscripcionDeLlaveFotoHermanos(', '/** "CIRO gabriel"')).toContain('compararTimingSafe(token, esperado)');
  });
  it('el envío es sólo para el admin, sólo a las marcadas por defecto y registra a quién se le mandó', () => {
    expect(enviar).toContain('requireAdminAuth');
    expect(enviar).toContain('sinConfirmarFotoHermanos(f)');
    expect(enviar).toContain("idempotencyKey: `foto-hermanos-");
    expect(enviar).toContain('.update({ foto_hermanos_consulta_at: new Date().toISOString() }).in(\'id\', idsEnviados)');
  });
});

describe('página public/foto-hermanos.html', () => {
  const LLAVE = '11111111-2222-3333-4444-555555555555.abcdefghijklmnopqrstuvwxyz012345';

  async function abrir(
    query: string,
    respuestaGet: any = { success: true, chicos: ['Renata', 'Inés'], colegio: 'Divino Pastor', respuesta: null, contacto: { email: 'familia@ejemplo.com', whatsapp: '' } }
  ) {
    const llamadas: { url: string; init?: any }[] = [];
    const fetchFalso = vi.fn((url: string, init?: any) => {
      llamadas.push({ url, init });
      const esPost = init?.method === 'POST';
      const cuerpo = esPost ? JSON.parse(init.body) : null;
      const data = esPost
        ? { success: true, respuesta: cuerpo.quiere ? 'si' : 'no', ...(cuerpo.quiere ? { contacto: { email: cuerpo.email, whatsapp: cuerpo.whatsapp } } : {}) }
        : respuestaGet;
      return Promise.resolve({ ok: data.success !== false, json: () => Promise.resolve(data) });
    });
    const dom = new JSDOM(pagina, {
      url: `https://www.retratoescolar.com.ar/foto-hermanos.html${query}`,
      runScripts: 'dangerously',
      beforeParse(window) {
        (window as any).fetch = fetchFalso;
      },
    });
    const esperar = async () => {
      for (let i = 0; i < 10; i++) await new Promise((r) => setTimeout(r, 0));
    };
    await esperar();
    const doc = dom.window.document;
    return { dom, doc, llamadas, esperar, $: (id: string) => doc.getElementById(id) as any };
  }

  it('el botón del email deja tildada su opción pero no guarda nada hasta confirmar', async () => {
    const { $, llamadas } = await abrir(`?f=${encodeURIComponent(LLAVE)}&r=no`);
    expect($('estadoFormulario').hidden).toBe(false);
    expect($('nombresChicos').textContent).toBe('Renata e Inés');
    expect($('opcionNo').checked).toBe(true);
    expect($('opcionSi').checked).toBe(false);
    expect($('botonConfirmar').disabled).toBe(false);
    expect(llamadas.every((l) => l.init?.method !== 'POST')).toBe(true);
  });

  it('las dos casillas se excluyen; con «Sí» pide email y WhatsApp antes de mandar', async () => {
    const { $, llamadas, esperar, dom } = await abrir(`?f=${encodeURIComponent(LLAVE)}&r=no`);
    expect($('bloqueContacto').hidden).toBe(true);
    $('opcionSi').checked = true;
    $('opcionSi').dispatchEvent(new dom.window.Event('change'));
    expect($('opcionNo').checked).toBe(false);
    expect($('bloqueContacto').hidden).toBe(false);
    expect($('campoEmail').value).toBe('familia@ejemplo.com');
    // Sin WhatsApp no se manda nada y se avisa qué falta.
    $('formulario').dispatchEvent(new dom.window.Event('submit', { cancelable: true }));
    await esperar();
    expect(llamadas.some((l) => l.init?.method === 'POST')).toBe(false);
    expect($('errorEnvio').hidden).toBe(false);
    expect($('errorEnvio').textContent).toContain('WhatsApp');
    $('campoWhatsapp').value = '11 2345-6789';
    $('campoWhatsapp').dispatchEvent(new dom.window.Event('input'));
    $('formulario').dispatchEvent(new dom.window.Event('submit', { cancelable: true }));
    await esperar();
    const post = llamadas.find((l) => l.init?.method === 'POST');
    expect(post?.url).toBe(`/api/foto-hermanos/${encodeURIComponent(LLAVE)}`);
    expect(JSON.parse(post?.init.body)).toEqual({ quiere: true, email: 'familia@ejemplo.com', whatsapp: '11 2345-6789' });
    expect($('estadoListo').hidden).toBe(false);
    expect($('textoListo').textContent).toContain('te avisamos a familia@ejemplo.com y por WhatsApp al 11 2345-6789');
  });

  it('con «No» se manda sin pedir contacto', async () => {
    const { $, llamadas, esperar, dom } = await abrir(`?f=${encodeURIComponent(LLAVE)}&r=no`);
    $('formulario').dispatchEvent(new dom.window.Event('submit', { cancelable: true }));
    await esperar();
    const post = llamadas.find((l) => l.init?.method === 'POST');
    expect(JSON.parse(post?.init.body)).toEqual({ quiere: false });
    expect($('textoListo').textContent).toContain('no quieren la foto de hermanos');
    expect(dom).toBeTruthy();
  });

  it('sin ninguna casilla tildada no se puede confirmar', async () => {
    const { $ } = await abrir(`?f=${encodeURIComponent(LLAVE)}`);
    expect($('opcionSi').checked).toBe(false);
    expect($('opcionNo').checked).toBe(false);
    expect($('botonConfirmar').disabled).toBe(true);
  });

  it('si ya respondió, lo muestra y deja cambiarlo', async () => {
    const { $ } = await abrir(`?f=${encodeURIComponent(LLAVE)}`, { success: true, chicos: ['Ana', 'Luz'], colegio: '', respuesta: 'si' });
    expect($('avisoYaRespondio').hidden).toBe(false);
    expect($('avisoYaRespondio').textContent).toContain('Ya nos respondiste');
    expect($('opcionSi').checked).toBe(true);
  });

  it('un link roto muestra el error sin llamar al servidor', async () => {
    const { $, llamadas } = await abrir('?f=cualquier-cosa');
    expect($('estadoError').hidden).toBe(false);
    expect(llamadas).toHaveLength(0);
  });
});

// 08/10 (pedido de Pablo): la IA le dijo a una familia que la foto de hermanos «no tiene ningún costo
// extra». Se vende aparte, como un evento (BROTHERS2026-D3EB): la IA toma precios, día y lugar del evento.
describe('IA de consultas: la foto de hermanos tiene costo', () => {
  function cargarDescribir() {
    const bloque = bloqueEntre('function describirEventoFotoHermanos(', 'let cacheEventoFotoHermanos');
    const js = ts.transpileModule(bloque, { compilerOptions: { target: ts.ScriptTarget.ES2020 } }).outputText;
    // eslint-disable-next-line no-new-func
    return new Function(`${js}\nreturn describirEventoFotoHermanos;`)() as (ev: any) => string;
  }

  it('el contexto del negocio dice que no es gratis y ya no la presenta como sin costo', () => {
    const contexto = bloqueEntre('function contextoNegocioConsultas(', '=== CÓMO SE COMPRA ===');
    expect(contexto).toContain('NO es gratis ni está incluida en el kit');
    expect(contexto).toContain('se vende como las fotos de un evento');
    expect(contexto.replace(/\n\s*/g, ' ')).toContain('Nunca digas que la foto de hermanos no tiene costo.');
    // 08/10: «pedirla no obliga a comprarla» confundía (la IA lo copiaba tal cual): se sacó.
    expect(contexto).not.toContain('no obliga a comprarla');
    expect(contexto).toContain('${datosHermanos}');
    expect(contexto).toContain('no inventes montos');
    expect(fuente).not.toContain('- Hay opción de "Foto de Hermanos juntos" si se pidió al inscribirse.');
  });

  it('los usos de la IA (consultas, «Escribir a esta familia» y el panel Emails) le pasan los datos del evento de hermanos', () => {
    expect(fuente).not.toContain('sistema: contextoNegocioConsultas()');
    // 26/10: 4 = borrador común, agente que investiga («Pedir otra a la IA»), «Escribir a esta familia» y panel Emails.
    expect(fuente.match(/sistema: contextoNegocioConsultas\(await textoEventoFotoHermanos\(\)\)/g)).toHaveLength(4);
    const lectura = bloqueEntre('async function textoEventoFotoHermanos(', '// Catálogo y reglas de negocio');
    expect(lectura).toContain(".from('ev_eventos')");
    expect(lectura).toContain(".ilike('nombre', '%herman%')");
    expect(lectura).toContain("return '';");
  });

  it('describe precios, día y lugar del evento', () => {
    const describir = cargarDescribir();
    const sinDia = describir({ precio_digital: 5000, precio_15x21: 8000, precio_20x30: 12000, impresa_incluye_digital: true, fecha_evento: null, lugar: null });
    expect(sinDia).toContain('digital $5.000');
    expect(sinDia).toContain('impresa 15x21 $8.000');
    expect(sinDia).toContain('impresa 20x30 $12.000');
    expect(sinDia).toContain('cada impresa incluye también la digital');
    // 29/10 (Pablo): nunca «el día no está definido»: los días salen de las novedades del equipo y de la ficha.
    expect(sinDia).not.toContain('no están definidos');
    expect(sinDia).toContain('NOVEDADES DEL EQUIPO');
    expect(sinDia).not.toContain('PUBLICADAS');
    const conFotos = describir({ precio_digital: 5000, precio_15x21: 0, precio_20x30: 0, impresa_incluye_digital: false, fecha_evento: null, lugar: null, codigo: 'BROTHERS2026-D3EB', publicado: true, fotos: 465 });
    expect(conFotos).toContain('YA HAY 465 FOTOS DE HERMANOS PUBLICADAS');
    expect(conFotos).toContain('retratoescolar.com.ar/eventos/BROTHERS2026-D3EB');
    const conDia = describir({ precio_digital: 5000, precio_15x21: 0, precio_20x30: 12000, impresa_incluye_digital: false, fecha_evento: '2026-10-24', lugar: 'Estudio Pilar' });
    expect(conDia).not.toContain('15x21');
    expect(conDia).not.toContain('incluye también');
    expect(conDia).toContain('Día y lugar de la foto de hermanos: 24/10/2026, Estudio Pilar.');
  });

  it('sin evento o sin precios no inventa nada', () => {
    const describir = cargarDescribir();
    expect(describir(null)).toBe('');
    expect(describir({ precio_digital: 0, precio_15x21: 0, precio_20x30: 0, impresa_incluye_digital: true, fecha_evento: null, lugar: null })).toBe('');
  });
});
