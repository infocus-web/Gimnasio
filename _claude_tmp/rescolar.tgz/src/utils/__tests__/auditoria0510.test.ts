import { describe, expect, it, vi } from 'vitest';
import { firmaDeCheckout, idsParaCheckout } from '../checkoutEstable';
import { crearReserva } from '../../services/reservasService';
import { normalizarNombreAlumno } from '../nombresAlumno';

// Auditoría 05/10 — portal de familias (bugs 1 y 2).

function respuesta(status: number, cuerpo: unknown): Response {
  return { ok: status >= 200 && status < 300, status, json: async () => cuerpo } as Response;
}

describe('ids del carrito independientes de las reservas sumadas (bug 2a)', () => {
  let n = 0;
  const uuid = () => `uuid-${++n}`;
  const numero = () => `IFS-2026-${1000 + n}`;
  const firma = firmaDeCheckout({ hijo: 'principal', kit: 'kit-clasico', fotos: ['a', 'b', 'c'] }, 'mama@mail.com');

  it('quitar o cambiar la reserva del hermano conserva los ids y la clave del carrito, y sortea sólo los de la reserva', () => {
    const conReserva = idsParaCheckout(null, firma, 2, uuid, numero, 1, undefined, JSON.stringify([['hermano-0', 'kit-clasico', 0]]));
    expect(conReserva.reservaIds).toHaveLength(1);
    // Mismo carrito, misma reserva: mismo objeto (reintento idempotente).
    expect(idsParaCheckout(conReserva, firma, 2, uuid, numero, 1, undefined, JSON.stringify([['hermano-0', 'kit-clasico', 0]]))).toBe(conReserva);
    // "Quitar" la reserva: los ids del carrito NO cambian (antes: ids nuevos → pedidos duplicados).
    const sinReserva = idsParaCheckout(conReserva, firma, 2, uuid, numero, 0, undefined, JSON.stringify([]));
    expect(sinReserva.itemIds).toEqual(conReserva.itemIds);
    expect(sinReserva.itemFriendlyIds).toEqual(conReserva.itemFriendlyIds);
    expect(sinReserva.claveCheckout).toBe(conReserva.claveCheckout);
    expect(sinReserva.numLista).toBe(conReserva.numLista);
    expect(sinReserva.reservaIds).toEqual([]);
    // Cambiar el kit de la reserva: ids nuevos sólo para la reserva.
    const otroKit = idsParaCheckout(conReserva, firma, 2, uuid, numero, 1, undefined, JSON.stringify([['hermano-0', 'kit-digital', 0]]));
    expect(otroKit.itemIds).toEqual(conReserva.itemIds);
    expect(otroKit.claveCheckout).toBe(conReserva.claveCheckout);
    expect(otroKit.reservaIds[0]).not.toBe(conReserva.reservaIds[0]);
    // Cambiar el carrito sí regenera todo.
    const otroCarrito = idsParaCheckout(otroKit, firmaDeCheckout({ hijo: 'principal', kit: 'kit-digital' }, 'mama@mail.com'), 2, uuid, numero, 1, undefined, otroKit.firmaReservas);
    expect(otroCarrito.itemIds[0]).not.toBe(conReserva.itemIds[0]);
    expect(otroCarrito.claveCheckout).not.toBe(conReserva.claveCheckout);
  });

  it('sin firma de reservas (compra de reservas solas) se comporta como antes', () => {
    const a = idsParaCheckout(null, firma, 0, uuid, numero, 2);
    expect(idsParaCheckout(a, firma, 0, uuid, numero, 2)).toBe(a);
    expect(idsParaCheckout(a, firma, 0, uuid, numero, 1).claveCheckout).not.toBe(a.claveCheckout);
  });
});

describe('crearReserva informa si la falla es pasajera (bug 2b)', () => {
  it('4xx del servidor → transitorio: false; 5xx/429/red → transitorio: true', async () => {
    const datos = { tutorNombre: 'T', tutorEmail: 't@m.com', metodoPago: 'mercadopago' as const, items: [] };
    vi.stubGlobal('fetch', vi.fn(async () => respuesta(409, { success: false, error: 'El curso ya tiene fotos' })));
    expect(await crearReserva(datos)).toMatchObject({ success: false, transitorio: false, error: 'El curso ya tiene fotos' });
    vi.stubGlobal('fetch', vi.fn(async () => respuesta(403, { success: false, error: 'Sin llave' })));
    expect((await crearReserva(datos)).transitorio).toBe(false);
    vi.stubGlobal('fetch', vi.fn(async () => respuesta(503, { success: false })));
    expect((await crearReserva(datos)).transitorio).toBe(true);
    vi.stubGlobal('fetch', vi.fn(async () => respuesta(429, { success: false })));
    expect((await crearReserva(datos)).transitorio).toBe(true);
    vi.stubGlobal('fetch', vi.fn(async () => { throw new Error('red'); }));
    expect((await crearReserva(datos)).transitorio).toBe(true);
    vi.unstubAllGlobals();
  });
});

describe('normalizarNombreAlumno (bug 1, red de seguridad)', () => {
  it('detecta el mismo alumno aunque cambie el orden, las mayúsculas o las tildes', () => {
    expect(normalizarNombreAlumno('Sofía Alder')).toBe(normalizarNombreAlumno('ALDER, Sofia'));
    expect(normalizarNombreAlumno('Pablo Alder')).not.toBe(normalizarNombreAlumno('Sofia Alder'));
  });
});
