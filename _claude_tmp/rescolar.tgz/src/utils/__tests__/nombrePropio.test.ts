// 10/10/2026 (pedido de Pablo, probando la inscripción): los nombres que escribe la familia se guardan
// con mayúscula inicial («PABLITA Alderete» → «Pablita Alderete»). Mismo resultado en la web y en el servidor.
import { describe, expect, it } from 'vitest';
import { nombrePropio as enLaWeb } from '../nombresAlumno';
import { nombrePropio as enElServidor } from '../../../servidor/nucleo/nombres';

const CASOS: [string, string][] = [
  ['PABLITA Alderete', 'Pablita Alderete'],
  ['pablita alderete', 'Pablita Alderete'],
  ['  MARÍA   JOSÉ  ', 'María José'],
  ['MARÍA DE LOS ÁNGELES', 'María de los Ángeles'],
  ['DE LA FUENTE', 'De la Fuente'],
  ['maría-josé', 'María-José'],
  ["D'ANGELO", "D'Angelo"],
  ['McDonald', 'McDonald'],
  ['Juan Pérez', 'Juan Pérez'],
  ['ñandú IBÁÑEZ', 'Ñandú Ibáñez'],
  ['', ''],
];

describe('nombrePropio', () => {
  it.each(CASOS)('«%s» → «%s»', (entrada, esperado) => {
    expect(enLaWeb(entrada)).toBe(esperado);
    expect(enElServidor(entrada)).toBe(esperado);
  });
});
