import { beforeEach, describe, expect, it, vi } from 'vitest';
import { esRuidoDeNavegador, reiniciarReportesAutomaticos, reportarAutomaticamente } from '../../services/reporteErrores';

// Reporte automático (2/10): cada error se manda solo, una vez por visita, con tope y sin ruido.
describe('reportarAutomaticamente', () => {
  let enviados: any[];
  beforeEach(() => {
    reiniciarReportesAutomaticos();
    enviados = [];
    global.fetch = vi.fn(async (_url: RequestInfo | URL, init?: RequestInit) => {
      enviados.push(JSON.parse(String(init?.body || '{}')));
      return { ok: true, status: 201, json: async () => ({ success: true, codigo: `ERR-${enviados.length}` }) } as Response;
    }) as unknown as typeof fetch;
  });

  it('manda el reporte marcado como automático y devuelve el código', async () => {
    const codigo = await reportarAutomaticamente('servidor', 'POST /api/pedidos → 500: falló');
    expect(codigo).toBe('ERR-1');
    expect(enviados[0].mensaje).toMatch(/^\[Automático\]/);
    expect(enviados[0].detalle.automatico).toBe(true);
  });

  it('no repite el mismo error (aunque cambien números o ids) y respeta el tope por visita', async () => {
    await reportarAutomaticamente('servidor', 'GET /api/pedidos/123 → 500');
    await reportarAutomaticamente('servidor', 'GET /api/pedidos/456 → 500');
    expect(enviados).toHaveLength(1);
    for (let i = 0; i < 10; i++) await reportarAutomaticamente('javascript', `Error distinto ${'x'.repeat(i)}`);
    expect(enviados).toHaveLength(5);
  });

  it('reconoce el ruido del navegador', () => {
    expect(esRuidoDeNavegador('ResizeObserver loop completed with undelivered notifications.')).toBe(true);
    expect(esRuidoDeNavegador('TypeError Failed to fetch')).toBe(true);
    expect(esRuidoDeNavegador('algo en chrome-extension://abc/script.js')).toBe(true);
    expect(esRuidoDeNavegador('Cannot read properties of undefined')).toBe(false);
  });

  // 13/10: llegaban «[Automático] Script error.» (iPhone, sin archivo ni línea) porque el texto a filtrar era
  // «Script error. » (mensaje + espacio + archivo vacío).
  it('«Script error.» sin archivo (script ajeno) no se reporta; un error nuestro sí', async () => {
    vi.resetModules();
    const mod = await import('../../services/reporteErrores');
    mod.instalarCapturaDeErrores();
    expect(esRuidoDeNavegador('Script error. ')).toBe(true);
    window.dispatchEvent(new ErrorEvent('error', { message: 'Script error.', filename: '', lineno: 0 }));
    await new Promise((r) => setTimeout(r, 0));
    expect(enviados).toHaveLength(0);
    window.dispatchEvent(new ErrorEvent('error', { message: 'Cannot read properties of undefined', filename: `${window.location.origin}/assets/index.js`, lineno: 10 }));
    await vi.waitFor(() => expect(enviados).toHaveLength(1));
    expect(enviados[0].mensaje).toBe('[Automático] Cannot read properties of undefined');
  });
});
