import { readFileSync } from 'fs';
import path from 'path';
import ts from 'typescript';
import { describe, expect, it } from 'vitest';

import { fuenteServidor } from '../../test/fuenteServidor';

// Auditoría 05/10 (panel admin, fotos y laboratorio): server.ts no se puede importar en las
// pruebas (arranca el servidor), así que se extraen las funciones puras nuevas y se verifica el
// texto de las rutas. Mismo patrón que servidorPedidosPagos.test.ts.
const server = fuenteServidor();

function extraerFuncion(nombre: string): string {
  const inicio = server.search(new RegExp(`^(async )?function ${nombre}\\b`, 'm'));
  if (inicio < 0) throw new Error(`No encontré ${nombre} en server.ts`);
  const fin = server.indexOf('\n}\n', inicio);
  return server.slice(inicio, fin + 2);
}

function cargar<T>(nombres: string[]): T {
  const fuente = nombres.map(extraerFuncion).join('\n\n');
  const js = ts.transpileModule(fuente, { compilerOptions: { target: ts.ScriptTarget.ES2020 } }).outputText;
  // eslint-disable-next-line @typescript-eslint/no-implied-eval
  return new Function(`${js}\nreturn { ${nombres.join(', ')} };`)() as T;
}

function rutaDesde(inicio: string, fin: string): string {
  const a = server.indexOf(inicio);
  if (a < 0) throw new Error(`No encontré ${inicio}`);
  const b = server.indexOf(fin, a);
  return server.slice(a, b < 0 ? undefined : b);
}

const { motivoPedidoProtegidoParaBorrar, descartarFotosYaRegistradas, rutasCompartidasConOtrasFotos, claveIdempotenciaActualizacionPedido, agruparAnuladosPorLote } = cargar<{
  motivoPedidoProtegidoParaBorrar: (fila: any) => string | null;
  descartarFotosYaRegistradas: (filas: any[], yaEnBase: Set<string>) => { nuevas: any[]; yaRegistradas: number };
  rutasCompartidasConOtrasFotos: (fotosABorrar: any[], otras: any[]) => Set<string>;
  claveIdempotenciaActualizacionPedido: (tipo: string, pedidoId: string, reenvio: boolean, ahora?: number) => string;
  agruparAnuladosPorLote: (filas: any[]) => Map<string, { friendlyId: string; alumno: string }[]>;
}>(['motivoPedidoProtegidoParaBorrar', 'descartarFotosYaRegistradas', 'rutasCompartidasConOtrasFotos', 'claveIdempotenciaActualizacionPedido', 'agruparAnuladosPorLote']);

describe('bug 1: DELETE /api/admin/pedidos/:id no borra pagados sin confirmación', () => {
  it('un pedido pagado, entregado o ya en un lote del laboratorio queda protegido', () => {
    expect(motivoPedidoProtegidoParaBorrar({ estado: 'pagado' })).toContain('PAGADO');
    expect(motivoPedidoProtegidoParaBorrar({ estado: 'entregado' })).toContain('ENTREGADO');
    expect(motivoPedidoProtegidoParaBorrar({ estado: 'pendiente_pago', lote_lab_id: 'lote-1' })).toContain('laboratorio');
  });

  it('un pendiente de pago, o un cancelado definitivo, se puede borrar', () => {
    expect(motivoPedidoProtegidoParaBorrar({ estado: 'pendiente_pago' })).toBeNull();
    expect(motivoPedidoProtegidoParaBorrar({ estado: 'cancelado', cancelado_definitivo: true, lote_lab_id: 'lote-1' })).toBeNull();
    expect(motivoPedidoProtegidoParaBorrar({ estado: 'pagado', cancelado_definitivo: true })).toBeNull();
  });

  it('la ruta lee el estado antes de borrar, responde 409 PEDIDO_PAGADO y acepta forzar', () => {
    const ruta = rutaDesde("app.delete('/api/admin/pedidos/:id'", "\napp.");
    expect(ruta).toContain("select('id, estado, cancelado_definitivo, lote_lab_id, estado_lab, pedido_friendly_id, comprobante_path')");
    expect(ruta).toContain("codigo: 'PEDIDO_PAGADO'");
    expect(ruta).toContain('status(409)');
    expect(ruta).toContain("req.query.forzar === '1'");
    expect(ruta).toContain('forzar === true');
    // El borrado va después del control, no antes.
    expect(ruta.indexOf('motivoPedidoProtegidoParaBorrar(')).toBeLessThan(ruta.indexOf("from('pedido_fotos').delete()"));
  });

  it('el panel reintenta con forzar sólo tras la confirmación específica y saltea pagados en bloque', () => {
    const modal = readFileSync(path.resolve(__dirname, '../../components/AdminModal.tsx'), 'utf8').replace(/\r\n/g, '\n');
    expect(modal).toContain("resultado.codigo === 'PEDIDO_PAGADO'");
    expect(modal).toContain('Este pedido está PAGADO');
    expect(modal).toContain('eliminarPedidoAdminConControl(pedido.supabaseId || pedido.id, true)');
    expect(modal).toContain("estadoPago === 'aprobado'");
    expect(modal).toContain('pagadosSalteados');
    expect(modal).not.toContain('eliminarPedidoAdmin(');
    const servicio = readFileSync(path.resolve(__dirname, '../../services/pedidosLabService.ts'), 'utf8');
    expect(servicio).toContain("${forzar ? '?forzar=1' : ''}");
  });
});

describe('bug 2: dos filas de fotos con el mismo storage_path', () => {
  it('registrar fotos descarta las que ya están en la base y las repetidas en la misma tanda', () => {
    const filas = [
      { storage_path: '2026/a.jpg', categoria: 'individual' },
      { storage_path: '2026/b.jpg', categoria: 'individual' },
      { storage_path: '2026/a.jpg', categoria: 'individual' },
      { storage_path: '2026/c.jpg', categoria: 'grupal' },
    ];
    const r = descartarFotosYaRegistradas(filas, new Set(['2026/b.jpg']));
    expect(r.nuevas.map((f) => f.storage_path)).toEqual(['2026/a.jpg', '2026/c.jpg']);
    expect(r.yaRegistradas).toBe(2);
  });

  it('la ruta de registro consulta por storage_path antes del insert y devuelve yaRegistradas', () => {
    const ruta = rutaDesde("app.post('/api/admin/fotos', requireAdminAuth", "\napp.");
    expect(ruta).toContain(".in('storage_path', grupo)");
    expect(ruta).toContain('yaRegistradas: yaRegistradas + ignoradasEnCarrera,');
    // 08/10: el insert ignora los repetidos (índice único fotos_storage_path_unico).
    expect(ruta.indexOf('descartarFotosYaRegistradas(')).toBeLessThan(ruta.indexOf(".upsert(filasAInsertar, { onConflict: 'storage_path', ignoreDuplicates: true })"));
  });

  it('al borrar, los archivos que otra fila sigue usando no se tocan', () => {
    const aBorrar = [{ id: 'f1', storage_path: '2026/a.jpg', preview_path: 'https://x/fotos-web/2026/a-web.jpg', thumb_path: 'https://x/fotos-web/2026/a-thumb.jpg' }];
    const otras = [
      // La misma fila que se borra no cuenta.
      { id: 'f1', storage_path: '2026/a.jpg', preview_path: 'https://x/fotos-web/2026/a-web.jpg', thumb_path: 'https://x/fotos-web/2026/a-thumb.jpg' },
      // La duplicada: comparte el HD y la muestra, pero tiene otra miniatura.
      { id: 'f2', storage_path: '2026/a.jpg', preview_path: 'https://x/fotos-web/2026/a-web.jpg', thumb_path: 'https://x/fotos-web/2026/otra-thumb.jpg' },
    ];
    const compartidas = rutasCompartidasConOtrasFotos(aBorrar, otras);
    expect(compartidas.has('2026/a.jpg')).toBe(true);
    expect(compartidas.has('https://x/fotos-web/2026/a-web.jpg')).toBe(true);
    expect(compartidas.has('https://x/fotos-web/2026/a-thumb.jpg')).toBe(false);
  });

  it('en el borrado en bloque, dos duplicadas borradas juntas sí liberan el archivo', () => {
    const aBorrar = [{ id: 'f1', storage_path: '2026/a.jpg' }, { id: 'f2', storage_path: '2026/a.jpg' }];
    expect(rutasCompartidasConOtrasFotos(aBorrar, aBorrar).size).toBe(0);
  });

  it('los dos borrados consultan las rutas compartidas antes de storage.remove', () => {
    const individual = rutaDesde("app.delete('/api/admin/fotos/:id'", "\nfunction pedidosQueUsanFoto");
    expect(individual.indexOf('buscarFotosQueCompartenRutas(')).toBeLessThan(individual.indexOf("storage.from('fotos-web').remove"));
    expect(individual).toContain("foto.storage_path && !compartidas.has(String(foto.storage_path))");
    const bloque = rutaDesde("app.post('/api/admin/fotos/borrar'", "\napp.");
    expect(bloque.indexOf('buscarFotosQueCompartenRutas(')).toBeLessThan(bloque.indexOf("from('fotos').delete().in('id'"));
    expect(bloque).toContain("foto.storage_path && !compartidas.has(String(foto.storage_path))");
  });
});

describe('bug 3: mejoras a Kit Impreso sin .zip propio', () => {
  it('salud, generar-zip-hd y reenviar-link excluyen mejora_de_pedido_id', () => {
    // 29/10/2026: también los pedidos de fotos extra (copias impresas, sin .zip).
    expect(server).toContain(".is('mejora_de_pedido_id', null).neq('tipo_kit', 'fotos_extra').or('link_descarga_hd.is.null,link_descarga_hd.eq.')");
    const zip = rutaDesde("app.post('/api/admin/pedidos/:id/generar-zip-hd'", "\napp.");
    expect(zip).toContain('if (pedido.mejora_de_pedido_id)');
    expect(zip.indexOf('pedido.mejora_de_pedido_id')).toBeLessThan(zip.indexOf('generarYSubirZipHDParaPedido('));
    const reenviar = rutaDesde("app.post('/api/pedidos/reenviar-link'", "\napp.");
    expect(reenviar).toContain('fila.seleccion_pendiente || esPedidoAdicional(fila)'); // 29/10: mejora o fotos extra
    const tab = readFileSync(path.resolve(__dirname, '../../components/AdminLaboratorioTab.tsx'), 'utf8');
    expect(tab).toContain('!p.mejoraDePedidoId');
  });
});

describe('bug 4: reenvío de etapa el mismo día', () => {
  it('la clave diaria se mantiene para el flujo automático y el reenvío lleva el tramo de 2 minutos (14/10)', () => {
    const ahora = Date.parse('2026-10-05T15:30:00Z');
    expect(claveIdempotenciaActualizacionPedido('en_produccion', 'p1', false, ahora)).toBe('estado-en_produccion-p1-2026-10-05');
    expect(claveIdempotenciaActualizacionPedido('en_produccion', 'p1', true, ahora)).toBe(`estado-en_produccion-p1-2026-10-05-r${Math.floor(ahora / 120_000)}`);
    expect(claveIdempotenciaActualizacionPedido('en_produccion', 'p1', true, ahora + 1000)).toBe(claveIdempotenciaActualizacionPedido('en_produccion', 'p1', true, ahora));
  });

  it('notificar-estado marca como reenvío cuando el pedido ya estaba en esa etapa (y el panel lo pidió, 14/10)', () => {
    expect(server).toContain('const esReenvio = supabase !== null && estadosActuales.get(destinatario.pedidoId) === tipo;');
    expect(server).toContain('if (esReenvio && !reenvioPedido) { yaAvisados.push(String(destinatario.pedidoId)); continue; }');
    expect(server).toContain('reenvio: esReenvio');
  });
});

describe('bug 6: pedidos anulados después de entrar a un lote', () => {
  it('agrupa por lote sólo los que ya no están pagados/entregados', () => {
    const r = agruparAnuladosPorLote([
      { id: 'a', pedido_friendly_id: 'IFS-1', alumno_nombre: 'Ana', estado: 'cancelado', lote_lab_id: 'L1' },
      { id: 'b', pedido_friendly_id: 'IFS-2', alumno_nombre: 'Bruno', estado: 'pagado', lote_lab_id: 'L1' },
      { id: 'c', pedido_friendly_id: null, alumno_nombre: 'Cami', estado: 'pendiente_pago', lote_lab_id: 'L2' },
      { id: 'd', pedido_friendly_id: 'IFS-4', alumno_nombre: 'Dani', estado: 'cancelado', lote_lab_id: null },
    ]);
    expect(r.get('L1')).toEqual([{ friendlyId: 'IFS-1', alumno: 'Ana' }]);
    expect(r.get('L2')).toEqual([{ friendlyId: 'c', alumno: 'Cami' }]);
    expect(r.size).toBe(2);
  });

  it('la lista de lotes del laboratorio incluye anulados y el panel los muestra', () => {
    const ruta = rutaDesde("app.get('/api/lab/pedidos'", "\napp.");
    expect(ruta).toContain('anulados: anuladosPorLote.get(l.id) || []');
    const panel = readFileSync(path.resolve(__dirname, '../../components/PanelLaboratorio.tsx'), 'utf8');
    expect(panel).toContain('después de armarlo: no imprimirlo');
  });
});
