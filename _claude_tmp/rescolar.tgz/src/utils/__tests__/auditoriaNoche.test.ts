import { afterEach, describe, expect, it, vi } from 'vitest';
import { firmaDeCheckout, idsParaCheckout, nuevaClaveCheckout } from '../checkoutEstable';
import { borrarLlavesPedidos, guardarLlavePedido, obtenerLlavePedido } from '../accesoPedido';
import { registrarCarritoMultipleDesdePortal, registrarPedidoDesdePortal } from '../../services/pedidosLabService';
import { crearReserva, elegirFotosDeReserva, obtenerEstadoReserva } from '../../services/reservasService';
import { buscarMiInscripcion, confirmarAccesoInscripcion, obtenerHijosDeFamiliaConEstado } from '../../services/inscripcionesService';

// Auditoría 03/10 noche — lado del navegador de los contratos 1-7 (equipo PORTAL).

function respuesta(status: number, cuerpo: unknown): Response {
  return { ok: status >= 200 && status < 300, status, json: async () => cuerpo } as Response;
}
function cuerpoDe(fetchMock: ReturnType<typeof vi.fn>, llamada = 0) {
  return JSON.parse(String((fetchMock.mock.calls[llamada] as unknown as [string, RequestInit])[1].body));
}

afterEach(() => {
  vi.unstubAllGlobals();
  window.history.replaceState(null, '', '/');
});

describe('claveCheckout (contrato 1, A1)', () => {
  let n = 0;
  const uuid = () => `uuid-${++n}`;
  const numero = () => `IFS-2026-${1000 + n}`;

  it('es un secreto de 32 hex al azar', () => {
    const a = nuevaClaveCheckout();
    expect(a).toMatch(/^[0-9a-f]{32}$/);
    expect(nuevaClaveCheckout()).not.toBe(a);
  });

  it('se mantiene igual en los reintentos del mismo checkout', () => {
    const firma = firmaDeCheckout({ kit: 'kit-clasico', fotos: ['a', 'b', 'c'] }, 'mama@mail.com');
    const primero = idsParaCheckout(null, firma, 1, uuid, numero);
    const reintento = idsParaCheckout(primero, firmaDeCheckout({ kit: 'kit-clasico', fotos: ['a', 'b', 'c'] }, 'mama@mail.com'), 1, uuid, numero);
    expect(primero.claveCheckout).toMatch(/^[0-9a-f]{32}$/);
    expect(reintento.claveCheckout).toBe(primero.claveCheckout);
    expect(reintento.pedidoId).toBe(primero.pedidoId);
  });

  it('cambia junto con los ids cuando cambia el checkout (kit, hijos, reservas o email)', () => {
    const primero = idsParaCheckout(null, firmaDeCheckout({ kit: 'kit-clasico' }), 1, uuid, numero);
    const otroKit = idsParaCheckout(primero, firmaDeCheckout({ kit: 'kit-digital' }), 1, uuid, numero);
    expect(otroKit.pedidoId).not.toBe(primero.pedidoId);
    expect(otroKit.claveCheckout).not.toBe(primero.claveCheckout);
    const conReserva = idsParaCheckout(otroKit, otroKit.firma, 1, uuid, numero, 1);
    expect(conReserva.claveCheckout).not.toBe(otroKit.claveCheckout);
    const otroEmail = idsParaCheckout(conReserva, firmaDeCheckout({ kit: 'kit-digital' }, 'otro@mail.com'), 1, uuid, numero, 1);
    expect(otroEmail.claveCheckout).not.toBe(conReserva.claveCheckout);
  });

  it('viaja en /api/pedidos/crear, en la raíz de /crear-multiple y en la raíz de /api/reservas/crear', async () => {
    const fetchMock = vi.fn(async () => respuesta(200, { success: true, pedidoId: 'p1', grupoPagoId: 'g1', pedidoIds: ['p1'], pedidoFriendlyIds: ['IFS-2026-1'], total: 30000 }));
    vi.stubGlobal('fetch', fetchMock);
    const clave = 'a'.repeat(32);
    const base = {
      colegioId: 'c1', colegioNombre: 'Colegio', cursoCodigo: 'GRADO1-A', grado: '1°', division: 'A', turno: 'Mañana',
      alumnoNombre: 'Ana', tutorNombre: 'Tutor', tutorTelefono: '11', tutorEmail: 't@x.com', kitId: 'kit-clasico', kitNombre: 'Kit',
      metodoPago: 'mercadopago' as const, fotosSeleccionadas: { individualId: 'i', grupalId: 'g', docenteId: 'd' },
    };
    await registrarPedidoDesdePortal({ ...base, total: 1, claveCheckout: clave });
    expect(cuerpoDe(fetchMock, 0).claveCheckout).toBe(clave);
    await registrarCarritoMultipleDesdePortal({ tutorNombre: 'T', tutorTelefono: '1', tutorEmail: 't@x.com', items: [base], claveCheckout: clave });
    const multiple = cuerpoDe(fetchMock, 1);
    expect(multiple.claveCheckout).toBe(clave);
    expect(multiple.items[0].claveCheckout).toBeUndefined();
    await crearReserva({ tutorNombre: 'T', tutorEmail: 't@x.com', metodoPago: 'transferencia', items: [{ codigoSeccion: 'X', alumnoNombre: 'Ana', kitId: 'kit-digital' }], claveCheckout: clave });
    expect(cuerpoDe(fetchMock, 2).claveCheckout).toBe(clave);
  });
});

describe('totales del servidor (contrato 7, M7/H6)', () => {
  it('el pedido registrado guarda el total del servidor, no el calculado en el navegador', async () => {
    vi.stubGlobal('fetch', vi.fn(async () => respuesta(200, { success: true, pedidoId: 'p1', pedidoFriendlyId: 'IFS-2026-1', total: 30000 })));
    const r = await registrarPedidoDesdePortal({
      colegioId: 'c1', colegioNombre: 'Colegio', cursoCodigo: 'GRADO1-A', grado: '1°', division: 'A', turno: 'Mañana',
      alumnoNombre: 'Ana', tutorNombre: 'Tutor', tutorTelefono: '11', tutorEmail: 't@x.com', kitId: 'kit-clasico', kitNombre: 'Kit',
      total: 99999, metodoPago: 'transferencia', fotosSeleccionadas: { individualId: 'i', grupalId: 'g', docenteId: 'd' },
    });
    expect(r.sincronizado).toBe(true);
    expect(r.pedido.total).toBe(30000);
    expect(JSON.parse(localStorage.getItem('infocus_pedidos_escolares_v1') || '[]')[0].total).toBe(30000);
  });
});

describe('login (contratos 2, 3 y 4)', () => {
  it('email sin confirmar: devuelve el aviso del servidor (no "no encontrado")', async () => {
    vi.stubGlobal('fetch', vi.fn(async () => respuesta(200, { success: false, requiereConfirmacion: true, error: 'Confirmá tu email: te mandamos un correo.' })));
    const r = await buscarMiInscripcion('ABCD-1234', 'Ana Pérez', '30111222');
    expect(r.requiereConfirmacion).toBe(true);
    expect(r.avisoConfirmacion).toBe('Confirmá tu email: te mandamos un correo.');
    expect(r.encontrada).toBe(false);
  });

  it('por teléfono/email sólo llega { estado, colegio_nombre }: no arma una familia vacía', async () => {
    vi.stubGlobal('fetch', vi.fn(async () => respuesta(200, { success: true, inscripcion: { estado: 'pendiente', colegio_nombre: 'Colegio Sol' } })));
    const r = await buscarMiInscripcion('mama@mail.com');
    expect(r.inscripcion).toBeUndefined();
    expect(r.estadoInscripcion).toEqual({ estado: 'pendiente', colegioNombre: 'Colegio Sol' });
  });

  it('confirmar-acceso manda id, token y DNI (sólo números) y devuelve el código', async () => {
    const fetchMock = vi.fn(async () => respuesta(200, { success: true, codigo: 'ABCD-1234' }));
    vi.stubGlobal('fetch', fetchMock);
    const r = await confirmarAccesoInscripcion('insc-1.tok.en', '30.111.222');
    expect(r).toEqual({ success: true, codigo: 'ABCD-1234' });
    expect((fetchMock.mock.calls[0] as unknown as [string])[0]).toBe('/api/inscripciones/confirmar-acceso');
    expect(cuerpoDe(fetchMock)).toEqual({ id: 'insc-1', token: 'tok.en', dni: '30111222' });
    expect((await confirmarAccesoInscripcion('sinpunto', '30111222')).success).toBe(false);
    // Sin DNI (o corto) no se llama al servidor.
    expect((await confirmarAccesoInscripcion('insc-1.tok', '123')).requiereDni).toBe(true);
    expect(fetchMock).toHaveBeenCalledTimes(1);
  });

  it('confirmar-acceso con DNI que no coincide devuelve el error del servidor tal cual', async () => {
    vi.stubGlobal('fetch', vi.fn(async () => respuesta(409, { success: false, dniNoCoincide: true, error: 'El DNI no coincide con el de la inscripción.' })));
    const r = await confirmarAccesoInscripcion('insc-1.tok', '30111222');
    expect(r).toMatchObject({ success: false, dniNoCoincide: true, error: 'El DNI no coincide con el de la inscripción.' });
  });

  it('elegir las fotos de una reserva pagada manda familia + acceso sólo si están', async () => {
    const fetchMock = vi.fn(async () => respuesta(200, { success: true, pedidoFriendlyId: 'IFS-2026-1' }));
    vi.stubGlobal('fetch', fetchMock);
    const fotos = { grupalId: 'g', individualId: 'i', docenteId: 'd' };
    await elegirFotosDeReserva('r1', 'COD', fotos, true, { familia: 'insc-1', acceso: 'llave' });
    expect(cuerpoDe(fetchMock, 0)).toMatchObject({ codigo: 'COD', fotos, confirmaPersonalizacion: true, familia: 'insc-1', acceso: 'llave' });
    await elegirFotosDeReserva('r1', 'COD', fotos, true, { familia: 'insc-1', acceso: null });
    const sinLlave = cuerpoDe(fetchMock, 1);
    expect(sinLlave.familia).toBeUndefined();
    expect(sinLlave.acceso).toBeUndefined();
    await elegirFotosDeReserva('r1', 'COD', fotos, true);
    expect(cuerpoDe(fetchMock, 2)).toMatchObject({ codigo: 'COD', fotos });
  });
});

describe('reservas/pendiente con la llave de la familia (contrato 5)', () => {
  it('manda familia + acceso y lee tienePedidoPendiente', async () => {
    const fetchMock = vi.fn(async () => respuesta(200, { success: true, reserva: null, fotosDisponibles: true, tienePedidoPagado: false, tienePedidoPendiente: true }));
    vi.stubGlobal('fetch', fetchMock);
    const estado = await obtenerEstadoReserva('X', 'Ana', { familia: 'insc-1', acceso: 'llave' });
    expect(estado.tienePedidoPendiente).toBe(true);
    const url = new URL(String((fetchMock.mock.calls[0] as unknown as [string])[0]), 'http://x');
    expect(url.searchParams.get('familia')).toBe('insc-1');
    expect(url.searchParams.get('acceso')).toBe('llave');
  });

  it('si el servidor rechaza la llave, reintenta sin ella y la reserva PAGADA sigue apareciendo', async () => {
    const fetchMock = vi.fn(async (url: string) =>
      url.includes('acceso=')
        ? respuesta(403, { success: false })
        : respuesta(200, { success: true, fotosDisponibles: true, tienePedidoPagado: false, reserva: { id: 'r1', pedidoFriendlyId: 'IFS-2026-1', kitNombre: 'Kit', total: 30000, pagada: true } })
    );
    vi.stubGlobal('fetch', fetchMock);
    const estado = await obtenerEstadoReserva('X', 'Ana', { familia: 'insc-1', acceso: 'vieja' });
    expect(estado.ok).toBe(true);
    expect(estado.reserva?.pagada).toBe(true);
    expect(fetchMock).toHaveBeenCalledTimes(2);
  });
});

describe('hermanos (R12) y llaves (M11)', () => {
  it('una falla pasajera de /api/familia/hijos no es "hijo único"', async () => {
    vi.stubGlobal('fetch', vi.fn(async () => respuesta(503, { success: false })));
    const r = await obtenerHijosDeFamiliaConEstado('ABCD', 'insc-1', 'llave');
    expect(r.falloTransitorio).toBe(true);
    expect(r.hijos).toEqual([]);
  });

  it('borrarLlavesPedidos borra las llaves HD guardadas', () => {
    guardarLlavePedido(['p1'], 'llave-1');
    expect(obtenerLlavePedido('p1')).toBe('llave-1');
    borrarLlavesPedidos();
    expect(localStorage.getItem('retrato_llaves_pedidos')).toBeNull();
    expect(obtenerLlavePedido('p1')).toBeNull();
  });
});
