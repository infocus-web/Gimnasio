import { describe, expect, it } from 'vitest';
import {
  ErrorSinReintento,
  conReintentos,
  desambiguarNombresArchivos,
  dividirEnPartes,
  ejecutarConConcurrencia,
  enTandas,
  repetirMientrasHayaRestantes,
} from '../descargasLote';

// Auditoría 03/10: utilidades para ZIP por partes, subidas por tandas y bucles de "restantes".
describe('descargasLote', () => {
  it('parte en tandas y en partes', () => {
    expect(enTandas([1, 2, 3, 4, 5], 2)).toEqual([[1, 2], [3, 4], [5]]);
    expect(dividirEnPartes([], 150)).toEqual([]);
    expect(dividirEnPartes(Array.from({ length: 301 }, (_, i) => i), 150).map((p) => p.length)).toEqual([150, 150, 1]);
  });

  it('nunca corre más tareas que el límite y respeta el orden', async () => {
    let enCurso = 0;
    let maximo = 0;
    const r = await ejecutarConConcurrencia([1, 2, 3, 4, 5, 6, 7, 8, 9], 4, async (n) => {
      enCurso++;
      maximo = Math.max(maximo, enCurso);
      await new Promise((res) => setTimeout(res, 2));
      enCurso--;
      return n * 2;
    });
    expect(maximo).toBeLessThanOrEqual(4);
    expect(r).toEqual([2, 4, 6, 8, 10, 12, 14, 16, 18]);
  });

  it('deja sin arrancar lo que sobra cuando se pide parar', async () => {
    let hechos = 0;
    const r = await ejecutarConConcurrencia([1, 2, 3, 4, 5], 1, async (n) => {
      hechos++;
      return n;
    }, { debeParar: () => hechos >= 2 });
    expect(r).toEqual([1, 2, undefined, undefined, undefined]);
  });

  it('reintenta errores pasajeros pero no los definitivos', async () => {
    let intentos = 0;
    await expect(
      conReintentos(async () => {
        intentos++;
        if (intentos < 3) throw new Error('503');
        return 'ok';
      }, { esperaBaseMs: 0 })
    ).resolves.toBe('ok');
    expect(intentos).toBe(3);

    let intentos404 = 0;
    await expect(
      conReintentos(async () => {
        intentos404++;
        throw new ErrorSinReintento('404');
      }, { esperaBaseMs: 0 })
    ).rejects.toThrow('404');
    expect(intentos404).toBe(1);
  });

  it('repite mientras el servidor devuelva restantes, con tope', async () => {
    const llamadas: string[][] = [];
    const r = await repetirMientrasHayaRestantes<string[], { restantes?: string[] }>(
      ['a', 'b', 'c'],
      async (pendientes) => {
        llamadas.push(pendientes);
        return { restantes: pendientes.slice(1) };
      },
      { hayMas: (x) => Boolean(x && x.length > 0) }
    );
    expect(llamadas).toEqual([['a', 'b', 'c'], ['b', 'c'], ['c']]);
    expect(r.cortadoPorTope).toBe(false);

    const tope = await repetirMientrasHayaRestantes<number, { restantes?: number }>(5, async () => ({ restantes: 5 }), {
      maxVueltas: 3,
      hayMas: (x) => Number(x) > 0,
    });
    expect(tope.ultimas).toHaveLength(3);
    expect(tope.cortadoPorTope).toBe(true);
  });

  it('agrega el número de pedido sólo a los nombres que chocan entre pedidos', () => {
    const pedidos = [
      { id: 'IFS-2026-4266', archivosParaLaboratorio: [{ nombreArchivoLab: '3ATT_JUAN_PEREZ.jpg' }, { nombreArchivoLab: '3ATT_JUAN_PEREZ_GRUPAL.jpg' }] },
      { id: 'IFS-2026-9001', archivosParaLaboratorio: [{ nombreArchivoLab: '3ATT_JUAN_PEREZ.jpg' }] },
      { id: 'IFS-2026-1111', archivosParaLaboratorio: [{ nombreArchivoLab: '3ATT_ANA_GOMEZ.jpg' }] },
    ];
    const r = desambiguarNombresArchivos(pedidos);
    expect(r[0].archivosParaLaboratorio.map((a) => a.nombreArchivoLab)).toEqual(['3ATT_JUAN_PEREZ_P4266.jpg', '3ATT_JUAN_PEREZ_GRUPAL.jpg']);
    expect(r[1].archivosParaLaboratorio[0].nombreArchivoLab).toBe('3ATT_JUAN_PEREZ_P9001.jpg');
    expect(r[2]).toBe(pedidos[2]);
  });
});
