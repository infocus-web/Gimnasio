// 10/10/2026 (pedido de Pablo, probando una reserva): la regla «si un hijo ya tiene fotos online sin
// comprar, primero se eligen esas fotos y la reserva se suma a esa compra» sólo mira los hijos del MISMO
// colegio que la reserva. Antes un hijo de otro colegio con el mismo email (en su prueba, uno del colegio
// oculto de laboratorio) frenaba la reserva con un aviso que no se podía resolver desde esa pantalla.
import { describe, expect, it } from 'vitest';
import { fuenteServidor } from '../../test/fuenteServidor';

describe('reserva con hermanos que ya tienen fotos online', () => {
  const codigo = fuenteServidor();
  const inicio = codigo.indexOf('if (!grupoExistente) {');
  const tramo = codigo.slice(inicio, codigo.indexOf('// Si la familia había empezado una reserva', inicio));

  it('sólo cuenta los hijos del mismo colegio que la reserva', () => {
    expect(inicio).toBeGreaterThan(0);
    expect(tramo).toContain('const colegiosDeLaReserva = new Set(resueltos.map((r) => String(r.colegio.id)));');
    expect(tramo).toContain('if (!colegiosDeLaReserva.has(String(chico.colegioId))) continue;');
    // El filtro va antes de buscar fotos o compras de ese chico.
    expect(tramo.indexOf('colegiosDeLaReserva.has')).toBeLessThan(tramo.indexOf('cursoTieneFotosDelPack'));
  });

  it('el aviso dice cómo seguir', () => {
    expect(tramo).toContain('Elegí primero sus fotos (botón «Ver sus fotos»');
    expect(tramo).toContain('sumá esta reserva: pagás todo junto');
  });
});
