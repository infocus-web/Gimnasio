/**
 * Auditoría 03/10 (alto 22): ningún fetch del portal de familias tenía tiempo máximo. Con la señal
 * mala del celular (o el servidor colgado) los botones quedaban en "Cargando…" para siempre y la
 * familia no sabía si reintentar. Este helper corta el pedido a los `ms` milisegundos (15 s por
 * defecto; las subidas de archivos usan más) con un AbortController, respetando además la señal que
 * mande quien llama.
 *
 * Cuando se corta por tiempo tira un `ErrorTiempoAgotado` (no un AbortError genérico) para que
 * la pantalla pueda decir "el servidor tardó demasiado" en vez de un error técnico.
 */
export const TIMEOUT_FETCH_MS = 15_000;
export const TIMEOUT_SUBIDA_MS = 60_000;

export class ErrorTiempoAgotado extends Error {
  constructor(ms: number) {
    super(`El servidor tardó demasiado en responder (más de ${Math.round(ms / 1000)} s). Revisá tu conexión e intentá de nuevo.`);
    this.name = 'ErrorTiempoAgotado';
  }
}

export async function fetchConTimeout(input: RequestInfo | URL, init: RequestInit = {}, ms: number = TIMEOUT_FETCH_MS): Promise<Response> {
  if (typeof AbortController === 'undefined') return fetch(input, init);
  const controlador = new AbortController();
  let vencido = false;
  const temporizador = setTimeout(() => {
    vencido = true;
    controlador.abort();
  }, ms);
  const senalExterna = init.signal;
  const alAbortarExterna = () => controlador.abort();
  if (senalExterna) {
    if (senalExterna.aborted) controlador.abort();
    else senalExterna.addEventListener('abort', alAbortarExterna, { once: true });
  }
  try {
    return await fetch(input, { ...init, signal: controlador.signal });
  } catch (err) {
    if (vencido) throw new ErrorTiempoAgotado(ms);
    throw err;
  } finally {
    clearTimeout(temporizador);
    senalExterna?.removeEventListener('abort', alAbortarExterna);
  }
}

/** Errores pasajeros (vale la pena reintentar): sin red, tiempo agotado, 429 o 5xx. */
export function esStatusTransitorio(status: number): boolean {
  return status === 429 || status === 408 || status >= 500;
}

export const MENSAJE_DEMASIADOS_INTENTOS = 'Demasiados intentos, esperá unos minutos y volvé a probar.';
