/**
 * 25/10/2026 (Pablo): número visible de cada foto, para que la familia diga «quiero la N° 3486» y el
 * equipo la encuentre de una. Sale del nombre del archivo original («FOTO-3486.jpg» → «3486»; las copias
 * del buscador por rostro, «FOTO-3486__rostro.jpg», dan el mismo número). Sin número en el nombre: null.
 */
export function numeroDeFoto(nombreOriginal: string | null | undefined): string | null {
  const base = String(nombreOriginal || '').replace(/\.[^./\\]+$/, '').split('__')[0];
  const numeros = base.match(/\d+/g);
  return numeros ? numeros[numeros.length - 1].replace(/^0+(?=\d)/, '') : null;
}
