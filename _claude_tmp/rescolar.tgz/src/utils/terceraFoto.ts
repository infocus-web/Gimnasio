/**
 * 06/10/2026 (pedido de Pablo, consulta real de una familia de secundaria): en secundaria no se
 * sacan fotos con el docente. La 3ª foto del kit puede ser «con la seño» (categoría `docente`) o
 * «con familia y/o amigos» (categoría `familia`). Las dos las ve todo el curso y cualquier familia
 * del curso las puede elegir (así un compañero puede elegir la foto en la que salió con su amigo).
 *
 * En el pedido la 3ª foto sigue guardándose en `docenteId` (es el lugar de la 3ª foto) para no tocar
 * pedidos viejos, el laboratorio ni las copias extra (`docente15x21`). Debe coincidir con
 * `esCategoriaTerceraFoto` de server.ts.
 */
export type CategoriaTerceraFoto = 'docente' | 'familia';

export function esTerceraFoto(categoria: unknown): categoria is CategoriaTerceraFoto {
  return categoria === 'docente' || categoria === 'familia';
}

/** Paso del pack al que va una foto en el portal: las de familia/amigos van en el paso de la 3ª foto. */
export function pasoDelPack<T extends string>(categoria: T): T | 'docente' {
  return categoria === 'familia' ? 'docente' : categoria;
}

export interface TextosTerceraFoto {
  /** Para la casilla del pack («3/3 Con Seño»). */
  corto: string;
  /** Título («Con la seño»). */
  titulo: string;
  /** «una foto con la seño» (para «Elegí …»). */
  una: string;
  /** «la foto con la seño» (para «Ahora elegí …»). */
  la: string;
  /** Aviso al elegirla. */
  elegida: string;
}

/** Cómo se nombra la 3ª foto según lo que haya en el curso (si no hay ninguna, «con la seño»). */
export function textosTerceraFoto(categorias: Iterable<unknown>): TextosTerceraFoto {
  let hayDocente = false;
  let hayFamilia = false;
  for (const c of categorias) {
    if (c === 'docente') hayDocente = true;
    else if (c === 'familia') hayFamilia = true;
  }
  if (hayFamilia && !hayDocente) {
    return {
      corto: 'Familia/Amigos',
      titulo: 'Con familia y/o amigos',
      una: 'una foto con familia y/o amigos',
      la: 'la foto con familia y/o amigos',
      elegida: 'Foto con familia/amigos elegida',
    };
  }
  if (hayFamilia && hayDocente) {
    return {
      corto: 'Seño o Amigos',
      titulo: 'Con la seño o con familia/amigos',
      una: 'una foto con la seño o con familia/amigos',
      la: 'la foto con la seño o con familia/amigos',
      elegida: '3ª foto elegida',
    };
  }
  return {
    corto: 'Con Seño',
    titulo: 'Con la seño',
    una: 'una foto con la seño',
    la: 'la foto con la seño',
    elegida: 'Foto con la seño elegida',
  };
}

/** Nombre corto de una 3ª foto ya elegida, según su categoría real (resumen del pedido). */
export function etiquetaTerceraFoto(categoria: unknown): string {
  if (categoria === 'familia') return 'Con familia/amigos';
  if (categoria === 'docente') return 'Con docente';
  return '3ª foto';
}
