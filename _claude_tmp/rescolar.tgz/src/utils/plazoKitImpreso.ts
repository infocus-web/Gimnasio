// 26/10/2026 (Pablo): las fotos del KIT IMPRESO se eligen hasta el 15/11/2026 inclusive (hora de Argentina), para que
// entren en la impresión; el Solo Digital no tiene límite. Debe coincidir con servidor/pagos/plazoKitImpreso.ts.
// 30/10/2026: la fecha se edita desde el panel → Configuración (utils/plazosTemporada.ts).
import { finDelDia, plazosVigentes } from './plazosTemporada';

export function plazoKitImpresoAbierto(ahora: Date = new Date()): boolean {
  return ahora.getTime() <= finDelDia(plazosVigentes().kitImpreso);
}

/** Pasado el plazo, el Kit Impreso no se ofrece (el servidor también lo rechaza). */
export function kitOfrecido(kitId: string, ahora: Date = new Date()): boolean {
  return kitId !== 'kit-clasico' || plazoKitImpresoAbierto(ahora);
}
