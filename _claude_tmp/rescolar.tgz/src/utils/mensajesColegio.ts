/**
 * Mensajes de difusión del panel del colegio (10/10/2026, pedido de Pablo). La secretaría o la docente
 * los copia o los comparte por WhatsApp en el grupo de cada curso: no hay número ni envío automático.
 * NO llevan el código del curso: ese código le llega por email sólo a cada familia inscripta (cláusula
 * SÉPTIMA del convenio).
 */

export type TipoMensajeColegio = 'inscripcion' | 'fotos' | 'cierre' | 'entrega';

export const MENSAJES_COLEGIO: { tipo: TipoMensajeColegio; titulo: string; cuando: string }[] = [
  { tipo: 'inscripcion', titulo: 'Inscribirse', cuando: 'Antes de la toma de fotos' },
  { tipo: 'fotos', titulo: 'Ya están las fotos', cuando: 'Cuando se publican las fotos' },
  { tipo: 'cierre', titulo: 'Último día para pedir', cuando: 'Unos días antes del cierre' },
  { tipo: 'entrega', titulo: 'Entrega de kits', cuando: 'Cuando llegan los kits al colegio' },
];

/** "lunes 20/10" a partir de "2026-10-20" (fecha sin hora: se lee como mediodía en Argentina). */
export function fechaCortaColegio(iso: string | null | undefined): string | null {
  if (!iso || !/^\d{4}-\d{2}-\d{2}$/.test(iso)) return null;
  const fecha = new Date(`${iso}T12:00:00-03:00`);
  if (Number.isNaN(fecha.getTime())) return null;
  const partes = new Intl.DateTimeFormat('es-AR', { weekday: 'long', day: 'numeric', month: 'numeric', timeZone: 'America/Argentina/Buenos_Aires' }).formatToParts(fecha);
  const p = (tipo: string) => partes.find((x) => x.type === tipo)?.value || '';
  return `${p('weekday')} ${p('day')}/${p('month')}`;
}

export interface DatosMensajeColegio {
  colegioNombre: string;
  /** Nombre del curso para el grupo de WhatsApp (ej.: 5° grado "C" · Mañana). Vacío = para todo el colegio. */
  curso?: string;
  fechas: { tomaFotos: string | null; cierrePedidos: string | null; entregaKits: string | null };
  urlSitio: string;
  urlInscripcion: string;
  anio?: number;
}

export function mensajeColegio(tipo: TipoMensajeColegio, datos: DatosMensajeColegio): string {
  const anio = datos.anio || new Date().getFullYear();
  const encabezado = (titulo: string) => `${titulo} · ${datos.colegioNombre}${datos.curso ? `\n*${datos.curso}*` : ''}`;
  const toma = fechaCortaColegio(datos.fechas.tomaFotos);
  const cierre = fechaCortaColegio(datos.fechas.cierrePedidos);
  const entrega = fechaCortaColegio(datos.fechas.entregaKits);
  switch (tipo) {
    case 'inscripcion':
      return [
        encabezado(`📸 *Fotos escolares ${anio}*`),
        '',
        `¡Hola, familias! ${toma ? `El *${toma}* vamos a tener la sesión de fotos escolares.` : 'Se viene la sesión de fotos escolares.'}`,
        'Para ver y pedir las fotos de su hijo/a, inscríbanse en la web (se hace una sola vez):',
        `👉 ${datos.urlInscripcion}`,
        '',
        'Cuando se aprueba la inscripción, les llega por email el código para entrar a la galería del curso.',
      ].join('\n');
    case 'fotos':
      return [
        encabezado('📸 *¡Ya están las fotos escolares!*'),
        '',
        `Entren a ${datos.urlSitio} con el código que les llegó por email al inscribirse y elijan sus fotos.`,
        `¿Todavía no se inscribieron? Háganlo acá: ${datos.urlInscripcion}`,
        ...(cierre ? ['', `⏳ Los pedidos cierran el *${cierre}*.`] : []),
      ].join('\n');
    case 'cierre':
      return [
        encabezado('⏳ *Últimos días para pedir las fotos escolares*'),
        '',
        `${cierre ? `Los pedidos cierran el *${cierre}*.` : 'Los pedidos cierran en pocos días.'} Después ya no entran en la impresión de los kits del colegio.`,
        `Pedidos en: ${datos.urlSitio}`,
      ].join('\n');
    case 'entrega':
      return [
        encabezado('📦 *Llegaron los kits de fotos escolares*'),
        '',
        entrega ? `Los kits impresos se entregan en el colegio el *${entrega}*.` : 'Los kits impresos ya están en el colegio y se entregan en estos días.',
        'Los archivos digitales ya les llegaron por email al confirmarse el pago.',
      ].join('\n');
  }
}

/** Link que abre WhatsApp con el texto ya escrito: quien lo toca elige el grupo y lo manda. */
export function linkCompartirWhatsApp(texto: string): string {
  return `https://wa.me/?text=${encodeURIComponent(texto)}`;
}
