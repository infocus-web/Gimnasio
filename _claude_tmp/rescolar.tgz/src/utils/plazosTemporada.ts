import { useEffect, useSyncExternalStore } from 'react';
import { fetchConTimeout } from './fetchConTimeout';

/**
 * Fechas límite de la temporada (30/10/2026, pedido de Pablo: se editan desde el panel → Configuración, sin tocar
 * código). La fuente de verdad es el servidor (GET /api/plazos → configuracion 'plazos_temporada'); estos valores
 * por defecto sólo se usan hasta que responde. Quien decide de verdad si se puede comprar o pedir es SIEMPRE el
 * servidor. Debe coincidir con servidor/nucleo/plazosTemporada.ts.
 *  - kitImpreso: elegir el Kit Impreso, pasar de digital a impreso y pedir fotos extra.
 *  - faltantes: pedir que le saquen una foto que le falta.
 */
export interface PlazosTemporada {
  kitImpreso: string;
  faltantes: string;
}

export const PLAZOS_POR_DEFECTO: Readonly<PlazosTemporada> = Object.freeze({ kitImpreso: '2026-11-15', faltantes: '2026-11-15' });

const MESES = ['enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre'];

let actuales: PlazosTemporada = { ...PLAZOS_POR_DEFECTO };
let delServidor = false;
let version = 0;
const oyentes = new Set<() => void>();

/** Día real con formato AAAA-MM-DD (entre 2024 y 2100). */
export function fechaValida(valor: unknown): valor is string {
  if (typeof valor !== 'string') return false;
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(valor);
  if (!m) return false;
  const [anio, mes, dia] = [Number(m[1]), Number(m[2]), Number(m[3])];
  if (anio < 2024 || anio > 2100) return false;
  const f = new Date(Date.UTC(anio, mes - 1, dia));
  return f.getUTCFullYear() === anio && f.getUTCMonth() === mes - 1 && f.getUTCDate() === dia;
}

/** Último instante del día (23:59:59.999 hora de Argentina), en milisegundos. */
export const finDelDia = (fecha: string): number => Date.parse(`${fecha}T23:59:59.999-03:00`);
/** «15/11» */
export const textoFechaCorta = (fecha: string): string => `${fecha.slice(8, 10)}/${fecha.slice(5, 7)}`;
/** «15 de noviembre» */
export const textoFechaLarga = (fecha: string): string => `${Number(fecha.slice(8, 10))} de ${MESES[Number(fecha.slice(5, 7)) - 1]}`;

export function plazosVigentes(): PlazosTemporada {
  return actuales;
}

export function plazosVienenDelServidor(): boolean {
  return delServidor;
}

/** Aplica fechas nuevas (del servidor o recién guardadas en el panel) y re-renderiza a quien las use. */
export function aplicarPlazos(p: unknown): boolean {
  const { kitImpreso, faltantes } = (p || {}) as Record<string, unknown>;
  if (!fechaValida(kitImpreso) || !fechaValida(faltantes)) return false;
  actuales = { kitImpreso, faltantes };
  delServidor = true;
  version += 1;
  oyentes.forEach((fn) => fn());
  return true;
}

let cargando: Promise<boolean> | null = null;
/** Pide las fechas al servidor (una vez; con `forzar`, de nuevo). Devuelve true si quedaron las del servidor. */
export function cargarPlazos(opciones: { forzar?: boolean } = {}): Promise<boolean> {
  if (delServidor && !opciones.forzar) return Promise.resolve(true);
  if (!cargando) {
    cargando = (async () => {
      try {
        const r = await fetchConTimeout('/api/plazos');
        const data = r.ok ? await r.json().catch(() => null) : null;
        return aplicarPlazos(data?.plazos);
      } catch {
        return false; // sin conexión: quedan las últimas conocidas y se reintenta en la próxima carga
      } finally {
        cargando = null;
      }
    })();
  }
  return cargando;
}

/** Re-renderiza el componente cuando llegan (o cambian) las fechas; la primera vez las pide al servidor. */
export function usePlazosTemporada(): PlazosTemporada {
  useSyncExternalStore(
    (fn) => {
      oyentes.add(fn);
      return () => oyentes.delete(fn);
    },
    () => version,
    () => version
  );
  useEffect(() => {
    void cargarPlazos();
  }, []);
  return actuales;
}
