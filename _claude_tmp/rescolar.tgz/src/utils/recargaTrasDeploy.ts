/**
 * Después de publicar una versión nueva, una pestaña que quedó abierta todavía tiene la versión
 * vieja de la web, que apunta a archivos (por ejemplo, el del panel del fotógrafo) que ya no
 * existen. Al abrir el panel fallaba la descarga y aparecía "Algo salió mal" (caso real 27/9).
 * En ese caso se recarga la página una sola vez para traer la versión nueva.
 */
import { cuandoNoHayaProcesos, hayProcesoEnCurso } from './procesoEnCurso';

const CLAVE = 'recarga_tras_deploy_at';
const MARCA_URL = 'recarga_version';

// Caso real 5/10 (reporte automático "Cannot read properties of undefined (reading 'default')"):
// el aviso `vite:preloadError` y el `catch` del import pedían la recarga por separado; el segundo
// pedido caía en el límite de 1 minuto, devolvía `false` y el error terminaba en el ErrorBoundary
// (pantalla "Algo salió mal" + reporte) justo antes de que la página se recargara. Ahora, una vez
// pedida la recarga en esta carga de la página, todos los pedidos siguientes responden `true`.
let recargaPedida = false;

/** `true` mientras la página se está recargando por una versión nueva (no mostrar ni reportar errores). */
export function recargaEnCurso(): boolean {
  return recargaPedida;
}

export function recargarPorVersionNueva(): boolean {
  if (recargaPedida) return true;
  // 14/10/2026 (auditoría): si hay un proceso largo en marcha (envío masivo, publicar…), no se lo corta:
  // la recarga queda pedida y se hace apenas termine.
  if (hayProcesoEnCurso()) {
    recargaPedida = true;
    cuandoNoHayaProcesos(() => {
      recargaPedida = false;
      recargarPorVersionNueva();
    });
    return true;
  }
  try {
    const ultima = Number(sessionStorage.getItem(CLAVE) || 0);
    // Si ya se recargó hace menos de un minuto, no se insiste (evita un bucle si el error es otro).
    if (Date.now() - ultima < 60_000) return false;
    sessionStorage.setItem(CLAVE, String(Date.now()));
  } catch {
    // Auditoría 11/10: sin sessionStorage el freno de 1 minuto no existía (bucle de recargas si el
    // archivo falta de verdad). La marca va en la URL: si ya se recargó una vez, no se insiste.
    try {
      const url = new URL(window.location.href);
      if (url.searchParams.has(MARCA_URL)) return false;
      url.searchParams.set(MARCA_URL, '1');
      recargaPedida = true;
      window.location.replace(url.toString());
      return true;
    } catch {
      return false;
    }
  }
  recargaPedida = true;
  window.location.reload();
  return true;
}

/** Envuelve un import dinámico: si el archivo ya no existe (versión nueva publicada), recarga. */
export function importarConRecarga<T>(cargar: () => Promise<T>): () => Promise<T> {
  return () =>
    cargar().catch((error) => {
      if (recargarPorVersionNueva()) return new Promise<T>(() => {}); // la página se está recargando
      throw error;
    });
}
