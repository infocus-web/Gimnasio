/**
 * Cursos que existen en la nómina de un colegio (12/10/2026). El formulario de inscripción ofrece en
 * División y Turno sólo las combinaciones reales del grado elegido. Caso real (Divino Pastor):
 * «Jornada Extendida» figura como división del colegio porque existe en 5° y 6° grado, y familias de
 * Sala 4 o de 1° a 3° grado la elegían, cuando ahí la jornada extendida es el turno de la división A o C.
 * Si el grado no está en la nómina (o la lista no cargó), se ofrece todo, como antes.
 */
export interface CursoColegio {
  grado: string;
  division: string;
  /** null = la nómina no trae turno (secundaria): cualquier turno vale. */
  turno: string | null;
}

export interface OpcionesCurso {
  divisiones: string[];
  turnos: string[];
}

const normalizar = (v: unknown) =>
  String(v ?? '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().replace(/\s+/g, ' ').trim();

/** Mismo texto que en la lista del colegio (si coincide), para guardar siempre igual. */
function comoEnLaLista(valor: string, lista: string[]): string {
  return lista.find((x) => normalizar(x) === normalizar(valor)) || valor;
}

function sinRepetir(valores: string[], orden: string[]): string[] {
  const unicos = [...new Map(valores.map((v) => [normalizar(v), v])).values()];
  const posicion = (v: string) => {
    const i = orden.findIndex((o) => normalizar(o) === normalizar(v));
    return i === -1 ? orden.length : i;
  };
  return unicos.sort((a, b) => posicion(a) - posicion(b) || a.localeCompare(b, 'es'));
}

/**
 * Divisiones y turnos para el grado (y la división, si ya se eligió). `base` es lo cargado en el colegio.
 */
export function opcionesDeCurso(cursos: CursoColegio[] | null | undefined, base: OpcionesCurso, grado: string, division: string): OpcionesCurso {
  const delGrado = (cursos || []).filter((c) => normalizar(c.grado) === normalizar(grado));
  if (!grado || delGrado.length === 0) return base;
  const divisiones = sinRepetir(delGrado.map((c) => comoEnLaLista(c.division, base.divisiones)), base.divisiones);
  const deLaDivision = division ? delGrado.filter((c) => normalizar(c.division) === normalizar(division)) : delGrado;
  const turnos =
    deLaDivision.length === 0 || deLaDivision.some((c) => !c.turno)
      ? base.turnos
      : sinRepetir(deLaDivision.map((c) => comoEnLaLista(String(c.turno), base.turnos)), base.turnos);
  return { divisiones, turnos };
}

/** «División C»; las que ya tienen nombre propio («Jornada Extendida») van tal cual. */
export function etiquetaDivision(division: string): string {
  return /extendida|jornada/i.test(division) ? division : `División ${division}`;
}
