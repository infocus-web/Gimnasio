// Fotos extra (29/10/2026): copias impresas sueltas que la familia pide sobre un kit ya pagado, en un pedido aparte.
// Debe coincidir con servidor/nucleo/fotosExtra.ts (el servidor vuelve a validar todo y calcula el total).

export const TAMANOS_FOTO_EXTRA = ['15x21', '20x30'] as const;
export type TamanoFotoExtra = (typeof TAMANOS_FOTO_EXTRA)[number];
export const MAX_COPIAS_POR_FOTO = 10;
export const MAX_ITEMS_FOTOS_EXTRA = 40;

export interface ItemFotoExtra {
  fotoId: string;
  tamano: TamanoFotoExtra;
  cantidad: number;
}

export interface PreciosFotosExtra {
  extra15x21: number;
  extra20x30: number;
}

export const PRECIOS_FOTOS_EXTRA_POR_DEFECTO: PreciosFotosExtra = { extra15x21: 5000, extra20x30: 8000 };

export function precioCopiaExtra(tamano: TamanoFotoExtra, precios: PreciosFotosExtra): number {
  return tamano === '20x30' ? precios.extra20x30 : precios.extra15x21;
}

/** Total que se muestra (el que se cobra lo calcula el servidor). */
export function totalFotosExtra(items: ItemFotoExtra[], precios: PreciosFotosExtra): number {
  return items.reduce((a, it) => a + it.cantidad * precioCopiaExtra(it.tamano, precios), 0);
}

export function contarCopias(items: ItemFotoExtra[]): number {
  return items.reduce((a, it) => a + it.cantidad, 0);
}

/**
 * Panel del fotógrafo: los archivos de un pedido de fotos extra son las copias que pidió la familia (no las 3 del
 * kit). Una entrada por foto y tamaño; si la foto ya no está en la galería del curso, queda marcada `sinFotoReal`.
 */
export function archivosLabDeFotosExtra(
  fila: any,
  fotos: { id: string; thumbnail: string; url: string; categoria: string }[]
): { id: string; tipo: 'individual' | 'grupal' | 'docente'; nombreArchivoOriginal: string; nombreArchivoLab: string; tamanoImpresion: string; urlMuestra: string; urlOriginalHD?: string; sinFotoReal?: boolean; esCopiaExtra?: boolean; numeroCopia?: number }[] {
  const items: any[] = Array.isArray(fila?.fotos_seleccionadas?.extras) ? fila.fotos_seleccionadas.extras : [];
  const pedido = String(fila?.pedido_friendly_id || fila?.id || '').replace(/[^A-Za-z0-9]+/g, '_');
  return items.map((it, i) => {
    const foto = fotos.find((f) => f.id === it?.fotoId);
    const tipo = foto?.categoria === 'grupal' ? 'grupal' : foto?.categoria === 'docente' || foto?.categoria === 'familia' ? 'docente' : 'individual';
    return {
      id: `${fila?.id || pedido}-extra-${i + 1}`,
      tipo,
      nombreArchivoOriginal: 'FOTO_EXTRA',
      nombreArchivoLab: `EXTRA_${pedido}_F${i + 1}_${it?.tamano}_x${Number(it?.cantidad) || 1}.jpg`,
      tamanoImpresion: String(it?.tamano || '15x21'),
      ...(foto ? { urlMuestra: foto.thumbnail, urlOriginalHD: foto.url } : { urlMuestra: '', sinFotoReal: true }),
      esCopiaExtra: true,
      numeroCopia: Number(it?.cantidad) || 1,
    };
  });
}
