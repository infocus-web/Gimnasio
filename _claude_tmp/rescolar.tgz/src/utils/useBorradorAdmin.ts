import { useCallback, useEffect, useRef, useState } from 'react';
import { fetchAdminAutenticado } from '../services/adminAuthService';

/**
 * 14/10/2026 (auditoría): borrador que se guarda solo en el servidor mientras Pablo escribe (AdminModal
 * desmonta las pestañas al cambiar, y recargar la página también borraba todo). Al montar (o al cambiar de
 * `clave`) se trae el borrador guardado; cada cambio se guarda ~800 ms después del último tecleo; al cambiar
 * de clave o de pestaña se guarda lo pendiente al toque. Si el servidor falla, la pantalla sigue andando igual
 * (sólo no queda guardado). Un valor vacío borra el borrador.
 *
 * - `setValor`: cambio de quien escribe (se guarda).
 * - `fijarSinGuardar`: valor que pone el código al abrir (texto sugerido, limpiar al cerrar): no se guarda y
 *   no impide que aparezca el borrador guardado.
 * - `borrar(clave?)`: después de enviar o guardar de verdad (con la clave explícita si pudo cambiar).
 */
const ESPERA_MS = 800;
const ruta = (clave: string) => `/api/admin/borradores/${encodeURIComponent(clave)}`;

export function borradorVacio(valor: unknown): boolean {
  if (valor === null || valor === undefined) return true;
  if (typeof valor === 'string') return valor.trim() === '';
  if (Array.isArray(valor)) return valor.length === 0;
  if (typeof valor === 'object') return Object.values(valor as Record<string, unknown>).every(borradorVacio);
  return false;
}

async function guardarEnServidor(clave: string, valor: unknown): Promise<void> {
  try {
    if (borradorVacio(valor)) await fetchAdminAutenticado(ruta(clave), { method: 'DELETE' });
    else await fetchAdminAutenticado(ruta(clave), { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ contenido: valor }) });
  } catch {
    // sin conexión: el borrador sólo queda en pantalla
  }
}

export function useBorradorAdmin<T>(clave: string | null, valorInicial: T) {
  const [valor, setValorEstado] = useState<T>(valorInicial);
  const [cargado, setCargado] = useState(false);
  const [recuperado, setRecuperado] = useState(false);
  const valorRef = useRef<T>(valorInicial);
  const tocado = useRef(false);
  const pendiente = useRef<{ clave: string; valor: T; timer: ReturnType<typeof setTimeout> } | null>(null);
  // La clave vigente (no la del render en que se armó el setter): una respuesta que llega tarde se guarda
  // en el borrador que está abierto ahora.
  const claveRef = useRef(clave);
  claveRef.current = clave;

  const guardarPendiente = useCallback(() => {
    const p = pendiente.current;
    if (!p) return;
    clearTimeout(p.timer);
    pendiente.current = null;
    void guardarEnServidor(p.clave, p.valor);
  }, []);

  useEffect(() => {
    tocado.current = false;
    setRecuperado(false);
    setCargado(false);
    if (!clave) return undefined;
    let vigente = true;
    void (async () => {
      try {
        const res = await fetchAdminAutenticado(ruta(clave));
        const data = await res.json().catch(() => null);
        if (!vigente || tocado.current || !res.ok || !data?.success || borradorVacio(data.contenido)) return;
        valorRef.current = data.contenido as T;
        setValorEstado(data.contenido as T);
        setRecuperado(true);
      } catch {
        // sin conexión: se arranca sin borrador
      } finally {
        if (vigente) setCargado(true);
      }
    })();
    return () => {
      vigente = false;
      guardarPendiente();
    };
  }, [clave, guardarPendiente]);

  const setValor = useCallback((nuevo: T | ((previo: T) => T)) => {
    const siguiente = typeof nuevo === 'function' ? (nuevo as (previo: T) => T)(valorRef.current) : nuevo;
    tocado.current = true;
    valorRef.current = siguiente;
    setValorEstado(siguiente);
    const destino = claveRef.current;
    if (!destino) return;
    if (pendiente.current) clearTimeout(pendiente.current.timer);
    pendiente.current = { clave: destino, valor: siguiente, timer: setTimeout(() => {
      pendiente.current = null;
      void guardarEnServidor(destino, siguiente);
    }, ESPERA_MS) };
  }, []);

  const fijarSinGuardar = useCallback((nuevo: T) => {
    valorRef.current = nuevo;
    setValorEstado(nuevo);
  }, []);

  const borrar = useCallback(async (claveExplicita?: string) => {
    const destino = claveExplicita || claveRef.current;
    if (pendiente.current && (!claveExplicita || pendiente.current.clave === claveExplicita)) {
      clearTimeout(pendiente.current.timer);
      pendiente.current = null;
    }
    if (destino) await guardarEnServidor(destino, null);
  }, []);

  return [valor, setValor, { fijarSinGuardar, borrar, cargado, recuperado }] as const;
}
