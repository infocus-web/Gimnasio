/**
 * 14/10/2026 (auditoría): los procesos largos del panel («Aceptar todos», envío masivo de emails, avisos de
 * etapa, campaña Zoho, publicar fotos…) se cortaban sin aviso si se cerraba la pestaña, y la recarga
 * automática tras publicar una versión nueva (recargaTrasDeploy.ts) también los cortaba. Este registro chico
 * dice si hay alguno en marcha: mientras haya uno, el navegador pregunta antes de cerrar la pestaña y la
 * recarga por versión nueva espera a que terminen.
 *
 * Uso: `const fin = iniciarProceso('Envío de emails'); try { … } finally { fin(); }`
 */
const activos = new Map<number, string>();
const alTerminar = new Set<() => void>();
let siguiente = 1;

function avisoAlCerrar(e: BeforeUnloadEvent) {
  e.preventDefault();
  e.returnValue = '';
}

/** Anota un proceso en marcha; devuelve la función que lo da por terminado (llamarla dos veces no pasa nada). */
export function iniciarProceso(nombre: string): () => void {
  const id = siguiente++;
  if (activos.size === 0 && typeof window !== 'undefined') window.addEventListener('beforeunload', avisoAlCerrar);
  activos.set(id, nombre);
  return () => {
    if (!activos.delete(id)) return;
    if (activos.size > 0) return;
    if (typeof window !== 'undefined') window.removeEventListener('beforeunload', avisoAlCerrar);
    for (const fn of [...alTerminar]) {
      alTerminar.delete(fn);
      try { fn(); } catch { /* un oyente roto no frena a los demás */ }
    }
  };
}

export function hayProcesoEnCurso(): boolean {
  return activos.size > 0;
}

/** Nombres de los procesos en marcha (para mostrar qué se está esperando). */
export function procesosEnCurso(): string[] {
  return [...activos.values()];
}

/** Corre `fn` cuando no quede ningún proceso en marcha (al toque si ya no hay). */
export function cuandoNoHayaProcesos(fn: () => void): void {
  if (activos.size === 0) fn();
  else alTerminar.add(fn);
}

/** Corre `tarea` anotada como proceso en curso (se da por terminada aunque falle). */
export async function conProcesoEnCurso<T>(nombre: string, tarea: () => Promise<T>): Promise<T> {
  const fin = iniciarProceso(nombre);
  try {
    return await tarea();
  } finally {
    fin();
  }
}
