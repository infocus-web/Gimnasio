import { useEffect, useState } from 'react';

/**
 * Modo noche del panel del fotógrafo (pedido de Pablo, 27/9/2026). Si nunca se eligió, sigue el
 * modo del sistema (compu o celular); si se toca el botón de la luna, se recuerda la elección.
 * Los colores oscuros salen de src/modoNoche.css (generado por scripts/generar-modo-noche.mjs).
 */
const CLAVE = 'modo_noche_panel';

function leerPreferencia(): boolean {
  try {
    const guardado = localStorage.getItem(CLAVE);
    if (guardado === 'on') return true;
    if (guardado === 'off') return false;
  } catch {
    /* sin localStorage: se usa el modo del sistema */
  }
  try {
    return window.matchMedia?.('(prefers-color-scheme: dark)').matches ?? false;
  } catch {
    return false;
  }
}

export function useModoNoche(): [boolean, () => void] {
  const [activo, setActivo] = useState<boolean>(() => (typeof window === 'undefined' ? false : leerPreferencia()));
  useEffect(() => {
    try {
      const guardado = localStorage.getItem(CLAVE);
      if (guardado) return; // la persona ya eligió: no se sigue al sistema
    } catch {
      /* nada */
    }
    const mq = window.matchMedia?.('(prefers-color-scheme: dark)');
    if (!mq?.addEventListener) return;
    const alCambiar = (e: MediaQueryListEvent) => setActivo(e.matches);
    mq.addEventListener('change', alCambiar);
    return () => mq.removeEventListener('change', alCambiar);
  }, []);
  const alternar = () =>
    setActivo((actual) => {
      const nuevo = !actual;
      try {
        localStorage.setItem(CLAVE, nuevo ? 'on' : 'off');
      } catch {
        /* nada */
      }
      return nuevo;
    });
  return [activo, alternar];
}
