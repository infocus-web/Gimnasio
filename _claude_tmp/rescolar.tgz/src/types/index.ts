// 06/10: 'familia' = foto con familia y/o amigos (3ª foto del kit en secundaria, ver utils/terceraFoto.ts).
export type CategoriaFoto = 'individual' | 'grupal' | 'docente' | 'familia' | 'patio';

export interface Foto {
  id: string;
  url: string;
  thumbnail: string;
  /** 04/10: base de la URL de la lupa (pedacitos nítidos de la foto), sin cx/cy/s. Sólo en la galería de las familias. */
  lupaUrl?: string;
  categoria: CategoriaFoto;
  titulo: string;
  descripcion?: string;
  alumnoNombre?: string;
  grado?: string;
  division?: string;
  /** 25/10: número visible de la foto («3486»), para que la familia pueda decir cuál quiere. */
  numero?: string;
}

export interface KitProducto {
  id: string;
  nombre: string;
  subtitulo?: string;
  tagline: string;
  precio: number;
  precioOriginal?: number;
  popular?: boolean;
  incluye: string[];
  icono: string;
  fotosPermitidas: {
    individuales: number;
    grupales: number;
    docentes: number;
  };
}

export interface Colegio {
  id: string;
  slug: string;
  nombre: string;
  localidad: string;
  zona: 'CABA' | 'Zona Norte' | 'Zona Sur' | 'Zona Oeste';
  eventoActual: string;
  grados: string[];
  divisiones: string[];
  turnos: string[];
  codigoAcceso: string;
  website?: string;
  whatsappContacto?: string;
  /** No aparece para las familias (ej. el colegio de prueba del laboratorio). Sólo lo ve el panel. */
  oculto?: boolean;
  /** 04/10: interruptor «Muestras con lupa» (muestra apenas desenfocada + lupa con la foto nítida). */
  muestrasLupa?: boolean;
}

export interface Pedido {
  id: string;
  codigoPedido: string;
  colegio: string;
  alumno: string;
  grado: string;
  division: string;
  tutorNombre: string;
  tutorTelefono: string;
  tutorEmail: string;
  kit: KitProducto;
  fotosSeleccionadas: {
    individual: string;
    grupal: string;
    docente?: string;
  };
  metodoPago: 'mercadopago' | 'transferencia' | 'efectivo';
  estadoPago: 'pendiente' | 'aprobado';
  montoTotal: number;
  fecha: string;
}

export interface Alumno {
  id: string;
  nombre: string;
  apellido?: string;
  colegioId?: string;
  colegio?: string;
  seccionId?: string;
  grado: string;
  division: string;
  turno?: string;
  codigoAcceso?: string;
  tutorNombre?: string;
  tutorEmail?: string;
  tutorTelefono?: string;
  estado?: 'pendiente' | 'pedido_confirmado' | 'entregado';
}

export interface SolicitudColegio {
  nombreInstitucion: string;
  cargo: string;
  contactoNombre: string;
  email: string;
  telefono: string;
  localidad: string;
  alumnosAproximados: number;
  niveles: ('inicial' | 'primaria' | 'secundaria')[];
  mensaje?: string;
}
