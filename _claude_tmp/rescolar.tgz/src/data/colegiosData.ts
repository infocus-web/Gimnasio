import { Colegio, KitProducto, Foto } from '../types';

export const KITS_DISPONIBLES: KitProducto[] = [
  {
    id: 'kit-clasico',
    nombre: 'Kit Impreso + Digital',
    subtitulo: 'Las 3 fotos impresas, con la carpeta',
    tagline: 'Foto grupal 20x30cm + 2 fotos 15x21cm + carpeta exclusiva y descarga HD de regalo',
    precio: 30000,
    popular: true,
    icono: 'Camera',
    incluye: [
      '1 fotografía grupal en formato ampliado 20x30cm',
      '2 fotografías 15x21cm (individual y con docente; en secundaria, con familia y/o amigos)',
      '1 carpeta de presentación con diseño exclusivo',
      '🎁 Descarga en alta resolución (HD) de regalo incluida',
      'Descarga desde la web y copia por email',
      'Entrega en sobre cerrado individual rotulado por grado y división',
    ],
    fotosPermitidas: {
      individuales: 1,
      grupales: 1,
      docentes: 1,
    },
  },
  {
    id: 'kit-digital',
    nombre: 'Solo Digital HD',
    subtitulo: 'Las mismas 3 fotos, sin impresión',
    tagline: 'Mismas 3 fotos seleccionadas en máxima resolución, sin producto físico',
    precio: 15000,
    popular: false,
    icono: 'Sparkles',
    incluye: [
      '1 fotografía grupal + 2 fotos (individual y con docente; en secundaria, con familia y/o amigos)',
      'Todas en alta resolución (HD), sin marca de agua',
      'Descarga inmediata desde el celular o la compu',
      'Copia automática enviada por email como respaldo permanente',
      'Libre de costos de envío o impresión',
    ],
    fotosPermitidas: {
      individuales: 1,
      grupales: 1,
      docentes: 1,
    },
  },
  {
    id: 'kit-evento-suelto',
    nombre: 'Fotos Sueltas de Eventos',
    subtitulo: 'Actos patrios, deportes, salidas y muestras',
    tagline: 'Galería digital opcional por evento para adquirir fotos individuales sueltas',
    precio: 5000,
    popular: false,
    icono: 'Bookmark',
    incluye: [
      '1 fotografía digital en alta resolución (HD) sin marca de agua',
      'Cobertura documental espontánea del calendario escolar',
      'Descarga inmediata a tu celular y computadora',
      '100% opcional evento por evento (sin compromiso)',
    ],
    fotosPermitidas: {
      individuales: 1,
      grupales: 0,
      docentes: 0,
    },
  },
];

// Fotos reales del repo (public/): reemplazan las fotos de stock (Unsplash) que se usaban antes.
// Nota: por ahora se repite la misma foto para las 3 "tomas" individuales y para las 2 variantes
// grupales, porque todavía no hay más fotos de muestra distintas cargadas — si Pablo suma más
// fotos a public/, alcanza con darles su propia entrada acá.
const FOTO_INDIVIDUAL_MUESTRA = '/individual.webp';
const FOTO_GRUPAL_MUESTRA = '/foto_grupal_grado.webp';
const FOTO_DOCENTE_MUESTRA = '/foto_con_seno.webp';

export const FOTOS_MUESTRA: Foto[] = [
  {
    id: 'foto-ind-1',
    url: FOTO_INDIVIDUAL_MUESTRA,
    thumbnail: FOTO_INDIVIDUAL_MUESTRA,
    categoria: 'individual',
    titulo: 'Individual - Toma 1',
    descripcion: '',
    grado: '3° grado',
    division: 'A',
  },
  {
    id: 'foto-ind-2',
    url: FOTO_INDIVIDUAL_MUESTRA,
    thumbnail: FOTO_INDIVIDUAL_MUESTRA,
    categoria: 'individual',
    titulo: 'Individual - Toma 2',
    descripcion: '',
    grado: '3° grado',
    division: 'A',
  },
  {
    id: 'foto-ind-3',
    url: FOTO_INDIVIDUAL_MUESTRA,
    thumbnail: FOTO_INDIVIDUAL_MUESTRA,
    categoria: 'individual',
    titulo: 'Individual - Toma 3',
    descripcion: '',
    grado: '3° grado',
    division: 'A',
  },
  {
    id: 'foto-grup-1',
    url: FOTO_GRUPAL_MUESTRA,
    thumbnail: FOTO_GRUPAL_MUESTRA,
    categoria: 'grupal',
    titulo: 'Grupal de Grado',
    descripcion: '',
    grado: '3° grado',
    division: 'A',
  },
  {
    id: 'foto-doc-1',
    url: FOTO_DOCENTE_MUESTRA,
    thumbnail: FOTO_DOCENTE_MUESTRA,
    categoria: 'docente',
    titulo: 'Con la Docente',
    descripcion: '',
    grado: '3° grado',
    division: 'A',
  },
  {
    id: 'foto-pat-1',
    url: FOTO_GRUPAL_MUESTRA,
    thumbnail: FOTO_GRUPAL_MUESTRA,
    categoria: 'patio',
    titulo: 'Otras Fotos',
    descripcion: '',
    grado: '3° grado',
    division: 'A',
  },
];

// Auditoría 28/9: preguntas reescritas a partir de las consultas reales de las familias.
// "{kitDigital}", "{kitClasico}" y "{carpetaExtra}" se reemplazan por los precios vigentes (ver
// FaqSection y preciosService).
export const PREGUNTAS_FRECUENTES = [
  {
    pregunta: '¿Cómo accedo a las fotos de mi hijo/a?',
    respuesta:
      '1) Te inscribís una sola vez (tocá "Inscribirme") con tus datos y los de tus hijos. Usá el mismo email o teléfono que tiene el colegio: así te reconocemos enseguida. 2) Te llega por email tu código de acceso (si algún dato no coincide, lo revisamos y te lo mandamos nosotros). 3) Tocás "Acceder a las Fotos" y entrás con ese código, tu nombre y tu DNI.',
  },
  {
    pregunta: 'Me inscribí pero no me llegó el código, ¿qué hago?',
    respuesta:
      'Revisá las carpetas Spam y Promociones de tu email. Si no está, tocá "Inscribirme" → "Ya me inscribí" y pedí que te lo reenviemos con tu teléfono o email: llega siempre al email con el que te inscribiste. Si tu inscripción quedó en revisión, te lo mandamos apenas la aprobamos.',
  },
  {
    pregunta: '¿Quién puede ver las fotos de mi hijo/a?',
    respuesta:
      'La galería es privada: sólo se entra con el código del curso y los datos del tutor. Las fotos individuales, la grupal, la foto con la seño y la foto con familia y/o amigos las ven las familias del mismo curso (cada familia elige la de su hijo/a). Hasta que las comprás, se muestran con marca de agua.',
  },
  {
    pregunta: '¿Cuáles son las 3 fotos que incluye el kit?',
    respuesta:
      '1 foto grupal de todo el grado/sala (20x30 cm en el kit impreso), 1 retrato individual de tu hijo/a (15x21 cm) eligiendo tu toma favorita, y 1 foto con la seño o docente (15x21 cm); en secundaria, en lugar de la del docente, 1 foto con familia y/o amigos. El Kit Impreso ({kitClasico}) trae las 3 impresas en carpeta más la descarga HD; el Solo Digital HD ({kitDigital}) trae las 3 en alta resolución, sin impresión.',
  },
  {
    pregunta: '¿Cuándo están las fotos y cómo las recibo?',
    respuesta:
      'Las cargamos después de la sesión en el colegio y te avisamos por email cuando están online. Al acreditarse el pago te llega por email el link para descargar las fotos en alta resolución, sin marca de agua. Si elegiste el Kit Impreso, la carpeta se entrega en el colegio dentro de los 15 días hábiles posteriores al cierre de pedidos del curso, y te avisamos por email cuando entra en producción y cuando está lista para retirar.',
  },
  {
    pregunta: '¿Cuáles son los medios de pago?',
    respuesta:
      'Mercado Pago (tarjeta de débito, crédito o dinero en cuenta) o transferencia bancaria: los datos aparecen en pantalla y después subís la captura del comprobante desde la misma página. No se maneja efectivo en el colegio.',
  },
  {
    pregunta: 'Toqué "Pagar" y no avanzó, ¿qué hago?',
    respuesta:
      'Fijate que esté tildada la casilla "Leí y acepto" que está justo arriba del botón: si falta, se marca en rojo. Si ya estaba tildada, probá desde otro navegador (Chrome) o desde la compu, o elegí otro medio de pago. Si el pago no se completó, al volver a la página te ofrecemos elegir otro medio sin tener que empezar de nuevo.',
  },
  {
    pregunta: 'Pagué y no me llegó nada',
    respuesta:
      'Revisá Spam y Promociones. Si pagaste por transferencia, el email llega cuando confirmamos el pago (por eso es importante subir el comprobante). También podés entrar a "Acceder a las Fotos" → "Consultar Mi Pedido" con tu número de pedido (empieza con IFS-) y pedir que te reenviemos el link de descarga.',
  },
  {
    pregunta: '¿Puedo pagar el kit por adelantado, antes de que estén las fotos?',
    respuesta:
      'Sí, y no es obligatorio. Si las fotos todavía no están, al entrar en "Acceder a las Fotos" vas a ver "Reservá tu kit ahora": elegís el kit y lo pagás. Cuando se suban las fotos te avisamos, entrás de nuevo, elegís tus 3 fotos y tocás "Confirmar mis fotos", sin volver a pagar. Ahí te llega la descarga en alta resolución.',
  },
  {
    pregunta: '¿Puedo cambiar de kit después de pagar?',
    respuesta:
      'Podés pasar de Solo Digital a Kit Impreso pagando sólo la diferencia: entrá a "Acceder a las Fotos" y en tu pedido vas a ver el botón "Pasar a Kit Impreso". También podés sumar copias extra de la carpeta ({carpetaExtra} c/u) para abuelos o familiares al elegir el kit.',
  },
  {
    pregunta: 'Tengo más de un hijo en el colegio, ¿tengo que hacer todo doble?',
    respuesta:
      'No. Te inscribís una sola vez para toda la familia y sumás a cada hijo/a con "Agregar Hermano/a", aunque vayan a distintas salas, turnos o grados. Con un solo acceso ves las fotos de todos y pagás todo junto en un solo pago. También podés pedir la foto de hermanos juntos.',
  },
  {
    pregunta: '¿Es obligatorio comprar las fotos?',
    respuesta:
      'No. Inscribirte es gratis y la compra es opcional: podés ver la galería con marca de agua y decidir con tranquilidad.',
  },
];
