// Auditoría 11/10: se borró la nómina escrita a mano (nombres reales de chicos) y sus funciones sin uso;
// sólo queda el tipo que usan la difusión y el panel.
export interface SeccionEscolar {
  id: string;
  sala: string;
  turno: 'Mañana' | 'Tarde' | 'Jornada Extendida';
  division: string;
  nombreCompleto: string;
  totalAlumnos: number;
}
