/**
 * Textos legales de Retrato Escolar (27/9/2026). Los usa el sitio (LegalModal, avisos antes de
 * pagar y al confirmar fotos) y el servidor (valida que la familia aceptó ESTA versión).
 *
 * IMPORTANTE: si se cambia el contenido de los términos, subir VERSION_TERMINOS. Cada pedido guarda
 * la versión que aceptó la familia, así se puede probar qué texto vio.
 *
 * Borrador para revisión de un abogado matriculado — ver el documento "Marco legal completo".
 */

// 06/10/2026: foto con compañeros / familia y amigos (3ª foto del kit en secundaria), visible para el curso.
// 10/10/2026: plazo de entrega del kit impreso (15 días hábiles desde el cierre de pedidos del curso).
// 24/10/2026: buscador por reconocimiento facial (Amazon Web Services, sin entrenamiento de IA, se borra al cerrar la temporada).
export const VERSION_TERMINOS = '2026-10-24';

export const PROVEEDOR = {
  marca: 'Retrato Escolar',
  // Nombre comercial que se muestra en los textos. El titular y el CUIT aparecen una sola vez, en el
  // pie del sitio (identificación del vendedor, Res. 104/2005).
  empresa: 'Infocus Producciones',
  titular: 'Pablo Gabriel Alderete',
  cuit: '20-28306117-6',
  domicilio: 'Pilar, Buenos Aires, Argentina',
  email: 'contacto@retratoescolar.com.ar',
  sitio: 'retratoescolar.com.ar',
};

/** Plazos de conservación (sección 4 del documento legal). */
export const PLAZO_CONSERVACION_HD_MESES = 12;

export type SeccionLegal = { titulo: string; parrafos: string[] };
export type DocumentoLegal = { id: 'terminos' | 'privacidad' | 'licencia'; titulo: string; resumen: string; secciones: SeccionLegal[] };

const P = PROVEEDOR;

export const TERMINOS: DocumentoLegal = {
  id: 'terminos',
  titulo: 'Términos y Condiciones',
  resumen:
    'Las reglas de la compra de fotos escolares en retratoescolar.com.ar: qué comprás, cómo se paga, cómo cancelar una compra y la política de cambios.',
  secciones: [
    {
      titulo: '1. Quiénes somos',
      parrafos: [
        `${P.marca} es un servicio de fotografía escolar de ${P.empresa}, con domicilio en ${P.domicilio}. Los datos de identificación del titular figuran al pie de este sitio. Contacto: ${P.email}.`,
        'Estos términos rigen la compra de fotos a través de este sitio. Al pagar, aceptás esta versión de los términos. Nada de lo que dicen limita los derechos que te dan la Ley 24.240 de Defensa del Consumidor y el Código Civil y Comercial.',
      ],
    },
    {
      titulo: '2. Qué comprás',
      parrafos: [
        'Kit Impreso + Digital: carpeta impresa con 3 fotos (individual, grupal y con la docente; en secundaria, en lugar de la foto con la docente, una foto con familia y/o amigos) más esas 3 fotos en archivo digital de alta resolución.',
        'Solo Digital HD: las 3 fotos en archivo digital de alta resolución, sin impresión.',
        'Copias extra de la carpeta y fotos sueltas de actos: se suman al pedido al precio informado antes de pagar.',
        'El precio que ves antes de pagar es el precio final. El servidor recalcula siempre el monto; no se cobra ningún adicional después.',
      ],
    },
    {
      titulo: '3. Pago anticipado (reserva)',
      parrafos: [
        'Si el curso todavía no tiene fotos, podés pagar el kit por adelantado. Cuando las fotos estén online te avisamos por email y elegís tus 3 fotos sin volver a pagar.',
        'Mientras no elijas las fotos, el kit todavía no está personalizado y podés cancelar la compra y recuperar todo lo que pagaste (ver punto 5).',
      ],
    },
    {
      titulo: '4. Entrega',
      parrafos: [
        'Archivos digitales: te llega un link de descarga por email en los minutos siguientes a confirmarse el pago (o a confirmar tus fotos, si pagaste por adelantado).',
        'Kit impreso: se imprime en laboratorio y se entrega en el colegio o en el punto que se informe, dentro de los 15 días hábiles posteriores al cierre de pedidos del curso. Si el pago se acredita (o, con pago anticipado, confirmás tus fotos) después del cierre, el plazo corre desde ese momento. Te avisamos por email cuando está listo y te mantenemos al tanto de cualquier cambio en la fecha de entrega (Ley 24.240, art. 10 bis).',
      ],
    },
    {
      titulo: '5. Cancelación de la compra',
      parrafos: [
        '¿Cuándo podés cancelar? Si pagaste por adelantado (reserva) y todavía no elegiste tus fotos: tenés 10 días corridos desde el pago para cancelar, sin dar explicaciones y sin ningún costo, y te devolvemos todo lo que pagaste por el mismo medio de pago (derecho de revocación: Ley 24.240, art. 34; Código Civil y Comercial, arts. 1110 y siguientes).',
        '¿Cuándo no? Una vez elegidas las fotos, el kit se arma con ellas y los archivos digitales se envían al instante: desde ese momento la compra ya no se puede cancelar, porque el kit es un producto personalizado y los archivos ya se entregaron (Código Civil y Comercial, art. 1116). En la compra común elegís las fotos antes de pagar, así que desde el pago no se puede cancelar.',
        'Para cancelar una reserva usá el link "Botón de arrepentimiento" que está al pie de todas las páginas del sitio. No hace falta registrarse. Dentro de las 24 horas te enviamos por email un código que identifica tu solicitud.',
        'Antes de pagar y antes de confirmar tus fotos te lo avisamos en pantalla y te pedimos que lo aceptes expresamente. Si el kit llega con una falla, lo reimprimimos sin costo (punto 7); esto no depende de la cancelación.',
      ],
    },
    {
      titulo: '6. Cambios de kit',
      parrafos: [
        'Podés pasar a un kit de mayor valor pagando la diferencia.',
        'Una vez confirmadas tus fotos, no se aceptan cambios a un kit de menor valor ni se devuelve la diferencia entre kits, porque el kit ya está personalizado.',
        'Esta política de cambios es distinta de la cancelación del punto 5 y no la limita: mientras esté vigente, podés cancelar y recuperar el total.',
      ],
    },
    {
      titulo: '7. Fallas o errores',
      parrafos: [
        'Si el kit llega con un defecto de impresión o no corresponde a las fotos que elegiste, escribinos a ' + P.email + ' y lo reimprimimos sin costo. Esto no afecta la garantía legal de la Ley 24.240.',
      ],
    },
    {
      titulo: '8. Fotos y datos personales',
      parrafos: [
        'Las fotos de los chicos se tratan según la Política de Privacidad y la Licencia de uso de las fotos, que forman parte de estos términos.',
      ],
    },
    {
      titulo: '9. Reclamos y jurisdicción',
      parrafos: [
        `Podés hacer cualquier consulta o reclamo a ${P.email}. También podés recurrir a la autoridad de Defensa del Consumidor de tu jurisdicción o a la Ventanilla Única Federal (argentina.gob.ar/produccion/defensadelconsumidor).`,
        'Son competentes los tribunales del lugar donde recibiste el producto o el servicio (Código Civil y Comercial, art. 1109).',
      ],
    },
  ],
};

export const PRIVACIDAD: DocumentoLegal = {
  id: 'privacidad',
  titulo: 'Política de Privacidad y Protección de Menores',
  resumen: 'Qué datos y fotos guardamos, para qué, dónde, cuánto tiempo, y cómo pedir que los veas, corrijas o borres.',
  secciones: [
    {
      titulo: '1. Responsable',
      parrafos: [
        `El responsable de la base de datos es ${P.titular} (${P.marca}), CUIT ${P.cuit}, ${P.domicilio}, inscripto como responsable en el Registro Nacional de Bases de Datos Personales de la AAIP. Consultas: ${P.email}. Tratamos los datos según la Ley 25.326 de Protección de Datos Personales.`,
      ],
    },
    {
      titulo: '2. Qué datos tratamos',
      parrafos: [
        'Del adulto responsable: nombre, DNI, email, teléfono y datos de los pagos (no guardamos datos de tarjetas: los procesa Mercado Pago o Nave).',
        'De los chicos: nombre, colegio, grado, turno y división, y las fotografías tomadas en el colegio.',
        'Registros técnicos: fecha, hora y dirección IP de cada aceptación de estos términos, para poder probar qué aceptaste.',
        'Darnos estos datos es necesario para identificar a tus hijos en el padrón del colegio y entregarte el pedido. Sin ellos no podemos prestar el servicio.',
      ],
    },
    {
      titulo: '3. Para qué los usamos',
      parrafos: [
        'Sólo para: validar la inscripción contra el padrón del colegio, mostrarte las fotos de tus hijos, procesar pagos, producir y entregar el pedido, y responder consultas.',
        'No vendemos ni cedemos datos. No usamos las fotos de tus hijos para publicidad, redes sociales ni portfolio salvo que lo autorices aparte, con una casilla opcional que podés retirar cuando quieras.',
        'Buscador por reconocimiento facial: para ayudarte a encontrar las fotos de tu hijo/a si quedaron en otro curso, registramos las caras de las fotos del colegio en Amazon Web Services. Sólo se usa cuando una familia sube una foto del rostro de su hijo/a desde la galería, con su autorización: esa foto no se guarda, se compara una vez y las fotos encontradas se suman sólo a la galería de esa familia.',
        'No usamos las fotos para entrenar sistemas de inteligencia artificial, y excluimos el uso de nuestros datos para mejorar los servicios de inteligencia artificial de nuestro proveedor.',
      ],
    },
    {
      titulo: '4. Quién ve las fotos',
      parrafos: [
        'La galería de un curso sólo se abre con el código secreto de ese curso, que se entrega a las familias inscriptas.',
        'Las fotos individuales, las grupales y las fotos con la docente las ven las familias del mismo curso: se cargan por curso y cada familia elige la de su hijo/a. Si una foto individual está identificada con el nombre de un chico, la ve sólo la familia de ese chico. Las fotos con familia y/o amigos también las ven las familias del mismo curso, para que cada compañero que aparece pueda elegirlas.',
        'Las fotos se muestran con marca de agua hasta que se compran.',
      ],
    },
    {
      titulo: '5. Dónde se guardan los datos',
      parrafos: [
        'Trabajamos con proveedores líderes en tecnología, con altos estándares de seguridad: Supabase (base de datos y fotos), Vercel (sitio web), Resend (emails), Google (asistente de consultas), Amazon Web Services (buscador por reconocimiento facial) y Mercado Pago o Nave (pagos). Algunos tienen sus servidores fuera de Argentina.',
        'Al inscribirte nos das tu consentimiento para alojar los datos con estos proveedores, como prevé la Ley 25.326 (art. 12).',
      ],
    },
    {
      titulo: '6. Cuánto tiempo los guardamos',
      parrafos: [
        'Fotos no vendidas, descartadas y copias con marca de agua: se borran al cerrar la temporada escolar.',
        'Caras registradas para el buscador por reconocimiento facial y registro de búsquedas: se borran al cerrar la temporada escolar.',
        `Originales en alta resolución de pedidos entregados: ${PLAZO_CONSERVACION_HD_MESES} meses desde la entrega, para poder reenviarte el link o reimprimir ante un reclamo.`,
        'Datos de pagos y facturación: el plazo que exija la ley fiscal.',
        'Consentimientos y aceptaciones: mientras se usen las fotos y durante el plazo legal de prescripción.',
      ],
    },
    {
      titulo: '7. Tus derechos',
      parrafos: [
        `Podés pedir ver tus datos (te respondemos en 10 días corridos) y corregirlos o borrarlos (en 5 días hábiles), escribiendo a ${P.email}. Es gratis.`,
        'Podés retirar en cualquier momento el consentimiento para el uso de la imagen de tu hijo/a hacia el futuro. Borramos sus fotos individuales y lo excluimos de las grupales que todavía no se vendieron. Las fotos entregadas antes del retiro quedan en poder de cada familia.',
        'La Agencia de Acceso a la Información Pública (AAIP), órgano de control de la Ley 25.326, atiende las denuncias por incumplimiento de las normas de protección de datos personales.',
      ],
    },
    {
      titulo: '8. Seguridad',
      parrafos: [
        'Los originales en alta resolución se guardan en almacenamiento privado. Los links de descarga están firmados y vencen. El acceso al panel de administración está protegido.',
        'Revisamos la seguridad de la plataforma en forma periódica y, ante cualquier novedad que te afecte, te avisamos por email.',
      ],
    },
  ],
};

export const LICENCIA: DocumentoLegal = {
  id: 'licencia',
  titulo: 'Licencia de uso de las fotos',
  resumen: 'Qué podés hacer con las fotos que comprás y qué no.',
  secciones: [
    {
      titulo: '1. De quién son las fotos',
      parrafos: [
        `Las fotografías son obras de ${P.empresa} (${P.marca}), titular de los derechos de autor (Ley 11.723).`,
        'La imagen de cada chico es de él o ella, y la administran sus padres o tutores (Código Civil y Comercial, art. 53; Ley 11.723, art. 31). Por eso nosotros tampoco podemos usarla fuera del pedido sin autorización.',
      ],
    },
    {
      titulo: '2. Qué recibís al comprar',
      parrafos: [
        'Las copias impresas del kit y una licencia personal, gratuita y sin vencimiento para usar los archivos digitales en el ámbito familiar.',
      ],
    },
    {
      titulo: '3. Qué podés hacer',
      parrafos: [
        'Imprimir las fotos para tu familia, las veces que quieras.',
        'Guardarlas y compartir la foto individual de tu propio hijo/a con familiares y amigos.',
      ],
    },
    {
      titulo: '4. Qué no podés hacer',
      parrafos: [
        'Revenderlas o usarlas con fines comerciales.',
        'Publicar las fotos grupales, con la docente o con amigos en redes sociales o sitios abiertos, porque aparecen otros chicos y un adulto que no lo autorizaron (Ley 26.061, art. 22).',
        'Recortar o editar a otros chicos para difundirlos.',
        'Usarlas para entrenar sistemas de inteligencia artificial o de reconocimiento facial.',
      ],
    },
  ],
};

export const DOCUMENTOS_LEGALES: DocumentoLegal[] = [TERMINOS, PRIVACIDAD, LICENCIA];

/** Textos cortos que se muestran en pantalla antes de cada aceptación. */
export const AVISO_ANTES_DE_PAGAR = {
  // 2/10 (pedido de Pablo): primero cuándo sí y cuándo no, sin vueltas. Reserva = todavía sin fotos.
  arrepentimiento:
    'Si pagaste por adelantado y todavía no elegiste las fotos, sí: tenés 10 días corridos y te devolvemos todo, desde el link "Botón de arrepentimiento" al pie de la página. Una vez elegidas las fotos, el kit se arma con ellas y los archivos digitales se envían al instante, así que la compra ya no se puede cancelar (Código Civil y Comercial, art. 1116). Si el kit llega con una falla, lo reimprimimos sin costo.',
  cambios:
    'Podés pasar a un kit de mayor valor pagando la diferencia. Una vez elegidas las fotos, no se aceptan cambios a un kit de menor valor ni se devuelve la diferencia.',
  // 10/10/2026 (Pablo): plazo de entrega del kit impreso (Ley 24.240, art. 10 inc. e). Igual que el punto 4 de los Términos.
  entrega:
    'Los archivos digitales te llegan por email al confirmarse el pago. El kit impreso se entrega en el colegio dentro de los 15 días hábiles posteriores al cierre de pedidos del curso (si pagás o confirmás tus fotos después del cierre, desde ese momento) y te avisamos por email cuando está listo.',
  casilla: 'Leí y acepto los Términos y Condiciones, la Política de Privacidad y la Licencia de uso de las fotos.',
};

/** Aviso cuando la compra ya incluye las fotos elegidas (compra normal, no reserva). */
export const AVISO_COMPRA_CON_FOTOS =
  'No. Como ya elegiste tus fotos, al pagar armamos el kit con ellas y te enviamos los archivos digitales al instante, así que esta compra ya no se puede cancelar (Código Civil y Comercial, art. 1116). Si el kit llega con una falla o con fotos que no son las que elegiste, lo reimprimimos sin costo.';

export const AVISO_CONFIRMAR_FOTOS = {
  texto:
    'Al confirmar, preparamos tu kit con estas fotos y te enviamos los archivos digitales. Desde ese momento es un producto personalizado: no se puede cancelar ni cambiar a un kit de menor valor.',
  casilla: 'Entiendo, confirmo mi elección y pido que me envíen ya los archivos digitales.',
};

export const CONSENTIMIENTOS_INSCRIPCION = [
  {
    id: 'toma',
    obligatorio: true,
    texto: 'Autorizo a Retrato Escolar a fotografiar a mi hijo/a en el colegio, en tomas individuales, grupales, con la docente y con compañeros de su curso, para ofrecernos las fotos a nuestra familia.',
  },
  {
    id: 'grupal',
    obligatorio: true,
    texto: 'Autorizo que las fotos grupales, con la docente y con compañeros o familiares donde aparece mi hijo/a se ofrezcan a las familias de su mismo curso.',
  },
  {
    id: 'transferencia',
    obligatorio: true,
    texto: 'Acepto la Política de Privacidad, incluido el alojamiento de nuestros datos y fotos en los servidores seguros de los proveedores de la plataforma (Ley 25.326, art. 12).',
  },
  {
    id: 'promocional',
    obligatorio: false,
    texto: '(Opcional) Autorizo usar fotos de mi hijo/a para mostrar el trabajo de Retrato Escolar en el sitio o en redes. Puedo retirar esta autorización cuando quiera.',
  },
] as const;

export type IdConsentimiento = (typeof CONSENTIMIENTOS_INSCRIPCION)[number]['id'];
