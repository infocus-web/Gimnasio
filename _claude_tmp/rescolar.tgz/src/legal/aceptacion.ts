import { VERSION_TERMINOS, type DocumentoLegal } from './textosLegales';

/**
 * Aceptación de los términos en esta pestaña (marco legal 27/9). La casilla de "Leí y acepto"
 * (AceptacionTerminos.tsx) la marca; los servicios que registran pedidos o reservas mandan
 * `datosAceptacion()` al servidor, que rechaza la compra si no llega. Se guarda en memoria (no en
 * localStorage): cada visita tiene que volver a aceptar.
 */
let aceptadoEn: number | null = null;

export function marcarTerminosAceptados(aceptado: boolean): void {
  aceptadoEn = aceptado ? Date.now() : null;
}

export function terminosAceptados(): boolean {
  return aceptadoEn !== null;
}

export function datosAceptacion(): { aceptaTerminos?: true; versionTerminos?: string } {
  return aceptadoEn !== null ? { aceptaTerminos: true, versionTerminos: VERSION_TERMINOS } : {};
}

export type PestanaLegal = DocumentoLegal['id'] | 'arrepentimiento';

export const EVENTO_ABRIR_LEGAL = 'retrato:abrir-legal';

/** Abre la ventana de textos legales (o el Botón de arrepentimiento) desde cualquier pantalla. */
export function abrirLegal(pestana: PestanaLegal = 'terminos'): void {
  if (typeof window === 'undefined') return;
  window.dispatchEvent(new CustomEvent<PestanaLegal>(EVENTO_ABRIR_LEGAL, { detail: pestana }));
}
