// Etapa 0 de la división de server.ts (plan `claude/plan-division-servidor.md`, 09/10/2026).
//
// Muchas pruebas no pueden importar server.ts (arrancaría Express, sharp, etc.) y leen su código
// como texto para controlar que un arreglo siga en su lugar. Cuando el servidor se divida en la
// carpeta `servidor/`, ese código va a estar repartido en varios archivos. Esta función junta
// server.ts + todos los .ts de `servidor/` (sin las pruebas) en un solo texto, así esas pruebas
// siguen andando sin importar en qué archivo quedó cada función.
//
// Siempre normaliza los saltos de línea (CRLF → LF): en la PC de Pablo hay archivos con CRLF.
//
// Etapa 1 (10/10): en los módulos de `servidor/` las declaraciones llevan `export` (en server.ts no lo
// tenían). Acá se les saca, así el texto se lee igual que el server.ts de antes y las pruebas que
// extraen una función con `^function nombre` (y la ejecutan con `new Function`) siguen andando sin
// cambios. `export default` no se toca.
//
// Etapa 2 (10/10): en los módulos, las rutas se declaran en un Router (`const rutas = express.Router()`)
// que server.ts monta en el mismo lugar: `rutas.post('/api/…'`. Acá se leen como `app.post('/api/…'`,
// igual que antes, para las pruebas que buscan una ruta por su texto. Etapa 4: un módulo puede tener
// más de un router (uno por tramo de server.ts), con nombres que empiezan con `rutas`.
import { existsSync, readdirSync, readFileSync, statSync } from 'fs';
import path from 'path';

export const RAIZ_PROYECTO = path.resolve(__dirname, '../..');

function tsDeCarpeta(carpeta: string): string[] {
  if (!existsSync(carpeta)) return [];
  const salida: string[] = [];
  for (const nombre of readdirSync(carpeta).sort()) {
    const completo = path.join(carpeta, nombre);
    if (statSync(completo).isDirectory()) {
      if (nombre === '__tests__' || nombre === 'node_modules') continue;
      salida.push(...tsDeCarpeta(completo));
    } else if (nombre.endsWith('.ts') && !/\.(test|spec)\.ts$/.test(nombre)) {
      salida.push(completo);
    }
  }
  return salida;
}

/** Rutas absolutas del código del servidor: primero server.ts, después `servidor/**` en orden alfabético. */
export function archivosServidor(): string[] {
  return [path.join(RAIZ_PROYECTO, 'server.ts'), ...tsDeCarpeta(path.join(RAIZ_PROYECTO, 'servidor'))];
}

let cache: string | null = null;

const QUITAR_EXPORT = /^export (?=(?:async )?function |const |let |interface |type |class |enum )/gm;
const RUTAS_COMO_APP = /^rutas[A-Za-z]*\.(get|post|put|patch|delete|all)\(/gm; // `rutas`, `rutasOrganizar`, …

/** Todo el código del servidor como un solo texto (con LF), para las pruebas que buscan por texto. */
export function fuenteServidor(): string {
  if (cache === null) {
    cache = archivosServidor()
      .map((archivo) => {
        const relativo = path.relative(RAIZ_PROYECTO, archivo).split(path.sep).join('/');
        const codigo = readFileSync(archivo, 'utf8').replace(/\r\n/g, '\n').replace(QUITAR_EXPORT, '').replace(RUTAS_COMO_APP, 'app.$1(');
        return `\n// ===== archivo: ${relativo} =====\n${codigo}`;
      })
      .join('\n');
  }
  return cache;
}
