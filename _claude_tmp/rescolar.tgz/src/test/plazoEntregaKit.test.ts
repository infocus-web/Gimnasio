// 10/10/2026 (Pablo): el kit impreso se entrega dentro de los 15 días hábiles posteriores al cierre de
// pedidos del curso (Ley 24.240, art. 10 inc. e). El mismo plazo tiene que decirse en todos lados.
import { describe, it, expect } from 'vitest';
import { readFileSync } from 'fs';
import path from 'path';
import { AVISO_ANTES_DE_PAGAR, TERMINOS } from '../legal/textosLegales';
import { PREGUNTAS_FRECUENTES } from '../data/colegiosData';
import { fuenteServidor } from './fuenteServidor';

const PLAZO = '15 días hábiles posteriores al cierre de pedidos del curso';

describe('plazo de entrega del kit impreso', () => {
  it('lo dicen los Términos (punto 4) y el aviso antes de pagar', () => {
    const entrega = TERMINOS.secciones.find((s) => s.titulo === '4. Entrega');
    expect(entrega?.parrafos.join(' ')).toContain(PLAZO);
    expect(AVISO_ANTES_DE_PAGAR.entrega).toContain(PLAZO);
  });

  it('lo dicen las preguntas frecuentes, el portal de familias y la IA de consultas', () => {
    expect(PREGUNTAS_FRECUENTES.map((p) => p.respuesta).join(' ')).toContain(PLAZO);
    const portal = readFileSync(path.resolve(__dirname, '../components/PortalFamiliasModal.tsx'), 'utf8');
    expect(portal.split(PLAZO).length - 1).toBe(3);
    const servidor = fuenteServidor().replace(/\s+/g, ' ');
    expect(servidor).toContain(PLAZO);
    expect(servidor).not.toContain('No prometas fechas');
  });
});
