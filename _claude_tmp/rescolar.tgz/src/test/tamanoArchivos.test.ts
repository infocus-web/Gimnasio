// Límite de tamaño de los archivos de código (10/10/2026, Pablo: «dale» a la regla de las 1.000 líneas
// de la revisión «Thermos»). Ningún archivo puede pasar las 1.000 líneas. Los que ya las pasaban quedan
// con su tamaño de hoy como techo: pueden achicarse, no crecer. Como Vercel corre las pruebas antes de
// cada deploy, si algo de acá falla no se publica.
//
// Si falla:
// - Un archivo nuevo (o que antes tenía menos) pasó las 1.000 líneas: dividilo (componente, helper o
//   módulo aparte) en vez de seguir sumándole.
// - Un archivo de la lista creció: sacá algo a otro archivo hasta volver a su techo.
// - Achicaste uno de la lista: conviene bajar su techo acá (no es obligatorio: achicar nunca frena un
//   deploy); si quedó en 1.000 o menos o lo borraste, sí hay que sacarlo de la lista.
// - Subir un techo es una decisión a propósito: sólo con el OK de Pablo y anotando el motivo al lado.
import fs from 'fs';
import path from 'path';
import { describe, expect, it } from 'vitest';
import { RAIZ_PROYECTO } from './fuenteServidor';

const LIMITE = 1000;
const EXTENSIONES = /\.(ts|tsx|js|jsx|mjs|cjs)$/;
const CARPETAS_IGNORADAS = new Set(['node_modules', '.git', 'dist', 'server-dist', 'build', 'coverage', 'graphify-out', '.vercel', '.claude']);
// Se generan solos en el build a partir de otro archivo (que sí se controla).
const GENERADOS = new Set(['public/eventos/lupa.js']);

// Tamaño al 10/10/2026 de los archivos que ya pasaban las 1.000 líneas (techo: no pueden crecer).
export const TECHOS: Record<string, number> = {
  'src/components/PortalFamiliasModal.tsx': 6262, // 29/10: -35, el pago de «Pasar a Kit Impreso» pasó a PagoPedidoAdicional.tsx. 25/10: +4 líneas, "ya está pagado" al reintentar → verificar estado (antes +6, galería sin vaciarla)
  'src/components/AdminModal.tsx': 3231, // 26/10: +3 líneas, pestaña «Emails» (AdminEmailsTab.tsx). 20/10: «Avance por curso» en ResumenCursosNomina.tsx. 14/10: columnas de la Nómina en ObservacionesNomina.tsx (ColumnasNomina); noche: estado de foto y botones en FiltroFotografiadoNomina.tsx
  'eventos/servidor.ts': 2518, // 27/10: +19 líneas, código de descuento en el pedido (la lógica y la ruta nueva en descuentos.ts). 14/10: Excel y foto de hermanos a excel.ts / fotoHermanos.ts; rutas nuevas en edicionEvento.ts
  'servidor/familias/inscripciones.ts': 1922, // 14/10: enviar-email, rechazar y whatsapp pasaron a inscripcionesAdmin.ts
  'src/components/AdminLoteFotosTab.tsx': 1867, // 14/10: aviso al cerrar y fotos ya subidas en utils/subidaFotos.ts; reenviar aviso en ReenviarAvisoFotos.tsx; 25/10: +2 líneas, «Publicar todos» en PublicarTodosCursos.tsx; +2 «Preparar lupa» (PrepararLupa.tsx)
  'src/components/AdminLaboratorioTab.tsx': 1608, // 25/10: +2 líneas, «Cambiar fotos» en CambiarFotosPedido.tsx
  'public/eventos/admin.js': 1547, // 14/10: la marca de agua de las muestras pasó a ventas.js
  'src/services/pedidosLabService.ts': 1493,
  'src/components/ModalInscripcionFamilia.tsx': 1464,
  'servidor/pagos/crearPedido.ts': 1241,
  'src/components/AdminInscriptosTab.tsx': 1104, // 14/10: envío masivo en inscriptosEnvioMasivo.ts; sin las 3 tarjetas de totales
  'servidor/panel/pedidos.ts': 1057,
};

/** Líneas como las cuenta un editor (igual con saltos CRLF o LF; el último salto no suma una línea). */
export function contarLineas(texto: string): number {
  if (texto.length === 0) return 0;
  return texto.split('\n').length - (texto.endsWith('\n') ? 1 : 0);
}

function archivosDeCodigo(): { archivo: string; lineas: number }[] {
  const lista: { archivo: string; lineas: number }[] = [];
  const recorrer = (carpeta: string) => {
    for (const entrada of fs.readdirSync(carpeta, { withFileTypes: true })) {
      if (CARPETAS_IGNORADAS.has(entrada.name)) continue;
      const ruta = path.join(carpeta, entrada.name);
      if (entrada.isDirectory()) recorrer(ruta);
      else if (EXTENSIONES.test(entrada.name)) {
        const archivo = path.relative(RAIZ_PROYECTO, ruta).split(path.sep).join('/');
        if (!GENERADOS.has(archivo)) lista.push({ archivo, lineas: contarLineas(fs.readFileSync(ruta, 'utf8')) });
      }
    }
  };
  recorrer(RAIZ_PROYECTO);
  return lista;
}

describe('tamaño de los archivos de código', () => {
  const archivos = archivosDeCodigo();
  const lineasDe = (archivo: string) => archivos.find((a) => a.archivo === archivo)?.lineas;

  it('cuenta las líneas igual con CRLF que con LF', () => {
    expect(contarLineas('a\nb\n')).toBe(2);
    expect(contarLineas('a\r\nb\r\n')).toBe(2);
    expect(contarLineas('a\nb')).toBe(2);
    expect(contarLineas('')).toBe(0);
  });

  it('está mirando el código del proyecto', () => {
    expect(archivos.length).toBeGreaterThan(150);
    expect(lineasDe('server.ts')).toBeGreaterThan(0);
    expect(lineasDe('src/components/PortalFamiliasModal.tsx')).toBeGreaterThan(0);
  });

  it(`ningún archivo pasa las ${LIMITE} líneas (salvo los de la lista, que tienen su techo)`, () => {
    const excedidos = archivos
      .filter((a) => !(a.archivo in TECHOS) && a.lineas > LIMITE)
      .map((a) => `${a.archivo}: ${a.lineas} líneas (máximo ${LIMITE}): dividilo en archivos más chicos`);
    expect(excedidos).toEqual([]);
  });

  it('los archivos que ya pasaban las 1.000 líneas no crecen', () => {
    const crecieron = Object.entries(TECHOS).flatMap(([archivo, techo]) => {
      const lineas = lineasDe(archivo);
      return lineas !== undefined && lineas > techo
        ? [`${archivo}: ${lineas} líneas, su techo es ${techo}: sacá algo a otro archivo`]
        : [];
    });
    expect(crecieron).toEqual([]);
  });

  it('la lista de techos no tiene archivos borrados ni que ya bajaron de 1.000 líneas', () => {
    const desactualizados = Object.entries(TECHOS).flatMap(([archivo, techo]) => {
      const lineas = lineasDe(archivo);
      if (lineas === undefined) return [`${archivo}: ya no existe, sacalo de TECHOS`];
      if (lineas <= LIMITE) return [`${archivo}: quedó en ${lineas} líneas, sacalo de TECHOS (desde ahora vale el límite de ${LIMITE})`];
      return [];
    });
    expect(desactualizados).toEqual([]);
  });
});
