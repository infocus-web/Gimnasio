// 25/10/2026 (Pablo): la IA de consultas tiene que saber responder sobre el aviso «ya están tus fotos», el buscador
// por rostro y los pedidos de fotos faltantes, sin hablar nunca de repetir una foto que no gustó.
import { describe, expect, it } from 'vitest';
import { contextoNegocioConsultas } from '../../../servidor/familias/contextoConsultas';

describe('contexto de la IA de consultas: proceso de fotos online', () => {
  const texto = contextoNegocioConsultas();

  it('explica el email de aviso y qué hacer si no llegó', () => {
    expect(texto).toContain('=== EL EMAIL «LAS FOTOS YA ESTÁN ONLINE» ===');
    expect(texto).toContain('Spam/Promociones');
    expect(texto).toContain('«Confirmar mis fotos»');
  });

  it('explica el buscador por rostro, sus mensajes y la privacidad', () => {
    expect(texto).toContain('«Buscar por rostro»');
    expect(texto).toContain('Busca sólo fotos INDIVIDUALES');
    expect(texto).toContain('«No encontramos una cara en la foto»');
    expect(texto).toContain('no se guarda');
    expect(texto).toContain('se borra al finalizar el año escolar');
  });

  it('explica las fotos faltantes con su fecha límite y prohíbe hablar de repetir fotos', () => {
    expect(texto).toContain('HASTA EL 15 DE NOVIEMBRE INCLUSIVE');
    expect(texto).toContain('«Ya podés cerrar el kit de [alumno]»');
    expect(texto).toContain('no hables de');
    expect(texto).toContain('NUNCA inventes fechas de tomas');
    expect(texto).toContain('EL KIT LLEVA SIEMPRE LAS 3 FOTOS'); // 26/10
    expect(texto).toContain('«No está en la grupal: avisar»');
    expect(texto).toContain('«Día para la foto de [alumno]»');
  });
});
