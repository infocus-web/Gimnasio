// 12/10/2026 (error real de Pablo: «Aprobación masiva terminada con errores… SALA4-JOJE»): el formulario
// de inscripción dejaba elegir cursos que no existen (división «Jornada Extendida» en Sala 4, cuando ahí la
// jornada extendida es el turno de la A o la C). Ahora el servidor sólo acepta cursos de la nómina y
// GET /api/colegios/:id/cursos le dice al formulario cuáles son.
import http from 'http';
import type { AddressInfo } from 'net';
import express from 'express';
import { afterAll, beforeAll, beforeEach, describe, expect, it, vi } from 'vitest';
import { estado } from '../auditoria1110/familias/baseFalsa';

vi.mock('dotenv', () => {
  const config = () => ({ parsed: {} });
  return { default: { config }, config };
});
vi.mock('@supabase/supabase-js', async () => {
  const b = await import('../auditoria1110/familias/baseFalsa');
  return { createClient: () => ({ from: (t: string) => b.consulta(t), rpc: (n: string, a: any) => b.rpc(n, a), storage: b.storage }) };
});
vi.mock('resend', async () => {
  const b = await import('../auditoria1110/familias/baseFalsa');
  return {
    Resend: class {
      emails = { send: async (m: any) => (b.estado.correos.push(m), { data: { id: 'x' }, error: null }) };
      batch = { send: async () => ({ data: { data: [] }, error: null }) };
    },
  };
});

const COLEGIO = '11111111-1111-4111-8111-111111111111';
const JE = 'Jornada Extendida / Completa';
let VERSION_TERMINOS_SERVIDOR = '';
let limpiarCache: () => void = () => undefined;
let servidor: http.Server;
let puerto = 0;
const entornoAntes: Record<string, string | undefined> = {};

let ipN = 0;
function pedir(metodo: string, ruta: string, cuerpo?: unknown): Promise<{ status: number; json: any; texto: string }> {
  return new Promise((ok, mal) => {
    const datos = cuerpo === undefined ? undefined : JSON.stringify(cuerpo);
    ipN++;
    const encabezados: Record<string, string | number> = { 'X-Forwarded-For': `10.8.${Math.floor(ipN / 250)}.${ipN % 250}` };
    if (datos) {
      encabezados['Content-Type'] = 'application/json';
      encabezados['Content-Length'] = Buffer.byteLength(datos);
    }
    const req = http.request({ host: '127.0.0.1', port: puerto, path: ruta, method: metodo, headers: encabezados }, (res) => {
      let texto = '';
      res.setEncoding('utf8');
      res.on('data', (c) => { texto += c; });
      res.on('end', () => {
        let json: any = null;
        try { json = JSON.parse(texto); } catch { /* no JSON */ }
        ok({ status: res.statusCode || 0, json, texto });
      });
    });
    req.on('error', mal);
    if (datos) req.write(datos);
    req.end();
  });
}

const inscribir = (extra: Record<string, any> = {}) =>
  pedir('POST', '/api/inscripciones/validar', {
    colegioId: COLEGIO, colegioNombre: 'Colegio', padreNombre: 'Ana Tutora', padreDni: '20111222', telefonoWhatsApp: '1144445555',
    email: 'ana@familia.test', alumnoNombre: 'Salvador', alumnoApellido: 'Prueba', alumnoDni: '50111222',
    grado: 'Sala 4 años', division: 'C', turno: JE, consentimientos: { toma: true, grupal: true, transferencia: true },
    versionTerminos: VERSION_TERMINOS_SERVIDOR, ...extra,
  });

const alumno = (nombre: string, grado: string, division: string, turno: string | null) => ({ id: `al-${nombre}`, colegio_id: COLEGIO, nombre, grado, division, turno });

beforeAll(async () => {
  for (const n of ['SUPABASE_SERVICE_ROLE_KEY', 'ADMIN_SESSION_SECRET', 'RESEND_API_KEY']) entornoAntes[n] = process.env[n];
  process.env.SUPABASE_SERVICE_ROLE_KEY = 'prueba';
  process.env.ADMIN_SESSION_SECRET = 'secreto-de-prueba';
  process.env.RESEND_API_KEY = 're_prueba';
  ({ VERSION_TERMINOS_SERVIDOR } = await import('../../../servidor/nucleo/legal'));
  const modulo = await import('../../../servidor/familias/cursosNomina');
  limpiarCache = modulo.limpiarCacheCursosNomina;
  const app = express();
  app.set('trust proxy', true);
  app.use(express.json());
  app.use((await import('../../../servidor/familias/inscripciones')).rutasInscripciones);
  app.use(modulo.rutasCursosNomina);
  servidor = app.listen(0);
  await new Promise((ok) => servidor.once('listening', ok));
  puerto = (servidor.address() as AddressInfo).port;
}, 120_000);

afterAll(async () => {
  await new Promise((ok) => servidor.close(ok));
  for (const [n, v] of Object.entries(entornoAntes)) {
    if (v === undefined) delete process.env[n];
    else process.env[n] = v;
  }
});

beforeEach(() => {
  limpiarCache();
  estado.correos = [];
  estado.latenciaMs = 0;
  estado.tablaQueFalla = '';
  // Como el Divino Pastor: en Sala 4 la jornada extendida es el TURNO de la A y la C; «Jornada Extendida»
  // como división existe sólo en 5° grado. En secundaria la nómina no trae turno.
  estado.tablas = {
    colegios: [{ id: COLEGIO, nombre: 'Colegio' }],
    alumnos: [
      alumno('UNO, A', 'Sala 4 años', 'A', JE), alumno('DOS, A', 'Sala 4 años', 'A', 'Mañana'), alumno('TRES, B', 'Sala 4 años', 'B', 'Tarde'),
      alumno('CUATRO, C', 'Sala 4 años', 'C', JE), alumno('CINCO, C', 'Sala 4 años', 'C', 'Tarde'), alumno('SEIS, C', 'Sala 4 años', 'C', JE),
      alumno('SIETE, JE', '5° grado', 'Jornada Extendida', JE), alumno('OCHO, A', '5° grado', 'A', 'Mañana'),
      alumno('NUEVE, B', '1° año', 'B', null),
    ],
    codigos_seccion: [], inscripciones: [], padres_autorizados: [], fotos: [], limites_intentos: [], solicitudes_codigo: [],
    consultas_familias: [], familias: [], pedidos: [], reportes_errores: [],
  };
});

describe('cursos de la nómina', () => {
  it('GET /api/colegios/:id/cursos: cada curso una vez, sin datos de los alumnos', async () => {
    const r = await pedir('GET', `/api/colegios/${COLEGIO}/cursos`);
    expect(r.status).toBe(200);
    expect(r.json.cursos).toHaveLength(8);
    expect(r.json.cursos).toContainEqual({ grado: 'Sala 4 años', division: 'C', turno: JE });
    expect(r.json.cursos).toContainEqual({ grado: '1° año', division: 'B', turno: null });
    expect(r.texto).not.toMatch(/UNO|CUATRO|NUEVE/);
    expect((await pedir('GET', '/api/colegios/22222222-2222-4222-8222-222222222222/cursos')).status).toBe(404);
  });

  it('el caso real: Sala 4 con división «Jornada Extendida» no se acepta y explica qué cursos hay', async () => {
    const r = await inscribir({ division: 'Jornada Extendida', turno: JE });
    expect(r.status).toBe(400);
    expect(r.json.error).toContain('en Sala 4 años no existe Jornada Extendida');
    expect(r.json.error).toContain('división C (Jornada Extendida / Completa)');
    expect(estado.tablas.inscripciones).toHaveLength(0);
  });

  it('un curso que existe se acepta (y «Jornada Extendida» como división vale donde sí existe)', async () => {
    expect((await inscribir()).status).toBe(200);
    expect(estado.tablas.inscripciones[0]).toMatchObject({ grado: 'Sala 4 años', division: 'C', turno: JE });
    expect((await inscribir({ email: 'otra@familia.test', telefonoWhatsApp: '1155556666', alumnoDni: '50999888', grado: '5° grado', division: 'Jornada Extendida', turno: JE })).status).toBe(200);
  });

  it('turno que no corresponde a la división: no (Sala 4 B es sólo de tarde)', async () => {
    const r = await inscribir({ division: 'B', turno: 'Mañana' });
    expect(r.status).toBe(400);
    expect(r.json.error).toContain('división B (Tarde)');
  });

  it('hermanos: la misma regla, avisando cuál de los chicos está mal', async () => {
    const r = await inscribir({ hermanos: [{ alumnoNombre: 'Pablita', alumnoApellido: 'Prueba', alumnoDni: '50333444', grado: 'Sala 4 años', division: 'Jornada Extendida', turno: 'Mañana' }] });
    expect(r.status).toBe(400);
    expect(r.json.error).toContain('Pablita Prueba');
  });

  it('secundaria (nómina sin turno): cualquier turno vale, pero la división tiene que existir', async () => {
    expect((await inscribir({ grado: '1° año', division: 'B', turno: 'Tarde' })).status).toBe(200);
    expect((await inscribir({ email: 'x@familia.test', telefonoWhatsApp: '1177778888', alumnoDni: '50777666', grado: '1° año', division: 'D', turno: 'Mañana' })).status).toBe(400);
  });

  it('un grado que no está en la nómina no se frena (colegio sin nómina o grado sin cargar)', async () => {
    expect((await inscribir({ grado: '7° grado', division: 'A', turno: 'Mañana' })).status).toBe(200);
  });
});
