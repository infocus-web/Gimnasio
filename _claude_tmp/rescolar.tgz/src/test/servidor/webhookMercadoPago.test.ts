// 10/10/2026: avisos de Mercado Pago al webhook general (servidor/pagos/mercadoPago.ts).
//
// Mercado Pago avisa cada pago dos veces: por Webhooks (`?data.id=…&type=payment`, firmado con la clave
// secreta) y por IPN (`?topic=payment|merchant_order&id=…`). Los IPN traen x-signature pero Mercado Pago
// aclara que no se pueden validar con la clave: antes se contestaban 401 y MP los reintentaba durante
// días. Ahora se contestan 200 sin procesar nada, y los avisos por Webhooks se siguen validando igual.
// Nada sale a la red: Mercado Pago está reemplazado por un doble y no hay Supabase.
import crypto from 'crypto';
import http from 'http';
import type { AddressInfo } from 'net';
import { afterAll, beforeAll, beforeEach, describe, expect, it, vi } from 'vitest';

vi.mock('dotenv', () => {
  const config = () => ({ parsed: {} });
  return { default: { config }, config };
});

const mp = vi.hoisted(() => ({ consultas: [] as string[] }));
vi.mock('mercadopago', () => ({
  MercadoPagoConfig: class {},
  Preference: class {
    async create() {
      throw new Error('no se usa en esta prueba');
    }
  },
  Payment: class {
    async get({ id }: { id: string }) {
      mp.consultas.push(String(id));
      return { status: 'pending', external_reference: null };
    }
    async search() {
      return { results: [] };
    }
  },
}));

const CLAVE = 'clave-de-prueba';
let servidor: http.Server;
let puerto = 0;
let vercelAntes: string | undefined;

function avisar(ruta: string, cuerpo: unknown, encabezados: Record<string, string> = {}): Promise<{ status: number; texto: string }> {
  return new Promise((ok, mal) => {
    const datos = JSON.stringify(cuerpo);
    const req = http.request(
      { host: '127.0.0.1', port: puerto, path: ruta, method: 'POST', headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(datos), ...encabezados } },
      (res) => {
        let texto = '';
        res.setEncoding('utf8');
        res.on('data', (c) => { texto += c; });
        res.on('end', () => ok({ status: res.statusCode || 0, texto }));
      },
    );
    req.on('error', mal);
    req.write(datos);
    req.end();
  });
}

/** Firma como lo hace Mercado Pago en los avisos por Webhooks. */
function firmar(id: string, requestId: string, ts: number): Record<string, string> {
  const v1 = crypto.createHmac('sha256', CLAVE).update(`id:${id};request-id:${requestId};ts:${ts};`).digest('hex');
  return { 'x-signature': `ts=${ts},v1=${v1}`, 'x-request-id': requestId };
}

beforeAll(async () => {
  vercelAntes = process.env.VERCEL;
  process.env.VERCEL = '1'; // server.ts no arranca Vite ni listen
  process.env.MERCADOPAGO_ACCESS_TOKEN = 'prueba';
  process.env.MERCADOPAGO_WEBHOOK_SECRET = CLAVE;
  const app = (await import('../../../server')).default as any;
  servidor = app.listen(0);
  await new Promise((ok) => servidor.once('listening', ok));
  puerto = (servidor.address() as AddressInfo).port;
}, 120_000);

afterAll(async () => {
  await new Promise((ok) => servidor.close(ok));
  delete process.env.MERCADOPAGO_ACCESS_TOKEN;
  delete process.env.MERCADOPAGO_WEBHOOK_SECRET;
  if (vercelAntes === undefined) delete process.env.VERCEL;
  else process.env.VERCEL = vercelAntes;
});

beforeEach(() => {
  mp.consultas.length = 0;
});

describe('webhook de Mercado Pago: avisos IPN', () => {
  it('reconoce el formato IPN y no confunde el de Webhooks', async () => {
    const { esAvisoIpn } = await import('../../../servidor/pagos/mercadoPago');
    expect(esAvisoIpn({ topic: 'payment', id: '1' })).toBe(true);
    expect(esAvisoIpn({ topic: 'merchant_order', id: '2' })).toBe(true);
    expect(esAvisoIpn({ 'data.id': '1', type: 'payment' })).toBe(false);
    expect(esAvisoIpn({})).toBe(false);
  });

  it('un aviso IPN (payment o merchant_order) se contesta 200 sin consultar el pago', async () => {
    for (const ruta of ['/api/mercadopago/webhook?topic=payment&id=181979590117', '/api/mercadopago/webhook?topic=merchant_order&id=45069819741', '/mercadopago/webhook?topic=payment&id=1']) {
      const r = await avisar(ruta, { resource: '181979590117', topic: 'payment' }, { 'x-signature': 'ts=1,v1=cualquiera', 'x-request-id': 'r1' });
      expect(r.status).toBe(200);
    }
    expect(mp.consultas).toEqual([]);
  });
});

describe('webhook de Mercado Pago: avisos por Webhooks (siguen validándose igual)', () => {
  const RUTA = '/api/mercadopago/webhook?data.id=123&type=payment';
  const CUERPO = { type: 'payment', action: 'payment.updated', data: { id: '123' } };

  it('sin firma → 401', async () => {
    expect((await avisar(RUTA, CUERPO)).status).toBe(401);
  });

  it('con firma inválida → 401', async () => {
    const r = await avisar(RUTA, CUERPO, { 'x-signature': `ts=${Math.floor(Date.now() / 1000)},v1=${'0'.repeat(64)}`, 'x-request-id': 'r2' });
    expect(r.status).toBe(401);
    expect(mp.consultas).toEqual([]);
  });

  it('con firma válida pero de hace más de 72 h → 401', async () => {
    const r = await avisar(RUTA, CUERPO, firmar('123', 'r3', Math.floor(Date.now() / 1000) - 100 * 3600));
    expect(r.status).toBe(401);
    expect(r.texto).toBe('Stale notification');
  });

  it('con firma válida y reciente → 200 y se consulta el pago a Mercado Pago', async () => {
    const r = await avisar(RUTA, CUERPO, firmar('123', 'r4', Math.floor(Date.now() / 1000)));
    expect(r.status).toBe(200);
    expect(mp.consultas).toEqual(['123']);
  });
});
