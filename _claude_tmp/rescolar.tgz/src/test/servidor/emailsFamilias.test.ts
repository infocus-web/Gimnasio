// 26/10/2026: panel «Emails» a las familias (grupos, tipos, IA, prueba, envío por tandas, historial y rebotes).
import { readFileSync } from 'fs';
import path from 'path';
import { describe, expect, it } from 'vitest';
import { fuenteServidor } from '../fuenteServidor';
import { armarCorreo, calcularDestinatarios, contenidoDeFamilia, faltaFotoDelPack, franjaPorTurnos, turnoDeCodigoCurso, leerContenido, leerFiltro, personalizar, repartirCitas } from '../../../servidor/panel/emailsFamilias';

const familia = { email: 'f@x.com', tutor: 'María Belén López', alumnos: ['Sofía López', 'Juan López'], inscripcionId: null, faltanteIds: [] };

describe('panel Emails', () => {
  it('filtros: grupo válido, cursos limpios, una familia exige email', () => {
    expect(leerFiltro({ grupo: 'faltantes', cursos: ['sala4-ctt', 'x;drop', 'SALA4-CTT'] })).toEqual({ grupo: 'faltantes', cursos: ['SALA4-CTT'], email: '' });
    expect(leerFiltro({ grupo: 'familia', email: 'no-es-mail' })).toBeNull();
    expect(leerFiltro({ grupo: 'cualquiera' })).toBeNull();
  });

  it('29/10: «Pagaron y les faltan fotos»: pedidos pagados sin grupal o sin individual, filtrados por curso, uno por email', async () => {
    expect(leerFiltro({ grupo: 'pagados_sin_fotos', cursos: ['anio3-atm'] })).toEqual({ grupo: 'pagados_sin_fotos', cursos: ['ANIO3-ATM'], email: '' });
    expect(faltaFotoDelPack({ grupalId: 'g', individualId: 'i' })).toBe(false);
    expect(faltaFotoDelPack({ grupalId: 'g', individualId: '' })).toBe(true);
    expect(faltaFotoDelPack(null)).toBe(true);
    const pedidos = [
      { id: '1', familia_id: 'fa', curso_codigo: 'ANIO3-ATM', alumno_nombre: 'Ana', fotos_seleccionadas: { grupalId: 'g' } },
      { id: '2', familia_id: 'fa', curso_codigo: 'ANIO3-ATM', alumno_nombre: 'Luz', fotos_seleccionadas: {} },
      { id: '3', familia_id: 'fb', curso_codigo: 'ANIO3-ATM', alumno_nombre: 'Completo', fotos_seleccionadas: { grupalId: 'g', individualId: 'i' } },
      { id: '4', familia_id: 'fc', curso_codigo: 'GRADO2-BTT', alumno_nombre: 'Otro curso', fotos_seleccionadas: {} },
      { id: '5', familia_id: 'fd', curso_codigo: 'ANIO3-ATM', alumno_nombre: 'Archivado', fotos_seleccionadas: {}, archivado: true },
    ];
    const familias = [{ id: 'fa', email: 'A@x.com', nombre: 'Marta' }, { id: 'fc', email: 'c@x.com', nombre: 'C' }, { id: 'fd', email: 'd@x.com', nombre: 'D' }];
    const consulta = (filas: any[]) => {
      const q: any = { select: () => q, eq: () => q, is: () => q, order: () => q, in: async (_c: string, ids: string[]) => ({ data: filas.filter((f) => ids.includes(f.id)), error: null }), range: async (desde: number) => ({ data: desde === 0 ? filas : [], error: null }) };
      return q;
    };
    const supabase: any = { from: (t: string) => consulta(t === 'pedidos' ? pedidos : familias) };
    const lista = await calcularDestinatarios(supabase, { grupo: 'pagados_sin_fotos', cursos: ['ANIO3-ATM'], email: '' });
    expect(lista).toEqual([expect.objectContaining({ email: 'a@x.com', tutor: 'Marta', alumnos: ['Ana', 'Luz'], turnos: ['Mañana'] })]);
  });

  it('contenido: asunto y texto obligatorios; la citación exige día, hora y lugar; la encuesta no pide nada', () => {
    expect(leerContenido('mensaje', { asunto: 'Hola', texto: '' }).ok).toBe(false);
    expect(leerContenido('citacion', { asunto: 'Foto de hermanos', texto: 'Los esperamos', dia: '2026-10-29', hora: '10 hs' }).ok).toBe(false);
    expect(leerContenido('citacion', { asunto: 'Foto de hermanos', texto: 'Los esperamos', dia: '2026-10-29', hora: '10 hs', lugar: 'Salón' }).ok).toBe(true);
    expect(leerContenido('encuesta', {}).ok).toBe(true);
  });

  it('personaliza {nombre} y {alumnos}', () => {
    expect(personalizar('Hola {nombre}, las fotos de {alumnos}', familia)).toBe('Hola María, las fotos de Sofía y Juan');
  });

  it('el mail: saludo, recuadro de la citación, código de la promoción y el texto escapado', () => {
    const citacion = armarCorreo('citacion', 'Te esperamos', { texto: 'Traé <b>uniforme</b>', boton: false, dia: '2026-10-29', hora: '10 hs', lugar: 'Salón de actos', codigo: '', vence: '' }, familia);
    expect(citacion.to).toEqual(['f@x.com']);
    expect(citacion.html).toContain('Hola <strong>María</strong>');
    expect(citacion.html).toContain('Salón de actos');
    expect(citacion.html).toContain('Traé &lt;b&gt;uniforme&lt;/b&gt;');
    const promo = armarCorreo('promocion', '15% para {nombre}', { texto: 'Aprovechá', boton: false, dia: '', hora: '', lugar: '', codigo: 'FOTO15', vence: '2026-11-15' }, familia);
    expect(promo.subject).toBe('15% para María');
    expect(promo.html).toContain('FOTO15');
    expect(promo.html).toContain('Ver mis fotos');
  });

  it('citación repartida: franja por turno, mediodía para ambos turnos y reparto parejo entre los días', () => {
    expect(franjaPorTurnos(['Mañana', 'Tarde'])).toBe('ambos');
    expect(franjaPorTurnos(['Jornada Extendida / Completa', 'Mañana'])).toBe('manana');
    expect(franjaPorTurnos(['Tarde', 'Jornada Extendida / Completa'])).toBe('tarde');
    expect(franjaPorTurnos(['Jornada Extendida / Completa'])).toBe('completa');
    expect(franjaPorTurnos([])).toBe('general');
    expect(['GRADO2-BTT', 'ANIO1-ATM', 'SALA5-AJE', 'X'].map(turnoDeCodigoCurso)).toEqual(['Tarde', 'Mañana', 'Jornada Extendida', '']);
    const cinco = leerContenido('citacion', { asunto: 'Fotos', texto: 'Los esperamos', hora: '10 h', lugar: 'Colegio', reparto: true, dias: ['2026-10-30', '2026-10-26', '2026-10-27', '2026-10-28', '2026-10-29'] });
    expect(cinco.ok && cinco.contenido.dias).toEqual(['2026-10-26', '2026-10-27', '2026-10-28', '2026-10-29', '2026-10-30']);
    const leido = leerContenido('citacion', { asunto: 'Foto de hermanos', texto: 'Los esperamos', hora: '10:30 a 14:30 h', lugar: 'Colegio', reparto: true, dias: ['2026-10-30', '2026-10-28', '', '2026-10-29'] });
    if (!leido.ok) throw new Error('debería ser válido');
    expect(leido.contenido.dias).toEqual(['2026-10-28', '2026-10-29', '2026-10-30']);
    const turnos = [...Array(20).fill(['Mañana', 'Tarde']), ...Array(36).fill(['Mañana']), ...Array(16).fill(['Tarde']), ...Array(15).fill(['Jornada Extendida / Completa'])];
    const lista = turnos.map((t, i) => ({ email: `f${String(i).padStart(2, '0')}@x.com`, tutor: '', alumnos: [], inscripcionId: null, faltanteIds: [], turnos: t }));
    const citas = repartirCitas(lista, leido.contenido);
    const porDia = (dia: string) => Object.values(citas).filter((c) => c.dia === dia).length;
    expect([porDia('2026-10-28'), porDia('2026-10-29'), porDia('2026-10-30')].sort()).toEqual([29, 29, 29]);
    const ambosPorDia = ['2026-10-28', '2026-10-29', '2026-10-30'].map((d) => Object.values(citas).filter((c) => c.dia === d && c.franja === 'ambos').length);
    expect(Math.max(...ambosPorDia) - Math.min(...ambosPorDia)).toBeLessThanOrEqual(1);
    expect(citas['f00@x.com'].hora).toBe('12:00 a 13:00 h');
    const c = contenidoDeFamilia({ ...leido.contenido, citas }, 'F00@x.com');
    const html = armarCorreo('citacion', 'Te esperamos', c, lista[0]).html;
    expect(html).toContain('12:00 a 13:00 h');
    expect(html).toMatch(/de octubre/);
    expect(armarCorreo('citacion', 'x', c, { ...lista[0], tutor: 'Pablo Alderete' }).html).toContain('¡Hola <strong>Pablo</strong>!');
  });

  it('rutas: todo exige admin; el envío es por tandas con clave de idempotencia; la citación a faltantes queda anotada; los rebotes se marcan', () => {
    const server = fuenteServidor();
    for (const ruta of ["app.get('/api/admin/emails/cursos'", "app.post('/api/admin/emails/destinatarios'", "app.post('/api/admin/emails/redactar', requireAdminAuth", "app.post('/api/admin/emails/prueba'", "app.post('/api/admin/emails/envios'", "app.post('/api/admin/emails/envios/:id/enviar'", "app.get('/api/admin/emails/rebotes'", "app.post('/api/admin/emails/corregir-email'"]) {
      expect(server).toContain(`${ruta}`);
    }
    expect(server).not.toMatch(/app\.(get|post)\('\/api\/admin\/emails\/[^']*', (?!requireAdminAuth)/);
    expect(server).toContain('idempotencyKey: `envio-familias-${clave}`');
    expect(server).toContain("from('fotos_faltantes_solicitudes')\n            .update({ convocatoria_dia: c.dia");
    expect(server).toContain("await registrarRebotesEnvios(supabase, emailId");
  });

  it('las tablas tienen RLS y un destinatario por casilla en cada envío', () => {
    const sql = readFileSync(path.resolve(__dirname, '../../../supabase/migrations/20261026000000_envios_email.sql'), 'utf8');
    expect(sql.match(/enable row level security/g)).toHaveLength(2);
    expect(sql).toContain('unique (envio_id, email)');
  });
});
