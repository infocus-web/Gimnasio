// 25/10/2026 (Pablo: «la IA debe actualizarse en tiempo real, con todos los cambios que vamos haciendo»).
import { describe, expect, it } from 'vitest';
import { fuenteServidor } from '../fuenteServidor';
import { contextoNegocioConsultas, fijarNovedadesEquipo } from '../../../servidor/familias/contextoConsultas';

describe('IA de consultas al día', () => {
  it('«Lo que la IA tiene que saber» entra al contexto con prioridad, y sin texto no aparece la sección', () => {
    fijarNovedadesEquipo('');
    expect(contextoNegocioConsultas()).not.toContain('NOVEDADES Y DECISIONES DEL EQUIPO');
    fijarNovedadesEquipo('Sala 4 C mañana: la grupal se saca el jueves 29/10 a las 10.');
    const ctx = contextoNegocioConsultas();
    expect(ctx).toContain('TIENEN PRIORIDAD');
    expect(ctx).toContain('la grupal se saca el jueves 29/10 a las 10.');
    expect(ctx.indexOf('NOVEDADES Y DECISIONES')).toBeLessThan(ctx.indexOf('=== TU TAREA ==='));
    fijarNovedadesEquipo('');
  });

  it('se guarda sólo del lado del servidor (borradores_admin, no configuracion que es pública), con admin, y se relee cada 30 s', () => {
    const server = fuenteServidor();
    expect(server).toContain("app.get('/api/admin/novedades-ia', requireAdminAuth");
    expect(server).toContain("app.put('/api/admin/novedades-ia', requireAdminAuth");
    expect(server).toContain("from('borradores_admin').upsert([{ clave: CLAVE, contenido: texto");
    expect(server).not.toMatch(/from\('configuracion'\)[^\n]*novedades/);
    expect(server).toContain('novedadesVencen = Date.now() + 30_000;');
  });

  it('la IA ve las fotos elegidas de cada pedido (con su número) y sabe cambiar sólo la impresa', () => {
    const server = fuenteServidor();
    expect(server).toContain('fotos elegidas para imprimir: ');
    expect(contextoNegocioConsultas().replace(/\s+/g, ' ')).toContain('igual cambiamos la foto de la COPIA IMPRESA');
  });

  it('un borrador nuevo de la IA descarta la copia vieja guardada del cuadro de respuesta', () => {
    expect(fuenteServidor()).toContain("from('borradores_admin').delete().eq('clave', `consulta-${consulta.id}`)");
  });
});
