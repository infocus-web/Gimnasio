// 26/10/2026 (Pablo: «busca una solución definitiva, no me sirve una IA que responda tan mal y genéricamente»).
// Banco de pruebas de las respuestas a consultas, armado con los casos reales de ese día (con nombres de prueba):
// - Colomba: «la foto con Valentina» era la foto de hermanos y estaba CITADO; la IA dijo «no figura ninguna convocatoria».
// - Villar: «Riesmersma» en la nómina por «Riemersma»; la IA dijo que el chico no figuraba.
// - Arbelo: en 1° año C no hay tercera foto; la IA prometía cosas que nadie decidió.
// Y las reglas nuevas: cada afirmación tiene que citar un dato que exista, un control revisa el borrador, y la respuesta
// sólo sale sola si pasó el control sin problemas, sin dudas ni decisiones pendientes.
import crypto from 'crypto';
import http from 'http';
import type { AddressInfo } from 'net';
import express from 'express';
import { afterAll, beforeAll, beforeEach, describe, expect, it, vi } from 'vitest';
import { estado } from '../auditoria1110/familias/baseFalsa';

type Llamada = { sistema: string; prompt: string; esfuerzo?: string };
const ia = vi.hoisted(() => ({ llamadas: [] as Llamada[], redaccion: {} as any, control: {} as any }));

vi.mock('dotenv', () => {
  const config = () => ({ parsed: {} });
  return { default: { config }, config };
});
vi.mock('@supabase/supabase-js', async () => {
  const b = await import('../auditoria1110/familias/baseFalsa');
  return { createClient: () => ({ from: (t: string) => b.consulta(t), rpc: (n: string, a: any) => b.rpc(n, a), storage: b.storage }) };
});
vi.mock('resend', async () => {
  const b = await import('../auditoria1110/familias/baseFalsa');
  return {
    Resend: class {
      emails = { send: async (m: any) => (b.estado.correos.push(m), { data: { id: 'x' }, error: null }) };
      batch = { send: async () => ({ data: { data: [] }, error: null }) };
    },
  };
});
vi.mock('../../../servidor/nucleo/ia', async (original) => ({
  ...((await original()) as object),
  iaConfigurada: () => true,
  ERROR_IA_NO_CONFIGURADA: 'sin ia',
  generarTextoIA: async (p: Llamada) => {
    ia.llamadas.push(p);
    return JSON.stringify(p.prompt.startsWith('Sos el control de calidad') ? ia.control : ia.redaccion);
  },
}));

const COLEGIO = '11111111-1111-4111-8111-111111111111';
let tokenAdmin = '';
let limpiarCache: () => void = () => undefined;
let servidor: http.Server;
let puerto = 0;
const entornoAntes: Record<string, string | undefined> = {};
let ipN = 0;

function pedir(metodo: string, ruta: string, cuerpo?: unknown, admin = false): Promise<{ status: number; json: any }> {
  return new Promise((ok, mal) => {
    const datos = cuerpo === undefined ? undefined : JSON.stringify(cuerpo);
    ipN++;
    const encabezados: Record<string, string | number> = { 'X-Forwarded-For': `10.9.${Math.floor(ipN / 250)}.${ipN % 250}` };
    if (admin) encabezados.Authorization = `Bearer ${tokenAdmin}`;
    if (datos) {
      encabezados['Content-Type'] = 'application/json';
      encabezados['Content-Length'] = Buffer.byteLength(datos);
    }
    const req = http.request({ host: '127.0.0.1', port: puerto, path: ruta, method: metodo, headers: encabezados }, (res) => {
      let texto = '';
      res.setEncoding('utf8');
      res.on('data', (c) => { texto += c; });
      res.on('end', () => {
        let json: any = null;
        try { json = JSON.parse(texto); } catch { /* no JSON */ }
        ok({ status: res.statusCode || 0, json });
      });
    });
    req.on('error', mal);
    if (datos) req.write(datos);
    req.end();
  });
}

const inscripcion = (extra: Record<string, any>) => ({
  id: crypto.randomUUID(), colegio_id: COLEGIO, colegio_nombre: 'Colegio', padre_dni: '20111222', hermanos: [], estado: 'aceptado',
  notificacion_email_enviada: true, codigo_asignado: 'ABCD-EFGH', grado: '3° grado', division: 'A', turno: 'Mañana', ...extra,
});
const consultar = (email: string, mensaje: string) => pedir('POST', '/api/consultas-familias', { nombre: 'Familia', email, asunto: 'Consulta', mensaje });
const redaccionOk = (extra: Record<string, any> = {}) => ({
  tema: 'funcionamiento', entendido: 'Pregunta cómo pagar por transferencia.', ambiguedades: [], decisiones: [],
  afirmaciones: [{ texto: 'Juan está en 3° grado A.', fuente: 'C1' }, { texto: 'Se paga desde la web.', fuente: 'REGLA: medios de pago' }],
  respondible: true, respuesta: 'Podés pagar por transferencia desde la web, al elegir el medio de pago.', motivo: 'x', ...extra,
});
const correosA = (email: string) => estado.correos.filter((c) => c.to?.[0] === email || c.to === email);
const guardada = (email: string) => estado.tablas.consultas_familias.find((c) => c.email === email);
const promptRedaccion = () => ia.llamadas.find((l) => !l.prompt.startsWith('Sos el control de calidad'))!.prompt;

beforeAll(async () => {
  for (const n of ['SUPABASE_SERVICE_ROLE_KEY', 'ADMIN_SESSION_SECRET', 'RESEND_API_KEY', 'RESPUESTAS_AUTOMATICAS']) entornoAntes[n] = process.env[n];
  process.env.SUPABASE_SERVICE_ROLE_KEY = 'prueba';
  process.env.ADMIN_SESSION_SECRET = 'secreto-de-prueba';
  process.env.RESEND_API_KEY = 're_prueba';
  delete process.env.RESPUESTAS_AUTOMATICAS;
  tokenAdmin = (await import('../../../servidor/nucleo/auth')).generateAdminToken() || '';
  limpiarCache = (await import('../../../servidor/familias/cursosNomina')).limpiarCacheCursosNomina;
  const app = express();
  app.set('trust proxy', true);
  app.use(express.json());
  app.use((await import('../../../servidor/familias/consultas')).rutasConsultas);
  servidor = app.listen(0);
  await new Promise((ok) => servidor.once('listening', ok));
  puerto = (servidor.address() as AddressInfo).port;
}, 120_000);

afterAll(async () => {
  await new Promise((ok) => servidor.close(ok));
  for (const [n, v] of Object.entries(entornoAntes)) {
    if (v === undefined) delete process.env[n];
    else process.env[n] = v;
  }
});

beforeEach(() => {
  limpiarCache();
  ia.llamadas.length = 0;
  ia.redaccion = redaccionOk();
  ia.control = { verificado: true, problemas: [], respuesta: 'Podés pagar por transferencia desde la web, al elegir el medio de pago.' };
  estado.correos = [];
  estado.latenciaMs = 0;
  estado.tablaQueFalla = '';
  estado.tablas = {
    colegios: [{ id: COLEGIO, nombre: 'Colegio' }],
    alumnos: [
      { id: 'a1', colegio_id: COLEGIO, nombre: 'PEREZ, JUAN', grado: '3° grado', division: 'A', turno: 'Mañana' },
      { id: 'a2', colegio_id: COLEGIO, nombre: 'RIESMERSMA VILLAR, BENICIO', grado: '6° grado', division: 'A', turno: 'Mañana' },
      { id: 'a3', colegio_id: COLEGIO, nombre: 'COLOMBA, DELFINA', grado: '6° año', division: 'A', turno: 'Mañana' },
      { id: 'a4', colegio_id: COLEGIO, nombre: 'COLOMBA, VALENTINA', grado: '1° grado', division: 'A', turno: 'Tarde' },
    ],
    codigos_seccion: [{ id: 's1', colegio_id: COLEGIO, grado: '3° grado', turno: 'Mañana', division: 'A', codigo_secreto: 'ABCD-EFGH' }],
    inscripciones: [], fotos: [], limites_intentos: [], consultas_familias: [], consultas_familias_mensajes: [], familias: [], pedidos: [], ev_eventos: [], envios_email: [],
  };
});

describe('reglas del análisis (sin IA)', () => {
  it('cada afirmación tiene que citar un dato que exista, una regla o la idea', async () => {
    const { afirmacionesSinRespaldo, fichaNumerada } = await import('../../../servidor/familias/respuestaVerificada');
    const { texto, codigos } = fichaNumerada({ chequeos: [{ ok: true, texto: 'Juan: 3° A' }], datos: ['Citado el 29/10', 'Sin pedidos'] });
    expect(texto).toBe('[C1] [OK] Juan: 3° A\n[D1] Citado el 29/10\n[D2] Sin pedidos');
    const alertas = afirmacionesSinRespaldo([
      { texto: 'Está citado el 29/10', fuente: 'D1' },
      { texto: 'Juan está en 3° A', fuente: 'C1, D2' },
      { texto: 'La grupal no se repite', fuente: 'REGLA: la grupal no se vuelve a sacar' },
      { texto: 'No figura ninguna convocatoria', fuente: 'D7' },
      { texto: 'Te la sacamos el lunes', fuente: '' },
      { texto: 'Lo cambiamos al 28', fuente: 'IDEA' },
    ], codigos, false);
    expect(alertas.map((a) => a.frase)).toEqual(['No figura ninguna convocatoria', 'Te la sacamos el lunes', 'Lo cambiamos al 28']);
    expect(afirmacionesSinRespaldo([{ texto: 'Lo cambiamos al 28', fuente: 'IDEA' }], codigos, true)).toEqual([]);
  });

  it('el control tiene que devolver su formato; si no, el borrador queda «sin verificar»', async () => {
    const { leerControl, analisisPermiteEnvio, leerRedaccion } = await import('../../../servidor/familias/respuestaVerificada');
    expect(leerControl(JSON.stringify({ tema: 'otro', respuesta: 'x' }))).toBeNull();
    expect(leerControl('no es json')).toBeNull();
    expect(leerControl('```json\n{"verificado":true,"problemas":[{"frase":"a","motivo":"b"}],"respuesta":"ok"}\n```')).toEqual({ verificado: true, problemas: [{ frase: 'a', motivo: 'b' }], respuesta: 'ok' });
    const d = leerRedaccion(JSON.stringify(redaccionOk()));
    expect(analisisPermiteEnvio({ ...d, verificado: true })).toBe(true);
    expect(analisisPermiteEnvio({ ...d, verificado: false })).toBe(false);
    expect(analisisPermiteEnvio({ ...d, verificado: true, ambiguedades: ['x'] })).toBe(false);
    expect(analisisPermiteEnvio({ ...d, verificado: true, decisiones: [{ pregunta: 'x', opciones: [] }] })).toBe(false);
    expect(analisisPermiteEnvio({ ...d, verificado: true, alertas: [{ frase: 'x', motivo: 'y' }] })).toBe(false);
    // Si la IA no devuelve JSON, su texto queda como borrador y nunca sale solo.
    expect(leerRedaccion('Hola, texto suelto')).toMatchObject({ respuesta: 'Hola, texto suelto', respondible: false, verificado: false });
  });

  it('caso Villar: un nombre mal escrito en la nómina se encuentra; dos candidatos iguales, no', async () => {
    const { nombreParecidoEnNomina } = await import('../../../servidor/familias/fichaFamiliaExtra');
    const nomina = [
      { nombre: 'RIESMERSMA VILLAR, BENICIO', grado: '6° grado', division: 'A', turno: 'Mañana' },
      { nombre: 'BENITEZ, BENICIO', grado: '6° grado', division: 'A', turno: 'Mañana' },
    ];
    expect(nombreParecidoEnNomina(nomina, 'Benicio Riemersma Villar', '6° grado')?.nombre).toBe('RIESMERSMA VILLAR, BENICIO');
    expect(nombreParecidoEnNomina(nomina, 'Benicio Riemersma Villar', '5° grado')).toBeNull(); // otro grado
    expect(nombreParecidoEnNomina(nomina, 'Benicio Gomez', '6° grado')).toBeNull(); // apellido distinto
    const dos = [...nomina, { nombre: 'RIEMERSMO VILLAR, BENICIO', grado: '6° grado', division: 'B', turno: 'Mañana' }];
    expect(nombreParecidoEnNomina(dos, 'Benicio Riemersma Villar', '6° grado')).toBeNull(); // no adivina
  });

  it('caso Arbelo: la ficha dice qué clases de fotos hay y que el curso no tiene tercera foto', async () => {
    const { clasesDeFotosDelCurso } = await import('../../../servidor/familias/fichaFamiliaExtra');
    const cuentas: Record<string, number> = { grupal: 7, individual: 91, docente: 0, familia: 0 };
    const supabaseFalso: any = {
      from: () => {
        let categoria = '';
        const q: any = { select: () => q, eq: (c: string, v: string) => ((c === 'categoria' ? (categoria = v) : null), q), not: () => q, then: (ok: any) => ok({ count: cuentas[categoria] }) };
        return q;
      },
    };
    const texto = await clasesDeFotosDelCurso(supabaseFalso, COLEGIO, { nombre: 'Baltazar', grado: '1° año', division: 'C', turno: 'Mañana' });
    expect(texto).toContain('7 grupales, 91 individuales');
    expect(texto).toContain('NO hay ninguna tercera foto');
    expect(texto).toContain('DECISIÓN del equipo');
  });

  it('caso Colomba: la foto de hermanos con su día y horario (o que no la pidió / no confirmó)', async () => {
    const { textoFotoHermanos } = await import('../../../servidor/familias/fichaFamiliaExtra');
    const base = { email: 'emi@familia.test', alumno_nombre: 'Delfina', hermanos: [{ alumnoNombre: 'Valentina' }] };
    const citas = { 'emi@familia.test': { dia: '2026-10-29', hora: '12:00 a 13:00 h' } };
    const citado = textoFotoHermanos({ ...base, solicita_foto_hermanos: true, foto_hermanos_confirmada_at: '2026-10-08T23:29:56Z' }, citas)!;
    expect(citado).toContain('Delfina, Valentina');
    expect(citado).toContain('CITADA el jueves 29 de octubre, de 12:00 a 13:00 h');
    expect(textoFotoHermanos({ ...base, solicita_foto_hermanos: true, foto_hermanos_confirmada_at: '2026-10-08T23:29:56Z' }, {})).toContain('todavía no tiene día asignado');
    expect(textoFotoHermanos({ ...base, solicita_foto_hermanos: true }, citas)).toContain('nunca la confirmó');
    expect(textoFotoHermanos({ ...base, solicita_foto_hermanos: false, foto_hermanos_confirmada_at: '2026-10-08T23:29:56Z' }, citas)).toContain('NO la quiere');
    expect(textoFotoHermanos({ ...base, hermanos: [] }, citas)).toBeNull();
  });
});

describe('casos reales: lo que recibe la IA', () => {
  it('Colomba: la ficha trae que está CITADO para la foto de hermanos', async () => {
    estado.tablas.inscripciones.push(inscripcion({
      email: 'emi@familia.test', padre_nombre: 'Emiliano', alumno_nombre: 'Delfina', alumno_apellido: 'Colomba', grado: '6° año', division: 'A', turno: 'Mañana',
      hermanos: [{ alumnoNombre: 'Valentina', alumnoApellido: 'Colomba', grado: '1° grado', division: 'A', turno: 'Tarde' }],
      solicita_foto_hermanos: true, foto_hermanos_confirmada_at: '2026-10-08T23:29:56Z',
    }));
    estado.tablas.envios_email.push({ id: 'e1', tipo: 'citacion', creado_at: '2026-10-26T13:45:00Z', contenido: { citas: { 'emi@familia.test': { dia: '2026-10-29', hora: '12:00 a 13:00 h', franja: 'ambos' } } } });
    await consultar('emi@familia.test', 'El día y horario que propusieron para la foto, Valentina ingresa más tarde. ¿Pueden cambiar el día?');
    const prompt = promptRedaccion();
    expect(prompt).toMatch(/\[D\d+\] Foto de hermanos \(Delfina, Valentina\): la pidió y la confirmó el 0?8\/10\. Está CITADA el jueves 29 de octubre, de 12:00 a 13:00 h/);
    expect(prompt).toContain('Cambiar el día u horario es una DECISIÓN del equipo');
  });

  it('Villar: con el apellido mal escrito en la nómina, la IA sabe que el chico SÍ está', async () => {
    estado.tablas.inscripciones.push(inscripcion({ email: 'cris@familia.test', padre_nombre: 'Cristina', alumno_nombre: 'Benicio', alumno_apellido: 'Riemersma Villar', grado: '6° grado', division: 'A', turno: 'Mañana' }));
    await consultar('cris@familia.test', 'No encuentro dónde pagar');
    const prompt = promptRedaccion();
    expect(prompt).toContain('hay un nombre casi igual: «RIESMERSMA VILLAR, BENICIO»');
    expect(prompt).toContain('NO le digas a la familia que no figura');
    expect(prompt).not.toContain('no figura en la nómina del colegio — revisar a mano');
  });

  it('las consultas anteriores de la familia entran en la ficha', async () => {
    estado.tablas.inscripciones.push(inscripcion({ email: 'ana@familia.test', padre_nombre: 'Ana', alumno_nombre: 'Juan', alumno_apellido: 'Pérez' }));
    estado.tablas.consultas_familias.push({ id: 'vieja', email: 'ana@familia.test', asunto: 'Foto con la seño', estado: 'resuelta', created_at: '2026-10-20T12:00:00Z' });
    await consultar('ana@familia.test', '¿Cómo pago por transferencia?');
    expect(promptRedaccion()).toMatch(/Consulta anterior de esta familia \(20\/10\): «Foto con la seño» — resuelta\./);
  });
});

describe('cuándo puede salir sola una respuesta', () => {
  const familiaOk = () => estado.tablas.inscripciones.push(inscripcion({ email: 'ana@familia.test', padre_nombre: 'Ana', alumno_nombre: 'Juan', alumno_apellido: 'Pérez' }));

  it('todo respaldado y el control sin problemas: sale (2 llamadas: redacción y control)', async () => {
    familiaOk();
    await consultar('ana@familia.test', '¿Cómo pago por transferencia?');
    expect(ia.llamadas).toHaveLength(2);
    expect(ia.llamadas[1].prompt).toContain('BORRADOR A REVISAR');
    expect(correosA('ana@familia.test')).toHaveLength(1);
    expect(guardada('ana@familia.test').verificacion_ia).toMatchObject({ enviadaAutomaticamente: true, verificado: true, alertas: [] });
  });

  it('una afirmación sin respaldo (como «no figura ninguna convocatoria»): no sale y queda marcada', async () => {
    familiaOk();
    ia.redaccion = redaccionOk({ afirmaciones: [{ texto: 'No figura ninguna convocatoria.', fuente: 'D40' }] });
    await consultar('ana@familia.test', '¿Cómo pago por transferencia?');
    expect(correosA('ana@familia.test')).toHaveLength(0);
    const v = guardada('ana@familia.test').verificacion_ia;
    expect(v.enviadaAutomaticamente).toBe(false);
    expect(v.alertas[0]).toMatchObject({ frase: 'No figura ninguna convocatoria.' });
    expect(v.motivoNoEnvio).toMatch(/sin respaldo/);
  });

  it('el control encuentra un problema: no sale, y el borrador guardado es el corregido', async () => {
    familiaOk();
    ia.control = { verificado: true, problemas: [{ frase: 'Te la cambiamos al martes.', motivo: 'Nadie decidió el cambio.' }], respuesta: 'Lo revisa el equipo y te responde por email.' };
    await consultar('ana@familia.test', '¿Cómo pago por transferencia?');
    expect(correosA('ana@familia.test')).toHaveLength(0);
    const g = guardada('ana@familia.test');
    expect(g.borrador_ia).toBe('Lo revisa el equipo y te responde por email.');
    expect(g.verificacion_ia.alertas).toEqual([{ frase: 'Te la cambiamos al martes.', motivo: 'Nadie decidió el cambio.' }]);
  });

  it('si el control no responde en su formato, no sale (queda «sin verificar»)', async () => {
    familiaOk();
    ia.control = { tema: 'otro', respuesta: 'cualquier cosa' };
    await consultar('ana@familia.test', '¿Cómo pago por transferencia?');
    expect(correosA('ana@familia.test')).toHaveLength(0);
    expect(guardada('ana@familia.test').verificacion_ia).toMatchObject({ verificado: false, enviadaAutomaticamente: false });
  });

  it('una decisión pendiente o una ambigüedad: no sale, y el panel recibe las opciones', async () => {
    familiaOk();
    ia.redaccion = redaccionOk({ decisiones: [{ pregunta: '¿Le cambiás el día?', opciones: ['Pasarlo al martes 27', 'Pasarlo al miércoles 28'] }] });
    await consultar('ana@familia.test', '¿Cómo pago por transferencia?');
    expect(correosA('ana@familia.test')).toHaveLength(0);
    expect(guardada('ana@familia.test').verificacion_ia.motivoNoEnvio).toMatch(/decidir vos/);

    ia.redaccion = redaccionOk({ ambiguedades: ['«la foto con Valentina» puede ser la de hermanos o la de la seño'] });
    const id = guardada('ana@familia.test').id;
    const r = await pedir('POST', `/api/admin/consultas-familias/${id}/sugerir-respuesta`, {}, true);
    expect(r.status).toBe(200);
    expect(r.json.analisis).toMatchObject({ entendido: 'Pregunta cómo pagar por transferencia.', ambiguedades: ['«la foto con Valentina» puede ser la de hermanos o la de la seño'], verificado: true });
  });

  it('con RESPUESTAS_AUTOMATICAS=off nunca sale sola, aunque todo esté bien', async () => {
    familiaOk();
    process.env.RESPUESTAS_AUTOMATICAS = 'off';
    try {
      await consultar('ana@familia.test', '¿Cómo pago por transferencia?');
    } finally {
      delete process.env.RESPUESTAS_AUTOMATICAS;
    }
    expect(correosA('ana@familia.test')).toHaveLength(0);
    expect(guardada('ana@familia.test').borrador_ia).toBeTruthy();
  });
});
