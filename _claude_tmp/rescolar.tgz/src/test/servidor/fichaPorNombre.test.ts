// 29/10/2026 (Pablo: «la IA sigue respondiendo con un desconocimiento que me enoja»): familia que escribe con otro email.
import { describe, expect, it } from 'vitest';
import { buscarInscripcionesPorNombre, enmascararEmail } from '../../../servidor/familias/fichaFamiliaExtra';

const inscripciones = [
  { id: '1', email: 'maemiliapavan@hotmail.com', padre_nombre: 'Emilia Pavan' },
  { id: '2', email: 'cintia_pavan@yahoo.com.ar', padre_nombre: 'Cintia Pavan' },
  { id: '3', email: 'otra@x.com', padre_nombre: 'Emilia González' },
];
function supabaseFalso(filas: any[]) {
  return {
    from: () => {
      let patron = '';
      const q: any = { select: () => q, ilike: (_c: string, p: string) => { patron = p.replace(/%/g, ''); return q; }, limit: async () => ({ data: filas.filter((f) => f.padre_nombre.toLowerCase().includes(patron)), error: null }) };
      return q;
    },
  } as any;
}

describe('ficha de la IA: inscripción por nombre', () => {
  it('encuentra a «María Emilia Pavan» aunque escriba con otro email; no confunde con otra Pavan ni otra Emilia', async () => {
    const r = await buscarInscripcionesPorNombre(supabaseFalso(inscripciones), 'María Emilia Pavan', 'id');
    expect(r.map((i) => i.id)).toEqual(['1']);
  });
  it('sin dos palabras en común, o con tutores distintos que coinciden, no adivina', async () => {
    expect(await buscarInscripcionesPorNombre(supabaseFalso(inscripciones), 'Pavan', 'id')).toEqual([]);
    const dos = [...inscripciones, { id: '4', email: 'otro@y.com', padre_nombre: 'Emilia Pavan' }];
    expect(await buscarInscripcionesPorNombre(supabaseFalso(dos), 'Emilia Pavan', 'id')).toEqual([]);
  });
  it('enmascara el email', () => {
    expect(enmascararEmail('maemiliapavan@hotmail.com')).toBe('ma***@hotmail.com');
    expect(enmascararEmail('')).toBe('otro email');
  });
});
