// 25/10/2026 (Pablo): pestaña «Atención especial» en Consultas; la IA nunca responde sola una consulta marcada.
import { describe, expect, it } from 'vitest';
import { fuenteServidor } from '../fuenteServidor';

describe('consultas: atención especial', () => {
  const server = fuenteServidor();
  it('la marca la cambia sólo el admin y la pestaña lista las marcadas no archivadas', () => {
    expect(server).toContain("app.patch('/api/admin/consultas-familias/:id/especial', requireAdminAuth");
    expect(server).toContain("if (estado === 'especial') query = query.eq('atencion_especial', true).neq('estado', 'archivada');");
  });
  it('la IA no envía sola una respuesta a una consulta marcada', () => {
    expect(server).toContain('!consulta.atencion_especial &&');
  });
});
