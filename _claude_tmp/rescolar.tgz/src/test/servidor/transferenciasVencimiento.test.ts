// 10/10/2026 (pedido de Pablo): transferencias sin comprobante.
//
// "El cliente hizo el pago pero no envió el comprobante" y a las 48 h el pedido se caía. Ahora:
//   1. cuando faltan 12 h o menos, último aviso a la familia y resumen a Pablo (una sola vez por plazo);
//   2. al vencer se cancela como antes, pero queda recuperable (transferencia_vencida_at, sin
//      cancelado_definitivo) y a Pablo le llega el resumen de lo que se canceló;
//   3. desde el panel, «Reabrir plazo» vuelve el pedido a pendiente con 48 h nuevas y un aviso nuevo.
// Corre el cron y la ruta del panel de verdad, con una base y un Resend falsos en memoria (nada sale a
// la red).
import http from 'http';
import type { AddressInfo } from 'net';
import express from 'express';
import { afterAll, beforeAll, beforeEach, describe, expect, it, vi } from 'vitest';

vi.mock('dotenv', () => {
  const config = () => ({ parsed: {} });
  return { default: { config }, config };
});

const h = vi.hoisted(() => {
  const estado = {
    tablas: { pedidos: [] as any[], tareas_programadas_estado: [] as any[] } as Record<string, any[]>,
    mails: [] as Array<{ to: string[]; subject: string; html: string; clave?: string }>,
  };
  const valor = (fila: any, campo: string) => fila[campo] ?? null;
  const comparar = (a: any, b: any) => {
    const fa = Date.parse(a);
    const fb = Date.parse(b);
    return Number.isFinite(fa) && Number.isFinite(fb) ? fa - fb : String(a).localeCompare(String(b));
  };
  // Constructor de consultas mínimo: filtra, ordena, actualiza y devuelve copias de las filas.
  function consulta(tabla: string) {
    const filtros: Array<(f: any) => boolean> = [];
    let cambios: Record<string, any> | null = null;
    let upsert: any = null;
    let unica = false;
    let limite = Infinity;
    let orden: { campo: string; asc: boolean } | null = null;
    const q: any = {
      select: () => q,
      eq: (c: string, v: any) => (filtros.push((f) => valor(f, c) === v), q),
      neq: (c: string, v: any) => (filtros.push((f) => valor(f, c) !== v), q),
      is: (c: string, v: any) => (filtros.push((f) => valor(f, c) === v), q),
      not: (c: string, op: string, v: any) => (filtros.push((f) => !(op === 'is' && valor(f, c) === v)), q),
      in: (c: string, vs: any[]) => (filtros.push((f) => vs.includes(valor(f, c))), q),
      gt: (c: string, v: any) => (filtros.push((f) => valor(f, c) !== null && comparar(valor(f, c), v) > 0), q),
      gte: (c: string, v: any) => (filtros.push((f) => valor(f, c) !== null && comparar(valor(f, c), v) >= 0), q),
      lte: (c: string, v: any) => (filtros.push((f) => valor(f, c) !== null && comparar(valor(f, c), v) <= 0), q),
      lt: (c: string, v: any) => (filtros.push((f) => valor(f, c) !== null && comparar(valor(f, c), v) < 0), q),
      order: (campo: string, o?: { ascending?: boolean }) => ((orden = { campo, asc: o?.ascending !== false }), q),
      limit: (n: number) => ((limite = n), q),
      update: (c: Record<string, any>) => ((cambios = c), q),
      upsert: (fila: any) => ((upsert = fila), q),
      maybeSingle: () => ((unica = true), q),
      single: () => ((unica = true), q),
      then: (ok: any, mal: any) => Promise.resolve(ejecutar()).then(ok, mal),
    };
    function ejecutar() {
      const filas = (estado.tablas[tabla] = estado.tablas[tabla] || []);
      if (upsert) {
        filas.push(upsert);
        return { data: null, error: null };
      }
      let elegidas = filas.filter((f) => filtros.every((fn) => fn(f)));
      if (cambios) {
        for (const f of elegidas) Object.assign(f, cambios);
      }
      if (orden) {
        const { campo, asc } = orden;
        elegidas = [...elegidas].sort((a, b) => (asc ? 1 : -1) * comparar(valor(a, campo), valor(b, campo)));
      }
      const copia = elegidas.slice(0, limite).map((f) => JSON.parse(JSON.stringify(f)));
      return { data: unica ? copia[0] ?? null : copia, error: null };
    }
    return q;
  }
  return { estado, consulta };
});

vi.mock('@supabase/supabase-js', () => ({
  createClient: () => ({ from: (tabla: string) => h.consulta(tabla), rpc: async () => ({ data: null, error: null }) }),
}));

vi.mock('resend', () => ({
  Resend: class {
    emails = {
      send: async (datos: any, opciones?: { idempotencyKey?: string }) => {
        h.estado.mails.push({ to: datos.to, subject: datos.subject, html: datos.html, clave: opciones?.idempotencyKey });
        return { data: { id: `mail-${h.estado.mails.length}` }, error: null };
      },
    };
    batch = { send: async () => ({ data: null, error: null }) };
  },
}));

const HORA = 60 * 60 * 1000;
const hace = (horas: number) => new Date(Date.now() - horas * HORA).toISOString();
const CASILLA_PABLO = 'avisos@prueba.test';

let servidor: http.Server;
let puerto = 0;
let tokenAdmin = '';
const entornoAntes: Record<string, string | undefined> = {};

function pedir(metodo: string, ruta: string, cuerpo?: unknown, autorizacion?: string): Promise<{ status: number; json: any }> {
  return new Promise((ok, mal) => {
    const datos = cuerpo === undefined ? undefined : JSON.stringify(cuerpo);
    const encabezados: Record<string, string | number> = {};
    if (datos) {
      encabezados['Content-Type'] = 'application/json';
      encabezados['Content-Length'] = Buffer.byteLength(datos);
    }
    if (autorizacion) encabezados.Authorization = `Bearer ${autorizacion}`;
    const req = http.request({ host: '127.0.0.1', port: puerto, path: ruta, method: metodo, headers: encabezados }, (res) => {
      let texto = '';
      res.setEncoding('utf8');
      res.on('data', (c) => { texto += c; });
      res.on('end', () => {
        let json: any = null;
        try { json = JSON.parse(texto); } catch { /* no es JSON */ }
        ok({ status: res.statusCode || 0, json });
      });
    });
    req.on('error', mal);
    if (datos) req.write(datos);
    req.end();
  });
}

const correrCron = () => pedir('POST', '/api/cron/recordar-pagos-pendientes', {}, 'secreto-cron');

/** Una fila de pedido por transferencia, sin comprobante, con el recordatorio de las 12 h ya enviado. */
function pedido(id: string, extra: Record<string, any> = {}) {
  return {
    id,
    pedido_friendly_id: `IFS-2026-${id}`,
    grupo_pago_id: null,
    estado: 'pendiente_pago',
    metodo_pago: 'transferencia',
    total: 30000,
    alumno_nombre: `Alumno ${id}`,
    colegio_nombre: 'Colegio de Prueba',
    archivado: false,
    en_espera: false,
    cancelado_definitivo: false,
    comprobante_subido_at: null,
    comprobante_path: null,
    mp_preference_id: null,
    nave_payment_request_id: null,
    created_at: hace(40),
    transferencia_desde: hace(40),
    transferencia_vencida_at: null,
    recordatorio_pago_at: hace(28),
    aviso_vencimiento_at: null,
    familias: { nombre: 'Familia Prueba', email: 'familia@prueba.test' },
    ...extra,
  };
}

const filaDe = (id: string) => h.estado.tablas.pedidos.find((f) => f.id === id);
const mailsA = (destino: string) => h.estado.mails.filter((m) => m.to.includes(destino));

beforeAll(async () => {
  for (const nombre of ['SUPABASE_SERVICE_ROLE_KEY', 'RESEND_API_KEY', 'CRON_SECRET', 'CONSULTAS_EMAIL', 'ADMIN_SESSION_SECRET']) entornoAntes[nombre] = process.env[nombre];
  process.env.SUPABASE_SERVICE_ROLE_KEY = 'prueba';
  process.env.RESEND_API_KEY = 'prueba';
  process.env.CRON_SECRET = 'secreto-cron';
  process.env.CONSULTAS_EMAIL = CASILLA_PABLO;
  process.env.ADMIN_SESSION_SECRET = 'secreto-de-prueba';
  const { rutasTareasProgramadas } = await import('../../../servidor/tareasProgramadas');
  const { rutasPanelPedidos } = await import('../../../servidor/panel/pedidos');
  const { generateAdminToken } = await import('../../../servidor/nucleo/auth');
  tokenAdmin = generateAdminToken() || '';
  const app = express();
  app.use(express.json());
  app.use(rutasTareasProgramadas);
  app.use(rutasPanelPedidos);
  servidor = app.listen(0);
  await new Promise((ok) => servidor.once('listening', ok));
  puerto = (servidor.address() as AddressInfo).port;
}, 120_000);

afterAll(async () => {
  await new Promise((ok) => servidor.close(ok));
  for (const [nombre, valor] of Object.entries(entornoAntes)) {
    if (valor === undefined) delete process.env[nombre];
    else process.env[nombre] = valor;
  }
});

beforeEach(() => {
  h.estado.tablas.pedidos = [];
  h.estado.tablas.tareas_programadas_estado = [];
  h.estado.mails = [];
});

describe('transferencias por vencer: último aviso a la familia y resumen a Pablo', () => {
  it('a 8 h del vencimiento avisa una sola vez, a todo el carrito', async () => {
    h.estado.tablas.pedidos.push(pedido('A1', { grupo_pago_id: 'G1' }), pedido('A2', { grupo_pago_id: 'G1', alumno_nombre: 'Hermano A2' }));
    const r = await correrCron();
    expect(r.status).toBe(200);
    expect(r.json).toMatchObject({ success: true, avisosPorVencer: 1, cancelados: 0 });
    expect(filaDe('A1').aviso_vencimiento_at).toBeTruthy();
    expect(filaDe('A2').aviso_vencimiento_at).toBeTruthy();
    expect(filaDe('A1').estado).toBe('pendiente_pago');

    const familia = mailsA('familia@prueba.test');
    expect(familia).toHaveLength(1);
    expect(familia[0].subject).toContain('último aviso');
    expect(familia[0].html).toContain('Subir mi comprobante');
    const pablo = mailsA(CASILLA_PABLO);
    expect(pablo).toHaveLength(1);
    expect(pablo[0].subject).toContain('1 pago por transferencia vence en menos de 12 h');
    expect(pablo[0].html).toContain('IFS-2026-A1');
    expect(pablo[0].html).toContain('Hermano A2');
    expect(pablo[0].html).toContain('$60.000');
    expect(pablo[0].html).toContain('Vencidos sin comprobante');

    const otraVez = await correrCron();
    expect(otraVez.json).toMatchObject({ avisosPorVencer: 0, cancelados: 0 });
    expect(h.estado.mails).toHaveLength(2);
  });

  it('con más de 12 h por delante todavía no avisa', async () => {
    h.estado.tablas.pedidos.push(pedido('B1', { transferencia_desde: hace(30), created_at: hace(30) }));
    const r = await correrCron();
    expect(r.json).toMatchObject({ avisosPorVencer: 0, cancelados: 0 });
    expect(h.estado.mails).toHaveLength(0);
    expect(filaDe('B1').aviso_vencimiento_at).toBeNull();
  });

  it('si la familia recibió el recordatorio hace poco, a ella no se le manda otro (a Pablo sí)', async () => {
    h.estado.tablas.pedidos.push(pedido('C1', { recordatorio_pago_at: hace(2) }));
    const r = await correrCron();
    expect(r.json).toMatchObject({ avisosPorVencer: 1 });
    expect(mailsA('familia@prueba.test')).toHaveLength(0);
    const pablo = mailsA(CASILLA_PABLO);
    expect(pablo).toHaveLength(1);
    expect(pablo[0].html).toContain('Recibió el recordatorio hace poco');
  });

  it('no avisa pedidos archivados, en espera ni con comprobante', async () => {
    h.estado.tablas.pedidos.push(
      pedido('D1', { archivado: true }),
      pedido('D2', { en_espera: true }),
      pedido('D3', { comprobante_subido_at: hace(1), comprobante_path: 'x/1.jpg' })
    );
    const r = await correrCron();
    expect(r.json).toMatchObject({ avisosPorVencer: 0, cancelados: 0 });
    expect(h.estado.mails).toHaveLength(0);
  });
});

describe('transferencias vencidas: se cancelan pero quedan recuperables', () => {
  it('al vencer se cancela sin cancelado_definitivo, con aviso a la familia y resumen a Pablo', async () => {
    h.estado.tablas.pedidos.push(pedido('E1', { transferencia_desde: hace(49), created_at: hace(49), aviso_vencimiento_at: hace(10) }));
    const r = await correrCron();
    expect(r.json).toMatchObject({ avisosPorVencer: 0, cancelados: 1 });
    const fila = filaDe('E1');
    expect(fila.estado).toBe('cancelado');
    expect(fila.transferencia_vencida_at).toBeTruthy();
    expect(fila.cancelado_definitivo).toBe(false);

    const familia = mailsA('familia@prueba.test');
    expect(familia).toHaveLength(1);
    expect(familia[0].subject).toContain('se canceló tu pedido');
    expect(familia[0].html).toContain('tu pedido queda guardado');
    const pablo = mailsA(CASILLA_PABLO);
    expect(pablo).toHaveLength(1);
    expect(pablo[0].subject).toContain('Se cancelaron 1 pago por transferencia sin comprobante (se pueden recuperar)');
    expect(pablo[0].html).toContain('IFS-2026-E1');
  });

  it('«Reabrir plazo» desde el panel: vuelve a pendiente con 48 h nuevas y un aviso nuevo', async () => {
    h.estado.tablas.pedidos.push(
      pedido('F1', { estado: 'cancelado', transferencia_desde: hace(60), transferencia_vencida_at: hace(12), aviso_vencimiento_at: hace(24) })
    );
    const r = await pedir('POST', '/api/admin/pedidos/F1/estado', { estadoPago: 'pendiente', estadoAnterior: 'cancelado' }, tokenAdmin);
    expect(r.status).toBe(200);
    expect(r.json.success).toBe(true);
    const fila = filaDe('F1');
    expect(fila.estado).toBe('pendiente_pago');
    expect(fila.transferencia_vencida_at).toBeNull();
    expect(fila.aviso_vencimiento_at).toBeNull();
    expect(Date.now() - Date.parse(fila.transferencia_desde)).toBeLessThan(60 * 1000);
  });

  it('un cancelado definitivo (arrepentimiento, reembolso, a mano) no se reabre así', async () => {
    h.estado.tablas.pedidos.push(pedido('G1', { estado: 'cancelado', cancelado_definitivo: true, transferencia_vencida_at: hace(12) }));
    const r = await pedir('POST', '/api/admin/pedidos/G1/estado', { estadoPago: 'pendiente', estadoAnterior: 'cancelado' }, tokenAdmin);
    expect(r.status).toBe(409);
    expect(r.json.codigo).toBe('CANCELADO_DEFINITIVO');
    expect(filaDe('G1').estado).toBe('cancelado');
  });
});

describe('ayudas del servidor', () => {
  it('transferenciaPorVencer: sólo dentro de las últimas 12 h y antes de vencer', async () => {
    const { transferenciaPorVencer } = await import('../../../servidor/tareasProgramadas');
    const ahora = Date.now();
    expect(transferenciaPorVencer([pedido('H1', { transferencia_desde: hace(40) })], ahora)).toBeInstanceOf(Date);
    expect(transferenciaPorVencer([pedido('H2', { transferencia_desde: hace(30) })], ahora)).toBeNull();
    expect(transferenciaPorVencer([pedido('H3', { transferencia_desde: hace(49) })], ahora)).toBeNull();
    expect(transferenciaPorVencer([pedido('H4', { aviso_vencimiento_at: hace(1) })], ahora)).toBeNull();
    expect(transferenciaPorVencer([pedido('H5', { metodo_pago: 'mercadopago' })], ahora)).toBeNull();
    expect(transferenciaPorVencer([], ahora)).toBeNull();
  });
});
