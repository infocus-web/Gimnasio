// 13/10/2026 (pedido de Pablo: que las consultas las conteste Claude): cómo se llama a la API de Anthropic.
// El modelo por defecto era 'claude-sonnet-5' (no existe) y el tope de 1200 tokens no dejaba lugar al
// razonamiento de Sonnet 5.5 (cuenta dentro de max_tokens): el JSON podía quedar cortado.
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';

vi.mock('dotenv', () => {
  const config = () => ({ parsed: {} });
  return { default: { config }, config };
});

const NOMBRES = ['ANTHROPIC_API_KEY', 'ANTHROPIC_MODEL', 'GEMINI_API_KEY'];
const entornoAntes: Record<string, string | undefined> = {};

function claudeResponde(cuerpo: unknown, status = 200) {
  const falso = vi.fn(async (_url: string, _init: any) => ({ ok: status < 400, status, json: async () => cuerpo }));
  vi.stubGlobal('fetch', falso);
  return falso;
}
const cuerpoEnviado = (falso: ReturnType<typeof claudeResponde>) => JSON.parse(falso.mock.calls[0][1].body);

beforeEach(() => {
  for (const n of NOMBRES) entornoAntes[n] = process.env[n];
  process.env.ANTHROPIC_API_KEY = 'clave-de-prueba';
  delete process.env.ANTHROPIC_MODEL;
  delete process.env.GEMINI_API_KEY;
});

afterEach(() => {
  vi.unstubAllGlobals();
  for (const [n, v] of Object.entries(entornoAntes)) {
    if (v === undefined) delete process.env[n];
    else process.env[n] = v;
  }
});

describe('generarTextoIA con Claude', () => {
  it('por defecto: claude-sonnet-5-5, esfuerzo bajo, margen para el razonamiento y contexto cacheado', async () => {
    const falso = claudeResponde({
      stop_reason: 'end_turn',
      content: [{ type: 'thinking', thinking: 'reviso los datos' }, { type: 'text', text: 'Hola, ' }, { type: 'text', text: 'familia.' }],
    });
    const { generarTextoIA, MODELO_CLAUDE_POR_DEFECTO } = await import('../../../servidor/nucleo/ia');
    expect(await generarTextoIA({ sistema: 'Contexto del negocio', prompt: 'Consulta' })).toBe('Hola, familia.');
    expect(falso.mock.calls[0][0]).toBe('https://api.anthropic.com/v1/messages');
    expect(falso.mock.calls[0][1].headers['x-api-key']).toBe('clave-de-prueba');
    const cuerpo = cuerpoEnviado(falso);
    expect(MODELO_CLAUDE_POR_DEFECTO).toBe('claude-sonnet-5-5');
    expect(cuerpo.model).toBe('claude-sonnet-5-5');
    expect(cuerpo.output_config).toEqual({ effort: 'low' });
    expect(cuerpo.max_tokens).toBe(6000);
    expect(cuerpo.system).toEqual([{ type: 'text', text: 'Contexto del negocio', cache_control: { type: 'ephemeral' } }]);
    expect(cuerpo.messages).toEqual([{ role: 'user', content: 'Consulta' }]);
  });

  it('respeta ANTHROPIC_MODEL, el esfuerzo pedido y el pedido de JSON', async () => {
    process.env.ANTHROPIC_MODEL = ' claude-haiku-5-5 ';
    const falso = claudeResponde({ stop_reason: 'end_turn', content: [{ type: 'text', text: '{"tema":"otro"}' }] });
    const { generarTextoIA } = await import('../../../servidor/nucleo/ia');
    expect(await generarTextoIA({ sistema: 'S', prompt: 'P', json: true, esfuerzo: 'medium' })).toBe('{"tema":"otro"}');
    const cuerpo = cuerpoEnviado(falso);
    expect(cuerpo.model).toBe('claude-haiku-5-5');
    expect(cuerpo.output_config).toEqual({ effort: 'medium' });
    expect(cuerpo.messages[0].content).toContain('Respondé únicamente con el JSON');
  });

  it('si la respuesta quedó cortada, error claro (no un borrador a medias)', async () => {
    claudeResponde({ stop_reason: 'max_tokens', content: [{ type: 'text', text: '{"tema":"funcionamiento","respuesta":"Hola, para' }] });
    const { generarTextoIA } = await import('../../../servidor/nucleo/ia');
    await expect(generarTextoIA({ sistema: 'S', prompt: 'P', json: true })).rejects.toThrow(/quedó cortada/);
  });

  it('error de la API: se ve el estado y el mensaje de Anthropic', async () => {
    claudeResponde({ type: 'error', error: { type: 'authentication_error', message: 'invalid x-api-key' } }, 401);
    const { generarTextoIA } = await import('../../../servidor/nucleo/ia');
    await expect(generarTextoIA({ sistema: 'S', prompt: 'P' })).rejects.toThrow('Claude respondió 401: invalid x-api-key');
  });

  // 13/10/2026 (Pablo: «eliminá gemini»): sin ANTHROPIC_API_KEY no hay IA, aunque siga cargada la clave vieja de Gemini.
  it('sin ANTHROPIC_API_KEY no hay IA (la clave de Gemini ya no se usa)', async () => {
    delete process.env.ANTHROPIC_API_KEY;
    process.env.GEMINI_API_KEY = 'clave-vieja-de-gemini';
    const falso = claudeResponde({});
    const { generarTextoIA, ERROR_IA_NO_CONFIGURADA, iaConfigurada } = await import('../../../servidor/nucleo/ia');
    expect(iaConfigurada()).toBe(false);
    await expect(generarTextoIA({ sistema: 'S', prompt: 'P' })).rejects.toThrow(ERROR_IA_NO_CONFIGURADA);
    expect(falso).not.toHaveBeenCalled();
  });
});
