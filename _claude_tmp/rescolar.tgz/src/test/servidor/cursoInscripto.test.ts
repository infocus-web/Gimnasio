// 14/10/2026 (caso Noguera Cabral): la mamá entró con la sesión vieja guardada en el navegador (código de 6° A,
// el curso anterior a la corrección) y pagó un kit en un curso que no era el de su hija. Además, la revisión
// automática de consultas decía que Adriana «no figura en la nómina» porque la familia escribió un nombre de más.
import { describe, expect, it } from 'vitest';
import { cursoDistintoAlInscripto } from '../../../servidor/pagos/cursoInscripto';
import { crearBuscadorEnNomina } from '../../../servidor/familias/cursosNomina';

const baseInscripciones = (filas: any[]) =>
  ({ from: () => ({ select: () => ({ eq: () => ({ ilike: async () => ({ data: filas, error: null }) }) }) }) }) as any;

const baseAlumnos = (filas: any[]) =>
  ({ from: () => ({ select: () => ({ eq: () => ({ order: () => ({ range: async (d: number, h: number) => ({ data: filas.slice(d, h + 1), error: null }) }) }) }) }) }) as any;

const inscripcion = {
  colegio_id: 'col-1', alumno_nombre: 'Adriana yanet', alumno_apellido: 'Noguera cabral', grado: '6° grado', turno: 'Mañana', division: 'B',
  hermanos: [{ alumnoNombre: 'Dante Uriel', alumnoApellido: 'Noguera cabral', grado: '1° grado', turno: 'Tarde', division: 'A' }],
};

describe('cursoDistintoAlInscripto', () => {
  it('frena un pedido en el curso viejo (6° A) cuando la inscripción ya está en 6° B', async () => {
    const r = await cursoDistintoAlInscripto(baseInscripciones([inscripcion]), 'mama@x.com', [
      { colegioId: 'col-1', cursoCodigo: 'GRADO6-ATM', alumnoNombre: 'Adriana yanet Noguera cabral' },
    ]);
    expect(r).toEqual({ alumno: 'Adriana yanet Noguera cabral', curso: '6° grado "B" Mañana' });
  });

  it('deja pasar el curso correcto, también para un hermano', async () => {
    const r = await cursoDistintoAlInscripto(baseInscripciones([inscripcion]), 'mama@x.com', [
      { colegioId: 'col-1', cursoCodigo: 'GRADO6-BTM', alumnoNombre: 'Adriana yanet Noguera cabral' },
      { colegioId: 'col-1', cursoCodigo: 'GRADO1-ATT', alumnoNombre: 'Dante Uriel Noguera cabral' },
    ]);
    expect(r).toBeNull();
  });

  it('un chico que no está en ninguna inscripción de ese email no se frena', async () => {
    const r = await cursoDistintoAlInscripto(baseInscripciones([inscripcion]), 'mama@x.com', [
      { colegioId: 'col-1', cursoCodigo: 'GRADO3-ATT', alumnoNombre: 'Otro Chico Distinto' },
    ]);
    expect(r).toBeNull();
    expect(await cursoDistintoAlInscripto(baseInscripciones([inscripcion]), 'sin-email', [{ colegioId: 'col-1', cursoCodigo: 'GRADO6-ATM', alumnoNombre: 'Adriana yanet Noguera cabral' }])).toBeNull();
  });
});

describe('crearBuscadorEnNomina: nombre con una palabra de más', () => {
  const nomina = [
    { nombre: 'NOGUERA CABRAL, ADRIANA', grado: '6° grado', turno: 'Mañana', division: 'B' },
    { nombre: 'NOGUERA CABRAL, DANTE URIEL', grado: '1° grado', turno: 'Tarde', division: 'A' },
    { nombre: 'PEREZ, JUAN', grado: '3° grado', turno: 'Tarde', division: 'A' },
    { nombre: 'PEREZ, JUAN', grado: '3° grado', turno: 'Tarde', division: 'B' },
  ];

  it('encuentra a «Adriana Yanet Noguera Cabral» como «NOGUERA CABRAL, ADRIANA» en su grado', async () => {
    const buscar = await crearBuscadorEnNomina(baseAlumnos(nomina), 'col-1');
    expect(await buscar('Adriana yanet Noguera cabral', '6° grado')).toEqual({ grado: '6° grado', turno: 'Mañana', division: 'B' });
    expect(await buscar('Adriana yanet Noguera cabral', '5° grado')).toBeNull();
  });

  it('si el nombre corto coincide con dos alumnos distintos, no elige ninguno', async () => {
    const buscar = await crearBuscadorEnNomina(baseAlumnos(nomina), 'col-1');
    expect(await buscar('Juan Martin Perez', '3° grado')).toBeNull();
  });
});
