// Etapa 0 de la división de server.ts (plan `claude/plan-division-servidor.md`, 09/10/2026).
//
// El servidor corre en Vercel como función de Node con módulos ES ("type": "module" en
// package.json). Ahí un import relativo SIN la extensión `.js` (`from './servidor/precios'`) rompe
// recién en producción, con la web caída: `tsc` no avisa (moduleResolution "bundler") y vitest
// tampoco (resuelve solo). Esta prueba recorre todo el código que carga cada función de Vercel
// (`api/*.ts` y lo que importan, más todo `servidor/`) y falla si algún import relativo no termina
// en `.js` o apunta a un archivo que no existe. También controla la regla de dependencias del plan:
// ningún módulo importa server.ts (sólo api/index.ts).
import { existsSync, readdirSync, readFileSync, statSync } from 'fs';
import path from 'path';
import ts from 'typescript';
import { describe, expect, it } from 'vitest';
import { RAIZ_PROYECTO } from '../fuenteServidor';

const ENTRADAS = ['api/index.ts', 'api/eventos.ts'];
const SERVER = path.join(RAIZ_PROYECTO, 'server.ts');

type Import = { especificador: string; linea: number };

/** Imports que existen en tiempo de ejecución (los `import type` / `export type` se borran al compilar). */
export function importsDeEjecucion(codigo: string, nombre = 'archivo.ts'): Import[] {
  const fuente = ts.createSourceFile(nombre, codigo, ts.ScriptTarget.ES2022, true, ts.ScriptKind.TS);
  const salida: Import[] = [];
  const anotar = (nodo: ts.Node, literal: ts.Expression | undefined) => {
    if (literal && ts.isStringLiteralLike(literal)) {
      salida.push({ especificador: literal.text, linea: fuente.getLineAndCharacterOfPosition(nodo.getStart()).line + 1 });
    }
  };
  const visitar = (nodo: ts.Node) => {
    if (ts.isImportDeclaration(nodo)) {
      if (!nodo.importClause?.isTypeOnly) anotar(nodo, nodo.moduleSpecifier);
    } else if (ts.isExportDeclaration(nodo)) {
      if (!nodo.isTypeOnly && nodo.moduleSpecifier) anotar(nodo, nodo.moduleSpecifier);
    } else if (ts.isCallExpression(nodo) && nodo.expression.kind === ts.SyntaxKind.ImportKeyword) {
      anotar(nodo, nodo.arguments[0]);
    }
    ts.forEachChild(nodo, visitar);
  };
  visitar(fuente);
  return salida;
}

function tsDeCarpeta(carpeta: string): string[] {
  if (!existsSync(carpeta)) return [];
  const salida: string[] = [];
  for (const nombre of readdirSync(carpeta).sort()) {
    const completo = path.join(carpeta, nombre);
    if (statSync(completo).isDirectory()) {
      if (nombre !== '__tests__' && nombre !== 'node_modules') salida.push(...tsDeCarpeta(completo));
    } else if (nombre.endsWith('.ts') && !/\.(test|spec)\.ts$/.test(nombre)) {
      salida.push(completo);
    }
  }
  return salida;
}

const relativo = (archivo: string) => path.relative(RAIZ_PROYECTO, archivo).split(path.sep).join('/');

type Resultado = { archivos: string[]; problemas: string[]; importanServer: string[] };

function revisar(): Resultado {
  const pendientes = [...ENTRADAS.map((e) => path.join(RAIZ_PROYECTO, e)), ...tsDeCarpeta(path.join(RAIZ_PROYECTO, 'servidor'))];
  const vistos = new Set<string>();
  const problemas: string[] = [];
  const importanServer: string[] = [];
  while (pendientes.length > 0) {
    const archivo = pendientes.shift()!;
    if (vistos.has(archivo)) continue;
    vistos.add(archivo);
    const codigo = readFileSync(archivo, 'utf8');
    for (const { especificador, linea } of importsDeEjecucion(codigo, archivo)) {
      if (!especificador.startsWith('./') && !especificador.startsWith('../')) continue; // paquete de npm o de Node
      const donde = `${relativo(archivo)}:${linea} → '${especificador}'`;
      if (!especificador.endsWith('.js')) {
        problemas.push(`${donde}: le falta la extensión .js (en Vercel rompería con ERR_MODULE_NOT_FOUND)`);
        continue;
      }
      const base = path.resolve(path.dirname(archivo), especificador.slice(0, -'.js'.length));
      const destino = [`${base}.ts`, `${base}.js`].find((c) => existsSync(c));
      if (!destino) {
        problemas.push(`${donde}: no existe ese archivo`);
        continue;
      }
      if (destino === SERVER && relativo(archivo) !== 'api/index.ts') importanServer.push(donde);
      if (destino.endsWith('.ts')) pendientes.push(destino);
    }
  }
  return { archivos: [...vistos].map(relativo).sort(), problemas, importanServer };
}

describe('imports del servidor (división de server.ts)', () => {
  const resultado = revisar();

  it('recorre el código de las funciones de Vercel (la prueba no quedó vacía)', () => {
    expect(resultado.archivos).toEqual(expect.arrayContaining(['api/index.ts', 'api/eventos.ts', 'server.ts', 'eventos/servidor.ts']));
  });

  it('todo import relativo termina en .js y apunta a un archivo que existe', () => {
    expect(resultado.problemas).toEqual([]);
  });

  it('ningún módulo importa server.ts (sólo api/index.ts)', () => {
    expect(resultado.importanServer).toEqual([]);
  });

  it('detecta un import sin .js y deja pasar los import type', () => {
    const encontrados = importsDeEjecucion(
      [
        "import type { A } from './tipos';",
        "export type { B } from './tipos';",
        "import { c } from './bien.js';",
        "import { d } from './mal';",
        "export * from './reexporta.js';",
        "// import { e } from './comentario';",
        "const f = await import('./dinamico');",
      ].join('\n'),
    ).map((i) => i.especificador);
    expect(encontrados).toEqual(['./bien.js', './mal', './reexporta.js', './dinamico']);
  });
});
