// 10/10/2026 (pedido de Pablo): panel propio del colegio (servidor/colegio/panelColegio.ts).
// Corre las rutas de verdad con una base falsa en memoria (nada sale a la red): acceso con link + PIN,
// sesiones que se cortan al dar un PIN nuevo o apagar el acceso, tope de PIN equivocados, que el colegio
// no vea datos de las familias, y las entregas (sólo sus kits, sólo «listo para entregar»).
import http from 'http';
import type { AddressInfo } from 'net';
import express from 'express';
import { afterAll, beforeAll, beforeEach, describe, expect, it, vi } from 'vitest';

vi.mock('dotenv', () => {
  const config = () => ({ parsed: {} });
  return { default: { config }, config };
});

const h = vi.hoisted(() => {
  const estado = { tablas: {} as Record<string, any[]> };
  const valor = (fila: any, campo: string) => fila[campo] ?? null;
  const comparar = (a: any, b: any) => {
    const fa = Date.parse(a);
    const fb = Date.parse(b);
    if (typeof a === 'string' && typeof b === 'string' && /^\d{4}-/.test(a) && Number.isFinite(fa) && Number.isFinite(fb)) return fa - fb;
    if (typeof a === 'number' && typeof b === 'number') return a - b;
    return String(a).localeCompare(String(b));
  };
  function consulta(tabla: string) {
    const filtros: Array<(f: any) => boolean> = [];
    let cambios: Record<string, any> | null = null;
    let nuevas: any[] | null = null;
    let unica = false;
    let rango: [number, number] | null = null;
    let limite = Infinity;
    const ordenes: { campo: string; asc: boolean }[] = [];
    const q: any = {
      select: () => q,
      eq: (c: string, v: any) => (filtros.push((f) => valor(f, c) === v), q),
      neq: (c: string, v: any) => (filtros.push((f) => valor(f, c) !== v), q),
      is: (c: string, v: any) => (filtros.push((f) => valor(f, c) === v), q),
      in: (c: string, vs: any[]) => (filtros.push((f) => vs.includes(valor(f, c))), q),
      gte: (c: string, v: any) => (filtros.push((f) => valor(f, c) !== null && comparar(valor(f, c), v) >= 0), q),
      lt: (c: string, v: any) => (filtros.push((f) => valor(f, c) !== null && comparar(valor(f, c), v) < 0), q),
      order: (campo: string, o?: { ascending?: boolean }) => (ordenes.push({ campo, asc: o?.ascending !== false }), q),
      range: (d: number, hasta: number) => ((rango = [d, hasta]), q),
      limit: (n: number) => ((limite = n), q),
      update: (c: Record<string, any>) => ((cambios = c), q),
      insert: (f: any) => ((nuevas = Array.isArray(f) ? f : [f]), q),
      maybeSingle: () => ((unica = true), q),
      single: () => ((unica = true), q),
      then: (ok: any, mal: any) => Promise.resolve(ejecutar()).then(ok, mal),
    };
    function ejecutar() {
      const filas = (estado.tablas[tabla] = estado.tablas[tabla] || []);
      if (nuevas) {
        const creadas = nuevas.map((f) => ({ created_at: new Date().toISOString(), ...f }));
        filas.push(...creadas);
        const copia = JSON.parse(JSON.stringify(creadas));
        return { data: unica ? copia[0] : copia, error: null };
      }
      let elegidas = filas.filter((f) => filtros.every((fn) => fn(f)));
      if (cambios) for (const f of elegidas) Object.assign(f, cambios);
      for (const { campo, asc } of [...ordenes].reverse()) {
        elegidas = [...elegidas].sort((a, b) => (asc ? 1 : -1) * comparar(valor(a, campo) ?? '', valor(b, campo) ?? ''));
      }
      if (rango) elegidas = elegidas.slice(rango[0], rango[1] + 1);
      const copia = JSON.parse(JSON.stringify(elegidas.slice(0, limite)));
      return { data: unica ? copia[0] ?? null : copia, error: null };
    }
    return q;
  }
  // registrar_intento: suma uno a la clave y devuelve los segundos de espera si pasó el tope.
  function rpc(nombre: string, args: any) {
    if (nombre !== 'registrar_intento') return Promise.resolve({ data: null, error: null });
    const filas = (estado.tablas.limites_intentos = estado.tablas.limites_intentos || []);
    let fila = filas.find((f) => f.clave === args.p_clave);
    if (!fila) {
      fila = { clave: args.p_clave, cantidad: 0, desde: new Date().toISOString() };
      filas.push(fila);
    }
    fila.cantidad += 1;
    return Promise.resolve({ data: fila.cantidad > args.p_max ? args.p_ventana_seg : 0, error: null });
  }
  return { estado, consulta, rpc };
});

vi.mock('@supabase/supabase-js', () => ({
  createClient: () => ({ from: (tabla: string) => h.consulta(tabla), rpc: (n: string, a: any) => h.rpc(n, a) }),
}));

const COLEGIO = '11111111-1111-4111-8111-111111111111';
const OTRO_COLEGIO = '22222222-2222-4222-8222-222222222222';
const anio = new Date().getFullYear();
const pagadoEste = `${anio}-06-15T15:00:00.000Z`;

let servidor: http.Server;
let puerto = 0;
let tokenAdmin = '';
const entornoAntes: Record<string, string | undefined> = {};

function pedir(metodo: string, ruta: string, cuerpo?: unknown, token?: string, ip?: string): Promise<{ status: number; json: any; texto: string }> {
  return new Promise((ok, mal) => {
    const datos = cuerpo === undefined ? undefined : JSON.stringify(cuerpo);
    const encabezados: Record<string, string | number> = {};
    if (ip) encabezados['X-Forwarded-For'] = ip;
    if (datos) {
      encabezados['Content-Type'] = 'application/json';
      encabezados['Content-Length'] = Buffer.byteLength(datos);
    }
    if (token) encabezados.Authorization = `Bearer ${token}`;
    const req = http.request({ host: '127.0.0.1', port: puerto, path: ruta, method: metodo, headers: encabezados }, (res) => {
      let texto = '';
      res.setEncoding('utf8');
      res.on('data', (c) => { texto += c; });
      res.on('end', () => {
        let json: any = null;
        try { json = JSON.parse(texto); } catch { /* no es JSON */ }
        ok({ status: res.statusCode || 0, json, texto });
      });
    });
    req.on('error', mal);
    if (datos) req.write(datos);
    req.end();
  });
}

function pedido(numero: string, extra: Record<string, any> = {}) {
  return {
    id: `uuid-${numero}`,
    pedido_friendly_id: numero,
    colegio_id: COLEGIO,
    colegio_nombre: 'Colegio de Prueba',
    grado: '5° grado',
    division: 'C',
    turno: 'Mañana',
    curso_codigo: 'GRADO5-CTM',
    alumno_nombre: `Alumno ${numero}`,
    alumno_numero_lista: 1,
    codigo_alumno: `GRADO5-CTM_01_${numero}`,
    tipo_kit: 'impreso_digital',
    kit_nombre: 'Kit Impreso',
    carpetas_impresas: 1,
    total: 30000,
    metodo_pago: 'transferencia',
    estado: 'pagado',
    estado_lab: 'listo_retiro',
    seleccion_pendiente: false,
    en_espera: false,
    archivado: false,
    pagado_at: pagadoEste,
    created_at: pagadoEste,
    fecha_entregado: null,
    entregado_por: null,
    copias_extras: {},
    fotos_seleccionadas: {},
    familias: { nombre: 'Tutor Secreto', email: 'familia-secreta@prueba.test' },
    ...extra,
  };
}

function cargarBase() {
  h.estado.tablas = {
    colegios: [
      { id: COLEGIO, nombre: 'Colegio de Prueba', evento_actual: 'Temporada 2026', porcentaje_participacion: 30 },
      { id: OTRO_COLEGIO, nombre: 'Otro Colegio', evento_actual: '', porcentaje_participacion: 30 },
    ],
    colegios_panel: [],
    convenios_colegios: [{ colegio_id: COLEGIO, created_at: `${anio}-03-01T12:00:00Z`, porcentaje_participacion: 30, razon_social: 'Asoc. Prueba', precios_laboratorio: null }],
    costos_liquidacion: [],
    codigos_seccion: [
      { id: 's1', colegio_id: COLEGIO, grado: '5° grado', turno: 'Mañana', division: 'C' },
      { id: 's2', colegio_id: COLEGIO, grado: '1° grado', turno: 'Mañana', division: 'A' },
    ],
    alumnos: [
      { id: 'a1', colegio_id: COLEGIO, grado: '5° grado', turno: 'Mañana', division: 'C' },
      { id: 'a2', colegio_id: COLEGIO, grado: '5° grado', turno: 'Mañana', division: 'C' },
      { id: 'a3', colegio_id: COLEGIO, grado: '1° grado', turno: 'Mañana', division: 'A' },
    ],
    inscripciones: [
      {
        id: 'i1', colegio_id: COLEGIO, estado: 'aceptado', alumno_nombre: 'Lorenzo', alumno_apellido: 'Prueba', grado: '5° grado', turno: 'Mañana', division: 'C',
        hermanos: [{ colegioId: COLEGIO, alumnoNombre: 'Hermana', alumnoApellido: 'Prueba', grado: '1° grado', turno: 'Mañana', division: 'A' }],
      },
      { id: 'i2', colegio_id: COLEGIO, estado: 'pendiente', alumno_nombre: 'Pendiente', alumno_apellido: 'X', grado: '5° grado', turno: 'Mañana', division: 'C', hermanos: [] },
    ],
    pedidos: [
      pedido('IFS-2026-0001', { alumno_nombre: 'Alumno Uno' }),
      pedido('IFS-2026-0002', { alumno_nombre: 'Alumno Dos', estado_lab: 'en_produccion', alumno_numero_lista: 2 }),
      pedido('IFS-2026-0003', { alumno_nombre: 'Alumno Uno', tipo_kit: 'solo_digital', kit_nombre: 'Kit Digital', carpetas_impresas: 0, estado_lab: null }),
      pedido('IFS-2026-0004', { alumno_nombre: 'Sin Pagar', estado: 'pendiente_pago', estado_lab: null, pagado_at: null }),
      pedido('IFS-2026-0005', { alumno_nombre: 'Archivado', archivado: true }),
      pedido('IFS-2026-0099', { colegio_id: OTRO_COLEGIO, alumno_nombre: 'De Otro Colegio' }),
    ],
    limites_intentos: [],
  };
}

const admin = (metodo: string, ruta: string, cuerpo?: unknown) => pedir(metodo, ruta, cuerpo, tokenAdmin);
const codigoDe = (link: string) => new URL(link).searchParams.get('c') || '';

async function darPin() {
  const r = await admin('POST', `/api/admin/colegios/${COLEGIO}/panel/pin`);
  expect(r.status).toBe(200);
  return { pin: String(r.json.pin), link: String(r.json.panel.link), codigo: codigoDe(r.json.panel.link) };
}
async function entrar(codigo: string, pin: string, ip?: string) {
  return pedir('POST', '/api/colegio/login', { codigo, pin }, undefined, ip);
}

beforeAll(async () => {
  for (const nombre of ['SUPABASE_SERVICE_ROLE_KEY', 'ADMIN_SESSION_SECRET', 'APP_URL']) entornoAntes[nombre] = process.env[nombre];
  process.env.SUPABASE_SERVICE_ROLE_KEY = 'prueba';
  process.env.ADMIN_SESSION_SECRET = 'secreto-de-prueba';
  process.env.APP_URL = 'https://www.retratoescolar.com.ar';
  const { rutasPanelColegio } = await import('../../../servidor/colegio/panelColegio');
  const { generateAdminToken } = await import('../../../servidor/nucleo/auth');
  tokenAdmin = generateAdminToken() || '';
  const app = express();
  app.set('trust proxy', true); // como server.ts: la IP sale de X-Forwarded-For
  app.use(express.json());
  app.use(rutasPanelColegio);
  servidor = app.listen(0);
  await new Promise((ok) => servidor.once('listening', ok));
  puerto = (servidor.address() as AddressInfo).port;
}, 120_000);

afterAll(async () => {
  await new Promise((ok) => servidor.close(ok));
  for (const [nombre, valor] of Object.entries(entornoAntes)) {
    if (valor === undefined) delete process.env[nombre];
    else process.env[nombre] = valor;
  }
});

beforeEach(() => cargarBase());

describe('acceso del colegio: link + PIN que maneja Pablo', () => {
  it('sin convenio firmado no entra aunque el PIN sea correcto: recibe el link para firmarlo; al firmar entra', async () => {
    h.estado.tablas.convenios_colegios = [];
    h.estado.tablas.colegios[0].codigo_convenio = 'CVPRUEBA123';
    const linkConvenio = 'https://www.retratoescolar.com.ar/convenio.html?c=CVPRUEBA123';
    const { pin, codigo } = await darPin();
    // Pablo ve en su panel que falta la firma (y el link para mandarlo)
    const panelAdmin = (await admin('GET', `/api/admin/colegios/${COLEGIO}/panel`)).json.panel;
    expect(panelAdmin.convenio).toEqual({ firmado: false, fecha: null, link: linkConvenio });

    const r = await entrar(codigo, pin);
    expect(r.status).toBe(403);
    expect(r.json).toMatchObject({ success: false, codigo: 'CONVENIO_SIN_FIRMAR', linkConvenio });
    expect(r.json.token).toBeUndefined();
    // Con un PIN equivocado no se entera de nada del convenio
    const malo = pin === '000000' ? '111111' : '000000';
    const fallido = await entrar(codigo, malo);
    expect(fallido.status).toBe(401);
    expect(fallido.texto).not.toContain('convenio');

    // Firma el convenio → entra
    h.estado.tablas.convenios_colegios.push({ colegio_id: COLEGIO, created_at: new Date().toISOString(), porcentaje_participacion: 30 });
    const ok = await entrar(codigo, pin);
    expect(ok.status).toBe(200);
    expect((await admin('GET', `/api/admin/colegios/${COLEGIO}/panel`)).json.panel.convenio.firmado).toBe(true);

    // Si el convenio deja de figurar, la sesión abierta tampoco sirve
    h.estado.tablas.convenios_colegios = [];
    const despues = await pedir('GET', '/api/colegio/resumen', undefined, ok.json.token);
    expect(despues.status).toBe(403);
    expect(despues.json.codigo).toBe('CONVENIO_SIN_FIRMAR');
    expect((await pedir('GET', '/api/colegio/comision/detalle', undefined, ok.json.token)).status).toBe(403);
  });

  it('las rutas de Pablo exigen su sesión', async () => {
    expect((await pedir('GET', `/api/admin/colegios/${COLEGIO}/panel`)).status).toBe(401);
    expect((await pedir('POST', `/api/admin/colegios/${COLEGIO}/panel/pin`)).status).toBe(401);
  });

  it('generar PIN: 6 números, se guarda sólo cifrado y arma el link del colegio', async () => {
    const { pin, link, codigo } = await darPin();
    expect(pin).toMatch(/^\d{6}$/);
    expect(link).toBe(`https://www.retratoescolar.com.ar/colegio?c=${codigo}`);
    expect(codigo).toMatch(/^PC[0-9A-F]{20}$/);
    const fila = h.estado.tablas.colegios_panel[0];
    expect(fila.activo).toBe(true);
    expect(fila.pin_hash).toMatch(/^scrypt\$/);
    expect(JSON.stringify(fila)).not.toContain(pin);
    const vista = await admin('GET', `/api/admin/colegios/${COLEGIO}/panel`);
    expect(vista.json.panel).toMatchObject({ activo: true, tienePin: true, link });
    expect(JSON.stringify(vista.json)).not.toContain(pin);
  });

  it('entra con el PIN correcto; con uno equivocado o un link inválido, no', async () => {
    const { pin, codigo } = await darPin();
    const malo = pin === '000000' ? '111111' : '000000';
    expect((await entrar(codigo, malo)).status).toBe(401);
    expect((await entrar('PC0000000000000000000000', pin)).status).toBe(404);
    expect((await entrar(codigo, '123')).status).toBe(400);
    const ok = await entrar(codigo, pin);
    expect(ok.status).toBe(200);
    expect(ok.json.colegio.nombre).toBe('Colegio de Prueba');
    expect((await pedir('GET', '/api/colegio/resumen', undefined, ok.json.token)).status).toBe(200);
  });

  it('PIN nuevo: el anterior deja de valer y la sesión abierta se cierra', async () => {
    const primero = await darPin();
    const sesion = (await entrar(primero.codigo, primero.pin)).json.token;
    // Las sesiones se comparan con milisegundos: se espera un poco para que el PIN nuevo sea posterior.
    await new Promise((ok) => setTimeout(ok, 5));
    const segundo = await darPin();
    expect(segundo.codigo).toBe(primero.codigo); // el link no cambia
    const vencida = await pedir('GET', '/api/colegio/resumen', undefined, sesion);
    expect(vencida.status).toBe(401);
    expect(vencida.json.codigo).toBe('SESION_VENCIDA');
    if (primero.pin !== segundo.pin) expect((await entrar(primero.codigo, primero.pin)).status).toBe(401);
    expect((await entrar(segundo.codigo, segundo.pin)).status).toBe(200);
  });

  it('apagar el acceso cierra las sesiones y no deja entrar; prenderlo lo vuelve a habilitar', async () => {
    const { pin, codigo } = await darPin();
    const sesion = (await entrar(codigo, pin)).json.token;
    await new Promise((ok) => setTimeout(ok, 5));
    expect((await admin('POST', `/api/admin/colegios/${COLEGIO}/panel`, { activo: false })).json.panel.activo).toBe(false);
    expect((await pedir('GET', '/api/colegio/resumen', undefined, sesion)).status).toBe(401);
    expect((await entrar(codigo, pin)).status).toBe(403);
    await admin('POST', `/api/admin/colegios/${COLEGIO}/panel`, { activo: true });
    expect((await entrar(codigo, pin)).status).toBe(200);
  });

  it('una misma IP: a los 10 intentos en 15 minutos frena (como los otros ingresos)', async () => {
    const { pin, codigo } = await darPin();
    const malo = pin === '000000' ? '111111' : '000000';
    for (let i = 0; i < 10; i++) expect((await entrar(codigo, malo, '10.0.0.1')).status).toBe(401);
    expect((await entrar(codigo, pin, '10.0.0.1')).status).toBe(429);
    expect((await entrar(codigo, pin, '10.0.0.2')).status).toBe(200);
  });

  it('desde muchas IPs: después de 20 PIN equivocados en una hora, frena aunque el PIN sea el correcto', async () => {
    const { pin, codigo } = await darPin();
    const malo = pin === '000000' ? '111111' : '000000';
    for (let i = 0; i < 20; i++) expect((await entrar(codigo, malo, `10.1.0.${i}`)).status).toBe(401);
    expect((await entrar(codigo, pin, '10.2.0.1')).status).toBe(429);
  });

  it('no se puede prender sin PIN; las fechas se validan y se guardan', async () => {
    expect((await admin('POST', `/api/admin/colegios/${COLEGIO}/panel`, { activo: true })).status).toBe(409);
    expect((await admin('POST', `/api/admin/colegios/${COLEGIO}/panel`, { fechas: { tomaFotos: '20/10/2026' } })).status).toBe(400);
    const r = await admin('POST', `/api/admin/colegios/${COLEGIO}/panel`, { fechas: { tomaFotos: '2026-10-20', cierrePedidos: '2026-11-05', entregaKits: null } });
    expect(r.status).toBe(200);
    expect(r.json.panel.fechas).toEqual({ tomaFotos: '2026-10-20', cierrePedidos: '2026-11-05', entregaKits: null });
    expect(r.json.panel.activo).toBe(false);
  });
});

describe('lo que ve el colegio', () => {
  async function sesionColegio() {
    const { pin, codigo } = await darPin();
    return (await entrar(codigo, pin)).json.token as string;
  }

  it('resumen: SÓLO la comisión del colegio (misma cuenta que la liquidación), sin lo cobrado, costos, ganancia ni datos de las familias', async () => {
    const token = await sesionColegio();
    const r = await pedir('GET', '/api/colegio/resumen', undefined, token);
    expect(r.status).toBe(200);
    const { comision } = r.json;
    // La misma cuenta que la pestaña Liquidación de Pablo. Pagados de este colegio en la temporada:
    // 0001, 0002, 0003 y 0005 (el archivado también se cobró).
    const { calcularLiquidacionColegio, periodoLiquidacion } = await import('../../../servidor/convenioLiquidacion');
    const { getServerSupabase } = await import('../../../servidor/nucleo/clientes');
    const liquidacion = await calcularLiquidacionColegio(getServerSupabase() as any, COLEGIO, periodoLiquidacion(undefined, undefined)!);
    expect(liquidacion!.totales.pedidos).toBe(4);
    expect(liquidacion!.totales.venta).toBe(120000);
    expect(comision.participacion).toBeGreaterThan(0);
    expect(comision.participacion).toBeCloseTo(liquidacion!.participacion, 2);
    // Pedido de Pablo (10/10): el colegio ve sólo la comisión que se lleva.
    expect(Object.keys(comision).sort()).toEqual(['participacion', 'periodo']);
    expect(r.json.convenio).toMatchObject({ firmado: true, porcentaje: 30 });
    const texto = r.texto;
    for (const privado of ['"venta"', '"gananciaNeta"', '"costoLaboratorio"', '"comisionesCobro"', '"impuestos"', '"detalle"', 'IFS-2026-', 'Alumno Uno', 'Alumno Dos', 'familia-secreta@prueba.test', 'Tutor Secreto', 'De Otro Colegio']) {
      expect(texto).not.toContain(privado);
    }
  });

  it('detalle de la comisión: sólo con sesión del colegio y cuando lo pide; totales y pedidos por número y curso, sin datos de las familias', async () => {
    expect((await pedir('GET', '/api/colegio/comision/detalle')).status).toBe(401);
    const token = await sesionColegio();
    const resumen = (await pedir('GET', '/api/colegio/resumen', undefined, token)).json;
    const r = await pedir('GET', '/api/colegio/comision/detalle', undefined, token);
    expect(r.status).toBe(200);
    const { comision } = r.json;
    expect(comision.pedidos).toBe(4);
    expect(comision.venta).toBe(120000);
    expect(comision.porcentaje).toBe(30);
    expect(comision.participacion).toBeCloseTo(resumen.comision.participacion, 2);
    expect(comision.participacion).toBeCloseTo(Math.max(0, comision.gananciaNeta) * 0.3, 1);
    expect(comision.detalle.map((d: any) => d.pedido).sort()).toEqual(['IFS-2026-0001', 'IFS-2026-0002', 'IFS-2026-0003', 'IFS-2026-0005']);
    expect(Object.keys(comision.detalle[0]).sort()).toEqual(['curso', 'gananciaNeta', 'pagado', 'pedido', 'venta']);
    for (const privado of ['Alumno Uno', 'Alumno Dos', 'familia-secreta@prueba.test', 'Tutor Secreto', 'De Otro Colegio', 'IFS-2026-0099']) {
      expect(r.texto).not.toContain(privado);
    }
  });

  it('cursos: sólo números (nómina, inscriptos con hermanos, compraron y kits impresos)', async () => {
    const token = await sesionColegio();
    const { cursos } = (await pedir('GET', '/api/colegio/resumen', undefined, token)).json;
    const quinto = cursos.find((c: any) => c.grado === '5° grado');
    const primero = cursos.find((c: any) => c.grado === '1° grado');
    expect(cursos.indexOf(primero)).toBeLessThan(cursos.indexOf(quinto)); // en orden de grado
    expect(quinto).toMatchObject({ etiqueta: '5° grado "C" · Mañana', nomina: 2, inscriptos: 1, compraron: 3, impresos: 3 });
    expect(primero).toMatchObject({ nomina: 1, inscriptos: 1, compraron: 0, impresos: 0 });
  });

  it('entregas: sólo los kits impresos pagados de este colegio, sin contacto ni montos', async () => {
    const token = await sesionColegio();
    const r = await pedir('GET', '/api/colegio/entregas', undefined, token);
    expect(r.status).toBe(200);
    expect(r.json.entregas.map((e: any) => e.pedido)).toEqual(['IFS-2026-0001', 'IFS-2026-0002']);
    expect(r.json.entregas[0]).toMatchObject({ alumno: 'Alumno Uno', estado: 'listo', codigoSobre: 'GRADO5-CTM_01_IFS-2026-0001', cursoEtiqueta: '5° grado "C" · Mañana' });
    expect(r.json.entregas[1].estado).toBe('en_laboratorio');
    for (const privado of ['familia-secreta@prueba.test', 'Tutor Secreto', 'uuid-', '30000', 'De Otro Colegio']) expect(r.texto).not.toContain(privado);
  });

  it('marcar entregado: sólo «listo para entregar» y sólo de este colegio; queda registrado que fue el colegio', async () => {
    const token = await sesionColegio();
    const ok = await pedir('POST', '/api/colegio/entregas/IFS-2026-0001/entregado', undefined, token);
    expect(ok.status).toBe(200);
    const fila = h.estado.tablas.pedidos.find((p) => p.pedido_friendly_id === 'IFS-2026-0001');
    expect(fila).toMatchObject({ estado_lab: 'entregado', entregado_por: 'colegio' });
    expect(fila.fecha_entregado).toBeTruthy();
    expect((await pedir('POST', '/api/colegio/entregas/IFS-2026-0001/entregado', undefined, token)).json).toMatchObject({ success: true, yaEstaba: true });
    expect((await pedir('POST', '/api/colegio/entregas/IFS-2026-0002/entregado', undefined, token)).status).toBe(409);
    expect((await pedir('POST', '/api/colegio/entregas/IFS-2026-0099/entregado', undefined, token)).status).toBe(404);
    expect(h.estado.tablas.pedidos.find((p) => p.pedido_friendly_id === 'IFS-2026-0099').estado_lab).toBe('listo_retiro');
    expect((await pedir('POST', '/api/colegio/entregas/IFS-2026-0001/entregado')).status).toBe(401);
  });
});

describe('vista previa de Pablo (ve el panel como el colegio, sin PIN ni convenio)', () => {
  it('sólo con la sesión de Pablo; ve el panel aunque no haya convenio ni PIN, y no puede marcar entregas', async () => {
    h.estado.tablas.convenios_colegios = [];
    expect((await pedir('POST', `/api/admin/colegios/${COLEGIO}/panel/vista-previa`)).status).toBe(401);

    const r = await admin('POST', `/api/admin/colegios/${COLEGIO}/panel/vista-previa`);
    expect(r.status).toBe(200);
    expect(r.json).toMatchObject({ success: true, colegio: { nombre: 'Colegio de Prueba' }, expiraEn: 7200 });
    const vista = String(r.json.token);
    expect(vista.startsWith('colegiovista.')).toBe(true);
    expect(h.estado.tablas.colegios_panel).toHaveLength(0); // no crea PIN ni acceso

    const resumen = await pedir('GET', '/api/colegio/resumen', undefined, vista);
    expect(resumen.status).toBe(200);
    expect(resumen.json.colegio.nombre).toBe('Colegio de Prueba');
    expect(resumen.json.convenio.firmado).toBe(false);
    expect((await pedir('GET', '/api/colegio/comision/detalle', undefined, vista)).status).toBe(200);
    expect((await pedir('GET', '/api/colegio/entregas', undefined, vista)).status).toBe(200);

    const marcar = await pedir('POST', '/api/colegio/entregas/IFS-2026-0001/entregado', undefined, vista);
    expect(marcar.status).toBe(403);
    expect(marcar.json.codigo).toBe('VISTA_PREVIA');
    expect(h.estado.tablas.pedidos.find((p) => p.pedido_friendly_id === 'IFS-2026-0001')).toMatchObject({ estado_lab: 'listo_retiro', entregado_por: null });

    expect((await admin('POST', '/api/admin/colegios/33333333-3333-4333-8333-333333333333/panel/vista-previa')).status).toBe(404);
  });

  it('una sesión del colegio no se convierte en vista previa, y la vista previa vence a las 2 horas', async () => {
    const { pin, codigo } = await darPin();
    const sesion = String((await entrar(codigo, pin)).json.token);
    const disfrazada = sesion.replace(/^colegio\./, 'colegiovista.');
    expect((await pedir('GET', '/api/colegio/resumen', undefined, disfrazada)).status).toBe(401);

    const { generarTokenVistaPrevia } = await import('../../../servidor/colegio/panelColegio');
    const vieja = generarTokenVistaPrevia(COLEGIO, Date.now() - 2 * 60 * 60 * 1000 - 1000) || '';
    expect((await pedir('GET', '/api/colegio/resumen', undefined, vieja)).status).toBe(401);
    const nueva = generarTokenVistaPrevia(COLEGIO) || '';
    expect((await pedir('GET', '/api/colegio/resumen', undefined, nueva)).status).toBe(200);
  });
});
