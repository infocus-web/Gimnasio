// 25/10/2026 (Pablo: «cambio hasta laboratorio»): cambiar las fotos de un pedido confirmado sólo antes del laboratorio.
import { describe, expect, it } from 'vitest';
import { motivoNoCambiable } from '../../../servidor/panel/cambiarFotosPedido';
import { contextoNegocioConsultas } from '../../../servidor/familias/contextoConsultas';
import { fuenteServidor } from '../fuenteServidor';

const base = { estado: 'pagado', cancelado_definitivo: false, mejora_de_pedido_id: null, seleccion_pendiente: false, lote_lab_id: null, estado_lab: null };

describe('cambiar fotos de un pedido', () => {
  it('se puede sólo con el pedido pagado, ya elegido y fuera del laboratorio', () => {
    expect(motivoNoCambiable(base)).toBeNull();
    expect(motivoNoCambiable({ ...base, lote_lab_id: 'x' })).toMatch(/laboratorio/);
    expect(motivoNoCambiable({ ...base, estado_lab: 'en_produccion' })).toMatch(/laboratorio/);
    expect(motivoNoCambiable({ ...base, seleccion_pendiente: true })).toMatch(/todavía no eligió/);
    expect(motivoNoCambiable({ ...base, estado: 'pendiente' })).toMatch(/no está pagado/);
    expect(motivoNoCambiable({ ...base, cancelado_definitivo: true })).toMatch(/no está pagado/);
    expect(motivoNoCambiable({ ...base, mejora_de_pedido_id: 'y' })).toMatch(/mejora/);
  });

  it('la ruta exige admin, valida como la familia, no pisa un pedido que entró al laboratorio y usa otra clave de mail', () => {
    const server = fuenteServidor();
    expect(server).toContain("app.post('/api/admin/pedidos/:id/cambiar-fotos', requireAdminAuth");
    expect(server).toContain(".is('lote_lab_id', null)\n      .is('estado_lab', null)");
    expect(server).toContain('validarSeleccionFotos(supabase, pedido.colegio_id, pedido.curso_codigo');
    expect(server).toContain('fotos-hd-cambio-');
  });

  it('la IA sabe la regla', () => {
    expect(contextoNegocioConsultas()).toContain('CAMBIAR UNA FOTO YA CONFIRMADA');
  });
});

// 25/10/2026 (Pablo: «si alguno se hace el vivo, pide el cambio para quedarse con las dos fotos»).
describe('cambiar fotos: si ya descargó el HD', () => {
  it('el servidor frena el cambio salvo confirmación explícita, y la IA no lo ofrece', () => {
    const server = fuenteServidor();
    expect(server).toContain("codigo: 'YA_DESCARGO'");
    expect(server).toContain('req.body?.aunqueDescargo !== true');
    expect(server).toContain('descargas HD: ${Number(p.descargas_hd) || 0}');
    expect(contextoNegocioConsultas().replace(/\s+/g, ' ')).toContain('Si YA descargó las fotos en HD');
  });
});

// 25/10/2026 noche (Pablo): «no quiero que se le reenvíe la foto en HD, se quedaría con más de las que compró».
describe('cambiar fotos: sólo la impresa', () => {
  it('cambia la selección sin rearmar el .zip ni mandar mail, y no aplica a kits sólo digitales', () => {
    const server = fuenteServidor();
    expect(server).toContain("const soloImpresa = req.body?.soloImpresa === true;");
    expect(server).toContain("if (soloImpresa) return res.json({ success: true, soloImpresa: true, zipListo: false, mailEnviado: false });");
    expect(server).toContain("pedido.tipo_kit === 'solo_digital'");
    expect(server).toContain('.update(soloImpresa ? { fotos_seleccionadas: nueva, updated_at: new Date().toISOString() } :');
  });
});
