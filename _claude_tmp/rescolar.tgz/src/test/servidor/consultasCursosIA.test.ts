// 13/10/2026 (Pablo: «gemini no sabe como funciona nuestra web ni tampoco tiene los datos de los alumnos y
// cursos»): la ficha que recibe la IA de consultas trae los cursos que existen en el grado de cada chico, el
// curso de la nómina también para las inscripciones pendientes (suele ser el motivo) y el contexto la regla
// «la nómina manda». Caso real: Tomás Hernando Paludi, anotado en Sala 4 C Mañana (curso que no existe; en
// la nómina figura en C Tarde), y el borrador viejo le decía a la familia que todo estaba «pendiente».
import crypto from 'crypto';
import http from 'http';
import type { AddressInfo } from 'net';
import express from 'express';
import { afterAll, beforeAll, beforeEach, describe, expect, it, vi } from 'vitest';
import { estado } from '../auditoria1110/familias/baseFalsa';

const llamadas = vi.hoisted(() => [] as { sistema: string; prompt: string; esfuerzo?: string }[]);
const fallaIA = vi.hoisted(() => ({ error: null as any }));

vi.mock('dotenv', () => {
  const config = () => ({ parsed: {} });
  return { default: { config }, config };
});
vi.mock('@supabase/supabase-js', async () => {
  const b = await import('../auditoria1110/familias/baseFalsa');
  return { createClient: () => ({ from: (t: string) => b.consulta(t), rpc: (n: string, a: any) => b.rpc(n, a), storage: b.storage }) };
});
vi.mock('resend', async () => {
  const b = await import('../auditoria1110/familias/baseFalsa');
  return {
    Resend: class {
      emails = { send: async (m: any) => (b.estado.correos.push(m), { data: { id: 'x' }, error: null }) };
      batch = { send: async () => ({ data: { data: [] }, error: null }) };
    },
  };
});
vi.mock('../../../servidor/nucleo/ia', async (original) => ({
  ...((await original()) as object),
  iaConfigurada: () => true,
  ERROR_IA_NO_CONFIGURADA: 'sin ia',
  generarTextoIA: async (p: { sistema: string; prompt: string; esfuerzo?: string }) => {
    llamadas.push(p);
    if (fallaIA.error) throw fallaIA.error;
    return JSON.stringify({ tema: 'otro', respondible: false, respuesta: 'Borrador para la familia.', motivo: 'x' });
  },
}));

const COLEGIO = '11111111-1111-4111-8111-111111111111';
const JE = 'Jornada Extendida / Completa';
let tokenAdmin = '';
let limpiarCache: () => void = () => undefined;
let servidor: http.Server;
let puerto = 0;
const entornoAntes: Record<string, string | undefined> = {};

let ipN = 0;
function pedir(metodo: string, ruta: string, cuerpo?: unknown, admin = false): Promise<{ status: number; json: any }> {
  return new Promise((ok, mal) => {
    const datos = cuerpo === undefined ? undefined : JSON.stringify(cuerpo);
    ipN++;
    const encabezados: Record<string, string | number> = { 'X-Forwarded-For': `10.7.${Math.floor(ipN / 250)}.${ipN % 250}` };
    if (admin) encabezados.Authorization = `Bearer ${tokenAdmin}`;
    if (datos) {
      encabezados['Content-Type'] = 'application/json';
      encabezados['Content-Length'] = Buffer.byteLength(datos);
    }
    const req = http.request({ host: '127.0.0.1', port: puerto, path: ruta, method: metodo, headers: encabezados }, (res) => {
      let texto = '';
      res.setEncoding('utf8');
      res.on('data', (c) => { texto += c; });
      res.on('end', () => {
        let json: any = null;
        try { json = JSON.parse(texto); } catch { /* no JSON */ }
        ok({ status: res.statusCode || 0, json });
      });
    });
    req.on('error', mal);
    if (datos) req.write(datos);
    req.end();
  });
}

const alumno = (nombre: string, grado: string, division: string, turno: string | null) => ({ id: `al-${nombre}`, colegio_id: COLEGIO, nombre, grado, division, turno });
const inscripcion = (extra: Record<string, any>) => ({
  id: crypto.randomUUID(), colegio_id: COLEGIO, colegio_nombre: 'Colegio', padre_dni: '20111222', hermanos: [],
  notificacion_email_enviada: true, ...extra,
});
const consultar = (email: string) => pedir('POST', '/api/consultas-familias', { nombre: 'Familia', email, asunto: 'Curso', mensaje: '¿Está bien la inscripción de mi hijo?' });

beforeAll(async () => {
  for (const n of ['SUPABASE_SERVICE_ROLE_KEY', 'ADMIN_SESSION_SECRET', 'RESEND_API_KEY']) entornoAntes[n] = process.env[n];
  process.env.SUPABASE_SERVICE_ROLE_KEY = 'prueba';
  process.env.ADMIN_SESSION_SECRET = 'secreto-de-prueba';
  process.env.RESEND_API_KEY = 're_prueba';
  tokenAdmin = (await import('../../../servidor/nucleo/auth')).generateAdminToken() || '';
  limpiarCache = (await import('../../../servidor/familias/cursosNomina')).limpiarCacheCursosNomina;
  const app = express();
  app.set('trust proxy', true);
  app.use(express.json());
  app.use((await import('../../../servidor/familias/consultas')).rutasConsultas);
  servidor = app.listen(0);
  await new Promise((ok) => servidor.once('listening', ok));
  puerto = (servidor.address() as AddressInfo).port;
}, 120_000);

afterAll(async () => {
  await new Promise((ok) => servidor.close(ok));
  for (const [n, v] of Object.entries(entornoAntes)) {
    if (v === undefined) delete process.env[n];
    else process.env[n] = v;
  }
});

beforeEach(() => {
  limpiarCache();
  llamadas.length = 0;
  fallaIA.error = null;
  estado.correos = [];
  estado.latenciaMs = 0;
  estado.tablaQueFalla = '';
  estado.tablas = {
    colegios: [{ id: COLEGIO, nombre: 'Colegio' }],
    alumnos: [
      alumno('HERNANDO PALUDI, TOMAS', 'Sala 4 años', 'C', 'Tarde'), alumno('UNO, A', 'Sala 4 años', 'A', JE), alumno('DOS, C', 'Sala 4 años', 'C', JE),
      alumno('PEREZ, JUAN', '3° grado', 'A', 'Mañana'), alumno('TRES, B', '3° grado', 'B', 'Tarde'),
    ],
    codigos_seccion: [{ id: 's1', colegio_id: COLEGIO, grado: '3° grado', turno: 'Mañana', division: 'A', codigo_secreto: 'ABCD-EFGH' }],
    inscripciones: [], fotos: [], limites_intentos: [], consultas_familias: [], consultas_familias_mensajes: [], familias: [], pedidos: [], ev_eventos: [],
  };
});

describe('cursosDelGradoEnTexto', () => {
  it('ordenados, sin importar tildes ni mayúsculas del grado; null si el grado no está en la nómina', async () => {
    const { cursosDelGradoEnTexto } = await import('../../../servidor/familias/cursosNomina');
    const cursos = [
      { grado: 'Sala 4 años', division: 'C', turno: 'Tarde' }, { grado: 'Sala 4 años', division: 'A', turno: JE },
      { grado: '5° grado', division: 'Jornada Extendida', turno: JE }, { grado: '1° año', division: 'B', turno: null },
    ];
    expect(cursosDelGradoEnTexto(cursos, 'sala 4 AÑOS')).toBe(`división A (${JE}), división C (Tarde)`);
    expect(cursosDelGradoEnTexto(cursos, '5° grado')).toBe(`Jornada Extendida (${JE})`);
    expect(cursosDelGradoEnTexto(cursos, '1° año')).toBe('división B');
    expect(cursosDelGradoEnTexto(cursos, '7° grado')).toBeNull();
    expect(cursosDelGradoEnTexto(cursos, '')).toBeNull();
  });
});

describe('ficha de la familia para la IA (13/10)', () => {
  it('pendiente en un curso que no existe: le dice a la IA dónde figura en la nómina y qué cursos hay', async () => {
    estado.tablas.inscripciones.push(inscripcion({
      email: 'paludi@familia.test', padre_nombre: 'Alejandra Tutora', estado: 'pendiente', codigo_asignado: null,
      alumno_nombre: 'Tomás', alumno_apellido: 'Hernando Paludi', grado: 'Sala 4 años', division: 'C', turno: 'Mañana',
    }));
    expect((await consultar('paludi@familia.test')).status).toBe(201);
    expect(llamadas).toHaveLength(2); // 26/10: redacción + control (respuestaVerificada.ts)
    const { sistema, prompt, esfuerzo } = llamadas[0];
    expect(sistema).toContain('LA NÓMINA MANDA');
    expect(sistema).toContain('Grado/Sala → División → Turno');
    expect(prompt).toContain('[PROBLEMA] La inscripción de Alejandra Tutora está "pendiente"');
    expect(prompt).toContain('[PROBLEMA] Tomás Hernando Paludi está inscripto en Sala 4 años "C" turno Mañana (curso que NO existe en el colegio), pero en la nómina figura en Sala 4 años "C" turno Tarde.');
    expect(prompt).toContain(`Cursos que existen en Sala 4 años según la nómina del colegio: división A (${JE}), división C (${JE}), división C (Tarde).`);
    expect(prompt).toContain('aplicá "LA NÓMINA MANDA"');
    // Pendiente: todavía no puede entrar, así que no se cuentan fotos. Lo automático usa el esfuerzo bajo.
    expect(prompt).not.toContain('Fotos cargadas');
    expect(esfuerzo).toBeUndefined();
  });

  it('aprobada y bien: [OK] con los cursos del grado; un hermano fuera de la nómina no inventa cursos', async () => {
    estado.tablas.inscripciones.push(inscripcion({
      email: 'perez@familia.test', padre_nombre: 'Ana Tutora', estado: 'aceptado', codigo_asignado: 'ABCD-EFGH',
      alumno_nombre: 'Juan', alumno_apellido: 'Pérez', grado: '3° grado', division: 'A', turno: 'Mañana',
      hermanos: [{ alumnoNombre: 'Lola', alumnoApellido: 'Pérez', grado: '7° grado', division: 'A', turno: 'Mañana' }],
    }));
    await consultar('perez@familia.test');
    const { prompt } = llamadas[0];
    expect(prompt).toContain('[OK] Juan Pérez: 3° grado "A" turno Mañana, coincide con la nómina.');
    expect(prompt).toContain('Cursos que existen en 3° grado según la nómina del colegio: división A (Mañana), división B (Tarde).');
    expect(prompt).toContain('Fotos cargadas del curso de Juan Pérez');
    expect(prompt).toContain('[PROBLEMA] Lola Pérez (7° grado "A" turno Mañana) no figura en la nómina del colegio');
    expect(prompt).not.toContain('Cursos que existen en 7° grado');
    expect(prompt.match(/Cursos que existen en 3° grado/g)).toHaveLength(1);
  });

  it('«Sugerir con IA» / «Revisar de nuevo» del panel: revisa con los datos de ahora y pide más esfuerzo', async () => {
    const insc = inscripcion({
      email: 'paludi@familia.test', padre_nombre: 'Alejandra Tutora', estado: 'pendiente', codigo_asignado: null,
      alumno_nombre: 'Tomás', alumno_apellido: 'Hernando Paludi', grado: 'Sala 4 años', division: 'C', turno: 'Mañana',
    });
    estado.tablas.inscripciones.push(insc);
    estado.tablas.consultas_familias.push({ id: 'c1', nombre: 'Alejandra', email: 'paludi@familia.test', asunto: 'Curso', mensaje: 'Hola', estado: 'nueva', origen: 'web' });
    // Después de la consulta Pablo aprobó la inscripción en el curso de la nómina:
    Object.assign(insc, { estado: 'aceptado', turno: 'Tarde', codigo_asignado: 'SALA-4CTT' });
    estado.tablas.codigos_seccion.push({ id: 's2', colegio_id: COLEGIO, grado: 'Sala 4 años', turno: 'Tarde', division: 'C', codigo_secreto: 'SALA-4CTT' });
    const r = await pedir('POST', '/api/admin/consultas-familias/c1/sugerir-respuesta', {}, true);
    expect(r.status).toBe(200);
    expect(r.json.sugerencia).toBe('Borrador para la familia.');
    expect(llamadas[0].esfuerzo).toBe('medium');
    expect(llamadas[0].prompt).toContain('[OK] Tomás Hernando Paludi: Sala 4 años "C" turno Tarde, coincide con la nómina.');
    expect(llamadas[0].prompt).not.toContain('"pendiente"');
    const guardada = estado.tablas.consultas_familias.find((c) => c.id === 'c1');
    expect(guardada.procesada_ia_at).toBeTruthy();
    expect(guardada.verificacion_ia.todoOk).toBe(true);
    expect(estado.correos.filter((c) => c.to?.[0] === 'paludi@familia.test')).toHaveLength(0);
  });

  // 13/10/2026: con la IA saturada (Claude 529 «Overloaded» o 503) el panel muestra un aviso
  // para reintentar en unos minutos, en vez de un error 500.
  it('«Sugerir con IA» con la IA saturada: aviso para reintentar (200), no error; otro error sigue siendo 500', async () => {
    estado.tablas.consultas_familias.push({ id: 'c1', nombre: 'Ana', email: 'ana@familia.test', asunto: 'Fotos', mensaje: 'Hola', estado: 'nueva', origen: 'web' });
    fallaIA.error = Object.assign(new Error('Claude respondió 529: Overloaded'), { status: 529 });
    const r = await pedir('POST', '/api/admin/consultas-familias/c1/sugerir-respuesta', {}, true);
    expect(r.status).toBe(200);
    expect(r.json).toMatchObject({ success: true, sugerencia: '' });
    expect(r.json.aviso).toMatch(/saturada/);
    fallaIA.error = new Error('This model is currently experiencing high demand. UNAVAILABLE');
    expect((await pedir('POST', '/api/admin/consultas-familias/c1/sugerir-respuesta', {}, true)).json.aviso).toMatch(/saturada/);
    fallaIA.error = Object.assign(new Error('Claude respondió 400: credit balance is too low'), { status: 400 });
    expect((await pedir('POST', '/api/admin/consultas-familias/c1/sugerir-respuesta', {}, true)).status).toBe(500);
  });
});

// 14/10/2026 (caso Paludi): la respuesta automática prometió «ya le pasamos la información al equipo… te va a
// llegar el nuevo código» y nadie hizo el cambio. Esas promesas no salen solas.
describe('respuestaPrometeCambio', () => {
  it('detecta promesas de corrección o de código nuevo', async () => {
    const { respuestaPrometeCambio } = await import('../../../servidor/familias/consultas');
    expect(respuestaPrometeCambio('Ya le pasamos la información al equipo para que corrija el curso de Tomás.')).toBe(true);
    expect(respuestaPrometeCambio('Apenas quede hecha la modificación, te va a llegar el nuevo código de acceso.')).toBe(true);
    expect(respuestaPrometeCambio('Ya lo corregimos.')).toBe(true);
    expect(respuestaPrometeCambio('Vamos a cambiar el curso.')).toBe(true);
    expect(respuestaPrometeCambio('Revisá Spam/Promociones; también podés pedir que te reenvíen el código desde la web.')).toBe(false);
    expect(respuestaPrometeCambio('Para elegir las fotos entrás con el código del curso y tu DNI.')).toBe(false);
  });
});

describe('hablaDeFotoFaltante (auditoría 25/10)', () => {
  it('las consultas por fotos que faltan o por repetir una foto nunca salen solas', async () => {
    const { hablaDeFotoFaltante } = await import('../../../servidor/familias/consultas');
    for (const t of [
      'Mi hijo faltó el día de la foto, ¿qué hacemos?',
      'Tomás estuvo ausente esa semana',
      'No aparece la foto individual de mi hija',
      'no encuentro la foto de Juan',
      'Mi nena no tiene la foto con la seño',
      '¿Se puede repetir la foto? Salió con los ojos cerrados',
      '¿Le pueden sacar otra foto?',
      'Quisiera que le saquen la foto individual',
      'A mi hijo le falta la foto grupal',
      'No salió en la grupal',
      'Estaba enfermo ese día',
      '¿Le pueden tomar la foto de nuevo?',
    ]) expect(hablaDeFotoFaltante(t), t).toBe(true);
    for (const t of [
      '¿Cómo pago por transferencia?',
      'No me llegó el código de acceso',
      'Quiero la foto de hermanos',
      '¿Cuándo entregan las carpetas impresas?',
      '¿Cuándo van a estar las fotos? Todavía no están',
      'Las fotos aún no están disponibles',
      'No hay fotos en la galería todavía',
      'El pago no fue acreditado',
      'No vino el código de acceso',
      'Me cobraron un pago repetido',
    ]) expect(hablaDeFotoFaltante(t), t).toBe(false);
  });
});
// Auditoría 28/10 (M2 y M3): el filtro de links mira el dominio real, y una promesa de plata queda como borrador.
describe('Auditoría 28/10: links ajenos y promesas de reintegro', () => {
  it('hayLinkAjeno: sólo deja pasar retratoescolar.com.ar y sus subdominios', async () => {
    const { hayLinkAjeno } = await import('../../../servidor/familias/consultas');
    expect(hayLinkAjeno('Entrá a https://retratoescolar.com.ar/portal y elegí tus fotos.')).toBe(false);
    expect(hayLinkAjeno('Mirá www.retratoescolar.com.ar, o escribí a contacto@retratoescolar.com.ar.')).toBe(false);
    expect(hayLinkAjeno('Podés verlo en retratoescolar.com.ar.')).toBe(false);
    expect(hayLinkAjeno('Pagá en https://retratoescolar.com.ar.pago-seguro.xyz/checkout')).toBe(true);
    expect(hayLinkAjeno('Pagá en https://evil.com/retratoescolar.com.ar')).toBe(true);
    expect(hayLinkAjeno('Pagá en pago-retrato.com/x')).toBe(true);
    expect(hayLinkAjeno('Tu código es ABCD-1234. Sala 5.A, turno mañana.')).toBe(false);
  });
  it('respuestaPrometeCambio: un reintegro, un descuento o algo gratis lo decide Pablo', async () => {
    const { respuestaPrometeCambio } = await import('../../../servidor/familias/consultas');
    expect(respuestaPrometeCambio('Te devolvemos el pago en las próximas 48 horas.')).toBe(true);
    expect(respuestaPrometeCambio('Te vamos a reintegrar la diferencia.')).toBe(true);
    expect(respuestaPrometeCambio('Te hacemos un descuento del 50% en el kit.')).toBe(true);
    expect(respuestaPrometeCambio('La foto extra va sin costo.')).toBe(true);
    expect(respuestaPrometeCambio('El Kit Impreso trae 3 fotos y la carpeta.')).toBe(false);
    expect(respuestaPrometeCambio('Si tenés un código de descuento, lo cargás antes de pagar.')).toBe(false);
  });
});
