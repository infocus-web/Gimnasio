// 25/10/2026: encuesta de satisfacción a las familias (mail a todas + link personal firmado + panel).
import { readFileSync } from 'fs';
import path from 'path';
import { afterEach, beforeEach, describe, expect, it } from 'vitest';
import { fuenteServidor } from '../fuenteServidor';
import { correoEncuesta, leerTokenEncuesta, linkEncuesta, tokenEncuesta, TOKEN_PRUEBA, validarRespuesta } from '../../../servidor/familias/encuesta';

const ID = '11111111-2222-4333-8444-555555555555';

describe('encuesta a las familias', () => {
  const anterior = process.env.PEDIDOS_ACCESO_SECRET;
  beforeEach(() => { process.env.PEDIDOS_ACCESO_SECRET = 'secreto-de-prueba'; });
  afterEach(() => { process.env.PEDIDOS_ACCESO_SECRET = anterior; });

  it('el link es personal y firmado: no se puede responder por otra familia', () => {
    const link = linkEncuesta(ID);
    const t = decodeURIComponent(link.split('encuesta=')[1]);
    expect(leerTokenEncuesta(t)).toBe(ID);
    expect(leerTokenEncuesta(`${ID}.${'x'.repeat(32)}`)).toBeNull();
    expect(leerTokenEncuesta(`22222222-2222-4333-8444-555555555555.${tokenEncuesta(ID)}`)).toBeNull();
    expect(leerTokenEncuesta('cualquier-cosa')).toBeNull();
    expect(leerTokenEncuesta(TOKEN_PRUEBA)).toBe(TOKEN_PRUEBA);
    expect(linkEncuesta(null)).toContain('encuesta=prueba');
  });

  it('valida las respuestas: estrellas 1 a 5, «recomendarías» obligatorio, atención opcional, sugerencias acotadas', () => {
    expect(validarRespuesta({ fotos: 5, web: 4, recomendaria: 'si' }).ok).toBe(true);
    expect(validarRespuesta({ fotos: 5, web: 4, atencion: null, recomendaria: 'tal_vez', sugerencias: 'x'.repeat(3000), quiereContacto: true })).toMatchObject({ ok: true, datos: { atencion: null, quiere_contacto: true } });
    expect((validarRespuesta({ fotos: 5, web: 4, recomendaria: 'no', sugerencias: 'x'.repeat(3000) }) as any).datos.sugerencias).toHaveLength(2000);
    expect(validarRespuesta({ fotos: 6, web: 4, recomendaria: 'si' }).ok).toBe(false);
    expect(validarRespuesta({ fotos: 5, web: 4 }).ok).toBe(false);
    expect(validarRespuesta({ fotos: 5, web: 4, recomendaria: 'quizas' }).ok).toBe(false);
  });

  it('el mail lleva disculpa, el compromiso con las fotos que faltan y el link personal', () => {
    const correo = correoEncuesta({ email: 'familia@x.com', tutor: 'María Belén López', inscripcionId: ID });
    expect(correo.to).toEqual(['familia@x.com']);
    expect(correo.html).toContain('Hola <strong>María</strong>');
    expect(correo.html).toContain('todos los chicos tengan la suya');
    expect(correo.html).toContain('te pedimos disculpas');
    expect(correo.html).toContain('Responder la encuesta');
    expect(correo.html).toContain(`encuesta=${encodeURIComponent(`${ID}.${tokenEncuesta(ID)}`)}`);
  });

  it('rutas: la familia responde con su link (con límite de intentos); los resultados exigen admin; el mail sale desde «Emails»', () => {
    const server = fuenteServidor();
    expect(server).toMatch(/app\.get\('\/api\/encuesta', limitarFrecuencia\(/);
    expect(server).toMatch(/app\.post\('\/api\/encuesta', limitarFrecuencia\(/);
    expect(server).toContain("app.get('/api/admin/encuesta', requireAdminAuth");
    expect(server).not.toContain("'/api/admin/encuesta/enviar'");
    expect(server).toContain("onConflict: 'inscripcion_id'");
    expect(server).toContain("update({ encuesta_enviada_at: ahora })");
  });

  it('la tabla tiene RLS prendido y una respuesta por inscripción', () => {
    const sql = readFileSync(path.resolve(__dirname, '../../../supabase/migrations/20261025230000_encuesta_familias.sql'), 'utf8');
    expect(sql).toContain('inscripcion_id text not null unique');
    expect(sql).toContain('enable row level security');
  });
});
