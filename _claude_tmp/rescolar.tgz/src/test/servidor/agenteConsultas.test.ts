// 26/10/2026 (Pablo: «cuando apriete "Pedir otra a la IA", te llegue la consulta a vos»; eligió Claude Opus 5.5).
// El agente investiga con herramientas de SÓLO LECTURA y entrega con «entregar_respuesta». Acá se simula la API de
// Claude (fetch) y la base, con el caso real de Cristina Villar («Riesmersma» en la nómina).
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { consulta as tabla, estado } from '../auditoria1110/familias/baseFalsa';
import { investigarYResponder } from '../../../servidor/familias/agenteConsultas';

const COLEGIO = '11111111-1111-4111-8111-111111111111';
const supabase: any = { from: (t: string) => tabla(t) };
const consultaVillar = { id: 'c1', nombre: 'Cristina', email: 'cris@familia.test', asunto: 'Pagos', mensaje: 'Cargué a mis 2 hijos pero de uno no quiero las fotos. ¿Es eso lo que no me deja pagar?', origen: 'web', consultas_familias_mensajes: [] };
const ficha = { chequeos: [{ ok: false, texto: 'Benicio Riemersma Villar (6° grado "A") no figura tal cual en la nómina.' }], datos: ['No tiene pedidos hechos todavía.'] };

let pedidos: any[] = [];
function respuestas(...contenidos: any[][]) {
  pedidos = [];
  const cola = [...contenidos];
  vi.stubGlobal('fetch', vi.fn(async (_url: string, init: any) => {
    pedidos.push(JSON.parse(init.body));
    const content = cola.shift() || [];
    return { ok: true, status: 200, json: async () => ({ content, stop_reason: content.some((b: any) => b.type === 'tool_use') ? 'tool_use' : 'end_turn' }) } as any;
  }));
}
const entregar = (extra: Record<string, any> = {}) => ({
  type: 'tool_use', id: 'fin', name: 'entregar_respuesta',
  input: { tema: 'pedido_pago', entendido: 'No puede pagar porque no quiere las fotos de un hijo.', ambiguedades: [], decisiones: [], respuesta: 'Sí, era eso: ahora podés tocar «No quiero sus fotos».', motivo: 'Benicio está en la nómina con el apellido mal escrito.', ...extra },
});

beforeEach(() => {
  process.env.ANTHROPIC_API_KEY = 'sk-prueba';
  delete process.env.ANTHROPIC_MODEL_AGENTE;
  estado.latenciaMs = 0;
  estado.tablaQueFalla = '';
  estado.tablas = {
    alumnos: [
      { id: 'a1', colegio_id: COLEGIO, nombre: 'RIESMERSMA VILLAR, BENICIO', grado: '6° grado', division: 'A', turno: 'Mañana', fotografiado_at: '2026-10-14T12:09:41Z', foto_grupal_at: '2026-10-19T12:45:26Z', foto_seno_at: null },
      { id: 'a2', colegio_id: COLEGIO, nombre: 'BENITEZ, BENICIO', grado: '6° grado', division: 'A', turno: 'Mañana' },
    ],
    inscripciones: [], pedidos: [], familias: [], consultas_familias: [], consultas_familias_mensajes: [], envios_email: [], fotos: [],
  };
});
afterEach(() => {
  vi.unstubAllGlobals();
  delete process.env.ANTHROPIC_API_KEY;
});

describe('agente de consultas (Opus, sólo lectura)', () => {
  it('investiga con herramientas, encuentra el nombre mal escrito y entrega el borrador con su análisis', async () => {
    respuestas(
      [{ type: 'text', text: 'Busco a Benicio en la nómina.' }, { type: 'tool_use', id: 't1', name: 'buscar_en_nomina', input: { nombre: 'Benicio Riemersma Villar', grado: '6° grado' } }],
      [entregar({ decisiones: [{ pregunta: '¿Corregís el apellido en la nómina?', opciones: ['Sí, corregirlo', 'No'] }] })],
    );
    const r = await investigarYResponder({ supabase, consulta: consultaVillar, ficha, colegios: [COLEGIO], sistema: 'Contexto del negocio' });

    // 1ª vuelta: modelo Opus, herramientas sólo de lectura, la consulta y la ficha numerada.
    expect(pedidos[0].model).toBe('claude-opus-5-5');
    expect(pedidos[0].tools.map((t: any) => t.name)).toEqual(['buscar_inscripciones', 'buscar_en_nomina', 'fotos_del_curso', 'ver_pedido', 'conversaciones_anteriores', 'entregar_respuesta']);
    expect(pedidos[0].messages[0].content).toContain('de uno no quiero las fotos');
    expect(pedidos[0].messages[0].content).toContain('[C1] [PROBLEMA] Benicio Riemersma Villar');
    // 2ª vuelta: recibió el resultado de la nómina, con el nombre parecido y las marcas del día de fotos.
    const resultado = pedidos[1].messages.at(-1).content[0];
    expect(resultado).toMatchObject({ type: 'tool_result', tool_use_id: 't1' });
    expect(resultado.content).toContain('RIESMERSMA VILLAR, BENICIO · 6° grado "A" Mañana (NOMBRE PARECIDO, no igual)');
    expect(resultado.content).toMatch(/individual 0?14\/10/);
    expect(resultado.content).not.toContain('BENITEZ');

    expect(r).toMatchObject({
      tema: 'pedido_pago', respondible: false, verificado: true, entendido: 'No puede pagar porque no quiere las fotos de un hijo.',
      respuesta: 'Sí, era eso: ahora podés tocar «No quiero sus fotos».',
      decisiones: [{ pregunta: '¿Corregís el apellido en la nómina?', opciones: ['Sí, corregirlo', 'No'] }],
    });
    expect(r.nota).toMatch(/^Investigada por Claude Opus con 1 consulta a la base/);
  });

  it('un pedido de OTRA familia se marca para no darle esos datos', async () => {
    estado.tablas.familias.push({ id: 'f-otra', email: 'otra@familia.test' });
    estado.tablas.pedidos.push({ pedido_friendly_id: 'IFS-2026-0001', alumno_nombre: 'Otro', curso_codigo: 'GRADO6-ATM', kit_nombre: 'Kit', estado: 'pagado', total: 30000, metodo_pago: 'mercadopago', familia_id: 'f-otra' });
    respuestas([{ type: 'tool_use', id: 't1', name: 'ver_pedido', input: { numero: 'IFS-2026-0001' } }], [entregar()]);
    await investigarYResponder({ supabase, consulta: consultaVillar, ficha, colegios: [COLEGIO], sistema: 'x' });
    expect(pedidos[1].messages.at(-1).content[0].content).toContain('NO es de este email');
  });

  it('si responde con texto sin entregar, se le pide que entregue; sin clave de la API no arranca', async () => {
    respuestas([{ type: 'text', text: 'Creo que ya está.' }], [entregar()]);
    const r = await investigarYResponder({ supabase, consulta: consultaVillar, ficha, colegios: [COLEGIO], sistema: 'x' });
    expect(pedidos[1].messages.at(-1).content).toMatch(/entregar_respuesta/);
    expect(r.respuesta).toContain('No quiero sus fotos');

    delete process.env.ANTHROPIC_API_KEY;
    respuestas();
    await expect(investigarYResponder({ supabase, consulta: consultaVillar, ficha, colegios: [COLEGIO], sistema: 'x' })).rejects.toThrow(/ANTHROPIC_API_KEY/);
    expect(pedidos).toHaveLength(0);
  });
});
