// 27/10/2026: «Pedirle a Claude» en Atender consultas (servidor/familias/pedirAClaude.ts).
import { afterEach, describe, expect, it, vi } from 'vitest';
import { dispararRutinaClaude, rutinaClaudeConfigurada, textoParaPegarEnClaude, textoPedidoClaude, URL_RUTINAS } from '../../../servidor/familias/pedirAClaude';

const consulta = {
  id: 'f1ea9485-0c04-4526-97cd-1f99fb58ba07',
  nombre: 'Melina',
  email: 'familia@ejemplo.com',
  asunto: 'Retomamos las fotos faltantes',
  mensaje: 'Quiero cambiar los datos de mi hija',
  created_at: '2026-10-26T21:12:10Z',
  verificacion_ia: { entendido: 'Quiere cambiar datos', motivo: 'Curso distinto a la nómina', ambiguedades: ['No dice qué dato'] },
};

describe('pedirle a Claude', () => {
  afterEach(() => {
    vi.unstubAllGlobals();
    vi.unstubAllEnvs();
  });

  it('el texto trae la consulta, la conversación en orden, lo que vio la IA y la nota de Pablo', () => {
    const t = textoPedidoClaude(consulta, [
      { direccion: 'entrante', contenido: 'Hola, quiero cambiar los datos', created_at: '1' },
      { direccion: 'saliente', contenido: '¿Qué dato?', created_at: '2' },
    ], 'fijate el curso');
    expect(t).toContain('Consulta: f1ea9485-0c04-4526-97cd-1f99fb58ba07');
    expect(t).toContain('Familia: Melina <familia@ejemplo.com>');
    expect(t.indexOf('Familia (1)')).toBeLessThan(t.indexOf('Nosotros (2)'));
    expect(t).toContain('Motivo: Curso distinto a la nómina');
    expect(t).toContain('Nota de Pablo: fijate el curso');
  });

  it('sin mensajes usa el de la consulta, y nunca pasa el límite de la API', () => {
    expect(textoPedidoClaude(consulta, [])).toContain('Quiero cambiar los datos de mi hija');
    const largo = textoPedidoClaude({ ...consulta, verificacion_ia: null }, Array.from({ length: 200 }, () => ({ direccion: 'entrante', contenido: 'x'.repeat(5000) })));
    expect(largo.length).toBeLessThanOrEqual(60_000);
  });

  it('28/10: sin rutina, el texto para pegar trae las reglas y el caso, sin pasarse del límite', () => {
    vi.stubEnv('CLAUDE_RUTINA_ID', '');
    vi.stubEnv('CLAUDE_RUTINA_TOKEN', '');
    expect(rutinaClaudeConfigurada()).toBe(false);
    const t = textoParaPegarEnClaude(textoPedidoClaude(consulta, []));
    expect(t).toContain('sólo con SELECT');
    expect(t).toContain('sin mi OK');
    expect(t).toContain('Consulta: f1ea9485-0c04-4526-97cd-1f99fb58ba07');
    expect(textoParaPegarEnClaude('x'.repeat(70_000)).length).toBeLessThanOrEqual(60_000);
    vi.stubEnv('CLAUDE_RUTINA_ID', 'trig_abc123');
    vi.stubEnv('CLAUDE_RUTINA_TOKEN', 'sk-ant-oat01-prueba');
    expect(rutinaClaudeConfigurada()).toBe(true);
  });

  it('sin variables no llama a nadie (503)', async () => {
    const fetchFalso = vi.fn();
    vi.stubGlobal('fetch', fetchFalso);
    vi.stubEnv('CLAUDE_RUTINA_ID', '');
    vi.stubEnv('CLAUDE_RUTINA_TOKEN', '');
    const r = await dispararRutinaClaude('hola');
    expect(r).toMatchObject({ ok: false, status: 503 });
    expect(fetchFalso).not.toHaveBeenCalled();
  });

  it('dispara la rutina con el token y devuelve el link de la sesión', async () => {
    vi.stubEnv('CLAUDE_RUTINA_ID', 'trig_abc123');
    vi.stubEnv('CLAUDE_RUTINA_TOKEN', 'sk-ant-oat01-prueba');
    const fetchFalso = vi.fn(async () => new Response(JSON.stringify({ type: 'routine_fire', claude_code_session_id: 'session_1', claude_code_session_url: 'https://claude.ai/code/session_1' }), { status: 200 }));
    vi.stubGlobal('fetch', fetchFalso);
    const r = await dispararRutinaClaude('caso');
    expect(r).toEqual({ ok: true, url: 'https://claude.ai/code/session_1', sesion: 'session_1' });
    const [url, init] = fetchFalso.mock.calls[0] as any;
    expect(url).toBe(`${URL_RUTINAS}/trig_abc123/fire`);
    expect(init.headers.Authorization).toBe('Bearer sk-ant-oat01-prueba');
    expect(JSON.parse(init.body)).toEqual({ text: 'caso' });
  });

  it('errores de la API: mensaje claro, sin el token; un link raro no se acepta', async () => {
    vi.stubEnv('CLAUDE_RUTINA_ID', 'trig_abc123');
    vi.stubEnv('CLAUDE_RUTINA_TOKEN', 'sk-ant-oat01-prueba');
    vi.stubGlobal('fetch', vi.fn(async () => new Response(JSON.stringify({ type: 'error', error: { type: 'authentication_error' } }), { status: 401 })));
    const r = await dispararRutinaClaude('caso');
    expect(r).toMatchObject({ ok: false, status: 502 });
    expect(JSON.stringify(r)).not.toContain('sk-ant');
    vi.stubGlobal('fetch', vi.fn(async () => new Response(JSON.stringify({ claude_code_session_url: 'https://otro.sitio/x' }), { status: 200 })));
    expect((await dispararRutinaClaude('caso')).ok).toBe(false);
    vi.stubGlobal('fetch', vi.fn(async () => new Response('{}', { status: 429 })));
    expect(await dispararRutinaClaude('caso')).toMatchObject({ ok: false, status: 429 });
  });
});
