// 25/10/2026 (Pablo): convocar a las familias a sacar la foto faltante (no la grupal) con día, hora y lugar.
import { describe, expect, it } from 'vitest';
import { correoConvocatoria, diaLegible, validarConvocatoria } from '../../../servidor/familias/convocatoriaFaltantes';
import { fuenteServidor } from '../fuenteServidor';

const ID = '11111111-2222-4333-8444-555555555555';
const manana = new Date(Date.now() + 86400000 * 2).toLocaleDateString('en-CA', { timeZone: 'America/Argentina/Buenos_Aires' });

describe('convocatoria de fotos faltantes', () => {
  it('valida día (no pasado), hora, lugar e ids', () => {
    expect(validarConvocatoria({ ids: [ID], dia: manana, hora: '9:30', lugar: 'Colegio' }).ok).toBe(true);
    expect(validarConvocatoria({ ids: [], dia: manana, hora: '9:30', lugar: 'Colegio' }).ok).toBe(false);
    expect(validarConvocatoria({ ids: [ID], dia: '2020-01-01', hora: '9:30', lugar: 'Colegio' }).ok).toBe(false);
    expect(validarConvocatoria({ ids: [ID], dia: manana, hora: '', lugar: 'Colegio' }).ok).toBe(false);
    expect(validarConvocatoria({ ids: [ID], dia: manana, hora: '9', lugar: '' }).ok).toBe(false);
    expect(validarConvocatoria({ ids: ['no-es-uuid'], dia: manana, hora: '9', lugar: 'Colegio' }).ok).toBe(false);
  });

  it('el mail trae día, hora, lugar, nota y cada foto, escapando el HTML', () => {
    const correo = correoConvocatoria(
      { email: 'a@b.com', tutor: 'Ana <b>', pedidos: [
        { alumno_nombre: 'Juan Pérez', lugar: 'individual', grado: '1°', division: 'A', turno: 'Mañana' },
        { alumno_nombre: 'Sofía Pérez', lugar: 'docente', grado: '3°', division: 'B', turno: 'Tarde' },
      ] },
      { dia: '2026-11-07', hora: '9:30 hs', lugar: 'Salón de actos', nota: 'Con uniforme' }
    );
    expect(correo.to).toEqual(['a@b.com']);
    expect(correo.subject).toContain('Juan Pérez y Sofía Pérez');
    expect(correo.subject).toContain(diaLegible('2026-11-07'));
    expect(correo.html).toContain('9:30 hs');
    expect(correo.html).toContain('Salón de actos');
    expect(correo.html).toContain('Con uniforme');
    expect(correo.html).toContain('la foto individual');
    expect(correo.html).toContain('Ana &lt;b&gt;');
    expect(correo.html).not.toMatch(/repet/i);
  });

  it('el servidor rechaza pedir la grupal y no la convoca; la ruta exige admin', () => {
    const server = fuenteServidor();
    expect(server).toContain("if (lugar === 'grupal') return res.status(400)");
    expect(server).toContain("f.estado === 'pendiente' && f.lugar !== 'grupal'");
    expect(server).toContain("app.post('/api/admin/fotos-faltantes/convocar', requireAdminAuth");
  });
});
