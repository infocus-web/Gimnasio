// Etapa 0 de la división de server.ts (plan `claude/plan-division-servidor.md`, 09/10/2026).
//
// Red de seguridad: importa la app de Express de verdad y anota, en el orden en que Express las
// atiende, todas las rutas (método + path + los middlewares de cada una, por ejemplo
// requireAdminAuth) y todos los `app.use`. Ese listado tiene que dar IDÉNTICO antes y después de
// cada etapa de la división: si al mover código se pierde una ruta, cambia de orden, queda con otro
// path o se le cae la protección de admin, esta prueba falla y el deploy no sale.
//
// Si agregás, sacás o cambiás una ruta A PROPÓSITO, regenerá el listado y revisá la diferencia:
//   ACTUALIZAR_INVENTARIO=1 npx vitest run src/test/servidor/inventarioRutas.test.ts
//   (en PowerShell: $env:ACTUALIZAR_INVENTARIO=1; npx vitest run src/test/servidor/inventarioRutas.test.ts)
import { existsSync, readFileSync, writeFileSync } from 'fs';
import path from 'path';
import { afterAll, beforeAll, describe, expect, it, vi } from 'vitest';

// Nunca leer el .env de la compu: las pruebas corren sin claves (ver vitest.config.ts). Importar la
// app sólo registra rutas; no se atiende ningún pedido ni sale nada a la red.
vi.mock('dotenv', () => {
  const config = () => ({ parsed: {} });
  return { default: { config }, config };
});

const ARCHIVO_INVENTARIO = path.resolve(__dirname, 'inventario-rutas.txt');
const ENCABEZADO = [
  '# Inventario de rutas y middlewares de server.ts, en el orden en que Express los atiende.',
  '# Lo genera y lo controla src/test/servidor/inventarioRutas.test.ts: NO editar a mano.',
  '# Formato: METODO /path  <- middlewares y handler de la ruta  |  USE <prefijo>  <middleware>',
  '',
].join('\n');

// app.all registra los ~35 métodos de HTTP de Node; se anota ALL para que el listado no dependa de
// la versión de Node.
const MINIMO_METODOS_ALL = 20;

const nombreDe = (fn: any): string => (fn && fn.name ? String(fn.name) : '<anonima>');

function prefijoDe(capa: any): string {
  if (capa.regexp?.fast_slash) return '/';
  return capa.regexp ? String(capa.regexp.source) : '?';
}

type Ruta = { metodos: string[]; paths: string[]; middlewares: string[] };

function recorrer(stack: any[], lineas: string[], rutas: Ruta[]) {
  for (const capa of stack) {
    if (capa.route) {
      const todos = Object.keys(capa.route.methods).filter((m) => m !== '_all');
      const metodos = todos.length >= MINIMO_METODOS_ALL || capa.route.methods._all ? ['ALL'] : todos.map((m) => m.toUpperCase());
      const paths = (Array.isArray(capa.route.path) ? capa.route.path : [capa.route.path]).map(String);
      // Etapa 4 (10/10): `app.all(path, fn)` guarda una capa por cada método (35 veces fn) y
      // `router.all(path, fn)` una sola que acepta cualquier método; atienden igual (verificado con
      // GET/POST/PUT/DELETE/PATCH/HEAD/OPTIONS). Para ALL se anotan sólo las capas de un método.
      const capas = metodos[0] === 'ALL' ? capa.route.stack.filter((c: any) => c.method === capa.route.stack[0]?.method) : capa.route.stack;
      const middlewares = capas.map((c: any) => nombreDe(c.handle));
      rutas.push({ metodos, paths, middlewares });
      lineas.push(`${metodos.join(',')} ${paths.join(' | ')}  <- ${middlewares.join(', ')}`);
    } else if (capa.name === 'router' && Array.isArray(capa.handle?.stack)) {
      // Router de un módulo de `servidor/`: se aplana. Montado sin prefijo (decisión 3 del plan) no
      // deja rastro; con prefijo se anota, para que el cambio de paths se vea en la diferencia.
      const prefijo = prefijoDe(capa);
      if (prefijo !== '/') lineas.push(`ROUTER ${prefijo}`);
      recorrer(capa.handle.stack, lineas, rutas);
      if (prefijo !== '/') lineas.push(`FIN ROUTER ${prefijo}`);
    } else {
      lineas.push(`USE ${prefijoDe(capa)}  ${nombreDe(capa.handle)}`);
    }
  }
}

let lineas: string[] = [];
let rutas: Ruta[] = [];
let vercelAntes: string | undefined;

beforeAll(async () => {
  vercelAntes = process.env.VERCEL;
  // Con VERCEL definido server.ts no arranca Vite ni app.listen (ver el final de server.ts).
  process.env.VERCEL = '1';
  const app = (await import('../../../server')).default as any;
  lineas = [];
  rutas = [];
  recorrer(app._router.stack, lineas, rutas);
}, 120_000);

afterAll(() => {
  if (vercelAntes === undefined) delete process.env.VERCEL;
  else process.env.VERCEL = vercelAntes;
});

describe('inventario de rutas del servidor (división de server.ts)', () => {
  it('encuentra las rutas (la prueba no quedó vacía)', () => {
    expect(rutas.length).toBeGreaterThan(100);
    expect(lineas.some((l) => l.startsWith('USE ') && l.includes('jsonParser'))).toBe(true);
  });

  it('coincide con inventario-rutas.txt (mismas rutas, mismo orden, mismos middlewares)', () => {
    const actual = ENCABEZADO + lineas.join('\n') + '\n';
    if (process.env.ACTUALIZAR_INVENTARIO === '1') {
      writeFileSync(ARCHIVO_INVENTARIO, actual, 'utf8');
      return;
    }
    if (!existsSync(ARCHIVO_INVENTARIO)) {
      throw new Error('Falta src/test/servidor/inventario-rutas.txt. Generalo con ACTUALIZAR_INVENTARIO=1 (ver el comentario del principio).');
    }
    const guardado = readFileSync(ARCHIVO_INVENTARIO, 'utf8').replace(/\r\n/g, '\n');
    expect(actual).toBe(guardado);
  });

  it('ninguna ruta está repetida (mismo método y path): Express atendería sólo la primera', () => {
    const vistas = new Map<string, number>();
    for (const r of rutas) for (const m of r.metodos) for (const p of r.paths) vistas.set(`${m} ${p}`, (vistas.get(`${m} ${p}`) || 0) + 1);
    expect([...vistas].filter(([, n]) => n > 1).map(([clave]) => clave)).toEqual([]);
  });

  it('toda ruta /api/admin/* pasa por requireAdminAuth, salvo el login y verify', () => {
    const sinProteccion = rutas
      .filter((r) => r.paths.some((p) => p.startsWith('/api/admin')) && !r.middlewares.includes('requireAdminAuth'))
      .map((r) => `${r.metodos.join(',')} ${r.paths.join(' | ')}`);
    expect(sinProteccion).toEqual(['POST /api/admin/login', 'GET /api/admin/verify']);
  });

  it('toda ruta /api/lab/* pasa por requireLabAuth, salvo el login', () => {
    const sinProteccion = rutas
      .filter((r) => r.paths.some((p) => p.startsWith('/api/lab')) && !r.middlewares.includes('requireLabAuth'))
      .map((r) => `${r.metodos.join(',')} ${r.paths.join(' | ')}`);
    expect(sinProteccion).toEqual(['POST /api/lab/login']);
  });
});
