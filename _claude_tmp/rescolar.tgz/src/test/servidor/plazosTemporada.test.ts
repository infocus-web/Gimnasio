// 30/10/2026 (Pablo): panel → Configuración. Las fechas límite se editan sin tocar código; la web, el servidor,
// los mails y la IA usan la fecha guardada (y, sin nada guardado, la de siempre: 15/11/2026).
import { afterEach, describe, expect, it, vi } from 'vitest';
import * as servidor from '../../../servidor/nucleo/plazosTemporada';
import * as web from '../../utils/plazosTemporada';
import { errorPlazoKitImpreso, exigirPlazoKitImpreso, plazoKitImpresoAbierto as kitServidor } from '../../../servidor/pagos/plazoKitImpreso';
import { solicitudFaltanteAbierta as faltantesServidor } from '../../../servidor/nucleo/fotosFaltantes';
import { kitOfrecido, plazoKitImpresoAbierto as kitWeb } from '../../utils/plazoKitImpreso';
import { solicitudFaltanteAbierta as faltantesWeb } from '../../utils/fotosFaltantes';
import { bloqueBuscadorRostro } from '../../../servidor/entrega/correos';
import { contextoNegocioConsultas } from '../../../servidor/familias/contextoConsultas';

function correr(mw: (req: any, res: any, next: () => void) => unknown, body: any) {
  const res: any = { codigo: 0, cuerpo: null, status(c: number) { this.codigo = c; return this; }, json(j: any) { this.cuerpo = j; return this; } };
  let siguio = false;
  mw({ body, params: {} }, res, () => { siguio = true; });
  return { siguio, res };
}

describe('plazos de la temporada (panel → Configuración)', () => {
  afterEach(() => {
    servidor.aplicarPlazos({ ...servidor.PLAZOS_POR_DEFECTO });
    web.aplicarPlazos({ ...web.PLAZOS_POR_DEFECTO });
    vi.useRealTimers();
  });

  it('sólo acepta días reales', () => {
    expect(servidor.validarPlazos({ kitImpreso: '2026-11-20', faltantes: '2026-11-18' })).toEqual({ kitImpreso: '2026-11-20', faltantes: '2026-11-18' });
    for (const malo of ['2026-02-30', '20/11/2026', '', null, '1999-01-01', '2026-13-01']) {
      expect(servidor.validarPlazos({ kitImpreso: malo, faltantes: '2026-11-18' })).toBeNull();
      expect(web.fechaValida(malo)).toBe(false);
    }
    expect(servidor.validarPlazos(null)).toBeNull();
    expect(web.aplicarPlazos({ kitImpreso: 'x', faltantes: '2026-11-18' })).toBe(false);
  });

  it('sin nada guardado, web y servidor siguen cortando el 15/11/2026 a la medianoche de Argentina', () => {
    expect(servidor.PLAZOS_POR_DEFECTO).toEqual(web.PLAZOS_POR_DEFECTO);
    const antes = new Date('2026-11-15T23:59:00-03:00');
    const despues = new Date('2026-11-16T00:00:30-03:00');
    expect([kitServidor(antes), kitWeb(antes), faltantesServidor(antes), faltantesWeb(antes)]).toEqual([true, true, true, true]);
    expect([kitServidor(despues), kitWeb(despues), faltantesServidor(despues), faltantesWeb(despues)]).toEqual([false, false, false, false]);
  });

  it('al mover las fechas, web y servidor cortan en el nuevo día (cada plazo por separado)', () => {
    servidor.aplicarPlazos({ kitImpreso: '2026-11-22', faltantes: '2026-11-08' });
    web.aplicarPlazos({ kitImpreso: '2026-11-22', faltantes: '2026-11-08' });
    const dia = new Date('2026-11-16T12:00:00-03:00');
    expect(kitServidor(dia)).toBe(true);
    expect(kitWeb(dia)).toBe(true);
    expect(kitOfrecido('kit-clasico', dia)).toBe(true);
    expect(faltantesServidor(dia)).toBe(false);
    expect(faltantesWeb(dia)).toBe(false);
    expect(kitServidor(new Date('2026-11-23T00:00:01-03:00'))).toBe(false);
  });

  it('el middleware del cobro usa la fecha guardada y el error la nombra', () => {
    vi.useFakeTimers({ toFake: ['Date'] });
    vi.setSystemTime(new Date('2026-11-18T12:00:00-03:00'));
    expect(correr(exigirPlazoKitImpreso, { kitId: 'kit-clasico' }).siguio).toBe(false);
    servidor.aplicarPlazos({ kitImpreso: '2026-11-20', faltantes: '2026-11-15' });
    expect(correr(exigirPlazoKitImpreso, { kitId: 'kit-clasico' }).siguio).toBe(true);
    servidor.aplicarPlazos({ kitImpreso: '2026-11-17', faltantes: '2026-11-15' });
    const r = correr(exigirPlazoKitImpreso, { kitId: 'kit-clasico' });
    expect(r.siguio).toBe(false);
    expect(r.res.codigo).toBe(410);
    expect(errorPlazoKitImpreso()).toContain('terminó el 17 de noviembre');
  });

  it('el mail «ya están tus fotos» y la IA dicen la fecha guardada', () => {
    servidor.aplicarPlazos({ kitImpreso: '2026-12-01', faltantes: '2026-11-20' });
    expect(bloqueBuscadorRostro()).toContain('hasta el 20/11 inclusive');
    const ia = contextoNegocioConsultas();
    expect(ia).toContain('Se pueden pedir hasta el 1 de diciembre.');
    expect(ia).toContain('Pasado el 20 de noviembre ya no se puede pedir que le saquen la foto');
  });

  it('textos de fecha', () => {
    expect(web.textoFechaCorta('2026-11-05')).toBe('05/11');
    expect(web.textoFechaLarga('2026-11-05')).toBe('5 de noviembre');
    expect(servidor.textoFechaLarga('2027-03-01')).toBe('1 de marzo');
  });
});
