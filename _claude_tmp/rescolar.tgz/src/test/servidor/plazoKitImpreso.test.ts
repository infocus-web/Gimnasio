// 26/10/2026 (Pablo): las fotos del Kit Impreso se eligen hasta el 15/11 inclusive; el Solo Digital no tiene límite.
import { afterEach, describe, expect, it, vi } from 'vitest';
import { exigirPlazoKitImpreso, exigirPlazoMejoraImpreso, plazoKitImpresoAbierto as plazoServidor } from '../../../servidor/pagos/plazoKitImpreso';
import { kitOfrecido, plazoKitImpresoAbierto as plazoWeb } from '../../utils/plazoKitImpreso';

function correr(mw: (req: any, res: any, next: () => void) => unknown, body: any) {
  const res: any = { codigo: 0, cuerpo: null, status(c: number) { this.codigo = c; return this; }, json(j: any) { this.cuerpo = j; return this; } };
  let siguio = false;
  mw({ body, params: {} }, res, () => { siguio = true; });
  return { siguio, res };
}

describe('plazo del Kit Impreso (15/11/2026)', () => {
  afterEach(() => vi.useRealTimers());

  it('web y servidor cortan en el mismo momento (fin del 15/11, hora de Argentina)', () => {
    for (const [fecha, abierto] of [['2026-11-15T23:59:00-03:00', true], ['2026-11-16T00:00:30-03:00', false]] as const) {
      expect(plazoServidor(new Date(fecha))).toBe(abierto);
      expect(plazoWeb(new Date(fecha))).toBe(abierto);
    }
    expect(kitOfrecido('kit-clasico', new Date('2026-11-16T10:00:00-03:00'))).toBe(false);
    expect(kitOfrecido('kit-digital', new Date('2026-11-16T10:00:00-03:00'))).toBe(true);
  });

  it('antes del plazo deja pasar todo', () => {
    vi.useFakeTimers({ toFake: ['Date'] });
    vi.setSystemTime(new Date('2026-11-10T12:00:00-03:00'));
    expect(correr(exigirPlazoKitImpreso, { kitId: 'kit-clasico' }).siguio).toBe(true);
    expect(correr(exigirPlazoMejoraImpreso, {}).siguio).toBe(true);
  });

  it('después del plazo frena el Kit Impreso (también en un carrito) y deja el Solo Digital', () => {
    vi.useFakeTimers({ toFake: ['Date'] });
    vi.setSystemTime(new Date('2026-11-16T09:00:00-03:00'));
    const impreso = correr(exigirPlazoKitImpreso, { kitId: 'kit-clasico' });
    expect(impreso.siguio).toBe(false);
    expect(impreso.res.codigo).toBe(410);
    expect(impreso.res.cuerpo.error).toMatch(/15 de noviembre/);
    expect(correr(exigirPlazoKitImpreso, { items: [{ kitId: 'kit-digital' }, { kitId: 'kit-clasico' }] }).siguio).toBe(false);
    expect(correr(exigirPlazoKitImpreso, { kitId: 'kit-digital' }).siguio).toBe(true);
    expect(correr(exigirPlazoKitImpreso, { items: [{ kitId: 'kit-digital' }] }).siguio).toBe(true);
    expect(correr(exigirPlazoMejoraImpreso, {}).siguio).toBe(false);
  });
});
