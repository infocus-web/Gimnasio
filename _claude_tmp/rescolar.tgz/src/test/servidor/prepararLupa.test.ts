// 25/10/2026: copias de la lupa preparadas de antemano (botón del panel + tarea cada 15 minutos).
import { readFileSync } from 'fs';
import path from 'path';
import { describe, expect, it } from 'vitest';
import { fuenteServidor } from '../fuenteServidor';
import { COPIAS_VALIDAS_DESDE } from '../../../servidor/panel/prepararLupa';

describe('preparar lupa', () => {
  const server = fuenteServidor();
  it('el botón exige admin y la tarea automática exige el secreto de cron', () => {
    expect(server).toContain("app.post('/api/admin/fotos/preparar-lupa', requireAdminAuth");
    expect(server).toMatch(/app\.all\('\/api\/cron\/preparar-lupa'[\s\S]{0,120}autorizarTareaProgramada\(req\)/);
  });
  it('usa la misma copia que la lupa (1600 px, al lado del original) y rehace las de 800 px de antes del 17/10', () => {
    expect(server).toContain('armarCopiaLupa(Buffer.from(await archivo.arrayBuffer()))');
    expect(server).toContain('upload(rutaCopiaLupa(ruta), data');
    expect(COPIAS_VALIDAS_DESDE).toBe(Date.parse('2026-10-18T00:00:00-03:00'));
  });
  it('Vercel la corre cada 15 minutos', () => {
    const vercel = JSON.parse(readFileSync(path.resolve(__dirname, '../../../vercel.json'), 'utf8'));
    expect(vercel.crons).toContainEqual({ path: '/api/cron/preparar-lupa', schedule: '*/15 * * * *' });
  });
});
