import { describe, expect, it } from 'vitest';
import { numeroDeFoto } from '../utils/numeroFoto';

// 25/10/2026: número visible de la foto en la galería («N° 3486») y en «Cambiar fotos».
describe('numeroDeFoto', () => {
  it('saca el número del nombre del archivo', () => {
    expect(numeroDeFoto('FOTO-3486.jpg')).toBe('3486');
    expect(numeroDeFoto('FOTO-853.JPG')).toBe('853');
    expect(numeroDeFoto('FOTO-3486__rostro.jpg')).toBe('3486');
    expect(numeroDeFoto('DSC_0042.jpg')).toBe('42');
  });
  it('sin número o sin nombre: null', () => {
    expect(numeroDeFoto('grupal.jpg')).toBeNull();
    expect(numeroDeFoto(null)).toBeNull();
    expect(numeroDeFoto(undefined)).toBeNull();
  });
});
