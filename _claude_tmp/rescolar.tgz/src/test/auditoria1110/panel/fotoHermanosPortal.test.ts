// 14/10/2026 (pedido de Pablo): la familia se anota (o se baja) de la foto de hermanos desde el portal, en
// cualquier momento, con su llave de galería. Corre la ruta REAL sobre la base falsa.
import crypto from 'crypto';
import { afterAll, beforeAll, beforeEach, describe, expect, it, vi } from 'vitest';
import { estado, reiniciar } from './falsoSupabase';
import { montar, type Montado } from './servidorPrueba';

vi.mock('dotenv', () => {
  const config = () => ({ parsed: {} });
  return { default: { config }, config };
});
vi.mock('@supabase/supabase-js', async () => {
  const m = await import('./falsoSupabase');
  return { createClient: () => m.clienteFalso() };
});
vi.mock('resend', async () => {
  const m = await import('./falsoSupabase');
  return { Resend: m.resendFalso() };
});

const ID = '11111111-1111-4111-8111-111111111111';
const SIN_HERMANOS = '22222222-2222-4222-8222-222222222222';
const llave = (id: string) => crypto.createHmac('sha256', 'secreto-pedidos').update(`acceso-galeria:${id}`).digest('base64url').slice(0, 32);
const fila = (id: string) => (estado.tablas.inscripciones || []).find((i: any) => i.id === id);

let srv: Montado;
const entornoAntes: Record<string, string | undefined> = {};
const anotar = (cuerpo: any) => srv.pedir('POST', '/api/familia/foto-hermanos', cuerpo);

beforeAll(async () => {
  for (const n of ['SUPABASE_SERVICE_ROLE_KEY', 'ADMIN_SESSION_SECRET', 'PEDIDOS_ACCESO_SECRET']) entornoAntes[n] = process.env[n];
  process.env.SUPABASE_SERVICE_ROLE_KEY = 'prueba';
  process.env.ADMIN_SESSION_SECRET = 'secreto-de-prueba';
  process.env.PEDIDOS_ACCESO_SECRET = 'secreto-pedidos';
  const { rutasFotoHermanos } = await import('../../../../servidor/familias/fotoHermanos');
  srv = await montar([rutasFotoHermanos]);
}, 120_000);

afterAll(async () => {
  await srv.cerrar();
  for (const [n, v] of Object.entries(entornoAntes)) {
    if (v === undefined) delete process.env[n];
    else process.env[n] = v;
  }
});

beforeEach(() => {
  reiniciar();
  estado.tablas.inscripciones = [
    { id: ID, estado: 'aceptado', acceso_confirmado_at: '2026-10-01T00:00:00Z', alumno_nombre: 'Franco', alumno_apellido: 'Marconcini', hermanos: [{ alumnoNombre: 'Sofia', alumnoApellido: 'Marconcini' }], solicita_foto_hermanos: false, foto_hermanos_confirmada_at: '2026-10-14T14:59:15Z', foto_hermanos_email: null, foto_hermanos_whatsapp: null },
    { id: SIN_HERMANOS, estado: 'aceptado', acceso_confirmado_at: '2026-10-01T00:00:00Z', alumno_nombre: 'Ana', alumno_apellido: 'Paz', hermanos: [], solicita_foto_hermanos: false, foto_hermanos_confirmada_at: null },
  ];
});

describe('POST /api/familia/foto-hermanos', () => {
  it('se anota con email y WhatsApp aunque antes haya dicho que no', async () => {
    const r = await anotar({ familia: ID, acceso: llave(ID), quiere: true, email: 'Laura@Mail.com ', whatsapp: '11 5833-4685' });
    expect(r.status).toBe(200);
    expect(fila(ID)).toMatchObject({ solicita_foto_hermanos: true, foto_hermanos_email: 'laura@mail.com', foto_hermanos_whatsapp: '11 5833-4685' });
    expect(fila(ID).foto_hermanos_confirmada_at).not.toBe('2026-10-14T14:59:15Z');
  });

  it('se baja y se borran los datos de contacto', async () => {
    await anotar({ familia: ID, acceso: llave(ID), quiere: true, email: 'laura@mail.com', whatsapp: '1158334685' });
    const r = await anotar({ familia: ID, acceso: llave(ID), quiere: false });
    expect(r.status).toBe(200);
    expect(fila(ID)).toMatchObject({ solicita_foto_hermanos: false, foto_hermanos_email: null, foto_hermanos_whatsapp: null });
  });

  it('sin la llave de la familia no cambia nada', async () => {
    const r = await anotar({ familia: ID, acceso: 'otra-llave-cualquiera-de-32-letras', quiere: true, email: 'a@b.com', whatsapp: '1158334685' });
    expect(r.status).toBe(403);
    expect(fila(ID).solicita_foto_hermanos).toBe(false);
  });

  it('pide email y WhatsApp válidos, y una familia sin hermanos no se puede anotar', async () => {
    expect((await anotar({ familia: ID, acceso: llave(ID), quiere: true, email: 'no-es-email', whatsapp: '1158334685' })).status).toBe(400);
    expect((await anotar({ familia: ID, acceso: llave(ID), quiere: true, email: 'a@b.com', whatsapp: '12' })).status).toBe(400);
    expect((await anotar({ familia: SIN_HERMANOS, acceso: llave(SIN_HERMANOS), quiere: true, email: 'a@b.com', whatsapp: '1158334685' })).status).toBe(409);
  });
});
