// 14/10/2026 (Pablo: ningún dato que deba estar en Supabase puede vivir sólo en el navegador): al registrar cada
// foto se guarda el nombre y el tamaño del archivo original, y el panel los recibe para no volver a subirlos.
// Ruta REAL sobre la base falsa.
import { afterAll, beforeAll, beforeEach, describe, expect, it, vi } from 'vitest';
import { estado, reiniciar } from './falsoSupabase';
import { montar, type Montado } from './servidorPrueba';

vi.mock('dotenv', () => {
  const config = () => ({ parsed: {} });
  return { default: { config }, config };
});
vi.mock('@supabase/supabase-js', async () => {
  const m = await import('./falsoSupabase');
  return { createClient: () => m.clienteFalso() };
});
vi.mock('resend', async () => {
  const m = await import('./falsoSupabase');
  return { Resend: m.resendFalso() };
});

const COLEGIO = '11111111-1111-4111-8111-111111111111';
let srv: Montado;
let token = '';
const entornoAntes: Record<string, string | undefined> = {};
const foto = (n: number, extra: Record<string, unknown> = {}) => ({
  colegioId: COLEGIO, categoria: 'individual', grado: '4° grado', turno: 'Tarde', division: 'C',
  storagePathHD: `2026/col/GRADO4-CTT/originales/IMG_${n}.jpg`, storagePathWeb: `2026/col/GRADO4-CTT/muestras/IMG_${n}.jpg`, ...extra,
});

beforeAll(async () => {
  for (const n of ['SUPABASE_SERVICE_ROLE_KEY', 'ADMIN_SESSION_SECRET']) entornoAntes[n] = process.env[n];
  process.env.SUPABASE_SERVICE_ROLE_KEY = 'prueba';
  process.env.ADMIN_SESSION_SECRET = 'secreto-de-prueba';
  const { rutasFotosPanel } = await import('../../../../servidor/panel/fotos');
  const { generateAdminToken } = await import('../../../../servidor/nucleo/auth');
  token = generateAdminToken() || '';
  srv = await montar([rutasFotosPanel]);
}, 120_000);

afterAll(async () => {
  await srv.cerrar();
  for (const [n, v] of Object.entries(entornoAntes)) {
    if (v === undefined) delete process.env[n];
    else process.env[n] = v;
  }
});

beforeEach(() => {
  reiniciar();
  estado.tablas.colegios = [{ id: COLEGIO, nombre: 'Divino Pastor' }];
  estado.tablas.fotos = [];
});

describe('registro de fotos: archivo original', () => {
  it('guarda nombre y tamaño, y el listado del panel los devuelve', async () => {
    const r = await srv.pedir('POST', '/api/admin/fotos', { fotos: [foto(1, { nombreOriginal: '  IMG_1234.JPG ', bytesOriginal: 5_123_456 })] }, token);
    expect(r.status).toBe(200);
    expect(estado.tablas.fotos[0]).toMatchObject({ nombre_original: 'IMG_1234.JPG', bytes_original: 5_123_456, publicada_at: null });
    const lista = await srv.pedir('GET', `/api/admin/fotos?colegioId=${COLEGIO}&grado=${encodeURIComponent('4° grado')}&turno=Tarde&division=C`, undefined, token);
    expect(lista.json.fotos[0]).toMatchObject({ nombre_original: 'IMG_1234.JPG', bytes_original: 5_123_456 });
  });

  it('sin datos del original (o inválidos) la foto se registra igual, con null', async () => {
    const r = await srv.pedir('POST', '/api/admin/fotos', { fotos: [foto(2), foto(3, { nombreOriginal: '   ', bytesOriginal: -5 })] }, token);
    expect(r.status).toBe(200);
    expect(estado.tablas.fotos).toHaveLength(2);
    for (const f of estado.tablas.fotos) expect(f).toMatchObject({ nombre_original: null, bytes_original: null });
  });
});
