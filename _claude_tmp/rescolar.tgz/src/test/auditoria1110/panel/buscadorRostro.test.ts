// Buscador por reconocimiento facial (24/10/2026, Pablo): la familia sube la cara de su hijo/a, se busca en Rekognition
// (falso acá) y las individuales de OTROS cursos se copian a su curso etiquetadas con el chico: la ve sólo esa familia y
// la puede elegir para el kit. Rutas reales (buscadorRostro + galería + reservas + cierre de año) con la base falsa.
import crypto from 'crypto';
import { afterAll, beforeAll, beforeEach, describe, expect, it, vi } from 'vitest';
import { estado, reiniciar } from './falsoSupabase';
import { montar, type Montado } from './servidorPrueba';

vi.mock('dotenv', () => {
  const config = () => ({ parsed: {} });
  return { default: { config }, config };
});
vi.mock('@supabase/supabase-js', async () => {
  const m = await import('./falsoSupabase');
  return { createClient: () => m.clienteFalso() };
});
vi.mock('resend', async () => {
  const m = await import('./falsoSupabase');
  return { Resend: m.resendFalso() };
});

// Rekognition falso: devuelve como coincidencias los archivos de `aws.coincidencias` (ExternalImageId) y anota cada comando.
const aws = vi.hoisted(() => ({ coincidencias: [] as string[], comandos: [] as { tipo: string; input: any }[], sinCara: false, borrarFalla: false, errorNombre: '' }));
vi.mock('@aws-sdk/client-rekognition', () => {
  class Comando { constructor(public input: any) {} }
  class SearchFacesByImageCommand extends Comando {}
  class DeleteCollectionCommand extends Comando {}
  class RekognitionClient {
    async send(c: any) {
      aws.comandos.push({ tipo: c.constructor.name, input: c.input });
      if (c instanceof SearchFacesByImageCommand) {
        if (aws.errorNombre) throw Object.assign(new Error('falla de AWS'), { name: aws.errorNombre });
        if (aws.sinCara) throw Object.assign(new Error('There are no faces in the image'), { name: 'InvalidParameterException' });
        return { FaceMatches: aws.coincidencias.map((ExternalImageId, i) => ({ Similarity: 99, Face: { FaceId: `cara-${i}`, ExternalImageId } })) };
      }
      if (c instanceof DeleteCollectionCommand && aws.borrarFalla) throw Object.assign(new Error('falla'), { name: 'ThrottlingException' });
      return {};
    }
  }
  return { RekognitionClient, SearchFacesByImageCommand, DeleteCollectionCommand };
});

const COLEGIO = '11111111-1111-4111-8111-111111111111';
const FAMILIA = '33333333-3333-4333-8333-333333333333';
const OTRA = '44444444-4444-4444-8444-444444444444';
const RESERVA = '66666666-6666-4666-8666-666666666666';
const SECRETO = 'secreto-de-prueba';
const ORIGEN = '77777777-7777-4777-8777-777777777777';
const llaveDe = (id: string) => crypto.createHmac('sha256', SECRETO).update(`acceso-galeria:${id}`).digest('base64url').slice(0, 32);
const JPEG = Buffer.concat([Buffer.from([0xff, 0xd8, 0xff, 0xe0]), Buffer.alloc(3000, 7)]).toString('base64');
const entornoAntes: Record<string, string | undefined> = {};
let srv: Montado;
let token = '';
let curso = '';
let otroCurso = '';
let versionTerminos = '';
let llavePedido: (ref: string) => string;
let limpiarCache: () => void;

beforeAll(async () => {
  for (const n of ['SUPABASE_SERVICE_ROLE_KEY', 'ADMIN_SESSION_SECRET', 'AWS_REKOGNITION_ACCESS_KEY_ID', 'AWS_REKOGNITION_SECRET_ACCESS_KEY', 'REKOGNITION_COLEGIOS']) entornoAntes[n] = process.env[n];
  process.env.SUPABASE_SERVICE_ROLE_KEY = 'prueba';
  process.env.ADMIN_SESSION_SECRET = SECRETO;
  process.env.AWS_REKOGNITION_ACCESS_KEY_ID = 'AKIAPRUEBA';
  process.env.AWS_REKOGNITION_SECRET_ACCESS_KEY = 'secreto-aws-prueba';
  process.env.REKOGNITION_COLEGIOS = '11111111-1111-4111-8111-111111111111';
  const { rutasBuscadorRostro } = await import('../../../../servidor/familias/buscadorRostro');
  const { rutasGaleria } = await import('../../../../servidor/familias/galeria');
  const { rutasReservas } = await import('../../../../servidor/pagos/crearPedido');
  const { rutasCierreTemporada } = await import('../../../../servidor/panel/cierreTemporada');
  const { generateAdminToken } = await import('../../../../servidor/nucleo/auth');
  const { determinarCodigoCursoServidor } = await import('../../../../servidor/nucleo/codigosCurso');
  const { VERSION_TERMINOS_SERVIDOR } = await import('../../../../servidor/nucleo/legal');
  const { tokenAccesoPedido } = await import('../../../../servidor/nucleo/accesoPedidos');
  token = generateAdminToken() || '';
  limpiarCache = (await import('../../../../servidor/nucleo/rostros')).limpiarCacheBuscadorRostro;
  curso = determinarCodigoCursoServidor('Sala 5 años', 'Tarde', 'C');
  otroCurso = determinarCodigoCursoServidor('2° grado', 'Tarde', 'B');
  versionTerminos = VERSION_TERMINOS_SERVIDOR;
  llavePedido = (ref) => tokenAccesoPedido(ref) as string;
  srv = await montar([rutasBuscadorRostro, rutasGaleria, rutasReservas, rutasCierreTemporada]);
}, 120_000);

afterAll(async () => {
  await srv.cerrar();
  for (const [n, v] of Object.entries(entornoAntes)) {
    if (v === undefined) delete process.env[n];
    else process.env[n] = v;
  }
});

beforeEach(() => {
  reiniciar();
  aws.coincidencias = ['FOTO-2600.jpg', 'FOTO-2601.jpg', 'FOTO-9999.jpg'];
  process.env.REKOGNITION_COLEGIOS = COLEGIO;
  aws.comandos = [];
  aws.sinCara = false;
  aws.borrarFalla = false;
  aws.errorNombre = '';
  limpiarCache();
  const pub = new Date(Date.now() - 3600_000).toISOString();
  estado.tablas.codigos_seccion = [
    { id: 's1', colegio_id: COLEGIO, grado: 'Sala 5 años', turno: 'Tarde', division: 'C', codigo_secreto: 'SA5C-0001' },
    { id: 's2', colegio_id: COLEGIO, grado: '2° grado', turno: 'Tarde', division: 'B', codigo_secreto: 'DOB2-0002' },
  ];
  estado.tablas.colegios = [{ id: COLEGIO, nombre: 'Colegio de prueba', muestras_lupa: false }];
  estado.tablas.inscripciones = [
    { id: FAMILIA, colegio_id: COLEGIO, estado: 'aceptado', acceso_confirmado_at: pub, alumno_nombre: 'Lola', alumno_apellido: 'Paz', grado: 'Sala 5 años', turno: 'Tarde', division: 'C', hermanos: [] },
    { id: OTRA, colegio_id: COLEGIO, estado: 'aceptado', acceso_confirmado_at: pub, alumno_nombre: 'Juan', alumno_apellido: 'Sol', grado: 'Sala 5 años', turno: 'Tarde', division: 'C', hermanos: [] },
  ];
  const foto = (id: string, codigo: string, nombre: string, extra: Record<string, unknown> = {}) => ({
    id, colegio_id: COLEGIO, codigo_curso: codigo, categoria: 'individual', alumno_nombre: null, publicada_at: pub, nombre_original: nombre, bytes_original: 2000,
    grado: null, division: null, storage_path: `2026/${codigo}/originales/${id}.jpg`,
    preview_path: `https://x.supabase.co/storage/v1/object/public/fotos-web/2026/${codigo}/muestras/${id}.jpg?v=1`,
    thumb_path: `https://x.supabase.co/storage/v1/object/public/fotos-web/2026/${codigo}/miniaturas/${id}.jpg?v=1`, created_at: pub, ...extra,
  });
  estado.tablas.fotos = [
    foto(ORIGEN, otroCurso, 'FOTO-2600.jpg'), // la de Lola quedó en 2°B
    foto('88888888-8888-4888-8888-888888888888', curso, 'FOTO-2601__copia-desde-2B_TARDE.jpg'), // ya estaba copiada a su curso
    foto('99999999-9999-4999-8999-999999999999', otroCurso, 'FOTO-26.jpg'), // nombre parecido: no es suya
    foto('aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa', otroCurso, 'FOTO-2602.jpg', { publicada_at: null }), // sin publicar
    foto('bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb', curso, 'FOTO-3000.jpg', { categoria: 'grupal' }),
    foto('cccccccc-cccc-4ccc-8ccc-cccccccccccc', otroCurso, 'FOTO-9999.jpg', { colegio_id: 'otro-colegio' }), // otro colegio: nunca
  ];
  estado.tablas.pedidos = [{ id: RESERVA, familia_id: null, colegio_id: COLEGIO, curso_codigo: curso, alumno_nombre: 'Lola Paz', seleccion_pendiente: true, estado: 'pagado', cancelado_definitivo: false, archivado: false, total: 30000, tipo_kit: 'impreso_digital', grupo_pago_id: null, email_enviado: true }];
});

const base = { codigo: 'SA5C-0001', familia: FAMILIA, acceso: llaveDe(FAMILIA), alumnoNombre: 'Lola Paz', imagen: JPEG, consentimiento: true };
const buscar = (extra: Record<string, unknown> = {}) => srv.pedir('POST', '/api/fotos/buscar-rostro', { ...base, ...extra });
const copias = () => (estado.tablas.fotos || []).filter((f) => String(f.nombre_original || '').endsWith('__rostro.jpg'));
const galeria = (familia?: string) =>
  srv.pedir('GET', `/api/fotos?codigo=SA5C-0001${familia ? `&familia=${familia}&acceso=${llaveDe(familia)}` : ''}`);

describe('Buscador por rostro: familia', () => {
  it('sin consentimiento, sin imagen válida o sin la llave de la familia no busca', async () => {
    expect((await buscar({ consentimiento: false })).status).toBe(400);
    expect((await buscar({ imagen: 'no-es-una-foto' })).status).toBe(400);
    expect((await buscar({ imagen: Buffer.from('GIF89a' + 'x'.repeat(2000)).toString('base64') })).status).toBe(400);
    expect((await buscar({ acceso: 'otra-llave' })).status).toBe(403);
    expect((await buscar({ alumnoNombre: 'Otro Chico' })).status).toBe(403);
    expect((await buscar({ codigo: 'DOB2-0002' })).status).toBe(403); // la llave es de Sala 5 C, no de 2° B
    expect(aws.comandos).toHaveLength(0);
  });

  it('copia la foto de otro curso etiquetada con el chico; lo que ya está en su curso, de otro colegio o sin publicar no', async () => {
    const r = await buscar();
    expect(r.status).toBe(200);
    expect(r.json).toMatchObject({ success: true, nuevas: 1, yaEnGaleria: 1 });
    expect(aws.comandos[0]).toMatchObject({ tipo: 'SearchFacesByImageCommand', input: { CollectionId: 'divino-pastor-2026-buscador', FaceMatchThreshold: 97 } });
    expect(copias()).toHaveLength(1);
    expect(copias()[0]).toMatchObject({ codigo_curso: curso, categoria: 'individual', alumno_nombre: 'Lola Paz', grado: 'Sala 5 años', turno: 'Tarde', division: 'C', nombre_original: 'FOTO-2600__rostro.jpg' });
    expect(copias()[0].publicada_at).toBeTruthy();
    // Archivos propios (otro path): borrar una no borra la otra. Original HD, muestra y miniatura.
    expect(estado.storage.copiados.map((c) => [c.bucket, c.desde])).toEqual([
      ['fotos-hd', `2026/${otroCurso}/originales/${ORIGEN}.jpg`],
      ['fotos-web', `2026/${otroCurso}/muestras/${ORIGEN}.jpg`],
      ['fotos-web', `2026/${otroCurso}/miniaturas/${ORIGEN}.jpg`],
    ]);
    expect(copias()[0].storage_path).toMatch(new RegExp(`^2026/rostro/${curso}/originales/`));
    expect(estado.tablas.rostros_hallazgos).toHaveLength(1);
    expect(estado.tablas.rostros_busquedas).toHaveLength(1);
    expect(estado.tablas.rostros_busquedas[0]).toMatchObject({ inscripcion_id: FAMILIA, alumno_nombre: 'Lola Paz', fotos_nuevas: 1, fotos_ya_en_galeria: 1, resultado: 'ok' });
    expect(JSON.stringify(estado.tablas.rostros_busquedas)).not.toContain(JPEG.slice(0, 40)); // la imagen no se guarda
  });

  it('repetir la búsqueda no duplica la copia', async () => {
    await buscar();
    const r = await buscar();
    expect(r.json).toMatchObject({ nuevas: 0, yaEnGaleria: 2 });
    expect(copias()).toHaveLength(1);
  });

  it('la copia la ve sólo esa familia (ni el resto del curso ni sin llave) y la puede elegir para su kit', async () => {
    await buscar();
    const id = copias()[0].id;
    expect((await galeria(FAMILIA)).json.fotos.map((f: any) => f.id)).toContain(id);
    expect((await galeria(OTRA)).json.fotos.map((f: any) => f.id)).not.toContain(id);
    expect((await galeria()).json.fotos.map((f: any) => f.id)).not.toContain(id);
    const grupal = 'bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb';
    const r = await srv.pedir('POST', `/api/reservas/${RESERVA}/elegir-fotos`, { codigo: 'SA5C-0001', fotos: { individualId: id, grupalId: grupal }, confirmaPersonalizacion: true, versionTerminos, t: llavePedido(RESERVA) });
    expect(r.status, JSON.stringify(r.json)).toBe(200);
    // Una foto encontrada para OTRO chico (etiquetada con otro nombre) no la puede elegir esta familia.
    estado.tablas.fotos.find((f) => f.id === id).alumno_nombre = 'Juan Sol';
    estado.tablas.pedidos[0].seleccion_pendiente = true;
    const ajena = await srv.pedir('POST', `/api/reservas/${RESERVA}/elegir-fotos`, { codigo: 'SA5C-0001', fotos: { individualId: id, grupalId: grupal }, confirmaPersonalizacion: true, versionTerminos, t: llavePedido(RESERVA) });
    expect(ajena.status).toBe(400);
  });

  it('foto sin cara: 422 y queda registrada; tope de búsquedas por día', async () => {
    aws.sinCara = true;
    const r = await buscar();
    expect(r.status).toBe(422);
    expect(estado.tablas.rostros_busquedas[0].resultado).toBe('sin_cara');
    aws.sinCara = false;
    estado.intentos = {};
    for (let i = 0; i < 5; i++) expect((await buscar()).status).toBe(200);
    expect((await buscar()).status).toBe(429);
  });

  it('sin variables de AWS el buscador responde 503 (no rompe nada)', async () => {
    const antes = process.env.AWS_REKOGNITION_ACCESS_KEY_ID;
    delete process.env.AWS_REKOGNITION_ACCESS_KEY_ID;
    try {
      expect((await buscar()).status).toBe(503);
    } finally {
      process.env.AWS_REKOGNITION_ACCESS_KEY_ID = antes;
    }
  });
});

describe('Buscador por rostro: revisión 24/10', () => {
  it('no copia una foto etiquetada con OTRO chico, ni la cuenta como «ya en tu galería»', async () => {
    estado.tablas.fotos.find((f) => f.id === ORIGEN).alumno_nombre = 'Juan Sol';
    estado.tablas.fotos.find((f) => f.id === '88888888-8888-4888-8888-888888888888').alumno_nombre = 'Juan Sol';
    const r = await buscar();
    expect(r.json).toMatchObject({ success: true, nuevas: 0, yaEnGaleria: 0, sinResultados: true });
    expect(copias()).toHaveLength(0);
  });

  it('una reserva vieja sin copia (se cortó a mitad) se reintenta; si la copia falla se borran los archivos copiados', async () => {
    estado.tablas.rostros_hallazgos = [{ id: 'h-viejo', colegio_id: COLEGIO, inscripcion_id: FAMILIA, alumno_nombre: 'Lola Paz', nombre_base: 'FOTO-2600', foto_copia_id: null, created_at: new Date(Date.now() - 10 * 60_000).toISOString() }];
    estado.fallar = (tabla, op) => tabla === 'fotos' && op === 'insert';
    const r = await buscar();
    expect(r.json).toMatchObject({ success: true, nuevas: 0, yaEnGaleria: 1 }); // la otra foto ya estaba en su curso
    expect(copias()).toHaveLength(0);
    expect(estado.storage.removidos.flatMap((x) => x.rutas)).toHaveLength(3); // HD, muestra y miniatura copiadas, borradas
    expect(estado.tablas.rostros_hallazgos).toEqual([]); // ni la vieja ni la nueva: se puede reintentar
    expect(estado.tablas.rostros_busquedas[0]).toMatchObject({ fotos_nuevas: 0, resultado: 'error' });
    estado.fallar = null;
    expect((await buscar()).json.nuevas).toBe(1);
    expect(estado.tablas.rostros_busquedas[1].fotos_nuevas).toBe(1);
  });

  it('el botón y la búsqueda sólo existen en los colegios con buscador', async () => {
    expect((await srv.pedir('GET', '/api/fotos/buscador-rostro?codigo=SA5C-0001')).json.disponible).toBe(true);
    expect((await srv.pedir('GET', '/api/fotos/buscador-rostro?codigo=NO-EXISTE')).json.disponible).toBe(false);
    process.env.REKOGNITION_COLEGIOS = 'otro-colegio';
    expect((await srv.pedir('GET', '/api/fotos/buscador-rostro?codigo=SA5C-0001')).json.disponible).toBe(false);
    expect((await buscar()).status).toBe(503);
    expect(aws.comandos).toHaveLength(0);
  });
});

describe('Buscador por rostro: auditoría 25/10', () => {
  it('con el curso de la familia sin fotos publicadas no muestra el botón ni gasta cupo', async () => {
    estado.intentos = {}; // cupo real de búsquedas
    for (const f of estado.tablas.fotos) if (f.codigo_curso === curso) f.publicada_at = null;
    expect((await srv.pedir('GET', '/api/fotos/buscador-rostro?codigo=SA5C-0001')).json.disponible).toBe(false);
    expect((await buscar()).status).toBe(409);
    expect(aws.comandos).toHaveLength(0);
    expect(Object.keys(estado.intentos || {}).filter((k) => k.includes('buscar-rostro'))).toEqual([]); // no gastó cupo
    expect(copias()).toHaveLength(0);
    // Al publicar el curso, el cupo está entero.
    for (const f of estado.tablas.fotos) if (f.codigo_curso === curso) f.publicada_at = new Date().toISOString();
    expect((await srv.pedir('GET', '/api/fotos/buscador-rostro?codigo=SA5C-0001')).json.disponible).toBe(true);
    expect((await buscar()).status).toBe(200);
  });

  it('un error de AWS nuestro (colección borrada) responde 503 y queda registrado como error', async () => {
    aws.errorNombre = 'ResourceNotFoundException';
    const r = await buscar();
    expect(r.status).toBe(503);
    expect(r.json.error).toMatch(/no está disponible/);
    expect(estado.tablas.rostros_busquedas[0].resultado).toBe('error');
    aws.errorNombre = 'ImageTooLargeException';
    expect((await buscar()).status).toBe(422);
  });
});

describe('Buscador por rostro: panel y cierre de año', () => {
  it('el panel lista las búsquedas sólo con sesión de admin', async () => {
    await buscar();
    expect((await srv.pedir('GET', `/api/admin/rostros/busquedas?colegioId=${COLEGIO}`)).status).toBe(401);
    const r = await srv.pedir('GET', `/api/admin/rostros/busquedas?colegioId=${COLEGIO}`, undefined, token);
    expect(r.status).toBe(200);
    expect(r.json.busquedas).toHaveLength(1);
    expect(r.json.configurado).toBe(true);
    expect(r.json.busquedas[0].copias).toEqual([{ nombre: 'FOTO-2600', cursoOrigen: otroCurso, copiaId: copias()[0].id }]);
  });

  it('cerrar el año de un colegio con buscador borra su colección en AWS y sus búsquedas; otro colegio no la toca', async () => {
    await buscar();
    const { borrarRostrosDelColegio } = await import('../../../../servidor/familias/buscadorRostro');
    const { getServerSupabase } = await import('../../../../servidor/nucleo/clientes');
    expect(await borrarRostrosDelColegio(getServerSupabase() as any, 'otro-colegio')).toBeNull();
    expect(aws.comandos.some((c) => c.tipo === 'DeleteCollectionCommand')).toBe(false);
    expect(estado.tablas.rostros_busquedas).toHaveLength(1);
    expect(await borrarRostrosDelColegio(getServerSupabase() as any, COLEGIO)).toBeNull();
    expect(aws.comandos.find((c) => c.tipo === 'DeleteCollectionCommand')?.input).toEqual({ CollectionId: 'divino-pastor-2026-buscador' });
    expect(estado.tablas.rostros_hallazgos).toEqual([]);
    expect(estado.tablas.rostros_busquedas).toEqual([]);
  });

  it('si AWS falla al borrar avisa (para reintentar); sin la tabla, no rompe el cierre', async () => {
    aws.borrarFalla = true;
    const { borrarRostrosDelColegio } = await import('../../../../servidor/familias/buscadorRostro');
    const { getServerSupabase } = await import('../../../../servidor/nucleo/clientes');
    expect(await borrarRostrosDelColegio(getServerSupabase() as any, COLEGIO)).toMatch(/no se pudo borrar la colección/);
    aws.borrarFalla = false;
    estado.fallar = (tabla) => (tabla.startsWith('rostros_') ? 'PGRST205' : false);
    expect(await borrarRostrosDelColegio(getServerSupabase() as any, COLEGIO)).toBeNull();
  });
});

describe('Textos', () => {
  it('nombreBase reconoce originales y copias, y rechaza nombres raros', async () => {
    const { nombreBase } = await import('../../../../servidor/familias/buscadorRostro');
    expect(nombreBase('FOTO-2600.jpg')).toBe('FOTO-2600');
    expect(nombreBase('foto-2600.JPG')).toBe('FOTO-2600');
    expect(nombreBase('FOTO-2600__copia-desde-2B_TARDE.jpg')).toBe('FOTO-2600');
    expect(nombreBase('FOTO-2600__rostro.jpg')).toBe('FOTO-2600');
    expect(nombreBase('a,b.jpg')).toBeNull();
    expect(nombreBase('x).or(id.neq.0')).toBeNull();
  });

  it('el mail y la pantalla dicen lo mismo sobre privacidad; la política ya no dice «no usamos reconocimiento facial»', async () => {
    const { bloqueBuscadorRostro } = await import('../../../../servidor/entrega/correos');
    const BLOQUE_BUSCADOR_ROSTRO = bloqueBuscadorRostro(); // 30/10: se arma al mandar el mail (fecha del panel → Configuración)
    const { TEXTO_PRIVACIDAD_ROSTRO } = await import('../../../components/BuscadorRostro');
    const { PRIVACIDAD } = await import('../../../legal/textosLegales');
    expect(BLOQUE_BUSCADOR_ROSTRO).toContain(TEXTO_PRIVACIDAD_ROSTRO);
    expect(BLOQUE_BUSCADOR_ROSTRO).toContain('Mi hijo/a no tiene esta foto');
    expect(BLOQUE_BUSCADOR_ROSTRO).toContain('hasta el 15/11 inclusive');
    const politica = JSON.stringify(PRIVACIDAD);
    expect(politica).not.toContain('No usamos las fotos para reconocimiento facial');
    expect(politica).toContain('Amazon Web Services');
  });
});
