// Auditoría 11/10 (panel): base y Storage falsos en memoria para montar las rutas reales de Express
// sin red. Mismo patrón que src/test/servidor/transferenciasVencimiento.test.ts, con algo más de
// PostgREST (delete, upsert, not, ilike, count, or registrado) y fallas a pedido (`estado.fallar`).
export type Operacion = 'select' | 'update' | 'insert' | 'upsert' | 'delete';

export const estado = {
  tablas: {} as Record<string, any[]>,
  /** Devuelve un error para esa consulta (tabla, operación y columnas pedidas). 14/10/2026: si devuelve un
   *  string, se usa como código del error (p. ej. '42P01' = tabla inexistente). */
  fallar: null as null | ((tabla: string, op: Operacion, columnas: string) => boolean | string),
  storage: { removidos: [] as { bucket: string; rutas: string[] }[], archivos: {} as Record<string, string[]>, alListar: null as null | (() => void), copiados: [] as { bucket: string; desde: string; hacia: string }[] },
  /** 14/10: si no es null, `registrar_intento` cuenta de verdad (para probar cupos); null = nunca limita. */
  intentos: null as null | Record<string, number>,
  mails: [] as { to: string[]; subject: string; html: string; clave?: string }[],
  /** 14/10: Resend falso con claves de idempotencia (descarta un segundo envío con la misma clave) y fallas a pedido. */
  resend: { claves: new Set<string>(), fallar: null as null | ((datos: any) => boolean), lotes: [] as { to: string[]; subject: string; clave?: string }[][], rechazar: null as null | ((datos: any) => boolean) },
  orRecibidos: [] as string[],
  /** Tope de filas por respuesta ("Max Rows" de PostgREST). */
  maxFilas: Infinity,
  /** Órdenes pedidos por consulta: `tabla: campo1,campo2`. */
  ordenes: [] as string[],
};

export function reiniciar() {
  estado.tablas = {};
  estado.fallar = null;
  estado.storage = { removidos: [], archivos: {}, alListar: null, copiados: [] };
  estado.intentos = null;
  estado.mails = [];
  estado.resend = { claves: new Set<string>(), fallar: null, lotes: [], rechazar: null };
  estado.orRecibidos = [];
  estado.maxFilas = Infinity;
  estado.ordenes = [];
}

const valor = (fila: any, campo: string) => {
  if (campo.includes('->>')) {
    const [c, k] = campo.split('->>');
    return fila[c]?.[k] ?? null;
  }
  return fila[campo] ?? null;
};
const comparar = (a: any, b: any) => {
  if (typeof a === 'number' && typeof b === 'number') return a - b;
  const fa = Date.parse(a);
  const fb = Date.parse(b);
  if (typeof a === 'string' && typeof b === 'string' && /^\d{4}-/.test(a) && Number.isFinite(fa) && Number.isFinite(fb)) return fa - fb;
  return String(a).localeCompare(String(b));
};
const comoRegex = (patron: string) => new RegExp(`^${patron.replace(/[.*+?^${}()|[\]\\]/g, '\\$&').replace(/%/g, '.*').replace(/_/g, '.')}$`, 'i');

export function consulta(tabla: string) {
  const filtros: Array<(f: any) => boolean> = [];
  let op: Operacion = 'select';
  let columnas = '';
  let cambios: Record<string, any> | null = null;
  let nuevas: any[] | null = null;
  let opcionesUpsert: any = null;
  let unica = false;
  let soloConteo = false;
  let conConteo = false;
  let rango: [number, number] | null = null;
  let limite = Infinity;
  let devolverFilas = false;
  const ordenes: { campo: string; asc: boolean }[] = [];
  const q: any = {
    select: (c?: string, o?: { count?: string; head?: boolean }) => {
      columnas = c || '*';
      if (op !== 'select') devolverFilas = true;
      if (o?.count) conConteo = true;
      if (o?.head) soloConteo = true;
      return q;
    },
    eq: (c: string, v: any) => (filtros.push((f) => valor(f, c) === v), q),
    neq: (c: string, v: any) => (filtros.push((f) => valor(f, c) !== v), q),
    is: (c: string, v: any) => (filtros.push((f) => valor(f, c) === v), q),
    not: (c: string, o: string, v: any) => {
      if (o === 'is') filtros.push((f) => valor(f, c) !== v);
      else if (o === 'in') {
        const lista = String(v).replace(/[()]/g, '').split(',');
        filtros.push((f) => !lista.includes(String(valor(f, c))));
      }
      return q;
    },
    in: (c: string, vs: any[]) => (filtros.push((f) => vs.includes(valor(f, c))), q),
    gt: (c: string, v: any) => (filtros.push((f) => valor(f, c) !== null && comparar(valor(f, c), v) > 0), q),
    gte: (c: string, v: any) => (filtros.push((f) => valor(f, c) !== null && comparar(valor(f, c), v) >= 0), q),
    lt: (c: string, v: any) => (filtros.push((f) => valor(f, c) !== null && comparar(valor(f, c), v) < 0), q),
    lte: (c: string, v: any) => (filtros.push((f) => valor(f, c) !== null && comparar(valor(f, c), v) <= 0), q),
    ilike: (c: string, p: string) => (filtros.push((f) => comoRegex(p).test(String(valor(f, c) ?? ''))), q),
    // .filter(c, 'imatch', regex) (19/10, ficha del cliente: teléfonos).
    filter: (c: string, o: string, v: string) => (o === 'imatch' && filtros.push((f) => new RegExp(v, 'i').test(String(valor(f, c) ?? ''))), q),
    // .or(): se registra el texto (no se evalúa).
    or: (texto: string) => (estado.orRecibidos.push(texto), q),
    order: (campo: string, o?: { ascending?: boolean }) => (ordenes.push({ campo, asc: o?.ascending !== false }), q),
    range: (d: number, h: number) => ((rango = [d, h]), q),
    limit: (n: number) => ((limite = n), q),
    abortSignal: () => q,
    update: (c: Record<string, any>) => ((op = 'update'), (cambios = c), q),
    insert: (f: any) => ((op = 'insert'), (nuevas = Array.isArray(f) ? f : [f]), q),
    upsert: (f: any, o?: any) => ((op = 'upsert'), (nuevas = Array.isArray(f) ? f : [f]), (opcionesUpsert = o || {}), q),
    delete: () => ((op = 'delete'), q),
    maybeSingle: () => ((unica = true), q),
    single: () => ((unica = true), q),
    then: (ok: any, mal: any) => Promise.resolve(ejecutar()).then(ok, mal),
  };
  function ejecutar() {
    const falla = estado.fallar ? estado.fallar(tabla, op, columnas) : false;
    if (falla) {
      return { data: null, count: null, error: { message: `falla simulada en ${tabla} (${op})`, code: typeof falla === 'string' ? falla : 'XX000' } };
    }
    const filas = (estado.tablas[tabla] = estado.tablas[tabla] || []);
    if (ordenes.length) estado.ordenes.push(`${tabla}: ${ordenes.map((o) => o.campo).join(',')}`);
    if (nuevas) {
      const creadas: any[] = [];
      for (const n of nuevas) {
        const clave: string | null = opcionesUpsert?.onConflict || (op === 'upsert' ? 'id' : null);
        const campos = clave ? clave.split(',').map((c) => c.trim()) : [];
        const existente = clave ? filas.find((f) => campos.every((c) => f[c] !== undefined && f[c] === n[c])) : null;
        if (existente) {
          if (!opcionesUpsert?.ignoreDuplicates) Object.assign(existente, n);
          continue;
        }
        const fila = { id: n.id ?? `${tabla}-${filas.length + 1}-${Math.random().toString(36).slice(2, 7)}`, created_at: new Date().toISOString(), ...n };
        filas.push(fila);
        creadas.push(fila);
      }
      const copia = JSON.parse(JSON.stringify(creadas));
      return { data: unica ? copia[0] ?? null : copia, error: null };
    }
    let elegidas = filas.filter((f) => filtros.every((fn) => fn(f)));
    if (op === 'delete') {
      estado.tablas[tabla] = filas.filter((f) => !elegidas.includes(f));
      return { data: devolverFilas ? JSON.parse(JSON.stringify(elegidas)) : null, error: null };
    }
    if (cambios) for (const f of elegidas) Object.assign(f, cambios);
    const total = elegidas.length;
    for (const { campo, asc } of [...ordenes].reverse()) {
      elegidas = [...elegidas].sort((a, b) => (asc ? 1 : -1) * comparar(valor(a, campo) ?? '', valor(b, campo) ?? ''));
    }
    if (rango) elegidas = elegidas.slice(rango[0], rango[1] + 1);
    elegidas = elegidas.slice(0, Math.min(limite, estado.maxFilas));
    if (soloConteo) return { data: null, count: total, error: null };
    if (op === 'update' && !devolverFilas) return { data: null, error: null };
    const copia = JSON.parse(JSON.stringify(elegidas));
    return { data: unica ? copia[0] ?? null : copia, count: conConteo ? total : null, error: null };
  }
  return q;
}

export function clienteFalso() {
  return {
    from: (tabla: string) => consulta(tabla),
    rpc: async (nombre: string, args?: any) => {
      if (nombre !== 'registrar_intento') return { data: null, error: null };
      if (!estado.intentos) return { data: 0, error: null };
      const n = (estado.intentos[args.p_clave] = (estado.intentos[args.p_clave] || 0) + 1);
      return { data: n > args.p_max ? 1 : 0, error: null };
    },
    storage: {
      from: (bucket: string) => ({
        remove: async (rutas: string[]) => {
          estado.storage.removidos.push({ bucket, rutas: [...rutas] });
          return { data: rutas.map((name) => ({ name })), error: null };
        },
        list: async (_carpeta: string, o?: { offset?: number }) => (estado.storage.alListar?.(), { data: (estado.storage.archivos[bucket] || []).slice(o?.offset || 0, (o?.offset || 0) + 1000).map((name) => ({ name, id: name, created_at: '2026-01-01T00:00:00Z' })), error: null }),
        download: async () => ({ data: new Blob([Buffer.from('x')]), error: null }),
        upload: async () => ({ data: {}, error: null }),
        // 24/10: copia dentro del bucket (buscador por rostro); se anota en estado.storage.copiados.
        copy: async (desde: string, hacia: string) => (estado.storage.copiados.push({ bucket, desde, hacia }), { data: { path: hacia }, error: null }),
        getPublicUrl: (ruta: string) => ({ data: { publicUrl: `https://x.supabase.co/storage/v1/object/public/${bucket}/${ruta}` } }),
        createSignedUrl: async (ruta: string) => ({ data: { signedUrl: `https://firmada/${bucket}/${ruta}` }, error: null }),
        createSignedUploadUrl: async (ruta: string) => ({ data: { signedUrl: `https://subida/${ruta}`, token: 't', path: ruta }, error: null }),
      }),
    },
  };
}

const claveDe = (opciones: any): string | undefined => opciones?.idempotencyKey || opciones?.headers?.['Idempotency-Key'];

export function resendFalso() {
  return class {
    emails = {
      send: async (datos: any, opciones?: any) => {
        if (estado.resend.fallar?.(datos)) return { data: null, error: { message: 'falla simulada de Resend' } };
        const clave = claveDe(opciones);
        if (clave && estado.resend.claves.has(clave)) return { data: { id: `mail-repetido-${clave}` }, error: null };
        if (clave) estado.resend.claves.add(clave);
        estado.mails.push({ to: datos.to, subject: datos.subject, html: datos.html, clave });
        return { data: { id: `mail-${estado.mails.length}` }, error: null };
      },
    };
    batch = {
      send: async (lista: any[], opciones?: any) => {
        if (lista.some((d) => estado.resend.fallar?.(d))) return { data: null, error: { message: 'falla simulada de Resend (lote)' } };
        const clave = claveDe(opciones);
        if (clave && estado.resend.claves.has(clave)) return { data: { data: [] }, error: null };
        if (clave) estado.resend.claves.add(clave);
        estado.resend.lotes.push(lista.map((d) => ({ to: d.to, subject: d.subject, clave })));
        // batchValidation 'permissive': las direcciones rechazadas vuelven en `errors` con su índice.
        const errors = lista.flatMap((d, index) => (estado.resend.rechazar?.(d) ? [{ index, message: 'rechazado (simulado)' }] : []));
        return { data: { data: lista.map((_, i) => ({ id: `lote-${i}` })), ...(errors.length ? { errors } : {}) }, error: null };
      },
    };
  };
}
