// 27/10/2026: «Sumar hijo» desde Inscriptos (servidor/familias/sumarHijo.ts). Casos reales de esa noche:
// Claudia (sumar a Nicolás, 1° año B sin turno en la nómina) y Carolina (sumar a Belén, 6° año C).
import { afterAll, beforeAll, beforeEach, describe, expect, it, vi } from 'vitest';
import { estado, reiniciar } from './falsoSupabase';
import { montar, type Montado } from './servidorPrueba';

vi.mock('dotenv', () => {
  const config = () => ({ parsed: {} });
  return { default: { config }, config };
});
vi.mock('@supabase/supabase-js', async () => {
  const m = await import('./falsoSupabase');
  return { createClient: () => m.clienteFalso() };
});

const COL = '00000000-0000-4000-8000-000000000900';
const OTRO = '00000000-0000-4000-8000-000000000901';
let srv: Montado;
let token = '';
const entornoAntes: Record<string, string | undefined> = {};

beforeAll(async () => {
  for (const n of ['SUPABASE_SERVICE_ROLE_KEY', 'ADMIN_SESSION_SECRET']) entornoAntes[n] = process.env[n];
  process.env.SUPABASE_SERVICE_ROLE_KEY = 'prueba';
  process.env.ADMIN_SESSION_SECRET = 'secreto-de-prueba';
  const { rutasSumarHijo } = await import('../../../../servidor/familias/sumarHijo');
  const { generateAdminToken } = await import('../../../../servidor/nucleo/auth');
  token = generateAdminToken() || '';
  srv = await montar([rutasSumarHijo]);
}, 120_000);

afterAll(async () => {
  await srv.cerrar();
  for (const [n, v] of Object.entries(entornoAntes)) {
    if (v === undefined) delete process.env[n];
    else process.env[n] = v;
  }
});

const preparar = () => {
  estado.tablas.inscripciones = [
    {
      id: 'ins1', colegio_id: COL, alumno_nombre: 'Maria Eugenia', alumno_apellido: 'Barchuk', grado: '1° grado', division: 'A', turno: 'Tarde',
      hermanos: [], updated_at: '2026-10-25T00:00:00Z',
    },
  ];
  estado.tablas.alumnos = [
    { id: 'a1', colegio_id: COL, nombre: 'BARCHUK YAGUSIECZKO, Nicolas', grado: '1° año', division: 'B', turno: null, dni: null },
    { id: 'a2', colegio_id: COL, nombre: 'BARCHUK YAGUSIECZKO, MARIA EUGENIA', grado: '1° grado', division: 'A', turno: 'Tarde', dni: null },
    { id: 'a3', colegio_id: OTRO, nombre: 'BARCHUK, Pedro', grado: '1° año', division: 'B', turno: 'Mañana', dni: null },
    { id: 'a4', colegio_id: COL, nombre: 'PEREZ, Ana', grado: '3° año', division: 'A', turno: null, dni: null },
  ];
  estado.tablas.codigos_seccion = [
    { colegio_id: COL, grado: '1° año', division: 'B', turno: 'Mañana', codigo_secreto: 'X' },
    { colegio_id: COL, grado: '3° año', division: 'A', turno: 'Mañana', codigo_secreto: 'Y' },
    { colegio_id: COL, grado: '3° año', division: 'A', turno: 'Tarde', codigo_secreto: 'Z' },
  ];
};

beforeEach(() => {
  reiniciar();
  preparar();
});

describe('Sumar hijo a una inscripción', () => {
  it('pide sesión de admin', async () => {
    const r = await srv.pedir('POST', '/api/admin/inscripciones/ins1/hermanos', { alumnoId: 'a1' });
    expect(r.status).toBe(401);
  });

  it('busca sólo en la nómina del mismo colegio y marca al que ya está', async () => {
    const r = await srv.pedir('GET', `/api/admin/inscripciones/ins1/nomina-hijos?q=${encodeURIComponent('barchuk')}`, undefined, token);
    expect(r.status).toBe(200);
    const ids = r.json.alumnos.map((a: any) => a.id).sort();
    expect(ids).toEqual(['a1', 'a2']);
    expect(r.json.alumnos.find((a: any) => a.id === 'a2').yaIncluido).toBe(true);
    expect(r.json.alumnos.find((a: any) => a.id === 'a1').yaIncluido).toBe(false);
  });

  it('suma al hermano con el formato de la inscripción y el turno del código del curso', async () => {
    const r = await srv.pedir('POST', '/api/admin/inscripciones/ins1/hermanos', { alumnoId: 'a1' }, token);
    expect(r.status).toBe(200);
    const h = estado.tablas.inscripciones[0].hermanos;
    expect(h).toHaveLength(1);
    expect(h[0]).toMatchObject({
      grado: '1° año', division: 'B', turno: 'Mañana', colegioId: COL,
      alumnoNombre: 'Nicolas', alumnoApellido: 'Barchuk Yagusieczko', verificadoEnNomina: true,
    });
    // Dos veces el mismo chico: no se duplica.
    const otra = await srv.pedir('POST', '/api/admin/inscripciones/ins1/hermanos', { alumnoId: 'a1' }, token);
    expect(otra.status).toBe(409);
    expect(estado.tablas.inscripciones[0].hermanos).toHaveLength(1);
  });

  it('no suma al chico principal ni a uno de otro colegio', async () => {
    expect((await srv.pedir('POST', '/api/admin/inscripciones/ins1/hermanos', { alumnoId: 'a2' }, token)).status).toBe(409);
    expect((await srv.pedir('POST', '/api/admin/inscripciones/ins1/hermanos', { alumnoId: 'a3' }, token)).status).toBe(400);
    expect(estado.tablas.inscripciones[0].hermanos).toHaveLength(0);
  });

  it('si el curso tiene dos turnos y la nómina no dice cuál, no adivina', async () => {
    const r = await srv.pedir('POST', '/api/admin/inscripciones/ins1/hermanos', { alumnoId: 'a4' }, token);
    expect(r.status).toBe(409);
    expect(r.json.error).toMatch(/más de un turno/);
    expect(estado.tablas.inscripciones[0].hermanos).toHaveLength(0);
  });
});
