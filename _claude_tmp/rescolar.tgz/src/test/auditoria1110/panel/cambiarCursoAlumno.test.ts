// Nómina del panel: cambiar de curso a un alumno mal cargado (13/10/2026). Corre la ruta REAL sobre la base falsa.
import { afterAll, beforeAll, beforeEach, describe, expect, it, vi } from 'vitest';
import { estado, reiniciar } from './falsoSupabase';
import { montar, type Montado } from './servidorPrueba';

vi.mock('dotenv', () => {
  const config = () => ({ parsed: {} });
  return { default: { config }, config };
});
vi.mock('@supabase/supabase-js', async () => {
  const m = await import('./falsoSupabase');
  return { createClient: () => m.clienteFalso() };
});
vi.mock('resend', async () => {
  const m = await import('./falsoSupabase');
  return { Resend: m.resendFalso() };
});

let srv: Montado;
let token = '';
const entornoAntes: Record<string, string | undefined> = {};
const alumno = (id: string) => (estado.tablas.alumnos || []).find((a: any) => a.id === id);
const mover = (id: string, cuerpo: any, conToken = true) =>
  srv.pedir('PATCH', `/api/admin/alumnos/${id}/curso`, cuerpo, conToken ? token : undefined);

beforeAll(async () => {
  for (const n of ['SUPABASE_SERVICE_ROLE_KEY', 'ADMIN_SESSION_SECRET']) entornoAntes[n] = process.env[n];
  process.env.SUPABASE_SERVICE_ROLE_KEY = 'prueba';
  process.env.ADMIN_SESSION_SECRET = 'secreto-de-prueba';
  const { rutasCursosNomina } = await import('../../../../servidor/familias/cursosNomina');
  const { generateAdminToken } = await import('../../../../servidor/nucleo/auth');
  token = generateAdminToken() || '';
  srv = await montar([rutasCursosNomina]);
}, 120_000);

afterAll(async () => {
  await srv.cerrar();
  for (const [n, v] of Object.entries(entornoAntes)) {
    if (v === undefined) delete process.env[n];
    else process.env[n] = v;
  }
});

beforeEach(() => {
  reiniciar();
  estado.tablas.alumnos = [
    { id: 'a1', colegio_id: 'col-1', nombre: 'PEREZ, ANA', grado: 'Sala 4 años', division: 'C', turno: 'Tarde', numero_lista: 3 },
    { id: 'a2', colegio_id: 'col-1', nombre: 'GOMEZ, LUZ', grado: 'Sala 4 años', division: 'C', turno: 'Jornada Extendida / Completa', numero_lista: 1 },
    { id: 'a3', colegio_id: 'col-1', nombre: 'DIAZ, SOL', grado: 'Sala 4 años', division: 'C', turno: 'Jornada Extendida / Completa', numero_lista: 9 },
    { id: 'b1', colegio_id: 'col-2', nombre: 'RUIZ, EVA', grado: '1° grado', division: 'A', turno: 'Mañana', numero_lista: 1 },
  ];
  estado.tablas.codigos_seccion = [
    { id: 's1', colegio_id: 'col-1', grado: 'Sala 4 años', division: 'C', turno: 'Tarde', codigo_secreto: 'VIEJ-0001' },
    { id: 's2', colegio_id: 'col-1', grado: 'Sala 4 años', division: 'C', turno: 'Jornada Extendida / Completa', codigo_secreto: 'NUEV-0002' },
  ];
  estado.tablas.inscripciones = [];
});

const inscripcion = (id: string) => (estado.tablas.inscripciones || []).find((i: any) => i.id === id);

describe('PATCH /api/admin/alumnos/:id/curso', () => {
  it('lo pasa a un curso que existe y lo pone último en la lista', async () => {
    const r = await mover('a1', { grado: 'sala 4 años', division: 'c', turno: 'jornada extendida / completa' });
    expect(r.status).toBe(200);
    expect(alumno('a1')).toMatchObject({ grado: 'Sala 4 años', division: 'C', turno: 'Jornada Extendida / Completa', numero_lista: 10 });
  });

  it('no inventa cursos: un curso que no está en la nómina del colegio da 400', async () => {
    const r = await mover('a1', { grado: 'Sala 4 años', division: 'C', turno: 'Mañana' });
    expect(r.status).toBe(400);
    expect(alumno('a1')).toMatchObject({ turno: 'Tarde', numero_lista: 3 });
  });

  it('no usa cursos de otro colegio', async () => {
    const r = await mover('a1', { grado: '1° grado', division: 'A', turno: 'Mañana' });
    expect(r.status).toBe(400);
    expect(alumno('a1').grado).toBe('Sala 4 años');
  });

  it('mismo curso (reintento, 14/10: es un éxito sin cambios) o alumno inexistente: no cambia nada', async () => {
    const antes = { ...alumno('a2') };
    const r = await mover('a2', { grado: 'Sala 4 años', division: 'C', turno: 'Jornada Extendida / Completa' });
    expect(r.status).toBe(200);
    expect(r.json).toMatchObject({ success: true, sinCambios: true });
    expect(alumno('a2')).toEqual(antes);
    expect((await mover('zz', { grado: 'Sala 4 años', division: 'C', turno: 'Tarde' })).status).toBe(404);
  });

  // 14/10/2026 (caso Paludi): mover la nómina dejaba a la familia con el código del curso viejo.
  it('mueve también la inscripción de la familia y le asigna el código del curso nuevo', async () => {
    estado.tablas.inscripciones = [
      { id: 'i1', colegio_id: 'col-1', estado: 'aceptado', padre_nombre: 'Mamá Ana', email: 'm@x.com', alumno_nombre: 'Ana', alumno_apellido: 'Perez', grado: 'Sala 4 años', division: 'C', turno: 'Tarde', codigo_asignado: 'VIEJ-0001', codigo_familiar: 'VIEJ-0001', hermanos: [] },
      { id: 'i2', colegio_id: 'col-1', estado: 'aceptado', padre_nombre: 'Otra', email: 'o@x.com', alumno_nombre: 'Juan', alumno_apellido: 'Lopez', grado: 'Sala 4 años', division: 'C', turno: 'Tarde', codigo_asignado: 'VIEJ-0001', codigo_familiar: 'VIEJ-0001', hermanos: [] },
    ];
    const r = await mover('a1', { grado: 'Sala 4 años', division: 'C', turno: 'Jornada Extendida / Completa' });
    expect(r.status).toBe(200);
    expect(inscripcion('i1')).toMatchObject({ turno: 'Jornada Extendida / Completa', codigo_asignado: 'NUEV-0002', codigo_familiar: 'NUEV-0002' });
    expect(inscripcion('i2')).toMatchObject({ turno: 'Tarde', codigo_asignado: 'VIEJ-0001' });
    expect(r.json.inscripciones).toEqual([{ id: 'i1', padre: 'Mamá Ana', email: 'm@x.com', esHermano: false, codigoNuevo: 'NUEV-0002' }]);
  });

  it('si es un hermano, cambia su curso dentro de la inscripción y el código de la familia no cambia', async () => {
    estado.tablas.inscripciones = [
      { id: 'i3', colegio_id: 'col-1', estado: 'aceptado', padre_nombre: 'Papá', email: 'p@x.com', alumno_nombre: 'Leo', alumno_apellido: 'Perez', grado: '1° grado', division: 'A', turno: 'Mañana', codigo_asignado: 'OTRO-0003', codigo_familiar: 'OTRO-0003',
        hermanos: [{ alumnoNombre: 'Ana', alumnoApellido: 'Perez', grado: 'Sala 4 años', division: 'C', turno: 'Tarde' }] },
    ];
    const r = await mover('a1', { grado: 'Sala 4 años', division: 'C', turno: 'Jornada Extendida / Completa' });
    expect(r.status).toBe(200);
    expect(inscripcion('i3').codigo_asignado).toBe('OTRO-0003');
    expect(inscripcion('i3').hermanos[0]).toMatchObject({ alumnoNombre: 'Ana', turno: 'Jornada Extendida / Completa' });
    expect(r.json.inscripciones[0]).toMatchObject({ id: 'i3', esHermano: true, codigoNuevo: null });
  });

  it('si el curso nuevo no tiene código, no mueve la inscripción y lo avisa', async () => {
    estado.tablas.codigos_seccion = estado.tablas.codigos_seccion.filter((c: any) => c.id !== 's2');
    estado.tablas.inscripciones = [
      { id: 'i1', colegio_id: 'col-1', estado: 'aceptado', padre_nombre: 'Mamá Ana', email: 'm@x.com', alumno_nombre: 'Ana', alumno_apellido: 'Perez', grado: 'Sala 4 años', division: 'C', turno: 'Tarde', codigo_asignado: 'VIEJ-0001', codigo_familiar: 'VIEJ-0001', hermanos: [] },
    ];
    const r = await mover('a1', { grado: 'Sala 4 años', division: 'C', turno: 'Jornada Extendida / Completa' });
    expect(r.status).toBe(200);
    expect(r.json.cursoSinCodigo).toBe(true);
    expect(inscripcion('i1')).toMatchObject({ turno: 'Tarde', codigo_asignado: 'VIEJ-0001' });
  });

  it('sin la sesión de admin no se puede', async () => {
    const r = await mover('a1', { grado: 'Sala 4 años', division: 'C', turno: 'Jornada Extendida / Completa' }, false);
    expect(r.status).toBe(401);
    expect(alumno('a1').turno).toBe('Tarde');
  });
});
