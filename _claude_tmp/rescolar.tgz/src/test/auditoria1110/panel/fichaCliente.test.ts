// «Ficha del cliente» desde Consultas (19/10/2026): todo lo de una familia (inscripción, hijos, kit, pago).
// Corre la ruta REAL sobre la base falsa.
import { afterAll, beforeAll, beforeEach, describe, expect, it, vi } from 'vitest';
import { estado, reiniciar } from './falsoSupabase';
import { montar, type Montado } from './servidorPrueba';

vi.mock('dotenv', () => {
  const config = () => ({ parsed: {} });
  return { default: { config }, config };
});
vi.mock('@supabase/supabase-js', async () => {
  const m = await import('./falsoSupabase');
  return { createClient: () => m.clienteFalso() };
});
vi.mock('resend', async () => {
  const m = await import('./falsoSupabase');
  return { Resend: m.resendFalso() };
});

const COL = '11111111-1111-4111-8111-111111111111';
const FAM1 = 'f1111111-1111-4111-8111-111111111111';
const FAM2 = 'f2222222-2222-4222-8222-222222222222';
const AJENA = 'f3333333-3333-4333-8333-333333333333';

let srv: Montado;
let token = '';
const entornoAntes: Record<string, string | undefined> = {};

beforeAll(async () => {
  for (const n of ['SUPABASE_SERVICE_ROLE_KEY', 'ADMIN_SESSION_SECRET']) entornoAntes[n] = process.env[n];
  process.env.SUPABASE_SERVICE_ROLE_KEY = 'prueba';
  process.env.ADMIN_SESSION_SECRET = 'secreto-de-prueba';
  const { rutasFichaCliente } = await import('../../../../servidor/familias/fichaCliente');
  const { generateAdminToken } = await import('../../../../servidor/nucleo/auth');
  token = generateAdminToken() || '';
  srv = await montar([rutasFichaCliente]);
}, 120_000);

afterAll(async () => {
  await srv.cerrar();
  for (const [n, v] of Object.entries(entornoAntes)) {
    if (v === undefined) delete process.env[n];
    else process.env[n] = v;
  }
});

beforeEach(() => {
  reiniciar();
  estado.tablas.inscripciones = [{
    id: 'ins-1', padre_nombre: 'Laura Gómez', padre_dni: '30111222', telefono_whatsapp: '+54 9 11 5555-1234', email: 'Laura@Mail.com',
    alumno_nombre: 'Tomás', alumno_apellido: 'Paz', grado: 'Sala 4 años', division: 'C', turno: 'Tarde', colegio_id: COL,
    colegio_nombre: 'Divino Pastor', estado: 'aceptado', codigo_asignado: 'ABC123', notificacion_email_enviada: true,
    hermanos: [{ alumnoNombre: 'Sofía', alumnoApellido: 'Paz', grado: '3° grado', division: 'A', turno: 'Mañana' }],
    created_at: '2026-09-20T10:00:00Z',
  }];
  estado.tablas.alumnos = [
    { id: 'alu-1', colegio_id: COL, nombre: 'PAZ, TOMAS', grado: 'Sala 4 años', division: 'C', turno: 'Tarde' },
    { id: 'alu-2', colegio_id: COL, nombre: 'PAZ, SOFIA', grado: '3° grado', division: 'B', turno: 'Mañana' },
  ];
  // FAM1: compró con el mismo email; FAM2: con otro email pero el mismo teléfono (escrito distinto).
  estado.tablas.familias = [
    { id: FAM1, nombre: 'Laura Gómez', email: 'laura@mail.com', whatsapp: '1155551234' },
    { id: FAM2, nombre: 'Laura G', email: 'otro@mail.com', whatsapp: '11 5555 1234' },
    { id: AJENA, nombre: 'Otra familia', email: 'ajena@mail.com', whatsapp: '1199998888' },
  ];
  estado.tablas.pedidos = [
    { id: 'p1', familia_id: FAM1, alumno_id: 'alu-1', pedido_friendly_id: 'IFS-2026-1111', alumno_nombre: 'Tomás Paz', kit_nombre: 'Kit Impreso', total: 30000, estado: 'pagado', metodo_pago: 'mercadopago', fotos_seleccionadas: { individual: 'f1', grupal: 'f2', docente: 'f3' }, created_at: '2026-10-01T10:00:00Z' },
    { id: 'p2', familia_id: FAM2, alumno_id: null, pedido_friendly_id: 'IFS-2026-2222', alumno_nombre: 'Sofía Paz', kit_nombre: 'Kit Digital', total: 15000, estado: 'pendiente_pago', metodo_pago: 'transferencia', fotos_seleccionadas: {}, created_at: '2026-10-02T10:00:00Z' },
    { id: 'p3', familia_id: AJENA, alumno_id: null, pedido_friendly_id: 'IFS-2026-9999', alumno_nombre: 'Otro Chico', kit_nombre: 'Kit Digital', total: 15000, estado: 'pagado', metodo_pago: 'nave', created_at: '2026-10-03T10:00:00Z' },
  ];
  estado.tablas.fotos = [
    { id: 'f1', colegio_id: COL, grado: 'Sala 4 años', division: 'C', turno: 'Tarde', publicada_at: '2026-10-01T00:00:00Z' },
    { id: 'f2', colegio_id: COL, grado: 'Sala 4 años', division: 'C', turno: 'Tarde', publicada_at: null },
  ];
  estado.tablas.ev_pedidos = [{ id: 'e1', numero: 'EV-1', evento_id: 'ev-1', comprador_email: 'laura@mail.com', nino_nombre: 'Tomás', total: 8000, estado: 'pagado', creado_en: '2026-10-05T10:00:00Z' }];
  estado.tablas.ev_eventos = [{ id: 'ev-1', nombre: 'Comunión 2026', codigo: 'COM' }];
  estado.tablas.observaciones_alumnos = [{ id: 'o1', colegio_id: COL, alumno_id: 'alu-1', alumno_nombre: 'PAZ, TOMAS', tipo: 'ausente', detalle: null, created_at: '2026-09-30T10:00:00Z' }];
  estado.tablas.consultas_familias = [{ id: 'c1', email: 'laura@mail.com', asunto: '¿Ya pagué?', estado: 'nueva', origen: 'web', created_at: '2026-10-06T10:00:00Z' }];
});

describe('GET /api/admin/ficha-cliente', () => {
  it('exige sesión de admin y algún dato para buscar', async () => {
    expect((await srv.pedir('GET', '/api/admin/ficha-cliente?email=laura@mail.com')).status).toBe(401);
    expect((await srv.pedir('GET', '/api/admin/ficha-cliente', undefined, token)).status).toBe(400);
    expect((await srv.pedir('GET', '/api/admin/ficha-cliente?email=no-es-email&telefono=12', undefined, token)).status).toBe(400);
  });

  it('junta inscripción, hijos, pedidos (también los del mismo teléfono con otro email), eventos y observaciones', async () => {
    const r = await srv.pedir('GET', '/api/admin/ficha-cliente?email=laura@mail.com', undefined, token);
    expect(r.status).toBe(200);
    const f = r.json.ficha;
    expect(f.encontrado).toBe(true);
    expect(f.inscripciones).toHaveLength(1);
    expect(f.inscripciones[0]).toMatchObject({ tutor: 'Laura Gómez', codigo: 'ABC123', estado: 'aceptado' });
    expect(f.pedidos.map((p: any) => p.numero).sort()).toEqual(['IFS-2026-1111', 'IFS-2026-2222']);
    expect(f.pedidos.find((p: any) => p.numero === 'IFS-2026-1111')).toMatchObject({ estado: 'pagado', kit: 'Kit Impreso', fotosElegidas: 3 });

    const tomas = f.hijos.find((h: any) => h.nombre === 'Tomás Paz');
    expect(tomas).toMatchObject({ coincideConNomina: true, pagado: true, fotosPublicadas: 1 });
    const sofia = f.hijos.find((h: any) => h.nombre === 'Sofía Paz');
    expect(sofia).toMatchObject({ coincideConNomina: false, enNomina: true, pagado: false, pedidos: 1 });
    expect(sofia.cursoNomina).toMatchObject({ division: 'B' });

    expect(f.pedidosEventos[0]).toMatchObject({ numero: 'EV-1', evento: 'Comunión 2026' });
    expect(f.observaciones).toHaveLength(1);
    expect(f.consultas).toHaveLength(1);
  });

  it('un número de pedido ajeno se muestra marcado, sin mezclarlo con los de la familia', async () => {
    const r = await srv.pedir('GET', '/api/admin/ficha-cliente?email=laura@mail.com&pedido=IFS-2026-9999', undefined, token);
    const f = r.json.ficha;
    expect(f.pedidoMencionado).toEqual({ numero: 'IFS-2026-9999', encontrado: true, deEstaFamilia: false });
    expect(f.pedidos.find((p: any) => p.numero === 'IFS-2026-9999')).toMatchObject({ soloPorNumero: true });
    expect(f.hijos.find((h: any) => h.nombre === 'Tomás Paz').pedidos).toBe(1);
  });

  it('encuentra a la familia sólo con el teléfono', async () => {
    const r = await srv.pedir('GET', `/api/admin/ficha-cliente?telefono=${encodeURIComponent('011 5555-1234')}`, undefined, token);
    expect(r.json.ficha.inscripciones).toHaveLength(1);
    expect(r.json.ficha.pedidos).toHaveLength(2);
  });

  it('sin coincidencias devuelve encontrado: false', async () => {
    const r = await srv.pedir('GET', '/api/admin/ficha-cliente?email=nadie@mail.com', undefined, token);
    expect(r.status).toBe(200);
    expect(r.json.ficha.encontrado).toBe(false);
  });
});
