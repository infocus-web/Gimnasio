// Auditoría 11/10: monta routers reales en un Express local y les pega por HTTP (127.0.0.1).
import http from 'http';
import type { AddressInfo } from 'net';
import express from 'express';

export interface Montado {
  pedir: (metodo: string, ruta: string, cuerpo?: unknown, token?: string) => Promise<{ status: number; json: any }>;
  cerrar: () => Promise<void>;
}

export async function montar(routers: any[]): Promise<Montado> {
  const app = express();
  app.use(express.json());
  for (const r of routers) app.use(r);
  const servidor = app.listen(0);
  await new Promise((ok) => servidor.once('listening', ok));
  const puerto = (servidor.address() as AddressInfo).port;
  const pedir = (metodo: string, ruta: string, cuerpo?: unknown, token?: string) =>
    new Promise<{ status: number; json: any }>((ok, mal) => {
      const datos = cuerpo === undefined ? undefined : JSON.stringify(cuerpo);
      const encabezados: Record<string, string | number> = {};
      if (datos) {
        encabezados['Content-Type'] = 'application/json';
        encabezados['Content-Length'] = Buffer.byteLength(datos);
      }
      if (token) encabezados.Authorization = `Bearer ${token}`;
      const req = http.request({ host: '127.0.0.1', port: puerto, path: ruta, method: metodo, headers: encabezados }, (res) => {
        let texto = '';
        res.setEncoding('utf8');
        res.on('data', (c) => { texto += c; });
        res.on('end', () => {
          let json: any = null;
          try { json = JSON.parse(texto); } catch { /* no es JSON */ }
          ok({ status: res.statusCode || 0, json });
        });
      });
      req.on('error', mal);
      if (datos) req.write(datos);
      req.end();
    });
  return { pedir, cerrar: () => new Promise((ok) => servidor.close(() => ok())) };
}
