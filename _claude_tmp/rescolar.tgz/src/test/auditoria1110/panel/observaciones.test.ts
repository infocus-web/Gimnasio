// Pestaña «Observaciones» del panel (13/10/2026): anotar que un alumno no quiso la foto individual, faltó, etc.
// Corre las rutas REALES sobre la base falsa.
import { afterAll, beforeAll, beforeEach, describe, expect, it, vi } from 'vitest';
import { estado, reiniciar } from './falsoSupabase';
import { montar, type Montado } from './servidorPrueba';

vi.mock('dotenv', () => {
  const config = () => ({ parsed: {} });
  return { default: { config }, config };
});
vi.mock('@supabase/supabase-js', async () => {
  const m = await import('./falsoSupabase');
  return { createClient: () => m.clienteFalso() };
});
vi.mock('resend', async () => {
  const m = await import('./falsoSupabase');
  return { Resend: m.resendFalso() };
});

const COL1 = '11111111-1111-4111-8111-111111111111';
const COL2 = '22222222-2222-4222-8222-222222222222';
const ALU1 = 'aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa';
const ALU2 = 'bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb';
const OBS1 = 'cccccccc-cccc-4ccc-8ccc-cccccccccccc';

let srv: Montado;
let token = '';
const entornoAntes: Record<string, string | undefined> = {};
const observaciones = () => estado.tablas.observaciones_alumnos || [];

beforeAll(async () => {
  for (const n of ['SUPABASE_SERVICE_ROLE_KEY', 'ADMIN_SESSION_SECRET']) entornoAntes[n] = process.env[n];
  process.env.SUPABASE_SERVICE_ROLE_KEY = 'prueba';
  process.env.ADMIN_SESSION_SECRET = 'secreto-de-prueba';
  const { rutasObservaciones } = await import('../../../../servidor/panel/observaciones');
  const { generateAdminToken } = await import('../../../../servidor/nucleo/auth');
  token = generateAdminToken() || '';
  srv = await montar([rutasObservaciones]);
}, 120_000);

afterAll(async () => {
  await srv.cerrar();
  for (const [n, v] of Object.entries(entornoAntes)) {
    if (v === undefined) delete process.env[n];
    else process.env[n] = v;
  }
});

beforeEach(() => {
  reiniciar();
  estado.tablas.alumnos = [
    { id: ALU1, colegio_id: COL1, nombre: 'PEREZ, ANA', grado: 'Sala 4 años', division: 'C', turno: 'Tarde' },
    { id: ALU2, colegio_id: COL2, nombre: 'RUIZ, EVA', grado: '1° grado', division: 'A', turno: 'Mañana' },
  ];
  estado.tablas.observaciones_alumnos = [
    { id: OBS1, colegio_id: COL2, alumno_id: ALU2, alumno_nombre: 'RUIZ, EVA', tipo: 'ausente', detalle: null, created_at: '2026-10-01T10:00:00Z' },
  ];
});

describe('POST /api/admin/observaciones', () => {
  it('guarda la observación con el nombre y el curso de la nómina (no los del navegador)', async () => {
    const r = await srv.pedir('POST', '/api/admin/observaciones', {
      alumnoId: ALU1, tipo: 'sin_foto_individual', detalle: '  Lloraba, no quiso  ', alumno_nombre: 'TRUCHO', colegio_id: COL2,
    }, token);
    expect(r.status).toBe(200);
    const nueva = observaciones().find((o: any) => o.alumno_id === ALU1);
    expect(nueva).toMatchObject({
      colegio_id: COL1, alumno_nombre: 'PEREZ, ANA', grado: 'Sala 4 años', division: 'C', turno: 'Tarde',
      tipo: 'sin_foto_individual', detalle: 'Lloraba, no quiso',
    });
  });

  it('rechaza tipo inválido, «otra» sin detalle, detalle largo y alumno inexistente', async () => {
    const p = (b: any) => srv.pedir('POST', '/api/admin/observaciones', b, token);
    expect((await p({ alumnoId: ALU1, tipo: 'cualquiera' })).status).toBe(400);
    expect((await p({ alumnoId: ALU1, tipo: 'otra', detalle: '   ' })).status).toBe(400);
    expect((await p({ alumnoId: ALU1, tipo: 'ausente', detalle: 'x'.repeat(1001) })).status).toBe(400);
    expect((await p({ alumnoId: 'no-es-uuid', tipo: 'ausente' })).status).toBe(400);
    expect((await p({ alumnoId: 'dddddddd-dddd-4ddd-8ddd-dddddddddddd', tipo: 'ausente' })).status).toBe(404);
    expect(observaciones()).toHaveLength(1);
  });

  it('sin la sesión de admin no se puede', async () => {
    const r = await srv.pedir('POST', '/api/admin/observaciones', { alumnoId: ALU1, tipo: 'ausente' });
    expect(r.status).toBe(401);
    expect(observaciones()).toHaveLength(1);
  });
});

describe('GET y DELETE /api/admin/observaciones', () => {
  it('lista sólo las del colegio pedido', async () => {
    await srv.pedir('POST', '/api/admin/observaciones', { alumnoId: ALU1, tipo: 'ausente' }, token);
    const r = await srv.pedir('GET', `/api/admin/observaciones?colegioId=${COL1}`, undefined, token);
    expect(r.status).toBe(200);
    expect(r.json.observaciones.map((o: any) => o.alumno_nombre)).toEqual(['PEREZ, ANA']);
    expect((await srv.pedir('GET', '/api/admin/observaciones?colegioId=x', undefined, token)).status).toBe(400);
    expect((await srv.pedir('GET', `/api/admin/observaciones?colegioId=${COL1}`)).status).toBe(401);
  });

  it('borra una observación sólo con sesión de admin', async () => {
    expect((await srv.pedir('DELETE', `/api/admin/observaciones/${OBS1}`)).status).toBe(401);
    expect(observaciones()).toHaveLength(1);
    expect((await srv.pedir('DELETE', `/api/admin/observaciones/${OBS1}`, undefined, token)).status).toBe(200);
    expect(observaciones()).toHaveLength(0);
  });
});
