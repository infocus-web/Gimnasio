// Auditoría 11/10/2026 (panel: servidor/panel/*.ts, servidor/convenioLiquidacion.ts, nucleo/utilidades.ts).
// Pruebas de REGRESIÓN de los arreglos PAN-1…PAN-11, ADM-1 y DB-8: corren las rutas REALES de Express sobre
// una base y un Storage falsos en memoria (falsoSupabase.ts). Con el código anterior al arreglo, fallan.
import { afterAll, beforeAll, beforeEach, describe, expect, it, vi } from 'vitest';
import { clienteFalso, estado, reiniciar } from './falsoSupabase';
import { montar, type Montado } from './servidorPrueba';

vi.mock('dotenv', () => {
  const config = () => ({ parsed: {} });
  return { default: { config }, config };
});
vi.mock('@supabase/supabase-js', async () => {
  const m = await import('./falsoSupabase');
  return { createClient: () => m.clienteFalso() };
});
vi.mock('resend', async () => {
  const m = await import('./falsoSupabase');
  return { Resend: m.resendFalso() };
});

let srv: Montado;
let token = '';
const entornoAntes: Record<string, string | undefined> = {};
const pedidos = () => estado.tablas.pedidos || [];
const pedido = (id: string) => pedidos().find((p) => p.id === id);
const removidos = (bucket: string) => estado.storage.removidos.filter((x) => x.bucket === bucket).flatMap((x) => x.rutas);
const UUID = (n: number) => `00000000-0000-4000-8000-${String(n).padStart(12, '0')}`;

beforeAll(async () => {
  for (const n of ['SUPABASE_SERVICE_ROLE_KEY', 'RESEND_API_KEY', 'ADMIN_SESSION_SECRET', 'CRON_SECRET', 'LAB_EMAIL']) entornoAntes[n] = process.env[n];
  process.env.SUPABASE_SERVICE_ROLE_KEY = 'prueba';
  process.env.RESEND_API_KEY = 'prueba';
  process.env.ADMIN_SESSION_SECRET = 'secreto-de-prueba';
  process.env.CRON_SECRET = 'secreto-cron';
  delete process.env.LAB_EMAIL;
  const { rutasPanelPedidos, rutasBorrarPedido } = await import('../../../../servidor/panel/pedidos');
  const { rutasFotosPanel } = await import('../../../../servidor/panel/fotos');
  const { rutasCierreTemporada } = await import('../../../../servidor/panel/cierreTemporada');
  const { rutasConvenioLiquidacion } = await import('../../../../servidor/convenioLiquidacion');
  const { rutasLaboratorio } = await import('../../../../servidor/panel/laboratorio');
  const { rutasColegios } = await import('../../../../servidor/panel/colegios');
  const { generateAdminToken } = await import('../../../../servidor/nucleo/auth');
  token = generateAdminToken() || '';
  srv = await montar([rutasPanelPedidos, rutasBorrarPedido, rutasFotosPanel, rutasCierreTemporada, rutasConvenioLiquidacion, rutasLaboratorio, rutasColegios]);
}, 120_000);

afterAll(async () => {
  await srv.cerrar();
  for (const [n, v] of Object.entries(entornoAntes)) {
    if (v === undefined) delete process.env[n];
    else process.env[n] = v;
  }
});

beforeEach(() => reiniciar());

describe('PAN-1: borrar una foto no falla abierto', () => {
  const fotoId = UUID(1);
  const preparar = () => {
    estado.tablas.fotos = [{ id: fotoId, colegio_id: 'col-1', codigo_curso: 'GRADO1-ATM', storage_path: '2026/col/GRADO1-ATM/originales/ana.jpg', preview_path: null, thumb_path: null }];
    estado.tablas.pedidos = [{ id: 'p1', colegio_id: 'col-1', curso_codigo: 'GRADO1-ATM', estado: 'pagado', cancelado_definitivo: false, pedido_friendly_id: 'IFS-1', alumno_nombre: 'Ana', fotos_seleccionadas: { individualId: fotoId, grupalId: 'g' } }];
  };

  it('en un pedido pagado queda protegida (409)', async () => {
    preparar();
    const r = await srv.pedir('DELETE', `/api/admin/fotos/${fotoId}`, undefined, token);
    expect(r.status).toBe(409);
    expect(estado.tablas.fotos).toHaveLength(1);
  });

  it('si no se pueden leer los pedidos, responde 503 y no borra ni la fila ni el original', async () => {
    preparar();
    estado.fallar = (tabla, op) => tabla === 'pedidos' && op === 'select';
    const r = await srv.pedir('DELETE', `/api/admin/fotos/${fotoId}`, undefined, token);
    expect(r.status).toBe(503);
    expect(estado.tablas.fotos).toHaveLength(1);
    expect(removidos('fotos-hd')).toHaveLength(0);
  });
});

describe('PAN-2: notificar-estado no avisa sin poder verificar', () => {
  const id = UUID(2);
  const preparar = () => {
    estado.tablas.pedidos = [{ id, estado: 'pendiente_pago', estado_lab: null, en_espera: false, archivado: false, seleccion_pendiente: false, tipo_kit: 'impreso_digital', lote_lab_id: null, fecha_envio_produccion: null, fecha_envio_listo_retiro: null }];
  };
  const cuerpo = (pedidoId: string) => ({ tipo: 'en_produccion', destinatarios: [{ pedidoId, to: 'familia@prueba.test', tutorNombre: 'Fam', alumnoNombre: 'Ana', colegioNombre: 'Col' }] });

  it('si falla la lectura previa: 503, ningún mail, la etapa no cambia', async () => {
    preparar();
    estado.fallar = (tabla, op, columnas) => tabla === 'pedidos' && op === 'select' && columnas.includes('en_espera');
    const r = await srv.pedir('POST', '/api/admin/pedidos/notificar-estado', cuerpo(id), token);
    expect(r.status).toBe(503);
    expect(estado.mails).toHaveLength(0);
    expect(pedido(id).estado_lab).toBeNull();
  });

  it('un pedido que no existe en la base no recibe aviso', async () => {
    preparar();
    const r = await srv.pedir('POST', '/api/admin/pedidos/notificar-estado', cuerpo(UUID(99)), token);
    expect(r.status).toBe(409);
    expect(estado.mails).toHaveLength(0);
  });

  it('un pedido pagado sí se avisa (sin regresión)', async () => {
    preparar();
    Object.assign(pedido(id), { estado: 'pagado', tipo_kit: 'solo_digital' });
    const r = await srv.pedir('POST', '/api/admin/pedidos/notificar-estado', cuerpo(id), token);
    expect(r.status).toBe(200);
    expect(estado.mails).toHaveLength(1);
    expect(pedido(id).estado_lab).toBe('en_produccion');
  });
});

describe('29/10: fotos extra en el panel', () => {
  const id = UUID(3);
  it('un pedido de fotos extra sin lote NO se puede pasar a «En producción» desde el panel (desaparecería de la cola del laboratorio)', async () => {
    estado.tablas.pedidos = [{ id, estado: 'pagado', estado_lab: null, en_espera: false, archivado: false, seleccion_pendiente: false, tipo_kit: 'fotos_extra', lote_lab_id: null, fecha_envio_produccion: null, fecha_envio_listo_retiro: null }];
    const r = await srv.pedir('POST', '/api/admin/pedidos/notificar-estado', { tipo: 'en_produccion', destinatarios: [{ pedidoId: id, to: 'familia@prueba.test', tutorNombre: 'Fam', alumnoNombre: 'Ana', colegioNombre: 'Col' }] }, token);
    expect(estado.mails).toHaveLength(0);
    expect(pedido(id).estado_lab).toBeNull();
    expect(JSON.stringify(r.json)).toContain('lote del laboratorio');
  });
  it('la liquidación del colegio descuenta el costo de las copias de fotos extra (sin carpeta)', async () => {
    estado.tablas.colegios = [{ id: 'col-L', nombre: 'Colegio L', porcentaje_participacion: 30 }];
    estado.tablas.costos_liquidacion = [{ id: 1, costo_carpeta: 1350, costo_foto_20x30: 1800, costo_foto_15x21: 850, comision_mercadopago_pct: 0, comision_nave_pct: 0, impuestos_pct: 0 }];
    estado.tablas.convenios_colegios = [];
    estado.tablas.pedidos = [{
      id: 'X1', colegio_id: 'col-L', estado: 'pagado', pagado_at: '2026-06-01T12:00:00Z', total: 18000, metodo_pago: 'mercadopago', aprobado_manual_at: '2026-06-01T12:00:00Z',
      mp_payment_id: null, nave_payment_id: null, comision_origen: null, comision_cobro: null, carpetas_impresas: 0, copias_extras: {}, tipo_kit: 'fotos_extra', extras_de_pedido_id: 'K1',
      fotos_seleccionadas: { extras: [{ fotoId: 'a', tamano: '15x21', cantidad: 2 }, { fotoId: 'b', tamano: '20x30', cantidad: 1 }] },
    }];
    const r = await srv.pedir('GET', '/api/admin/liquidacion?colegioId=col-L&desde=2026-01-01&hasta=2026-12-31', undefined, token);
    expect(r.json.filas[0]).toMatchObject({ carpetas: 0, fotos15x21: 2, fotos20x30: 1, costoLaboratorio: 2 * 850 + 1800, ganancia: 18000 - 3500 });
  });
});

describe('PAN-3: liquidación sin comisión para lo aprobado a mano sin pasarela', () => {
  const preparar = (extra: Record<string, any>) => {
    estado.tablas.colegios = [{ id: 'col-L', nombre: 'Colegio L', porcentaje_participacion: 30 }];
    estado.tablas.costos_liquidacion = [{ id: 1, costo_carpeta: 0, costo_foto_20x30: 0, costo_foto_15x21: 0, comision_mercadopago_pct: 10, comision_nave_pct: 0, impuestos_pct: 0 }];
    estado.tablas.convenios_colegios = [];
    estado.tablas.pedidos = [{
      id: 'M1', colegio_id: 'col-L', estado: 'pagado', pagado_at: '2026-06-01T12:00:00Z', total: 15000, metodo_pago: 'mercadopago',
      mp_payment_id: null, nave_payment_id: null, comision_origen: null, comision_cobro: null, aprobado_manual_at: null,
      carpetas_impresas: 1, copias_extras: {}, fotos_seleccionadas: {}, mejora_de_pedido_id: 'orig', tipo_kit: 'impreso_digital', ...extra,
    }];
  };
  const liquidar = () => srv.pedir('GET', '/api/admin/liquidacion?colegioId=col-L&desde=2026-01-01&hasta=2026-12-31', undefined, token);

  it('mejora "mercadopago" aprobada a mano: comisión 0 y participación sobre $15.000', async () => {
    preparar({ aprobado_manual_at: '2026-06-01T12:00:00Z' });
    const r = await liquidar();
    expect(r.json.filas[0]).toMatchObject({ comision: 0, comisionOrigen: 'sin_comision', ganancia: 15000 });
    expect(r.json.participacion).toBe(4500);
  });

  it('un pago viejo de Mercado Pago sin id (no aprobado a mano) sigue estimando la comisión', async () => {
    preparar({});
    const r = await liquidar();
    expect(r.json.filas[0]).toMatchObject({ comision: 1500, comisionOrigen: 'estimada' });
  });
});

describe('PAN-4: paginado y freno de "Limpiar huérfanos"', () => {
  const preparar = (cantidad: number, enStorage = cantidad) => {
    const rutas = Array.from({ length: cantidad }, (_, i) => `2026/col/GRADO1-ATM/originales/f${i}.jpg`);
    estado.tablas.fotos = rutas.map((r, i) => ({ id: `f${i}`, storage_path: r, preview_path: null, thumb_path: null }));
    estado.tablas.pedidos = [];
    estado.storage.archivos['fotos-hd'] = Array.from({ length: enStorage }, (_, i) => `2026/col/GRADO1-ATM/originales/f${i}.jpg`);
    estado.storage.archivos['fotos-web'] = [];
  };

  it('traerTodasLasFilas trae todo aunque PostgREST corte en 500 filas', async () => {
    preparar(1200);
    estado.maxFilas = 500;
    const { traerTodasLasFilas } = await import('../../../../servidor/nucleo/utilidades');
    const sb = clienteFalso();
    const filas = await traerTodasLasFilas<any>((d, h) => sb.from('fotos').select('id').order('id').range(d, h));
    expect(filas).toHaveLength(1200);
  });

  it('con "Max Rows" en 500 no se borra ningún original en uso', async () => {
    preparar(600);
    estado.maxFilas = 500;
    const { limpiarArchivosHuerfanos } = await import('../../../../servidor/panel/fotos');
    const r = await limpiarArchivosHuerfanos(clienteFalso() as any, true, 3 * 24 * 3600_000);
    expect(r.originalesHdHuerfanos).toBe(0);
    expect(removidos('fotos-hd')).toHaveLength(0);
  });

  it('si los huérfanos HD pasan el 20 % no borra nada y deja una alerta', async () => {
    preparar(10, 30); // 20 de 30 archivos sin fila en el catálogo
    const { limpiarArchivosHuerfanos } = await import('../../../../servidor/panel/fotos');
    const r = await limpiarArchivosHuerfanos(clienteFalso() as any, true, 3 * 24 * 3600_000);
    expect(r).toMatchObject({ originalesHdHuerfanos: 20, borrados: 0, frenado: true });
    expect(removidos('fotos-hd')).toHaveLength(0);
    expect(estado.tablas.reportes_errores?.[0]?.detalle?.clave).toBe('limpieza-huerfanos-frenada');
  });

  it('pocos huérfanos (≤ 20 %) se siguen borrando', async () => {
    preparar(10, 11);
    const { limpiarArchivosHuerfanos } = await import('../../../../servidor/panel/fotos');
    const r = await limpiarArchivosHuerfanos(clienteFalso() as any, true, 3 * 24 * 3600_000);
    expect(r).toMatchObject({ originalesHdHuerfanos: 1, borrados: 1, frenado: false });
  });
});

describe('PAN-5: /estado no pisa un pedido cobrado', () => {
  it('"pendiente" sobre un pagado: 409 y sigue pagado', async () => {
    estado.tablas.pedidos = [{ id: 'P3', estado: 'pagado', cancelado_definitivo: false, metodo_pago: 'transferencia', transferencia_desde: null }];
    const r = await srv.pedir('POST', '/api/admin/pedidos/P3/estado', { estadoPago: 'pendiente' }, token);
    expect(r.status).toBe(409);
    expect(pedido('P3')).toMatchObject({ estado: 'pagado', transferencia_desde: null });
  });

  it('"rechazado" sobre un pagado: 409; con forzar sí se cancela', async () => {
    estado.tablas.pedidos = [{ id: 'P4', estado: 'pagado', cancelado_definitivo: false, metodo_pago: 'mercadopago' }];
    expect((await srv.pedir('POST', '/api/admin/pedidos/P4/estado', { estadoPago: 'rechazado' }, token)).status).toBe(409);
    expect(pedido('P4').estado).toBe('pagado');
    const r = await srv.pedir('POST', '/api/admin/pedidos/P4/estado', { estadoPago: 'rechazado', forzar: true }, token);
    expect(r.status).toBe(200);
    expect(pedido('P4')).toMatchObject({ estado: 'cancelado', cancelado_definitivo: true });
  });

  it('«Reabrir plazo» de un vencido sigue andando', async () => {
    estado.tablas.pedidos = [{ id: 'P5', estado: 'cancelado', cancelado_definitivo: false, transferencia_vencida_at: '2026-06-01T00:00:00Z' }];
    const r = await srv.pedir('POST', '/api/admin/pedidos/P5/estado', { estadoPago: 'pendiente', estadoAnterior: 'cancelado' }, token);
    expect(r.status).toBe(200);
    expect(pedido('P5')).toMatchObject({ estado: 'pendiente_pago', transferencia_vencida_at: null });
  });
});

describe('PAN-6: un lote que falla a mitad guarda los totales de lo asignado', () => {
  it('150 pedidos, falla la 2ª tanda: el lote queda con cantidad 100', async () => {
    estado.tablas.lotes_laboratorio = [];
    estado.tablas.pedidos = Array.from({ length: 150 }, (_, i) => ({
      id: `L${String(i).padStart(3, '0')}`, estado: 'pagado', tipo_kit: 'impreso_digital', seleccion_pendiente: false, en_espera: false, archivado: false,
      lote_lab_id: null, estado_lab: null, carpetas_impresas: 1, copias_extras: {}, fotos_seleccionadas: {}, created_at: '2026-06-01T00:00:00Z',
    }));
    let updates = 0;
    estado.fallar = (tabla, op) => tabla === 'pedidos' && op === 'update' && ++updates === 2;
    const r = await srv.pedir('POST', '/api/lab/lotes', undefined, token);
    expect(r.status).toBe(500);
    expect(pedidos().filter((p) => p.lote_lab_id).length).toBe(100);
    expect(estado.tablas.lotes_laboratorio[0]).toMatchObject({ cantidad: 100, carpetas: 100, fotos_20x30: 100 });
  });
});

describe('PAN-7 y PAN-11: cierre de temporada', () => {
  const hace = (h: number) => new Date(Date.now() - h * 3600_000).toISOString();
  const preparar = (extra: Record<string, any>) => {
    estado.tablas.colegios = [{ id: 'col-C', nombre: 'Colegio C' }];
    estado.tablas.alumnos = [];
    estado.tablas.fotos = [];
    estado.tablas.pedido_fotos = [];
    estado.tablas.pedidos = [{
      id: 'V1', colegio_id: 'col-C', familia_id: null, alumno_id: null, pedido_friendly_id: 'IFS-V1', alumno_nombre: 'Bruno',
      estado: 'cancelado', cancelado_definitivo: false, metodo_pago: 'transferencia', tipo_kit: 'impreso_digital',
      created_at: hace(72), updated_at: hace(2), transferencia_desde: hace(72), transferencia_vencida_at: hace(2), comprobante_path: null, ...extra,
    }];
  };

  it('una transferencia vencida hace 2 h frena el cierre (409) y no se borra', async () => {
    preparar({});
    const resumen = await srv.pedir('GET', '/api/admin/cerrar-anio/resumen?colegioId=col-C', undefined, token);
    expect(resumen.json.bloqueos.pendientesRecientes).toBe(1);
    const r = await srv.pedir('POST', '/api/admin/cerrar-anio/ejecutar', { colegioId: 'col-C', confirmacion: 'CERRAR Colegio C' }, token);
    expect(r.status).toBe(409);
    expect(pedidos()).toHaveLength(1);
  });

  it('una vencida hace más de una semana no frena; al cerrar se borra con su comprobante', async () => {
    preparar({ transferencia_vencida_at: hace(24 * 9), updated_at: hace(24 * 9), comprobante_path: 'col-C/V1.jpg' });
    const r = await srv.pedir('POST', '/api/admin/cerrar-anio/ejecutar', { colegioId: 'col-C', confirmacion: 'CERRAR Colegio C' }, token);
    expect(r.status).toBe(200);
    expect(pedidos()).toHaveLength(0);
    expect(removidos('comprobantes')).toEqual(['col-C/V1.jpg']);
  });

  it('25/10: al cerrar se borran los avisos «ya están tus fotos» del colegio (el año que viene se vuelve a avisar)', async () => {
    preparar({ transferencia_vencida_at: hace(24 * 9), updated_at: hace(24 * 9) });
    estado.tablas.avisos_fotos_curso = [{ colegio_id: 'col-C', codigo_curso: 'GRADO1-ATM' }, { colegio_id: 'otro', codigo_curso: 'GRADO1-ATM' }];
    estado.tablas.avisos_fotos_destinatarios = [{ colegio_id: 'col-C', codigo_curso: 'GRADO1-ATM', email_hash: 'h1' }];
    const r = await srv.pedir('POST', '/api/admin/cerrar-anio/ejecutar', { colegioId: 'col-C', confirmacion: 'CERRAR Colegio C' }, token);
    expect(r.status).toBe(200);
    expect(estado.tablas.avisos_fotos_curso.map((a: any) => a.colegio_id)).toEqual(['otro']);
    expect(estado.tablas.avisos_fotos_destinatarios).toEqual([]);
  });
});

describe('PAN-8: no se borra un colegio con convenio o pedidos', () => {
  it('con convenio firmado: 409 y el convenio sigue', async () => {
    estado.tablas.colegios = [{ id: 'col-X', nombre: 'X' }];
    estado.tablas.convenios_colegios = [{ id: 'cv1', colegio_id: 'col-X' }];
    estado.tablas.pedidos = [];
    const r = await srv.pedir('DELETE', '/api/admin/colegios/col-X', undefined, token);
    expect(r.status).toBe(409);
    expect(r.json.error).toContain('ocultalo en vez de borrarlo');
    expect(estado.tablas.colegios).toHaveLength(1);
  });

  it('con pedidos: 409; sin nada: se borra; y se puede ocultar por PUT', async () => {
    estado.tablas.colegios = [{ id: 'col-Y', nombre: 'Y', activo_publico: true }, { id: 'col-Z', nombre: 'Z' }];
    estado.tablas.convenios_colegios = [];
    estado.tablas.pedidos = [{ id: 'p', colegio_id: 'col-Y' }];
    expect((await srv.pedir('DELETE', '/api/admin/colegios/col-Y', undefined, token)).status).toBe(409);
    expect((await srv.pedir('DELETE', '/api/admin/colegios/col-Z', undefined, token)).status).toBe(200);
    expect(estado.tablas.colegios.map((c) => c.id)).toEqual(['col-Y']);
    const put = await srv.pedir('PUT', '/api/admin/colegios/col-Y', { oculto: true }, token);
    expect(put.json.colegio.oculto).toBe(true);
  });

  it('si no se puede verificar, no se borra', async () => {
    estado.tablas.colegios = [{ id: 'col-W', nombre: 'W' }];
    estado.fallar = (tabla) => tabla === 'convenios_colegios';
    expect((await srv.pedir('DELETE', '/api/admin/colegios/col-W', undefined, token)).status).toBe(500);
    expect(estado.tablas.colegios).toHaveLength(1);
  });

  it('convenio-links: un error al leer firmados ya no los muestra "sin firmar"', async () => {
    estado.tablas.colegios = [{ id: 'col-V', codigo_convenio: 'CV000000000001' }];
    estado.fallar = (tabla) => tabla === 'convenios_colegios';
    expect((await srv.pedir('GET', '/api/admin/colegios/convenio-links', undefined, token)).status).toBe(500);
  });
});

describe('PAN-9 y PAN-10: nómina y estado de pagos', () => {
  it('las dos consultas de alumnos desempatan por id', async () => {
    estado.tablas.alumnos = [];
    estado.tablas.pedidos = [];
    await srv.pedir('GET', '/api/admin/alumnos?colegioId=c', undefined, token);
    await srv.pedir('GET', '/api/admin/colegios/c/estado-pagos', undefined, token);
    const deAlumnos = estado.ordenes.filter((o) => o.startsWith('alumnos:'));
    expect(deAlumnos).toHaveLength(2);
    for (const o of deAlumnos) expect(o.endsWith(',id')).toBe(true);
  });

  it('totalRecaudado suma kit + mejora del mismo alumno', async () => {
    estado.tablas.alumnos = [{ id: 'a1', colegio_id: 'col-E', nombre: 'PEREZ, ANA', grado: '1', division: 'A', turno: 'M', numero_lista: 1 }];
    estado.tablas.pedidos = [
      { id: 'k1', colegio_id: 'col-E', alumno_nombre: 'Ana Perez', estado: 'pagado', total: 30000, created_at: '2026-05-01T00:00:00Z' },
      { id: 'm1', colegio_id: 'col-E', alumno_nombre: 'Ana Perez', estado: 'pagado', total: 15000, created_at: '2026-06-01T00:00:00Z' },
      { id: 'x1', colegio_id: 'col-E', alumno_nombre: 'Ana Perez', estado: 'cancelado', total: 30000, created_at: '2026-06-02T00:00:00Z' },
    ];
    const r = await srv.pedir('GET', '/api/admin/colegios/col-E/estado-pagos', undefined, token);
    expect(r.json.resumen).toMatchObject({ totalRecaudado: 45000, alumnosPagados: 1 });
  });
});

describe('PAN-11: borrar un pedido borra su comprobante salvo que lo comparta el carrito', () => {
  it('pedido solo: se borra el comprobante', async () => {
    estado.tablas.pedidos = [{ id: 'B1', estado: 'pendiente_pago', cancelado_definitivo: false, comprobante_path: 'g1/c.jpg' }];
    const r = await srv.pedir('DELETE', '/api/admin/pedidos/B1', undefined, token);
    expect(r.status).toBe(200);
    expect(removidos('comprobantes')).toEqual(['g1/c.jpg']);
  });

  it('hermano del mismo carrito con el mismo comprobante: no se borra', async () => {
    estado.tablas.pedidos = [
      { id: 'B2', grupo_pago_id: 'G', estado: 'pendiente_pago', cancelado_definitivo: false, comprobante_path: 'g2/c.jpg' },
      { id: 'B3', grupo_pago_id: 'G', estado: 'pendiente_pago', cancelado_definitivo: false, comprobante_path: 'g2/c.jpg' },
    ];
    expect((await srv.pedir('DELETE', '/api/admin/pedidos/B2', undefined, token)).status).toBe(200);
    expect(removidos('comprobantes')).toHaveLength(0);
    expect(pedidos().map((p) => p.id)).toEqual(['B3']);
  });

  it('si falla el borrado de pedido_fotos, el pedido no se borra', async () => {
    estado.tablas.pedidos = [{ id: 'B4', estado: 'pendiente_pago', cancelado_definitivo: false, comprobante_path: null }];
    estado.fallar = (tabla, op) => tabla === 'pedido_fotos' && op === 'delete';
    expect((await srv.pedir('DELETE', '/api/admin/pedidos/B4', undefined, token)).status).toBe(500);
    expect(pedidos()).toHaveLength(1);
  });
});

describe('ADM-1: reimpresión con el mismo nombre en dos tamaños', () => {
  it('individual 20x30 y grupal 15x21 con el mismo nombre se registran las dos', async () => {
    estado.tablas.pedidos = [{
      id: 'R1', pedido_friendly_id: 'IFS-R1', estado: 'pagado', tipo_kit: 'impreso_digital', seleccion_pendiente: false, en_espera: false, archivado: false,
      lote_lab_id: 'lote-1', estado_lab: 'en_produccion', fotos_seleccionadas: {}, copias_extras: {},
    }];
    estado.tablas.reimpresiones_lab = [];
    const archivos = [{ nombre: 'ANA.jpg', tamano: '20x30' }, { nombre: 'ANA.jpg', tamano: '15x21' }, { nombre: 'ANA.jpg', tamano: '15x21' }];
    const r = await srv.pedir('POST', '/api/lab/pedidos/R1/reimpresion', { motivo: 'falla_laboratorio', archivos }, token);
    expect(r.status).toBe(200);
    expect(estado.tablas.reimpresiones_lab[0]).toMatchObject({ fotos_20x30: 1, fotos_15x21: 1 });
    expect(estado.tablas.reimpresiones_lab[0].archivos).toHaveLength(2);
  });
});

describe('DB-8: el aviso diario al laboratorio anota la ejecución siempre', () => {
  it('sin LAB_EMAIL (omitido) y con 0 nuevos', async () => {
    estado.tablas.pedidos = [];
    estado.tablas.tareas_programadas_estado = [];
    const omitido = await srv.pedir('POST', '/api/cron/aviso-laboratorio', {}, 'secreto-cron');
    expect(omitido.json.omitido).toBeTruthy();
    expect(estado.tablas.tareas_programadas_estado[0]).toMatchObject({ nombre: 'aviso-laboratorio', resultado: { omitido: 'Falta LAB_EMAIL' } });
    process.env.LAB_EMAIL = 'lab@prueba.test';
    try {
      const cero = await srv.pedir('POST', '/api/cron/aviso-laboratorio', {}, 'secreto-cron');
      expect(cero.json).toMatchObject({ success: true, nuevos: 0 });
      expect(estado.tablas.tareas_programadas_estado.at(-1)?.resultado).toEqual({ nuevos: 0 });
    } finally {
      delete process.env.LAB_EMAIL;
    }
  });
});
