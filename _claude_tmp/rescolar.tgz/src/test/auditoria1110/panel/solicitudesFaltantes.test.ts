// «Faltantes solicitadas» (22/10/2026, Pablo): la familia pide que le saquen (o busquen) la foto que le falta al
// chico; mientras está pendiente, el kit no se cierra sin esa foto; Pablo la ve en el panel y con «Ya está la foto»
// le llega un mail. Rutas reales (servidor/familias/solicitudesFaltantes.ts + reservas) con la base falsa.
import crypto from 'crypto';
import { afterAll, afterEach, beforeAll, beforeEach, describe, expect, it, vi } from 'vitest';
import { estado, reiniciar } from './falsoSupabase';
import { montar, type Montado } from './servidorPrueba';

vi.mock('dotenv', () => {
  const config = () => ({ parsed: {} });
  return { default: { config }, config };
});
vi.mock('@supabase/supabase-js', async () => {
  const m = await import('./falsoSupabase');
  return { createClient: () => m.clienteFalso() };
});
vi.mock('resend', async () => {
  const m = await import('./falsoSupabase');
  return { Resend: m.resendFalso() };
});

const COLEGIO = '11111111-1111-4111-8111-111111111111';
const FAMILIA = '33333333-3333-4333-8333-333333333333';
const RESERVA = '66666666-6666-4666-8666-666666666666';
const SECRETO = 'secreto-de-prueba';
let srv: Montado;
let token = '';
let curso = '';
let versionTerminos = '';
let llavePedido: (ref: string) => string;
const entornoAntes: Record<string, string | undefined> = {};
const FAMILIA_B = '44444444-4444-4444-8444-444444444444';
const llaveDe = (id: string) => crypto.createHmac('sha256', SECRETO).update(`acceso-galeria:${id}`).digest('base64url').slice(0, 32);
const acceso = llaveDe(FAMILIA);
const solicitudes = () => estado.tablas.fotos_faltantes_solicitudes || [];

beforeAll(async () => {
  for (const n of ['SUPABASE_SERVICE_ROLE_KEY', 'ADMIN_SESSION_SECRET', 'RESEND_API_KEY']) entornoAntes[n] = process.env[n];
  process.env.SUPABASE_SERVICE_ROLE_KEY = 'prueba';
  process.env.ADMIN_SESSION_SECRET = SECRETO;
  process.env.RESEND_API_KEY = 're_prueba';
  const { rutasSolicitudesFaltantes } = await import('../../../../servidor/familias/solicitudesFaltantes');
  const { rutasReservas } = await import('../../../../servidor/pagos/crearPedido');
  const { generateAdminToken } = await import('../../../../servidor/nucleo/auth');
  const { determinarCodigoCursoServidor } = await import('../../../../servidor/nucleo/codigosCurso');
  const { VERSION_TERMINOS_SERVIDOR } = await import('../../../../servidor/nucleo/legal');
  const { tokenAccesoPedido } = await import('../../../../servidor/nucleo/accesoPedidos');
  token = generateAdminToken() || '';
  curso = determinarCodigoCursoServidor('6° año', 'Mañana', 'A');
  versionTerminos = VERSION_TERMINOS_SERVIDOR;
  llavePedido = (ref) => tokenAccesoPedido(ref) as string;
  srv = await montar([rutasSolicitudesFaltantes, rutasReservas]);
}, 120_000);

afterAll(async () => {
  await srv.cerrar();
  for (const [n, v] of Object.entries(entornoAntes)) {
    if (v === undefined) delete process.env[n];
    else process.env[n] = v;
  }
});

afterEach(() => vi.useRealTimers());

beforeEach(() => {
  reiniciar();
  const pub = new Date(Date.now() - 3600_000).toISOString();
  estado.tablas.codigos_seccion = [
    { id: 's1', colegio_id: COLEGIO, grado: '6° año', turno: 'Mañana', division: 'A', codigo_secreto: 'SE12-CU34' },
    { id: 's2', colegio_id: COLEGIO, grado: '5° año', turno: 'Mañana', division: 'B', codigo_secreto: 'OT12-RO34' },
  ];
  estado.tablas.inscripciones = [
    { id: FAMILIA, colegio_id: COLEGIO, estado: 'aceptado', acceso_confirmado_at: pub, alumno_nombre: 'Gino', alumno_apellido: 'Estevez', grado: '6° año', turno: 'Mañana', division: 'A', hermanos: [] },
    { id: FAMILIA_B, colegio_id: COLEGIO, estado: 'aceptado', acceso_confirmado_at: pub, alumno_nombre: 'Gino Tomas', alumno_apellido: 'Estevez', grado: '6° año', turno: 'Mañana', division: 'A', hermanos: [] },
  ];
  estado.tablas.alumnos = [
    { id: 'aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa', colegio_id: COLEGIO, nombre: 'ESTEVEZ, Gino', grado: '6° año', division: 'A', turno: 'Mañana', fotografiado_at: null, foto_grupal_at: pub, foto_seno_at: null },
  ];
  estado.tablas.fotos = [
    { id: 'fg', colegio_id: COLEGIO, codigo_curso: curso, categoria: 'grupal', alumno_nombre: null, publicada_at: pub },
    { id: 'fi', colegio_id: COLEGIO, codigo_curso: curso, categoria: 'individual', alumno_nombre: null, publicada_at: pub },
  ];
  estado.tablas.pedidos = [{ id: RESERVA, familia_id: null, colegio_id: COLEGIO, curso_codigo: curso, alumno_nombre: 'Gino Estevez', seleccion_pendiente: true, estado: 'pagado', cancelado_definitivo: false, archivado: false, total: 30000, tipo_kit: 'impreso_digital', grupo_pago_id: null, email_enviado: true }];
});

const base = { codigo: 'SE12-CU34', familia: FAMILIA, acceso, alumnoNombre: 'Gino Estevez' };
const solicitar = (extra: Record<string, unknown> = {}) =>
  srv.pedir('POST', '/api/fotos-faltantes/solicitar', { ...base, lugar: 'individual', motivo: 'ausente', email: 'mama@prueba.test', whatsapp: '11 5555-1234', tutorNombre: 'Ana', ...extra });
const elegir = (fotos: Record<string, unknown>) =>
  srv.pedir('POST', `/api/reservas/${RESERVA}/elegir-fotos`, { codigo: 'SE12-CU34', fotos, confirmaPersonalizacion: true, versionTerminos, t: llavePedido(RESERVA) });

describe('Familia: pedir la foto que falta', () => {
  it('sin la llave de la familia no se puede pedir', async () => {
    expect((await solicitar({ acceso: 'otra' })).status).toBe(403);
    expect((await solicitar({ alumnoNombre: 'Otro Chico' })).status).toBe(403);
    expect(solicitudes()).toHaveLength(0);
  });

  it('se guarda con curso, turno y división de la sección, el motivo y lo que dice la nómina; repetido no duplica', async () => {
    const r = await solicitar();
    expect(r.status).toBe(200);
    expect(solicitudes()).toHaveLength(1);
    expect(solicitudes()[0]).toMatchObject({ grado: '6° año', division: 'A', turno: 'Mañana', lugar: 'individual', motivo: 'ausente', estado: 'pendiente', contacto_email: 'mama@prueba.test', nomina_tiene_foto: false });
    expect((await solicitar()).json.repetida).toBe(true);
    expect(solicitudes()).toHaveLength(1);
  });

  it('revisión 22/10: se guarda el nombre de la inscripción; texto inventado, otro curso u otra familia parecida no pasan', async () => {
    expect((await solicitar({ alumnoNombre: 'Gino Estevez Ana Gomez Luis Diaz' })).status).toBe(403);
    expect((await solicitar({ codigo: 'OT12-RO34' })).status).toBe(403); // la llave es de 6° A, no de 5° B
    expect((await solicitar({ alumnoNombre: 'gino  ESTÉVEZ' })).status).toBe(200);
    expect(solicitudes()[0].alumno_nombre).toBe('Gino Estevez');
    // Otra familia del curso con un hijo de nombre parecido («Gino Tomas Estevez»): no ve, no cancela y no se frena.
    const otra = { codigo: 'SE12-CU34', familia: FAMILIA_B, acceso: llaveDe(FAMILIA_B), alumnoNombre: 'Gino Tomas Estevez' };
    expect((await srv.pedir('POST', '/api/fotos-faltantes/estado', otra)).json.solicitudes).toEqual([]);
    expect((await srv.pedir('POST', `/api/fotos-faltantes/${solicitudes()[0].id}/cancelar`, otra)).status).toBe(404);
    expect(solicitudes()[0].estado).toBe('pendiente');
    const suya = await srv.pedir('POST', '/api/fotos-faltantes/solicitar', { ...otra, lugar: 'individual', motivo: 'no_quiso', email: 'papa@prueba.test' });
    expect(suya.status).toBe(200);
    expect(suya.json.repetida).toBeUndefined();
    expect(solicitudes().map((x) => x.alumno_nombre).sort()).toEqual(['Gino Estevez', 'Gino Tomas Estevez']);
  });

  it('pide motivo y email válidos', async () => {
    expect((await solicitar({ motivo: 'no_le_gusto' })).status).toBe(400);
    expect((await solicitar({ email: 'x' })).status).toBe(400);
  });

  it('después del 15/11 ya no se puede pedir', async () => {
    vi.useFakeTimers({ toFake: ['Date'] });
    vi.setSystemTime(new Date('2026-11-16T03:00:01Z')); // 16/11 00:00:01 en Argentina
    const r = await solicitar();
    expect(r.status).toBe(410);
    vi.setSystemTime(new Date('2026-11-16T02:59:00Z')); // 15/11 23:59 en Argentina
    expect((await solicitar()).status).toBe(200);
  });
});

describe('Pedido en espera', () => {
  it('con la foto pedida, el kit no se cierra «sin individual»; al cancelar el pedido de foto, sí', async () => {
    await solicitar();
    const frenado = await elegir({ grupalId: 'fg', individualId: '', sinFoto: ['individual'] });
    expect(frenado.status).toBe(400);
    expect(frenado.json.error).toMatch(/Pediste que le saquemos la foto individual/);
    expect(estado.tablas.pedidos[0].seleccion_pendiente).toBe(true);

    const id = solicitudes()[0].id;
    expect((await srv.pedir('POST', `/api/fotos-faltantes/${id}/cancelar`, base)).status).toBe(200);
    expect(solicitudes()[0]).toMatchObject({ estado: 'cancelada', cancelada_por: 'familia' });
    // 26/10: el kit lleva 3 fotos: sin pedido de foto ya no queda en espera, pero tiene que elegir otra en su lugar.
    expect((await elegir({ grupalId: 'fg', individualId: '', sinFoto: ['individual'] })).json.error).toMatch(/lleva siempre/);
    expect((await elegir({ grupalId: 'fg', individualId: 'fi', sinFoto: ['individual'] })).status).toBe(200);
  });

  it('si la familia ya elige una foto para ese lugar, no se frena', async () => {
    await solicitar();
    expect((await elegir({ grupalId: 'fg', individualId: 'fi' })).status).toBe(200);
  });

  it('la familia ve sus pedidos pendientes', async () => {
    await solicitar();
    const r = await srv.pedir('POST', '/api/fotos-faltantes/estado', base);
    expect(r.status).toBe(200);
    expect(r.json).toMatchObject({ abierto: true, solicitudes: [{ lugar: 'individual', estado: 'pendiente' }] });
  });
});

describe('Panel «Faltantes»', () => {
  it('sólo con la sesión del panel', async () => {
    expect((await srv.pedir('GET', `/api/admin/fotos-faltantes?colegioId=${COLEGIO}`)).status).toBe(401);
  });

  it('lista, y «Ya está la foto» la resuelve y manda UN mail (un segundo clic no repite)', async () => {
    await solicitar();
    const lista = await srv.pedir('GET', `/api/admin/fotos-faltantes?colegioId=${COLEGIO}`, undefined, token);
    expect(lista.json.solicitudes).toHaveLength(1);
    const id = lista.json.solicitudes[0].id;
    // 25/10: sin una individual publicada DESPUÉS del pedido no se manda «ya publicamos» (salvo `forzar`).
    solicitudes()[0].created_at = new Date(Date.now() - 60_000).toISOString();
    const sinFoto = await srv.pedir('POST', `/api/admin/fotos-faltantes/${id}/resolver`, {}, token);
    expect(sinFoto.status).toBe(409);
    expect(sinFoto.json.codigo).toBe('SIN_FOTO_PUBLICADA');
    expect(solicitudes()[0].estado).toBe('pendiente');
    expect(estado.mails).toHaveLength(0);
    estado.tablas.fotos.push({ id: 'fi2', colegio_id: COLEGIO, codigo_curso: curso, categoria: 'individual', alumno_nombre: null, publicada_at: new Date().toISOString() });
    const r = await srv.pedir('POST', `/api/admin/fotos-faltantes/${id}/resolver`, {}, token);
    expect(r.status).toBe(200);
    expect(r.json.avisoEnviado).toBe(true);
    expect(solicitudes()[0].estado).toBe('resuelta');
    expect(estado.mails).toHaveLength(1);
    expect(estado.mails[0]).toMatchObject({ to: ['mama@prueba.test'] });
    expect(estado.mails[0].subject).toMatch(/Gino Estevez/);
    expect((await srv.pedir('POST', `/api/admin/fotos-faltantes/${id}/resolver`, {}, token)).status).toBe(200);
    expect(estado.mails).toHaveLength(1);
    // Resuelto, el kit ya no está frenado.
    expect((await elegir({ grupalId: 'fg', individualId: 'fi' })).status).toBe(200);
  });

  it('«Descartar» lo cancela y libera el kit', async () => {
    await solicitar();
    const id = solicitudes()[0].id;
    expect((await srv.pedir('POST', `/api/admin/fotos-faltantes/${id}/descartar`, {}, token)).status).toBe(200);
    expect(solicitudes()[0]).toMatchObject({ estado: 'cancelada', cancelada_por: 'admin' });
    // 25/10: la familia recibe un mail neutro (sin hablar de repetir fotos) y no puede volver a pedirla enseguida.
    expect(estado.mails).toHaveLength(1);
    expect(estado.mails[0].subject).toMatch(/Ya podés cerrar el kit/);
    expect(estado.mails[0].html).not.toMatch(/repet/i);
    const otra = await solicitar();
    expect(otra.status).toBe(409);
    expect(otra.json.codigo).toBe('YA_REVISADO');
    // 26/10: el kit lleva 3 fotos: sin pedido de foto ya no queda en espera, pero tiene que elegir otra en su lugar.
    expect((await elegir({ grupalId: 'fg', individualId: '', sinFoto: ['individual'] })).json.error).toMatch(/lleva siempre/);
    expect((await elegir({ grupalId: 'fg', individualId: 'fi', sinFoto: ['individual'] })).status).toBe(200);
  });

  it('25/10: «Ya está la foto» con `forzar` avisa aunque no encuentre la foto publicada', async () => {
    await solicitar();
    const id = solicitudes()[0].id;
    solicitudes()[0].created_at = new Date().toISOString();
    const r = await srv.pedir('POST', `/api/admin/fotos-faltantes/${id}/resolver`, { forzar: true }, token);
    expect(r.status).toBe(200);
    expect(solicitudes()[0].estado).toBe('resuelta');
  });
});
