// Nómina del panel: la marca de «fotografiado» se guarda en el servidor (13/10/2026, Pablo: «los alumnos que
// fotografiamos hoy, y tildamos, no están»: antes vivía sólo en la memoria del navegador). Ruta REAL, base falsa.
import { afterAll, beforeAll, beforeEach, describe, expect, it, vi } from 'vitest';
import { estado, reiniciar } from './falsoSupabase';
import { montar, type Montado } from './servidorPrueba';

vi.mock('dotenv', () => {
  const config = () => ({ parsed: {} });
  return { default: { config }, config };
});
vi.mock('@supabase/supabase-js', async () => {
  const m = await import('./falsoSupabase');
  return { createClient: () => m.clienteFalso() };
});
vi.mock('resend', async () => {
  const m = await import('./falsoSupabase');
  return { Resend: m.resendFalso() };
});

const A1 = 'aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaa1';
const A2 = 'aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaa2';
const A3 = 'aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaa3';
let srv: Montado;
let token = '';
const entornoAntes: Record<string, string | undefined> = {};
const alumno = (id: string) => (estado.tablas.alumnos || []).find((a: any) => a.id === id);
const marcar = (cuerpo: any, conToken = true) => srv.pedir('POST', '/api/admin/alumnos/fotografiados', cuerpo, conToken ? token : undefined);

beforeAll(async () => {
  for (const n of ['SUPABASE_SERVICE_ROLE_KEY', 'ADMIN_SESSION_SECRET']) entornoAntes[n] = process.env[n];
  process.env.SUPABASE_SERVICE_ROLE_KEY = 'prueba';
  process.env.ADMIN_SESSION_SECRET = 'secreto-de-prueba';
  const { rutasCursosNomina } = await import('../../../../servidor/familias/cursosNomina');
  const { rutasPanelPedidos } = await import('../../../../servidor/panel/pedidos');
  const { generateAdminToken } = await import('../../../../servidor/nucleo/auth');
  token = generateAdminToken() || '';
  srv = await montar([rutasCursosNomina, rutasPanelPedidos]);
}, 120_000);

afterAll(async () => {
  await srv.cerrar();
  for (const [n, v] of Object.entries(entornoAntes)) {
    if (v === undefined) delete process.env[n];
    else process.env[n] = v;
  }
});

beforeEach(() => {
  reiniciar();
  estado.tablas.alumnos = [
    { id: A1, colegio_id: 'col-1', nombre: 'PEREZ, ANA', grado: '4° grado', division: 'C', turno: 'Tarde', numero_lista: 1, fotografiado_at: null },
    { id: A2, colegio_id: 'col-1', nombre: 'GOMEZ, LUZ', grado: '4° grado', division: 'C', turno: 'Tarde', numero_lista: 2, fotografiado_at: null },
    { id: A3, colegio_id: 'col-1', nombre: 'DIAZ, SOL', grado: '4° grado', division: 'C', turno: 'Tarde', numero_lista: 3, fotografiado_at: '2026-10-13T12:00:00Z' },
  ];
});

describe('POST /api/admin/alumnos/fotografiados', () => {
  it('marca uno o varios y queda guardado: al volver a traer la nómina siguen marcados', async () => {
    const r = await marcar({ ids: [A1, A2], fotografiado: true });
    expect(r.status).toBe(200);
    expect(r.json.alumnos).toHaveLength(2);
    expect(alumno(A1).fotografiado_at).toBeTruthy();
    expect(alumno(A2).fotografiado_at).toBeTruthy();
    const nomina = await srv.pedir('GET', '/api/admin/alumnos', undefined, token);
    expect(nomina.json.alumnos.filter((a: any) => a.fotografiado_at).map((a: any) => a.id).sort()).toEqual([A1, A2, A3]);
  });

  it('desmarca', async () => {
    expect((await marcar({ ids: [A3], fotografiado: false })).status).toBe(200);
    expect(alumno(A3).fotografiado_at).toBeNull();
  });

  it('datos inválidos o sin sesión de admin: no cambia nada', async () => {
    expect((await marcar({ ids: [], fotografiado: true })).status).toBe(400);
    expect((await marcar({ ids: ['no-es-uuid'], fotografiado: true })).status).toBe(400);
    expect((await marcar({ ids: [A1], fotografiado: 'si' })).status).toBe(400);
    expect((await marcar({ ids: [A1], fotografiado: true }, false)).status).toBe(401);
    expect(alumno(A1).fotografiado_at).toBeNull();
  });

  it('si la base falla responde 500 (el panel vuelve atrás la marca y avisa)', async () => {
    estado.fallar = (tabla: string, op: string) => tabla === 'alumnos' && op === 'update';
    expect((await marcar({ ids: [A1], fotografiado: true })).status).toBe(500);
    expect(alumno(A1).fotografiado_at).toBeNull();
  });
});

// 14/10/2026 (noche): la foto grupal se marca aparte (`foto: 'grupal'` → alumnos.foto_grupal_at).
describe('POST /api/admin/alumnos/fotografiados con foto grupal', () => {
  it('marca y desmarca la grupal sin tocar el fotografiado, y la nómina la trae', async () => {
    const r = await marcar({ ids: [A3], fotografiado: true, foto: 'grupal' });
    expect(r.status).toBe(200);
    expect(alumno(A3).foto_grupal_at).toBeTruthy();
    expect(alumno(A3).fotografiado_at).toBe('2026-10-13T12:00:00Z');
    expect(r.json.alumnos[0]).toMatchObject({ id: A3, fotografiado_at: '2026-10-13T12:00:00Z' });
    const nomina = await srv.pedir('GET', '/api/admin/alumnos', undefined, token);
    expect(nomina.json.alumnos.find((a: any) => a.id === A3).foto_grupal_at).toBeTruthy();
    expect((await marcar({ ids: [A3], fotografiado: false, foto: 'grupal' })).status).toBe(200);
    expect(alumno(A3).foto_grupal_at).toBeNull();
    expect(alumno(A3).fotografiado_at).toBe('2026-10-13T12:00:00Z');
  });

  it('una foto que no existe da 400', async () => {
    expect((await marcar({ ids: [A1], fotografiado: true, foto: 'docente' })).status).toBe(400);
    expect(alumno(A1).fotografiado_at).toBeNull();
  });
});

// 21/10/2026: la foto con la seño se marca aparte (`foto: 'seno'` → alumnos.foto_seno_at).
describe('POST /api/admin/alumnos/fotografiados con foto con la seño', () => {
  it('marca y desmarca la seño sin tocar la individual ni la grupal, y la nómina la trae', async () => {
    const antes = { fotografiado_at: alumno(A2).fotografiado_at ?? null, foto_grupal_at: alumno(A2).foto_grupal_at ?? null };
    const r = await marcar({ ids: [A2], fotografiado: true, foto: 'seno' });
    expect(r.status).toBe(200);
    expect(alumno(A2).foto_seno_at).toBeTruthy();
    expect(alumno(A2).fotografiado_at ?? null).toEqual(antes.fotografiado_at);
    expect(alumno(A2).foto_grupal_at ?? null).toEqual(antes.foto_grupal_at);
    const nomina = await srv.pedir('GET', '/api/admin/alumnos', undefined, token);
    expect(nomina.json.alumnos.find((a: any) => a.id === A2).foto_seno_at).toBeTruthy();
    expect((await marcar({ ids: [A2], fotografiado: false, foto: 'seno' })).status).toBe(200);
    expect(alumno(A2).foto_seno_at).toBeNull();
  });
  it('rechaza una foto que no existe', async () => {
    expect((await marcar({ ids: [A2], fotografiado: true, foto: 'toString' })).status).toBe(400);
  });
});
