// Auditoría 14/10/2026 (panel): pruebas de los arreglos de envíos duplicados, avisos que no se podían reenviar
// y carreras del panel. Corren las rutas REALES de Express sobre la base, el Storage y el Resend falsos
// (falsoSupabase.ts: Resend descarta un segundo envío con la misma clave de idempotencia, como el real).
import { readFileSync } from 'fs';
import path from 'path';
import { afterAll, beforeAll, beforeEach, describe, expect, it, vi } from 'vitest';
import { clienteFalso, estado, reiniciar } from './falsoSupabase';
import { montar, type Montado } from './servidorPrueba';
import { fuenteServidor } from '../../fuenteServidor';

vi.mock('dotenv', () => {
  const config = () => ({ parsed: {} });
  return { default: { config }, config };
});
vi.mock('@supabase/supabase-js', async () => {
  const m = await import('./falsoSupabase');
  return { createClient: () => m.clienteFalso() };
});
vi.mock('resend', async () => {
  const m = await import('./falsoSupabase');
  return { Resend: m.resendFalso() };
});

const UUID = (n: number) => `00000000-0000-4000-8000-${String(n).padStart(12, '0')}`;
const COL = UUID(900);
let srv: Montado;
let token = '';
const entornoAntes: Record<string, string | undefined> = {};
const tabla = (t: string) => estado.tablas[t] || [];
const migracion = (nombre: string) => readFileSync(path.resolve(__dirname, '../../../../supabase/migrations', nombre), 'utf8');

beforeAll(async () => {
  for (const n of ['SUPABASE_SERVICE_ROLE_KEY', 'RESEND_API_KEY', 'ADMIN_SESSION_SECRET']) entornoAntes[n] = process.env[n];
  process.env.SUPABASE_SERVICE_ROLE_KEY = 'prueba';
  process.env.RESEND_API_KEY = 'prueba';
  process.env.ADMIN_SESSION_SECRET = 'secreto-de-prueba';
  const { rutasAvisosFotos } = await import('../../../../servidor/panel/avisosFotos');
  const { rutasFotosPanel } = await import('../../../../servidor/panel/fotos');
  const { rutasPanelPedidos } = await import('../../../../servidor/panel/pedidos');
  const { rutasInscripciones } = await import('../../../../servidor/familias/inscripciones');
  const { rutasInscripcionesAdmin } = await import('../../../../servidor/familias/inscripcionesAdmin');
  const { rutasConsultasAdmin } = await import('../../../../servidor/familias/consultasAdmin');
  const { rutasSolicitudesCodigo } = await import('../../../../servidor/familias/solicitudesCodigo');
  const { rutasResend } = await import('../../../../servidor/entrega/rutasResend');
  const { rutasObservaciones } = await import('../../../../servidor/panel/observaciones');
  const { rutasBorradores } = await import('../../../../servidor/panel/borradores');
  const { rutasLaboratorio } = await import('../../../../servidor/panel/laboratorio');
  const { generateAdminToken } = await import('../../../../servidor/nucleo/auth');
  token = generateAdminToken() || '';
  srv = await montar([
    rutasPanelPedidos, rutasObservaciones, rutasBorradores, rutasLaboratorio, rutasAvisosFotos, rutasFotosPanel,
    rutasInscripciones, rutasInscripcionesAdmin, rutasConsultasAdmin, rutasSolicitudesCodigo, rutasResend,
  ]);
}, 120_000);

afterAll(async () => {
  await srv.cerrar();
  for (const [n, v] of Object.entries(entornoAntes)) {
    if (v === undefined) delete process.env[n];
    else process.env[n] = v;
  }
});

beforeEach(() => reiniciar());

describe('1: aviso «ya están tus fotos» por curso (avisos_fotos_curso)', () => {
  const foto = (n: number, publicada: string | null = null) => ({
    id: UUID(n), colegio_id: COL, codigo_curso: 'GRADO1-ATM', grado: '1° grado', turno: 'Mañana', division: 'A', categoria: 'grupal', publicada_at: publicada,
  });
  const preparar = () => {
    estado.tablas.fotos = [foto(1)];
    estado.tablas.inscripciones = [{ id: 'i1', email: 'fam1@prueba.test', estado: 'aceptado', colegio_id: COL, grado: '1° grado', turno: 'Mañana', division: 'A', alumno_nombre: 'Ana', padre_nombre: 'Pa', colegio_nombre: 'Col' }];
    estado.tablas.pedidos = [];
  };
  const publicar = () => srv.pedir('POST', '/api/admin/fotos/publicar', { colegioId: COL, codigoCurso: 'GRADO1-ATM' }, token);

  it('al publicar avisa y anota el curso SÓLO cuando Resend confirmó', async () => {
    preparar();
    const r = await publicar();
    expect(r.json).toMatchObject({ success: true, publicadas: 1, emailsEnviados: 1 });
    expect(r.json.warning).toBeUndefined();
    expect(estado.resend.lotes).toHaveLength(1);
    expect(tabla('avisos_fotos_curso')).toEqual([expect.objectContaining({ colegio_id: COL, codigo_curso: 'GRADO1-ATM', enviados: 1 })]);
    // Más fotos del mismo curso: ya fue avisado, no se repite.
    estado.tablas.fotos.push(foto(2));
    const otra = await publicar();
    expect(otra.json).toMatchObject({ success: true, publicadas: 1, emailsEnviados: 0 });
    expect(estado.resend.lotes).toHaveLength(1);
  });

  it('si Resend falla: no se anota, avisa con `warning` y la próxima publicación lo vuelve a intentar', async () => {
    preparar();
    estado.resend.fallar = () => true;
    const r = await publicar();
    expect(r.json).toMatchObject({ success: true, publicadas: 1, emailsEnviados: 0 });
    expect(r.json.warning).toMatch(/Reenviar aviso a las familias/);
    expect(tabla('avisos_fotos_curso')).toHaveLength(0);
    estado.resend.fallar = null;
    estado.tablas.fotos.push(foto(2));
    const despues = await publicar();
    expect(despues.json.emailsEnviados).toBe(1);
    expect(tabla('avisos_fotos_curso')).toHaveLength(1);
  });

  it('un curso ya anotado (p. ej. por la migración) no se vuelve a avisar', async () => {
    preparar();
    estado.tablas.avisos_fotos_curso = [{ colegio_id: COL, codigo_curso: 'GRADO1-ATM', enviados: 0 }];
    const r = await publicar();
    expect(r.json.emailsEnviados).toBe(0);
    expect(estado.resend.lotes).toHaveLength(0);
  });

  it('«Reenviar aviso» manda aunque el curso ya esté anotado, pero un doble clic no duplica; pide fotos publicadas y sesión', async () => {
    preparar();
    estado.tablas.fotos = [foto(1, '2026-10-01T10:00:00Z')];
    estado.tablas.avisos_fotos_curso = [{ colegio_id: COL, codigo_curso: 'GRADO1-ATM', enviados: 0 }];
    const cuerpo = { colegioId: COL, codigoCurso: 'GRADO1-ATM' };
    const [a, b] = await Promise.all([srv.pedir('POST', '/api/admin/fotos/reenviar-aviso', cuerpo, token), srv.pedir('POST', '/api/admin/fotos/reenviar-aviso', cuerpo, token)]);
    expect(a.json.success && b.json.success).toBe(true);
    expect(estado.resend.lotes).toHaveLength(1);
    expect(estado.resend.lotes[0][0].clave).toMatch(/^fotos-online-[0-9a-f]+-reenvio-\d+$/);
    expect(tabla('avisos_fotos_curso')[0].enviados).toBe(1);
    expect((await srv.pedir('POST', '/api/admin/fotos/reenviar-aviso', { colegioId: COL, codigoCurso: 'OTRO' }, token)).status).toBe(400);
    expect((await srv.pedir('POST', '/api/admin/fotos/reenviar-aviso', cuerpo)).status).toBe(401);
  });

  it('25/10/2026: si Resend rechaza a una familia, «Reenviar aviso» le escribe sólo a ella (no duplica a las demás)', async () => {
    preparar();
    estado.tablas.inscripciones.push(
      { id: 'i2', email: 'fam2@prueba.test', estado: 'aceptado', colegio_id: COL, grado: '1° grado', turno: 'Mañana', division: 'A', alumno_nombre: 'Beto', padre_nombre: 'Pe', colegio_nombre: 'Col' },
      { id: 'i3', email: 'Fam3@Prueba.test', estado: 'aceptado', colegio_id: COL, grado: '1° grado', turno: 'Mañana', division: 'A', alumno_nombre: 'Cami', padre_nombre: 'Pi', colegio_nombre: 'Col' },
    );
    estado.resend.rechazar = (d) => d.to[0] === 'fam2@prueba.test';
    const r = await publicar();
    expect(r.json).toMatchObject({ success: true, emailsEnviados: 2 });
    expect(r.json.warning).toMatch(/Reenviar aviso/);
    expect(tabla('avisos_fotos_destinatarios')).toHaveLength(2);
    expect(JSON.stringify(tabla('avisos_fotos_destinatarios'))).not.toContain('@'); // sólo el hash, nunca el email
    estado.resend.rechazar = null;
    const cuerpo = { colegioId: COL, codigoCurso: 'GRADO1-ATM' };
    const re = await srv.pedir('POST', '/api/admin/fotos/reenviar-aviso', cuerpo, token);
    expect(re.json).toMatchObject({ success: true, emailsEnviados: 1, destinatarios: 1, yaAvisados: 2 });
    expect(estado.resend.lotes.at(-1)!.map((m) => m.to[0])).toEqual(['fam2@prueba.test']);
    // Todas avisadas: otro reenvío no manda nada y lo dice.
    estado.resend.claves.clear();
    const otra = await srv.pedir('POST', '/api/admin/fotos/reenviar-aviso', cuerpo, token);
    expect(otra.json).toMatchObject({ success: true, emailsEnviados: 0, yaAvisados: 3 });
    expect(otra.json.warning).toMatch(/ya habían recibido el aviso/);
    expect(estado.resend.lotes).toHaveLength(2);
  });

  it('25/10/2026: si falla la lectura de a quién ya se avisó (error pasajero), no se manda a todo el curso', async () => {
    preparar();
    estado.fallar = (t, op) => (t === 'avisos_fotos_destinatarios' && op === 'select' ? 'XX000' : false);
    const r = await publicar();
    expect(r.json).toMatchObject({ success: true, publicadas: 1, emailsEnviados: 0 });
    expect(r.json.warning).toMatch(/Reenviar aviso/);
    expect(estado.resend.lotes).toHaveLength(0);
    expect(tabla('avisos_fotos_curso')).toHaveLength(0);
  });

  it('14/10/2026: sin la tabla avisos_fotos_curso (migración sin aplicar) no queda «incompleto» y el listado da vacío', async () => {
    preparar();
    for (const codigo of ['42P01', 'PGRST205']) {
      estado.tablas.fotos = [foto(1)];
      estado.resend = { claves: new Set<string>(), fallar: null, lotes: [], rechazar: null };
      estado.tablas.avisos_fotos_destinatarios = [];
      estado.fallar = (t) => (t === 'avisos_fotos_curso' ? codigo : false);
      const r = await publicar();
      expect(r.json).toMatchObject({ success: true, publicadas: 1, emailsEnviados: 1 });
      expect(r.json.warning).toBeUndefined();
      const lista = await srv.pedir('GET', `/api/admin/fotos/avisos?colegioId=${COL}`, undefined, token);
      expect(lista.status).toBe(200);
      expect(lista.json).toEqual({ success: true, avisos: [] });
    }
    // Otro error de la base sí sigue siendo 500.
    estado.fallar = (t) => t === 'avisos_fotos_curso';
    expect((await srv.pedir('GET', `/api/admin/fotos/avisos?colegioId=${COL}`, undefined, token)).status).toBe(500);
  });

  it('la migración crea la tabla y anota como avisados los cursos que ya tienen fotos publicadas', () => {
    const sql = migracion('20261014020100_avisos_fotos_curso.sql');
    expect(sql).toContain('create table if not exists public.avisos_fotos_curso');
    expect(sql).toContain('primary key (colegio_id, codigo_curso)');
    expect(sql).toMatch(/insert into public\.avisos_fotos_curso[\s\S]*min\(publicada_at\), 0[\s\S]*where publicada_at is not null and colegio_id is not null and codigo_curso is not null[\s\S]*on conflict do nothing/);
  });
});

describe('2: «En producción» / «Listo» no se duplican (sólo `reenvio: true` repite)', () => {
  const id = UUID(2);
  const cuerpo = (extra: Record<string, unknown> = {}) => ({ tipo: 'en_produccion', destinatarios: [{ pedidoId: id, to: 'f@prueba.test', tutorNombre: 'F', alumnoNombre: 'Ana', colegioNombre: 'Col' }], ...extra });
  beforeEach(() => {
    estado.tablas.pedidos = [{ id, estado: 'pagado', estado_lab: 'en_produccion', en_espera: false, archivado: false, seleccion_pendiente: false, tipo_kit: 'solo_digital', lote_lab_id: null, fecha_envio_produccion: '2026-10-10T10:00:00Z' }];
  });

  it('sin `reenvio`, el que ya está en esa etapa se saltea (yaAvisados) y no recibe otro email', async () => {
    const r = await srv.pedir('POST', '/api/admin/pedidos/notificar-estado', cuerpo(), token);
    expect(r.status).toBe(200);
    expect(r.json).toMatchObject({ success: true, enviados: 0, yaAvisados: 1, idsYaAvisados: [id] });
    expect(estado.mails).toHaveLength(0);
  });

  it('con `reenvio: true` sale, pero dos clics seguidos mandan uno solo', async () => {
    await srv.pedir('POST', '/api/admin/pedidos/notificar-estado', cuerpo({ reenvio: true }), token);
    await srv.pedir('POST', '/api/admin/pedidos/notificar-estado', cuerpo({ reenvio: true }), token);
    expect(estado.mails).toHaveLength(1);
    expect(estado.mails[0].clave).toMatch(/^estado-en_produccion-.*-r\d+$/);
  });
});

describe('3, 6 y 16: acciones del panel sobre una inscripción', () => {
  const insc = (extra: Record<string, unknown> = {}) => ({ id: 'ins1', estado: 'aceptado', email: 'f@prueba.test', codigo_asignado: 'ABC123', padre_nombre: 'Pa', colegio_nombre: 'Col', alumno_nombre: 'Ana', notificacion_email_enviada: false, ...extra });

  it('«Enviar todos los pendientes» en dos pestañas: el email con el código sale una sola vez', async () => {
    estado.tablas.inscripciones = [insc()];
    const [a, b] = await Promise.all([
      srv.pedir('POST', '/api/admin/inscripciones/ins1/enviar-email', {}, token),
      srv.pedir('POST', '/api/admin/inscripciones/ins1/enviar-email', {}, token),
    ]);
    expect(a.json.success && b.json.success).toBe(true);
    expect([a.json.yaEnviado, b.json.yaEnviado].filter(Boolean)).toHaveLength(1);
    expect(estado.mails).toHaveLength(1);
    expect(estado.mails[0].clave).toMatch(/^codigo-acceso-ins1-[0-9a-f]{16}$/);
    expect(estado.mails[0].clave).not.toContain('ABC123');
    expect(tabla('inscripciones')[0].notificacion_email_enviada).toBe(true);
  });

  it('si el envío falla, la marca se libera (queda pendiente para reintentar)', async () => {
    estado.tablas.inscripciones = [insc()];
    estado.resend.fallar = () => true;
    const r = await srv.pedir('POST', '/api/admin/inscripciones/ins1/enviar-email', {}, token);
    expect(r.status).toBe(502);
    expect(tabla('inscripciones')[0].notificacion_email_enviada).toBe(false);
  });

  it('el botón manual (`reenviar: true`) sí lo manda aunque ya figure enviado', async () => {
    estado.tablas.inscripciones = [insc({ notificacion_email_enviada: true })];
    expect((await srv.pedir('POST', '/api/admin/inscripciones/ins1/enviar-email', {}, token)).json.yaEnviado).toBe(true);
    expect(estado.mails).toHaveLength(0);
    const r = await srv.pedir('POST', '/api/admin/inscripciones/ins1/enviar-email', { reenviar: true }, token);
    expect(r.json.success).toBe(true);
    expect(estado.mails).toHaveLength(1);
    expect(estado.mails[0].clave).toMatch(/-r\d+$/);
  });

  it('«Rechazar» no pisa una inscripción ya aprobada (409), salvo `forzar`', async () => {
    estado.tablas.inscripciones = [insc()];
    const r = await srv.pedir('POST', '/api/admin/inscripciones/ins1/rechazar', {}, token);
    expect(r.status).toBe(409);
    expect(tabla('inscripciones')[0].estado).toBe('aceptado');
    expect((await srv.pedir('POST', '/api/admin/inscripciones/ins1/rechazar', { forzar: true }, token)).status).toBe(200);
    expect(tabla('inscripciones')[0].estado).toBe('rechazado');
    estado.tablas.inscripciones = [insc({ id: 'ins2', estado: 'pendiente' })];
    expect((await srv.pedir('POST', '/api/admin/inscripciones/ins2/rechazar', {}, token)).json.success).toBe(true);
    expect((await srv.pedir('POST', '/api/admin/inscripciones/nada/rechazar', {}, token)).status).toBe(404);
  });

  it('«Abrir chat de WhatsApp» deja anotado el WhatsApp enviado', async () => {
    estado.tablas.inscripciones = [insc()];
    const r = await srv.pedir('POST', '/api/admin/inscripciones/ins1/whatsapp-enviado', undefined, token);
    expect(r.json).toMatchObject({ success: true, inscripcion: { notificacion_whatsapp_enviada: true } });
    expect((await srv.pedir('POST', '/api/admin/inscripciones/ins1/whatsapp-enviado')).status).toBe(401);
    expect((await srv.pedir('POST', '/api/admin/inscripciones/nada/whatsapp-enviado', undefined, token)).status).toBe(404);
  });
});

describe('4 y 7: respuestas a familias sin duplicados y «Archivar» sin enterrar una respuesta nueva', () => {
  beforeEach(() => {
    estado.tablas.consultas_familias = [{ id: 'c1', nombre: 'Fam', email: 'f@prueba.test', asunto: 'Duda', estado: 'nueva' }];
    estado.tablas.consultas_familias_mensajes = [];
  });

  it('«Responder» con la misma clave (reintento tras un corte) manda y guarda una sola vez', async () => {
    const cuerpo = { mensaje: 'Hola, ya está.', clave: 'clave-uno-1234' };
    const a = await srv.pedir('POST', '/api/admin/consultas-familias/c1/responder', cuerpo, token);
    const b = await srv.pedir('POST', '/api/admin/consultas-familias/c1/responder', cuerpo, token);
    expect(a.json).toMatchObject({ success: true, yaEnviada: false });
    expect(b.json).toMatchObject({ success: true, yaEnviada: true });
    expect(estado.mails).toHaveLength(1);
    expect(estado.mails[0].clave).toBe('respuesta-c1-clave-uno-1234');
    expect(tabla('consultas_familias_mensajes')).toEqual([expect.objectContaining({ consulta_id: 'c1', clave_envio: 'clave-uno-1234' })]);
    // Otro texto = otra clave: sale.
    await srv.pedir('POST', '/api/admin/consultas-familias/c1/responder', { mensaje: 'Otra cosa', clave: 'clave-dos-1234' }, token);
    expect(estado.mails).toHaveLength(2);
  });

  it('«Escribir a esta familia» reintentado con la misma clave reusa la conversación y no duplica el email', async () => {
    estado.tablas.consultas_familias = [];
    const cuerpo = { nombre: 'Fam', email: 'f@prueba.test', asunto: 'Tu kit', mensaje: 'Ya está pago.', clave: 'clave-ini-1234' };
    const a = await srv.pedir('POST', '/api/admin/consultas-familias/iniciar', cuerpo, token);
    const b = await srv.pedir('POST', '/api/admin/consultas-familias/iniciar', cuerpo, token);
    expect(a.json.success && b.json.success).toBe(true);
    expect(b.json.consultaId).toBe(a.json.consultaId);
    expect(tabla('consultas_familias')).toHaveLength(1);
    expect(estado.mails).toHaveLength(1);
  });

  it('14/10/2026: «Escribir a esta familia» que choca (23505) con otro pedido concurrente no borra la conversación ajena si su envío falla', async () => {
    estado.tablas.consultas_familias = [];
    const cuerpo = { nombre: 'Fam', email: 'f@prueba.test', asunto: 'Tu kit', mensaje: 'Ya está pago.', clave: 'clave-ini-5678' };
    // El otro pedido la crea justo entre la búsqueda por clave y el insert de este.
    estado.fallar = (t, op) => {
      if (t !== 'consultas_familias' || op !== 'insert') return false;
      estado.tablas.consultas_familias.push({ id: 'c-otro', nombre: 'Fam', email: 'f@prueba.test', asunto: 'Tu kit', estado: 'en_proceso', clave_envio: 'clave-ini-5678' });
      return '23505';
    };
    estado.resend.fallar = () => true;
    const r = await srv.pedir('POST', '/api/admin/consultas-familias/iniciar', cuerpo, token);
    expect(r.status).toBe(500);
    expect(tabla('consultas_familias').map((c: any) => c.id)).toEqual(['c-otro']);
  });

  it('cambiar el estado desde una lista vieja: 409 «la familia escribió de nuevo»; con el estado que se veía, sí', async () => {
    const r = await srv.pedir('PATCH', '/api/admin/consultas-familias/c1/estado', { estado: 'archivada', estadoAnterior: 'en_proceso' }, token);
    expect(r.status).toBe(409);
    expect(r.json.error).toMatch(/escribió de nuevo/);
    expect(tabla('consultas_familias')[0].estado).toBe('nueva');
    expect((await srv.pedir('PATCH', '/api/admin/consultas-familias/c1/estado', { estado: 'archivada', estadoAnterior: 'nueva' }, token)).status).toBe(200);
    expect(tabla('consultas_familias')[0].estado).toBe('archivada');
  });

  it('solicitudes de código: la respuesta lleva clave de idempotencia (un reintento no duplica)', async () => {
    estado.tablas.solicitudes_codigo = [{ id: 's1', nombre_solicitante: 'Fam', contacto: 'f@prueba.test', estado: 'pendiente' }];
    const cuerpo = { mensaje: 'Inscribite acá.', clave: 'clave-sol-1234' };
    await srv.pedir('POST', '/api/admin/solicitudes-codigo/s1/responder', cuerpo, token);
    await srv.pedir('POST', '/api/admin/solicitudes-codigo/s1/responder', cuerpo, token);
    expect(estado.mails).toHaveLength(1);
    expect(estado.mails[0].clave).toBe('respuesta-solicitud-s1-clave-sol-1234');
  });
});

describe('5: correo HD (/api/enviar-fotos-hd) sin repetir', () => {
  const id = UUID(5);
  const cuerpo = (extra: Record<string, unknown> = {}) => ({ to: 'f@prueba.test', alumnoNombre: 'Ana', colegioNombre: 'Col', cursoCodigo: 'C', pedidoId: 'IFS-1', kitNombre: 'Kit', total: 1, linkDescargaHD: 'https://zip', pedidoSupabaseId: id, ...extra });
  const pedidoHD = (extra: Record<string, unknown>) => { estado.tablas.pedidos = [{ id, seleccion_pendiente: false, mejora_de_pedido_id: null, email_enviado: false, link_descarga_hd: null, ...extra }]; };

  it('si ya se le mandó el link, el reintento no repite el correo; el reenvío manual (`forzar`) sí', async () => {
    pedidoHD({ email_enviado: true, link_descarga_hd: 'https://zip' });
    const r = await srv.pedir('POST', '/api/enviar-fotos-hd', cuerpo(), token);
    expect(r.json).toMatchObject({ success: true, omitido: true, yaEnviado: true });
    expect(estado.mails).toHaveLength(0);
    expect((await srv.pedir('POST', '/api/enviar-fotos-hd', cuerpo({ forzar: true }), token)).json.success).toBe(true);
    expect(estado.mails).toHaveLength(1);
  });

  it('el reintento masivo sin link no manda el «en breve» y cuenta como fallido', async () => {
    pedidoHD({});
    const r = await srv.pedir('POST', '/api/enviar-fotos-hd', cuerpo({ linkDescargaHD: '', soloConLink: true }), token);
    expect(r.status).toBe(409);
    expect(r.json).toMatchObject({ success: false, sinLink: true });
    expect(estado.mails).toHaveLength(0);
  });

  it('un doble clic manda un solo correo (clave fotos-hd-panel-<pedido>-<link>, distinta de la del webhook/cron)', async () => {
    pedidoHD({});
    await Promise.all([srv.pedir('POST', '/api/enviar-fotos-hd', cuerpo(), token), srv.pedir('POST', '/api/enviar-fotos-hd', cuerpo(), token)]);
    expect(estado.mails).toHaveLength(1);
    expect(estado.mails[0].clave).toMatch(new RegExp(`^fotos-hd-panel-${id}-[0-9a-f]{16}-`));
    // 14/10/2026: aunque el webhook ya usó `fotos-hd-<uuid>-con-link`, el panel con otro link sale igual.
    estado.resend.claves.add(`fotos-hd-${id}-con-link`);
    pedidoHD({});
    await srv.pedir('POST', '/api/enviar-fotos-hd', cuerpo({ linkDescargaHD: 'https://otro-zip' }), token);
    expect(estado.mails).toHaveLength(2);
    expect(estado.mails[1].clave).not.toBe(estado.mails[0].clave);
  });
});

describe('10: importar la nómina o el padrón dos veces no duplica', () => {
  it('alumnos: el reintento saltea los que ya están (sin importar mayúsculas ni espacios)', async () => {
    const filas = [{ nombre: 'PEREZ, ANA', grado: '1° grado', division: 'A', turno: 'Mañana', numeroLista: 1 }, { nombre: 'RUIZ, EVA', grado: '1° grado', division: 'A', turno: 'Mañana', numeroLista: 2 }];
    const a = await srv.pedir('POST', '/api/admin/alumnos/importar', { colegioId: COL, filas }, token);
    expect(a.json).toMatchObject({ success: true, importados: 2, repetidos: 0 });
    const b = await srv.pedir('POST', '/api/admin/alumnos/importar', { colegioId: COL, filas: [...filas.map((f) => ({ ...f, nombre: ` ${f.nombre.toLowerCase()} ` })), { nombre: 'SOSA, LIA', grado: '1° grado', division: 'A', turno: 'Mañana' }] }, token);
    expect(b.json).toMatchObject({ success: true, importados: 1, repetidos: 2 });
    expect(tabla('alumnos')).toHaveLength(3);
  });

  it('padrón: igual', async () => {
    const filas = [{ nombre: 'Pa', email: 'pa@prueba.test', alumnoNombre: 'Ana', grado: '1° grado', division: 'A', turno: 'Mañana' }];
    await srv.pedir('POST', '/api/admin/padron/importar', { colegioId: COL, filas }, token);
    const b = await srv.pedir('POST', '/api/admin/padron/importar', { colegioId: COL, filas }, token);
    expect(b.json).toMatchObject({ success: true, importados: 0, repetidos: 1 });
    expect(tabla('padres_autorizados')).toHaveLength(1);
  });
});

describe('12: DNI equivocado en el primer ingreso', () => {
  it('a la 3ª vez frena los intentos, no la vuelve a «pendiente», avisa a Pablo una vez y nombra al tutor a medias', async () => {
    const { tokenConfirmacionAcceso } = await import('../../../../servidor/familias/accesoFamilias');
    const id = UUID(12);
    estado.intentos = {};
    estado.tablas.inscripciones = [{ id, estado: 'aceptado', codigo_asignado: 'COD1', acceso_confirmado_at: null, padre_dni: '30111222', padre_nombre: 'Pablo Alderete', alumno_nombre: 'Ana', alumno_apellido: 'P', colegio_nombre: 'Col' }];
    const intentar = (dni: string) => srv.pedir('POST', '/api/inscripciones/confirmar-acceso', { id, token: tokenConfirmacionAcceso(id), dni });
    const primero = await intentar('99888777');
    expect(primero.status).toBe(409);
    expect(primero.json.error).toContain('Pablo A.');
    expect(primero.json.error).not.toContain('Alderete');
    await intentar('99888777');
    const tercero = await intentar('99888777');
    expect(tercero.status).toBe(429);
    expect(tercero.json.bloqueado).toBe(true);
    expect(tabla('inscripciones')[0].estado).toBe('aceptado');
    // El aviso a Pablo es registrarAlertaPago con una sola clave (la base real, con estado 'nuevo' por defecto,
    // no repite la misma clave; la base falsa no completa ese default).
    expect(new Set(tabla('reportes_errores').map((r: any) => r.detalle?.clave))).toEqual(new Set([`confirmacion-dni:${id}`]));
    // La familia real, con su DNI, entra igual.
    expect((await intentar('30111222')).json).toMatchObject({ success: true, codigo: 'COD1' });
  });
});

describe('11 y 13: reenvío del formulario (contratos en el código)', () => {
  const fuente = fuenteServidor();
  it('la respuesta avisa `congelada` cuando la inscripción aprobada no se modificó', () => {
    expect(fuente).toContain('...(congelarInscripcionAprobada ? { congelada: true } : {}),');
  });
  it('el email de la aprobación automática consume el cupo de reenvío sólo si salió (prueba real en familias.test.ts)', () => {
    expect(fuente).toMatch(/if \(emailEnviado\) \{\s*await hayCupoPorClave\(`reenvio-codigo:\$\{resultadoFila\.id\}`, 1, 600\);/);
  });
});

describe('16: observaciones, borradores y laboratorio', () => {
  it('observación con la misma clave (reintento) queda una sola vez', async () => {
    estado.tablas.alumnos = [{ id: UUID(16), colegio_id: COL, nombre: 'PEREZ, ANA', grado: 'Sala 4', division: 'C', turno: 'Tarde' }];
    const cuerpo = { alumnoId: UUID(16), tipo: 'ausente', clave: 'clave-obs-1234' };
    const a = await srv.pedir('POST', '/api/admin/observaciones', cuerpo, token);
    const b = await srv.pedir('POST', '/api/admin/observaciones', cuerpo, token);
    expect(a.json.success && b.json.success).toBe(true);
    expect(b.json.repetida).toBe(true);
    expect(tabla('observaciones_alumnos')).toHaveLength(1);
  });

  it('borradores: guardar, leer, borrar; con tope de 200 KB, clave válida y sesión de admin', async () => {
    expect((await srv.pedir('PUT', '/api/admin/borradores/consulta-c1', { contenido: 'hola' }, token)).json.success).toBe(true);
    await srv.pedir('PUT', '/api/admin/borradores/consulta-c1', { contenido: 'hola, ¿cómo va?' }, token);
    expect((await srv.pedir('GET', '/api/admin/borradores/consulta-c1', undefined, token)).json).toMatchObject({ success: true, contenido: 'hola, ¿cómo va?' });
    expect(tabla('borradores_admin')).toHaveLength(1);
    expect((await srv.pedir('PUT', '/api/admin/borradores/grande', { contenido: 'x'.repeat(210 * 1024) }, token)).status).toBe(413);
    expect((await srv.pedir('PUT', '/api/admin/borradores/no%20vale', { contenido: 'x' }, token)).status).toBe(400);
    expect((await srv.pedir('GET', '/api/admin/borradores/consulta-c1')).status).toBe(401);
    await srv.pedir('DELETE', '/api/admin/borradores/consulta-c1', undefined, token);
    expect((await srv.pedir('GET', '/api/admin/borradores/consulta-c1', undefined, token)).json.contenido).toBeNull();
  });

  it('reimpresión pedida dos veces (recarga) queda registrada una sola vez', async () => {
    const id = UUID(161);
    estado.tablas.pedidos = [{ id, pedido_friendly_id: 'IFS-9', alumno_nombre: 'Ana', estado: 'pagado', tipo_kit: 'impreso_digital', seleccion_pendiente: false, en_espera: false, archivado: false, lote_lab_id: 'l1', estado_lab: 'en_produccion', fotos_seleccionadas: {}, copias_extras: {} }];
    const cuerpo = { motivo: 'falla_laboratorio', archivos: [{ nombre: 'ANA.jpg', tamano: '20x30' }] };
    const a = await srv.pedir('POST', `/api/lab/pedidos/${id}/reimpresion`, cuerpo, token);
    const b = await srv.pedir('POST', `/api/lab/pedidos/${id}/reimpresion`, cuerpo, token);
    expect(a.json.success && b.json.success).toBe(true);
    expect(b.json).toMatchObject({ id: a.json.id, repetida: true });
    expect(tabla('reimpresiones_lab')).toHaveLength(1);
    expect(estado.mails).toHaveLength(1);
  });

  it('«Hay un problema» responde 500 si el reporte no quedó guardado', async () => {
    estado.tablas.pedidos = [{ id: 'p1', pedido_friendly_id: 'IFS-1', alumno_nombre: 'Ana', curso_codigo: 'C' }];
    estado.fallar = (t, op) => t === 'reportes_errores' && op === 'insert';
    const r = await srv.pedir('POST', '/api/lab/pedidos/p1/problema', { motivo: 'Falta una foto' }, token);
    expect(r.status).toBe(500);
    expect(estado.mails).toHaveLength(0);
  });

  it('ZIP por partes: el avance del lote se guarda y se lee', async () => {
    estado.tablas.lotes_laboratorio = [{ id: 'l1', numero: 1 }];
    expect((await srv.pedir('PUT', '/api/lab/lotes/l1/zip-partes', { total: 3, hechas: [0, 2, 9], nombre: 'LOTE_1' }, token)).json.success).toBe(true);
    expect((await srv.pedir('GET', '/api/lab/lotes/l1/zip-partes', undefined, token)).json.zipPartes).toMatchObject({ total: 3, hechas: [0, 2] });
    expect((await srv.pedir('PUT', '/api/lab/lotes/l1/zip-partes', { total: 0, hechas: [] }, token)).status).toBe(400);
    expect((await srv.pedir('PUT', '/api/lab/lotes/otro/zip-partes', { total: 2, hechas: [] }, token)).status).toBe(404);
  });
});

describe('17: «Limpiar huérfanos» no borra una foto registrada mientras corría', () => {
  it('relee el catálogo justo antes de cada tanda', async () => {
    const { limpiarArchivosHuerfanos } = await import('../../../../servidor/panel/fotos');
    const supabase: any = clienteFalso();
    estado.tablas.fotos = [];
    estado.tablas.pedidos = [];
    estado.storage.archivos['fotos-hd'] = ['2026/col/a.jpg', '2026/col/b.jpg'];
    // La subida de «a.jpg» termina justo después de la lectura del catálogo (al listar el bucket).
    estado.storage.alListar = () => {
      if (!estado.tablas.fotos.length) estado.tablas.fotos.push({ id: 'f-a', storage_path: '2026/col/a.jpg', preview_path: null, thumb_path: null, created_at: '2020-01-01T00:00:00Z' });
    };
    const r = await limpiarArchivosHuerfanos(supabase, true, 0, false);
    const borradosHd = estado.storage.removidos.filter((x) => x.bucket === 'fotos-hd').flatMap((x) => x.rutas);
    expect(borradosHd).toEqual(['2026/col/b.jpg']);
    expect(r.borrados).toBe(1);
  });
});
