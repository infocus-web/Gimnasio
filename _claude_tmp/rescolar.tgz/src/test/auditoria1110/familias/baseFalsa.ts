// Auditoría 11/10 — base falsa en memoria que imita a PostgREST para las pruebas del área familias:
// corta en 1000 filas por respuesta, `ilike` con `*` como alias de `%` (y `\` para escapar), latencia
// configurable (para carreras) y una tabla que puede fallar a pedido.
import crypto from 'crypto';

export const estado = {
  tablas: {} as Record<string, any[]>,
  correos: [] as any[],
  prompts: [] as string[],
  latenciaMs: 0,
  tablaQueFalla: '' as string,
  /** 14/10/2026: si es true, el Resend falso de familias.test.ts devuelve error. */
  resendFalla: false,
};

const esperar = () => (estado.latenciaMs ? new Promise((r) => setTimeout(r, estado.latenciaMs)) : Promise.resolve());
const valor = (fila: any, campo: string) => fila[campo] ?? null;
const comparar = (a: any, b: any) => (typeof a === 'number' && typeof b === 'number' ? a - b : String(a).localeCompare(String(b)));

function patronIlike(p: string): RegExp {
  let re = '';
  for (let i = 0; i < p.length; i++) {
    const c = p[i];
    if (c === '\\' && i + 1 < p.length) {
      re += p[++i].replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      continue;
    }
    if (c === '%' || c === '*') re += '.*';
    else if (c === '_') re += '.';
    else re += c.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  }
  return new RegExp(`^${re}$`, 'is');
}

export function consulta(tabla: string) {
  const filtros: Array<(f: any) => boolean> = [];
  let cambios: Record<string, any> | null = null;
  let nuevas: any[] | null = null;
  let borrar = false;
  let unica = false;
  let rango: [number, number] | null = null;
  let limite = Infinity;
  const ordenes: { campo: string; asc: boolean }[] = [];
  const q: any = {
    select: () => q,
    eq: (c: string, v: any) => (filtros.push((f) => valor(f, c) === v), q),
    neq: (c: string, v: any) => (filtros.push((f) => valor(f, c) !== v), q),
    is: (c: string, v: any) => (filtros.push((f) => valor(f, c) === v), q),
    not: (c: string, _op: string, v: any) => (filtros.push((f) => valor(f, c) !== v), q),
    in: (c: string, vs: any[]) => (filtros.push((f) => vs.includes(valor(f, c))), q),
    ilike: (c: string, p: string) => (filtros.push((f) => patronIlike(p).test(String(valor(f, c) ?? ''))), q),
    gte: (c: string, v: any) => (filtros.push((f) => valor(f, c) !== null && comparar(valor(f, c), v) >= 0), q),
    order: (campo: string, o?: { ascending?: boolean }) => (ordenes.push({ campo, asc: o?.ascending !== false }), q),
    range: (d: number, hasta: number) => ((rango = [d, hasta]), q),
    limit: (n: number) => ((limite = n), q),
    abortSignal: () => q,
    update: (c: Record<string, any>) => ((cambios = c), q),
    upsert: (f: any) => ((nuevas = Array.isArray(f) ? f : [f]), q),
    insert: (f: any) => ((nuevas = Array.isArray(f) ? f : [f]), q),
    delete: () => ((borrar = true), q),
    maybeSingle: () => ((unica = true), q),
    single: () => ((unica = true), q),
    then: (ok: any, mal: any) => esperar().then(() => ejecutar()).then(ok, mal),
  };
  function ejecutar() {
    if (estado.tablaQueFalla === tabla) return { data: null, error: { message: `caída de ${tabla}` } };
    const filas = (estado.tablas[tabla] = estado.tablas[tabla] || []);
    if (nuevas) {
      const creadas = nuevas.map((f) => ({ id: crypto.randomUUID(), created_at: new Date().toISOString(), ...f }));
      filas.push(...creadas);
      const copia = JSON.parse(JSON.stringify(creadas));
      return { data: unica ? copia[0] : copia, error: null };
    }
    let elegidas = filas.filter((f) => filtros.every((fn) => fn(f)));
    if (borrar) {
      estado.tablas[tabla] = filas.filter((f) => !elegidas.includes(f));
      return { data: null, error: null };
    }
    if (cambios) for (const f of elegidas) Object.assign(f, cambios);
    for (const { campo, asc } of [...ordenes].reverse()) {
      elegidas = [...elegidas].sort((a, b) => (asc ? 1 : -1) * comparar(valor(a, campo) ?? '', valor(b, campo) ?? ''));
    }
    if (rango) elegidas = elegidas.slice(rango[0], rango[1] + 1);
    elegidas = elegidas.slice(0, Math.min(limite, 1000)); // max-rows de PostgREST
    const copia = JSON.parse(JSON.stringify(elegidas));
    return { data: unica ? copia[0] ?? null : copia, error: null };
  }
  return q;
}

export function rpc(nombre: string, args: any) {
  if (nombre !== 'registrar_intento') return Promise.resolve({ data: null, error: null });
  const filas = (estado.tablas.limites_intentos = estado.tablas.limites_intentos || []);
  let fila = filas.find((f) => f.clave === args.p_clave);
  if (!fila) {
    fila = { clave: args.p_clave, cantidad: 0, desde: new Date().toISOString() };
    filas.push(fila);
  }
  fila.cantidad += 1;
  const data = fila.cantidad > args.p_max ? args.p_ventana_seg : 0;
  return esperar().then(() => ({ data, error: null }));
}

// Storage siempre vacío: la lupa con permiso termina en 500 (no hay original); sin permiso, 404.
export const storage = {
  from: () => ({
    download: async () => ({ data: null, error: { message: 'sin archivo' } }),
    upload: async () => ({ data: null, error: null }),
  }),
};
