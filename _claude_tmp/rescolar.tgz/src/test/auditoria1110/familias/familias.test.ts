// Auditoría 11/10/2026 — área familias: pruebas de REGRESIÓN de los arreglos FAM-1/2/3/5/6/7/8, INS-2 y DB-5.
// Corren las rutas reales (Express + Routers) contra una base falsa que imita a PostgREST (baseFalsa.ts).
import crypto from 'crypto';
import http from 'http';
import type { AddressInfo } from 'net';
import express from 'express';
import { afterAll, beforeAll, beforeEach, describe, expect, it, vi } from 'vitest';
import { estado } from './baseFalsa';
import { fuenteServidor } from '../../fuenteServidor';

vi.mock('dotenv', () => {
  const config = () => ({ parsed: {} });
  return { default: { config }, config };
});
vi.mock('@supabase/supabase-js', async () => {
  const b = await import('./baseFalsa');
  return { createClient: () => ({ from: (t: string) => b.consulta(t), rpc: (n: string, a: any) => b.rpc(n, a), storage: b.storage }) };
});
vi.mock('resend', async () => {
  const b = await import('./baseFalsa');
  return {
    Resend: class {
      emails = { send: async (m: any) => (b.estado.resendFalla ? { data: null, error: { message: 'falla simulada' } } : (b.estado.correos.push(m), { data: { id: 'x' }, error: null })) };
      batch = { send: async () => ({ data: { data: [] }, error: null }) };
    },
  };
});
vi.mock('../../../../servidor/nucleo/ia', async (original) => {
  const b = await import('./baseFalsa');
  return {
    ...((await original()) as object),
    iaConfigurada: () => true,
    ERROR_IA_NO_CONFIGURADA: 'sin ia',
    generarTextoIA: async (p: { prompt: string }) => {
      b.estado.prompts.push(p.prompt);
      return JSON.stringify({ tema: 'otro', respondible: false, respuesta: 'Borrador de respuesta para la familia.', motivo: 'x' });
    },
  };
});

const COLEGIO = '11111111-1111-4111-8111-111111111111';
const SECRETO = 'secreto-de-prueba';
const INSC = 'aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa';
const llave = (id: string) => crypto.createHmac('sha256', SECRETO).update(`acceso-galeria:${id}`).digest('base64url').slice(0, 32);

let determinarCodigoCursoServidor: (g: string, t: string, d: string) => string;
let VERSION_TERMINOS_SERVIDOR = '';
let tokenAdmin = '';
let servidor: http.Server;
let puerto = 0;
const entornoAntes: Record<string, string | undefined> = {};

function pedir(metodo: string, ruta: string, cuerpo?: unknown, ip?: string, admin = false): Promise<{ status: number; json: any }> {
  return new Promise((ok, mal) => {
    const datos = cuerpo === undefined ? undefined : JSON.stringify(cuerpo);
    const encabezados: Record<string, string | number> = { 'X-Forwarded-For': ip || ipNueva() };
    if (admin) encabezados.Authorization = `Bearer ${tokenAdmin}`;
    if (datos) {
      encabezados['Content-Type'] = 'application/json';
      encabezados['Content-Length'] = Buffer.byteLength(datos);
    }
    const req = http.request({ host: '127.0.0.1', port: puerto, path: ruta, method: metodo, headers: encabezados }, (res) => {
      let texto = '';
      res.setEncoding('utf8');
      res.on('data', (c) => { texto += c; });
      res.on('end', () => {
        let json: any = null;
        try { json = JSON.parse(texto); } catch { /* no JSON */ }
        ok({ status: res.statusCode || 0, json });
      });
    });
    req.on('error', mal);
    if (datos) req.write(datos);
    req.end();
  });
}
let ipN = 0;
function ipNueva() {
  ipN++;
  return `10.9.${Math.floor(ipN / 250)}.${ipN % 250}`;
}

let nFoto = 0;
const foto = (categoria: string, alumno: string | null, cursoCodigo: string, extra: Record<string, any> = {}) => ({
  id: `00000000-0000-4000-8000-${String(++nFoto).padStart(12, '0')}`,
  colegio_id: COLEGIO, codigo_curso: cursoCodigo, categoria, alumno_nombre: alumno,
  storage_path: `orig/${nFoto}.jpg`, preview_path: `prev/${nFoto}.jpg`, thumb_path: null, grado: '3° grado', division: 'A',
  publicada_at: '2026-10-01T00:00:00Z', created_at: '2026-10-01T00:00:00Z', ...extra,
});
const inscripcion = (extra: Record<string, any> = {}) => ({
  id: INSC, colegio_id: COLEGIO, colegio_nombre: 'Colegio', estado: 'aceptado', acceso_confirmado_at: '2026-10-01T00:00:00Z',
  padre_nombre: 'Ana Tutora', padre_dni: '20111222', email: 'ana@familia.test', telefono_whatsapp: '1144445555',
  alumno_nombre: 'María', alumno_apellido: 'García', grado: '3° grado', turno: 'Mañana', division: 'A', hermanos: [],
  codigo_asignado: 'ABCD-EFGH', ...extra,
});
function seccion(grado: string, turno: string, division: string, codigo: string) {
  estado.tablas.codigos_seccion.push({ id: crypto.randomUUID(), colegio_id: COLEGIO, grado, turno, division, codigo_secreto: codigo });
  return determinarCodigoCursoServidor(grado, turno, division);
}
const galeria = (codigo: string, familia?: string) =>
  pedir('GET', `/api/fotos?codigo=${encodeURIComponent(codigo)}${familia ? `&familia=${familia}&acceso=${llave(familia)}` : ''}`);
const individuales = (r: any) => r.json.fotos.filter((f: any) => f.categoria === 'individual').map((f: any) => f.alumno_nombre).sort();
const inscribir = (extra: Record<string, any> = {}) =>
  pedir('POST', '/api/inscripciones/validar', {
    colegioId: COLEGIO, colegioNombre: 'Colegio', padreNombre: 'Ana Tutora', padreDni: '20111222', telefonoWhatsApp: '1144445555',
    email: 'ana@familia.test', alumnoNombre: 'Juan', alumnoApellido: 'Pérez', alumnoDni: '50111222',
    grado: '3° grado', division: 'A', turno: 'Mañana', consentimientos: { toma: true, grupal: true, transferencia: true },
    versionTerminos: VERSION_TERMINOS_SERVIDOR, ...extra,
  });
const filaPadron = (extra: Record<string, any> = {}) => ({
  id: crypto.randomUUID(), colegio_id: COLEGIO, nombre: 'Ana Tutora', email: 'ana@familia.test', telefono: '1144445555',
  alumno_nombre: 'Juan Pérez', grado: '3° grado', turno: 'Mañana', division: 'A', usado: false, origen: null, ...extra,
});

beforeAll(async () => {
  for (const n of ['SUPABASE_SERVICE_ROLE_KEY', 'ADMIN_SESSION_SECRET', 'RESEND_API_KEY']) entornoAntes[n] = process.env[n];
  process.env.SUPABASE_SERVICE_ROLE_KEY = 'prueba';
  process.env.ADMIN_SESSION_SECRET = SECRETO;
  process.env.RESEND_API_KEY = 're_prueba';
  ({ determinarCodigoCursoServidor } = await import('../../../../servidor/nucleo/codigosCurso'));
  ({ VERSION_TERMINOS_SERVIDOR } = await import('../../../../servidor/nucleo/legal'));
  tokenAdmin = (await import('../../../../servidor/nucleo/auth')).generateAdminToken() || '';
  const app = express();
  app.set('trust proxy', true);
  app.use(express.json());
  app.use((await import('../../../../servidor/familias/galeria')).rutasGaleria);
  app.use((await import('../../../../servidor/familias/inscripciones')).rutasInscripciones);
  app.use((await import('../../../../servidor/familias/solicitudesCodigo')).rutasSolicitudesCodigo);
  app.use((await import('../../../../servidor/familias/consultas')).rutasConsultas);
  servidor = app.listen(0);
  await new Promise((ok) => servidor.once('listening', ok));
  puerto = (servidor.address() as AddressInfo).port;
}, 120_000);

afterAll(async () => {
  await new Promise((ok) => servidor.close(ok));
  for (const [n, v] of Object.entries(entornoAntes)) {
    if (v === undefined) delete process.env[n];
    else process.env[n] = v;
  }
});

beforeEach(async () => {
  estado.correos = [];
  estado.prompts = [];
  estado.latenciaMs = 0;
  estado.tablaQueFalla = '';
  estado.resendFalla = false;
  estado.tablas = {
    colegios: [{ id: COLEGIO, nombre: 'Colegio', muestras_lupa: true }],
    codigos_seccion: [], inscripciones: [], padres_autorizados: [], alumnos: [], fotos: [], limites_intentos: [],
    solicitudes_codigo: [], consultas_familias: [], consultas_familias_mensajes: [], familias: [], pedidos: [], ev_eventos: [], reportes_errores: [],
  };
  (await import('../../../../servidor/nucleo/codigosCurso')).invalidarCacheCodigosSeccion();
});

describe('FAM-1: una familia sólo ve las individuales de SU hijo', () => {
  it('nombre inscripto largo: ya no empata con las etiquetas de los compañeros', async () => {
    const curso = seccion('3° grado', 'Mañana', 'A', 'ABCD-EFGH');
    estado.tablas.fotos.push(foto('individual', 'Juan Pérez', curso), foto('individual', 'Pedro Gómez', curso), foto('individual', 'Lucas Díaz', curso));
    estado.tablas.inscripciones.push(inscripcion({ alumno_nombre: 'Juan Pedro Lucas', alumno_apellido: 'Pérez Gómez Díaz' }));
    expect(individuales(await galeria('ABCD-EFGH', INSC))).toEqual([]);
  });
  it('«María García» ante «María Sol García» y «María Laura García»: ambiguo, ninguna', async () => {
    const curso = seccion('3° grado', 'Mañana', 'A', 'ABCD-EFGH');
    estado.tablas.fotos.push(foto('individual', 'María Sol García', curso), foto('individual', 'María Laura García', curso));
    estado.tablas.inscripciones.push(inscripcion());
    expect(individuales(await galeria('ABCD-EFGH', INSC))).toEqual([]);
  });
  // Revisión 11/10: UNA palabra de más en lo que escribió la familia sigue valiendo (la nómina no siempre tiene el
  // segundo apellido). Riesgo residual aceptado y documentado: si en el curso hay un homónimo exacto y la foto propia
  // todavía no se subió, se ve la del otro; apenas está la propia (puntaje 0), gana la propia.
  it('«Juan Pérez García»: ve la de su nómina «Juan Pérez», y si está la propia, sólo la propia', async () => {
    const curso = seccion('3° grado', 'Mañana', 'A', 'ABCD-EFGH');
    estado.tablas.fotos.push(foto('individual', 'Juan Pérez', curso));
    estado.tablas.inscripciones.push(inscripcion({ alumno_nombre: 'Juan', alumno_apellido: 'Pérez García' }));
    expect(individuales(await galeria('ABCD-EFGH', INSC))).toEqual(['Juan Pérez']);
    estado.tablas.fotos.push(foto('individual', 'PÉREZ GARCÍA, Juan', curso));
    expect(individuales(await galeria('ABCD-EFGH', INSC))).toEqual(['PÉREZ GARCÍA, Juan']);
  });
  it('dos palabras de más no valen, y un nombre largo que cubre a dos compañeros no ve ninguna', async () => {
    const curso = seccion('3° grado', 'Mañana', 'A', 'ABCD-EFGH');
    estado.tablas.fotos.push(foto('individual', 'Juan Pérez', curso), foto('individual', 'Pedro Gómez', curso));
    estado.tablas.inscripciones.push(inscripcion({ alumno_nombre: 'Juan Pedro', alumno_apellido: 'Pérez Gómez' }));
    expect(individuales(await galeria('ABCD-EFGH', INSC))).toEqual([]);
  });
  it('sigue viendo la suya: etiqueta completa de la nómina, en otro orden, con tildes, o idéntica aunque haya otra más larga', async () => {
    const curso = seccion('3° grado', 'Mañana', 'A', 'ABCD-EFGH');
    estado.tablas.fotos.push(
      foto('individual', 'PEREZ, Juan Martín', curso),
      foto('individual', 'Pedro Gómez', curso),
      foto('individual', 'María García', curso),
      foto('individual', 'María Sol García', curso),
    );
    estado.tablas.inscripciones.push(inscripcion({ alumno_nombre: 'juan', alumno_apellido: 'perez', hermanos: [{ alumnoNombre: 'María', alumnoApellido: 'García' }] }));
    expect(individuales(await galeria('ABCD-EFGH', INSC))).toEqual(['María García', 'PEREZ, Juan Martín']);
  });

  it('servidor y navegador dan lo mismo (tabla de casos)', async () => {
    const srv = await import('../../../../servidor/nucleo/nombres');
    const web = await import('../../../utils/nombresAlumno');
    const etiquetas = ['Juan Pérez', 'PEREZ, Juan Martín', 'María Sol García', 'María Laura García', 'María García', 'Ñoño Ibáñez', 'Juan'];
    const nombres = ['Juan Pérez', 'Juan Martín Pérez', 'María García', 'María Sol García', 'nono ibanez', 'Juan', '', 'Juan Pedro Pérez Gómez', 'García  María'];
    for (const n of nombres) {
      expect([...web.etiquetasDelAlumno(n, etiquetas)].sort(), n).toEqual([...srv.etiquetasDelAlumno(n, etiquetas)].sort());
      for (const e of etiquetas) expect(web.nombresCompatibles(n, e), `${n} / ${e}`).toBe(srv.nombresCompatibles(n, e));
    }
    expect([...srv.etiquetasDelAlumno('María García', etiquetas)]).toEqual(['garcia maria']);
    expect(web.fotoVisibleParaAlumno({ categoria: 'individual', alumnoNombre: 'Juan Pérez' }, 'Juan Pérez García')).toBe(true);
    expect(web.fotoVisibleParaAlumno({ categoria: 'individual', alumnoNombre: 'Juan Pérez' }, 'Juan Pedro Pérez Gómez')).toBe(false);
    expect([...srv.etiquetasDelAlumno('María de los Ángeles Pérez', ['PEREZ, Maria Angeles'])]).toHaveLength(1); // partículas
    expect(web.fotoVisibleParaAlumno({ categoria: 'individual', alumnoNombre: 'PEREZ, Juan Martín' }, 'Juan Pérez')).toBe(true);
  });
});

describe('individuales sin nombre (11/10, Pablo: «opción 3»)', () => {
  it('una individual sin nombre la ve todo el curso; una con nombre, sólo su familia', async () => {
    const curso = seccion('3° grado', 'Mañana', 'A', 'ABCD-EFGH');
    estado.tablas.fotos.push(foto('individual', null, curso), foto('individual', 'Pedro Gómez', curso));
    estado.tablas.inscripciones.push(inscripcion({ alumno_nombre: 'Juan', alumno_apellido: 'Pérez' }));
    const sinLlave = await galeria('ABCD-EFGH');
    expect(sinLlave.json.fotos.filter((f: any) => f.categoria === 'individual')).toHaveLength(1);
    expect(individuales(sinLlave)).toEqual([null]);
    expect(individuales(await galeria('ABCD-EFGH', INSC))).toEqual([null]); // la de Pedro no
  });
});

describe('FAM-2: secciones que darían el mismo codigo_curso (preventivo)', () => {
  it('asegurar / regenerar / actualizar → 409 con mensaje claro; sin choque sigue andando', async () => {
    seccion('1° grado', 'Jornada Extendida', 'A', 'JEJE-JEJE');
    const cuerpo = { colegioId: COLEGIO, grado: '1° grado', turno: 'Jornada Completa', division: 'A' };
    for (const ruta of ['asegurar', 'regenerar']) {
      const r = await pedir('POST', `/api/admin/codigos-seccion/${ruta}`, cuerpo, undefined, true);
      expect(r.status, ruta).toBe(409);
      expect(r.json.error).toContain('mismo código interno de curso');
    }
    const act = await pedir('POST', '/api/admin/codigos-seccion/actualizar', { ...cuerpo, nuevoCodigo: 'QWER-TYUP' }, undefined, true);
    expect(act.status).toBe(409);
    expect(estado.tablas.codigos_seccion).toHaveLength(1);
    const ok = await pedir('POST', '/api/admin/codigos-seccion/asegurar', { ...cuerpo, turno: 'Tarde' }, undefined, true);
    expect(ok.status).toBe(200);
    // La propia sección existente (regenerar su código) no choca consigo misma.
    expect((await pedir('POST', '/api/admin/codigos-seccion/regenerar', { ...cuerpo, turno: 'Jornada Extendida' }, undefined, true)).status).toBe(200);
  });
  it('inscripción automática: queda pendiente con una alerta, sin romperse', async () => {
    seccion('1° grado', 'Jornada Extendida', 'A', 'JEJE-JEJE');
    estado.tablas.padres_autorizados.push(filaPadron({ grado: '1° grado', turno: 'Jornada Completa' }));
    const r = await inscribir();
    expect(r.status).toBe(200);
    expect(r.json.estado).toBe('pendiente');
    expect(estado.tablas.inscripciones[0].codigo_asignado).toBeNull();
    expect(estado.tablas.padres_autorizados[0].usado).toBe(false);
    expect(JSON.stringify(estado.tablas.reportes_errores)).toContain('mismo código interno de curso');
    expect(estado.correos.map((c) => c.to[0])).not.toContain('ana@familia.test'); // no salió el código
  });
  it('sin choque, la aprobación automática sigue igual', async () => {
    estado.tablas.padres_autorizados.push(filaPadron());
    const r = await inscribir();
    expect(r.json.estado).toBe('aceptado');
  });
});

describe('14/10/2026: email de la aprobación automática y cupo de reenvío', () => {
  it('si Resend falla no se consume el cupo: el reintento manda de verdad, y uno posterior ya no repite', async () => {
    estado.tablas.padres_autorizados.push(filaPadron());
    estado.resendFalla = true;
    const primero = await inscribir();
    expect(primero.json).toMatchObject({ estado: 'aceptado', emailEnviado: false });
    expect(estado.correos).toHaveLength(0);
    estado.resendFalla = false;
    const reintento = await inscribir();
    expect(reintento.json.emailEnviado).toBe(true);
    expect(estado.correos.map((c) => c.to[0])).toEqual(['ana@familia.test']);
    const otro = await inscribir();
    expect(otro.json.emailEnviado).toBe(true);
    expect(estado.correos).toHaveLength(1);
  });
});

describe('FAM-3: `*`, `%` y `\\` no hacen búsquedas con comodín', () => {
  it('solicitudes-codigo con «*@familia.test»: no le reenvía nada a nadie y no guarda solicitud (27/10)', async () => {
    estado.tablas.inscripciones.push(inscripcion());
    const r = await pedir('POST', '/api/solicitudes-codigo', { nombreSolicitante: 'X', contacto: '*@familia.test' });
    expect(r.status).toBe(200);
    expect(r.json).toMatchObject({ bloqueado: true, motivo: 'sin_inscripcion' });
    expect(estado.correos).toHaveLength(0);
    expect(estado.tablas.solicitudes_codigo).toHaveLength(0);
  });
  it('27/10: email sin inscripción → se bloquea con aviso y no se guarda la solicitud', async () => {
    estado.tablas.inscripciones.push(inscripcion());
    const r = await pedir('POST', '/api/solicitudes-codigo', { nombreSolicitante: 'Zoe', contacto: 'zoe@otra.test' });
    expect(r.json).toMatchObject({ success: true, bloqueado: true, motivo: 'sin_inscripcion' });
    expect(r.json.mensaje).toContain('Aún no te inscribiste');
    expect(estado.tablas.solicitudes_codigo).toHaveLength(0);
    expect(estado.correos).toHaveLength(0);
  });
  it('27/10: inscripción pendiente de aprobación → aviso de revisión, sin solicitud', async () => {
    estado.tablas.inscripciones.push(inscripcion({ estado: 'pendiente' }));
    const r = await pedir('POST', '/api/solicitudes-codigo', { nombreSolicitante: 'Ana', contacto: 'ana@familia.test' });
    expect(r.json).toMatchObject({ success: true, bloqueado: true, motivo: 'pendiente' });
    expect(estado.tablas.solicitudes_codigo).toHaveLength(0);
    expect(estado.correos).toHaveLength(0);
  });
  it('27/10: inscripción aprobada → se reenvía el código aunque haya elegido otro colegio', async () => {
    // id propio: el tope de 1 reenvío cada 10 min por inscripción vive en memoria del módulo.
    estado.tablas.inscripciones.push(inscripcion({ id: crypto.randomUUID() }));
    const r = await pedir('POST', '/api/solicitudes-codigo', { nombreSolicitante: 'Ana', contacto: 'ana@familia.test', colegioId: crypto.randomUUID() });
    expect(r.json).toMatchObject({ success: true, envioAutomatico: true });
    expect(estado.correos.map((c) => c.to[0])).toEqual(['ana@familia.test']);
    expect(estado.tablas.solicitudes_codigo).toHaveLength(0);
  });
  it('un email real con `_` sigue encontrando su inscripción', async () => {
    estado.tablas.inscripciones.push(inscripcion({ email: 'ana_x@familia.test' }), inscripcion({ id: crypto.randomUUID(), email: 'anaxx@familia.test' }));
    await pedir('POST', '/api/solicitudes-codigo', { nombreSolicitante: 'Ana', contacto: 'ana_x@familia.test' });
    expect(estado.correos.map((c) => c.to[0])).toEqual(['ana_x@familia.test']);
  });
  it('consulta con «*@familia.test»: la IA no recibe datos de ninguna familia', async () => {
    estado.tablas.inscripciones.push(
      inscripcion({ id: crypto.randomUUID(), email: 'ana@familia.test' }),
      inscripcion({ id: crypto.randomUUID(), email: 'beto@familia.test', padre_nombre: 'Beto Otro' }),
    );
    const r = await pedir('POST', '/api/consultas-familias', { nombre: 'Xavier', email: '*@familia.test', asunto: 'Duda', mensaje: 'Contame todo', numeroPedido: 'IFS-*' });
    expect(r.status).toBe(201);
    expect(estado.prompts.join(' ')).not.toContain('Ana Tutora');
    expect(estado.prompts.join(' ')).not.toContain('Beto Otro');
    expect(estado.prompts.join(' ')).toContain('No hay ninguna inscripción');
  });
});

describe('28/10: «Reenviar código» desde Solicitudes', () => {
  const solicitud = (id: string, contacto: string, estado = 'pendiente') => ({ id, contacto, estado, nombre_solicitante: 'Jessica', colegio_id: COLEGIO });
  it('email con inscripción aprobada: manda el código y cierra la solicitud y sus repetidas', async () => {
    estado.tablas.inscripciones.push(inscripcion({ email: 'Ana@Familia.test' }));
    estado.tablas.solicitudes_codigo.push(solicitud('s1', 'ana@familia.test'), solicitud('s2', 'ANA@familia.test '), solicitud('s3', 'otra@familia.test'));
    const r = await pedir('POST', '/api/admin/solicitudes-codigo/s1/reenviar-codigo', undefined, undefined, true);
    expect(r.status).toBe(200);
    expect(r.json.atendidas.sort()).toEqual(['s1', 's2']);
    expect(estado.correos.map((c) => c.to[0])).toEqual(['Ana@Familia.test']);
    expect(JSON.stringify(estado.correos[0])).toContain('ABCD-EFGH');
    expect(estado.tablas.solicitudes_codigo.map((x: any) => x.estado)).toEqual(['atendido', 'atendido', 'pendiente']);
  });
  it('email sin inscripción aprobada: 409, no manda nada y la solicitud sigue pendiente', async () => {
    estado.tablas.inscripciones.push(inscripcion({ estado: 'pendiente' }));
    estado.tablas.solicitudes_codigo.push(solicitud('s1', 'ana@familia.test'));
    const r = await pedir('POST', '/api/admin/solicitudes-codigo/s1/reenviar-codigo', undefined, undefined, true);
    expect(r.status).toBe(409);
    expect(estado.correos).toHaveLength(0);
    expect(estado.tablas.solicitudes_codigo[0].estado).toBe('pendiente');
  });
  it('sin sesión de admin no se puede usar', async () => {
    estado.tablas.inscripciones.push(inscripcion());
    estado.tablas.solicitudes_codigo.push(solicitud('s1', 'ana@familia.test'));
    const r = await pedir('POST', '/api/admin/solicitudes-codigo/s1/reenviar-codigo');
    expect(r.status).toBe(401);
    expect(estado.correos).toHaveLength(0);
  });
});

describe('DB-5: el tope de respuestas automáticas no guarda el email en limites_intentos', () => {
  it('la clave lleva el hash del email', async () => {
    estado.tablas.inscripciones.push(inscripcion());
    await pedir('POST', '/api/consultas-familias', { nombre: 'Ana', email: 'ana@familia.test', asunto: 'Duda', mensaje: 'Hola, una duda' });
    const claves = estado.tablas.limites_intentos.map((f) => f.clave).filter((c) => c.startsWith('auto-respuesta:'));
    expect(claves).toHaveLength(1);
    expect(claves[0]).toMatch(/^auto-respuesta:[0-9a-f]{64}$/);
  });
});

describe('FAM-5: ingreso con código + DNI, tope por código+IP atómico', () => {
  const intento = (dni: string, ip: string) => pedir('POST', '/api/inscripciones/buscar', { query: 'ABCD-EFGH', tutorNombre: 'Ana Tutora', dni }, ip);
  it('100 intentos simultáneos desde la misma IP: como mucho 60 llegan a comparar el DNI', async () => {
    estado.tablas.inscripciones.push(inscripcion());
    estado.latenciaMs = 15;
    const rs = await Promise.all(Array.from({ length: 100 }, (_, i) => intento(String(30000000 + i), '10.200.0.1')));
    estado.latenciaMs = 0;
    expect(rs.filter((r) => r.json?.datosNoCoinciden).length).toBeLessThanOrEqual(60);
    expect(rs.filter((r) => r.status === 429).length).toBeGreaterThanOrEqual(40);
  });
  it('familias normales: 40 ingresos correctos desde el WiFi del colegio entran todos; las fallas en serie siguen frenando en 30', async () => {
    // 40 familias del mismo curso (cada una con su DNI) entran desde la misma IP.
    for (let i = 0; i < 40; i++) estado.tablas.inscripciones.push(inscripcion({ id: crypto.randomUUID(), padre_dni: String(20000000 + i) }));
    for (let i = 0; i < 40; i++) expect((await intento(String(20000000 + i), '10.201.0.1')).json.success, `ingreso ${i}`).toBe(true);
    for (let i = 0; i < 30; i++) expect((await intento(String(31000000 + i), '10.202.0.1')).status).toBe(200);
    expect((await intento('31999999', '10.202.0.1')).status).toBe(429);
  });
});

describe('FAM-6: galería y lupa paginadas', () => {
  it('con más de 1000 fotos publicadas, la individual del hijo aparece (galería y lupa)', async () => {
    const curso = seccion('3° grado', 'Mañana', 'A', 'ABCD-EFGH');
    for (let i = 0; i < 1000; i++) estado.tablas.fotos.push(foto('individual', `Chico Numero${i}`, curso));
    const propia = foto('individual', 'María García', curso, { created_at: '2026-10-02T00:00:00Z' });
    estado.tablas.fotos.push(propia);
    estado.tablas.inscripciones.push(inscripcion());
    expect(individuales(await galeria('ABCD-EFGH', INSC))).toEqual(['María García']);
    // Lupa: con permiso llega a buscar el original (500 en la base falsa, sin archivos); sin permiso sería 404.
    const lupa = await pedir('GET', `/api/fotos/${propia.id}/lupa?codigo=ABCD-EFGH&familia=${INSC}&acceso=${llave(INSC)}&cx=0.5&cy=0.5&s=0.3`);
    expect(lupa.status).toBe(500);
    const ajena = await pedir('GET', `/api/fotos/${estado.tablas.fotos[0].id}/lupa?codigo=ABCD-EFGH&familia=${INSC}&acceso=${llave(INSC)}&cx=0.5&cy=0.5&s=0.3`);
    expect(ajena.status).toBe(404);
  });
});

describe('FAM-7: la lupa recuerda el permiso 60 s', () => {
  it('MS_ACCESO_LUPA = 60 s', () => {
    expect(fuenteServidor()).toMatch(/const MS_ACCESO_LUPA = 60 \* 1000;/);
  });
});

describe('FAM-8: un error de la base responde 500 (no "código no encontrado")', () => {
  it('/api/inscripciones/buscar y /api/familia/hijos', async () => {
    estado.tablaQueFalla = 'inscripciones';
    expect((await pedir('POST', '/api/inscripciones/buscar', { query: 'ABCD-EFGH' })).status).toBe(500);
    expect((await pedir('POST', '/api/inscripciones/buscar', { query: 'ana@familia.test' })).status).toBe(500);
    expect((await pedir('POST', '/api/inscripciones/buscar', { query: '1144445555' })).status).toBe(500);
    expect((await pedir('GET', `/api/familia/hijos?codigo=ABCD-EFGH&familia=${INSC}&acceso=${llave(INSC)}`)).status).toBe(500);
  });
});

describe('INS-2: el panel sólo aprueba inscripciones pendientes', () => {
  it('aceptada o rechazada → 409; con forzar:true sí; pendiente → aprobada', async () => {
    seccion('3° grado', 'Mañana', 'A', 'ABCD-EFGH');
    estado.tablas.inscripciones.push(inscripcion({ estado: 'rechazado' }));
    const r = await pedir('POST', `/api/admin/inscripciones/${INSC}/aprobar`, { codigo: 'ZZZZ-ZZZZ' }, undefined, true);
    expect(r.status).toBe(409);
    expect(estado.tablas.inscripciones[0].estado).toBe('rechazado');
    expect((await pedir('POST', `/api/admin/inscripciones/${INSC}/aprobar`, { forzar: true }, undefined, true)).status).toBe(200);
    expect(estado.tablas.inscripciones[0].estado).toBe('aceptado');
    estado.tablas.inscripciones[0].estado = 'pendiente';
    const p = await pedir('POST', `/api/admin/inscripciones/${INSC}/aprobar`, { codigo: 'ZZZZ-ZZZZ' }, undefined, true);
    expect(p.status).toBe(200);
    expect(p.json.codigo).toBe('ABCD-EFGH');
  });
});

// 13/10/2026 (casos reales del día): un tutor escribía «O» donde su código tenía «0», y muchos padres ponen sólo
// primer nombre y apellido aunque se inscribieron con el nombre completo.
describe('Ingreso: código con O/0 e I/L/1 confundidos, y nombre del tutor incompleto', () => {
  const buscar = (query: string, tutorNombre: string, dni = '20111222') => pedir('POST', '/api/inscripciones/buscar', { query, tutorNombre, dni });
  it('«ABOC-DIEF» encuentra el código «AB0C-D1EF» (ingreso y galería); uno inexistente sigue sin entrar', async () => {
    seccion('3° grado', 'Mañana', 'A', 'AB0C-D1EF');
    estado.tablas.inscripciones.push(inscripcion({ codigo_asignado: 'AB0C-D1EF' }));
    const r = await buscar('ABOC-DIEF', 'Ana Tutora');
    expect(r.json.success).toBe(true);
    expect(r.json.inscripcion?.codigo_asignado).toBe('AB0C-D1EF');
    expect(r.json.requiereDatosTutor).toBeFalsy();
    expect((await buscar('aboc dlef', 'Ana Tutora')).json.inscripcion?.codigo_asignado).toBe('AB0C-D1EF');
    expect((await galeria('ABOC-DIEF')).status).toBe((await galeria('AB0C-D1EF')).status);
    expect((await buscar('ABXC-DIEF', 'Ana Tutora')).json.inscripcion).toBeFalsy();
  });
  it('si el código «plegado» coincide con dos secciones, no adivina', async () => {
    seccion('3° grado', 'Mañana', 'A', 'AB0C-D1EF');
    seccion('3° grado', 'Mañana', 'B', 'ABOC-D1EF');
    estado.tablas.inscripciones.push(inscripcion({ codigo_asignado: 'AB0C-D1EF' }));
    expect((await buscar('ABOC-DIEF', 'Ana Tutora')).json.inscripcion).toBeFalsy();
  });
  it('sin DNI guardado: «Ana López» alcanza para «Ana María Tutora López» (sólo manda el email de confirmación)', async () => {
    seccion('3° grado', 'Mañana', 'A', 'ABCD-EFGH');
    estado.tablas.inscripciones.push(inscripcion({ padre_dni: null, padre_nombre: 'Ana María Tutora López' }));
    const r = await buscar('ABCD-EFGH', 'ana lopez');
    expect(r.json.inscripcion?.id).toBeUndefined();
    expect(estado.correos.map((c: any) => [].concat(c.to).join(','))).toEqual(['ana@familia.test']);
  });
  it('una sola palabra, una palabra que no está, o dos familias posibles: no manda nada', async () => {
    seccion('3° grado', 'Mañana', 'A', 'ABCD-EFGH');
    estado.tablas.inscripciones.push(inscripcion({ padre_dni: null, padre_nombre: 'Ana María Tutora López' }));
    expect((await buscar('ABCD-EFGH', 'Ana')).json.datosNoCoinciden).toBe(true);
    expect((await buscar('ABCD-EFGH', 'Ana Gómez')).json.datosNoCoinciden).toBe(true);
    estado.tablas.inscripciones.push(inscripcion({ id: crypto.randomUUID(), padre_dni: null, padre_nombre: 'Ana Laura López', email: 'otra@familia.test' }));
    expect((await buscar('ABCD-EFGH', 'Ana López')).json.datosNoCoinciden).toBe(true);
    expect(estado.correos).toHaveLength(0);
  });
});
