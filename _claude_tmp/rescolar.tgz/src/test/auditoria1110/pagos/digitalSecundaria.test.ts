// 14/10/2026 (Pablo: «los de secundaria sólo se sacan la grupal; si un padre compra el digital se la reparten»):
// en secundaria no se vende el Kit Solo Digital. Corre las rutas reales de compra con la base falsa en memoria.
import http from 'http';
import type { AddressInfo } from 'net';
import express from 'express';
import { afterAll, beforeAll, beforeEach, describe, expect, it, vi } from 'vitest';
import * as base from './baseFalsa';
import { esGradoDeSecundaria as esSecundariaFront, kitsParaGrados } from '../../../utils/kitsSecundaria';

vi.mock('dotenv', () => {
  const config = () => ({ parsed: {} });
  return { default: { config }, config };
});
vi.mock('@supabase/supabase-js', async () => {
  const m = await import('./baseFalsa');
  return { createClient: () => m.cliente };
});
vi.mock('mercadopago', () => ({
  MercadoPagoConfig: class {},
  Preference: class {
    async create() {
      return { id: 'pref-1', init_point: 'https://mp/pref-1' };
    }
  },
  Payment: class {},
  PaymentRefund: class {},
}));

const COLEGIO = '11111111-1111-4111-8111-111111111111';
let servidor: http.Server;
let puerto = 0;
let versionTerminos = '';
let esSecundariaServidor: (g: unknown) => boolean;

function pedir(ruta: string, cuerpo: unknown): Promise<{ status: number; json: any }> {
  return new Promise((ok, mal) => {
    const datos = JSON.stringify(cuerpo);
    const req = http.request(
      { host: '127.0.0.1', port: puerto, path: ruta, method: 'POST', headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(datos) } },
      (res) => {
        let texto = '';
        res.setEncoding('utf8');
        res.on('data', (c) => (texto += c));
        res.on('end', () => {
          let json: any = null;
          try { json = JSON.parse(texto); } catch { /* texto plano */ }
          ok({ status: res.statusCode || 0, json });
        });
      }
    );
    req.on('error', mal);
    req.write(datos);
    req.end();
  });
}

beforeAll(async () => {
  process.env.SUPABASE_SERVICE_ROLE_KEY = 'prueba';
  process.env.ADMIN_SESSION_SECRET = 'secreto-de-prueba-largo-para-hmac';
  process.env.MERCADOPAGO_ACCESS_TOKEN = 'prueba';
  const { rutasCrearPedido, rutasReservas } = await import('../../../../servidor/pagos/crearPedido');
  const { marcarPreciosGuardados } = await import('../../../../servidor/nucleo/precios');
  const { VERSION_TERMINOS_SERVIDOR } = await import('../../../../servidor/nucleo/legal');
  const { esGradoDeSecundaria } = await import('../../../../servidor/pagos/totales');
  esSecundariaServidor = esGradoDeSecundaria;
  versionTerminos = VERSION_TERMINOS_SERVIDOR;
  marcarPreciosGuardados();
  const app = express();
  app.use(express.json({ limit: '4mb' }));
  app.use(rutasCrearPedido, rutasReservas);
  servidor = app.listen(0);
  await new Promise((ok) => servidor.once('listening', ok));
  puerto = (servidor.address() as AddressInfo).port;
}, 120_000);

afterAll(async () => {
  await new Promise((ok) => servidor.close(ok));
  delete process.env.MERCADOPAGO_ACCESS_TOKEN;
});

beforeEach(() => {
  base.reiniciar();
  base.filas('colegios').push({ id: COLEGIO, nombre: 'Colegio Prueba' });
  base.filas('codigos_seccion').push(
    { id: 's1', colegio_id: COLEGIO, grado: '1° grado', turno: 'Mañana', division: 'A', codigo_secreto: 'AB12-CD34' },
    { id: 's2', colegio_id: COLEGIO, grado: '3° año', turno: 'Mañana', division: 'B', codigo_secreto: 'SE12-CU34' }
  );
});

const reservar = (codigoSeccion: string, kitId: string) =>
  pedir('/api/reservas/crear', {
    tutorNombre: 'Ana', tutorEmail: 'mama@prueba.test', metodoPago: 'mercadopago', aceptaTerminos: true, versionTerminos,
    items: [{ codigoSeccion, alumnoNombre: 'Lola Perez', kitId }],
  });

// 29/10/2026 (Pablo): se vuelve a habilitar el Solo Digital en secundaria.
describe('Secundaria: Kit Solo Digital habilitado otra vez', () => {
  it('reconoce los cursos de secundaria igual en el servidor y en la web', () => {
    for (const [grado, esperado] of [['3° año', true], ['1 año', true], ['6°Año', true], ['Sala 4 años', false], ['1° grado', false], ['', false]] as const) {
      expect(esSecundariaServidor(grado)).toBe(esperado);
      expect(esSecundariaFront(grado)).toBe(esperado);
    }
    const kits = [{ id: 'kit-clasico' }, { id: 'kit-digital' }];
    expect(kitsParaGrados(kits, ['1° grado', '2° año']).map((k) => k.id)).toEqual(['kit-clasico', 'kit-digital']);
    expect(kitsParaGrados(kits, ['1° grado', undefined]).map((k) => k.id)).toEqual(['kit-clasico', 'kit-digital']);
  });

  it('pago anticipado: secundaria y primaria pueden elegir los dos kits', async () => {
    expect((await reservar('SE12-CU34', 'kit-digital')).status).toBe(200);
    expect((await reservar('SE12-CU34', 'kit-clasico')).status).toBe(200);
    expect((await reservar('AB12-CD34', 'kit-digital')).status).toBe(200);
    expect(base.filas('pedidos').map((p) => p.tipo_kit).sort()).toEqual(['impreso_digital', 'solo_digital', 'solo_digital']);
  });

  it('compra desde la galería (un hijo y carrito): acepta el Solo Digital de secundaria', async () => {
    const uno = await pedir('/api/pedidos/crear', { kitId: 'kit-digital', grado: '3° año', turno: 'Mañana', division: 'B', colegioId: COLEGIO, alumnoNombre: 'Lola Perez', aceptaTerminos: true, versionTerminos });
    expect(uno.json?.error || '').not.toMatch(/secundaria/i);
    const carrito = await pedir('/api/pedidos/crear-multiple', {
      aceptaTerminos: true, versionTerminos, confirmarOtroKit: true, tutorNombre: 'Ana', tutorTelefono: '1155551234',
      items: [{ kitId: 'kit-digital', grado: '3° año', turno: 'Mañana', division: 'B', colegioId: COLEGIO, alumnoNombre: 'Lola Perez' }],
    });
    expect(carrito.json?.error || '').not.toMatch(/secundaria/i);
  });
});
