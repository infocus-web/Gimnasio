// Auditoría 11/10 (pagos): pruebas de regresión de los arreglos PAG-1, PAG-2, PAG-3, PAG-4 y PAG-6.
// Corren las rutas reales de servidor/pagos con una base falsa en memoria (baseFalsa.ts); Mercado Pago
// y Nave están reemplazados por dobles. Nada sale a la red.
import crypto from 'crypto';
import http from 'http';
import type { AddressInfo } from 'net';
import express from 'express';
import { afterAll, beforeAll, beforeEach, describe, expect, it, vi } from 'vitest';
import * as base from './baseFalsa';

vi.mock('dotenv', () => {
  const config = () => ({ parsed: {} });
  return { default: { config }, config };
});
vi.mock('@supabase/supabase-js', async () => {
  const m = await import('./baseFalsa');
  return { createClient: () => m.cliente };
});
const mp = vi.hoisted(() => ({ pagos: {} as Record<string, any> }));
vi.mock('mercadopago', () => ({
  MercadoPagoConfig: class {},
  Preference: class {
    async create() {
      return { id: 'pref-1', init_point: 'https://mp/pref-1' };
    }
  },
  Payment: class {
    async get({ id }: { id: string }) {
      return mp.pagos[String(id)];
    }
    async search() {
      return { results: [] };
    }
  },
  PaymentRefund: class {},
}));

const CLAVE_MP = 'clave-webhook';
const COLEGIO = '11111111-1111-4111-8111-111111111111';
let servidor: http.Server;
let puerto = 0;
let llave: (ref: string) => string;
let cursoDe: (g: string, t: string, d: string) => string;
let versionTerminos = '';

function pedir(metodo: string, ruta: string, cuerpo?: unknown, encabezados: Record<string, string> = {}): Promise<{ status: number; json: any; texto: string }> {
  return new Promise((ok, mal) => {
    const datos = cuerpo === undefined ? undefined : JSON.stringify(cuerpo);
    const h: Record<string, string | number> = { ...encabezados };
    if (datos) {
      h['Content-Type'] = 'application/json';
      h['Content-Length'] = Buffer.byteLength(datos);
    }
    const req = http.request({ host: '127.0.0.1', port: puerto, path: ruta, method: metodo, headers: h }, (res) => {
      let texto = '';
      res.setEncoding('utf8');
      res.on('data', (c) => (texto += c));
      res.on('end', () => {
        let json: any = null;
        try { json = JSON.parse(texto); } catch { /* texto plano */ }
        ok({ status: res.statusCode || 0, json, texto });
      });
    });
    req.on('error', mal);
    if (datos) req.write(datos);
    req.end();
  });
}

const firmar = (id: string) => {
  const ts = Math.floor(Date.now() / 1000);
  const v1 = crypto.createHmac('sha256', CLAVE_MP).update(`id:${id};request-id:r1;ts:${ts};`).digest('hex');
  return { 'x-signature': `ts=${ts},v1=${v1}`, 'x-request-id': 'r1' };
};
const avisoMp = (id: string) => pedir('POST', `/api/mercadopago/webhook?data.id=${id}&type=payment`, { type: 'payment', data: { id } }, firmar(id));
const hace = (h: number) => new Date(Date.now() - h * 3600 * 1000).toISOString();
const pedido = (id: string) => base.filas('pedidos').find((p) => p.id === id);
const falla = { code: '57014', message: 'canceling statement due to statement timeout' };

beforeAll(async () => {
  process.env.SUPABASE_SERVICE_ROLE_KEY = 'prueba';
  process.env.ADMIN_SESSION_SECRET = 'secreto-de-prueba-largo-para-hmac';
  process.env.MERCADOPAGO_ACCESS_TOKEN = 'prueba';
  process.env.MERCADOPAGO_WEBHOOK_SECRET = CLAVE_MP;
  process.env.NAVE_ENVIRONMENT = 'production';
  process.env.NAVE_CLIENT_ID = 'cliente';
  process.env.NAVE_CLIENT_SECRET = 'secreto';
  process.env.NAVE_POS_ID = 'pos';
  const { rutasReservas } = await import('../../../../servidor/pagos/crearPedido');
  const { rutasEstadoPedido } = await import('../../../../servidor/pagos/estadoPedido');
  const { rutasComprobantes } = await import('../../../../servidor/pagos/comprobantes');
  const { rutasMercadoPagoWebhook } = await import('../../../../servidor/pagos/mercadoPago');
  const { rutasNave } = await import('../../../../servidor/pagos/nave');
  const { rutasBuscadorPedidos } = await import('../../../../servidor/pagos/buscadorPedidos');
  const { marcarPreciosGuardados } = await import('../../../../servidor/nucleo/precios');
  const { tokenAccesoPedido } = await import('../../../../servidor/nucleo/accesoPedidos');
  const { determinarCodigoCursoServidor } = await import('../../../../servidor/nucleo/codigosCurso');
  const { VERSION_TERMINOS_SERVIDOR } = await import('../../../../servidor/nucleo/legal');
  versionTerminos = VERSION_TERMINOS_SERVIDOR;
  marcarPreciosGuardados();
  llave = (ref) => tokenAccesoPedido(ref) as string;
  cursoDe = determinarCodigoCursoServidor;
  const app = express();
  app.use(express.json({ limit: '4mb' }));
  app.use(rutasReservas, rutasEstadoPedido, rutasComprobantes, rutasMercadoPagoWebhook, rutasNave, rutasBuscadorPedidos);
  servidor = app.listen(0);
  await new Promise((ok) => servidor.once('listening', ok));
  puerto = (servidor.address() as AddressInfo).port;
}, 120_000);

afterAll(async () => {
  await new Promise((ok) => servidor.close(ok));
  for (const n of ['NAVE_ENVIRONMENT', 'NAVE_CLIENT_ID', 'NAVE_CLIENT_SECRET', 'NAVE_POS_ID', 'MERCADOPAGO_ACCESS_TOKEN', 'MERCADOPAGO_WEBHOOK_SECRET']) delete process.env[n];
});

beforeEach(() => {
  base.reiniciar();
  mp.pagos = {};
  base.filas('colegios').push({ id: COLEGIO, nombre: 'Colegio Prueba' });
  base.filas('codigos_seccion').push({ id: 's1', colegio_id: COLEGIO, grado: '1', turno: 'Mañana', division: 'A', codigo_secreto: 'AB12-CD34' });
  base.filas('familias').push({ id: 'fam-1', nombre: 'Ana', email: 'mama@prueba.test', whatsapp: '11 5555-1234' });
});

describe('PAG-1: /api/reservas/crear anula la reserva vieja recién después de registrar la nueva', () => {
  const reservar = (extra: Record<string, any>, item: Record<string, any> = {}) =>
    pedir('POST', '/api/reservas/crear', {
      tutorNombre: 'Ana', tutorEmail: 'mama@prueba.test', metodoPago: 'mercadopago', aceptaTerminos: true, versionTerminos,
      items: [{ codigoSeccion: 'AB12-CD34', alumnoNombre: 'Lola Perez', kitId: 'kit-digital', ...item }],
      ...extra,
    });
  const reservaVieja = (id: string, grupo: string) => ({ id, familia_id: 'fam-1', colegio_id: COLEGIO, curso_codigo: cursoDe('1', 'Mañana', 'A'), alumno_nombre: 'Lola Perez', seleccion_pendiente: true, estado: 'pendiente_pago', cancelado_definitivo: false, archivado: false, total: 15000, grupo_pago_id: grupo });
  const G = '22222222-2222-4222-8222-222222222222';
  const hermanoConLink = { id: 'H1', familia_id: 'fam-1', colegio_id: COLEGIO, curso_codigo: 'OTRO', alumno_nombre: 'Leo Perez', seleccion_pendiente: false, estado: 'pendiente_pago', cancelado_definitivo: false, archivado: false, total: 30000, grupo_pago_id: G, mp_preference_id: 'pref-G' };

  it('un 409 por grupo con link de pago no deja cancelada la reserva vieja (otro grupo)', async () => {
    base.filas('pedidos').push({ ...reservaVieja('R1', 'GVIEJO'), mp_preference_id: 'pref-viejo' }, { ...hermanoConLink });
    const r = await reservar({ grupoPagoId: G, t: llave(G) });
    expect(r.status).toBe(409);
    expect(pedido('R1')).toMatchObject({ estado: 'pendiente_pago', cancelado_definitivo: false });
  });

  it('un 409 tampoco cancela la reserva vieja del MISMO grupo (el link sigue cobrando lo que existe)', async () => {
    base.filas('pedidos').push({ ...reservaVieja('RS', G), mp_preference_id: 'pref-G' }, { ...hermanoConLink });
    const r = await reservar({ grupoPagoId: G, t: llave(G) }, { kitId: 'kit-clasico', reservaId: '55555555-5555-4555-8555-555555555555' });
    expect(r.status).toBe(409);
    expect(pedido('RS')).toMatchObject({ estado: 'pendiente_pago', cancelado_definitivo: false });
    expect(base.filas('pedidos')).toHaveLength(2);
  });

  it('camino feliz: la nueva reserva queda registrada y la vieja sin pagar SÍ se cancela (definitivo)', async () => {
    base.filas('pedidos').push(reservaVieja('R1', 'GVIEJO'));
    const nuevoId = '77777777-7777-4777-8777-777777777777';
    const r = await reservar({}, { reservaId: nuevoId });
    expect(r.status).toBe(200);
    expect(r.json.success).toBe(true);
    expect(pedido('R1')).toMatchObject({ estado: 'cancelado', cancelado_definitivo: true });
    expect(pedido(nuevoId)).toMatchObject({ estado: 'pendiente_pago', cancelado_definitivo: false, seleccion_pendiente: true });
  });

  it('camino feliz sin reservaId (navegador viejo): no cancela la reserva que acaba de crear', async () => {
    base.filas('pedidos').push(reservaVieja('R1', 'GVIEJO'));
    const r = await reservar({});
    expect(r.status).toBe(200);
    const nuevas = base.filas('pedidos').filter((p) => p.id !== 'R1');
    expect(nuevas).toHaveLength(1);
    expect(nuevas[0].cancelado_definitivo).toBe(false);
    expect(pedido('R1').cancelado_definitivo).toBe(true);
  });
});

describe('PAG-2: reembolsos y contracargos con la base caída → 500 para que la pasarela reintente', () => {
  it('Mercado Pago: si falla el UPDATE de la reversión responde 500; el reintento cancela una sola vez (idempotente)', async () => {
    base.filas('pedidos').push({ id: 'P1', estado: 'pagado', mp_payment_id: '999', cancelado_definitivo: false, total: 30000 });
    mp.pagos['999'] = { status: 'refunded', external_reference: 'P1', transaction_amount: 30000 };
    base.estado.fallas.push((tabla, op, cambios) => (tabla === 'pedidos' && op === 'update' && cambios?.cancelado_definitivo ? falla : null));
    expect((await avisoMp('999')).status).toBe(500);
    expect(pedido('P1').estado).toBe('pagado');

    base.estado.fallas = [];
    expect((await avisoMp('999')).status).toBe(200);
    expect(pedido('P1')).toMatchObject({ estado: 'cancelado', cancelado_definitivo: true });
    expect(base.alertas()).toEqual(['reembolso-mp:999']);
    // Mercado Pago repite el aviso: mismo estado final, sin alerta duplicada.
    expect((await avisoMp('999')).status).toBe(200);
    expect(pedido('P1')).toMatchObject({ estado: 'cancelado', cancelado_definitivo: true });
    expect(base.alertas()).toEqual(['reembolso-mp:999']);
  });

  it('Mercado Pago: si falla la lectura de las filas del pago, un "cancelled" no se toma por rechazo (500)', async () => {
    base.filas('pedidos').push({ id: 'P1', estado: 'pagado', mp_payment_id: '998', metodo_pago: 'mercadopago', cancelado_definitivo: false, total: 30000 });
    mp.pagos['998'] = { status: 'cancelled', external_reference: 'P1', transaction_amount: 30000 };
    base.estado.fallas.push((tabla, op) => (tabla === 'pedidos' && op === 'select' ? falla : null));
    expect((await avisoMp('998')).status).toBe(500);
    base.estado.fallas = [];
    expect((await avisoMp('998')).status).toBe(200);
    expect(pedido('P1')).toMatchObject({ estado: 'cancelado', cancelado_definitivo: true });
  });

  it('Nave: si falla el UPDATE de la reversión responde 500 (sin la alerta engañosa) y el reintento la cancela', async () => {
    base.filas('pedidos').push({ id: 'P2', estado: 'pagado', nave_payment_id: 'nv1', cancelado_definitivo: false, total: 30000 });
    vi.stubGlobal('fetch', async (url: string) => {
      const json = String(url).includes('/auth0/') ? { access_token: 'tok', expires_in: 3600 } : { status: { name: 'REFUNDED' }, external_payment_id: 'P2' };
      return new Response(JSON.stringify(json), { status: 200, headers: { 'Content-Type': 'application/json' } });
    });
    base.estado.fallas.push((tabla, op, cambios) => (tabla === 'pedidos' && op === 'update' && cambios?.cancelado_definitivo ? falla : null));
    const aviso = () => pedir('POST', '/api/nave/webhook', { payment_id: 'nv1' }); // sin estado: no lo frena el turno de 5 s
    expect((await aviso()).status).toBe(500);
    expect(pedido('P2').estado).toBe('pagado');
    expect(base.alertas()).toEqual([]);
    base.estado.fallas = [];
    expect((await aviso()).status).toBe(200);
    expect(pedido('P2')).toMatchObject({ estado: 'cancelado', cancelado_definitivo: true });
    expect(base.alertas()).toEqual(['reversion-nave:nv1']);
  });
});

describe('PAG-3: una transferencia vencida no se revive desde el portal', () => {
  it('cambiar-metodo-pago responde 409 TRANSFERENCIA_VENCIDA y el pedido sigue cancelado (recuperable desde el panel)', async () => {
    const id = '33333333-3333-4333-8333-333333333333';
    base.filas('pedidos').push({ id, familia_id: 'fam-1', estado: 'cancelado', metodo_pago: 'transferencia', cancelado_definitivo: false, archivado: false, en_espera: false, total: 30000, transferencia_desde: hace(60), transferencia_vencida_at: hace(12) });
    // Revisión 11/10: sólo se frena volver a TRANSFERENCIA; con tarjeta puede pagar (crear-preferencia igual arma el link).
    for (const metodoPago of ['transferencia']) {
      const r = await pedir('POST', `/api/pedidos/${id}/cambiar-metodo-pago`, { metodoPago, t: llave(id) });
      expect(r.status).toBe(409);
      expect(r.json).toMatchObject({ success: false, codigo: 'TRANSFERENCIA_VENCIDA', error: 'El plazo para pagar este pedido venció. Escribinos y lo reabrimos.' });
    }
    expect(pedido(id)).toMatchObject({ estado: 'cancelado', metodo_pago: 'transferencia' });
  });

  it('un rechazo de tarjeta ("cancelado" sin vencimiento) sigue pudiendo cambiar de medio', async () => {
    const id = '44444444-4444-4444-8444-444444444444';
    base.filas('pedidos').push({ id, estado: 'cancelado', metodo_pago: 'mercadopago', cancelado_definitivo: false, total: 30000, transferencia_vencida_at: null });
    const r = await pedir('POST', `/api/pedidos/${id}/cambiar-metodo-pago`, { metodoPago: 'transferencia', t: llave(id) });
    expect(r.status).toBe(200);
    expect(pedido(id)).toMatchObject({ estado: 'pendiente_pago', metodo_pago: 'transferencia' });
  });
});

describe('PAG-4: elegir las fotos de una reserva que se reembolsa en el medio', () => {
  it('el UPDATE exige pagado y no cancelado: no confirma ni entrega el HD de un pedido ya reembolsado', async () => {
    const curso = cursoDe('1', 'Mañana', 'A');
    const id = '66666666-6666-4666-8666-666666666666';
    const pub = hace(1);
    base.filas('fotos').push(
      { id: 'fi', colegio_id: COLEGIO, codigo_curso: curso, categoria: 'individual', alumno_nombre: 'Lola Perez', publicada_at: pub },
      { id: 'fg', colegio_id: COLEGIO, codigo_curso: curso, categoria: 'grupal', alumno_nombre: null, publicada_at: pub },
      { id: 'fd', colegio_id: COLEGIO, codigo_curso: curso, categoria: 'docente', alumno_nombre: null, publicada_at: pub },
    );
    base.filas('pedidos').push({ id, familia_id: 'fam-1', colegio_id: COLEGIO, curso_codigo: curso, alumno_nombre: 'Lola Perez', seleccion_pendiente: true, estado: 'pagado', mp_payment_id: '777', cancelado_definitivo: false, archivado: false, total: 15000, grupo_pago_id: null, email_enviado: true });
    let yaCancelado = false;
    base.estado.fallas.push((tabla, op) => {
      if (!yaCancelado && tabla === 'fotos' && op === 'select') {
        yaCancelado = true; // el webhook del reembolso entra mientras se validan las fotos
        Object.assign(pedido(id), { estado: 'cancelado', cancelado_definitivo: true });
      }
      return null;
    });
    const r = await pedir('POST', `/api/reservas/${id}/elegir-fotos`, {
      codigo: 'AB12-CD34', fotos: { grupalId: 'fg', individualId: 'fi', docenteId: 'fd' }, confirmaPersonalizacion: true, versionTerminos, t: llave(id),
    });
    expect(r.status).toBe(409);
    expect(pedido(id)).toMatchObject({ estado: 'cancelado', seleccion_pendiente: true, email_enviado: true });
  });
});

describe('PAG-6: seguimiento por teléfono tolera espacios, guiones y +54 9', () => {
  it.each([
    ['11 5555-1234', '1155551234'],
    ['11 5555-1234', '11 5555-1234'],
    ['+54 9 11 5555-1234', '1155551234'],
    ['1155551234', '+54 9 11 5555-1234'],
  ])('guardado "%s", buscado "%s" → lo encuentra', async (guardado, buscado) => {
    base.filas('pedidos').push({ id: 'P9', pedido_friendly_id: 'IFS-2026-1234', estado: 'pagado', total: 30000, created_at: hace(5), familias: { nombre: 'Ana Perez', whatsapp: guardado } });
    const r = await pedir('GET', `/api/pedidos/buscar?query=${encodeURIComponent(buscado)}`);
    expect(r.status).toBe(200);
    expect(r.json.pedido.id).toBe('IFS-2026-1234');
  });

  it('otro número no coincide, y un comodín tipeado no llega al patrón', async () => {
    base.filas('pedidos').push({ id: 'P9', pedido_friendly_id: 'IFS-2026-1234', estado: 'pagado', total: 30000, created_at: hace(5), familias: { nombre: 'Ana Perez', whatsapp: '11 5555-1234' } });
    expect((await pedir('GET', '/api/pedidos/buscar?query=1166667777')).status).toBe(404);
    // Revisión 11/10: los dígitos tienen que ir seguidos (sólo separadores en el medio) y al final del número.
    expect((await pedir('GET', '/api/pedidos/buscar?query=1155551239')).status).toBe(404);
    base.filas('pedidos').push({ id: 'P8', pedido_friendly_id: 'IFS-2026-1235', estado: 'pagado', total: 30000, created_at: hace(6), familias: { nombre: 'Otra', whatsapp: '11 95 5 5 5 9 1 2 3 4' } });
    expect((await pedir('GET', '/api/pedidos/buscar?query=1122223333')).status).toBe(404);
    expect((await pedir('GET', `/api/pedidos/buscar?query=${encodeURIComponent('%%%%%%%%55551234')}`)).status).toBe(200);
    expect((await pedir('GET', `/api/pedidos/buscar?query=${encodeURIComponent('%%%%%%%%%%')}`)).status).toBe(404);
  });
});
