// Códigos de descuento (22/10/2026, Pablo): porcentaje elegido en el panel (hasta 100%), sólo sobre el kit, usos y
// vencimiento opcionales; el monto lo calcula el servidor; en $0 el pedido nace pagado («bonificado») y no entra en
// la liquidación del colegio. Rutas reales con la base falsa en memoria.
import http from 'http';
import type { AddressInfo } from 'net';
import express from 'express';
import { afterAll, beforeAll, beforeEach, describe, expect, it, vi } from 'vitest';
import * as base from './baseFalsa';

vi.mock('dotenv', () => {
  const config = () => ({ parsed: {} });
  return { default: { config }, config };
});
vi.mock('@supabase/supabase-js', async () => {
  const m = await import('./baseFalsa');
  return { createClient: () => m.cliente };
});
vi.mock('mercadopago', () => ({
  MercadoPagoConfig: class {},
  Preference: class {
    async create() {
      return { id: 'pref-1', init_point: 'https://mp/pref-1' };
    }
  },
  Payment: class {},
  PaymentRefund: class {},
}));

const COLEGIO = '11111111-1111-4111-8111-111111111111';
let servidor: http.Server;
let puerto = 0;
let versionTerminos = '';
let curso = '';
let token = '';

function pedir(ruta: string, cuerpo: unknown, metodo = 'POST', auth = ''): Promise<{ status: number; json: any }> {
  return new Promise((ok, mal) => {
    const datos = cuerpo === undefined ? '' : JSON.stringify(cuerpo);
    const headers: Record<string, string | number> = { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(datos) };
    if (auth) headers.Authorization = `Bearer ${auth}`;
    const req = http.request({ host: '127.0.0.1', port: puerto, path: ruta, method: metodo, headers }, (res) => {
      let texto = '';
      res.setEncoding('utf8');
      res.on('data', (c) => (texto += c));
      res.on('end', () => {
        let json: any = null;
        try { json = JSON.parse(texto); } catch { /* texto plano */ }
        ok({ status: res.statusCode || 0, json });
      });
    });
    req.on('error', mal);
    if (datos) req.write(datos);
    req.end();
  });
}

beforeAll(async () => {
  process.env.SUPABASE_SERVICE_ROLE_KEY = 'prueba';
  process.env.ADMIN_SESSION_SECRET = 'secreto-de-prueba-largo-para-hmac';
  process.env.MERCADOPAGO_ACCESS_TOKEN = 'prueba';
  const { rutasCrearPedido, rutasReservas } = await import('../../../../servidor/pagos/crearPedido');
  const { rutasDescuentos } = await import('../../../../servidor/pagos/descuentos');
  const { marcarPreciosGuardados } = await import('../../../../servidor/nucleo/precios');
  const { VERSION_TERMINOS_SERVIDOR } = await import('../../../../servidor/nucleo/legal');
  const { determinarCodigoCursoServidor } = await import('../../../../servidor/nucleo/codigosCurso');
  const { generateAdminToken } = await import('../../../../servidor/nucleo/auth');
  versionTerminos = VERSION_TERMINOS_SERVIDOR;
  curso = determinarCodigoCursoServidor('1', 'Mañana', 'A');
  token = generateAdminToken() || '';
  marcarPreciosGuardados();
  const app = express();
  app.use(express.json({ limit: '4mb' }));
  app.use(rutasCrearPedido, rutasReservas, rutasDescuentos);
  servidor = app.listen(0);
  await new Promise((ok) => servidor.once('listening', ok));
  puerto = (servidor.address() as AddressInfo).port;
}, 120_000);

afterAll(async () => {
  await new Promise((ok) => servidor.close(ok));
  delete process.env.MERCADOPAGO_ACCESS_TOKEN;
});

const pub = new Date(Date.now() - 3600_000).toISOString();
const foto = (id: string, categoria: string) => ({ id, colegio_id: COLEGIO, codigo_curso: curso, categoria, alumno_nombre: null, publicada_at: pub });
const codigo = (extra: Record<string, unknown> = {}) => ({ id: crypto.randomUUID(), codigo: 'DOCENTE-AB12', porcentaje: 100, usos_max: null, usos: 0, vence_at: null, activo: true, nota: null, ...extra });

beforeEach(() => {
  base.reiniciar();
  base.filas('colegios').push({ id: COLEGIO, nombre: 'Colegio Prueba' });
  base.filas('codigos_seccion').push({ id: 's1', colegio_id: COLEGIO, grado: '1', turno: 'Mañana', division: 'A', codigo_secreto: 'AB12-CD34' });
  base.filas('fotos').push(foto('fg', 'grupal'), foto('fi', 'individual'), foto('fd', 'docente'));
});

let n = 0;
const crear = (extra: Record<string, unknown> = {}) =>
  pedir('/api/pedidos/crear', {
    pedidoId: crypto.randomUUID(), kitId: 'kit-clasico', carpetasExtras: 0, tutorNombre: 'Ana', tutorTelefono: '1155551234', tutorEmail: `familia${++n}@prueba.test`,
    metodoPago: 'mercadopago', colegioId: COLEGIO, colegioNombre: 'Colegio Prueba', grado: '1', division: 'A', turno: 'Mañana', alumnoNombre: `Chico ${n}`,
    fotosSeleccionadas: { individualId: 'fi', grupalId: 'fg', docenteId: 'fd', otrasIds: [] }, aceptaTerminos: true, versionTerminos, claveCheckout: 'clave-prueba-1234567890',
    ...extra,
  });
const pedido = (id: string) => base.filas('pedidos').find((p) => p.id === id);

describe('Compra con código de descuento', () => {
  it('sin código, todo igual que antes ($30.000, pendiente de pago)', async () => {
    const r = await crear();
    expect(r.status).toBe(200);
    expect(pedido(r.json.pedidoId)).toMatchObject({ total: 30000, estado: 'pendiente_pago', metodo_pago: 'mercadopago' });
    expect(pedido(r.json.pedidoId)?.codigo_descuento).toBeUndefined();
  });

  it('50%: sólo sobre el kit; las carpetas extra se cobran completas', async () => {
    base.filas('codigos_descuento').push(codigo({ codigo: 'MITAD-2026', porcentaje: 50 }));
    const r = await crear({ codigoDescuento: ' mitad-2026 ', carpetasExtras: 1 });
    expect(r.status).toBe(200);
    expect(r.json.total).toBe(15000 + 15000);
    expect(pedido(r.json.pedidoId)).toMatchObject({ total: 30000, estado: 'pendiente_pago', codigo_descuento: 'MITAD-2026', descuento_pct: 50, descuento_monto: 15000 });
  });

  it('100% en el kit digital: nace pagado, «bonificado», sin pasarela', async () => {
    base.filas('codigos_descuento').push(codigo());
    const r = await crear({ codigoDescuento: 'DOCENTE-AB12', kitId: 'kit-digital' });
    expect(r.status).toBe(200);
    expect(r.json).toMatchObject({ bonificado: true, total: 0 });
    expect(pedido(r.json.pedidoId)).toMatchObject({ total: 0, estado: 'pagado', metodo_pago: 'bonificado' });
    expect(pedido(r.json.pedidoId)?.pagado_at).toBeTruthy();
  });

  it('Pablo 22/10: en el kit impreso el 100% queda en 70% (la impresión no se regala) y se paga el resto', async () => {
    base.filas('codigos_descuento').push(codigo());
    const r = await crear({ codigoDescuento: 'DOCENTE-AB12', metodoPago: 'transferencia' });
    expect(r.json.bonificado).toBeUndefined();
    expect(pedido(r.json.pedidoId)).toMatchObject({ total: 9000, estado: 'pendiente_pago', metodo_pago: 'transferencia', descuento_pct: 70, descuento_monto: 21000 });
  });

  it('Pablo 27/10: un código marcado «sin tope en el impreso» deja el kit impreso al 100%, sin cargo', async () => {
    base.filas('codigos_descuento').push(codigo({ sin_tope_impreso: true }));
    const r = await crear({ codigoDescuento: 'DOCENTE-AB12', metodoPago: 'transferencia' });
    expect(r.json).toMatchObject({ bonificado: true, total: 0 });
    expect(pedido(r.json.pedidoId)).toMatchObject({ total: 0, estado: 'pagado', metodo_pago: 'bonificado', descuento_pct: 100, descuento_monto: 30000 });
  });

  it('un código de 70% o menos vale igual en el kit impreso', async () => {
    base.filas('codigos_descuento').push(codigo({ porcentaje: 70 }));
    const r = await crear({ codigoDescuento: 'DOCENTE-AB12', carpetasExtras: 1 });
    expect(pedido(r.json.pedidoId)).toMatchObject({ total: 9000 + 15000, descuento_pct: 70 });
  });

  it('código inexistente, desactivado o vencido: 400 y no se registra nada', async () => {
    base.filas('codigos_descuento').push(codigo({ codigo: 'APAGADO-1', activo: false }), codigo({ codigo: 'VIEJO-1', vence_at: new Date(Date.now() - 1000).toISOString() }));
    for (const c of ['NO-EXISTE', 'APAGADO-1', 'VIEJO-1', 'x']) {
      const r = await crear({ codigoDescuento: c });
      expect(r.status).toBe(400);
      expect(r.json.codigo).toBe('DESCUENTO_INVALIDO');
    }
    expect(base.filas('pedidos')).toHaveLength(0);
  });

  it('usos: un código de 1 uso no sirve para una segunda compra, ni aunque lleguen juntas', async () => {
    base.filas('codigos_descuento').push(codigo({ usos_max: 1, porcentaje: 50 }));
    const juntas = await Promise.all([crear({ codigoDescuento: 'DOCENTE-AB12' }), crear({ codigoDescuento: 'DOCENTE-AB12' }), crear({ codigoDescuento: 'DOCENTE-AB12' })]);
    expect(juntas.map((r) => r.status).sort()).toEqual([200, 400, 400]);
    expect(base.filas('pedidos')).toHaveLength(1);
    expect(base.filas('codigos_descuento')[0].usos).toBe(1);
  });

  it('revisión 22/10: un reintento del mismo pedido sin cargo no gasta otro uso y vuelve a decir «bonificado»', async () => {
    base.filas('codigos_descuento').push(codigo({ usos_max: 1 }));
    const pedidoId = crypto.randomUUID();
    const tutorEmail = 'docente@prueba.test';
    const alumnoNombre = 'Seño Laura';
    const claveCheckout = 'a'.repeat(32);
    const primero = await crear({ codigoDescuento: 'DOCENTE-AB12', pedidoId, tutorEmail, alumnoNombre, claveCheckout, kitId: 'kit-digital' });
    const reintento = await crear({ codigoDescuento: 'DOCENTE-AB12', pedidoId, tutorEmail, alumnoNombre, claveCheckout, kitId: 'kit-digital' });
    expect(primero.json.bonificado).toBe(true);
    expect(reintento.status).toBe(200);
    expect(reintento.json).toMatchObject({ bonificado: true, pedidoId });
    expect(base.filas('codigos_descuento')[0].usos).toBe(1);
  });

  it('validar: dice el porcentaje de un código vigente y rechaza uno que no existe', async () => {
    base.filas('codigos_descuento').push(codigo({ codigo: 'MITAD-2026', porcentaje: 50 }));
    expect((await pedir('/api/descuentos/validar', { codigo: 'mitad-2026' })).json).toMatchObject({ success: true, codigo: 'MITAD-2026', porcentaje: 50 });
    expect((await pedir('/api/descuentos/validar', { codigo: 'OTRO-1234' })).status).toBe(404);
  });
});

describe('Carrito de hermanos con código', () => {
  const item = (nombre: string, kitId = 'kit-clasico') => ({
    pedidoId: crypto.randomUUID(), kitId, carpetasExtras: 0, metodoPago: 'mercadopago', colegioId: COLEGIO, colegioNombre: 'Colegio Prueba', grado: '1', division: 'A', turno: 'Mañana',
    alumnoNombre: nombre, fotosSeleccionadas: { individualId: 'fi', grupalId: 'fg', docenteId: 'fd', otrasIds: [] },
  });
  const carrito = (extra: Record<string, unknown> = {}) =>
    pedir('/api/pedidos/crear-multiple', { tutorNombre: 'Ana', tutorTelefono: '1155551234', tutorEmail: 'hermanos@prueba.test', aceptaTerminos: true, versionTerminos, claveCheckout: 'clave-prueba-1234567890', items: [item('Uno Perez'), item('Dos Perez')], ...extra });

  it('24/10: 100% con un uso por kit: 2 usos dejan los 2 kits «bonificado» y se gastan los 2', async () => {
    base.filas('codigos_descuento').push(codigo({ usos_max: 2 }));
    const r = await carrito({ codigoDescuento: 'DOCENTE-AB12', items: [item('Uno Perez', 'kit-digital'), item('Dos Perez', 'kit-digital')] });
    expect(r.status).toBe(200);
    expect(r.json).toMatchObject({ bonificado: true, total: 0 });
    expect(base.filas('pedidos').map((p) => [p.estado, p.metodo_pago, p.total])).toEqual([['pagado', 'bonificado', 0], ['pagado', 'bonificado', 0]]);
    expect(base.filas('codigos_descuento')[0].usos).toBe(2);
  });

  it('24/10 (auditoría): un código de 1 uso descuenta UN solo kit del carrito; el resto se cobra completo', async () => {
    base.filas('codigos_descuento').push(codigo({ usos_max: 1, porcentaje: 50 }));
    const r = await carrito({ codigoDescuento: 'DOCENTE-AB12', items: [item('Uno Perez'), item('Dos Perez'), item('Tres Perez')] });
    expect(r.status).toBe(200);
    expect(r.json.total).toBe(15000 + 30000 + 30000);
    expect(base.filas('pedidos').filter((p) => p.codigo_descuento === 'DOCENTE-AB12')).toHaveLength(1);
    expect(base.filas('codigos_descuento')[0].usos).toBe(1);
  });

  it('24/10: 100% de 1 uso con 2 kits: uno quedaría en $0 junto a otro que se paga → no se mezcla y no gasta el uso', async () => {
    base.filas('codigos_descuento').push(codigo({ usos_max: 1 }));
    const r = await carrito({ codigoDescuento: 'DOCENTE-AB12', items: [item('Uno Perez', 'kit-digital'), item('Dos Perez', 'kit-digital')] });
    expect(r.status).toBe(400);
    expect(r.json.codigo).toBe('DESCUENTO_COMBINADO');
    expect(base.filas('pedidos')).toHaveLength(0);
    expect(base.filas('codigos_descuento')[0].usos).toBe(0);
  });

  it('revisión 22/10: un kit en $0 no se mezcla con lo que se paga (otro hermano con extras o reservas sumadas)', async () => {
    base.filas('codigos_descuento').push(codigo({ usos_max: 5 }));
    const conExtra = await pedir('/api/pedidos/crear-multiple', { tutorNombre: 'Ana', tutorTelefono: '1155551234', tutorEmail: 'hermanos@prueba.test', aceptaTerminos: true, versionTerminos, claveCheckout: 'clave-prueba-1234567890', codigoDescuento: 'DOCENTE-AB12', items: [item('Uno Perez', 'kit-digital'), item('Dos Perez')] });
    expect(conExtra.status).toBe(400);
    expect(conExtra.json.error).toMatch(/sin cargo/);
    expect(conExtra.json.codigo).toBe('DESCUENTO_COMBINADO'); // el portal no borra el código en este caso
    const conReservas = await carrito({ codigoDescuento: 'DOCENTE-AB12', sumaReservas: true, items: [item('Uno Perez', 'kit-digital')] });
    expect(conReservas.status).toBe(400);
    expect(base.filas('pedidos')).toHaveLength(0);
    expect(base.filas('codigos_descuento')[0].usos).toBe(0); // no se gastó ningún uso
  });

  it('con 50%, el carrito con extras se paga normal (cada kit con su descuento)', async () => {
    base.filas('codigos_descuento').push(codigo({ porcentaje: 50 }));
    const r = await pedir('/api/pedidos/crear-multiple', { tutorNombre: 'Ana', tutorTelefono: '1155551234', tutorEmail: 'hermanos@prueba.test', aceptaTerminos: true, versionTerminos, claveCheckout: 'clave-prueba-1234567890', codigoDescuento: 'DOCENTE-AB12', items: [item('Uno Perez'), { ...item('Dos Perez'), carpetasExtras: 1 }] });
    expect(r.status).toBe(200);
    expect(r.json.total).toBe(15000 + 15000 + 15000);
    expect(base.filas('pedidos').every((p) => p.estado === 'pendiente_pago')).toBe(true);
  });
});

describe('Panel «Descuentos»', () => {
  it('sólo con la sesión del panel; crea un código al azar con el porcentaje, y lo desactiva', async () => {
    expect((await pedir('/api/admin/descuentos', { porcentaje: 30 })).status).toBe(401);
    expect((await pedir('/api/admin/descuentos', { porcentaje: 0 }, 'POST', token)).status).toBe(400);
    const r = await pedir('/api/admin/descuentos', { porcentaje: 30, usosMax: 5, vence: '2099-12-31', nota: 'Docentes 1° A' }, 'POST', token);
    expect(r.status).toBe(200);
    expect(r.json.codigo).toMatchObject({ porcentaje: 30, usos_max: 5, activo: true, nota: 'Docentes 1° A' });
    expect(r.json.codigo.codigo).toMatch(/^RE-[A-Z0-9]{8}$/);
    const lista = await pedir('/api/admin/descuentos', undefined, 'GET', token);
    expect(lista.json.codigos).toHaveLength(1);
    const off = await pedir(`/api/admin/descuentos/${r.json.codigo.id}/activo`, { activo: false }, 'POST', token);
    expect(off.json.codigo.activo).toBe(false);
    expect((await pedir('/api/descuentos/validar', { codigo: r.json.codigo.codigo })).status).toBe(404);
  });

  it('Pablo 28/10: lote para docentes y administrativos — un código al azar por persona, 100% digital y 70% impreso', async () => {
    expect((await pedir('/api/admin/descuentos/lote', { porcentaje: 100, nombres: ['Laura'] })).status).toBe(401);
    expect((await pedir('/api/admin/descuentos/lote', { porcentaje: 100, nombres: ['  ', ''] }, 'POST', token)).status).toBe(400);
    const r = await pedir('/api/admin/descuentos/lote', { porcentaje: 100, usosMax: 1, nombres: ['Laura Gómez', 'Marcelo  Pérez', 'laura gómez', ''] }, 'POST', token);
    expect(r.status).toBe(200);
    expect(r.json.codigos.map((c: any) => c.nota)).toEqual(['Laura Gómez', 'Marcelo Pérez']);
    expect(new Set(r.json.codigos.map((c: any) => c.codigo)).size).toBe(2);
    for (const c of r.json.codigos) expect(c).toMatchObject({ porcentaje: 100, usos_max: 1, activo: true, sin_tope_impreso: false, ambito: 'kit' });
    const impreso = await crear({ codigoDescuento: r.json.codigos[0].codigo, metodoPago: 'transferencia' });
    expect(pedido(impreso.json.pedidoId)).toMatchObject({ total: 9000, descuento_pct: 70 });
    const digital = await crear({ codigoDescuento: r.json.codigos[1].codigo, kitId: 'kit-digital' });
    expect(digital.json).toMatchObject({ bonificado: true, total: 0 });
  });

  it('lote: más de 500 personas se rechaza sin crear nada', async () => {
    const r = await pedir('/api/admin/descuentos/lote', { porcentaje: 100, nombres: Array.from({ length: 501 }, (_, i) => `Persona ${i}`) }, 'POST', token);
    expect(r.status).toBe(400);
    expect(base.filas('codigos_descuento')).toHaveLength(0);
  });
});
