// Base Supabase falsa en memoria para las pruebas de auditoría 11/10 de pagos (no es una prueba).
// Defaults de columnas como en la base real: pedidos.cancelado_definitivo/archivado = false, reportes_errores.estado = 'nuevo'.
// Soporta lo que usan las rutas de servidor/pagos: filtros, joins a familias, insert/update con
// .select(), count/head, range, rpc y storage. Permite inyectar errores por tabla/operación.
import crypto from 'crypto';

export const estado = {
  tablas: {} as Record<string, any[]>,
  fallas: [] as Array<(tabla: string, op: string, cambios: any) => any>,
  subidas: [] as string[],
};

export function reiniciar() {
  estado.tablas = {};
  estado.fallas = [];
  estado.subidas = [];
}

const valor = (fila: any, campo: string) => {
  if (campo.includes('->>')) {
    const [col, clave] = campo.split('->>');
    return fila[col]?.[clave] ?? null;
  }
  if (campo.includes('.')) {
    const [rel, col] = campo.split('.');
    const r = fila[rel];
    return (Array.isArray(r) ? r[0] : r)?.[col] ?? null;
  }
  return fila[campo] ?? null;
};
const comparar = (a: any, b: any) => {
  if (typeof a === 'number' && typeof b === 'number') return a - b;
  const fa = Date.parse(a);
  const fb = Date.parse(b);
  if (typeof a === 'string' && /^\d{4}-/.test(a) && Number.isFinite(fa) && Number.isFinite(fb)) return fa - fb;
  return String(a).localeCompare(String(b));
};
const comoRegex = (patron: string) => new RegExp(`^${String(patron).replace(/[.*+?^${}()|[\]\\]/g, '\\$&').replace(/%/g, '.*').replace(/_/g, '.')}$`, 'i');

function conJoins(tabla: string, fila: any, columnas: string) {
  const copia = JSON.parse(JSON.stringify(fila));
  if (tabla === 'pedidos' && /familias/.test(columnas) && copia.familias === undefined) {
    copia.familias = (estado.tablas.familias || []).find((f) => f.id === copia.familia_id) || null;
  }
  return copia;
}

function consulta(tabla: string) {
  const filtros: Array<(f: any) => boolean> = [];
  let cambios: Record<string, any> | null = null;
  let nuevas: any[] | null = null;
  let unica = false;
  let soloConteo = false;
  let conConteo = false;
  let columnas = '*';
  let rango: [number, number] | null = null;
  let limite = Infinity;
  let borrar = false;
  const ordenes: { campo: string; asc: boolean }[] = [];
  const q: any = {
    select: (c?: string, o?: { count?: string; head?: boolean }) => {
      if (c) columnas = c;
      if (o?.head) soloConteo = true;
      if (o?.count) conConteo = true;
      return q;
    },
    eq: (c: string, v: any) => (filtros.push((f) => valor(f, c) === v), q),
    neq: (c: string, v: any) => (filtros.push((f) => valor(f, c) !== v), q),
    is: (c: string, v: any) => (filtros.push((f) => valor(f, c) === v), q),
    not: (c: string, op: string, v: any) => (filtros.push((f) => !(op === 'is' && valor(f, c) === v)), q),
    in: (c: string, vs: any[]) => (filtros.push((f) => vs.includes(valor(f, c))), q),
    ilike: (c: string, p: string) => (filtros.push((f) => comoRegex(p).test(String(valor(f, c) ?? ''))), q),
    filter: (c: string, op: string, p: string) => { if (op !== 'imatch') throw new Error(`filter ${op} no simulado`); filtros.push((f) => new RegExp(p, 'i').test(String(valor(f, c) ?? ''))); return q; }, // POSIX ~*
    contains: (c: string, vs: any[]) => (filtros.push((f) => Array.isArray(f[c]) && vs.every((v) => f[c].includes(v))), q),
    gt: (c: string, v: any) => (filtros.push((f) => valor(f, c) !== null && comparar(valor(f, c), v) > 0), q),
    gte: (c: string, v: any) => (filtros.push((f) => valor(f, c) !== null && comparar(valor(f, c), v) >= 0), q),
    lt: (c: string, v: any) => (filtros.push((f) => valor(f, c) !== null && comparar(valor(f, c), v) < 0), q),
    lte: (c: string, v: any) => (filtros.push((f) => valor(f, c) !== null && comparar(valor(f, c), v) <= 0), q),
    order: (campo: string, o?: { ascending?: boolean }) => (ordenes.push({ campo, asc: o?.ascending !== false }), q),
    range: (d: number, h: number) => ((rango = [d, h]), q),
    limit: (n: number) => ((limite = n), q),
    abortSignal: () => q,
    update: (c: Record<string, any>) => ((cambios = c), q),
    insert: (f: any) => ((nuevas = Array.isArray(f) ? f : [f]), q),
    upsert: (f: any) => ((nuevas = Array.isArray(f) ? f : [f]), q),
    delete: () => ((borrar = true), q),
    maybeSingle: () => ((unica = true), q),
    single: () => ((unica = true), q),
    then: (ok: any, mal: any) => Promise.resolve(ejecutar()).then(ok, mal),
  };
  function ejecutar() {
    const op = nuevas ? 'insert' : cambios ? 'update' : borrar ? 'delete' : 'select';
    for (const falla of estado.fallas) {
      const error = falla(tabla, op, cambios || nuevas);
      if (error) return { data: null, error, count: null };
    }
    const filas = (estado.tablas[tabla] = estado.tablas[tabla] || []);
    if (nuevas) {
      for (const f of nuevas) {
        if (f.id && filas.some((e) => e.id === f.id)) return { data: null, error: { code: '23505', message: `duplicate key value violates unique constraint "${tabla}_pkey"` } };
      }
      const creadas = nuevas.map((f) => ({ id: f.id || crypto.randomUUID(), created_at: new Date().toISOString(), cancelado_definitivo: tabla === 'pedidos' ? false : undefined, archivado: tabla === 'pedidos' ? false : undefined, estado: tabla === 'reportes_errores' ? 'nuevo' : undefined, ...f }));
      filas.push(...creadas);
      const copia = creadas.map((f) => conJoins(tabla, f, columnas));
      return { data: unica ? copia[0] : copia, error: null };
    }
    let elegidas = filas.filter((f) => filtros.every((fn) => fn(f)));
    if (borrar) {
      estado.tablas[tabla] = filas.filter((f) => !elegidas.includes(f));
      return { data: null, error: null };
    }
    if (cambios) for (const f of elegidas) Object.assign(f, cambios);
    for (const { campo, asc } of [...ordenes].reverse()) {
      elegidas = [...elegidas].sort((a, b) => (asc ? 1 : -1) * comparar(valor(a, campo), valor(b, campo)));
    }
    if (rango) elegidas = elegidas.slice(rango[0], rango[1] + 1);
    const total = elegidas.length;
    if (soloConteo) return { data: null, error: null, count: total };
    const copia = elegidas.slice(0, limite).map((f) => conJoins(tabla, f, columnas));
    return { data: unica ? copia[0] ?? null : copia, error: null, count: conConteo ? total : null };
  }
  return q;
}

export const cliente = {
  from: (tabla: string) => consulta(tabla),
  // 22/10: los usos de un código de descuento se suman/devuelven como en la base (ver la migración 20261022200000).
  rpc: async (nombre?: string, args?: any) => {
    const c = filas('codigos_descuento').find((x) => x.codigo === args?.p_codigo);
    if (nombre === 'usar_codigo_descuento') {
      if (!c || c.activo === false || (c.vence_at && Date.parse(c.vence_at) < Date.now()) || (c.usos_max != null && (c.usos || 0) >= c.usos_max)) return { data: null, error: null };
      c.usos = (c.usos || 0) + 1;
      return { data: c.porcentaje, error: null };
    }
    if (nombre === 'devolver_uso_codigo_descuento') {
      if (c) c.usos = Math.max(0, (c.usos || 0) - 1);
      return { data: null, error: null };
    }
    return { data: 0, error: null };
  },
  storage: {
    from: () => ({
      upload: async (ruta: string) => (estado.subidas.push(ruta), { data: { path: ruta }, error: null }),
      remove: async () => ({ data: null, error: null }),
      createSignedUrl: async (ruta: string) => ({ data: { signedUrl: `https://firmado/${ruta}` }, error: null }),
      createSignedUrls: async (rutas: string[]) => ({ data: rutas.map((ruta) => ({ path: ruta, signedUrl: `https://firmado/${ruta}` })), error: null }), // 29/10: lotes de fotos extra
    }),
  },
};

export const filas = (tabla: string) => (estado.tablas[tabla] = estado.tablas[tabla] || []);
export const alertas = () => filas('reportes_errores').map((r) => String(r.detalle?.clave || ''));
