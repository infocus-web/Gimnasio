// 22/10/2026 (Pablo: «si un alumno le falta una foto, ya sea porque no quiso o porque no estaba presente el día
// de la toma, no podrá terminar el pedido»): la familia avisa «Mi hijo/a no tiene esta foto» y en ese lugar
// elige otra foto del curso o sigue sin ella (fotos_seleccionadas.sinFoto). Corre las rutas reales de compra y
// de reservas con la base falsa en memoria; también las reglas compartidas (impresiones, laboratorio).
import http from 'http';
import type { AddressInfo } from 'net';
import express from 'express';
import { afterAll, beforeAll, beforeEach, describe, expect, it, vi } from 'vitest';
import * as base from './baseFalsa';
import { generarArchivosParaLaboratorio } from '../../../services/pedidosLabService';
import * as front from '../../../utils/fotosFaltantes';
import * as servidorReglas from '../../../../servidor/nucleo/fotosFaltantes';
import { contarImpresionesPedido } from '../../../../servidor/nucleo/pedidos';

vi.mock('dotenv', () => {
  const config = () => ({ parsed: {} });
  return { default: { config }, config };
});
vi.mock('@supabase/supabase-js', async () => {
  const m = await import('./baseFalsa');
  return { createClient: () => m.cliente };
});
vi.mock('mercadopago', () => ({
  MercadoPagoConfig: class {},
  Preference: class {
    async create() {
      return { id: 'pref-1', init_point: 'https://mp/pref-1' };
    }
  },
  Payment: class {},
  PaymentRefund: class {},
}));

const COLEGIO = '11111111-1111-4111-8111-111111111111';
const RESERVA = '66666666-6666-4666-8666-666666666666';
let servidor: http.Server;
let puerto = 0;
let versionTerminos = '';
let curso = '';
let llave: (ref: string) => string;

function pedir(ruta: string, cuerpo: unknown): Promise<{ status: number; json: any }> {
  return new Promise((ok, mal) => {
    const datos = JSON.stringify(cuerpo);
    const req = http.request(
      { host: '127.0.0.1', port: puerto, path: ruta, method: 'POST', headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(datos) } },
      (res) => {
        let texto = '';
        res.setEncoding('utf8');
        res.on('data', (c) => (texto += c));
        res.on('end', () => {
          let json: any = null;
          try { json = JSON.parse(texto); } catch { /* texto plano */ }
          ok({ status: res.statusCode || 0, json });
        });
      }
    );
    req.on('error', mal);
    req.write(datos);
    req.end();
  });
}

beforeAll(async () => {
  process.env.SUPABASE_SERVICE_ROLE_KEY = 'prueba';
  process.env.ADMIN_SESSION_SECRET = 'secreto-de-prueba-largo-para-hmac';
  process.env.MERCADOPAGO_ACCESS_TOKEN = 'prueba';
  const { rutasCrearPedido, rutasReservas } = await import('../../../../servidor/pagos/crearPedido');
  const { marcarPreciosGuardados } = await import('../../../../servidor/nucleo/precios');
  const { VERSION_TERMINOS_SERVIDOR } = await import('../../../../servidor/nucleo/legal');
  const { determinarCodigoCursoServidor } = await import('../../../../servidor/nucleo/codigosCurso');
  const { tokenAccesoPedido } = await import('../../../../servidor/nucleo/accesoPedidos');
  versionTerminos = VERSION_TERMINOS_SERVIDOR;
  curso = determinarCodigoCursoServidor('1', 'Mañana', 'A');
  llave = (ref) => tokenAccesoPedido(ref) as string;
  marcarPreciosGuardados();
  const app = express();
  app.use(express.json({ limit: '4mb' }));
  app.use(rutasCrearPedido, rutasReservas);
  servidor = app.listen(0);
  await new Promise((ok) => servidor.once('listening', ok));
  puerto = (servidor.address() as AddressInfo).port;
}, 120_000);

afterAll(async () => {
  await new Promise((ok) => servidor.close(ok));
  delete process.env.MERCADOPAGO_ACCESS_TOKEN;
});

const pub = new Date(Date.now() - 3600_000).toISOString();
const foto = (id: string, categoria: string, alumno_nombre: string | null = null) => ({ id, colegio_id: COLEGIO, codigo_curso: curso, categoria, alumno_nombre, publicada_at: pub });

beforeEach(() => {
  base.reiniciar();
  base.filas('colegios').push({ id: COLEGIO, nombre: 'Colegio Prueba' });
  base.filas('codigos_seccion').push({ id: 's1', colegio_id: COLEGIO, grado: '1', turno: 'Mañana', division: 'A', codigo_secreto: 'AB12-CD34' });
  base.filas('familias').push({ id: 'fam-1', nombre: 'Ana', email: 'mama@prueba.test', whatsapp: '11 5555-1234' });
  // Curso SIN individual de Lola (estuvo ausente): grupal, otra grupal, la de la seño y la individual de otro chico.
  base.filas('fotos').push(foto('fg', 'grupal'), foto('fg2', 'grupal'), foto('fd', 'docente'), foto('fi-otro', 'individual', 'Juan Gomez'), foto('fp', 'patio'));
  base.filas('pedidos').push({ id: RESERVA, familia_id: 'fam-1', colegio_id: COLEGIO, curso_codigo: curso, alumno_nombre: 'Lola Perez', seleccion_pendiente: true, estado: 'pagado', mp_payment_id: '777', cancelado_definitivo: false, archivado: false, total: 30000, tipo_kit: 'impreso_digital', grupo_pago_id: null, email_enviado: true });
});

const elegir = (fotos: Record<string, unknown>) =>
  pedir(`/api/reservas/${RESERVA}/elegir-fotos`, { codigo: 'AB12-CD34', fotos, confirmaPersonalizacion: true, versionTerminos, t: llave(RESERVA) });
const reserva = () => base.filas('pedidos').find((p) => p.id === RESERVA);

describe('Reserva pagada: el chico no tiene una foto del pack', () => {
  it('sin avisar, la individual sigue siendo obligatoria (no cambia nada para el resto)', async () => {
    const r = await elegir({ grupalId: 'fg', individualId: '', docenteId: 'fd' });
    expect(r.status).toBe(400);
    expect(reserva()?.seleccion_pendiente).toBe(true);
  });

  it('26/10 (Pablo: «el kit sí o sí lleva 3 fotos»): «no tiene la individual» ya no deja seguir sin ella', async () => {
    const r = await elegir({ grupalId: 'fg', individualId: '', docenteId: 'fd', sinFoto: ['individual'] });
    expect(r.status).toBe(400);
    expect(r.json.error).toMatch(/lleva siempre 3 fotos/);
    expect(reserva()?.seleccion_pendiente).toBe(true);
  });

  it('«no tiene la individual» y en su lugar elige otra foto del curso (otra grupal)', async () => {
    const r = await elegir({ grupalId: 'fg', individualId: 'fg2', docenteId: 'fd', sinFoto: ['individual'] });
    expect(r.status).toBe(200);
    expect(reserva()?.fotos_seleccionadas).toMatchObject({ individualId: 'fg2', sinFoto: ['individual'] });
  });

  it('no se puede poner en su lugar la individual con nombre de otro chico', async () => {
    const r = await elegir({ grupalId: 'fg', individualId: 'fi-otro', docenteId: 'fd', sinFoto: ['individual'] });
    expect(r.status).toBe(400);
    expect(r.json.error).toMatch(/otro alumno/);
  });

  it('no se repite la misma foto en dos lugares, ni queda un kit sin ninguna foto', async () => {
    expect((await elegir({ grupalId: 'fg', individualId: 'fg', docenteId: 'fd', sinFoto: ['individual'] })).status).toBe(400);
    const vacio = await elegir({ grupalId: '', individualId: '', sinFoto: ['individual', 'grupal', 'docente'] });
    expect(vacio.status).toBe(400);
    expect(vacio.json.error).toMatch(/lleva siempre 3 fotos/);
  });

  it('una reserva no suma fotos sueltas que no se pagaron', async () => {
    const r = await elegir({ grupalId: 'fg', individualId: 'fg2', docenteId: 'fd', sinFoto: ['individual'], otrasIds: ['fp'] });
    expect(r.status).toBe(200);
    expect(reserva()?.fotos_seleccionadas.otrasIds).toBeUndefined();
  });

  it('revisión 22/10: una foto suelta (patio) no entra al pack, ni en el lugar de una que falta', async () => {
    const r = await elegir({ grupalId: 'fg', individualId: 'fp', docenteId: 'fd', sinFoto: ['individual'] });
    expect(r.status).toBe(400);
  });

  it('revisión 22/10: en un curso sin 3ª foto, «no tiene la 3ª» no deja sumar una foto gratis', async () => {
    base.estado.tablas.fotos = base.filas('fotos').filter((f) => f.categoria !== 'docente');
    const r = await elegir({ grupalId: 'fg', individualId: '', docenteId: 'fg2', sinFoto: ['individual', 'docente'] });
    expect(r.status).toBe(400);
    const ok = await elegir({ grupalId: 'fg', individualId: 'fg2', sinFoto: ['individual', 'docente'] });
    expect(ok.status).toBe(200);
    expect(reserva()?.fotos_seleccionadas).toEqual({ grupalId: 'fg', individualId: 'fg2', sinFoto: ['individual'] });
  });

  it('un valor raro en sinFoto se ignora (sólo individual, grupal y la 3ª)', async () => {
    const r = await elegir({ grupalId: 'fg', individualId: '', docenteId: 'fd', sinFoto: ['patio', 'cualquiera'] });
    expect(r.status).toBe(400);
  });
});

describe('Compra desde la galería con «no tiene esta foto»', () => {
  it('se registra con el mismo precio y guarda sinFoto', async () => {
    const cuerpo = (sinFoto?: string[]) => ({
      pedidoId: sinFoto ? '77777777-7777-4777-8777-777777777777' : '88888888-8888-4888-8888-888888888888',
      kitId: 'kit-clasico', carpetasExtras: 0, tutorNombre: 'Ana', tutorTelefono: '1155551234', tutorEmail: 'mama@prueba.test', metodoPago: 'mercadopago',
      colegioId: COLEGIO, colegioNombre: 'Colegio Prueba', grado: '1', division: 'A', turno: 'Mañana', alumnoNombre: sinFoto ? 'Mia Lopez' : 'Juan Gomez',
      fotosSeleccionadas: sinFoto ? { individualId: 'fg2', grupalId: 'fg', docenteId: 'fd', otrasIds: [], sinFoto } : { individualId: 'fi-otro', grupalId: 'fg', docenteId: 'fd', otrasIds: [] },
      aceptaTerminos: true, versionTerminos, claveCheckout: 'clave-prueba-1234567890',
    });
    const conFaltante = await pedir('/api/pedidos/crear', cuerpo(['individual']));
    expect(conFaltante.status).toBe(200);
    const normal = await pedir('/api/pedidos/crear', cuerpo());
    expect(normal.status).toBe(200);
    const [a, b] = ['Mia Lopez', 'Juan Gomez'].map((n) => base.filas('pedidos').find((p) => p.alumno_nombre === n));
    expect(a?.fotos_seleccionadas).toMatchObject({ individualId: 'fg2', sinFoto: ['individual'] });
    expect(a?.total).toBe(b?.total);
  });
});

describe('Reglas compartidas', () => {
  it('servidor y web dicen lo mismo', () => {
    for (const sel of [{ sinFoto: ['grupal', 'x', 'individual'] }, { sinFoto: 'individual' }, null, {}]) {
      expect(front.lugaresSinFoto(sel)).toEqual(servidorReglas.lugaresSinFoto(sel));
    }
    for (const lugar of ['individual', 'grupal', 'docente'] as const) {
      for (const cat of ['individual', 'grupal', 'docente', 'familia', 'patio', '', undefined]) {
        for (const sf of [[], [lugar]] as const) {
          expect(front.categoriaValeEnLugar(cat, lugar, sf)).toBe(servidorReglas.categoriaValeEnLugar(cat, lugar, sf));
        }
      }
    }
  });

  it('impresiones: sin individual ni reemplazo no se cuenta; con reemplazo sí', () => {
    const base1 = { copias_extras: { carpetasExtras: 1 } };
    expect(contarImpresionesPedido({ ...base1, fotos_seleccionadas: { individualId: 'a', grupalId: 'b', docenteId: 'c' } })).toMatchObject({ fotos20x30: 2, fotos15x21: 4 });
    expect(contarImpresionesPedido({ ...base1, fotos_seleccionadas: { individualId: '', grupalId: 'b', docenteId: 'c', sinFoto: ['individual'] } })).toMatchObject({ fotos20x30: 2, fotos15x21: 2 });
    expect(contarImpresionesPedido({ ...base1, fotos_seleccionadas: { individualId: 'x', grupalId: 'b', docenteId: 'c', sinFoto: ['individual'] } })).toMatchObject({ fotos20x30: 2, fotos15x21: 4 });
    expect(contarImpresionesPedido({ ...base1, fotos_seleccionadas: { individualId: 'a', grupalId: '', sinFoto: ['grupal'] } })).toMatchObject({ fotos20x30: 0, fotos15x21: 2 });
  });

  it('laboratorio: el lugar sin foto no genera archivo (ni «Falta foto»); el reemplazo va en ese lugar', () => {
    const galeria: any[] = [
      { id: 'fg', categoria: 'grupal', thumbnail: 't', url: 'u', titulo: 'G' },
      { id: 'fg2', categoria: 'grupal', thumbnail: 't', url: 'u', titulo: 'G2' },
      { id: 'fd', categoria: 'docente', thumbnail: 't', url: 'u', titulo: 'D' },
    ];
    const sin = generarArchivosParaLaboratorio('1AMA', 3, 'Lola Perez', { individualId: '', grupalId: 'fg', docenteId: 'fd', sinFoto: ['individual'] }, { carpetasExtras: 1, individual15x21: 1, grupal20x30: 1, docente15x21: 1 }, galeria);
    expect(sin.some((a) => a.tipo === 'individual')).toBe(false);
    expect(sin.some((a) => a.sinFotoReal)).toBe(false);
    expect(sin.filter((a) => a.tipo === 'grupal')).toHaveLength(2);
    const con = generarArchivosParaLaboratorio('1AMA', 3, 'Lola Perez', { individualId: 'fg2', grupalId: 'fg', docenteId: 'fd', sinFoto: ['individual'] }, undefined, galeria);
    expect(con.find((a) => a.tipo === 'individual')).toMatchObject({ urlMuestra: 't', tamanoImpresion: '15x21' });
    expect(con.find((a) => a.tipo === 'individual')?.sinFotoReal).toBeFalsy();
    // Revisión 22/10: las fotos sueltas pagadas (OTRAS, que también son tipo 'individual') no se pierden.
    const conSueltas = generarArchivosParaLaboratorio('1AMA', 3, 'Lola Perez', { individualId: '', grupalId: 'fg', otrasIds: ['fp'], sinFoto: ['individual'] }, undefined, [...galeria, { id: 'fp', categoria: 'patio', thumbnail: 't', url: 'u', titulo: 'P' }]);
    expect(conSueltas.filter((a) => a.nombreArchivoOriginal === 'OTRAS_HD.jpg')).toHaveLength(1);
    expect(conSueltas.some((a) => a.nombreArchivoOriginal === 'INDIVIDUAL_HD.jpg')).toBe(false);
    // Un pedido viejo (sin sinFoto) sigue marcando «Falta foto» si no aparece la individual.
    const viejo = generarArchivosParaLaboratorio('1AMA', 3, 'Lola Perez', { individualId: 'no-existe', grupalId: 'fg' }, undefined, galeria);
    expect(viejo.find((a) => a.tipo === 'individual')?.sinFotoReal).toBe(true);
  });
});
