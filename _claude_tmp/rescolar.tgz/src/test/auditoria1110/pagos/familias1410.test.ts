// 14/10/2026 (auditoría de familias y pagos): pruebas de comportamiento de los arreglos del lado servidor.
// Corren las rutas reales de servidor/pagos y el cron de recordatorios con la base falsa en memoria
// (baseFalsa.ts); Mercado Pago, Nave y Resend están reemplazados por dobles. Nada sale a la red.
import crypto from 'crypto';
import http from 'http';
import type { AddressInfo } from 'net';
import express from 'express';
import { afterAll, beforeAll, beforeEach, describe, expect, it, vi } from 'vitest';
import * as base from './baseFalsa';

vi.mock('dotenv', () => {
  const config = () => ({ parsed: {} });
  return { default: { config }, config };
});
vi.mock('@supabase/supabase-js', async () => {
  const m = await import('./baseFalsa');
  return { createClient: () => m.cliente };
});
const dobles = vi.hoisted(() => ({
  correos: [] as Array<{ mensaje: any; opciones: any }>,
  procesar: null as null | (() => Promise<void>),
}));
vi.mock('resend', () => ({
  Resend: class {
    emails = { send: async (mensaje: any, opciones?: any) => (dobles.correos.push({ mensaje, opciones }), { data: { id: 'mail' }, error: null }) };
    batch = { send: async () => ({ data: { data: [] }, error: null }) };
  },
}));
vi.mock('mercadopago', () => ({
  MercadoPagoConfig: class {},
  Preference: class {
    async create() {
      return { id: 'pref-1', init_point: 'https://mp/pref-1' };
    }
  },
  Payment: class {
    async get() {
      return null;
    }
    async search() {
      return { results: [] };
    }
  },
  PaymentRefund: class {},
}));
vi.mock('../../../../servidor/entrega/pedidosPagados', async (original) => ({
  ...((await original()) as object),
  procesarPedidosRecienPagados: async () => (dobles.procesar ? dobles.procesar() : undefined),
}));

const COLEGIO = '11111111-1111-4111-8111-111111111111';
const FAMILIA = 'aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa';
const G = '22222222-2222-4222-8222-222222222222';
const P1 = '33333333-3333-4333-8333-333333333333';
const P2 = '44444444-4444-4444-8444-444444444444';
let servidor: http.Server;
let puerto = 0;
let llave: (ref: string) => string;
let cursoDe: (g: string, t: string, d: string) => string;
let versionTerminos = '';
let cobros: typeof import('../../../../servidor/pagos/cobros');
let aviso: typeof import('../../../../servidor/pagos/avisoPedidoPendiente');

function pedir(metodo: string, ruta: string, cuerpo?: unknown, encabezados: Record<string, string> = {}): Promise<{ status: number; json: any }> {
  return new Promise((ok, mal) => {
    const datos = cuerpo === undefined ? undefined : JSON.stringify(cuerpo);
    const h: Record<string, string | number> = { ...encabezados };
    if (datos) {
      h['Content-Type'] = 'application/json';
      h['Content-Length'] = Buffer.byteLength(datos);
    }
    const req = http.request({ host: '127.0.0.1', port: puerto, path: ruta, method: metodo, headers: h }, (res) => {
      let texto = '';
      res.setEncoding('utf8');
      res.on('data', (c) => (texto += c));
      res.on('end', () => {
        let json: any = null;
        try { json = JSON.parse(texto); } catch { /* texto plano */ }
        ok({ status: res.statusCode || 0, json });
      });
    });
    req.on('error', mal);
    if (datos) req.write(datos);
    req.end();
  });
}

const hace = (h: number) => new Date(Date.now() - h * 3600 * 1000).toISOString();
const pedido = (id: string) => base.filas('pedidos').find((p) => p.id === id);
const fila = (id: string, extra: Record<string, any> = {}) => ({
  id, familia_id: 'fam-1', estado: 'pendiente_pago', metodo_pago: 'transferencia', cancelado_definitivo: false, archivado: false, en_espera: false,
  total: 30000, grupo_pago_id: null, colegio_id: COLEGIO, curso_codigo: 'K', alumno_nombre: `Chico ${id.slice(0, 4)}`, pedido_friendly_id: `IFS-2026-${id.slice(0, 4)}`,
  comprobante_subido_at: null, recordatorio_pago_at: null, created_at: hace(1), ...extra,
});
const accesoGaleria = (id: string) => crypto.createHmac('sha256', 'secreto-de-prueba-largo-para-hmac').update(`acceso-galeria:${id}`).digest('base64url').slice(0, 32);

beforeAll(async () => {
  process.env.SUPABASE_SERVICE_ROLE_KEY = 'prueba';
  process.env.ADMIN_SESSION_SECRET = 'secreto-de-prueba-largo-para-hmac';
  process.env.MERCADOPAGO_ACCESS_TOKEN = 'prueba';
  process.env.RESEND_API_KEY = 'prueba';
  process.env.CRON_SECRET = 'secreto-cron';
  const { rutasReservas } = await import('../../../../servidor/pagos/crearPedido');
  const { rutasEstadoPedido } = await import('../../../../servidor/pagos/estadoPedido');
  const { rutasMercadoPagoPreferencias } = await import('../../../../servidor/pagos/mercadoPago');
  const { rutasNave } = await import('../../../../servidor/pagos/nave');
  const { rutasBuscadorPedidos } = await import('../../../../servidor/pagos/buscadorPedidos');
  const { rutasArrepentimiento } = await import('../../../../servidor/pagos/arrepentimiento');
  const { rutasTareasProgramadas } = await import('../../../../servidor/tareasProgramadas');
  const { marcarPreciosGuardados } = await import('../../../../servidor/nucleo/precios');
  const { tokenAccesoPedido } = await import('../../../../servidor/nucleo/accesoPedidos');
  const { determinarCodigoCursoServidor } = await import('../../../../servidor/nucleo/codigosCurso');
  const { VERSION_TERMINOS_SERVIDOR } = await import('../../../../servidor/nucleo/legal');
  cobros = await import('../../../../servidor/pagos/cobros');
  aviso = await import('../../../../servidor/pagos/avisoPedidoPendiente');
  versionTerminos = VERSION_TERMINOS_SERVIDOR;
  marcarPreciosGuardados();
  llave = (ref) => tokenAccesoPedido(ref) as string;
  cursoDe = determinarCodigoCursoServidor;
  const app = express();
  app.use(express.json({ limit: '4mb' }));
  app.use(rutasReservas, rutasEstadoPedido, rutasMercadoPagoPreferencias, rutasNave, rutasBuscadorPedidos, rutasArrepentimiento, rutasTareasProgramadas);
  servidor = app.listen(0);
  await new Promise((ok) => servidor.once('listening', ok));
  puerto = (servidor.address() as AddressInfo).port;
}, 120_000);

afterAll(async () => {
  await new Promise((ok) => servidor.close(ok));
  for (const n of ['MERCADOPAGO_ACCESS_TOKEN', 'RESEND_API_KEY', 'CRON_SECRET']) delete process.env[n];
});

beforeEach(() => {
  base.reiniciar();
  dobles.correos = [];
  dobles.procesar = null;
  base.filas('colegios').push({ id: COLEGIO, nombre: 'Colegio Prueba' });
  base.filas('codigos_seccion').push({ id: 's1', colegio_id: COLEGIO, grado: '1', turno: 'Mañana', division: 'A', codigo_secreto: 'AB12-CD34' });
  base.filas('familias').push({ id: 'fam-1', nombre: 'Ana', email: 'mama@prueba.test', whatsapp: '11 5555-1234' });
});

describe('fix 1: transferencia con comprobante subido → no se invita a pagar de nuevo', () => {
  it('cambiar-metodo-pago a tarjeta: 409 COMPROBANTE_YA_SUBIDO (comprobante en un hermano del carrito); con confirmarIgual pasa', async () => {
    base.filas('pedidos').push(fila(P1, { grupo_pago_id: G }), fila(P2, { grupo_pago_id: G, comprobante_subido_at: hace(1) }));
    const r = await pedir('POST', `/api/pedidos/${P1}/cambiar-metodo-pago`, { metodoPago: 'mercadopago', t: llave(G) });
    expect(r.status).toBe(409);
    expect(r.json).toMatchObject({ success: false, codigo: 'COMPROBANTE_YA_SUBIDO' });
    expect(pedido(P1).metodo_pago).toBe('transferencia');
    const igual = await pedir('POST', `/api/pedidos/${P1}/cambiar-metodo-pago`, { metodoPago: 'mercadopago', t: llave(G), confirmarIgual: true });
    expect(igual.status).toBe(200);
    expect([pedido(P1).metodo_pago, pedido(P2).metodo_pago]).toEqual(['mercadopago', 'mercadopago']);
  });

  it('sin comprobante (o volviendo a transferencia) el cambio de medio sigue como siempre', async () => {
    base.filas('pedidos').push(fila(P1, { metodo_pago: 'mercadopago' }), fila(P2, { comprobante_subido_at: hace(1) }));
    expect((await pedir('POST', `/api/pedidos/${P1}/cambiar-metodo-pago`, { metodoPago: 'nave', t: llave(P1) })).status).toBe(200);
    expect((await pedir('POST', `/api/pedidos/${P2}/cambiar-metodo-pago`, { metodoPago: 'transferencia', t: llave(P2) })).status).toBe(200);
  });

  it('crear-preferencia (Mercado Pago) y crear-intencion (Nave): 409 sin confirmación; MP con confirmarIgual genera el link', async () => {
    base.filas('pedidos').push(fila(P1, { metodo_pago: 'mercadopago', comprobante_subido_at: hace(2) }));
    const mp = await pedir('POST', '/api/mercadopago/crear-preferencia', { pedidoId: P1, t: llave(P1) });
    expect(mp.status).toBe(409);
    expect(mp.json.codigo).toBe('COMPROBANTE_YA_SUBIDO');
    expect(pedido(P1).mp_preference_id).toBeUndefined();
    const nave = await pedir('POST', '/api/nave/crear-intencion', { pedidoId: P1, t: llave(P1) });
    expect(nave.status).toBe(409);
    expect(nave.json.codigo).toBe('COMPROBANTE_YA_SUBIDO');
    const igual = await pedir('POST', '/api/mercadopago/crear-preferencia', { pedidoId: P1, t: llave(P1), confirmarIgual: true });
    expect(igual.status).toBe(200);
    expect(igual.json).toMatchObject({ success: true, initPoint: 'https://mp/pref-1' });
  });

  it('el estado del pedido informa comprobanteSubido (también por un hermano del carrito)', async () => {
    base.filas('pedidos').push(fila(P1, { grupo_pago_id: G }), fila(P2, { grupo_pago_id: G, comprobante_subido_at: hace(1) }));
    expect((await pedir('GET', `/api/pedidos/${P1}/status`)).json).toMatchObject({ success: true, comprobanteSubido: true });
    base.filas('pedidos').push(fila('55555555-5555-4555-8555-555555555555'));
    expect((await pedir('GET', '/api/pedidos/55555555-5555-4555-8555-555555555555/status')).json.comprobanteSubido).toBe(false);
  });

  it('cobro por la pasarela de un pedido con comprobante subido → alerta pago-doble-transferencia', async () => {
    base.filas('pedidos').push(fila('A', { grupo_pago_id: G, comprobante_subido_at: hace(1) }), fila('B', { grupo_pago_id: G }));
    const r = await cobros.marcarReferenciaComoPagada(base.cliente as any, G, 60000, { mp_payment_id: '91' });
    expect(r).toHaveLength(2);
    expect(base.alertas()).toContain(`pago-doble-transferencia:${G}`);
  });

  it('sin comprobante, o aprobado a mano (sin pasarela), no hay alerta de pago doble por transferencia', async () => {
    base.filas('pedidos').push(fila('A', { comprobante_subido_at: null }), fila('C', { comprobante_subido_at: hace(1) }));
    await cobros.marcarReferenciaComoPagada(base.cliente as any, 'A', 30000, { mp_payment_id: '92' });
    await cobros.marcarReferenciaComoPagada(base.cliente as any, 'C', 30000, {});
    expect(base.alertas().filter((a) => a.startsWith('pago-doble-transferencia'))).toEqual([]);
  });
});

describe('fix 2: el recordatorio de las 12 h no invita a pagar un pedido duplicado de un chico con kit pagado', () => {
  const cron = () => pedir('POST', '/api/cron/recordar-pagos-pendientes', {}, { Authorization: 'Bearer secreto-cron' });
  const pendiente = () => fila(P1, { metodo_pago: 'mercadopago', alumno_nombre: 'Lola Perez', created_at: hace(13) });

  it('con otro kit pagado del mismo chico: no manda el email ni lo marca como recordado', async () => {
    base.filas('pedidos').push(pendiente(), fila('PAGO', { estado: 'pagado', alumno_nombre: 'lola  perez', created_at: hace(30) }));
    const r = await cron();
    expect(r.json).toMatchObject({ success: true, enviados: 0 });
    expect(dobles.correos.filter((c) => /pendiente de pago/.test(c.mensaje.subject))).toHaveLength(0);
    expect(pedido(P1).recordatorio_pago_at).toBeNull();
  });

  it('14/10/2026: una mejora «Pasar a Kit Impreso» pendiente (copia alumno y curso del kit pagado) sí recibe el recordatorio', async () => {
    base.filas('pedidos').push({ ...pendiente(), mejora_de_pedido_id: 'PAGO' }, fila('PAGO', { estado: 'pagado', alumno_nombre: 'Lola Perez', created_at: hace(30) }));
    const r = await cron();
    expect(r.json).toMatchObject({ success: true, enviados: 1 });
    expect(pedido(P1).recordatorio_pago_at).toBeTruthy();
  });

  it('control: sin kit pagado, el recordatorio sale una vez y queda marcado', async () => {
    base.filas('pedidos').push(pendiente());
    const r = await cron();
    expect(r.json).toMatchObject({ success: true, enviados: 1 });
    expect(dobles.correos.some((c) => /pendiente de pago/.test(c.mensaje.subject))).toBe(true);
    expect(pedido(P1).recordatorio_pago_at).toBeTruthy();
  });
});

describe('fix 3: pagar un pedido pendiente desde otro dispositivo', () => {
  const curso = () => cursoDe('1', 'Mañana', 'A');
  const delCurso = (id: string, extra: Record<string, any> = {}) => fila(id, { curso_codigo: curso(), alumno_nombre: 'Lola Perez', metodo_pago: 'mercadopago', created_at: hace(3), ...extra });
  const existente = (conLlaveFamilia: boolean) =>
    pedir('GET', `/api/pedidos/existente?codigo=AB12-CD34&alumnoNombre=${encodeURIComponent('Lola Perez')}${conLlaveFamilia ? `&familia=${FAMILIA}&acceso=${accesoGaleria(FAMILIA)}` : ''}`);
  beforeEach(() => {
    base.filas('inscripciones').push({ id: FAMILIA, estado: 'aceptado', acceso_confirmado_at: hace(100), alumno_nombre: 'Lola', alumno_apellido: 'Perez', hermanos: [] });
  });

  it('la familia identificada recibe la llave del pedido pendiente (la de su grupo de pago si es un carrito)', async () => {
    base.filas('pedidos').push(delCurso(P1, { grupo_pago_id: G }));
    const r = await existente(true);
    expect(r.json.pedido).toMatchObject({ pedidoUuid: P1, grupoPagoId: G, accesoToken: llave(G), comprobanteSubido: false });
  });

  it('con sólo el código del curso no hay UUID ni llave; un pedido ya pagado tampoco da llave', async () => {
    base.filas('pedidos').push(delCurso(P1));
    const anonimo = await existente(false);
    expect(anonimo.json.pedido).toMatchObject({ pedidoUuid: null, grupoPagoId: null, accesoToken: null, requiereLlave: true });
    pedido(P1).estado = 'pagado';
    expect((await existente(true)).json.pedido.accesoToken).toBeNull();
  });

  it('avisa si la transferencia ya tiene el comprobante subido', async () => {
    base.filas('pedidos').push(delCurso(P1, { metodo_pago: 'transferencia', comprobante_subido_at: hace(1) }));
    expect((await existente(true)).json.pedido).toMatchObject({ comprobanteSubido: true, metodoPago: 'transferencia' });
  });

  it('email inmediato de una transferencia registrada: datos, plazo y botón (una vez); nunca con tarjeta ni con comprobante', async () => {
    base.filas('pedidos').push(fila('T1', { grupo_pago_id: G, transferencia_desde: hace(0) }), fila('T2', { grupo_pago_id: G, transferencia_desde: hace(0) }));
    expect(await aviso.enviarAvisoTransferenciaRegistrada(base.cliente as any, 'grupo_pago_id', G)).toBe(true);
    expect(dobles.correos).toHaveLength(1);
    const { mensaje, opciones } = dobles.correos[0];
    expect(mensaje.to).toEqual(['mama@prueba.test']);
    expect(mensaje.subject).toMatch(/datos para transferir/);
    expect(mensaje.html).toContain('$60.000');
    expect(mensaje.html).toContain('se cancela automáticamente');
    expect(mensaje.html).toContain(`grupo_pago_id=${G}`);
    expect(mensaje.html).toContain(`t=${llave(G)}`);
    expect(opciones.idempotencyKey).toBe(`pedido-pendiente-${G}`);

    dobles.correos = [];
    base.filas('pedidos').push(fila('M1', { metodo_pago: 'mercadopago' }), fila('C1', { comprobante_subido_at: hace(0) }));
    expect(await aviso.enviarAvisoTransferenciaRegistrada(base.cliente as any, 'id', 'M1')).toBe(false);
    expect(await aviso.enviarAvisoTransferenciaRegistrada(base.cliente as any, 'id', 'C1')).toBe(false);
    expect(dobles.correos).toHaveLength(0);
  });

  it('/api/reservas/crear por transferencia manda el email al toque; por Mercado Pago no', async () => {
    const reservar = (metodoPago: string, reservaId: string) =>
      pedir('POST', '/api/reservas/crear', {
        tutorNombre: 'Ana', tutorEmail: 'mama@prueba.test', metodoPago, aceptaTerminos: true, versionTerminos,
        items: [{ codigoSeccion: 'AB12-CD34', alumnoNombre: 'Lola Perez', kitId: 'kit-digital', reservaId }],
      });
    expect((await reservar('mercadopago', '77777777-7777-4777-8777-777777777777')).status).toBe(200);
    expect(dobles.correos).toHaveLength(0);
    const r = await reservar('transferencia', '88888888-8888-4888-8888-888888888888');
    expect(r.status).toBe(200);
    expect(dobles.correos).toHaveLength(1);
    // 14/10/2026: en reservas la clave lleva un resumen de los ids del lote (otro lote del grupo = otra clave).
    expect(dobles.correos[0].opciones.idempotencyKey).toMatch(new RegExp(`^pedido-pendiente-${r.json.grupoPagoId}-[0-9a-f]{16}$`));
  });

  it('14/10/2026: con claveConIds, otro lote del mismo grupo usa otra clave; el mismo lote, la misma', async () => {
    base.filas('pedidos').push(fila('T1', { grupo_pago_id: G, transferencia_desde: hace(0) }));
    await aviso.enviarAvisoTransferenciaRegistrada(base.cliente as any, 'grupo_pago_id', G, { claveConIds: true });
    await aviso.enviarAvisoTransferenciaRegistrada(base.cliente as any, 'grupo_pago_id', G, { claveConIds: true });
    base.filas('pedidos').push(fila('T2', { grupo_pago_id: G, transferencia_desde: hace(0) }));
    await aviso.enviarAvisoTransferenciaRegistrada(base.cliente as any, 'grupo_pago_id', G, { claveConIds: true });
    const claves = dobles.correos.map((c) => c.opciones.idempotencyKey);
    expect(claves[0]).toBe(claves[1]);
    expect(claves[2]).not.toBe(claves[0]);
  });

  it('14/10/2026: el email inmediato nunca tira error y no demora la respuesta más de 3 s', async () => {
    const colgado = { from: () => ({ select: () => ({ eq: () => new Promise(() => {}) }) }) };
    const antes = Date.now();
    expect(await aviso.enviarAvisoTransferenciaRegistrada(colgado as any, 'id', 'X')).toBe(false);
    expect(Date.now() - antes).toBeLessThan(4000);
    const roto = { from: () => { throw new Error('base caída'); } };
    expect(await aviso.enviarAvisoTransferenciaRegistrada(roto as any, 'id', 'X')).toBe(false);
  }, 10_000);
});

describe('fix 5: confirmar las fotos de una reserva no espera el .zip HD más de 8 s', () => {
  it('responde éxito aunque el armado del .zip siga en curso (el reintento horario lo termina)', async () => {
    const curso = cursoDe('1', 'Mañana', 'A');
    const pub = hace(1);
    base.filas('fotos').push(
      { id: 'fi', colegio_id: COLEGIO, codigo_curso: curso, categoria: 'individual', alumno_nombre: 'Lola Perez', publicada_at: pub },
      { id: 'fg', colegio_id: COLEGIO, codigo_curso: curso, categoria: 'grupal', alumno_nombre: null, publicada_at: pub },
      { id: 'fd', colegio_id: COLEGIO, codigo_curso: curso, categoria: 'docente', alumno_nombre: null, publicada_at: pub },
    );
    base.filas('pedidos').push(fila(P1, { estado: 'pagado', curso_codigo: curso, alumno_nombre: 'Lola Perez', seleccion_pendiente: true, email_enviado: true }));
    dobles.procesar = () => new Promise(() => {}); // nunca termina (zip lento)
    const inicio = Date.now();
    const r = await pedir('POST', `/api/reservas/${P1}/elegir-fotos`, {
      codigo: 'AB12-CD34', fotos: { grupalId: 'fg', individualId: 'fi', docenteId: 'fd' }, confirmaPersonalizacion: true, versionTerminos, t: llave(P1),
    });
    expect(r.status).toBe(200);
    expect(r.json.success).toBe(true);
    expect(Date.now() - inicio).toBeLessThan(12_000);
    expect(pedido(P1)).toMatchObject({ seleccion_pendiente: false, email_enviado: false });
  }, 20_000);
});

describe('fix 6: botón de arrepentimiento', () => {
  const pedirArrepentimiento = () => pedir('POST', '/api/arrepentimiento', { pedido: 'IFS-2026-3333', nombre: 'Ana Perez', email: 'mama@prueba.test', motivo: 'me equivoqué' });

  it('el reintento (corte o doble toque) devuelve el mismo código ARR, sin otra solicitud ni otro email', async () => {
    base.filas('pedidos').push(fila(P1, { estado: 'pagado', pedido_friendly_id: 'IFS-2026-3333' }));
    const a = await pedirArrepentimiento();
    const b = await pedirArrepentimiento();
    expect(a.status).toBe(201);
    expect(b.status).toBe(201);
    expect(b.json.codigo).toBe(a.json.codigo);
    expect(base.filas('solicitudes_arrepentimiento')).toHaveLength(1);
    // 14/10/2026: el reintento vuelve a llamar a Resend con la MISMA clave y el mismo contenido (Resend lo descarta).
    const envios = dobles.correos.filter((c) => /solicitud de cancelación/.test(c.mensaje.subject));
    expect(new Set(envios.map((c) => c.opciones?.idempotencyKey))).toEqual(new Set([`arrepentimiento-codigo-${a.json.codigo}`]));
    expect(new Set(envios.map((c) => c.mensaje.html)).size).toBe(1);
    expect(b.json).toMatchObject({ repetida: true, emailEnviado: true });
  });

  it('14/10/2026: si el primer intento se cortó después de insertar, el reintento igual avisa a Pablo y manda el email', async () => {
    base.filas('pedidos').push(fila(P1, { estado: 'pagado', pedido_friendly_id: 'IFS-2026-3333' }));
    base.filas('solicitudes_arrepentimiento').push({ id: 'S1', codigo: 'ARR-2026-ABC123', pedido_ref: 'IFS-2026-3333', email: 'mama@prueba.test', created_at: hace(0.05) });
    const r = await pedirArrepentimiento();
    expect(r.json).toMatchObject({ success: true, codigo: 'ARR-2026-ABC123', repetida: true, emailEnviado: true });
    expect(base.alertas()).toContain('arrepentimiento:ARR-2026-ABC123');
    expect(dobles.correos.map((c) => c.opciones?.idempotencyKey)).toContain('arrepentimiento-codigo-ARR-2026-ABC123');
    expect(base.filas('solicitudes_arrepentimiento')).toHaveLength(1);
  });

  it('en un carrito de hermanos queda en espera todo el pago, no sólo la fila escrita', async () => {
    base.filas('pedidos').push(
      fila(P1, { estado: 'pagado', grupo_pago_id: G, pedido_friendly_id: 'IFS-2026-3333' }),
      fila(P2, { estado: 'pagado', grupo_pago_id: G }),
      fila('OTRO', { estado: 'pagado' }),
    );
    expect((await pedirArrepentimiento()).status).toBe(201);
    expect([pedido(P1).en_espera, pedido(P2).en_espera, pedido('OTRO').en_espera]).toEqual([true, true, false]);
  });

  it('25/10: al resolver la solicitud se libera también el kit del hermano (rechazar y aprobar)', async () => {
    const { generateAdminToken } = await import('../../../../servidor/nucleo/auth');
    const admin = { Authorization: `Bearer ${generateAdminToken()}` };
    for (const accion of ['rechazar', 'aprobar']) {
      base.reiniciar();
      base.filas('familias').push({ id: 'fam-1', nombre: 'Ana', email: 'mama@prueba.test', whatsapp: '11 5555-1234' });
      base.filas('pedidos').push(fila(P1, { estado: 'pagado', grupo_pago_id: G, pedido_friendly_id: 'IFS-2026-3333' }), fila(P2, { estado: 'pagado', grupo_pago_id: G }));
      expect((await pedirArrepentimiento()).status).toBe(201);
      const sol = base.filas('solicitudes_arrepentimiento')[0];
      sol.estado ??= 'nueva'; // default de la columna en la base
      const r = await pedir('POST', `/api/admin/cancelaciones/${sol.id}/resolver`, { accion, nota: 'Motivo de prueba' }, admin);
      expect(r.status, JSON.stringify(r.json)).toBe(200);
      expect(pedido(P2).en_espera, accion).toBe(false);
      expect(pedido(P1).estado).toBe(accion === 'aprobar' ? 'cancelado' : 'pagado');
    }
  });

  it('25/10: al resolver la solicitud de un hermano, el otro sigue en espera si tiene su propia solicitud abierta', async () => {
    const { generateAdminToken } = await import('../../../../servidor/nucleo/auth');
    base.filas('pedidos').push(fila(P1, { estado: 'pagado', grupo_pago_id: G, pedido_friendly_id: 'IFS-2026-3333' }), fila(P2, { estado: 'pagado', grupo_pago_id: G, pedido_friendly_id: 'IFS-2026-4444' }));
    expect((await pedir('POST', '/api/arrepentimiento', { pedido: 'IFS-2026-4444', nombre: 'Ana', email: 'mama@prueba.test', motivo: 'x' })).status).toBe(201);
    expect((await pedirArrepentimiento()).status).toBe(201);
    for (const s of base.filas('solicitudes_arrepentimiento')) s.estado ??= 'nueva';
    const segunda = base.filas('solicitudes_arrepentimiento').find((s: any) => s.pedido_id === P1);
    const r = await pedir('POST', `/api/admin/cancelaciones/${segunda.id}/resolver`, { accion: 'rechazar', nota: 'Motivo de prueba' }, { Authorization: `Bearer ${generateAdminToken()}` });
    expect(r.status, JSON.stringify(r.json)).toBe(200);
    expect(pedido(P1).en_espera).toBe(false);
    expect(pedido(P2).en_espera).toBe(true); // su solicitud sigue abierta
  });

  it('25/10: una solicitud sin pedido verificado (email distinto) no se puede aprobar', async () => {
    const { generateAdminToken } = await import('../../../../servidor/nucleo/auth');
    base.filas('pedidos').push(fila(P1, { estado: 'pagado', pedido_friendly_id: 'IFS-2026-3333' }));
    expect((await pedir('POST', '/api/arrepentimiento', { pedido: 'IFS-2026-3333', nombre: 'Otro', email: 'otro@prueba.test', motivo: 'x' })).status).toBe(201);
    const sol = base.filas('solicitudes_arrepentimiento')[0];
    sol.estado ??= 'nueva';
    expect(sol.pedido_id ?? null).toBeNull();
    const r = await pedir('POST', `/api/admin/cancelaciones/${sol.id}/resolver`, { accion: 'aprobar' }, { Authorization: `Bearer ${generateAdminToken()}` });
    expect(r.status).toBe(400);
    expect(base.filas('solicitudes_arrepentimiento')[0].estado).toBe('nueva');
    expect(pedido(P1).estado).toBe('pagado');
  });
});
