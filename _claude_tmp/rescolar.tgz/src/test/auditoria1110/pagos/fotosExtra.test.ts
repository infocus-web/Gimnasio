// 29/10/2026 (Pablo): «muchos padres quieren comprar fotos extra de sus hijos, fuera del kit» y «que esos pedidos se
// impriman en otro lote para que no se mezcle con los kit». Corre las rutas reales (compra y laboratorio) con la base
// falsa en memoria.
import http from 'http';
import type { AddressInfo } from 'net';
import express from 'express';
import { afterAll, afterEach, beforeAll, beforeEach, describe, expect, it, vi } from 'vitest';
import * as base from './baseFalsa';

vi.mock('dotenv', () => {
  const config = () => ({ parsed: {} });
  return { default: { config }, config };
});
vi.mock('@supabase/supabase-js', async () => {
  const m = await import('./baseFalsa');
  return { createClient: () => m.cliente };
});

const COLEGIO = '11111111-1111-4111-8111-111111111111';
const KIT = '22222222-2222-4222-8222-222222222222';
const FOTO_GRUPAL = 'aaaaaaaa-0000-4000-8000-000000000001';
const FOTO_INDIVIDUAL_JUAN = 'aaaaaaaa-0000-4000-8000-000000000002';
const FOTO_INDIVIDUAL_OTRO = 'aaaaaaaa-0000-4000-8000-000000000003';
const FOTO_OTRO_CURSO = 'aaaaaaaa-0000-4000-8000-000000000004';
const FOTO_SIN_PUBLICAR = 'aaaaaaaa-0000-4000-8000-000000000005';
const FOTO_SIN_NOMBRE = 'aaaaaaaa-0000-4000-8000-000000000006';

let servidor: http.Server;
let puerto = 0;
let curso = '';
let llaveKit = '';
let tokenLab = '';
let nucleo: typeof import('../../../../servidor/nucleo/fotosExtra');
let contarImpresionesPedido: (p: any) => any;
let validarPrecios: (p: any) => any;
let pedidosParaLabKits: () => Promise<any[]>;

function pedir(metodo: string, ruta: string, cuerpo?: unknown, token?: string): Promise<{ status: number; json: any }> {
  return new Promise((ok, mal) => {
    const datos = cuerpo === undefined ? '' : JSON.stringify(cuerpo);
    const headers: Record<string, string | number> = { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(datos) };
    if (token) headers.Authorization = `Bearer ${token}`;
    const req = http.request({ host: '127.0.0.1', port: puerto, path: ruta, method: metodo, headers }, (res) => {
      let texto = '';
      res.setEncoding('utf8');
      res.on('data', (c) => (texto += c));
      res.on('end', () => {
        let json: any = null;
        try {
          json = JSON.parse(texto);
        } catch {
          /* texto plano */
        }
        ok({ status: res.statusCode || 0, json });
      });
    });
    req.on('error', mal);
    if (datos) req.write(datos);
    req.end();
  });
}

beforeAll(async () => {
  process.env.SUPABASE_SERVICE_ROLE_KEY = 'prueba';
  process.env.ADMIN_SESSION_SECRET = 'secreto-de-prueba-largo-para-hmac';
  process.env.LAB_PIN = '123456';
  const { rutasFotosExtra } = await import('../../../../servidor/pagos/fotosExtra');
  const { rutasLaboratorioExtras } = await import('../../../../servidor/panel/laboratorioExtras');
  const { rutasLaboratorio } = await import('../../../../servidor/panel/laboratorio');
  const { rutasBuscadorPedidos } = await import('../../../../servidor/pagos/buscadorPedidos');
  const { rutasMejoraImpreso } = await import('../../../../servidor/pagos/mejoraImpreso');
  const precios = await import('../../../../servidor/nucleo/precios');
  const { determinarCodigoCursoServidor } = await import('../../../../servidor/nucleo/codigosCurso');
  const { tokenAccesoPedido } = await import('../../../../servidor/nucleo/accesoPedidos');
  const { generarTokenLab } = await import('../../../../servidor/nucleo/auth');
  nucleo = await import('../../../../servidor/nucleo/fotosExtra');
  ({ contarImpresionesPedido } = await import('../../../../servidor/nucleo/pedidos'));
  validarPrecios = precios.validarPrecios;
  precios.marcarPreciosGuardados();
  curso = determinarCodigoCursoServidor('1° grado', 'Mañana', 'A');
  llaveKit = String(tokenAccesoPedido(KIT));
  tokenLab = String(generarTokenLab());
  const app = express();
  app.use(express.json({ limit: '4mb' }));
  app.use(rutasLaboratorio, rutasLaboratorioExtras, rutasFotosExtra, rutasBuscadorPedidos, rutasMejoraImpreso);
  servidor = app.listen(0);
  await new Promise((ok) => servidor.once('listening', ok));
  puerto = (servidor.address() as AddressInfo).port;
  pedidosParaLabKits = async () => (await pedir('GET', '/api/lab/pedidos', undefined, tokenLab)).json?.pedidos || [];
}, 120_000);

afterAll(async () => {
  await new Promise((ok) => servidor.close(ok));
  delete process.env.LAB_PIN;
});

afterEach(() => {
  vi.useRealTimers();
});

const foto = (id: string, extra: Record<string, unknown> = {}) => ({
  id,
  colegio_id: COLEGIO,
  codigo_curso: curso,
  categoria: 'grupal',
  alumno_nombre: null,
  publicada_at: '2026-10-20T10:00:00Z',
  storage_path: `hd/${id}.jpg`,
  ...extra,
});

beforeEach(() => {
  base.reiniciar();
  base.filas('colegios').push({ id: COLEGIO, nombre: 'Colegio Prueba' });
  base.filas('codigos_seccion').push({ id: 's1', colegio_id: COLEGIO, grado: '1° grado', turno: 'Mañana', division: 'A', codigo_secreto: 'AB12-CD34' });
  base.filas('pedidos').push({
    id: KIT,
    pedido_friendly_id: 'IFS-2026-1111',
    colegio_id: COLEGIO,
    colegio_nombre: 'Colegio Prueba',
    curso_codigo: curso,
    grado: '1° grado',
    division: 'A',
    turno: 'Mañana',
    alumno_nombre: 'Juan Pérez',
    alumno_numero_lista: 7,
    codigo_alumno: 'C-7',
    tipo_kit: 'solo_digital',
    estado: 'pagado',
    seleccion_pendiente: false,
    en_espera: false,
    archivado: false,
    cancelado_definitivo: false,
    total: 15000,
    fotos_seleccionadas: { individualId: FOTO_INDIVIDUAL_JUAN, grupalId: FOTO_GRUPAL, otrasIds: [] },
  });
  base.filas('fotos').push(
    foto(FOTO_GRUPAL),
    foto(FOTO_INDIVIDUAL_JUAN, { categoria: 'individual', alumno_nombre: 'Juan Pérez' }),
    foto(FOTO_INDIVIDUAL_OTRO, { categoria: 'individual', alumno_nombre: 'Martina Gómez' }),
    foto(FOTO_OTRO_CURSO, { codigo_curso: 'OTRO' }),
    foto(FOTO_SIN_PUBLICAR, { publicada_at: null }),
    foto(FOTO_SIN_NOMBRE, { categoria: 'individual', alumno_nombre: null })
  );
});

const comprar = (items: unknown, extra: Record<string, unknown> = {}) =>
  pedir('POST', `/api/pedidos/${KIT}/fotos-extra`, { codigo: 'AB12-CD34', t: llaveKit, items, ...extra });

describe('fotos extra: compra (POST /api/pedidos/:id/fotos-extra)', () => {
  it('crea un pedido APARTE con el total del servidor, ligado al kit y sin número de lista', async () => {
    const r = await comprar([
      { fotoId: FOTO_GRUPAL, tamano: '15x21', cantidad: 2 },
      { fotoId: FOTO_INDIVIDUAL_JUAN, tamano: '20x30', cantidad: 1 },
    ], { total: 1 });
    expect(r.status).toBe(200);
    expect(r.json.total).toBe(2 * 5000 + 8000);
    const fila = base.filas('pedidos').find((p) => p.id === r.json.pedidoId);
    expect(fila).toMatchObject({
      tipo_kit: 'fotos_extra',
      estado: 'pendiente_pago',
      total: 18000,
      extras_de_pedido_id: KIT,
      alumno_numero_lista: null,
      carpetas_impresas: 0,
      metodo_pago: 'mercadopago',
      kit_nombre: 'Fotos extra (2 de 15x21 + 1 de 20x30)',
    });
    expect(fila.fotos_seleccionadas.extras).toHaveLength(2);
    // El kit original no se toca.
    expect(base.filas('pedidos').find((p) => p.id === KIT).estado).toBe('pagado');
  });

  it('repetir el mismo pedido sin pagarlo devuelve el mismo (no duplica)', async () => {
    const items = [{ fotoId: FOTO_GRUPAL, tamano: '15x21', cantidad: 1 }];
    const a = await comprar(items);
    const b = await comprar(items);
    expect(b.json.pedidoId).toBe(a.json.pedidoId);
    expect(base.filas('pedidos').filter((p) => p.extras_de_pedido_id === KIT)).toHaveLength(1);
  });

  it('si cambia la selección, el pedido viejo sin pagar se da de baja (no queda para pagar de más)', async () => {
    const viejo = await comprar([{ fotoId: FOTO_GRUPAL, tamano: '15x21', cantidad: 1 }]);
    const nuevo = await comprar([{ fotoId: FOTO_GRUPAL, tamano: '15x21', cantidad: 2 }]);
    expect(nuevo.json.pedidoId).not.toBe(viejo.json.pedidoId);
    expect(base.filas('pedidos').find((p) => p.id === viejo.json.pedidoId)).toMatchObject({ estado: 'cancelado', cancelado_definitivo: true });
    expect(base.filas('pedidos').find((p) => p.id === nuevo.json.pedidoId).estado).toBe('pendiente_pago');
  });

  it('un pedido viejo con el comprobante de una transferencia subido no se cancela', async () => {
    const viejo = await comprar([{ fotoId: FOTO_GRUPAL, tamano: '15x21', cantidad: 1 }]);
    base.filas('pedidos').find((p) => p.id === viejo.json.pedidoId).comprobante_subido_at = '2026-10-29T10:00:00Z';
    await comprar([{ fotoId: FOTO_GRUPAL, tamano: '20x30', cantidad: 1 }]);
    expect(base.filas('pedidos').find((p) => p.id === viejo.json.pedidoId).cancelado_definitivo).toBe(false);
  });

  it('la misma foto y tamaño repetidos se suman', async () => {
    const r = await comprar([
      { fotoId: FOTO_GRUPAL, tamano: '15x21', cantidad: 1 },
      { fotoId: FOTO_GRUPAL, tamano: '15x21', cantidad: 2 },
    ]);
    expect(r.json.total).toBe(15000);
    expect(base.filas('pedidos').find((p) => p.id === r.json.pedidoId).fotos_seleccionadas.extras).toEqual([{ fotoId: FOTO_GRUPAL, tamano: '15x21', cantidad: 3 }]);
  });

  it('una individual SIN nombre la puede pedir cualquiera del curso', async () => {
    const r = await comprar([{ fotoId: FOTO_SIN_NOMBRE, tamano: '15x21', cantidad: 1 }]);
    expect(r.status).toBe(200);
  });

  it.each([
    ['foto individual de otro chico', [{ fotoId: FOTO_INDIVIDUAL_OTRO, tamano: '15x21', cantidad: 1 }]],
    ['foto de otro curso', [{ fotoId: FOTO_OTRO_CURSO, tamano: '15x21', cantidad: 1 }]],
    ['foto sin publicar', [{ fotoId: FOTO_SIN_PUBLICAR, tamano: '15x21', cantidad: 1 }]],
    ['tamaño que no existe', [{ fotoId: FOTO_GRUPAL, tamano: '40x50', cantidad: 1 }]],
    ['cantidad 0', [{ fotoId: FOTO_GRUPAL, tamano: '15x21', cantidad: 0 }]],
    ['más de 10 copias de la misma', [{ fotoId: FOTO_GRUPAL, tamano: '15x21', cantidad: 11 }]],
    ['lista vacía', []],
  ])('rechaza: %s (400, no crea nada)', async (_caso, items) => {
    const r = await comprar(items);
    expect(r.status).toBe(400);
    expect(base.filas('pedidos').filter((p) => p.extras_de_pedido_id)).toHaveLength(0);
  });

  it('sin la llave de la familia ni la del pedido: 403', async () => {
    const r = await pedir('POST', `/api/pedidos/${KIT}/fotos-extra`, { codigo: 'AB12-CD34', items: [{ fotoId: FOTO_GRUPAL, tamano: '15x21', cantidad: 1 }] });
    expect(r.status).toBe(403);
  });

  it('con el código de otro curso: no encuentra el pedido', async () => {
    base.filas('codigos_seccion').push({ id: 's2', colegio_id: COLEGIO, grado: '2° grado', turno: 'Mañana', division: 'A', codigo_secreto: 'ZZ99-YY88' });
    const r = await comprar([{ fotoId: FOTO_GRUPAL, tamano: '15x21', cantidad: 1 }], { codigo: 'ZZ99-YY88' });
    expect(r.status).toBe(404);
  });

  it.each([
    ['kit sin pagar', { estado: 'pendiente_pago' }],
    ['reserva sin fotos elegidas', { seleccion_pendiente: true }],
    ['es una mejora a impreso', { mejora_de_pedido_id: '33333333-3333-4333-8333-333333333333' }],
  ])('sobre un %s: 409', async (_caso, cambios) => {
    Object.assign(base.filas('pedidos').find((p) => p.id === KIT), cambios);
    const r = await comprar([{ fotoId: FOTO_GRUPAL, tamano: '15x21', cantidad: 1 }]);
    expect(r.status).toBe(409);
  });

  it('después del 15/11: 410 (como el Kit Impreso)', async () => {
    vi.useFakeTimers({ toFake: ['Date'] });
    vi.setSystemTime(new Date('2026-11-16T12:00:00-03:00'));
    const r = await comprar([{ fotoId: FOTO_GRUPAL, tamano: '15x21', cantidad: 1 }]);
    expect(r.status).toBe(410);
    expect(r.json.codigo).toBe('PLAZO_FOTOS_EXTRA');
  });
});

describe('29/10: fotos extra y mejora a impreso se pagan con los 3 medios (como el kit)', () => {
  const item = [{ fotoId: FOTO_GRUPAL, tamano: '15x21', cantidad: 1 }];
  it.each(['mercadopago', 'nave', 'transferencia'])('fotos extra con %s: el pedido nace con ese medio', async (metodo) => {
    const r = await comprar(item, { metodoPago: metodo });
    expect(r.status).toBe(200);
    expect(r.json.metodoPago).toBe(metodo);
    expect(base.filas('pedidos').find((p) => p.id === r.json.pedidoId).metodo_pago).toBe(metodo);
  });

  it('un medio que no existe se toma como Mercado Pago (nunca «efectivo» ni otro)', async () => {
    const r = await comprar(item, { metodoPago: 'efectivo' });
    expect(base.filas('pedidos').find((p) => p.id === r.json.pedidoId).metodo_pago).toBe('mercadopago');
  });

  it('el mismo pedido sin pagar, con otro medio: se reutiliza y cambia el medio (no se duplica)', async () => {
    const a = await comprar(item, { metodoPago: 'mercadopago' });
    const b = await comprar(item, { metodoPago: 'transferencia' });
    expect(b.json.pedidoId).toBe(a.json.pedidoId);
    expect(base.filas('pedidos').find((p) => p.id === a.json.pedidoId)).toMatchObject({ metodo_pago: 'transferencia', estado: 'pendiente_pago' });
    expect(base.filas('pedidos').filter((p) => p.extras_de_pedido_id === KIT)).toHaveLength(1);
  });

  it('con el comprobante de la transferencia ya subido no se cambia a tarjeta (409)', async () => {
    const a = await comprar(item, { metodoPago: 'transferencia' });
    base.filas('pedidos').find((p) => p.id === a.json.pedidoId).comprobante_subido_at = '2026-10-29T10:00:00Z';
    const b = await comprar(item, { metodoPago: 'mercadopago' });
    expect(b.status).toBe(409);
    expect(base.filas('pedidos').find((p) => p.id === a.json.pedidoId).metodo_pago).toBe('transferencia');
  });

  const mejorar = (metodo?: string) => pedir('POST', `/api/pedidos/${KIT}/mejorar-a-impreso`, { codigo: 'AB12-CD34', t: llaveKit, ...(metodo ? { metodoPago: metodo } : {}) });
  it.each(['mercadopago', 'nave', 'transferencia'])('«Pasar a Kit Impreso» con %s: la mejora nace con ese medio', async (metodo) => {
    const r = await mejorar(metodo);
    expect(r.status).toBe(200);
    expect(base.filas('pedidos').find((p) => p.id === r.json.pedidoId)).toMatchObject({ metodo_pago: metodo, mejora_de_pedido_id: KIT, estado: 'pendiente_pago' });
  });

  it('«Pasar a Kit Impreso» sin medio (navegador viejo) sigue siendo Mercado Pago, y al elegir otro se reutiliza la misma mejora', async () => {
    const a = await mejorar();
    expect(base.filas('pedidos').find((p) => p.id === a.json.pedidoId).metodo_pago).toBe('mercadopago');
    const b = await mejorar('transferencia');
    expect(b.json.pedidoId).toBe(a.json.pedidoId);
    expect(base.filas('pedidos').filter((p) => p.mejora_de_pedido_id === KIT)).toHaveLength(1);
    expect(base.filas('pedidos').find((p) => p.id === a.json.pedidoId).metodo_pago).toBe('transferencia');
  });

  it('una mejora cuya transferencia venció no se reabre por transferencia (409)', async () => {
    const a = await mejorar('transferencia');
    Object.assign(base.filas('pedidos').find((p) => p.id === a.json.pedidoId), { estado: 'cancelado', transferencia_vencida_at: '2026-10-29T10:00:00Z' });
    expect((await mejorar('transferencia')).status).toBe(409);
  });
});

describe('fotos extra: aviso «ya tiene un pedido» (GET /api/pedidos/existente)', () => {
  const existente = () => pedir('GET', `/api/pedidos/existente?codigo=AB12-CD34&alumnoNombre=${encodeURIComponent('Juan Pérez')}&t=${llaveKit}`);
  it('muestra el KIT (no el pedido de extras más nuevo) y ofrece fotos extra con sus precios', async () => {
    const compra = await comprar([{ fotoId: FOTO_GRUPAL, tamano: '15x21', cantidad: 1 }]);
    Object.assign(base.filas('pedidos').find((p) => p.id === compra.json.pedidoId), { estado: 'pagado', created_at: '2026-12-31T00:00:00Z' });
    const r = await existente();
    expect(r.status).toBe(200);
    expect(r.json.pedido).toMatchObject({ id: 'IFS-2026-1111', puedeComprarFotosExtra: true, fotosExtraPagadas: 1, preciosFotosExtra: { extra15x21: 5000, extra20x30: 8000 } });
  });
  it('un kit sin pagar no ofrece fotos extra', async () => {
    base.filas('pedidos').find((p) => p.id === KIT).estado = 'pendiente_pago';
    expect((await existente()).json.pedido.puedeComprarFotosExtra).toBe(false);
  });
});

describe('fotos extra: laboratorio (lotes aparte de los kits)', () => {
  const EXTRA = '44444444-4444-4444-8444-444444444444';
  const KIT_IMPRESO = '55555555-5555-4555-8555-555555555555';
  beforeEach(() => {
    base.filas('pedidos').push(
      {
        id: EXTRA,
        pedido_friendly_id: 'IFS-2026-2222',
        colegio_id: COLEGIO,
        curso_codigo: curso,
        alumno_nombre: 'Juan Pérez',
        alumno_numero_lista: null,
        tipo_kit: 'fotos_extra',
        estado: 'pagado',
        seleccion_pendiente: false,
        en_espera: false,
        archivado: false,
        lote_lab_id: null,
        estado_lab: null,
        extras_de_pedido_id: KIT,
        fotos_seleccionadas: { extras: [{ fotoId: FOTO_GRUPAL, tamano: '20x30', cantidad: 2 }, { fotoId: FOTO_INDIVIDUAL_JUAN, tamano: '15x21', cantidad: 1 }] },
      },
      {
        id: KIT_IMPRESO,
        pedido_friendly_id: 'IFS-2026-3333',
        colegio_id: COLEGIO,
        curso_codigo: curso,
        alumno_nombre: 'Ana Ruiz',
        alumno_numero_lista: 8,
        tipo_kit: 'impreso_digital',
        carpetas_impresas: 1,
        estado: 'pagado',
        seleccion_pendiente: false,
        en_espera: false,
        archivado: false,
        lote_lab_id: null,
        estado_lab: null,
        fotos_seleccionadas: { individualId: FOTO_SIN_NOMBRE, grupalId: FOTO_GRUPAL, otrasIds: [] },
      }
    );
  });

  it('los pedidos de fotos extra NO aparecen entre los pedidos de kits del laboratorio', async () => {
    const ids = (await pedidosParaLabKits()).map((p: any) => p.id);
    expect(ids).toContain(KIT_IMPRESO);
    expect(ids).not.toContain(EXTRA);
  });

  it('el lote de extras toma sólo las fotos extra, con tipo «extras» y sus copias por tamaño', async () => {
    const nuevos = await pedir('GET', '/api/lab/extras', undefined, tokenLab);
    expect(nuevos.json.nuevos).toEqual({ pedidos: 1, fotos15x21: 1, fotos20x30: 2 });
    const r = await pedir('POST', '/api/lab/extras/lotes', {}, tokenLab);
    expect(r.status).toBe(200);
    const lote = base.filas('lotes_laboratorio')[0];
    expect(lote).toMatchObject({ tipo: 'extras', cantidad: 1, fotos_15x21: 1, fotos_20x30: 2, carpetas: 0 });
    expect(base.filas('pedidos').find((p) => p.id === EXTRA).lote_lab_id).toBe(lote.id);
    expect(base.filas('pedidos').find((p) => p.id === KIT_IMPRESO).lote_lab_id).toBeNull();
    // Un segundo intento no repite pedidos.
    expect((await pedir('POST', '/api/lab/extras/lotes', {}, tokenLab)).status).toBe(409);
    // La lista de lotes de KITS no muestra el lote de extras.
    const kits = await pedir('GET', '/api/lab/pedidos', undefined, tokenLab);
    expect(kits.json.lotes.map((l: any) => l.id)).not.toContain(lote.id);
  });

  it('el manifiesto trae un archivo por copia, en la carpeta de su tamaño, con el número de lista del kit', async () => {
    await pedir('POST', '/api/lab/extras/lotes', {}, tokenLab);
    const lote = base.filas('lotes_laboratorio')[0];
    const r = await pedir('GET', `/api/lab/extras/lotes/${lote.id}/manifiesto`, undefined, tokenLab);
    expect(r.status).toBe(200);
    const archivos = r.json.archivos;
    expect(archivos).toHaveLength(3);
    expect(archivos.filter((a: any) => a.carpeta === '20x30')).toHaveLength(2);
    expect(archivos.every((a: any) => a.url?.startsWith('https://firmado/hd/'))).toBe(true);
    expect(archivos[0].nombre).toMatch(/_07_JUAN_PEREZ_IFS_2026_2222_F1_1de2\.jpg$/);
    expect(archivos[0].numeroLista).toBe(7);
  });

  it('las rutas del laboratorio exigen sesión', async () => {
    expect((await pedir('GET', '/api/lab/extras')).status).toBe(401);
    expect((await pedir('POST', '/api/lab/extras/lotes', {})).status).toBe(401);
  });
});

describe('fotos extra: reglas compartidas', () => {
  it('cuentan como copias impresas (sin carpeta) para el laboratorio y la liquidación', () => {
    const p = { tipo_kit: 'fotos_extra', carpetas_impresas: 0, fotos_seleccionadas: { extras: [{ fotoId: 'x', tamano: '15x21', cantidad: 3 }, { fotoId: 'y', tamano: '20x30', cantidad: 1 }] } };
    expect(contarImpresionesPedido(p)).toEqual({ carpetas: 0, fotos15x21: 3, fotos20x30: 1, sueltas: 0 });
  });

  it('un pedido de fotos extra es «adicional» (sin .zip HD, no cuenta como kit); un kit no', () => {
    expect(nucleo.esPedidoAdicional({ tipo_kit: 'fotos_extra' })).toBe(true);
    expect(nucleo.esPedidoAdicional({ extras_de_pedido_id: KIT })).toBe(true);
    expect(nucleo.esPedidoAdicional({ mejora_de_pedido_id: KIT, tipo_kit: 'impreso_digital' })).toBe(true);
    expect(nucleo.esPedidoAdicional({ tipo_kit: 'impreso_digital' })).toBe(false);
  });

  it('los precios guardados antes de las fotos extra siguen valiendo (las claves nuevas toman su valor por defecto)', () => {
    const viejos = { kitClasico: 32000, kitDigital: 16000, carpetaExtra: 15000, fotoEvento: 5000 };
    expect(validarPrecios(viejos)).toEqual({ ...viejos, extra15x21: 5000, extra20x30: 8000 });
    expect(validarPrecios({ ...viejos, extra15x21: 6000, extra20x30: 9000 })).toMatchObject({ extra15x21: 6000, extra20x30: 9000 });
    expect(validarPrecios({ ...viejos, extra20x30: 10 })).toBeNull();
  });
});
