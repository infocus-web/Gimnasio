// Auditoría 11/10 (pagos): control de comportamiento del núcleo de cobro (marcarReferenciaComoPagada,
// montoCubrePedidos, obtenerPedidosPendientesParaCobro, calcularTotalPedido). No había ninguna prueba
// que lo ejecutara: las existentes sólo buscan texto en el código.
import { beforeAll, beforeEach, describe, expect, it, vi } from 'vitest';
import * as base from './baseFalsa';

vi.mock('dotenv', () => {
  const config = () => ({ parsed: {} });
  return { default: { config }, config };
});

let cobros: typeof import('../../../../servidor/pagos/cobros');
let totales: typeof import('../../../../servidor/pagos/totales');
const db = base.cliente as any;

beforeAll(async () => {
  cobros = await import('../../../../servidor/pagos/cobros');
  totales = await import('../../../../servidor/pagos/totales');
});

const G = '22222222-2222-4222-8222-222222222222';
const fila = (id: string, extra: Record<string, any> = {}) => ({ id, estado: 'pendiente_pago', cancelado_definitivo: false, archivado: false, total: 30000, grupo_pago_id: null, colegio_id: 'C', curso_codigo: 'K', alumno_nombre: `Chico ${id}`, ...extra });

beforeEach(() => base.reiniciar());

describe('marcarReferenciaComoPagada', () => {
  it('monto insuficiente: no marca y deja alerta', async () => {
    base.filas('pedidos').push(fila('P1'));
    expect(await cobros.marcarReferenciaComoPagada(db, 'P1', 15000, { mp_payment_id: '1' })).toEqual([]);
    expect(base.filas('pedidos')[0].estado).toBe('pendiente_pago');
    expect(base.alertas()).toContain('monto-insuficiente:P1');
  });
  it('monto ilegible (NaN): no marca', async () => {
    base.filas('pedidos').push(fila('P1'));
    expect(await cobros.marcarReferenciaComoPagada(db, 'P1', NaN, { nave_payment_id: 'n1' })).toEqual([]);
    expect(base.alertas()).toContain('monto-ilegible:P1');
  });
  it('carrito con un hermano cancelado definitivo: marca sólo el vivo y avisa el sobrante; idempotente', async () => {
    base.filas('pedidos').push(fila('A', { grupo_pago_id: G }), fila('B', { grupo_pago_id: G, estado: 'cancelado', cancelado_definitivo: true }));
    const r = await cobros.marcarReferenciaComoPagada(db, G, 60000, { mp_payment_id: '9' });
    expect(r.map((f: any) => f.id)).toEqual(['A']);
    expect(base.filas('pedidos').find((p) => p.id === 'B').estado).toBe('cancelado');
    expect(base.alertas()).toContain(`monto-sobrante:${G}`);
    expect(await cobros.marcarReferenciaComoPagada(db, G, 60000, { mp_payment_id: '9' })).toEqual([]);
  });
  it('rechazo de tarjeta previo ("cancelado" no definitivo) sí pasa a pagado; un pago ajeno no se reusa', async () => {
    base.filas('pedidos').push(fila('P1', { estado: 'cancelado' }), fila('P2', { estado: 'pagado', mp_payment_id: '5' }));
    expect(await cobros.marcarReferenciaComoPagada(db, 'P1', 30000, { mp_payment_id: '5' })).toEqual([]);
    expect(base.alertas()).toContain('pago-reusado:5');
    expect((await cobros.marcarReferenciaComoPagada(db, 'P1', 30000, { mp_payment_id: '6' })).map((f: any) => f.id)).toEqual(['P1']);
  });
  it('pago aprobado sobre un pedido cancelado definitivo: no revive y deja alerta de pago huérfano', async () => {
    base.filas('pedidos').push(fila('P1', { estado: 'cancelado', cancelado_definitivo: true }));
    expect(await cobros.marcarReferenciaComoPagada(db, 'P1', 30000, { mp_payment_id: '7' })).toEqual([]);
    expect(base.alertas()).toContain('pago-huerfano:7');
  });
  it('segundo pago aprobado distinto sobre un pedido ya pagado: alerta de pago doble', async () => {
    base.filas('pedidos').push(fila('P1', { estado: 'pagado', mp_payment_id: '1' }));
    expect(await cobros.marcarReferenciaComoPagada(db, 'P1', 30000, { nave_payment_id: 'n9' })).toEqual([]);
    expect(base.alertas()).toContain('pago-doble:n9');
  });
});

describe('obtenerPedidosPendientesParaCobro', () => {
  it('un hermano de un carrito no se cobra suelto si quedan otros cobrables', async () => {
    const A = '11111111-1111-4111-8111-11111111111a';
    base.filas('pedidos').push(fila(A, { grupo_pago_id: G }), fila('B', { grupo_pago_id: G }));
    const r = await cobros.obtenerPedidosPendientesParaCobro(db, { pedidoId: A });
    expect(r.status).toBe(409);
  });
});

describe('calcularTotalPedido', () => {
  it('kit + carpetas (sólo impreso, tope 20) + fotos sueltas (tope 50)', () => {
    expect(totales.calcularTotalPedido('kit-clasico', 2, 1)).toBe(30000 + 2 * 15000 + 5000);
    expect(totales.calcularTotalPedido('kit-digital', 5, 0)).toBe(15000);
    expect(totales.calcularTotalPedido('kit-clasico', 999, 0)).toBe(30000 + 20 * 15000);
    expect(totales.calcularTotalPedido('kit-clasico', -3, '2.9')).toBe(30000 + 2 * 5000);
    expect(totales.calcularTotalPedido('kit-inventado', 0, 0)).toBeNull();
  });
});
