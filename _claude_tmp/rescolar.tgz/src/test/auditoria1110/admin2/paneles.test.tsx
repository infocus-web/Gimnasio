import { describe, expect, it, vi, beforeEach } from 'vitest';
import { render, screen, fireEvent, act } from '@testing-library/react';

// ADM-1 (auditoría 11/10): una búsqueda vieja que responde tarde no pisa la nueva.
const pendientes: Array<{ q: string; resolver: (v: any) => void }> = [];
vi.mock('../../../services/buscadorAlumnosService', () => ({
  buscarAlumnosAdmin: (q: string) => new Promise((resolver) => pendientes.push({ q, resolver })),
}));

import AdminBuscadorAlumnosTab from '../../../components/AdminBuscadorAlumnosTab';

const alumno = (nombre: string) => ({ success: true, pedidosPorTelefono: [], alumnos: [{ id: nombre, nombre, apellido: '', colegioNombre: 'C', grado: '1°', turno: 'Mañana', division: 'A', inscripciones: [], pedidos: [] }] });

describe('ADM-1: buscador de alumnos', () => {
  beforeEach(() => { pendientes.length = 0; vi.useFakeTimers(); });
  it('descarta la respuesta de una búsqueda anterior', async () => {
    render(<AdminBuscadorAlumnosTab {...({} as any)} />);
    const campo = screen.getByRole('textbox') as HTMLInputElement;
    fireEvent.change(campo, { target: { value: 'Juan Pérez' } });
    await act(async () => { vi.advanceTimersByTime(400); });
    fireEvent.change(campo, { target: { value: 'Juan Gómez' } });
    await act(async () => { vi.advanceTimersByTime(400); });
    expect(pendientes.map((p) => p.q)).toEqual(['Juan Pérez', 'Juan Gómez']);
    await act(async () => { pendientes[1].resolver(alumno('Gómez')); });
    await act(async () => { pendientes[0].resolver(alumno('Pérez')); });
    vi.useRealTimers();
    expect(screen.queryByText(/Pérez/)).toBeNull();
    expect(screen.getAllByText(/Gómez/).length).toBeGreaterThan(0);
  });
});
