import { describe, expect, it } from 'vitest';
import { readFileSync } from 'node:fs';
import { sugerirCorreccionEmail } from '../../../utils/emailSugerencia';

// Auditoría 11/10 (área fotos/inscripción): regresiones de los arreglos chicos.
describe('INS-6: la sugerencia de email no «corrige» dominios reales', () => {
  it('deja quietos ymail.com, mail.com, email.com y live.com.mx', () => {
    for (const d of ['ymail.com', 'mail.com', 'email.com', 'live.com.mx', 'hotmail.es', 'me.com']) {
      expect(sugerirCorreccionEmail(`ana@${d}`)).toBeNull();
    }
  });
  it('sigue corrigiendo los errores de tipeo', () => {
    expect(sugerirCorreccionEmail('ana@gmial.com')).toBe('ana@gmail.com');
    expect(sugerirCorreccionEmail('ana@gmail.comm')).toBe('ana@gmail.com');
  });
});

const lote = readFileSync('src/components/AdminLoteFotosTab.tsx', 'utf8');
describe('FOT-1/2/4/5: subida de fotos', () => {
  it('FOT-1: los selectores de colegio y curso se traban con fotos en la cola', () => {
    for (const v of ['colegioSeleccionado', 'gradoSeleccionado', 'turnoSeleccionado', 'divisionSeleccionada']) {
      expect(lote).toContain(`value={${v}} disabled={colaPendiente}`);
    }
    expect(lote).toContain("const colaPendiente = fotosLote.some(f => f.estado !== 'registrada');");
  });
  it('FOT-2: el saneado colapsa los «..» que el servidor descarta', () => {
    expect(lote).toContain(".replace(/\\.{2,}/g, '.')");
  });
  it('FOT-4: al cambiar de curso se vacía la lista antes de recargar', () => {
    expect(lote).toMatch(/setFotosActivasCurso\(\[\]\); setErrorFotosCurso\(null\);[^\n]*\n\s*recargarFotosActivas\(\);/);
  });
  it('FOT-5: el selector de archivos se resetea para poder volver a elegir los mismos', () => {
    expect(lote).toContain("e.target.value = ''");
  });
});
