import { render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { afterEach, describe, expect, it } from 'vitest';
import PortalFamiliasModal from '../../../components/PortalFamiliasModal';
import { json, llamadas, mockearFamiliaDeUnHijo, sobreescribirFetch } from '../portal/ayudas';

afterEach(() => window.history.replaceState(null, '', '/'));

describe('revisión: tarjeta rechazada → paso a transferencia', () => {
  it('después de cambiar a transferencia se ven los datos bancarios y la subida del comprobante', async () => {
    const GRUPO = '11111111-2222-4333-8444-555555555555';
    const FILA = 'aaaaaaaa-bbbb-4ccc-8ddd-eeeeeeeeeeee';
    mockearFamiliaDeUnHijo();
    window.history.replaceState(null, '', `/?mp_status=rejected&grupo_pago_id=${GRUPO}&t=llave-grupo`);
    // MP rechazó la tarjeta: el servidor deja el pedido "cancelado" no definitivo → estadoPago 'rechazado'.
    sobreescribirFetch((u) => u.includes(`/api/pedidos/${GRUPO}/status`), () => json(200, { success: true, pedidoId: FILA, estado: 'cancelado', estadoPago: 'rechazado', total: 60000, metodoPago: 'mercadopago' }));
    sobreescribirFetch((u) => u.includes('/api/mercadopago/crear-preferencia-multiple'), () => json(200, { success: true, initPoint: 'https://mp.test/g' }));
    sobreescribirFetch((u) => u.includes('/cambiar-metodo-pago'), () => json(200, { success: true, metodoPago: 'transferencia' }));
    sobreescribirFetch((u) => u.includes('/api/pagos/comprobante'), () => json(200, { success: true, subido: false }));
    const user = userEvent.setup();
    render(<PortalFamiliasModal isOpen={true} onClose={() => {}} />);
    await waitFor(() => expect(llamadas(`/api/pedidos/${GRUPO}/status`).length).toBeGreaterThan(0));
    await user.click(await screen.findByRole('button', { name: /pagar con transferencia/i }));
    await user.click(document.getElementById('chk-plazo-cambio-transferencia') as HTMLElement);
    await user.click(screen.getByRole('button', { name: /confirmar el pago por transferencia/i }));
    await waitFor(() => expect(llamadas('/cambiar-metodo-pago')).toHaveLength(1));
    // Damos tiempo a cualquier re-verificación automática.
    await new Promise((r) => setTimeout(r, 1500));
    expect(screen.queryByText(/datos para completar la transferencia bancaria/i)).toBeInTheDocument();
  }, 20000);
});
