import { render, screen, act } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { describe, expect, it, vi } from 'vitest';
import PortalFamiliasModal from '../../../components/PortalFamiliasModal';
import LegalModal from '../../../components/legal/LegalModal';
import { abrirLegal } from '../../../legal/aceptacion';
import { guardarFamilia, mockearFamiliaDeUnHijo, irAlPaso4 } from '../portal/ayudas';

describe('revisión: Escape', () => {
  it('Escape con los Términos (LegalModal) abiertos NO debería cerrar el portal', async () => {
    guardarFamilia();
    mockearFamiliaDeUnHijo();
    const onClose = vi.fn();
    const user = userEvent.setup();
    render(<><PortalFamiliasModal isOpen={true} onClose={onClose} /><LegalModal /></>);
    await screen.findByRole('button', { name: /abrir galería de fotos/i });
    act(() => abrirLegal('terminos'));
    expect(await screen.findByRole('dialog', { name: /t[ée]rminos/i })).toBeInTheDocument();
    await user.keyboard('{Escape}');
    expect(screen.queryByRole('dialog', { name: /t[ée]rminos/i })).not.toBeInTheDocument();
    expect(onClose).not.toHaveBeenCalled();
  });

  it('Escape escribiendo en un campo de texto NO debería cerrar el portal', async () => {
    guardarFamilia();
    mockearFamiliaDeUnHijo();
    const onClose = vi.fn();
    const user = userEvent.setup();
    render(<PortalFamiliasModal isOpen={true} onClose={onClose} />);
    await irAlPaso4(user);
    const campos = screen.getAllByRole('textbox');
    expect(campos.length).toBeGreaterThan(0);
    const campo = campos[campos.length - 1] as HTMLInputElement;
    campo.focus();
    await user.keyboard('{Escape}');
    expect(onClose).not.toHaveBeenCalled();
  });
});
