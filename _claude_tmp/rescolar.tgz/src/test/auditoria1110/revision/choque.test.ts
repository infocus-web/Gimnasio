import { expect, it } from 'vitest';
import { verificarSinChoqueCodigoCurso, invalidarCacheCodigosSeccion } from '../../../../servidor/nucleo/codigosCurso';

// Revisión 11/10 (FAM-2): «Mañana» y «Turno Mañana», «A» y «División A» o mayúsculas distintas son la MISMA sección
// (no es choque); «Jornada Extendida» y «Jornada Completa» sí chocan (las dos dan JE).
it('la misma sección escrita distinto no es choque; dos secciones distintas con el mismo código sí', async () => {
  const filas = [{ id: 1, colegio_id: 'c1', grado: '1° Grado', turno: 'Turno Mañana', division: 'A', codigo_secreto: 'X' },
    { id: 2, colegio_id: 'c1', grado: '2° grado', turno: 'Jornada Extendida', division: 'A', codigo_secreto: 'Y' }];
  const sb: any = { from: () => ({ select: () => ({ order: () => ({ order: () => ({ range: (d: number) => Promise.resolve({ data: d === 0 ? filas : [], error: null }) }), range: (d: number) => Promise.resolve({ data: d === 0 ? filas : [], error: null }) }) }) }) };
  for (const [g, t, d] of [['1° grado', 'Mañana', 'A'], ['1° Grado', 'Turno Mañana', 'A'], ['1° grado', 'Turno Mañana', 'División A']]) {
    invalidarCacheCodigosSeccion();
    await expect(verificarSinChoqueCodigoCurso(sb, 'c1', g, t, d)).resolves.toBeUndefined();
  }
  invalidarCacheCodigosSeccion();
  await expect(verificarSinChoqueCodigoCurso(sb, 'c1', '2° grado', 'Jornada Completa', 'A')).rejects.toMatchObject({ status: 409 });
});
