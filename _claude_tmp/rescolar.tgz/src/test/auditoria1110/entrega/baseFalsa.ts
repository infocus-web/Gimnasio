// Auditoría 11/10/2026 (área ENTREGA): base de Supabase, Storage y Resend falsos en memoria para las
// pruebas de regresión de esta carpeta. Nada sale a la red. PostgREST se imita con su tope de 1000 filas
// por respuesta (db-max-rows) y `registrar_intento` con la misma lógica que la función de la base.

export const estado = {
  tablas: {} as Record<string, any[]>,
  archivos: new Map<string, Buffer>(),
  mails: [] as Array<{ to: string[]; subject: string; html: string; clave?: string; replyTo?: string }>,
  inbound: new Map<string, any>(),
  inboundFalla: false,
  limites: new Map<string, { cantidad: number; desde: number }>(),
  fallaInsert: new Set<string>(),
  antesDeUpdate: null as null | ((tabla: string, cambios: any) => void),
  maxFilas: 1000,
  enviosEmail: 0,
};

export function reiniciar() {
  estado.tablas = {};
  estado.archivos = new Map();
  estado.mails = [];
  estado.inbound = new Map();
  estado.inboundFalla = false;
  estado.limites = new Map();
  estado.fallaInsert = new Set();
  estado.antesDeUpdate = null;
  estado.maxFilas = 1000;
  estado.enviosEmail = 0;
}

const valor = (fila: any, campo: string) => {
  if (campo.includes('->>')) {
    const [col, clave] = campo.split('->>');
    return fila[col]?.[clave] ?? null;
  }
  return fila[campo] ?? null;
};
const comparar = (a: any, b: any) => {
  const fa = Date.parse(a);
  const fb = Date.parse(b);
  return Number.isFinite(fa) && Number.isFinite(fb) ? fa - fb : String(a).localeCompare(String(b));
};

export function consulta(tabla: string) {
  const filtros: Array<(f: any) => boolean> = [];
  let cambios: Record<string, any> | null = null;
  let insertar: any[] | null = null;
  let upsert: { filas: any[]; opciones: any } | null = null;
  let unica = false;
  let limite: number | null = null;
  let rango: [number, number] | null = null;
  let soloConteo = false;
  let orden: { campo: string; asc: boolean } | null = null;
  const q: any = {
    select: (_c?: string, o?: { count?: string; head?: boolean }) => {
      if (o?.head) soloConteo = true;
      return q;
    },
    eq: (c: string, v: any) => (filtros.push((f) => valor(f, c) === v), q),
    neq: (c: string, v: any) => (filtros.push((f) => valor(f, c) !== v), q),
    is: (c: string, v: any) => (filtros.push((f) => valor(f, c) === v), q),
    not: (c: string, op: string, v: any) => (filtros.push((f) => !(op === 'is' && valor(f, c) === v)), q),
    in: (c: string, vs: any[]) => (filtros.push((f) => vs.includes(valor(f, c))), q),
    ilike: (c: string, v: string) => (filtros.push((f) => String(valor(f, c) || '').toLowerCase() === String(v).replace(/\\/g, '').toLowerCase()), q),
    gt: (c: string, v: any) => (filtros.push((f) => valor(f, c) !== null && comparar(valor(f, c), v) > 0), q),
    gte: (c: string, v: any) => (filtros.push((f) => valor(f, c) !== null && comparar(valor(f, c), v) >= 0), q),
    lte: (c: string, v: any) => (filtros.push((f) => valor(f, c) !== null && comparar(valor(f, c), v) <= 0), q),
    lt: (c: string, v: any) => (filtros.push((f) => valor(f, c) !== null && comparar(valor(f, c), v) < 0), q),
    or: () => q, // no lo usan las rutas probadas en esta carpeta
    order: (campo: string, o?: { ascending?: boolean }) => ((orden = { campo, asc: o?.ascending !== false }), q),
    limit: (n: number) => ((limite = n), q),
    range: (d: number, h: number) => ((rango = [d, h]), q),
    update: (c: Record<string, any>) => ((cambios = c), q),
    insert: (f: any) => ((insertar = Array.isArray(f) ? f : [f]), q),
    upsert: (f: any, o?: any) => ((upsert = { filas: Array.isArray(f) ? f : [f], opciones: o || {} }), q),
    maybeSingle: () => ((unica = true), q),
    single: () => ((unica = true), q),
    then: (ok: any, mal: any) => Promise.resolve(ejecutar()).then(ok, mal),
  };
  function ejecutar() {
    const filas = (estado.tablas[tabla] = estado.tablas[tabla] || []);
    if (insertar) {
      if (estado.fallaInsert.has(tabla)) return { data: null, error: { message: `insert en ${tabla} rechazado`, code: '57014' } };
      const unicaPor = tabla === 'consultas_familias' ? 'resend_email_id' : null;
      if (unicaPor && insertar.some((f) => f[unicaPor] && filas.some((x) => x[unicaPor] === f[unicaPor]))) {
        return { data: null, error: { message: 'duplicate key', code: '23505' } };
      }
      const nuevas = insertar.map((f) => ({ id: f.id || `${tabla}-${filas.length + 1}`, ...f }));
      filas.push(...nuevas);
      const copia = nuevas.map((f) => ({ ...f }));
      return { data: unica ? copia[0] : copia, error: null };
    }
    if (upsert) {
      const clave = upsert.opciones.onConflict || 'id';
      const nuevas: any[] = [];
      for (const f of upsert.filas) {
        const existe = filas.find((x) => x[clave] !== undefined && x[clave] === f[clave]);
        if (existe) {
          if (!upsert.opciones.ignoreDuplicates) Object.assign(existe, f);
          continue;
        }
        const nueva = { id: f.id || `${tabla}-${filas.length + 1}`, ...f };
        filas.push(nueva);
        nuevas.push({ ...nueva });
      }
      return { data: nuevas, error: null };
    }
    let elegidas = filas.filter((f) => filtros.every((fn) => fn(f)));
    if (soloConteo) return { data: null, count: elegidas.length, error: null };
    if (cambios) {
      estado.antesDeUpdate?.(tabla, cambios);
      elegidas = filas.filter((f) => filtros.every((fn) => fn(f)));
      for (const f of elegidas) Object.assign(f, cambios);
    }
    if (orden) {
      const { campo, asc } = orden;
      elegidas = [...elegidas].sort((a, b) => (asc ? 1 : -1) * comparar(valor(a, campo), valor(b, campo)));
    }
    if (rango) elegidas = elegidas.slice(rango[0], rango[1] + 1);
    else if (limite !== null) elegidas = elegidas.slice(0, limite);
    if (!cambios) elegidas = elegidas.slice(0, estado.maxFilas);
    const copia = elegidas.map((f) => JSON.parse(JSON.stringify(f)));
    return { data: unica ? copia[0] ?? null : copia, error: null };
  }
  return q;
}

export async function rpc(nombre: string, args: any) {
  if (nombre === 'registrar_intento') {
    const ahora = Date.now();
    const actual = estado.limites.get(args.p_clave);
    if (!actual || actual.desde < ahora - args.p_ventana_seg * 1000) estado.limites.set(args.p_clave, { cantidad: 1, desde: ahora });
    else actual.cantidad += 1;
    const fila = estado.limites.get(args.p_clave)!;
    // Como la tabla real: superoTopeIntentos lee limites_intentos por clave.
    const tabla = (estado.tablas.limites_intentos = estado.tablas.limites_intentos || []);
    const existente = tabla.find((x) => x.clave === args.p_clave);
    const datos = { clave: args.p_clave, cantidad: fila.cantidad, desde: new Date(fila.desde).toISOString() };
    if (existente) Object.assign(existente, datos);
    else tabla.push(datos);
    return { data: fila.cantidad > args.p_max ? Math.max(1, Math.ceil((fila.desde + args.p_ventana_seg * 1000 - ahora) / 1000)) : 0, error: null };
  }
  if (nombre === 'sumar_envios_email') {
    estado.enviosEmail += args.p_cantidad;
    return { data: [{ hoy: estado.enviosEmail, mes: estado.enviosEmail }], error: null };
  }
  return { data: null, error: null };
}

export const storage = {
  from: (bucket: string) => ({
    download: async (ruta: string) => {
      const b = estado.archivos.get(`${bucket}/${ruta}`);
      if (!b) return { data: null, error: { message: 'Object not found' } };
      return { data: { arrayBuffer: async () => b.buffer.slice(b.byteOffset, b.byteOffset + b.byteLength) }, error: null };
    },
    upload: async (ruta: string, contenido: Buffer) => {
      estado.archivos.set(`${bucket}/${ruta}`, Buffer.from(contenido));
      return { data: { path: ruta }, error: null };
    },
    createSignedUrl: async (ruta: string, segundos: number) => {
      if (!estado.archivos.has(`${bucket}/${ruta}`)) return { data: null, error: { message: 'Object not found' } };
      const payload = Buffer.from(JSON.stringify({ exp: Math.floor(Date.now() / 1000) + segundos })).toString('base64url');
      return { data: { signedUrl: `https://storage.test/${bucket}/${encodeURI(ruta)}?token=x.${payload}.y` }, error: null };
    },
  }),
};

export class ResendFalso {
  emails = {
    send: async (datos: any, opciones?: { idempotencyKey?: string }) => {
      // Freno de seguridad: un bucle de envíos (ENT-6) colgaría la prueba en vez de hacerla fallar.
      if (estado.mails.length >= 500) return { data: null, error: { name: 'validation_error', statusCode: 422, message: 'freno de la prueba' } };
      estado.mails.push({ to: datos.to, subject: datos.subject, html: datos.html, clave: opciones?.idempotencyKey, replyTo: datos.replyTo });
      return { data: { id: `mail-${estado.mails.length}` }, error: null };
    },
    receiving: {
      get: async (id: string) =>
        estado.inboundFalla || !estado.inbound.has(id)
          ? { data: null, error: { name: 'application_error', statusCode: 500, message: 'Internal server error' } }
          : { data: estado.inbound.get(id), error: null },
      attachments: { list: async () => ({ data: { data: [] }, error: null }) },
    },
  };
  batch = { send: async () => ({ data: { data: [] }, error: null }) };
  webhooks = {
    verify: ({ payload, headers }: any) => {
      if (headers.signature !== 'v1,valida') throw new Error('firma inválida');
      return JSON.parse(payload);
    },
  };
}
