// Auditoría 11/10/2026 — área ENTREGA: pruebas de regresión de ENT-1 a ENT-6 y DB-5 (claves de
// limites_intentos sin DNI ni email). Cada una falla con el código anterior al arreglo.
// Corre las rutas reales sobre la base, Storage y Resend falsos de ./baseFalsa (nada sale a la red).
import http from 'http';
import type { AddressInfo } from 'net';
import express from 'express';
import JSZip from 'jszip';
import { afterAll, beforeAll, beforeEach, describe, expect, it, vi } from 'vitest';
import { estado, reiniciar } from './baseFalsa';

vi.mock('dotenv', () => {
  const config = () => ({ parsed: {} });
  return { default: { config }, config };
});
vi.mock('@supabase/supabase-js', async () => {
  const b = await import('./baseFalsa');
  return { createClient: () => ({ from: (t: string) => b.consulta(t), rpc: b.rpc, storage: b.storage }) };
});
vi.mock('resend', async () => {
  const b = await import('./baseFalsa');
  return { Resend: b.ResendFalso };
});

const CASILLA_ZOHO = 'colegios@contacto.retratoescolar.com.ar';
const PABLO = 'pablo@prueba.test';
let servidor: http.Server;
let puerto = 0;
const entornoAntes: Record<string, string | undefined> = {};

function pedir(metodo: string, ruta: string, cuerpo?: string, encabezados: Record<string, string> = {}): Promise<{ status: number; json: any }> {
  return new Promise((ok, mal) => {
    const hdrs: Record<string, string | number> = { ...encabezados };
    if (cuerpo !== undefined) {
      hdrs['Content-Type'] = 'application/json';
      hdrs['Content-Length'] = Buffer.byteLength(cuerpo);
    }
    const req = http.request({ host: '127.0.0.1', port: puerto, path: ruta, method: metodo, headers: hdrs }, (res) => {
      let texto = '';
      res.setEncoding('utf8');
      res.on('data', (c) => { texto += c; });
      res.on('end', () => {
        let json: any = null;
        try { json = JSON.parse(texto); } catch { /* html */ }
        ok({ status: res.statusCode || 0, json });
      });
    });
    req.on('error', mal);
    if (cuerpo !== undefined) req.write(cuerpo);
    req.end();
  });
}

function eventoEntrante(emailId: string, datos: Record<string, any> = {}) {
  const cuerpo = JSON.stringify({ type: 'email.received', data: { email_id: emailId, ...datos } });
  return pedir('POST', '/api/webhooks/resend-inbound', cuerpo, { 'svix-id': `msg_${emailId}`, 'svix-timestamp': String(Math.floor(Date.now() / 1000)), 'svix-signature': 'v1,valida' });
}

const reenviosAZoho = () => estado.mails.filter((m) => m.to.includes(CASILLA_ZOHO) && m.subject.startsWith('Fwd:'));

beforeAll(async () => {
  for (const n of ['SUPABASE_SERVICE_ROLE_KEY', 'RESEND_API_KEY', 'RESEND_WEBHOOK_SECRET', 'CRON_SECRET', 'CONSULTAS_EMAIL', 'ADMIN_SESSION_SECRET', 'PEDIDOS_ACCESO_SECRET', 'RESEND_LIMITE_DIARIO']) entornoAntes[n] = process.env[n];
  process.env.SUPABASE_SERVICE_ROLE_KEY = 'prueba';
  process.env.RESEND_API_KEY = 'prueba';
  process.env.RESEND_WEBHOOK_SECRET = 'whsec_prueba';
  process.env.CRON_SECRET = 'secreto-cron';
  process.env.ADMIN_SESSION_SECRET = 'secreto-admin';
  process.env.PEDIDOS_ACCESO_SECRET = 'secreto-pedidos';
  const { rutasCorreoEntrante } = await import('../../../../servidor/correoEntrante');
  const { rutasTareasProgramadas } = await import('../../../../servidor/tareasProgramadas');
  const app = express();
  app.use(rutasCorreoEntrante);
  app.use(express.json());
  app.use(rutasTareasProgramadas);
  servidor = app.listen(0);
  await new Promise((ok) => servidor.once('listening', ok));
  puerto = (servidor.address() as AddressInfo).port;
}, 120_000);

afterAll(async () => {
  await new Promise((ok) => servidor.close(ok));
  for (const [n, v] of Object.entries(entornoAntes)) {
    if (v === undefined) delete process.env[n];
    else process.env[n] = v;
  }
});

beforeEach(() => {
  reiniciar();
  delete process.env.CONSULTAS_EMAIL;
  delete process.env.RESEND_LIMITE_DIARIO;
});

// ---------------------------------------------------------------------------------------------
describe('ENT-1: correos de familias que parecían «automáticos» por el asunto', () => {
  it('«ausente» en el asunto: entra al panel como consulta nueva', async () => {
    estado.inbound.set('e1', {
      id: 'e1', from: 'Mariana Gómez <mariana.gomez@gmail.com>', to: ['contacto@retratoescolar.com.ar'],
      subject: 'Mi hijo estuvo ausente el día de la foto', text: 'Hola, Tomás de 3° B faltó el día de las fotos.', headers: {}, attachments: [],
    });
    const r = await eventoEntrante('e1', { to: ['contacto@retratoescolar.com.ar'] });
    expect(r.status).toBe(200);
    expect(r.json).toMatchObject({ success: true, motivo: 'nueva' });
    expect(estado.tablas.consultas_familias).toHaveLength(1);
  });

  it('«no se pudo entregar» en el asunto: también entra', async () => {
    estado.inbound.set('e1b', {
      id: 'e1b', from: 'papa@gmail.com', to: ['contacto@retratoescolar.com.ar'],
      subject: 'El kit no se pudo entregar en el colegio', text: 'Hola, ¿qué pasó con el kit?', headers: {}, attachments: [],
    });
    const r = await eventoEntrante('e1b', { to: ['contacto@retratoescolar.com.ar'] });
    expect(r.json).toMatchObject({ motivo: 'nueva' });
  });

  it('una autorespuesta de verdad (encabezado Auto-Submitted) no entra al panel pero se reenvía a Zoho', async () => {
    estado.inbound.set('e2', {
      id: 'e2', from: 'mama@empresa.com', to: ['contacto@retratoescolar.com.ar'], subject: 'Fuera de la oficina',
      text: 'Vuelvo el lunes.', headers: { 'Auto-Submitted': 'auto-replied' }, attachments: [],
    });
    const r = await eventoEntrante('e2', { to: ['contacto@retratoescolar.com.ar'] });
    expect(r.json).toMatchObject({ success: true, reenviado: true });
    expect(estado.tablas.consultas_familias || []).toHaveLength(0);
    expect(reenviosAZoho()).toHaveLength(1);
  });

  it('anti-bucle: una autorespuesta que sale de nuestro dominio no se reenvía', async () => {
    estado.inbound.set('e3', {
      id: 'e3', from: 'fotos@retratoescolar.com.ar', to: ['contacto@retratoescolar.com.ar'], subject: 'Respuesta automática',
      text: 'x', headers: { 'Auto-Submitted': 'auto-replied' }, attachments: [],
    });
    const r = await eventoEntrante('e3', { to: ['contacto@retratoescolar.com.ar'] });
    expect(r.status).toBe(200);
    expect(estado.mails).toHaveLength(0);
  });
});

describe('ENT-2: si Resend no devuelve el correo recibido, se pide el reintento', () => {
  it('comprobante a fotos@: 503 y nada escrito; el reintento (con el correo ya disponible) lo reenvía una sola vez', async () => {
    estado.inboundFalla = true;
    const evento = { from: 'papa@gmail.com', to: ['fotos@retratoescolar.com.ar'], subject: 'Comprobante IFS-2026-1234' };
    const r1 = await eventoEntrante('e4', evento);
    expect(r1.status).toBe(503);
    expect(estado.mails).toHaveLength(0);

    estado.inboundFalla = false;
    estado.inbound.set('e4', { id: 'e4', ...evento, text: 'Adjunto comprobante', headers: {}, attachments: [] });
    const r2 = await eventoEntrante('e4', evento);
    expect(r2.json).toMatchObject({ success: true, reenviado: true });
    expect(reenviosAZoho()).toHaveLength(1);
    expect(reenviosAZoho()[0].clave).toBe('reenvio-e4'); // Resend descarta un tercer intento con la misma clave
  });

  it('consulta a contacto@: el reintento después de un éxito no duplica la consulta en el panel', async () => {
    estado.inboundFalla = true;
    const evento = { from: 'mama@gmail.com', to: ['contacto@retratoescolar.com.ar'], subject: 'Consulta' };
    expect((await eventoEntrante('e5', evento)).status).toBe(503);
    expect(estado.tablas.consultas_familias || []).toHaveLength(0);

    estado.inboundFalla = false;
    estado.inbound.set('e5', { id: 'e5', from: 'mama@gmail.com', to: ['contacto@retratoescolar.com.ar'], subject: 'Consulta', text: '¿Cuándo llegan las fotos?', headers: {}, attachments: [] });
    expect((await eventoEntrante('e5', evento)).json).toMatchObject({ motivo: 'nueva' });
    expect((await eventoEntrante('e5', evento)).json).toMatchObject({ motivo: 'duplicado' });
    expect(estado.tablas.consultas_familias).toHaveLength(1);
  });

  it('respuesta a una consulta (consulta-<uuid>@) sin texto: se guarda igual con el aviso (no 503)', async () => {
    estado.inboundFalla = true;
    const id = '11111111-2222-3333-4444-555555555555';
    estado.tablas.consultas_familias = [{ id, email: 'mama@gmail.com', estado: 'en_proceso' }];
    const r = await eventoEntrante('e6', { from: 'mama@gmail.com', to: [`consulta-${id}@respuestas.retratoescolar.com.ar`], subject: 'Re: Consulta' });
    expect(r.status).toBe(200);
    expect(estado.tablas.consultas_familias_mensajes).toHaveLength(1);
  });
});

// ---------------------------------------------------------------------------------------------
const PEDIDO_ID = '11111111-2222-3333-4444-555555555555';
function prepararPedidoConFotos(cantidadFotosCurso: number, posicionPatio: number) {
  const fotos: any[] = [];
  for (let i = 0; i < cantidadFotosCurso; i++) {
    const categoria = i === 0 ? 'individual' : i === 1 ? 'grupal' : i === 2 ? 'docente' : 'patio';
    const id = `f-${String(i).padStart(5, '0')}`;
    fotos.push({ id, colegio_id: 'c1', codigo_curso: 'CUR-1', categoria, storage_path: `2026/c1/${id}.jpg` });
    estado.archivos.set(`fotos-hd/2026/c1/${id}.jpg`, Buffer.from(`jpg-${id}`));
  }
  estado.tablas.fotos = fotos;
  const pedido = {
    id: PEDIDO_ID, pedido_friendly_id: 'IFS-2026-0001', estado: 'pagado', colegio_id: 'c1', curso_codigo: 'CUR-1',
    alumno_nombre: 'Ana', colegio_nombre: 'Colegio', seleccion_pendiente: false,
    fotos_seleccionadas: { individualId: 'f-00000', grupalId: 'f-00001', docenteId: 'f-00002', otrasIds: [`f-${String(posicionPatio).padStart(5, '0')}`] },
  };
  estado.tablas.pedidos = [pedido];
  return pedido;
}

async function armarZip(pedido: any) {
  const { generarYSubirZipHDParaPedido } = await import('../../../../servidor/entrega/zipHD');
  const { getServerSupabase } = await import('../../../../servidor/nucleo/clientes');
  return generarYSubirZipHDParaPedido(getServerSupabase()!, pedido);
}

describe('ENT-3: el .zip HD trae sólo las fotos del pedido (sin el tope de 1000 filas)', () => {
  it('curso con 1.200 fotos y la suelta elegida en la posición 1.100: .zip completo, sin aviso a Pablo', async () => {
    process.env.CONSULTAS_EMAIL = PABLO;
    const link = await armarZip(prepararPedidoConFotos(1200, 1100));
    expect(link).toContain(`zips-pedidos/${PEDIDO_ID}.zip`);
    const zip = await JSZip.loadAsync(estado.archivos.get(`fotos-hd/zips-pedidos/${PEDIDO_ID}.zip`)!);
    expect(Object.keys(zip.files).sort()).toEqual(['Con_la_seño.jpg', 'Grupal.jpg', 'Individual.jpg', 'Otra_1.jpg']);
    expect(await zip.file('Otra_1.jpg')!.async('string')).toBe('jpg-f-01100');
    expect(estado.mails).toHaveLength(0);
  });

  it('una foto elegida de OTRO curso no se cuela en el .zip', async () => {
    process.env.CONSULTAS_EMAIL = PABLO;
    const pedido = prepararPedidoConFotos(10, 5);
    estado.tablas.fotos[5].codigo_curso = 'OTRO-CURSO';
    expect(await armarZip(pedido)).toBeNull();
    expect(estado.mails.filter((m) => m.to.includes(PABLO))).toHaveLength(1);
  });
});

describe('22/10: «no tiene esta foto» en el .zip HD', () => {
  it('sin individual: el .zip va sin ella; con otra foto en su lugar, va como «En_lugar_de_la_individual»', async () => {
    process.env.CONSULTAS_EMAIL = PABLO;
    const sin = prepararPedidoConFotos(10, 5);
    sin.fotos_seleccionadas = { individualId: '', grupalId: 'f-00001', docenteId: 'f-00002', otrasIds: [], sinFoto: ['individual'] } as any;
    expect(await armarZip(sin)).toContain(`zips-pedidos/${PEDIDO_ID}.zip`);
    let zip = await JSZip.loadAsync(estado.archivos.get(`fotos-hd/zips-pedidos/${PEDIDO_ID}.zip`)!);
    expect(Object.keys(zip.files).sort()).toEqual(['Con_la_seño.jpg', 'Grupal.jpg']);
    const con = prepararPedidoConFotos(10, 5);
    estado.tablas.fotos[5].categoria = 'grupal'; // otra grupal del curso
    con.fotos_seleccionadas = { individualId: 'f-00005', grupalId: 'f-00001', docenteId: 'f-00002', otrasIds: [], sinFoto: ['individual'] } as any;
    expect(await armarZip(con)).toContain(`zips-pedidos/${PEDIDO_ID}.zip`);
    zip = await JSZip.loadAsync(estado.archivos.get(`fotos-hd/zips-pedidos/${PEDIDO_ID}.zip`)!);
    expect(Object.keys(zip.files).sort()).toEqual(['Con_la_seño.jpg', 'En_lugar_de_la_individual.jpg', 'Grupal.jpg']);
    expect(estado.mails).toHaveLength(0);
  });
});

describe('ENT-4: pedido pagado cuyo curso quedó sin fotos', () => {
  it('avisa a Pablo («fotos faltantes») una sola vez cada 24 h', async () => {
    process.env.CONSULTAS_EMAIL = PABLO;
    const pedido = prepararPedidoConFotos(5, 4);
    estado.tablas.fotos = [];
    expect(await armarZip(pedido)).toBeNull();
    const avisos = () => estado.mails.filter((m) => m.to.includes(PABLO));
    expect(avisos()).toHaveLength(1);
    expect(avisos()[0].html).toContain('4 foto(s) elegidas por la familia ya no existen en el curso');
    expect(await armarZip(pedido)).toBeNull(); // el reintento horario no vuelve a avisar
    expect(avisos()).toHaveLength(1);
  });
});

// ---------------------------------------------------------------------------------------------
const hace = (horas: number) => new Date(Date.now() - horas * 3600_000).toISOString();
function pedidoTransferencia(extra: Record<string, any> = {}) {
  return {
    id: 'P1', pedido_friendly_id: 'IFS-2026-0101', grupo_pago_id: null, estado: 'pendiente_pago', metodo_pago: 'transferencia', total: 30000,
    alumno_nombre: 'Ana', colegio_nombre: 'Colegio', archivado: false, en_espera: false, cancelado_definitivo: false,
    comprobante_subido_at: null, mp_preference_id: null, nave_payment_request_id: null, created_at: hace(50), transferencia_desde: hace(49),
    recordatorio_pago_at: hace(30), aviso_vencimiento_at: hace(10), familias: { nombre: 'Familia', email: 'familia@prueba.test' }, ...extra,
  };
}
const correrCron = () => pedir('POST', '/api/cron/recordar-pagos-pendientes', '{}', { Authorization: 'Bearer secreto-cron' });

describe('ENT-5: la cancelación/aviso por transferencia vencida re-chequea el pedido al escribir', () => {
  for (const [caso, cambio] of [
    ['pasa a Mercado Pago', { metodo_pago: 'mercadopago', mp_preference_id: 'pref-1' }],
    ['Pablo lo pone en espera', { en_espera: true }],
    ['Pablo lo archiva', { archivado: true }],
  ] as const) {
    it(`si justo antes del UPDATE ${caso}, no se cancela ni se manda «se canceló»`, async () => {
      estado.tablas.pedidos = [pedidoTransferencia()];
      estado.antesDeUpdate = (tabla, cambios) => {
        if (tabla === 'pedidos' && cambios.estado === 'cancelado') Object.assign(estado.tablas.pedidos[0], cambio);
      };
      const r = await correrCron();
      expect(r.json).toMatchObject({ success: true, cancelados: 0 });
      expect(estado.tablas.pedidos[0].estado).toBe('pendiente_pago');
      expect(estado.mails.some((m) => /se canceló tu pedido/.test(m.subject))).toBe(false);
    });
  }

  it('aviso de 12 h: si justo pasa a Mercado Pago, no se marca ni se avisa a la familia', async () => {
    estado.tablas.pedidos = [pedidoTransferencia({ transferencia_desde: hace(40), created_at: hace(40), aviso_vencimiento_at: null })];
    estado.antesDeUpdate = (tabla, cambios) => {
      if (tabla === 'pedidos' && 'aviso_vencimiento_at' in cambios) Object.assign(estado.tablas.pedidos[0], { metodo_pago: 'mercadopago' });
    };
    const r = await correrCron();
    expect(r.json).toMatchObject({ avisosPorVencer: 0 });
    expect(estado.tablas.pedidos[0].aviso_vencimiento_at).toBeNull();
    expect(estado.mails.filter((m) => m.to.includes('familia@prueba.test'))).toHaveLength(0);
  });

  it('control: sin cambios, la transferencia vencida se cancela como siempre', async () => {
    estado.tablas.pedidos = [pedidoTransferencia()];
    const r = await correrCron();
    expect(r.json).toMatchObject({ cancelados: 1 });
    expect(estado.tablas.pedidos[0].estado).toBe('cancelado');
  });
});

// ---------------------------------------------------------------------------------------------
async function enviarUnCorreoCercaDelCupo() {
  process.env.RESEND_LIMITE_DIARIO = '10';
  process.env.CONSULTAS_EMAIL = PABLO;
  estado.enviosEmail = 9;
  const { getResendClient } = await import('../../../../servidor/nucleo/clientes');
  await getResendClient()!.emails.send({ from: 'a@b.c', to: ['familia@prueba.test'], subject: 'x', html: 'x' } as any);
  for (let i = 0; i < 20; i++) await new Promise((r) => setTimeout(r, 5));
  return estado.mails.filter((m) => m.to.includes(PABLO));
}

describe('ENT-6: aviso de cupo de Resend', () => {
  it('si no se puede guardar la marca, no avisa (y no entra en bucle)', async () => {
    estado.fallaInsert.add('reportes_errores');
    expect(await enviarUnCorreoCercaDelCupo()).toHaveLength(0);
  });

  it('con la marca guardada: un solo aviso, que no se cuenta a sí mismo', async () => {
    const avisos = await enviarUnCorreoCercaDelCupo();
    expect(avisos).toHaveLength(1);
    expect(avisos[0].subject).toContain('cupo de emails');
    expect(estado.enviosEmail).toBe(10); // 9 + el correo a la familia; el aviso no suma
  });
});

// ---------------------------------------------------------------------------------------------
describe('DB-5: limites_intentos sin DNI ni email en texto plano', () => {
  it('la clave por DNI guarda el hash, y sigue contando igual (mismo DNI → misma clave)', async () => {
    const { hayCupoPorClave, superoTopeIntentos } = await import('../../../../servidor/nucleo/limites');
    const clave = 'inscripciones-buscar-dni:ABCD-1234:30111222';
    for (let i = 0; i < 12; i++) expect(await hayCupoPorClave(clave, 12, 900)).toBe(true);
    expect(await hayCupoPorClave(clave, 12, 900)).toBe(false);
    expect(await superoTopeIntentos(clave, 12, 900)).toBe(true);
    const guardadas = [...estado.limites.keys()];
    expect(guardadas).toHaveLength(1);
    expect(guardadas[0]).toMatch(/^inscripciones-buscar-dni:ABCD-1234:h-[0-9a-f]{64}$/);
    expect(guardadas[0]).not.toContain('30111222');
    // Otro DNI es otra clave.
    expect(await hayCupoPorClave('inscripciones-buscar-dni:ABCD-1234:30111223', 12, 900)).toBe(true);
  });

  it('un email dentro de la clave se guarda como hash', async () => {
    const { hayCupoPorClave } = await import('../../../../servidor/nucleo/limites');
    await hayCupoPorClave('auto-respuesta:mama@gmail.com', 3, 86400);
    const [guardada] = [...estado.limites.keys()];
    expect(guardada).toMatch(/^auto-respuesta:h-[0-9a-f]{64}$/);
  });

  it('las claves sin datos personales no cambian', async () => {
    const { claveSinDatosPersonales } = await import('../../../../servidor/nucleo/limites');
    expect(claveSinDatosPersonales('reenvio-codigo:123e4567-e89b-12d3-a456-426614174000')).toBe('reenvio-codigo:123e4567-e89b-12d3-a456-426614174000');
    expect(claveSinDatosPersonales('inscripciones-buscar-fallas-ip:ABCD-1234:200.1.2.3')).toBe('inscripciones-buscar-fallas-ip:ABCD-1234:200.1.2.3');
  });
});
