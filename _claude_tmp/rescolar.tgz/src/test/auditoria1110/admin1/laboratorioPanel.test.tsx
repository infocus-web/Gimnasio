// Auditoría 11/10 (admin1): regresiones del resumen para facturar (ADM-10), CSV de cursos (ADM-12),
// textos de difusión (FRO-12) y nombres reales fuera del bundle (FRO-13).
import { readFileSync } from 'fs';
import path from 'path';
import { act, fireEvent, render, screen, waitFor } from '@testing-library/react';
import { beforeEach, describe, expect, it, vi } from 'vitest';

const m = vi.hoisted(() => ({ blobs: [] as { blob: Blob; nombre: string }[] }));
vi.mock('../../../services/excelDownloadHelper', async (importOriginal) => ({
  ...(await importOriginal<typeof import('../../../services/excelDownloadHelper')>()),
  descargarBlobSeguro: (blob: Blob, nombre: string) => (m.blobs.push({ blob, nombre }), true),
}));

import ResumenFacturacionLab from '../../../components/ResumenFacturacionLab';
import { CircularImprimibleModal } from '../../../components/CircularImprimibleModal';
import { descargarCSVEspañolCompatible, generarMensajeWhatsApp } from '../../../services/difusionEscolarService';
import { obtenerPedidosGuardados } from '../../../services/pedidosLabService';

const seccion = { id: 's', sala: '1° grado', turno: 'Mañana' as any, division: 'A', nombreCompleto: '1° grado "A" (Mañana)', totalAlumnos: 3 };

beforeEach(() => {
  m.blobs.length = 0;
});

describe('Resumen para facturar', () => {
  it('ADM-10: si se cambia de mes rápido, la respuesta vieja que llega tarde se descarta', async () => {
    const pendientes = new Map<string, (r: Response) => void>();
    const fetcher = (url: string) => new Promise<Response>((r) => pendientes.set(new URL(url, 'http://x').searchParams.get('desde')!, r));
    const respuesta = (desde: string, hasta: string, carpetas: number) =>
      ({ ok: true, json: async () => ({ success: true, desde, hasta, lotes: [], totales: { lotes: 0, pedidos: 0, carpetas, fotos20x30: 0, fotos15x21: 0, sueltas: 0 }, pendientes: [], totalesPendientes: { lotes: 0, pedidos: 0, carpetas: 0, fotos20x30: 0, fotos15x21: 0, sueltas: 0 } }) }) as unknown as Response;
    render(<ResumenFacturacionLab fetcher={fetcher} />);
    const inicial = [...pendientes.keys()][0];
    fireEvent.change(screen.getByLabelText('Mes'), { target: { value: '2026-01' } });
    await waitFor(() => expect(pendientes.has('2026-01-01')).toBe(true));
    await act(async () => pendientes.get('2026-01-01')!(respuesta('2026-01-01', '2026-01-31', 11)));
    await act(async () => pendientes.get(inicial)!(respuesta(inicial, inicial, 99)));
    expect(screen.getByText('11')).toBeInTheDocument();
    expect(screen.queryByText('99')).not.toBeInTheDocument();
  });
});

describe('CSV de cursos (Códigos y difusión)', () => {
  it('ADM-12: duplica las comillas y neutraliza fórmulas', async () => {
    descargarCSVEspañolCompatible([{ ...seccion, sala: '=HYPERLINK("http://x","clic")', nombreCompleto: '1° "A"' }], { s: 'ABC123' }, 'Colegio');
    const fila = (await m.blobs[0].blob.text()).split('\r\n')[1];
    expect(fila.startsWith('"1° ""A"""')).toBe(true);
    expect(fila).toContain(`"'=HYPERLINK(""http://x"",""clic"")"`);
  });
});

describe('Textos de difusión (FRO-12)', () => {
  it('el mensaje de WhatsApp y las notas imprimibles describen el acceso actual y la 3ª foto', () => {
    const msg = generarMensajeWhatsApp(seccion, 'ABC123', 'Colegio');
    expect(msg).toContain('Entrás con el código del curso, tu nombre y tu DNI');
    expect(msg).toContain('con la seño o con familia y/o amigos');
    expect(msg).not.toMatch(/Seleccionen a su hijo\/a de la lista/);
    render(<CircularImprimibleModal isOpen onClose={() => {}} secciones={[seccion]} codigosMap={{ s: 'ABC123' }} colegioNombre="Colegio" />);
    expect(document.body.textContent).toContain('tu nombre y tu DNI');
    expect(document.body.textContent).toContain('con la seño o con familia y/o amigos');
    expect(document.body.textContent).not.toMatch(/nómina de la sala|elegir al alumno|Grupal, Docente/);
  });
});

describe('Nombres reales fuera del código (FRO-13)', () => {
  it('pedidosLabService no tiene nombres de alumnos y no borra pedidos reales por el nombre', () => {
    const fuente = readFileSync(path.resolve(__dirname, '../../../services/pedidosLabService.ts'), 'utf8');
    expect(fuente).not.toMatch(/Abba|Fazio|Amigorena|Balbi/i);
    localStorage.setItem('infocus_pedidos_escolares_v1', JSON.stringify([{ id: 'IFS-2026-1234', alumnoNombre: 'Balbi, Paz', archivosParaLaboratorio: [] }, { id: 'IFS-2026-9001', alumnoNombre: 'Demo', archivosParaLaboratorio: [] }]));
    expect(obtenerPedidosGuardados().map((p) => p.id)).toEqual(['IFS-2026-1234']);
  });
});
