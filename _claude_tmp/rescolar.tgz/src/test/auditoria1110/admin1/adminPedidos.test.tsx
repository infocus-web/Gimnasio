// Auditoría 11/10 (admin1): regresiones del panel del fotógrafo (Pedidos y Códigos). ADM-2, ADM-3, ADM-4, ADM-11.
import { act, fireEvent, render, screen, waitFor, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { beforeEach, describe, expect, it, vi } from 'vitest';
import type { PedidoEscolarCompleto } from '../../../services/pedidosLabService';

const m = vi.hoisted(() => ({
  obtenerPedidos: vi.fn(),
  actualizarEstado: vi.fn(),
  organizar: vi.fn(),
  actualizarCodigo: vi.fn(),
  usarReal: false,
}));

vi.mock('../../../services/adminAuthService', () => ({
  loginAdminConServidor: async () => ({ success: true }),
  verificarSesionAdmin: async () => true,
  cerrarSesionAdminYBorrarDatos: () => undefined,
  obtenerTokenAdmin: () => 'token-admin',
  actualizarEstadoPedidoAdmin: (...a: unknown[]) => m.actualizarEstado(...a),
  fetchAdminAutenticado: (url: string, init?: RequestInit) => fetch(url, init),
}));

vi.mock('../../../services/pedidosLabService', async (importOriginal) => {
  const real = await importOriginal<typeof import('../../../services/pedidosLabService')>();
  return {
    ...real,
    obtenerPedidosAdminDesdeSupabase: (...a: unknown[]) =>
      m.usarReal ? (real.obtenerPedidosAdminDesdeSupabase as any)(...a) : m.obtenerPedidos(...a),
    organizarPedidoAdmin: (...a: unknown[]) => m.organizar(...a),
  };
});

vi.mock('../../../services/colegiosService', () => ({
  useColegiosLista: () => ({ colegios: [{ id: 'c1', nombre: 'Colegio Uno', localidad: '', zona: 'CABA', codigoAcceso: 'X' }], agregarColegio: vi.fn(), editarColegio: vi.fn(), borrarColegio: vi.fn() }),
  obtenerTokensPadronAdmin: async () => ({}),
  regenerarTokenPadronAdmin: async () => ({ success: false }),
  obtenerAlumnosNominaAdmin: async () => [{ id: 'a1', nombre: 'Ana Pérez', grado: '1° grado', turno: 'Mañana', division: 'A', colegio_id: 'c1' }],
}));
vi.mock('../../../services/inscripcionesService', () => ({ obtenerInscripcionesAdmin: async () => [], determinarCodigoParaInscripcion: () => '' }));
vi.mock('../../../services/solicitudesCodigoService', () => ({ obtenerSolicitudesCodigoAdmin: async () => [] }));
vi.mock('../../../services/codigosSeccionService', () => ({
  obtenerCodigosSeccionAdmin: async () => [{ grado: '1° grado', turno: 'Mañana', division: 'A', codigo_secreto: 'VIEJO1' }],
  asegurarCodigoSeccionAdmin: async () => ({ success: false }),
  regenerarCodigoSeccionAdmin: async () => ({ success: false }),
  actualizarCodigoSeccionAdmin: (...a: unknown[]) => m.actualizarCodigo(...a),
}));
vi.mock('../../../services/emailService', () => ({ enviarFotosPorEmail: async () => ({ success: true }) }));
vi.mock('../../../components/AdminEstadoSistema', () => ({ default: () => null }));
vi.mock('../../../components/AdminResumenKitsSection', () => ({ default: () => null }));
vi.mock('../../../components/AdminCampanaPagoAnticipado', () => ({ default: () => null }));
vi.mock('../../../components/AdminInscriptosTab', () => ({ default: () => null }));
vi.mock('../../../components/AdminLaboratorioTab', () => ({ default: () => null }));

import AdminModal from '../../../components/AdminModal';

const base = (extra: Partial<PedidoEscolarCompleto>): PedidoEscolarCompleto =>
  ({
    id: 'IFS-2026-0001',
    supabaseId: '11111111-1111-1111-1111-111111111111',
    fecha: '10/10/2026 10:00',
    colegioId: 'c1',
    colegioNombre: 'Colegio Uno',
    cursoCodigo: 'GRADO1-ATM',
    grado: '1° grado',
    division: 'A',
    turno: 'Mañana',
    alumnoNumeroLista: 1,
    alumnoNombre: 'Ana Pérez',
    codigoAlumno: 'X',
    tutorNombre: 'Tutor',
    tutorTelefono: '',
    tutorEmail: 'tutor@x.com',
    kitId: 'kit-clasico',
    kitNombre: 'Kit',
    total: 30000,
    metodoPago: 'efectivo',
    estadoPago: 'pendiente',
    estadoEntrega: 'en_espera',
    fotosSeleccionadas: { individualId: 'i', grupalId: 'g' },
    archivosParaLaboratorio: [],
    linkDescargaHD: '',
    emailEnviado: false,
    ...extra,
  }) as PedidoEscolarCompleto;

function diferido<T>() {
  let resolver!: (v: T) => void;
  const promesa = new Promise<T>((r) => (resolver = r));
  return { promesa, resolver };
}

beforeEach(() => {
  vi.stubGlobal('ResizeObserver', class { observe() {} disconnect() {} unobserve() {} });
  m.usarReal = false;
  m.obtenerPedidos.mockReset();
  m.actualizarEstado.mockReset();
  m.organizar.mockReset();
  m.actualizarCodigo.mockReset();
});

describe('Pedidos: vistas', () => {
  it('ADM-4: un vencido sin comprobante archivado aparece en «Ver archivados» y se puede desarchivar', async () => {
    const vencidoArchivado = base({ estadoPago: 'rechazado', metodoPago: 'transferencia', transferenciaVencidaAt: '2026-10-10T10:00:00Z', archivado: true });
    m.obtenerPedidos.mockResolvedValue([vencidoArchivado]);
    render(<AdminModal isOpen onClose={() => {}} tabInicial="pedidos" />);
    await waitFor(() => expect(m.obtenerPedidos).toHaveBeenCalled());
    await userEvent.click(await screen.findByRole('button', { name: 'Ver archivados (1)' }));
    const tabla = screen.getByRole('table');
    expect(within(tabla).getByText('Ana Pérez')).toBeInTheDocument();
    expect(within(tabla).getByRole('button', { name: 'Desarchivar' })).toBeInTheDocument();
  });

  it('ADM-4: archivar desde Pedidos pide confirmación (si se cancela no se llama al servidor)', async () => {
    m.obtenerPedidos.mockResolvedValue([base({})]);
    const confirmar = vi.spyOn(window, 'confirm').mockReturnValue(false);
    render(<AdminModal isOpen onClose={() => {}} tabInicial="pedidos" />);
    await userEvent.click(await screen.findByRole('button', { name: 'Archivar' }));
    expect(confirmar).toHaveBeenCalled();
    expect(m.organizar).not.toHaveBeenCalled();
  });

  it('ADM-3: con la sesión vencida (401) vuelve a pedir el PIN, sin mostrar la copia vieja como "sin conexión"', async () => {
    m.usarReal = true;
    localStorage.setItem('infocus_pedidos_escolares_v1', JSON.stringify([base({ estadoPago: 'pendiente' })]));
    vi.stubGlobal('fetch', vi.fn(async () => ({ ok: false, status: 401, json: async () => ({ success: false, error: 'Sesión vencida' }) })));
    render(<AdminModal isOpen onClose={() => {}} tabInicial="pedidos" />);
    expect(await screen.findByText(/Tu sesión venció/)).toBeInTheDocument();
    expect(screen.getByPlaceholderText(/PIN/)).toBeInTheDocument();
    expect(screen.queryByText(/Sin conexión: mostrando datos guardados/)).not.toBeInTheDocument();
    expect(screen.queryByText('Ana Pérez')).not.toBeInTheDocument();
  });
});

describe('Pedidos: aprobar pago', () => {
  it('ADM-2: una recarga vieja que contesta tarde no pisa el pedido ya aprobado', async () => {
    const pendiente = base({});
    const recargaVieja = diferido<PedidoEscolarCompleto[]>();
    m.obtenerPedidos
      .mockResolvedValueOnce([pendiente]) // carga inicial
      .mockImplementationOnce(() => recargaVieja.promesa) // recarga por el cambio de pestaña (leyó antes de la aprobación)
      .mockResolvedValue([base({ estadoPago: 'aprobado', estadoEntrega: 'en_laboratorio' })]); // recarga nueva
    const aprobacion = diferido<{ success: boolean; linkDescargaHD?: string }>();
    m.actualizarEstado.mockImplementation(() => aprobacion.promesa);

    render(<AdminModal isOpen onClose={() => {}} tabInicial="pedidos" />);
    await userEvent.click(await screen.findByRole('button', { name: 'Aprobar Pago' }));
    await userEvent.click(screen.getByRole('button', { name: /Buscar alumno/ }));
    await userEvent.click(screen.getByRole('button', { name: /Pedidos \(/ }));
    await act(async () => aprobacion.resolver({ success: true, linkDescargaHD: 'https://zip' }));
    await act(async () => recargaVieja.resolver([pendiente]));
    await waitFor(() => expect(screen.getByText('✓ Aprobado')).toBeInTheDocument());
    expect(screen.queryByRole('button', { name: 'Aprobar Pago' })).not.toBeInTheDocument();
    expect(m.actualizarEstado).toHaveBeenCalledTimes(1);
  });
});

describe('Códigos y difusión', () => {
  it('ADM-11: cambiar el código de una sección pide confirmación; si se cancela, no se guarda y vuelve el anterior', async () => {
    m.obtenerPedidos.mockResolvedValue([]);
    m.actualizarCodigo.mockResolvedValue({ success: true, codigo: 'NUEVO2' });
    const confirmar = vi.spyOn(window, 'confirm').mockReturnValueOnce(false).mockReturnValueOnce(true);
    render(<AdminModal isOpen onClose={() => {}} tabInicial="codigos" />);
    const campo = (await screen.findByDisplayValue('VIEJO1')) as HTMLInputElement;
    fireEvent.change(campo, { target: { value: 'VIEJO1X' } });
    fireEvent.blur(campo);
    expect(confirmar).toHaveBeenCalledTimes(1);
    expect(m.actualizarCodigo).not.toHaveBeenCalled();
    expect(campo.value).toBe('VIEJO1');
    fireEvent.change(campo, { target: { value: 'NUEVO2' } });
    fireEvent.blur(campo);
    await waitFor(() => expect(m.actualizarCodigo).toHaveBeenCalledWith('c1', '1° grado', 'Mañana', 'A', 'NUEVO2'));
  });
});
