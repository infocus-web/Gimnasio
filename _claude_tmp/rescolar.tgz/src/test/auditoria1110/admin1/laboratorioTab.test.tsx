// Auditoría 11/10 (admin1): regresiones de la pestaña Laboratorio del panel del fotógrafo (ADM-5 a ADM-9).
import { act, fireEvent, render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import * as XLSX from 'xlsx';
import { beforeEach, describe, expect, it, vi } from 'vitest';
import { construirPedidoCompletoDesdeFila, type PedidoEscolarCompleto } from '../../../services/pedidosLabService';

const m = vi.hoisted(() => ({
  enviarFotosPorEmail: vi.fn(),
  generarZipHDAdmin: vi.fn(),
  releer: vi.fn(async (p: any[]) => ({ pendientes: p, yaEnviados: [] as string[] })),
  fetchAdmin: vi.fn(),
  blobs: [] as { blob: Blob; nombre: string }[],
  libros: [] as { wb: any; nombre: string }[],
}));

vi.mock('../../../services/emailService', () => ({
  enviarFotosPorEmail: (...a: unknown[]) => m.enviarFotosPorEmail(...a),
  consultarEstadoResend: async () => null,
  enviarEmailPruebaResend: async () => ({ success: true }),
  enviarActualizacionPedidos: async () => ({ success: true, enviados: 0, fallidos: 0 }),
  releerPedidosHDPendientes: (p: any[]) => m.releer(p),
}));
vi.mock('../../../services/adminAuthService', () => ({
  fetchAdminAutenticado: (...a: unknown[]) => m.fetchAdmin(...a),
  obtenerTokenAdmin: () => 'tok',
}));
vi.mock('../../../services/pedidosLabService', async (importOriginal) => ({
  ...(await importOriginal<typeof import('../../../services/pedidosLabService')>()),
  generarZipHDAdmin: (...a: unknown[]) => m.generarZipHDAdmin(...a),
}));
vi.mock('../../../services/zipLaboratorio', async (importOriginal) => ({
  ...(await importOriginal<typeof import('../../../services/zipLaboratorio')>()),
  descargarBlobComoArchivo: (blob: Blob, nombre: string) => m.blobs.push({ blob, nombre }),
}));
vi.mock('../../../services/excelDownloadHelper', async (importOriginal) => ({
  ...(await importOriginal<typeof import('../../../services/excelDownloadHelper')>()),
  descargarLibroExcel: (wb: unknown, nombre: string) => (m.libros.push({ wb, nombre }), true),
}));

import AdminLaboratorioTab from '../../../components/AdminLaboratorioTab';

const fotos = [
  { id: 'i1', categoria: 'individual', url: '/api/admin/fotos/i1/original', thumbnail: 't', titulo: '' },
  { id: 'g1', categoria: 'grupal', url: '/api/admin/fotos/g1/original', thumbnail: 't', titulo: '' },
] as any;

const pedido = (n: number, extra: Record<string, unknown> = {}): PedidoEscolarCompleto =>
  ({
    ...construirPedidoCompletoDesdeFila(
      {
        id: `0000000${n}-0000-0000-0000-000000000000`,
        pedido_friendly_id: `IFS-2026-000${n}`,
        estado: 'pagado',
        tipo_kit: 'impreso_digital',
        colegio_nombre: 'Colegio Uno',
        curso_codigo: 'GRADO1-ATM',
        grado: '1° grado',
        division: 'A',
        turno: 'Mañana',
        alumno_nombre: n === 1 ? 'Pérez, Ana' : 'Gómez, Beto',
        alumno_numero_lista: n,
        codigo_alumno: `GRADO1_ATM_0${n}_${n === 1 ? 'PEREZ_ANA' : 'GOMEZ_BETO'}`,
        fotos_seleccionadas: { individualId: 'i1', grupalId: 'g1' },
        familias: { nombre: 'Tutor', email: `t${n}@x.com` },
      },
      fotos
    ),
    ...extra,
  }) as PedidoEscolarCompleto;

function diferido<T>() {
  let resolver!: (v: T) => void;
  const promesa = new Promise<T>((r) => (resolver = r));
  return { promesa, resolver };
}

const montar = (pedidos: PedidoEscolarCompleto[]) => render(<AdminLaboratorioTab pedidos={pedidos} onActualizarPedidos={() => {}} />);

beforeEach(() => {
  m.blobs.length = 0;
  m.libros.length = 0;
  m.enviarFotosPorEmail.mockReset();
  m.generarZipHDAdmin.mockReset();
  m.fetchAdmin.mockReset();
});

describe('Laboratorio (panel del fotógrafo)', () => {
  it('ADM-6: "Email HD" se bloquea mientras envía: dos clics = un solo correo', async () => {
    const correo = diferido<{ success: boolean }>();
    m.enviarFotosPorEmail.mockImplementation(() => correo.promesa);
    montar([pedido(1, { linkDescargaHD: 'https://zip', emailEnviado: true })]);
    const boton = screen.getAllByTitle('Reenviar enlace Ultra HD por email a t1@x.com')[1];
    await userEvent.click(boton);
    expect(boton).toBeDisabled();
    fireEvent.click(boton);
    expect(m.enviarFotosPorEmail).toHaveBeenCalledTimes(1);
    await act(async () => correo.resolver({ success: true }));
    await waitFor(() => expect(boton).toBeEnabled());
  });

  it('ADM-7: "Reintentar todos" avisa cuántos fallaron (sin ✅) si no se pudo mandar ninguno', async () => {
    m.generarZipHDAdmin.mockResolvedValue({ success: false, error: 'Sesión vencida' });
    m.enviarFotosPorEmail.mockResolvedValue({ success: false, error: 'Sesión vencida' });
    montar([pedido(1), pedido(2)]);
    await userEvent.click(screen.getByRole('button', { name: /Reintentar los 2/ }));
    expect(await screen.findByText(/Se enviaron 0 de 2 correos HD; 2 fallaron/)).toBeInTheDocument();
    expect(screen.queryByText(/✅ Reintento terminado/)).not.toBeInTheDocument();
  });

  it('ADM-7: si salen todos, el aviso es ✅', async () => {
    m.generarZipHDAdmin.mockResolvedValue({ success: true, linkDescargaHD: 'https://zip' });
    m.enviarFotosPorEmail.mockResolvedValue({ success: true });
    montar([pedido(1)]);
    await userEvent.click(screen.getByRole('button', { name: /Reintentar los 1/ }));
    expect(await screen.findByText(/✅ Reintento terminado: se enviaron los 1 correo HD/)).toBeInTheDocument();
  });

  it('14/10: «Reintentar» relee los pedidos antes del bucle: el que ya tenía el link enviado no se repite y el resto va sin «en breve»', async () => {
    m.releer.mockImplementationOnce(async (p: any[]) => ({ pendientes: [p[1]], yaEnviados: [p[0].id] }));
    m.generarZipHDAdmin.mockResolvedValue({ success: false, error: 'sin fotos' });
    m.enviarFotosPorEmail.mockResolvedValue({ success: false, error: 'Todavía no hay .zip HD' });
    montar([pedido(1), pedido(2)]);
    await userEvent.click(screen.getByRole('button', { name: /Reintentar los 2/ }));
    expect(await screen.findByText(/Se enviaron 0 de 1 correos HD; 1 fallaron/)).toBeInTheDocument();
    expect(m.enviarFotosPorEmail).toHaveBeenCalledTimes(1);
    expect(m.enviarFotosPorEmail.mock.calls[0][0]).toMatchObject({ alumnoNombre: 'Gómez, Beto', soloConLink: true, forzar: false });
  });

  it('14/10: el botón suelto «Reenviar Email HD» es un reenvío a propósito (forzar)', async () => {
    m.enviarFotosPorEmail.mockResolvedValue({ success: true });
    montar([{ ...pedido(1), linkDescargaHD: 'https://zip', emailEnviado: true } as PedidoEscolarCompleto]);
    await userEvent.click(screen.getAllByTitle(/Reenviar enlace Ultra HD por email/)[0]);
    await waitFor(() => expect(m.enviarFotosPorEmail).toHaveBeenCalled());
    expect(m.enviarFotosPorEmail.mock.calls[0][0]).toMatchObject({ forzar: true, soloConLink: false });
  });

  it('ADM-5: el QR de un pedido anterior que contesta tarde no se muestra en el de otro alumno', async () => {
    const qrAna = diferido<Response>();
    const qrBeto = diferido<Response>();
    m.fetchAdmin.mockImplementation((url: string) => (url.includes('00000001-') ? qrAna.promesa : qrBeto.promesa));
    vi.stubGlobal('URL', Object.assign(URL, { createObjectURL: (b: Blob & { etiqueta?: string }) => `blob:${b.etiqueta}`, revokeObjectURL: () => {} }));
    montar([pedido(1), pedido(2)]);
    const botonesQr = screen.getAllByTitle('Ver / descargar el QR para pegar en el sobre del laboratorio');
    await userEvent.click(botonesQr[2]);
    await userEvent.click(screen.getAllByRole('button').find((b) => b.querySelector('svg.lucide-x') && b.closest('.max-w-xs'))!);
    await userEvent.click(botonesQr[3]);
    const blob = (etiqueta: string) => Object.assign(new Blob(['png']), { etiqueta });
    await act(async () => qrBeto.resolver({ ok: true, blob: async () => blob('QR-BETO') } as unknown as Response));
    await act(async () => qrAna.resolver({ ok: true, blob: async () => blob('QR-ANA') } as unknown as Response));
    const img = await screen.findByAltText('QR del pedido de Gómez, Beto');
    expect(img.getAttribute('src')).toBe('blob:QR-BETO');
  });

  it('ADM-8: bajar el ZIP de un alumno "En espera" no baja un ZIP vacío y lo avisa', async () => {
    montar([pedido(1, { enEspera: true })]);
    await userEvent.click(screen.getByRole('button', { name: /En espera \(1\)/ }));
    await userEvent.click(screen.getAllByTitle('Descargar ZIP renombrado de este alumno')[1]);
    expect(await screen.findByText(/está en espera o archivado, no entra al ZIP/)).toBeInTheDocument();
    expect(m.blobs).toHaveLength(0);
  });

  it('ADM-9: la planilla Excel nombra los mismos archivos que el ZIP y deja afuera lo que el ZIP excluye', async () => {
    const p = pedido(1);
    const enLote = { ...pedido(2), loteLabId: 'l1' } as PedidoEscolarCompleto;
    montar([p, enLote]);
    await userEvent.click(screen.getByRole('button', { name: /^Excel$/ }));
    await waitFor(() => expect(m.libros).toHaveLength(1));
    const filas = XLSX.utils.sheet_to_json<Record<string, string>>(m.libros[0].wb.Sheets['Planilla de Control']);
    expect(filas).toHaveLength(1);
    expect(filas[0]['Código Cliente (Archivo Minilab)']).toBe('GRADO1_ATM_ANA_PEREZ');
    expect(filas[0]['Ubicación 15x21']).toBe('15x21/GRADO1_ATM_ANA_PEREZ.jpg');
    expect(filas[0]['Ubicación 20x30']).toBe('20x30/GRADO1_ATM_ANA_PEREZ.jpg');
    expect(p.archivosParaLaboratorio.map((a) => `${a.tamanoImpresion}/${a.nombreArchivoLab}`)).toEqual([filas[0]['Ubicación 15x21'], filas[0]['Ubicación 20x30']]);
  });
});
