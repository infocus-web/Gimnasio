// Auditoría 14/10/2026 (panel, navegador): procesos en curso y recarga por versión nueva, borradores que se
// guardan solos, claves de envío y relecturas antes de decir «no se pudo».
import { act, render, renderHook, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';

function respuesta(status: number, cuerpo: unknown): Response {
  return { ok: status >= 200 && status < 300, status, json: async () => cuerpo, headers: new Headers() } as unknown as Response;
}
const urlDe = (u: RequestInfo | URL) => (typeof u === 'string' ? u : u.toString());

afterEach(() => {
  vi.unstubAllGlobals();
  vi.useRealTimers();
  vi.restoreAllMocks();
});

describe('14: procesos en curso', () => {
  it('mientras hay uno, el navegador pregunta antes de cerrar; al terminar el último, deja de preguntar y avisa', async () => {
    const { iniciarProceso, hayProcesoEnCurso, cuandoNoHayaProcesos } = await import('../../../utils/procesoEnCurso');
    const agregar = vi.spyOn(window, 'addEventListener');
    const sacar = vi.spyOn(window, 'removeEventListener');
    const fin1 = iniciarProceso('a');
    const fin2 = iniciarProceso('b');
    expect(hayProcesoEnCurso()).toBe(true);
    expect(agregar.mock.calls.filter(([t]) => t === 'beforeunload')).toHaveLength(1);
    const alTerminar = vi.fn();
    cuandoNoHayaProcesos(alTerminar);
    fin1();
    fin1(); // dos veces no pasa nada
    expect(alTerminar).not.toHaveBeenCalled();
    fin2();
    expect(hayProcesoEnCurso()).toBe(false);
    expect(alTerminar).toHaveBeenCalledTimes(1);
    expect(sacar.mock.calls.filter(([t]) => t === 'beforeunload')).toHaveLength(1);
  });

  it('la recarga por versión nueva espera a que termine el proceso', async () => {
    const originalLocation = window.location;
    const reload = vi.fn();
    Object.defineProperty(window, 'location', { configurable: true, value: { href: 'https://x/', reload, replace: vi.fn() } });
    try {
      vi.resetModules();
      const { iniciarProceso } = await import('../../../utils/procesoEnCurso');
      const { recargarPorVersionNueva, recargaEnCurso } = await import('../../../utils/recargaTrasDeploy');
      try { sessionStorage.removeItem('recarga_tras_deploy_at'); } catch { /* sin storage */ }
      const fin = iniciarProceso('Envío de emails');
      expect(recargarPorVersionNueva()).toBe(true);
      expect(recargaEnCurso()).toBe(true);
      expect(reload).not.toHaveBeenCalled();
      fin();
      expect(reload).toHaveBeenCalledTimes(1);
    } finally {
      Object.defineProperty(window, 'location', { configurable: true, value: originalLocation });
      vi.resetModules();
    }
  });
});

describe('15: useBorradorAdmin', () => {
  it('trae el borrador guardado, guarda ~800 ms después de escribir y lo borra al enviar', async () => {
    vi.useFakeTimers({ shouldAdvanceTime: true });
    const fetchMock = vi.fn(async (input: RequestInfo | URL, init?: RequestInit) => {
      if ((init?.method || 'GET') === 'GET') return respuesta(200, { success: true, contenido: 'lo que había escrito' });
      return respuesta(200, { success: true });
    });
    vi.stubGlobal('fetch', fetchMock);
    const { useBorradorAdmin } = await import('../../../utils/useBorradorAdmin');
    const { result } = renderHook(() => useBorradorAdmin('consulta-c1', ''));
    await waitFor(() => expect(result.current[0]).toBe('lo que había escrito'));
    act(() => result.current[1]('nuevo texto'));
    expect(fetchMock.mock.calls.some(([, i]) => (i as RequestInit | undefined)?.method === 'PUT')).toBe(false);
    await act(async () => { vi.advanceTimersByTime(900); });
    const put = fetchMock.mock.calls.find(([, i]) => (i as RequestInit | undefined)?.method === 'PUT')!;
    expect(urlDe(put[0] as RequestInfo)).toBe('/api/admin/borradores/consulta-c1');
    expect(JSON.parse(String((put[1] as RequestInit).body))).toEqual({ contenido: 'nuevo texto' });
    await act(async () => { await result.current[2].borrar(); });
    expect(fetchMock.mock.calls.some(([, i]) => (i as RequestInit | undefined)?.method === 'DELETE')).toBe(true);
  });

  it('si el servidor no responde, la pantalla sigue andando (sin borrador)', async () => {
    vi.stubGlobal('fetch', vi.fn(async () => { throw new TypeError('Failed to fetch'); }));
    const { useBorradorAdmin } = await import('../../../utils/useBorradorAdmin');
    const { result } = renderHook(() => useBorradorAdmin('x', 'inicial'));
    await waitFor(() => expect(result.current[2].cargado).toBe(true));
    act(() => result.current[1]('escrito'));
    expect(result.current[0]).toBe('escrito');
  });

  it('al cambiar de pestaña (desmontar) guarda lo pendiente al toque', async () => {
    vi.useFakeTimers({ shouldAdvanceTime: true });
    const fetchMock = vi.fn(async () => respuesta(200, { success: true, contenido: null }));
    vi.stubGlobal('fetch', fetchMock);
    const { useBorradorAdmin } = await import('../../../utils/useBorradorAdmin');
    const { result, unmount } = renderHook(() => useBorradorAdmin('cancelaciones-notas', {} as Record<string, string>));
    await waitFor(() => expect(result.current[2].cargado).toBe(true));
    act(() => result.current[1]({ s1: 'motivo a medias' }));
    unmount();
    const put = fetchMock.mock.calls.find((c: any[]) => c[1]?.method === 'PUT') as any[] | undefined;
    expect(put && JSON.parse(String(put[1].body))).toEqual({ contenido: { s1: 'motivo a medias' } });
  });
});

describe('4: clave de envío', () => {
  it('el mismo texto lleva la misma clave; otro texto, otra; después de enviar, una nueva', async () => {
    const { useClaveEnvio } = await import('../../../utils/claveEnvio');
    const { result } = renderHook(() => useClaveEnvio());
    const a = result.current.claveParaEnviar('hola');
    expect(result.current.claveParaEnviar('hola')).toBe(a);
    expect(result.current.claveParaEnviar('hola!')).not.toBe(a);
    result.current.reiniciar();
    expect(result.current.claveParaEnviar('hola!')).toMatch(/^[A-Za-z0-9-]{8,64}$/);
  });
});

describe('1: publicar con la respuesta perdida', () => {
  it('relee las fotos: si quedaron publicadas, no dice «no se pudieron publicar»', async () => {
    vi.stubGlobal('fetch', vi.fn(async (input: RequestInfo | URL) => {
      if (urlDe(input) === '/api/admin/fotos/publicar') throw new TypeError('Failed to fetch');
      return respuesta(200, { success: true, fotos: [{ id: 'f1', publicada_at: '2026-10-14T10:00:00Z' }, { id: 'f2', publicada_at: '2026-10-14T10:00:00Z' }] });
    }));
    const { publicarFotosAdmin } = await import('../../../services/fotosSubidasService');
    const r = await publicarFotosAdmin({ ids: ['f1', 'f2'] });
    expect(r).toMatchObject({ success: true, publicadas: 2 });
    expect(r.warning).toMatch(/Reenviar aviso/);
  });

  it('si de verdad no se publicaron, sí avisa el error', async () => {
    vi.stubGlobal('fetch', vi.fn(async (input: RequestInfo | URL) => {
      if (urlDe(input) === '/api/admin/fotos/publicar') throw new TypeError('Failed to fetch');
      return respuesta(200, { success: true, fotos: [{ id: 'f1', publicada_at: null }] });
    }));
    const { publicarFotosAdmin } = await import('../../../services/fotosSubidasService');
    expect(await publicarFotosAdmin({ ids: ['f1'] })).toMatchObject({ success: false, publicadas: 0 });
  });

  it('«Reenviar aviso a las familias» confirma, llama al servidor y muestra el resultado', async () => {
    const fetchMock = vi.fn(async () => respuesta(200, { success: true, emailsEnviados: 3 }));
    vi.stubGlobal('fetch', fetchMock);
    vi.spyOn(window, 'confirm').mockReturnValue(true);
    const { default: ReenviarAvisoFotos } = await import('../../../components/ReenviarAvisoFotos');
    render(<ReenviarAvisoFotos colegioId="col-1" codigoCurso="GRADO1-ATM" nombreCurso="1° grado · A" />);
    await userEvent.click(screen.getByRole('button', { name: /reenviar aviso a las familias/i }));
    expect(await screen.findByRole('status')).toHaveTextContent('se avisó a 3 familia(s)');
    const [url, init] = fetchMock.mock.calls[0] as unknown as [string, RequestInit];
    expect(url).toBe('/api/admin/fotos/reenviar-aviso');
    expect(JSON.parse(String(init.body))).toEqual({ colegioId: 'col-1', codigoCurso: 'GRADO1-ATM' });
  });
});

describe('9: aprobar un pago con la respuesta perdida', () => {
  it('relee el pedido: si ya figura pagado, se toma como confirmado (con su link HD)', async () => {
    vi.stubGlobal('fetch', vi.fn(async (input: RequestInfo | URL) => {
      if (urlDe(input).endsWith('/estado')) throw new DOMException('timeout', 'AbortError');
      return respuesta(200, { success: true, pedido: { estado: 'pagado', linkDescargaHD: 'https://zip' } });
    }));
    const { actualizarEstadoPedidoAdmin } = await import('../../../services/adminAuthService');
    expect(await actualizarEstadoPedidoAdmin('p1', { estadoPago: 'aprobado' })).toMatchObject({ success: true, confirmadoAlReleer: true, linkDescargaHD: 'https://zip' });
  });

  it('sesión vencida: lo dice (no «revisá tu conexión»)', async () => {
    vi.stubGlobal('fetch', vi.fn(async () => respuesta(401, { success: false })));
    const { actualizarEstadoPedidoAdmin } = await import('../../../services/adminAuthService');
    const r = await actualizarEstadoPedidoAdmin('p1', { estadoPago: 'aprobado' });
    expect(r).toMatchObject({ success: false, codigo: 'SESION_VENCIDA' });
    expect(r.error).toMatch(/sesión del panel venció/);
  });
});

describe('2: avisos de etapa', () => {
  const dest = [{ pedidoId: 'p1', to: 'f@x.com', tutorNombre: 'F', alumnoNombre: 'Ana', colegioNombre: 'Col' }];
  it('`reenvio` sólo viaja si se pide, y los ya avisados se informan', async () => {
    const fetchMock = vi.fn(async () => respuesta(200, { success: true, enviados: 0, omitidos: 0, yaAvisados: 1, restantes: [] }));
    vi.stubGlobal('fetch', fetchMock);
    const { enviarActualizacionPedidos } = await import('../../../services/emailService');
    const r = await enviarActualizacionPedidos('listo_retiro', dest);
    expect(JSON.parse(String((fetchMock.mock.calls[0] as any)[1].body)).reenvio).toBeUndefined();
    expect(r.yaAvisados).toBe(1);
    await enviarActualizacionPedidos('listo_retiro', dest, undefined, { reenvio: true });
    expect(JSON.parse(String((fetchMock.mock.calls[1] as any)[1].body)).reenvio).toBe(true);
  });

  it('tras un corte de red relee los pedidos: los que ya quedaron en la etapa no siguen tildados', async () => {
    vi.stubGlobal('fetch', vi.fn(async (input: RequestInfo | URL) => {
      if (urlDe(input).includes('notificar-estado')) throw new TypeError('Failed to fetch');
      return respuesta(200, { success: true, pedido: { estadoLab: 'listo_retiro', fechaEnvioListoRetiro: '2026-10-14T10:00:00Z' } });
    }));
    const { enviarActualizacionPedidos } = await import('../../../services/emailService');
    const r = await enviarActualizacionPedidos('listo_retiro', dest);
    expect(r).toMatchObject({ success: false, restantes: [], yaAvisados: 1 });
    expect(r.resultados).toEqual([expect.objectContaining({ pedidoId: 'p1', estadoLab: 'listo_retiro' })]);
  });
});

describe('3: envío masivo de códigos', () => {
  beforeEach(() => vi.useRealTimers());
  it('14/10/2026: `yaEnviado` del servidor cuenta como «ya figuraba enviado», no como enviado ahora', async () => {
    let n = 0;
    vi.stubGlobal('fetch', vi.fn(async () => respuesta(200, ++n === 2 ? { success: true, yaEnviado: true } : { success: true })));
    const { enviarCodigosEnSerie, resumenEnvioMasivo } = await import('../../../components/inscriptosEnvioMasivo');
    const lista = [1, 2, 3].map((k) => ({ id: `i${k}`, email: `f${k}@x.com`, alumnoNombre: 'A', alumnoApellido: String(k) })) as any[];
    const r = await enviarCodigosEnSerie(lista, { seguir: () => true, pausaMs: 0 });
    expect(r).toMatchObject({ enviados: 2, yaFiguraban: 1, fallidos: [], cortado: false });
    const aviso = resumenEnvioMasivo(r, 3);
    expect(aviso.mensaje).toMatch(/a 2 de 3 familias/);
    expect(aviso.mensaje).toMatch(/1 ya figuraba enviado/);
    expect(aviso.titulo).not.toMatch(/Todos los emails/);
  });

  it('corta si se cerró la pestaña (seguir() = false) y no deja el proceso anotado', async () => {
    const fetchMock = vi.fn(async () => respuesta(200, { success: true }));
    vi.stubGlobal('fetch', fetchMock);
    const { enviarCodigosEnSerie } = await import('../../../components/inscriptosEnvioMasivo');
    const { hayProcesoEnCurso } = await import('../../../utils/procesoEnCurso');
    let seguir = true;
    const lista = [1, 2, 3].map((n) => ({ id: `i${n}`, email: `f${n}@x.com`, alumnoNombre: 'A', alumnoApellido: String(n) })) as any[];
    const r = await enviarCodigosEnSerie(lista, { seguir: () => seguir, onProgreso: () => { seguir = false; }, pausaMs: 0 });
    expect(r).toMatchObject({ enviados: 1, cortado: true });
    expect(fetchMock).toHaveBeenCalledTimes(1);
    expect(hayProcesoEnCurso()).toBe(false);
  });
});

describe('8: cancelaciones', () => {
  it('sin `emailEnviado` del servidor no dice «la familia recibió el email»', async () => {
    const solicitud = { id: 's1', created_at: new Date().toISOString(), codigo: 'ARR-1', pedido_ref: 'IFS-1', nombre: 'F', email: 'f@x.com', motivo: null, estado: 'nueva', nota_admin: null, atendida_at: null, pedidos: null };
    vi.stubGlobal('fetch', vi.fn(async (input: RequestInfo | URL) => {
      const url = urlDe(input);
      if (url.endsWith('/resolver')) return respuesta(200, { success: true });
      if (url.includes('/api/admin/borradores/')) return respuesta(200, { success: true, contenido: null });
      return respuesta(200, { success: true, solicitudes: [solicitud] });
    }));
    vi.spyOn(window, 'confirm').mockReturnValue(true);
    const { default: AdminCancelacionesTab } = await import('../../../components/AdminCancelacionesTab');
    render(<AdminCancelacionesTab />);
    await userEvent.click(await screen.findByRole('button', { name: /^aprobar/i }));
    expect(await screen.findByText(/el email a la familia no se pudo confirmar/i)).toBeInTheDocument();
    expect(screen.queryByText(/La familia recibió el email/)).not.toBeInTheDocument();
  });
});

describe('7: archivar desde una lista vieja', () => {
  it('manda el estado que se veía y, si la familia escribió de nuevo (409), avisa para recargar', async () => {
    const fetchMock = vi.fn(async () => respuesta(409, { success: false, error: 'La familia escribió de nuevo: revisá su mensaje antes de cambiar el estado.' }));
    vi.stubGlobal('fetch', fetchMock);
    const { actualizarEstadoConsultaFamiliaAdmin, ConsultaCambiadaError } = await import('../../../services/consultasFamiliasService');
    await expect(actualizarEstadoConsultaFamiliaAdmin('c1', 'archivada', 'en_proceso')).rejects.toBeInstanceOf(ConsultaCambiadaError);
    expect(JSON.parse(String((fetchMock.mock.calls[0] as any)[1].body))).toEqual({ estado: 'archivada', estadoAnterior: 'en_proceso' });
  });
});
