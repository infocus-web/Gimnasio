// Auditoría 11/10 (FRO-9): si el servidor rechaza un reintento, se sigue viendo que el comprobante llegó.
import { fireEvent, render, screen, waitFor } from '@testing-library/react';
import { afterEach, describe, expect, it, vi } from 'vitest';
import SubirComprobante from '../../../components/SubirComprobante';

afterEach(() => vi.unstubAllGlobals());

describe('FRO: SubirComprobante', () => {
  it('"Me equivoqué de archivo" + 429 del servidor (2 min): sigue "Recibimos tu comprobante" con el aviso', async () => {
    vi.stubGlobal(
      'fetch',
      vi.fn(async (_u: string, init?: RequestInit) => {
        if (init?.method === 'POST') {
          return new Response(JSON.stringify({ success: false, error: 'Ya recibimos un comprobante hace un momento.' }), { status: 429 });
        }
        return new Response(JSON.stringify({ success: true, subido: true, fecha: '2026-10-11T10:00:00Z' }));
      })
    );
    const { container } = render(<SubirComprobante pedidoId="11111111-1111-1111-1111-111111111111" codigo="AAAA-1111" />);
    expect(await screen.findByText(/recibimos tu comprobante/i)).toBeInTheDocument();
    const input = container.querySelector('input[type=file]') as HTMLInputElement;
    const pdf = new File(['%PDF-1.4 hola'], 'comprobante.pdf', { type: 'application/pdf' });
    fireEvent.change(input, { target: { files: [pdf] } });
    await waitFor(() => expect(screen.getByText(/ya recibimos un comprobante hace un momento/i)).toBeInTheDocument());
    expect(screen.getByText(/recibimos tu comprobante/i)).toBeInTheDocument();
    expect(screen.queryByText(/último paso: subí el comprobante/i)).toBeNull();
  });
});
