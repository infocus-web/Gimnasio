// Auditoría 11/10 (FRO-14): el CSV de la campaña respeta las comas entre comillas.
import { describe, expect, it } from 'vitest';
import { parsearCsvDestinatarios } from '../../../services/zohoCampanaService';

describe('FRO: CSV de campaña Zoho', () => {
  it('"Colegio San José, Sede Norte" no corre las columnas', () => {
    const csv = 'institucion,localidad,email\n"Colegio San José, Sede Norte",Pilar,direccion@sanjose.edu.ar';
    const [d] = parsearCsvDestinatarios(csv);
    expect(d.institucion).toBe('Colegio San José, Sede Norte');
    expect(d.localidad_partido).toBe('Pilar');
    expect(d.email).toBe('direccion@sanjose.edu.ar');
  });
});
