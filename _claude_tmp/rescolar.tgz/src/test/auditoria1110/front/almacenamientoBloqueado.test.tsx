// Auditoría 11/10 (FRO-1): con el almacenamiento del navegador bloqueado la home sigue funcionando.
import { render, screen } from '@testing-library/react';
import { afterEach, describe, expect, it, vi } from 'vitest';

describe('FRO: sessionStorage bloqueado (Chrome "bloquear todas las cookies")', () => {
  const original = Object.getOwnPropertyDescriptor(window, 'sessionStorage')!;
  afterEach(() => {
    Object.defineProperty(window, 'sessionStorage', original);
    vi.unstubAllGlobals();
  });

  it('Hero se muestra (no cae en "Algo salió mal") aunque leer sessionStorage tire', async () => {
    vi.stubGlobal('fetch', vi.fn(async () => new Response(JSON.stringify({ success: true, colegios: [] }))));
    Object.defineProperty(window, 'sessionStorage', {
      configurable: true,
      get() {
        throw new DOMException("Failed to read the 'sessionStorage' property from 'Window': Access is denied for this document.", 'SecurityError');
      },
    });
    vi.spyOn(console, 'error').mockImplementation(() => {});
    const { default: ErrorBoundary } = await import('../../../components/ErrorBoundary');
    const { default: Hero } = await import('../../../components/Hero');
    render(
      <ErrorBoundary variante="pagina">
        <Hero onOpenFamilias={() => {}} />
      </ErrorBoundary>
    );
    expect(screen.queryByText('Algo salió mal')).toBeNull();
    expect(screen.getByText(/Ver mis fotos/i)).toBeInTheDocument();
  });
});
