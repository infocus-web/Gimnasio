// Auditoría 11/10 (FRO-3): el plazo de 10 días se cuenta desde el pago hasta la fecha de la solicitud.
import { render, screen } from '@testing-library/react';
import { afterEach, describe, expect, it, vi } from 'vitest';

const DIA = 24 * 60 * 60 * 1000;
const compra = new Date('2026-10-01T12:00:00Z');
const solicitud = new Date(compra.getTime() + 9 * DIA); // día 9: dentro del plazo legal
const hoy = new Date(compra.getTime() + 12 * DIA); // Pablo la mira 3 días después

vi.mock('../../../services/adminAuthService', () => ({
  fetchAdminAutenticado: vi.fn(async () =>
    new Response(
      JSON.stringify({
        success: true,
        solicitudes: [
          {
            id: 's1',
            created_at: solicitud.toISOString(),
            codigo: 'ARR-1',
            pedido_ref: 'IFS-2026-1',
            nombre: 'Ana',
            email: 'a@x.com',
            motivo: null,
            estado: 'nueva',
            nota_admin: null,
            atendida_at: null,
            pedidos: {
              id: 'p1', pedido_friendly_id: 'IFS-2026-1', estado: 'pagado', total: 15000, metodo_pago: 'transferencia', mp_payment_id: null,
              kit_nombre: 'Solo Digital HD', alumno_nombre: 'X', colegio_nombre: 'C', seleccion_pendiente: true, email_enviado: false,
              created_at: compra.toISOString(),
            },
          },
        ],
      })
    )
  ),
}));

describe('FRO: cancelaciones', () => {
  afterEach(() => vi.useRealTimers());
  it('una reserva pedida a tiempo (día 9) sigue "dentro del plazo" aunque se revise el día 12', async () => {
    vi.useFakeTimers({ toFake: ['Date'] });
    vi.setSystemTime(hoy);
    const { default: AdminCancelacionesTab } = await import('../../../components/AdminCancelacionesTab');
    render(<AdminCancelacionesTab />);
    expect(await screen.findByText('Corresponde devolver el total')).toBeInTheDocument();
    expect(screen.queryByText('La pidió pasados los 10 días del pago')).toBeNull();
  });
});
