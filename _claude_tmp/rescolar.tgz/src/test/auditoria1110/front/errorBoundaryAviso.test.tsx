// Auditoría 11/10: «Ya le avisamos» sólo si el reporte automático salió de verdad.
import { render, screen, waitFor } from '@testing-library/react';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import ErrorBoundary from '../../../components/ErrorBoundary';
import { reiniciarReportesAutomaticos } from '../../../services/reporteErrores';

function Explota(): never {
  throw new Error('boom auditoria');
}

describe('ErrorBoundary', () => {
  beforeEach(() => {
    reiniciarReportesAutomaticos();
    vi.spyOn(console, 'error').mockImplementation(() => {});
  });
  afterEach(() => vi.unstubAllGlobals());

  it('si el reporte falla no dice "Ya le avisamos"', async () => {
    vi.stubGlobal('fetch', vi.fn(async () => new Response('{}', { status: 500 })));
    render(<ErrorBoundary><Explota /></ErrorBoundary>);
    await screen.findByText(/no se pudo enviar, reintentar/i);
    expect(screen.queryByText(/ya le avisamos/i)).toBeNull();
  });

  it('si el reporte salió, lo dice', async () => {
    vi.stubGlobal('fetch', vi.fn(async () => new Response(JSON.stringify({ success: true, codigo: 'ERR-9' }), { status: 201 })));
    render(<ErrorBoundary><Explota /></ErrorBoundary>);
    await waitFor(() => expect(screen.getByText(/ya le avisamos a nuestro equipo técnico/i)).toBeInTheDocument());
  });
});
