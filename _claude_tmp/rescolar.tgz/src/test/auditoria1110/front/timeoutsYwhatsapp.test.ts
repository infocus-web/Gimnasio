// Auditoría 11/10 (FRO-11 / FRO-10 / FRO-1): tiempos máximos, guardado de WhatsApp y token sin storage.
import { afterEach, describe, expect, it, vi } from 'vitest';

afterEach(() => {
  vi.useRealTimers();
  vi.unstubAllGlobals();
  vi.resetModules();
});

describe('pedidos con tiempo máximo', () => {
  it('el Botón de arrepentimiento no queda esperando para siempre', async () => {
    vi.useFakeTimers();
    vi.stubGlobal('fetch', vi.fn((_u: string, init?: RequestInit) => new Promise<Response>((_r, rej) => init?.signal?.addEventListener('abort', () => rej(new DOMException('a', 'AbortError'))))));
    const { enviarSolicitudArrepentimiento } = await import('../../../services/arrepentimientoService');
    const p = enviarSolicitudArrepentimiento({ pedido: 'IFS-1', nombre: 'A', email: 'a@x.com' });
    await vi.advanceTimersByTimeAsync(20_000);
    expect((await p).success).toBe(false);
  });

  it('el login del panel corta por tiempo', async () => {
    vi.useFakeTimers();
    vi.stubGlobal('fetch', vi.fn((_u: string, init?: RequestInit) => new Promise<Response>((_r, rej) => init?.signal?.addEventListener('abort', () => rej(new DOMException('a', 'AbortError'))))));
    const { loginAdminConServidor } = await import('../../../services/adminAuthService');
    const p = loginAdminConServidor('123');
    await vi.advanceTimersByTimeAsync(70_000);
    expect((await p).success).toBe(false);
  });
});

describe('token del panel con sessionStorage bloqueado', () => {
  const original = Object.getOwnPropertyDescriptor(window, 'sessionStorage')!;
  afterEach(() => Object.defineProperty(window, 'sessionStorage', original));
  it('obtenerTokenAdmin y cerrarSesionAdmin no tiran; se usa localStorage', async () => {
    localStorage.setItem('infocus_admin_session_token', 'tok');
    Object.defineProperty(window, 'sessionStorage', { configurable: true, get() { throw new DOMException('denied', 'SecurityError'); } });
    const { obtenerTokenAdmin, cerrarSesionAdmin } = await import('../../../services/adminAuthService');
    expect(obtenerTokenAdmin()).toBe('tok');
    expect(() => cerrarSesionAdmin()).not.toThrow();
    expect(obtenerTokenAdmin()).toBeNull();
  });
});

describe('configuración de WhatsApp', () => {
  it('si el servidor rechaza, supabaseOk es false (la pestaña lo muestra como error)', async () => {
    vi.stubGlobal('fetch', vi.fn(async () => new Response(JSON.stringify({ success: false, error: 'Sesión vencida' }), { status: 401 })));
    const { guardarConfiguracionWhatsApp } = await import('../../../services/configuracionService');
    const r = await guardarConfiguracionWhatsApp({ whatsappSolicitudCodigo: '1112345678' });
    expect(r.supabaseOk).toBe(false);
    expect(r.errorSupabase).toBe('Sesión vencida');
  });
});
