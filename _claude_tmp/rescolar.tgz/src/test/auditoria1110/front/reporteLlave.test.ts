// Auditoría 11/10 (FRO-2): el reporte de errores no manda la llave del pedido (`t`) ni datos del tutor.
import { beforeEach, describe, expect, it, vi } from 'vitest';

describe('reporte de errores sin secretos', () => {
  beforeEach(() => {
    vi.resetModules();
    window.history.replaceState(null, '', '/?mp_status=approved&grupo_pago_id=11111111-1111-1111-1111-111111111111&t=LLAVESECRETA123');
    localStorage.setItem(
      'infocus_familia_activa_v1',
      JSON.stringify({ padreNombre: 'Ana Tutora', email: 'ana@x.com', padreDni: '123', alumnoNombre: 'Sofi', grado: '2°' })
    );
  });

  it('ni la URL ni las llamadas fallidas llevan la llave; no viaja el nombre ni el email del tutor', async () => {
    const cuerpos: any[] = [];
    (window as any).fetch = vi.fn(async (input: RequestInfo | URL, init?: RequestInit) => {
      if (String(input).includes('/api/errores/reportar')) {
        cuerpos.push(JSON.parse(String(init?.body)));
        return new Response(JSON.stringify({ success: true, codigo: 'ERR-1' }), { status: 201 });
      }
      return new Response(JSON.stringify({ success: false, error: 'x' }), { status: 429 });
    });
    const mod = await import('../../../services/reporteErrores');
    mod.instalarCapturaDeErrores();
    const { urlEstadoPedido } = await import('../../../utils/accesoPedido');
    await window.fetch(urlEstadoPedido('11111111-1111-1111-1111-111111111111'));
    await mod.enviarReporteDeError({ mensaje: 'Falla al pagar' });
    expect(cuerpos).toHaveLength(1);
    const texto = JSON.stringify(cuerpos[0]);
    expect(texto).not.toContain('LLAVESECRETA123');
    expect(cuerpos[0].url).toContain('grupo_pago_id=');
    expect(JSON.stringify(cuerpos[0].detalle.eventos)).toContain('/api/pedidos/11111111-1111-1111-1111-111111111111/status');
    expect(texto).not.toContain('Ana Tutora');
    expect(texto).not.toContain('ana@x.com');
  });

  it('sinSecretos saca t, acceso y confirmar-acceso y deja el resto', async () => {
    const { sinSecretos } = await import('../../../services/reporteErrores');
    expect(sinSecretos('/api/x?t=1&pedido_id=2&acceso=3&confirmar-acceso=4')).toBe('/api/x?pedido_id=2');
  });
});
