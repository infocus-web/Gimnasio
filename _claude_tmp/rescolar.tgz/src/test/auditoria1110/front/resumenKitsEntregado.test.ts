// Auditoría 11/10 (FRO-7): la recaudación del Resumen de Kits incluye los pedidos entregados.
import { describe, expect, it, vi } from 'vitest';

vi.mock('../../../services/adminAuthService', () => ({
  fetchAdminAutenticado: vi.fn(async () =>
    new Response(
      JSON.stringify({
        success: true,
        pedidos: [
          { id: 'a', estado: 'pagado', total: 30000, tipo_kit: 'kit-clasico', familias: { email: 'a@x.com' } },
          { id: 'b', estado: 'entregado', total: 30000, tipo_kit: 'kit-clasico', familias: { email: 'b@x.com' } },
        ],
      })
    )
  ),
}));
vi.mock('../../../services/pedidosLabService', () => ({ obtenerPedidosGuardados: () => [] }));

describe('FRO: resumen de kits', () => {
  it('un pedido entregado (pagado y retirado) suma a la recaudación', async () => {
    const { extraerResumenKitsDesdeSupabase } = await import('../../../services/resumenKitsService');
    const r = await extraerResumenKitsDesdeSupabase();
    expect(r.totalPedidos).toBe(2);
    expect(r.totalRecaudado).toBe(60000);
  });
});
