// Auditoría 11/10 (FRO-6): sin sessionStorage la recarga tras deploy se hace una sola vez (marca en la URL).
import { afterEach, describe, expect, it, vi } from 'vitest';

describe('recarga tras deploy sin sessionStorage', () => {
  const original = Object.getOwnPropertyDescriptor(window, 'sessionStorage')!;
  const originalLocation = window.location;
  afterEach(() => {
    Object.defineProperty(window, 'sessionStorage', original);
    Object.defineProperty(window, 'location', { configurable: true, value: originalLocation });
  });

  it('recarga una vez con la marca y, ya marcada, no vuelve a recargar (sin bucle)', async () => {
    Object.defineProperty(window, 'sessionStorage', {
      configurable: true,
      get() {
        throw new DOMException('denied', 'SecurityError');
      },
    });
    let href = 'https://www.retratoescolar.com.ar/?pedido_id=1';
    const reload = vi.fn();
    const replace = vi.fn((u: string) => {
      href = u;
    });
    Object.defineProperty(window, 'location', {
      configurable: true,
      value: { get href() { return href; }, reload, replace },
    });
    const resultados: boolean[] = [];
    for (let carga = 0; carga < 5; carga++) {
      vi.resetModules(); // cada recarga = módulo nuevo
      const { recargarPorVersionNueva } = await import('../../../utils/recargaTrasDeploy');
      resultados.push(recargarPorVersionNueva());
    }
    expect(resultados).toEqual([true, false, false, false, false]);
    expect(replace).toHaveBeenCalledTimes(1);
    expect(href).toContain('recarga_version=1');
    expect(href).toContain('pedido_id=1');
    expect(reload).not.toHaveBeenCalled();
  });
});
