// 14/10/2026 (revisión): al escanear un sobre, si el servidor contesta success con enviados: 0 y
// yaAvisados > 0 (el pedido ya estaba en esa etapa), se muestra «Ya estaba avisado», no un error.
import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { describe, expect, it, vi } from 'vitest';

const respuestaAviso = vi.hoisted(() => ({ valor: { success: true, enviados: 0, yaAvisados: 1 } as any }));
vi.mock('../../../services/adminAuthService', () => ({
  loginAdminConServidor: vi.fn(),
  verificarSesionAdmin: vi.fn(async () => true),
}));
vi.mock('../../../services/escaneoPedidoService', () => ({
  obtenerResumenPedidoEscaneo: vi.fn(async () => ({
    success: true,
    pedido: {
      id: 'p1', pedidoFriendlyId: 'IFS-1', alumnoNombre: 'Ana', colegioNombre: 'Col', grado: '1', division: 'A', turno: 'Mañana',
      estado: 'pagado', estadoLab: null, fechaEnvioProduccion: null, fechaEnvioListoRetiro: null, fechaEntregado: null,
      tutorNombre: 'Mamá', tutorEmail: 'mama@x.com', tutorWhatsapp: null,
    },
  })),
}));
vi.mock('../../../services/emailService', () => ({ enviarActualizacionPedidos: vi.fn(async () => respuestaAviso.valor) }));
vi.mock('../../../services/pedidosLabService', () => ({ marcarPedidoRetirado: vi.fn() }));

describe('EscaneoPedidoModal: aviso ya enviado', () => {
  it('enviados: 0 con yaAvisados: 1 → «Ya estaba avisado» y no «No se pudo enviar el aviso»', async () => {
    const { default: EscaneoPedidoModal } = await import('../../../components/EscaneoPedidoModal');
    render(<EscaneoPedidoModal pedidoId="p1" onClose={() => {}} />);
    await userEvent.click(await screen.findByRole('button', { name: /avisar "en producción"/i }));
    expect(await screen.findByText(/ya estaba avisado/i)).toBeInTheDocument();
    expect(screen.queryByText(/no se pudo enviar el aviso/i)).toBeNull();
  });

  it('control: enviados 0 sin yaAvisados sigue siendo un error', async () => {
    respuestaAviso.valor = { success: true, enviados: 0, yaAvisados: 0 };
    const { default: EscaneoPedidoModal } = await import('../../../components/EscaneoPedidoModal');
    render(<EscaneoPedidoModal pedidoId="p1" onClose={() => {}} />);
    await userEvent.click(await screen.findByRole('button', { name: /avisar "en producción"/i }));
    expect(await screen.findByText(/no se pudo enviar el aviso/i)).toBeInTheDocument();
  });
});
