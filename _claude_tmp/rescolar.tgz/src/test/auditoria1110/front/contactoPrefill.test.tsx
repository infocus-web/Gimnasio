// Auditoría 11/10 (FRO-8): los datos que deja el portal se cargan en el formulario ya montado.
import { act, render, screen } from '@testing-library/react';
import { describe, expect, it, vi } from 'vitest';
import ContactoSection from '../../../components/ContactoSection';
import { irAConsultasConDatos } from '../../../utils/consultaPrefill';

describe('FRO: prefill de Consultas', () => {
  it('con ContactoSection ya montada (App la monta siempre) el prefill se aplica y se borra', async () => {
    vi.useFakeTimers();
    Element.prototype.scrollIntoView = vi.fn();
    render(<ContactoSection />);
    act(() => {
      irAConsultasConDatos({ nombre: 'Ana Pérez', numeroPedido: 'IFS-2026-1234', mensaje: 'No me llegó el link' });
      vi.advanceTimersByTime(500);
    });
    expect((screen.getByPlaceholderText('Tu nombre...') as HTMLInputElement).value).toBe('Ana Pérez');
    expect((screen.getByPlaceholderText('Ej.: IFS-2026-7699') as HTMLInputElement).value).toBe('IFS-2026-1234');
    // No queda guardado para la próxima carga de la página.
    expect(sessionStorage.getItem('rp_consulta_prefill')).toBeNull();
    vi.useRealTimers();
  });
});
