// Auditoría 11/10 (área "núcleo"): pruebas de regresión del panel del colegio (NUC-2 y NUC-5).
// Misma base falsa en memoria que src/test/servidor/panelColegio.test.ts (nada sale a la red), con una
// demora configurable por consulta para que se comporte como una base real (latencia de red).
import http from 'http';
import type { AddressInfo } from 'net';
import express from 'express';
import { afterAll, beforeAll, beforeEach, describe, expect, it, vi } from 'vitest';

vi.mock('dotenv', () => {
  const config = () => ({ parsed: {} });
  return { default: { config }, config };
});

const h = vi.hoisted(() => {
  const estado = { tablas: {} as Record<string, any[]>, demoraMs: 0 };
  const valor = (fila: any, campo: string) => fila[campo] ?? null;
  const comparar = (a: any, b: any) => {
    const fa = Date.parse(a);
    const fb = Date.parse(b);
    if (typeof a === 'string' && typeof b === 'string' && /^\d{4}-/.test(a) && Number.isFinite(fa) && Number.isFinite(fb)) return fa - fb;
    if (typeof a === 'number' && typeof b === 'number') return a - b;
    return String(a).localeCompare(String(b));
  };
  const esperar = () => new Promise((ok) => setTimeout(ok, estado.demoraMs));
  function consulta(tabla: string) {
    const filtros: Array<(f: any) => boolean> = [];
    let cambios: Record<string, any> | null = null;
    let nuevas: any[] | null = null;
    let unica = false;
    let rango: [number, number] | null = null;
    let limite = Infinity;
    const ordenes: { campo: string; asc: boolean }[] = [];
    const q: any = {
      select: () => q,
      eq: (c: string, v: any) => (filtros.push((f) => valor(f, c) === v), q),
      neq: (c: string, v: any) => (filtros.push((f) => valor(f, c) !== v), q),
      is: (c: string, v: any) => (filtros.push((f) => valor(f, c) === v), q),
      in: (c: string, vs: any[]) => (filtros.push((f) => vs.includes(valor(f, c))), q),
      gte: (c: string, v: any) => (filtros.push((f) => valor(f, c) !== null && comparar(valor(f, c), v) >= 0), q),
      lt: (c: string, v: any) => (filtros.push((f) => valor(f, c) !== null && comparar(valor(f, c), v) < 0), q),
      order: (campo: string, o?: { ascending?: boolean }) => (ordenes.push({ campo, asc: o?.ascending !== false }), q),
      range: (d: number, hasta: number) => ((rango = [d, hasta]), q),
      limit: (n: number) => ((limite = n), q),
      update: (c: Record<string, any>) => ((cambios = c), q),
      insert: (f: any) => ((nuevas = Array.isArray(f) ? f : [f]), q),
      upsert: (f: any) => ((nuevas = Array.isArray(f) ? f : [f]), q),
      maybeSingle: () => ((unica = true), q),
      single: () => ((unica = true), q),
      then: (ok: any, mal: any) => esperar().then(() => ejecutar()).then(ok, mal),
    };
    function ejecutar() {
      const filas = (estado.tablas[tabla] = estado.tablas[tabla] || []);
      if (nuevas) {
        const creadas = nuevas.map((f, i) => ({ id: `id-${filas.length + i}`, created_at: new Date().toISOString(), ...f }));
        filas.push(...creadas);
        const copia = JSON.parse(JSON.stringify(creadas));
        return { data: unica ? copia[0] : copia, error: null };
      }
      let elegidas = filas.filter((f) => filtros.every((fn) => fn(f)));
      if (cambios) for (const f of elegidas) Object.assign(f, cambios);
      for (const { campo, asc } of [...ordenes].reverse()) {
        elegidas = [...elegidas].sort((a, b) => (asc ? 1 : -1) * comparar(valor(a, campo) ?? '', valor(b, campo) ?? ''));
      }
      if (rango) elegidas = elegidas.slice(rango[0], rango[1] + 1);
      const copia = JSON.parse(JSON.stringify(elegidas.slice(0, limite)));
      return { data: unica ? copia[0] ?? null : copia, error: null };
    }
    return q;
  }
  async function rpc(nombre: string, args: any) {
    await esperar();
    if (nombre !== 'registrar_intento') return { data: null, error: null };
    const filas = (estado.tablas.limites_intentos = estado.tablas.limites_intentos || []);
    let fila = filas.find((f) => f.clave === args.p_clave);
    if (!fila) {
      fila = { clave: args.p_clave, cantidad: 0, desde: new Date().toISOString() };
      filas.push(fila);
    }
    fila.cantidad += 1;
    return { data: fila.cantidad > args.p_max ? args.p_ventana_seg : 0, error: null };
  }
  return { estado, consulta, rpc };
});

vi.mock('@supabase/supabase-js', () => ({
  createClient: () => ({ from: (tabla: string) => h.consulta(tabla), rpc: (n: string, a: any) => h.rpc(n, a) }),
}));

const COLEGIO = '11111111-1111-4111-8111-111111111111';
const anio = new Date().getFullYear();
const pagadoEste = `${anio}-06-15T15:00:00.000Z`;

let servidor: http.Server;
let puerto = 0;
let tokenAdmin = '';
const entornoAntes: Record<string, string | undefined> = {};

function pedir(metodo: string, ruta: string, cuerpo?: unknown, token?: string, ip?: string): Promise<{ status: number; json: any; texto: string }> {
  return new Promise((ok, mal) => {
    const datos = cuerpo === undefined ? undefined : JSON.stringify(cuerpo);
    const encabezados: Record<string, string | number> = {};
    if (ip) encabezados['X-Forwarded-For'] = ip;
    if (datos) {
      encabezados['Content-Type'] = 'application/json';
      encabezados['Content-Length'] = Buffer.byteLength(datos);
    }
    if (token) encabezados.Authorization = `Bearer ${token}`;
    const req = http.request({ host: '127.0.0.1', port: puerto, path: ruta, method: metodo, headers: encabezados, agent: false }, (res) => {
      let texto = '';
      res.setEncoding('utf8');
      res.on('data', (c) => { texto += c; });
      res.on('end', () => {
        let json: any = null;
        try { json = JSON.parse(texto); } catch { /* no es JSON */ }
        ok({ status: res.statusCode || 0, json, texto });
      });
    });
    req.on('error', mal);
    if (datos) req.write(datos);
    req.end();
  });
}

function pedido(numero: string, extra: Record<string, any> = {}) {
  return {
    id: `uuid-${numero}`, pedido_friendly_id: numero, colegio_id: COLEGIO, colegio_nombre: 'Colegio de Prueba',
    grado: '5° grado', division: 'C', turno: 'Mañana', curso_codigo: 'GRADO5-CTM', alumno_nombre: `Alumno ${numero}`,
    alumno_numero_lista: 1, codigo_alumno: `GRADO5-CTM_01_${numero}`, tipo_kit: 'impreso_digital', kit_nombre: 'Kit Impreso',
    carpetas_impresas: 1, total: 30000, metodo_pago: 'transferencia', estado: 'pagado', estado_lab: 'listo_retiro',
    seleccion_pendiente: false, en_espera: false, archivado: false, pagado_at: pagadoEste, created_at: pagadoEste,
    fecha_entregado: null, entregado_por: null, copias_extras: {}, fotos_seleccionadas: {}, ...extra,
  };
}

function cargarBase() {
  h.estado.demoraMs = 0;
  h.estado.tablas = {
    colegios: [{ id: COLEGIO, nombre: 'Colegio de Prueba', evento_actual: '', porcentaje_participacion: 30, codigo_convenio: 'CVA1B2C3D4E5F6' }],
    colegios_panel: [],
    convenios_colegios: [{ colegio_id: COLEGIO, created_at: `${anio}-03-01T12:00:00Z`, porcentaje_participacion: 30, precios_laboratorio: null }],
    costos_liquidacion: [{ id: 1, costo_carpeta: 1000, costo_foto_20x30: 500, costo_foto_15x21: 300 }],
    codigos_seccion: [], alumnos: [], inscripciones: [],
    pedidos: [
      // Una familia pagó con recargo por copias extra (total distinto al precio de lista del kit).
      pedido('IFS-2026-0001', { alumno_nombre: 'Martina Gómez', total: 41750, pagado_at: `${anio}-06-15T22:47:00.000Z` }),
      pedido('IFS-2026-0002', { alumno_nombre: 'Lucas Pérez', total: 30000, estado_lab: 'en_produccion', alumno_numero_lista: 2 }),
      pedido('IFS-2026-0005', { alumno_nombre: 'Archivado', archivado: true }),
    ],
    limites_intentos: [],
  };
}

const admin = (metodo: string, ruta: string, cuerpo?: unknown) => pedir(metodo, ruta, cuerpo, tokenAdmin);

async function darPin() {
  const r = await admin('POST', `/api/admin/colegios/${COLEGIO}/panel/pin`);
  return { pin: String(r.json.pin), codigo: new URL(r.json.panel.link).searchParams.get('c') || '' };
}

beforeAll(async () => {
  for (const nombre of ['SUPABASE_SERVICE_ROLE_KEY', 'ADMIN_SESSION_SECRET', 'APP_URL']) entornoAntes[nombre] = process.env[nombre];
  process.env.SUPABASE_SERVICE_ROLE_KEY = 'prueba';
  process.env.ADMIN_SESSION_SECRET = 'secreto-de-prueba';
  process.env.APP_URL = 'https://www.retratoescolar.com.ar';
  const { rutasPanelColegio } = await import('../../../../servidor/colegio/panelColegio');
  const { generateAdminToken } = await import('../../../../servidor/nucleo/auth');
  tokenAdmin = generateAdminToken() || '';
  const app = express();
  app.set('trust proxy', true);
  app.use(express.json({ limit: '4mb' }));
  app.use(rutasPanelColegio);
  servidor = app.listen(0);
  await new Promise((ok) => servidor.once('listening', ok));
  puerto = (servidor.address() as AddressInfo).port;
}, 120_000);

afterAll(async () => {
  await new Promise((ok) => servidor.close(ok));
  for (const [nombre, valor] of Object.entries(entornoAntes)) {
    if (valor === undefined) delete process.env[nombre];
    else process.env[nombre] = valor;
  }
});

beforeEach(() => cargarBase());

describe('NUC-2: el tope de 20 intentos de PIN por hora es atómico', () => {
  it('60 intentos simultáneos desde IPs distintas: como mucho 20 llegan a verificar el PIN, el resto 429', async () => {
    const { pin, codigo } = await darPin();
    h.estado.demoraMs = 30; // latencia típica Vercel → Supabase
    const malos = Array.from({ length: 60 }, (_, i) => String((Number(pin) + 1 + i) % 1_000_000).padStart(6, '0'));
    const respuestas = await Promise.all(malos.map((p, i) => pedir('POST', '/api/colegio/login', { codigo, pin: p }, undefined, `10.9.0.${i}`)));
    expect(respuestas.filter((r) => r.status === 401).length).toBeLessThanOrEqual(20);
    expect(respuestas.filter((r) => r.status === 429).length).toBeGreaterThanOrEqual(40);
    // Pasado el tope, ni el PIN correcto entra (hasta que pase la hora o Pablo dé un PIN nuevo).
    expect((await pedir('POST', '/api/colegio/login', { codigo, pin }, undefined, '10.9.1.1')).status).toBe(429);
  }, 60_000);

  it('uso normal: el PIN correcto entra después de algunos equivocados', async () => {
    const { pin, codigo } = await darPin();
    const malo = pin === '000000' ? '111111' : '000000';
    for (let i = 0; i < 3; i++) expect((await pedir('POST', '/api/colegio/login', { codigo, pin: malo }, undefined, `10.8.0.${i}`)).status).toBe(401);
    expect((await pedir('POST', '/api/colegio/login', { codigo, pin }, undefined, '10.8.0.9')).status).toBe(200);
  });
});

describe('NUC-5: el colegio no puede marcar entregado un pedido archivado', () => {
  it('IFS-2026-0005 (archivado) responde 404 y queda como estaba; uno normal se marca', async () => {
    const { pin, codigo } = await darPin();
    const token = (await pedir('POST', '/api/colegio/login', { codigo, pin })).json.token;
    const r = await pedir('POST', '/api/colegio/entregas/IFS-2026-0005/entregado', undefined, token);
    expect(r.status).toBe(404);
    expect(h.estado.tablas.pedidos.find((p) => p.pedido_friendly_id === 'IFS-2026-0005')).toMatchObject({ estado_lab: 'listo_retiro', entregado_por: null });
    expect((await pedir('POST', '/api/colegio/entregas/IFS-2026-0001/entregado', undefined, token)).status).toBe(200);
  });
});
