import { render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { afterEach, describe, expect, it, vi } from 'vitest';
import ReservaRetorno from '../../../components/ReservaRetorno';

vi.mock('../../../services/mediosPagoService', () => ({ useNaveHabilitado: () => false }));

// Auditoría 11/10 — ReservaRetorno: POR-12 (casilla de 48 h), POR-13 (tiempo máximo) y transferencia vencida.
afterEach(() => vi.unstubAllGlobals());

function servidor(cambio: () => Response) {
  const fetchMock = vi.fn(async (url: string, _init?: RequestInit) => {
    if (String(url).includes('/cambiar-metodo-pago')) return cambio();
    if (String(url).includes('/api/pagos/comprobante')) return new Response(JSON.stringify({ success: true, subido: false }));
    return new Response(JSON.stringify({ success: true, pedidoId: 'p-1', pedidoFriendlyId: 'IFS-2026-1234', estadoPago: 'rechazado', metodoPago: 'mercadopago', total: 15000 }));
  });
  vi.stubGlobal('fetch', fetchMock);
  return fetchMock;
}

describe('ReservaRetorno (auditoría 11/10)', () => {
  it('POR-12: pasar a transferencia exige tildar el plazo de 48 h', async () => {
    const fetchMock = servidor(() => new Response(JSON.stringify({ success: true, metodoPago: 'transferencia' })));
    const user = userEvent.setup();
    render(<ReservaRetorno grupoPagoId="g-1" onCerrar={() => {}} />);
    await user.click(await screen.findByRole('button', { name: /elegir otro medio de pago/i }));
    await user.click(screen.getByRole('button', { name: /pagar con transferencia/i }));
    await user.click(screen.getByRole('button', { name: /confirmar el pago por transferencia/i }));
    expect(screen.getByText(/tildá esta casilla/i)).toBeInTheDocument();
    expect(fetchMock.mock.calls.some((c) => String(c[0]).includes('/cambiar-metodo-pago'))).toBe(false);
    await user.click(document.getElementById('chk-plazo-transferencia-retorno') as HTMLElement);
    await user.click(screen.getByRole('button', { name: /confirmar el pago por transferencia/i }));
    expect(await screen.findByText('RETRATO.ESCOLAR')).toBeInTheDocument();
  });

  it('transferencia vencida (409 TRANSFERENCIA_VENCIDA): muestra el mensaje del servidor y no reabre el portal', async () => {
    servidor(() => new Response(JSON.stringify({ success: false, codigo: 'TRANSFERENCIA_VENCIDA', error: 'El plazo de 48 h venció: el pedido se canceló.' }), { status: 409 }));
    const onElegirOtroMedio = vi.fn();
    const user = userEvent.setup();
    render(<ReservaRetorno grupoPagoId="g-1" onCerrar={() => {}} onElegirOtroMedio={onElegirOtroMedio} />);
    await user.click(await screen.findByRole('button', { name: /elegir otro medio de pago/i }));
    await user.click(screen.getByRole('button', { name: /pagar con transferencia/i }));
    await user.click(document.getElementById('chk-plazo-transferencia-retorno') as HTMLElement);
    await user.click(screen.getByRole('button', { name: /confirmar el pago por transferencia/i }));
    expect(await screen.findByText('El plazo de 48 h venció: el pedido se canceló.')).toBeInTheDocument();
    expect(onElegirOtroMedio).not.toHaveBeenCalled();
  });

  it('POR-13: la consulta de estado lleva tiempo máximo (señal de corte)', async () => {
    const fetchMock = servidor(() => new Response('{}'));
    render(<ReservaRetorno grupoPagoId="g-1" onCerrar={() => {}} />);
    await waitFor(() => expect(fetchMock).toHaveBeenCalled());
    const init = fetchMock.mock.calls[0][1] as RequestInit | undefined;
    expect(init?.signal).toBeInstanceOf(AbortSignal);
  });
});
