import { render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { describe, expect, it } from 'vitest';
import PortalFamiliasModal from '../../../components/PortalFamiliasModal';
import { guardarFamilia, irAlPaso4, json, mockearFamiliaDeUnHijo, sobreescribirFetch } from './ayudas';

// Auditoría 11/10 — POR-5 y POR-11 (archivo aparte: los precios del servidor son estado del módulo).
describe('POR-5: sin los precios del servidor no se paga un monto inventado', () => {
  it('muestra "a confirmar", deshabilita Pagar y con Reintentar (precios ya cargados) se habilita', async () => {
    guardarFamilia();
    mockearFamiliaDeUnHijo();
    let preciosOk = false;
    sobreescribirFetch(
      (u) => u.includes('/api/precios'),
      () => (preciosOk ? json(200, { success: true, precios: { kitClasico: 35000, kitDigital: 15000, carpetaExtra: 15000, fotoEvento: 5000 } }) : json(503, { success: false }))
    );
    const user = userEvent.setup();
    render(<PortalFamiliasModal isOpen={true} onClose={() => {}} />);
    await irAlPaso4(user);
    const boton = document.getElementById('btn-confirmar-pagar') as HTMLButtonElement;
    expect(boton).toBeDisabled();
    expect(boton).toHaveTextContent(/monto a confirmar/i);
    expect(screen.getByText(/no pudimos cargar los precios vigentes/i)).toBeInTheDocument();
    preciosOk = true;
    // La carga en curso reintenta sola; el botón "Reintentar" también la dispara.
    await waitFor(() => expect(boton).not.toBeDisabled(), { timeout: 8000 });
    expect(boton).toHaveTextContent('$35.000');
    expect(screen.queryByText(/no pudimos cargar los precios vigentes/i)).not.toBeInTheDocument();
  }, 15000);

  it('POR-11: la etiqueta de la carpeta extra usa el precio vigente', async () => {
    guardarFamilia();
    mockearFamiliaDeUnHijo();
    sobreescribirFetch((u) => u.includes('/api/precios'), () => json(200, { success: true, precios: { kitClasico: 30000, kitDigital: 15000, carpetaExtra: 18000, fotoEvento: 5000 } }));
    const { cargarPreciosDelServidor } = await import('../../../services/preciosService');
    expect(await cargarPreciosDelServidor({ forzar: true })).toBe(true);
    const user = userEvent.setup();
    render(<PortalFamiliasModal isOpen={true} onClose={() => {}} />);
    await irAlPaso4(user);
    await user.click(screen.getByRole('button', { name: /volver a cambiar kit/i }));
    expect(await screen.findByText('+$18.000 ARS c/u')).toBeInTheDocument();
    expect(screen.queryByText('+$15.000 ARS c/u')).not.toBeInTheDocument();
  });
});
