import { render, screen, waitFor, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { afterEach, describe, expect, it, vi } from 'vitest';
import PortalFamiliasModal from '../../../components/PortalFamiliasModal';
import { comprarPorTransferencia, elegirLasTres, guardarFamilia, irAlPaso4, json, llamadas, mockearFamiliaDeUnHijo, pagar, sobreescribirFetch } from './ayudas';

// Auditoría 11/10/2026 — portal de familias: pruebas de REGRESIÓN (fallaban con el código anterior).
// Ver /home/claude/informes/portal.md (POR-1…POR-14, FRO-2).

afterEach(() => {
  window.history.replaceState(null, '', '/');
});

function pedidoLocal(id: string, metodoPago: string) {
  return { id: 'IFS-2026-1111', supabaseId: id, total: 30000, metodoPago, estadoPago: 'pendiente', kitNombre: 'Kit Impreso + Digital', alumnoNombre: 'Pablo Alder', archivosParaLaboratorio: [] };
}

describe('POR-1: una respuesta de estado atrasada no se aplica al pedido nuevo', () => {
  it('el pedido nuevo por transferencia sigue pendiente aunque llegue tarde el "aprobado" del anterior', async () => {
    guardarFamilia();
    mockearFamiliaDeUnHijo();
    window.history.replaceState(null, '', '/?mp_status=approved&pedido_id=pedido-viejo');
    localStorage.setItem('infocus_pedidos_escolares_v1', JSON.stringify([pedidoLocal('pedido-viejo', 'mercadopago')]));
    let responderViejo: () => void = () => {};
    sobreescribirFetch(
      (u) => u.includes('/api/pedidos/pedido-viejo/status'),
      () => new Promise<Response>((r) => { responderViejo = () => r(json(200, { success: true, estadoPago: 'aprobado', total: 15000, linkDescargaHD: 'https://descarga.test/zip-viejo' })); })
    );
    sobreescribirFetch((u) => u.includes('/api/pedidos/crear'), () => json(200, { success: true, pedidoId: 'pedido-nuevo', pedidoFriendlyId: 'IFS-2026-6666', total: 30000, accesoToken: 'llave' }));

    const user = userEvent.setup();
    render(<PortalFamiliasModal isOpen={true} onClose={() => {}} />);
    expect((await screen.findAllByText(/estamos confirmando tu pago/i)).length).toBeGreaterThan(0);
    await user.click(screen.getByRole('button', { name: /ver fotos \/ comprar/i }));
    await comprarPorTransferencia(user);
    expect(await screen.findByText(/datos para completar la transferencia bancaria/i)).toBeInTheDocument();

    responderViejo();
    await new Promise((r) => setTimeout(r, 50));
    expect(screen.queryByText(/pago aprobado con éxito/i)).not.toBeInTheDocument();
    expect(screen.queryByRole('link', { name: /descargar fotos hd/i })).not.toBeInTheDocument();
    expect(screen.getByText('Pendiente de Pago')).toBeInTheDocument();
    expect(screen.getAllByText(/\$30\.000 ARS/).length).toBeGreaterThan(0);
  });
});

describe('POR-2 y POR-9: lo del pedido de la vuelta del pago no se pega al pedido siguiente', () => {
  it('después de volver de Mercado Pago sin pagar, la compra nueva por transferencia no dice "Pago no completado"', async () => {
    guardarFamilia();
    mockearFamiliaDeUnHijo();
    window.history.replaceState(null, '', '/?mp_status=failure&pedido_id=pedido-viejo');
    localStorage.setItem('infocus_pedidos_escolares_v1', JSON.stringify([pedidoLocal('pedido-viejo', 'mercadopago')]));
    sobreescribirFetch((u) => u.includes('/api/pedidos/pedido-viejo/status'), () => json(200, { success: true, estadoPago: 'pendiente', total: 30000 }));
    sobreescribirFetch((u) => u.includes('/api/mercadopago/crear-preferencia'), () => json(200, { success: true, initPoint: 'https://mp.test/x' }));
    sobreescribirFetch((u) => u.includes('/api/pedidos/crear'), () => json(200, { success: true, pedidoId: 'pedido-nuevo', pedidoFriendlyId: 'IFS-2026-2222', total: 30000, accesoToken: 'llave' }));

    const user = userEvent.setup();
    render(<PortalFamiliasModal isOpen={true} onClose={() => {}} />);
    expect(await screen.findByText(/tu pedido todavía no está pago/i)).toBeInTheDocument();
    await user.click(screen.getByRole('button', { name: /ver fotos \/ comprar/i }));
    await comprarPorTransferencia(user);
    expect(await screen.findByText(/datos para completar la transferencia bancaria/i)).toBeInTheDocument();
    expect(screen.queryByText(/pago no completado/i)).not.toBeInTheDocument();
    expect(screen.queryByText(/volviste de mercado pago sin completar el pago/i)).not.toBeInTheDocument();
    expect(screen.getByText(/verificación automática de pago activa/i)).toBeInTheDocument();
  });

  it('después de un pago aprobado, la compra nueva no muestra "¡Pago confirmado!"', async () => {
    guardarFamilia();
    mockearFamiliaDeUnHijo();
    window.history.replaceState(null, '', '/?mp_status=approved&pedido_id=pedido-viejo');
    localStorage.setItem('infocus_pedidos_escolares_v1', JSON.stringify([pedidoLocal('pedido-viejo', 'mercadopago')]));
    sobreescribirFetch((u) => u.includes('/api/pedidos/pedido-viejo/status'), () => json(200, { success: true, estadoPago: 'aprobado', total: 30000, linkDescargaHD: 'https://descarga.test/zip' }));
    sobreescribirFetch((u) => u.includes('/api/pedidos/crear'), () => json(200, { success: true, pedidoId: 'pedido-nuevo', pedidoFriendlyId: 'IFS-2026-3333', total: 30000, accesoToken: 'llave' }));

    const user = userEvent.setup();
    render(<PortalFamiliasModal isOpen={true} onClose={() => {}} />);
    expect(await screen.findByText(/pago aprobado con éxito/i)).toBeInTheDocument();
    await user.click(screen.getByRole('button', { name: /ver fotos \/ comprar/i }));
    await comprarPorTransferencia(user);
    expect(await screen.findByText(/datos para completar la transferencia bancaria/i)).toBeInTheDocument();
    expect(screen.queryByText(/¡pago confirmado! ya podés descargar/i)).not.toBeInTheDocument();
  });
});

describe('POR-4: rechazado o cancelado se dice como tal', () => {
  it('vuelta de Nave con el pago rechazado', async () => {
    guardarFamilia();
    mockearFamiliaDeUnHijo();
    window.history.replaceState(null, '', '/?nave_status=vuelta&pedido_id=pedido-nave');
    localStorage.setItem('infocus_pedidos_escolares_v1', JSON.stringify([pedidoLocal('pedido-nave', 'nave')]));
    sobreescribirFetch((u) => u.includes('/api/pedidos/pedido-nave/status'), () => json(200, { success: true, estado: 'cancelado', estadoPago: 'rechazado', total: 30000 }));
    render(<PortalFamiliasModal isOpen={true} onClose={() => {}} />);
    expect((await screen.findAllByText(/pago rechazado o pedido cancelado/i)).length).toBeGreaterThan(0);
    expect(screen.getByText('Rechazado / cancelado')).toBeInTheDocument();
    expect(screen.queryByText(/pendiente de acreditación/i)).not.toBeInTheDocument();
    expect(screen.queryByText('Pendiente de Pago')).not.toBeInTheDocument();
  });

  it('transferencia cancelada (vencida): no se muestran los datos bancarios', async () => {
    guardarFamilia();
    mockearFamiliaDeUnHijo();
    sobreescribirFetch((u) => u.includes('/api/pedidos/crear'), () => json(200, { success: true, pedidoId: 'pedido-t', pedidoFriendlyId: 'IFS-2026-7777', total: 30000, accesoToken: 'llave' }));
    sobreescribirFetch((u) => /\/api\/pedidos\/[^/]+\/status/.test(u), () => json(200, { success: true, estado: 'cancelado', estadoPago: 'rechazado', total: 30000 }));
    const user = userEvent.setup();
    render(<PortalFamiliasModal isOpen={true} onClose={() => {}} />);
    await comprarPorTransferencia(user);
    expect(await screen.findByText(/datos para completar la transferencia bancaria/i)).toBeInTheDocument();
    await user.click(screen.getByRole('button', { name: /re-verificar estado/i }));
    expect(await screen.findByText('Rechazado / cancelado')).toBeInTheDocument();
    expect(screen.queryByText(/datos para completar la transferencia bancaria/i)).not.toBeInTheDocument();
    expect(screen.queryByText(/0070313830004052956749/)).not.toBeInTheDocument();
  });
});

describe('POR-7: casillas legales sin premarcar en la segunda compra', () => {
  it('la segunda compra arranca con "Leí y acepto" y el plazo de 48 h sin tildar', async () => {
    guardarFamilia();
    mockearFamiliaDeUnHijo();
    let n = 0;
    sobreescribirFetch(
      (u) => u.includes('/api/pedidos/crear'),
      () => {
        n += 1;
        return json(200, { success: true, pedidoId: `pedido-${n}`, pedidoFriendlyId: `IFS-2026-400${n}`, total: 30000, accesoToken: 'llave' });
      }
    );
    const user = userEvent.setup();
    render(<PortalFamiliasModal isOpen={true} onClose={() => {}} />);
    await comprarPorTransferencia(user);
    expect(await screen.findByText(/datos para completar la transferencia bancaria/i)).toBeInTheDocument();
    await user.click(screen.getByRole('button', { name: /ver fotos \/ comprar/i }));
    await irAlPaso4(user);
    await user.click(screen.getByRole('button', { name: /^transferencia\s*alias/i }));
    expect(screen.getByRole('checkbox', { name: /leí y acepto/i })).not.toBeChecked();
    expect(document.getElementById('chk-plazo-transferencia')).not.toBeChecked();
  });
});

describe('POR-10: "Ingresar de nuevo" lleva al formulario de ingreso', () => {
  it('sesión sin llave de galería: aparecen nombre y DNI del tutor', async () => {
    guardarFamilia({ accesoGaleria: undefined });
    mockearFamiliaDeUnHijo();
    sobreescribirFetch((u) => u.includes('/api/inscripciones/buscar'), () => json(503, { success: false }));
    const user = userEvent.setup();
    render(<PortalFamiliasModal isOpen={true} onClose={() => {}} />);
    await user.click(await screen.findByRole('button', { name: /abrir galería de fotos/i }));
    expect(await screen.findByText(/para ver la foto individual de tu hijo\/a, volvé a ingresar/i)).toBeInTheDocument();
    await user.click(screen.getByRole('button', { name: /ingresar de nuevo/i }));
    expect(await screen.findByPlaceholderText(/nombre y apellido del tutor/i)).toBeInTheDocument();
    expect(screen.getByPlaceholderText(/dni del tutor/i)).toBeInTheDocument();
  });
});

describe('POR-3, POR-12 y transferencia vencida: carrito que vuelve del pago en otro navegador', () => {
  const GRUPO = '11111111-2222-4333-8444-555555555555';
  const FILA = 'aaaaaaaa-bbbb-4ccc-8ddd-eeeeeeeeeeee';
  function preparar(cambio: (url: string) => Response) {
    mockearFamiliaDeUnHijo();
    window.history.replaceState(null, '', `/?mp_status=rejected&grupo_pago_id=${GRUPO}&t=llave-grupo`);
    sobreescribirFetch((u) => u.includes(`/api/pedidos/${GRUPO}/status`), () => json(200, { success: true, pedidoId: FILA, estadoPago: 'pendiente', total: 60000, metodoPago: 'mercadopago' }));
    sobreescribirFetch((u) => u.includes('/api/mercadopago/crear-preferencia-multiple'), () => json(200, { success: true, initPoint: 'https://mp.test/g' }));
    sobreescribirFetch((u) => u.includes('/cambiar-metodo-pago'), (u) => cambio(u));
  }

  it('pasa a transferencia con la fila real del carrito, y sólo después de tildar el plazo de 48 h', async () => {
    preparar((u) => (u.includes(FILA) ? json(200, { success: true }) : json(404, { success: false, error: 'Pedido no encontrado' })));
    const user = userEvent.setup();
    render(<PortalFamiliasModal isOpen={true} onClose={() => {}} />);
    await waitFor(() => expect(llamadas(`/api/pedidos/${GRUPO}/status`).length).toBeGreaterThan(0));
    await user.click(await screen.findByRole('button', { name: /pagar con transferencia/i }));
    // POR-12: sin tildar la casilla no se cambia el medio.
    await user.click(screen.getByRole('button', { name: /confirmar el pago por transferencia/i }));
    expect(llamadas('/cambiar-metodo-pago')).toHaveLength(0);
    expect(screen.getByText(/tildá esta casilla/i)).toBeInTheDocument();
    await user.click(document.getElementById('chk-plazo-cambio-transferencia') as HTMLElement);
    await user.click(screen.getByRole('button', { name: /confirmar el pago por transferencia/i }));
    await waitFor(() => expect(llamadas('/cambiar-metodo-pago')).toHaveLength(1));
    expect(String(llamadas('/cambiar-metodo-pago')[0][0])).toContain(`/api/pedidos/${FILA}/cambiar-metodo-pago`);
    expect(await screen.findByText(/datos para completar la transferencia bancaria/i)).toBeInTheDocument();
    expect(screen.queryByText(/pedido no encontrado/i)).not.toBeInTheDocument();
  });

  it('409 TRANSFERENCIA_VENCIDA: se muestra el mensaje del servidor', async () => {
    preparar(() => json(409, { success: false, codigo: 'TRANSFERENCIA_VENCIDA', error: 'El plazo de 48 h de la transferencia venció: el pedido se canceló.' }));
    const user = userEvent.setup();
    render(<PortalFamiliasModal isOpen={true} onClose={() => {}} />);
    await waitFor(() => expect(llamadas(`/api/pedidos/${GRUPO}/status`).length).toBeGreaterThan(0));
    await user.click(await screen.findByRole('button', { name: /pagar con transferencia/i }));
    await user.click(document.getElementById('chk-plazo-cambio-transferencia') as HTMLElement);
    await user.click(screen.getByRole('button', { name: /confirmar el pago por transferencia/i }));
    expect(await screen.findByText('El plazo de 48 h de la transferencia venció: el pedido se canceló.')).toBeInTheDocument();
  });
});

describe('POR-8: con el código del colegio (público) no se dice "no hay fotos" ni se ofrece reservar', () => {
  it('pide el código del curso en vez de mostrar la galería vacía y la reserva', async () => {
    sobreescribirFetch((u) => u.includes('/api/inscripciones/buscar'), () => json(200, { success: true, inscripcion: null }));
    const user = userEvent.setup();
    render(<PortalFamiliasModal isOpen={true} onClose={() => {}} />);
    await user.type(screen.getByPlaceholderText(/nombre y apellido del tutor/i), 'Ana Pérez');
    await user.type(screen.getByPlaceholderText(/dni del tutor/i), '30111222');
    await user.type(screen.getByRole('textbox', { name: /código de acceso del curso/i }), 'IMDP2026');
    await user.click(screen.getByRole('button', { name: /validar/i }));
    expect(await screen.findByText(/institución reconocida/i)).toBeInTheDocument();
    await user.type(screen.getByPlaceholderText(/ej: benjamín gómez/i), 'Juan Pérez');
    await user.click(screen.getByRole('button', { name: /abrir galería de fotos/i }));
    expect(await screen.findByText(/necesitás el código de acceso de tu curso/i)).toBeInTheDocument();
    expect(screen.queryByText(/tus fotos todavía no fueron ingresadas/i)).not.toBeInTheDocument();
    expect(screen.queryByText(/reservá tu kit ahora/i)).not.toBeInTheDocument();
    await user.click(screen.getByRole('button', { name: /pedir mi código/i }));
    expect(await screen.findByPlaceholderText(/email usado al registrarte/i)).toBeInTheDocument();
  });
});

describe('POR-14: teclado y Escape', () => {
  it('el kit se elige con Enter y los casilleros del pack con Espacio; Escape cierra el portal', async () => {
    guardarFamilia();
    mockearFamiliaDeUnHijo();
    const onClose = vi.fn();
    const user = userEvent.setup();
    render(<PortalFamiliasModal isOpen={true} onClose={onClose} />);
    await user.click(await screen.findByRole('button', { name: /abrir galería de fotos/i }));
    await screen.findByText(/^1\/3 grupal$/i);
    // Casillero "2/3 Retrato" con teclado: pasa a la categoría individual.
    const casillero = screen.getByText(/^2\/3 retrato$/i).closest('[role="button"]') as HTMLElement;
    casillero.focus();
    await user.keyboard(' ');
    expect((await screen.findAllByText(/foto individual/i)).length).toBeGreaterThan(0); // 29/10: también lo dice el pie («Falta elegir…»)
    await elegirLasTres(user);
    await user.click(screen.getByRole('button', { name: /elegir kit y formato/i }));
    const digital = (await screen.findByText('Solo Digital HD', { selector: 'h4' })).closest('[role="button"]') as HTMLElement;
    expect(digital).toHaveAttribute('aria-pressed', 'false');
    digital.focus();
    await user.keyboard('{Enter}');
    expect(digital).toHaveAttribute('aria-pressed', 'true');
    await user.keyboard('{Escape}');
    expect(onClose).toHaveBeenCalledTimes(1);
  });

  it('Escape con el visor abierto cierra sólo el visor', async () => {
    guardarFamilia();
    mockearFamiliaDeUnHijo();
    const onClose = vi.fn();
    const user = userEvent.setup();
    render(<PortalFamiliasModal isOpen={true} onClose={onClose} />);
    await user.click(await screen.findByRole('button', { name: /abrir galería de fotos/i }));
    const tarjeta = (await screen.findAllByText(/foto grupal/i))[0].closest('div.relative') as HTMLElement;
    await user.click(within(tarjeta).getByTitle(/ampliar foto/i));
    expect(screen.getByRole('button', { name: /elegir esta foto/i })).toBeInTheDocument();
    await user.keyboard('{Escape}');
    expect(screen.queryByRole('button', { name: /elegir esta foto/i })).not.toBeInTheDocument();
    expect(onClose).not.toHaveBeenCalled();
  });
});

describe('FRO-2: la llave ?t= no queda en la URL al descartar un pedido inexistente', () => {
  it('saca t de la URL y la llave queda guardada', async () => {
    window.history.replaceState(null, '', '/?mp_status=approved&pedido_id=p-x&t=llave-x');
    sobreescribirFetch((u) => u.includes('/api/pedidos/p-x/status'), () => json(404, { success: false }));
    render(<PortalFamiliasModal isOpen={true} onClose={() => {}} />);
    expect(await screen.findByText(/este pedido ya no está disponible/i)).toBeInTheDocument();
    expect(window.location.search).not.toContain('t=');
    expect(JSON.parse(localStorage.getItem('retrato_llaves_pedidos') || '{}')['p-x']).toBe('llave-x');
  });
});

describe('doble toque en "Pagar" (verificación)', () => {
  it('doble clic: una sola llamada a /api/pedidos/crear', async () => {
    guardarFamilia();
    mockearFamiliaDeUnHijo();
    let liberar: () => void = () => {};
    sobreescribirFetch(
      (u) => u.includes('/api/pedidos/crear'),
      () => new Promise<Response>((r) => { liberar = () => r(json(500, { success: false, error: 'lento' })); })
    );
    const user = userEvent.setup();
    render(<PortalFamiliasModal isOpen={true} onClose={() => {}} />);
    await irAlPaso4(user);
    await user.click(screen.getByRole('button', { name: /^transferencia\s*alias/i }));
    await user.click(screen.getByRole('checkbox', { name: /leí y acepto/i }));
    await user.click(document.getElementById('chk-plazo-transferencia') as HTMLElement);
    await pagar(user);
    await user.click(document.getElementById('btn-confirmar-pagar') as HTMLElement);
    await waitFor(() => expect(llamadas('/api/pedidos/crear').length).toBe(1));
    liberar();
    expect(await screen.findByText(/no pudimos registrar tu pedido/i)).toBeInTheDocument();
    expect(llamadas('/api/pedidos/crear')).toHaveLength(1);
  });
});
