// Código de descuento en el Paso 4 (22/10/2026, Pablo): se valida con el servidor, el total muestra el descuento
// (sólo sobre el kit), viaja al crear el pedido y, si queda en $0, no se pasa por Mercado Pago.
import { render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { describe, expect, it } from 'vitest';
import PortalFamiliasModal from '../../../components/PortalFamiliasModal';
import { elegirLasTres, guardarFamilia, irAlPaso4, json, llamadas, mockearFamiliaDeUnHijo, sobreescribirFetch } from './ayudas';

async function irAlPaso4Digital(user: ReturnType<typeof userEvent.setup>) {
  await user.click(await screen.findByRole('button', { name: /abrir galería de fotos/i }));
  await screen.findByText(/^1\/3 grupal$/i);
  await elegirLasTres(user);
  await user.click(screen.getByRole('button', { name: /elegir kit y formato/i }));
  await user.click((await screen.findByText('Solo Digital HD', { selector: 'h4' })).closest('[role="button"]') as HTMLElement);
  await user.click(await screen.findByRole('button', { name: /ir a datos y pago/i }));
}

async function aplicarCodigo(user: ReturnType<typeof userEvent.setup>, codigo: string) {
  await user.click(await screen.findByRole('button', { name: /tenés un código de descuento/i }));
  await user.type(screen.getByLabelText(/código de descuento/i), codigo);
  await user.click(screen.getByRole('button', { name: /^aplicar$/i }));
}
const cuerpo = (fragmento: string) => JSON.parse(String((llamadas(fragmento)[0][1] as RequestInit).body));

describe('Código de descuento en el pago', () => {
  it('50%: el total baja sólo el kit y el código viaja al crear el pedido', async () => {
    guardarFamilia();
    mockearFamiliaDeUnHijo();
    sobreescribirFetch((u) => u.includes('/api/descuentos/validar'), () => json(200, { success: true, codigo: 'MITAD-2026', porcentaje: 50 }));
    sobreescribirFetch((u) => u.includes('/api/pedidos/crear'), () => json(500, { success: false, error: 'corte' }));
    const user = userEvent.setup();
    render(<PortalFamiliasModal isOpen={true} onClose={() => {}} />);
    await irAlPaso4(user);
    await aplicarCodigo(user, 'mitad-2026');
    expect(await screen.findByText(/código MITAD-2026 \(50% en el kit\)/i)).toBeInTheDocument();
    expect(screen.getByText('-$15.000')).toBeInTheDocument();
    const boton = document.getElementById('btn-confirmar-pagar') as HTMLButtonElement;
    expect(boton).toHaveTextContent('$15.000');
    await user.click(screen.getByRole('checkbox', { name: /leí y acepto/i }));
    await waitFor(() => expect(boton).not.toBeDisabled());
    await user.click(boton);
    await waitFor(() => expect(llamadas('/api/pedidos/crear').length).toBe(1));
    expect(cuerpo('/api/pedidos/crear').codigoDescuento).toBe('MITAD-2026');
  });

  it('código no válido: avisa y el total no cambia', async () => {
    guardarFamilia();
    mockearFamiliaDeUnHijo();
    sobreescribirFetch((u) => u.includes('/api/descuentos/validar'), () => json(404, { success: false, error: 'El código de descuento no es válido o ya no está disponible.' }));
    const user = userEvent.setup();
    render(<PortalFamiliasModal isOpen={true} onClose={() => {}} />);
    await irAlPaso4(user);
    await aplicarCodigo(user, 'NADA-1234');
    expect(await screen.findByText(/no es válido o ya no está disponible/i)).toBeInTheDocument();
    expect(document.getElementById('btn-confirmar-pagar')).toHaveTextContent('$30.000');
  });

  it('100% en el kit impreso: queda en 70% (Pablo 22/10) y se paga el resto', async () => {
    guardarFamilia();
    mockearFamiliaDeUnHijo();
    sobreescribirFetch((u) => u.includes('/api/descuentos/validar'), () => json(200, { success: true, codigo: 'DOCENTE-AB12', porcentaje: 100 }));
    const user = userEvent.setup();
    render(<PortalFamiliasModal isOpen={true} onClose={() => {}} />);
    await irAlPaso4(user);
    await aplicarCodigo(user, 'DOCENTE-AB12');
    expect(await screen.findByText(/100% en el kit digital, 70% en el impreso/i)).toBeInTheDocument();
    expect(screen.getByText('-$21.000')).toBeInTheDocument();
    const boton = document.getElementById('btn-confirmar-pagar') as HTMLButtonElement;
    expect(boton).toHaveTextContent('$9.000');
    expect(boton).not.toHaveTextContent(/sin cargo/i);
  });

  it('100% en el kit digital: «Confirmar pedido sin cargo», no se abre Mercado Pago y queda aprobado', async () => {
    guardarFamilia();
    mockearFamiliaDeUnHijo();
    sobreescribirFetch((u) => u.includes('/api/descuentos/validar'), () => json(200, { success: true, codigo: 'DOCENTE-AB12', porcentaje: 100 }));
    sobreescribirFetch(
      (u) => u.includes('/api/pedidos/crear'),
      (_u, init) => json(200, { success: true, pedidoId: JSON.parse(String(init?.body)).pedidoId, pedidoFriendlyId: 'IFS-2026-0001', total: 0, accesoToken: 'llave', bonificado: true })
    );
    const user = userEvent.setup();
    render(<PortalFamiliasModal isOpen={true} onClose={() => {}} />);
    await irAlPaso4Digital(user);
    await aplicarCodigo(user, 'DOCENTE-AB12');
    const boton = document.getElementById('btn-confirmar-pagar') as HTMLButtonElement;
    await waitFor(() => expect(boton).toHaveTextContent(/confirmar pedido sin cargo/i));
    await user.click(screen.getByRole('checkbox', { name: /leí y acepto/i }));
    await waitFor(() => expect(boton).not.toBeDisabled());
    await user.click(boton);
    await waitFor(() => expect(llamadas('/api/pedidos/crear').length).toBe(1));
    expect(cuerpo('/api/pedidos/crear').codigoDescuento).toBe('DOCENTE-AB12');
    expect(cuerpo('/api/pedidos/crear').kitId).toBe('kit-digital');
    expect(await screen.findAllByText(/IFS-2026-0001/)).not.toHaveLength(0);
    expect(llamadas('/api/mercadopago')).toHaveLength(0);
  });
});
