import { screen, waitFor, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { expect, vi } from 'vitest';
import { COLEGIO_ID, fotosSeccionCompartida, familiaActivaMellizos, hijosMellizos } from '../../fixtures/familiaMellizos';

// Ayudas de las pruebas de regresión de la auditoría 11/10 (portal de familias). Mismo patrón que
// PortalFamiliasModal.auditoriaNoche.test.tsx.

export type Implementacion = (input: RequestInfo | URL, init?: RequestInit) => Promise<Response>;

export function json(status: number, cuerpo: unknown): Response {
  return { ok: status >= 200 && status < 300, status, json: async () => cuerpo } as Response;
}
export function urlDe(input: RequestInfo | URL) {
  return typeof input === 'string' ? input : input.toString();
}
export function sobreescribirFetch(coincide: (url: string, init?: RequestInit) => boolean, respuesta: (url: string, init?: RequestInit) => Response | Promise<Response>) {
  const fetchBase = global.fetch as unknown as ReturnType<typeof vi.fn>;
  const base = fetchBase.getMockImplementation() as Implementacion | undefined;
  fetchBase.mockImplementation(async (input: RequestInfo | URL, init?: RequestInit) => {
    const url = urlDe(input);
    if (coincide(url, init)) return respuesta(url, init);
    return base ? base(input, init) : json(404, { success: false });
  });
}
export function llamadas(fragmento: string) {
  const fetchBase = global.fetch as unknown as ReturnType<typeof vi.fn>;
  return fetchBase.mock.calls.filter((c) => urlDe(c[0] as RequestInfo).includes(fragmento));
}

/** Familia de UN solo hijo (el principal de los mellizos), con galería de 3 fotos y sin pedidos. */
export function mockearFamiliaDeUnHijo() {
  (global.fetch as unknown as ReturnType<typeof vi.fn>).mockImplementation(async (input: RequestInfo | URL) => {
    const url = urlDe(input);
    if (url.includes('/api/precios')) return json(200, { success: true, precios: { kitClasico: 30000, kitDigital: 15000, carpetaExtra: 15000, fotoEvento: 5000 } });
    if (url.includes('/api/familia/hijos')) return json(200, { success: true, hijos: [hijosMellizos[0]] });
    if (url.includes('/api/reservas/pendiente')) return json(200, { success: true, reserva: null, fotosDisponibles: true, tienePedidoPagado: false });
    if (url.includes('/api/pedidos/existente')) return json(200, { success: true, existe: false });
    if (url.includes('/api/fotos')) {
      return json(200, {
        success: true,
        seccion: { colegioId: COLEGIO_ID, grado: '1° grado', turno: 'Tarde', division: 'A' },
        fotos: fotosSeccionCompartida,
      });
    }
    return json(404, { success: false });
  });
}

export function guardarFamilia(cambios: Record<string, unknown> = {}) {
  localStorage.setItem('infocus_familia_activa_v1', JSON.stringify({ ...familiaActivaMellizos, ...cambios }));
}

export async function elegirFoto(user: ReturnType<typeof userEvent.setup>, categoria: 'grupal' | 'individual' | 'docente', titulo: RegExp) {
  const slotLabels: Record<typeof categoria, RegExp> = {
    grupal: /^1\/3 grupal$/i,
    individual: /^2\/3 retrato$/i,
    docente: /^3\/3 con seño$/i,
  };
  const slot = screen.getByText(slotLabels[categoria]).closest('div')!.parentElement!;
  await user.click(slot);
  const tarjeta = (await screen.findAllByText(titulo))[0].closest('div.relative')!;
  await user.click(within(tarjeta as HTMLElement).getByRole('button', { name: /^elegir$/i }));
}

export async function elegirLasTres(user: ReturnType<typeof userEvent.setup>) {
  await elegirFoto(user, 'grupal', /foto grupal/i);
  await elegirFoto(user, 'individual', /foto individual/i);
  await elegirFoto(user, 'docente', /foto.*seño|foto docente/i);
}

/** Desde el Paso 1 con la familia ya identificada: galería → 3 fotos → kit → pago por transferencia. */
export async function comprarPorTransferencia(user: ReturnType<typeof userEvent.setup>, opciones: { tildarCasillas?: boolean } = {}) {
  await user.click(await screen.findByRole('button', { name: /abrir galería de fotos/i }));
  await screen.findByText(/^1\/3 grupal$/i);
  await elegirLasTres(user);
  await user.click(screen.getByRole('button', { name: /elegir kit y formato/i }));
  await user.click(await screen.findByRole('button', { name: /ir a datos y pago/i }));
  await user.click(screen.getByRole('button', { name: /^transferencia\s*alias/i }));
  if (opciones.tildarCasillas !== false) {
    const terminos = screen.getByRole('checkbox', { name: /leí y acepto/i }) as HTMLInputElement;
    if (!terminos.checked) await user.click(terminos);
    const plazo = document.getElementById('chk-plazo-transferencia') as HTMLInputElement;
    if (!plazo.checked) await user.click(plazo);
  }
  await pagar(user);
}

/** Toca «Pagar / Confirmar pedido» cuando ya está habilitado (precios del servidor cargados). */
export async function pagar(user: ReturnType<typeof userEvent.setup>) {
  const boton = document.getElementById('btn-confirmar-pagar') as HTMLButtonElement;
  await waitFor(() => expect(boton).not.toBeDisabled());
  await user.click(boton);
}

/** Desde el Paso 1: galería → 3 fotos → kit → Paso 4. */
export async function irAlPaso4(user: ReturnType<typeof userEvent.setup>) {
  await user.click(await screen.findByRole('button', { name: /abrir galería de fotos/i }));
  await screen.findByText(/^1\/3 grupal$/i);
  await elegirLasTres(user);
  await user.click(screen.getByRole('button', { name: /elegir kit y formato/i }));
  await user.click(await screen.findByRole('button', { name: /ir a datos y pago/i }));
}
