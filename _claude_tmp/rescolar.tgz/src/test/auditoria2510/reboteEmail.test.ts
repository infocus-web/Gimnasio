// Auditoría 25/10/2026: rebotes permanentes y quejas por spam de Resend dejan una alerta en el panel (antes se ignoraban).
import { describe, expect, it } from 'vitest';
import { registrarProblemaDeEntrega } from '../../../servidor/correoEntrante';

function baseFalsa(tablas: Record<string, any[]>) {
  const insertados: any[] = [];
  const from = (tabla: string) => {
    let filas = [...(tablas[tabla] || [])];
    const q: any = {
      select: () => q,
      eq: (c: string, v: unknown) => ((filas = filas.filter((f) => (c === 'detalle->>clave' ? f.detalle?.clave : f[c]) === v)), q),
      in: (c: string, v: unknown[]) => ((filas = filas.filter((f) => v.includes(f[c]))), q),
      limit: () => q,
      insert: async (fila: any) => (insertados.push(fila), (tablas[tabla] = [...(tablas[tabla] || []), fila]), { error: null }),
      then: (ok: any) => ok({ data: filas, error: null }),
    };
    return q;
  };
  return { supabase: { from } as any, insertados };
}

describe('registrarProblemaDeEntrega', () => {
  it('rebote permanente: alerta con los pedidos de la familia, una sola vez por email', async () => {
    const { supabase, insertados } = baseFalsa({
      familias: [{ id: 'f1', email: 'mama@prueba.test' }],
      pedidos: [{ familia_id: 'f1', pedido_friendly_id: 'IFS-2026-0001' }],
      reportes_errores: [],
    });
    const datos = { email_id: 'e1', to: ['Mama@Prueba.test'], subject: 'Tus fotos HD', bounce: { type: 'Permanent', message: 'mailbox does not exist' } };
    await registrarProblemaDeEntrega(supabase, 'email.bounced', datos);
    await registrarProblemaDeEntrega(supabase, 'email.bounced', datos);
    expect(insertados).toHaveLength(1);
    expect(insertados[0].mensaje).toContain('mama@prueba.test');
    expect(insertados[0].mensaje).toContain('IFS-2026-0001');
    expect(insertados[0].detalle).toMatchObject({ tipo: 'rebote_email', clave: 'entrega-email:e1' });
  });

  it('rebote temporal: nada (Resend reintenta); queja por spam: alerta', async () => {
    const { supabase, insertados } = baseFalsa({ reportes_errores: [] });
    await registrarProblemaDeEntrega(supabase, 'email.bounced', { email_id: 'e2', to: ['a@b.test'], bounce: { type: 'Transient' } });
    expect(insertados).toHaveLength(0);
    await registrarProblemaDeEntrega(supabase, 'email.complained', { email_id: 'e3', to: ['a@b.test'], subject: 'Ya están tus fotos' });
    expect(insertados).toHaveLength(1);
    expect(insertados[0].detalle.tipo).toBe('queja_spam');
  });
});
