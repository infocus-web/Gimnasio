// Auditoría 25/10/2026: si la limpieza borró el .zip de un pedido (cancelado y después reactivado), /api/descargas
// usaba el link guardado «como último recurso» y la familia caía en un error de Storage para siempre. Ahora lo arma
// de nuevo.
import express from 'express';
import http from 'http';
import type { AddressInfo } from 'net';
import { afterAll, beforeAll, describe, expect, it, vi } from 'vitest';

const PEDIDO = '12345678-1234-4123-8123-123456789012';
const dobles = vi.hoisted(() => ({ existentes: new Set<string>(), generados: 0 }));

vi.mock('../../../servidor/nucleo/clientes', () => {
  const fila = { id: '12345678-1234-4123-8123-123456789012', pedido_friendly_id: 'IFS-2026-0001', estado: 'pagado', cancelado_definitivo: false, descargas_hd: 0, link_descarga_hd: 'https://x.supabase.co/storage/v1/object/sign/fotos-hd/zips-pedidos/borrado.zip?token=viejo' };
  const consulta: any = {
    select: () => consulta, eq: () => consulta, is: () => consulta, in: () => consulta,
    update: () => consulta, maybeSingle: async () => ({ data: fila, error: null }), single: async () => ({ data: fila, error: null }),
    then: (ok: any) => ok({ data: null, error: null }),
  };
  const supabase = {
    from: () => consulta,
    storage: {
      from: () => ({
        createSignedUrl: async (ruta: string) =>
          dobles.existentes.has(ruta) ? { data: { signedUrl: `https://firmada/${ruta}` }, error: null } : { data: null, error: { message: 'Object not found' } },
      }),
    },
  };
  return { getServerSupabase: () => supabase };
});
vi.mock('../../../servidor/entrega/zipHD', () => ({
  nombreZipHDPedido: (p: { id: string }) => `zips-pedidos/${p.id}.zip`,
  armarZipHDConTurno: async (_supabase: unknown, p: { id: string }) => {
    dobles.generados++;
    dobles.existentes.add(`zips-pedidos/${p.id}.zip`);
    return `https://firmada/zips-pedidos/${p.id}.zip?nuevo=1`;
  },
}));

let servidor: http.Server;
let puerto = 0;
let llave = '';

beforeAll(async () => {
  process.env.ADMIN_SESSION_SECRET = 'secreto-de-prueba-largo-para-hmac';
  const { rutasDescargas } = await import('../../../servidor/entrega/descargas');
  const { tokenAccesoPedido } = await import('../../../servidor/nucleo/accesoPedidos');
  llave = tokenAccesoPedido(PEDIDO) as string;
  const app = express();
  app.use(rutasDescargas);
  servidor = app.listen(0);
  await new Promise((ok) => servidor.once('listening', ok));
  puerto = (servidor.address() as AddressInfo).port;
});

afterAll(async () => {
  await new Promise((ok) => servidor.close(ok));
  delete process.env.ADMIN_SESSION_SECRET;
});

const bajar = () =>
  new Promise<{ status: number; location?: string }>((ok, mal) => {
    http.get({ host: '127.0.0.1', port: puerto, path: `/api/descargas/${PEDIDO}?t=${encodeURIComponent(llave)}&ir=1`, headers: { 'User-Agent': 'Mozilla/5.0' } }, (res) => {
      res.resume();
      ok({ status: res.statusCode || 0, location: res.headers.location });
    }).on('error', mal);
  });

describe('descarga HD con el .zip borrado', () => {
  it('arma el .zip de nuevo en vez de mandar al link guardado (roto)', async () => {
    const r = await bajar();
    expect(r.status).toBe(302);
    expect(r.location).toContain('?nuevo=1');
    expect(r.location).not.toContain('borrado.zip');
    expect(dobles.generados).toBe(1);
    // Ya armado: la siguiente descarga firma el .zip existente sin rearmarlo.
    const otra = await bajar();
    expect(otra.location).toBe(`https://firmada/zips-pedidos/${PEDIDO}.zip`);
    expect(dobles.generados).toBe(1);
  });
});
