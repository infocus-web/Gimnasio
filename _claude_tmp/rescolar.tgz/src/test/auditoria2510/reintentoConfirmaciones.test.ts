// Auditoría 25/10/2026: el cron reintentar-hd también reenvía las confirmaciones de reserva y de mejora a Kit
// Impreso cuyo correo falló (antes quedaban con email_enviado=false sin reintento ni alerta).
import { afterAll, beforeAll, beforeEach, describe, expect, it, vi } from 'vitest';
import * as base from '../auditoria1110/pagos/baseFalsa';

vi.mock('dotenv', () => {
  const config = () => ({ parsed: {} });
  return { default: { config }, config };
});
vi.mock('@supabase/supabase-js', async () => {
  const m = await import('../auditoria1110/pagos/baseFalsa');
  return { createClient: () => m.cliente };
});
const dobles = vi.hoisted(() => ({ correos: [] as Array<{ mensaje: any; opciones: any }> }));
vi.mock('resend', () => ({
  Resend: class {
    emails = { send: async (mensaje: any, opciones?: any) => (dobles.correos.push({ mensaje, opciones }), { data: { id: 'mail' }, error: null }) };
    batch = { send: async () => ({ data: { data: [] }, error: null }) };
  },
}));

let reintentar: (supabase: any) => Promise<{ revisadas: number; enviadas: number }>;
const hace = (horas: number) => new Date(Date.now() - horas * 3600_000).toISOString();

beforeAll(async () => {
  process.env.SUPABASE_URL = 'https://x.supabase.co';
  process.env.SUPABASE_SERVICE_ROLE_KEY = 'prueba';
  process.env.RESEND_API_KEY = 'prueba';
  process.env.CRON_SECRET = 'secreto-cron';
  reintentar = (await import('../../../servidor/tareasProgramadas')).reintentarConfirmacionesPendientes;
}, 120_000);

afterAll(async () => {
  for (const n of ['SUPABASE_URL', 'SUPABASE_SERVICE_ROLE_KEY', 'RESEND_API_KEY', 'CRON_SECRET']) delete process.env[n];
});

beforeEach(() => {
  base.reiniciar();
  dobles.correos = [];
});

const correrCron = async () => ({ status: 200, json: { confirmaciones: await reintentar(base.cliente) } });

describe('cron reintentar-hd: confirmaciones de reserva y mejora', () => {
  it('reenvía la confirmación de una reserva pagada cuyo correo falló, una sola vez', async () => {
    base.filas('familias').push({ id: 'fam-1', nombre: 'Ana', email: 'mama@prueba.test' });
    base.filas('pedidos').push(
      { id: 'r1', familia_id: 'fam-1', familias: { nombre: 'Ana', email: 'mama@prueba.test' }, estado: 'pagado', seleccion_pendiente: true, email_enviado: false, pagado_at: hace(2), created_at: hace(2), pedido_friendly_id: 'IFS-2026-0001', total: 30000, alumno_nombre: 'Lola' },
      // Recién pagada (dentro de la gracia del webhook) y vieja (más de 14 días): no.
      { id: 'r2', familia_id: 'fam-1', familias: { nombre: 'Ana', email: 'mama@prueba.test' }, estado: 'pagado', seleccion_pendiente: true, email_enviado: false, pagado_at: hace(0.05), created_at: hace(0.05) },
      { id: 'r3', familia_id: 'fam-1', familias: { nombre: 'Ana', email: 'mama@prueba.test' }, estado: 'pagado', seleccion_pendiente: true, email_enviado: false, pagado_at: hace(24 * 20), created_at: hace(24 * 20) },
    );
    const r = await correrCron();
    expect(r.status).toBe(200);
    expect(r.json.confirmaciones).toMatchObject({ revisadas: 1, enviadas: 1 });
    expect(dobles.correos.map((c) => c.opciones?.idempotencyKey)).toEqual(['reserva-confirmada-r1']);
    expect(base.filas('pedidos').find((p) => p.id === 'r1').email_enviado).toBe(true);
    dobles.correos = [];
    await correrCron();
    expect(dobles.correos).toHaveLength(0);
  });
});
