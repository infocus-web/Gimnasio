// MODO MANTENIMIENTO (09/10/2026, pedido de Pablo). Routing Middleware de Vercel: corre antes que
// todo lo demás (páginas, archivos y /api). Si en la tabla `configuracion` la clave 'mantenimiento'
// vale 'activo', muestra la pantalla de mantenimiento (503) a todos, salvo:
//   - las rutas libres (avisos de pago, correo entrante, tareas automáticas, ingreso de Pablo);
//   - quien tenga la cookie con la llave firmada (Pablo, después de poner su PIN en esa pantalla).
// Se prende y apaga desde el panel (Estado del sistema → Modo mantenimiento), sin volver a publicar.
// Si la base no responde, la web sigue andando normal (nunca queda trabada en mantenimiento).
import {
  CLAVE_CONFIG_MANTENIMIENTO,
  COOKIE_MANTENIMIENTO,
  leerCookie,
  llaveMantenimientoValida,
  paginaMantenimiento,
  rutaLibreEnMantenimiento,
  TEXTO_MANTENIMIENTO,
} from './mantenimiento/llave.js';

const CACHE_MS = 10_000;
let cache: { activo: boolean; hasta: number } | null = null;

// Mismos valores públicos que usa el navegador (src/services/supabaseClient.ts): la clave pública sólo
// puede leer `configuracion`.
const SUPABASE_URL_DEFECTO = 'https://ntkqypxvrljuihbxdrtx.supabase.co';
const SUPABASE_CLAVE_PUBLICA_DEFECTO = 'sb_publishable_94eG1ynOFoTUTPfcKgBwlw_rfhcRNbT';

async function mantenimientoActivo(): Promise<boolean> {
  const ahora = Date.now();
  if (cache && cache.hasta > ahora) return cache.activo;
  let activo = false;
  try {
    const url = (process.env.VITE_SUPABASE_URL || process.env.SUPABASE_URL || SUPABASE_URL_DEFECTO).replace(/\/+$/, '');
    const clave = process.env.VITE_SUPABASE_ANON_KEY || process.env.SUPABASE_ANON_KEY || SUPABASE_CLAVE_PUBLICA_DEFECTO;
    if (clave) {
      const resp = await fetch(`${url}/rest/v1/configuracion?clave=eq.${CLAVE_CONFIG_MANTENIMIENTO}&select=valor`, {
        headers: { apikey: clave, Authorization: `Bearer ${clave}` },
        signal: AbortSignal.timeout(1500),
      });
      if (resp.ok) {
        const filas = (await resp.json()) as Array<{ valor?: string }>;
        activo = Array.isArray(filas) && filas[0]?.valor === 'activo';
      }
    }
  } catch {
    activo = false; // falla abierto: sin base, la web anda normal
  }
  cache = { activo, hasta: ahora + CACHE_MS };
  return activo;
}

/** Igual que next() de @vercel/functions: deja seguir el pedido. */
function seguir(): Response {
  return new Response(null, { headers: { 'x-middleware-next': '1' } });
}

export default async function middleware(request: Request): Promise<Response> {
  const url = new URL(request.url);
  if (rutaLibreEnMantenimiento(url.pathname)) return seguir();
  if (!(await mantenimientoActivo())) return seguir();

  const secreto = process.env.ADMIN_SESSION_SECRET?.trim();
  const llave = leerCookie(request.headers.get('cookie'), COOKIE_MANTENIMIENTO);
  if (await llaveMantenimientoValida(secreto, llave)) return seguir();

  const comunes = { 'Cache-Control': 'no-store', 'Retry-After': '3600', 'X-Robots-Tag': 'noindex' };
  if (url.pathname.startsWith('/api/') || url.pathname.startsWith('/mercadopago/')) {
    return new Response(JSON.stringify({ success: false, mantenimiento: true, error: TEXTO_MANTENIMIENTO }), {
      status: 503,
      headers: { ...comunes, 'Content-Type': 'application/json; charset=utf-8' },
    });
  }
  const error = url.searchParams.get('mantenimiento');
  return new Response(paginaMantenimiento(error === 'pin' || error === 'muchos' ? error : null), {
    status: 503,
    headers: { ...comunes, 'Content-Type': 'text/html; charset=utf-8' },
  });
}
