import Link from 'next/link'
import { notFound } from 'next/navigation'
import type { Metadata, Route } from 'next'
import { ArrowLeft, Smartphone, UserPlus, Crown, Info } from 'lucide-react'
import { getAdminContext } from '@/features/admin/context'
import { createClient } from '@/lib/supabase/server'
import { adjustMembershipEnd, assignPlan, deleteMember, inviteMemberToApp, removeMedicalCert, saveMedicalCert, sendAccessLink, updateMember, updateMemberPhoto } from '@/features/admin/actions'
import { MedicalCertCard, MemberPhotoForm } from '@/features/admin/MemberFileForms'
import { signedUrl } from '@/features/admin/member-files'
import { DeleteMemberButton } from '@/features/admin/DeleteMemberButton'
import { recordPayment } from '@/features/admin/billing-actions'
import { assignTrainer } from '@/features/admin/coach-actions'
import { TrainerSelectForm } from '@/features/admin/CoachForms'
import { METHOD_LABELS, PaymentForm } from '@/features/admin/PaymentForms'
import { cancelSubscriptionAction, createPaymentLink } from '@/features/payments/actions'
import { ConfirmAction } from '@/features/admin/ConfirmAction'
import { mpConfigured } from '@/features/payments/mercadopago'
import { PaymentLinkButton } from '@/features/payments/PaymentLinkButton'
import { CHECKIN_REASON, fmtDate, fmtDateTime, formatMoney, planState, PLAN_STATE_UI, todayYMD } from '@/features/admin/format'
import { MemberForm } from '@/features/admin/MemberForm'
import { AdjustEndForm, AssignPlanForm, InviteButton } from '@/features/admin/MemberPanels'
import { Card } from '@/features/admin/ui'
import { InfoTip } from '@/components/InfoTip'
import { EnrollForm } from '@/features/admin/AccessForms'
import { enrollMember } from '@/features/admin/access-actions'

export const metadata: Metadata = { title: 'Ficha de socio' }

export default async function MemberDetailPage({ params, searchParams }: PageProps<'/[org]/admin/socios/[memberId]'>) {
  const { org: slug, memberId } = await params
  const sp = await searchParams
  const aviso = typeof sp.aviso === 'string' ? sp.aviso.slice(0, 300) : null

  const ctx = await getAdminContext(slug)
  if (!ctx) return null // sin sesión de staff: el layout ya muestra el aviso
  if (!ctx.can('members.read')) return <p className="text-sm text-zinc-400">No tenés permiso para ver socios.</p>

  const supabase = await createClient()
  const { data: m } = await supabase
    .from('member_directory')
    .select('*')
    .eq('id', memberId)
    .eq('org_id', ctx.org.id)
    .maybeSingle()
  if (!m) notFound()

  const [{ data: staffList }, { data: tc }] = await Promise.all([
    // Profesores (y dueño/admin, que también pueden dar clase); recepción no
    supabase.from('staff').select('id, display_name, role').eq('org_id', ctx.org.id).eq('active', true).neq('role', 'staff').order('display_name'),
    supabase.from('trainer_clients').select('trainer_id').eq('member_id', memberId).maybeSingle(),
  ])
  const [family, checkins, plans, payments] = await Promise.all([
    m.billing_account_id
      ? supabase
          .from('member_directory')
          .select('id, first_name, last_name, is_payer, has_app, status')
          .eq('billing_account_id', m.billing_account_id)
          .neq('status', 'archived')
          .order('is_payer', { ascending: false })
          .order('first_name')
      : Promise.resolve({ data: [] as { id: string; first_name: string; last_name: string; is_payer: boolean; has_app: boolean; status: string }[] }),
    supabase
      .from('checkins')
      .select('id, created_at, allowed, reason, method')
      .eq('member_id', memberId)
      .order('created_at', { ascending: false })
      .limit(10),
    supabase
      .from('membership_plans')
      .select('id, name, price_cents, currency, max_members')
      .eq('org_id', ctx.org.id)
      .eq('active', true)
      .order('sort')
      .order('price_cents'),
    m.billing_account_id && ctx.can('billing.read')
      ? supabase
          .from('payment_ledger')
          .select('id, paid_at, amount_cents, currency, provider, status, plan_name, note')
          .eq('billing_account_id', m.billing_account_id)
          .order('paid_at', { ascending: false })
          .limit(12)
      : Promise.resolve({ data: [] as { id: string | null; paid_at: string | null; amount_cents: number | null; currency: string | null; provider: string | null; status: string | null; plan_name: string | null; note: string | null }[] }),
  ])

  // Lectores de acceso (cara/palma/huella)
  const [{ data: pinRow }, { data: accessDevices }] = await Promise.all([
    supabase
      .from('members')
      .select('access_pin, gender, biometric_consent_at, photo_url, medical_cert_path, medical_cert_uploaded_at, medical_cert_expires_on')
      .eq('id', memberId)
      .maybeSingle(),
    supabase.from('access_devices').select('id, name, info').eq('org_id', ctx.org.id).eq('active', true).order('created_at'),
  ])
  const accessPin = pinRow?.access_pin ?? null
  // Lectores manejados por el intermediario de la PC (ej. MB360): no aceptan el registro de cara a distancia
  const agentMode = (d: { info: unknown }) =>
    ((d.info as { agent?: { mode?: string } } | null)?.agent?.mode ?? null) as 'lectura' | 'sincronizar' | null
  const localDevices = (accessDevices ?? []).filter((d) => agentMode(d))
  const remoteDevices = (accessDevices ?? []).filter((d) => !agentMode(d))
  // Foto y apto físico: archivos privados, se muestran con links que vencen en 10 minutos
  const [photoSrc, certUrl] = await Promise.all([
    signedUrl(supabase, pinRow?.photo_url),
    signedUrl(supabase, pinRow?.medical_cert_path),
  ])
  const certExpires = pinRow?.medical_cert_expires_on ?? null
  const certExpired = !!certExpires && certExpires < todayYMD(ctx.org.timezone)
  const [{ data: onDevices }, { data: lastEnroll }, { data: pendingPuts }] =
    accessPin && accessDevices?.length
      ? await Promise.all([
          supabase.from('access_device_users').select('device_id, state, has_bio').eq('org_id', ctx.org.id).eq('pin', accessPin),
          supabase
            .from('access_commands')
            .select('status, return_code, created_at')
            .eq('member_id', memberId)
            .eq('kind', 'enroll')
            .order('created_at', { ascending: false })
            .limit(1)
            .maybeSingle(),
          // Altas que el intermediario todavía no hizo (en modo "lectura" no las hace nunca)
          supabase.from('access_commands').select('device_id').eq('member_id', memberId).eq('kind', 'user_put').eq('status', 'pending'),
        ])
      : [{ data: [] as { device_id: string; state: string; has_bio: boolean }[] }, { data: null }, { data: [] as { device_id: string }[] }]

  // Débito automático de la cuenta (0056)
  const { data: debit } =
    m.billing_account_id && ctx.can('billing.read')
      ? await supabase
          .from('mp_subscriptions')
          .select('id, status, amount_cents, currency, next_payment_date, last_payment_at, last_failure_at, last_failure_detail, payer_email')
          .eq('billing_account_id', m.billing_account_id)
          .in('status', ['pending', 'authorized', 'paused'])
          .order('created_at', { ascending: false })
          .limit(1)
          .maybeSingle()
      : { data: null }
  const debitFailing =
    !!debit && !!debit.last_failure_at && (!debit.last_payment_at || debit.last_failure_at > debit.last_payment_at) && debit.status !== 'pending'
  const st = PLAN_STATE_UI[planState(m as { membership_status: string | null; current_period_end: string | null; status: string })]
  const payer = (family.data ?? []).find((f) => f.is_payer)
  const canWrite = ctx.can('members.write')
  const canBill = ctx.can('billing.write')
  const planOptions = (plans.data ?? []).map((p) => ({
    id: p.id,
    label: `${p.name} · ${formatMoney(p.price_cents, p.currency)}${p.max_members > 1 ? ` · hasta ${p.max_members}` : ''}`,
  }))

  return (
    <div className="space-y-5">
      <Link href={`/${slug}/admin/socios` as Route} className="inline-flex items-center gap-1 text-sm text-zinc-400 hover:text-white">
        <ArrowLeft className="h-4 w-4" aria-hidden="true" /> Socios
      </Link>

      <div className="flex flex-wrap items-center gap-3">
        <h1 className="text-2xl font-extrabold text-white">
          {m.first_name} {m.last_name}
        </h1>
        <span className={`rounded-md border px-2 py-0.5 text-xs font-semibold ${st.className}`}>{st.label}</span>
        {accessPin && (
          <span className="rounded-md border border-[#edcc36]/40 bg-[#edcc36]/10 px-2 py-0.5 font-mono text-xs font-semibold text-[#edcc36]">
            N° de socio {accessPin}
          </span>
        )}
        {certExpired && (
          <span className="rounded-md border border-red-500/40 bg-red-500/10 px-2 py-0.5 text-xs font-semibold text-red-300">Apto vencido</span>
        )}
        {!pinRow?.medical_cert_path && (
          <span className="rounded-md border border-amber-500/40 bg-amber-500/10 px-2 py-0.5 text-xs font-semibold text-amber-200">Sin apto físico</span>
        )}
        {m.status === 'archived' && (
          <span className="rounded-md border border-zinc-700 px-2 py-0.5 text-xs text-zinc-400">Archivado</span>
        )}
      </div>

      {aviso && (
        <p role="status" className="flex items-start gap-2 rounded-xl border border-[#edcc36]/30 bg-[#edcc36]/10 p-3 text-sm text-zinc-100">
          <Info className="mt-0.5 h-4 w-4 shrink-0 text-[#edcc36]" aria-hidden="true" /> {aviso}
        </p>
      )}

      <div className="grid gap-5 lg:grid-cols-[1.4fr_1fr]">
        <div className="space-y-5">
          <Card title="Datos">
            <MemberForm
              mode="edit"
              readOnly={!canWrite}
              action={updateMember.bind(null, slug, memberId)}
              values={{
                firstName: m.first_name ?? '',
                lastName: m.last_name ?? '',
                email: m.email,
                phone: m.phone,
                documentId: m.document_id,
                birthDate: m.birth_date,
                gender: pinRow?.gender ?? null,
                medicalNotes: m.medical_notes,
                status: m.status ?? 'active',
              }}
            />
          </Card>

          <Card title="Plan">
            <dl className="mb-4 grid grid-cols-2 gap-3 text-sm sm:grid-cols-3">
              <div>
                <dt className="text-xs text-zinc-500">Plan</dt>
                <dd className="font-semibold text-white">{m.plan_name ?? 'Sin plan'}</dd>
              </div>
              <div>
                <dt className="text-xs text-zinc-500">Vence</dt>
                <dd className="font-semibold tabular-nums text-white">{fmtDate(m.current_period_end)}</dd>
              </div>
              {m.credits_remaining != null && (
                <div>
                  <dt className="text-xs text-zinc-500">Clases restantes</dt>
                  <dd className="font-semibold tabular-nums text-white">{m.credits_remaining}</dd>
                </div>
              )}
            </dl>
            {debit && (
              <div
                className={`mb-4 rounded-xl border p-3 text-sm ${
                  debitFailing
                    ? 'border-amber-400/40 bg-amber-400/10 text-amber-100'
                    : debit.status === 'pending'
                      ? 'border-zinc-700 bg-zinc-900 text-zinc-300'
                      : 'border-emerald-500/40 bg-emerald-500/10 text-emerald-100'
                }`}
              >
                <p className="font-semibold">
                  {debit.status === 'pending'
                    ? 'Débito automático: falta que autorice en Mercado Pago'
                    : debit.status === 'paused'
                      ? 'Débito automático pausado en Mercado Pago'
                      : `Débito automático activo · ${formatMoney(Number(debit.amount_cents), debit.currency)}`}
                </p>
                {debit.next_payment_date && debit.status !== 'pending' && (
                  <p className="text-xs opacity-80">Próximo cobro: {fmtDate(debit.next_payment_date)}</p>
                )}
                {debitFailing && (
                  <p className="text-xs">
                    Último cobro rechazado el {fmtDate(debit.last_failure_at)}
                    {debit.last_failure_detail ? ` (${debit.last_failure_detail})` : ''}. Mercado Pago lo reintenta.
                  </p>
                )}
                <p className="text-xs opacity-70">Cuenta de Mercado Pago: {debit.payer_email}</p>
                {canBill && (
                  <ConfirmAction
                    action={cancelSubscriptionAction.bind(null, slug, debit.id, 'panel')}
                    confirmText="No se le van a hacer más cobros automáticos. El plan sigue hasta su vencimiento."
                    yesLabel="Sí, dar de baja"
                    className="mt-2 space-y-2"
                  >
                    Dar de baja el débito
                  </ConfirmAction>
                )}
              </div>
            )}
            {m.is_payer || !m.billing_account_id ? (
              canBill ? (
                <>
                  <AssignPlanForm
                    action={assignPlan.bind(null, slug, memberId)}
                    plans={planOptions}
                    today={todayYMD(ctx.org.timezone)}
                    currentPlanId={m.plan_id}
                  />
                  {m.membership_id && (
                    <AdjustEndForm
                      action={adjustMembershipEnd.bind(null, slug, memberId)}
                      current={
                        m.current_period_end
                          ? new Intl.DateTimeFormat('en-CA', { timeZone: ctx.org.timezone }).format(new Date(m.current_period_end))
                          : null
                      }
                    />
                  )}
                </>
              ) : null
            ) : payer ? (
              <p className="text-sm text-zinc-400">
                El plan lo maneja el titular del grupo:{' '}
                <Link href={`/${slug}/admin/socios/${payer.id}` as Route} className="font-semibold text-[#edcc36]">
                  {payer.first_name} {payer.last_name}
                </Link>
              </p>
            ) : null}
          </Card>
          {canBill && (
            <div id="cobrar" className="scroll-mt-24">
              <Card title="Registrar cobro">
                {m.is_payer || !m.billing_account_id ? null : (
                  <p className="mb-3 text-xs text-zinc-500">El cobro se imputa a la cuenta del titular del grupo familiar.</p>
                )}
                <PaymentForm
                  action={recordPayment.bind(null, slug, memberId)}
                  plans={(plans.data ?? []).map((p) => ({ id: p.id, label: `${p.name} · ${formatMoney(p.price_cents, p.currency)}`, priceCents: p.price_cents }))}
                  currentPlanId={m.plan_id}
                  extra={
                    mpConfigured() ? (
                      <div className="mt-4 border-t border-zinc-900 pt-4">
                        <PaymentLinkButton action={createPaymentLink.bind(null, slug, memberId)} />
                      </div>
                    ) : null
                  }
                />
              </Card>
            </div>
          )}

          {ctx.can('billing.read') && (
            <Card title="Pagos">
              {payments.data?.length ? (
                <ul className="divide-y divide-zinc-900 text-sm">
                  {payments.data.map((p) => (
                    <li key={p.id} className={`flex items-center justify-between gap-3 py-2 ${p.status === 'succeeded' ? '' : 'opacity-50'}`}>
                      <span className="min-w-0">
                        <span className="tabular-nums text-zinc-200">{fmtDate(p.paid_at)}</span>
                        <span className="block truncate text-xs text-zinc-500">
                          {[p.plan_name, METHOD_LABELS[p.provider ?? ''] ?? p.provider, p.status !== 'succeeded' && 'anulado', p.note].filter(Boolean).join(' · ')}
                        </span>
                      </span>
                      <span className={`tabular-nums font-semibold ${p.status === 'succeeded' ? 'text-white' : 'line-through text-zinc-500'}`}>
                        {formatMoney(Number(p.amount_cents), p.currency ?? 'ARS')}
                      </span>
                    </li>
                  ))}
                </ul>
              ) : (
                <p className="text-sm text-zinc-500">Todavía no hay pagos registrados.</p>
              )}
            </Card>
          )}
        </div>

        <div className="space-y-5">
          <Card title="Foto">
            <MemberPhotoForm current={photoSrc} canWrite={canWrite} action={updateMemberPhoto.bind(null, slug, memberId)} />
          </Card>

          <Card title="Apto físico">
            <MedicalCertCard
              orgId={ctx.org.id}
              memberId={memberId}
              viewUrl={certUrl}
              uploadedLabel={pinRow?.medical_cert_uploaded_at ? fmtDate(pinRow.medical_cert_uploaded_at, ctx.org.timezone) : null}
              expiresOn={certExpires ? fmtDate(certExpires, ctx.org.timezone) : null}
              expired={certExpired}
              canWrite={canWrite}
              save={saveMedicalCert.bind(null, slug, memberId)}
              remove={removeMedicalCert.bind(null, slug, memberId)}
            />
          </Card>

          <Card title="Profesor a cargo">
            {canWrite ? (
              <TrainerSelectForm
                action={assignTrainer.bind(null, slug, memberId)}
                trainers={(staffList ?? []).map((t) => ({ id: t.id, name: t.display_name }))}
                current={tc?.trainer_id ?? null}
              />
            ) : (
              <p className="text-sm text-zinc-400">
                {(staffList ?? []).find((t) => t.id === tc?.trainer_id)?.display_name ?? 'Sin profesor asignado'}
              </p>
            )}
            <p className="mt-2 text-xs text-zinc-500">El profe ve su progreso y le asigna rutinas.</p>
          </Card>

          <Card title="Acceso a la app">
            {m.has_app ? (
              <div className="space-y-3">
                <p className="flex items-center gap-2 text-sm text-emerald-200">
                  <Smartphone className="h-4 w-4" aria-hidden="true" /> Tiene cuenta y puede entrar a la app.
                </p>
                {canWrite && m.email && (
                  <InviteButton action={sendAccessLink.bind(null, slug, memberId)} label="Enviarle link para entrar" />
                )}
              </div>
            ) : (
              <div className="space-y-3">
                <p className="text-sm text-zinc-400">
                  {m.email ? (
                    <>
                      Todavía no entró. La invitación le llega a <strong className="text-white">{m.email}</strong>.
                    </>
                  ) : (
                    'Cargale un email en Datos para poder invitarlo.'
                  )}
                </p>
                {canWrite && m.email && <InviteButton action={inviteMemberToApp.bind(null, slug, memberId)} />}
              </div>
            )}
          </Card>

          {accessPin && accessDevices && accessDevices.length > 0 && (
            <Card title="Acceso con lector">
              <p className="text-sm text-zinc-400">
                Número en el lector: <strong className="font-mono text-white">{accessPin}</strong>
              </p>
              <ul className="mt-2 space-y-1 text-sm">
                {accessDevices.map((d) => {
                  const u = (onDevices ?? []).find((x) => x.device_id === d.id)
                  const label =
                    agentMode(d) && (!u || u.state !== 'present' || (pendingPuts ?? []).some((x) => x.device_id === d.id))
                      ? ['Falta darlo de alta en el lector', 'text-amber-300']
                      : agentMode(d)
                        ? ['Está en el lector (la cara se registra en el equipo)', 'text-emerald-300']
                        : !u || u.state === 'absent'
                      ? ['No cargado (no está al día)', 'text-zinc-500']
                      : u.state === 'error'
                        ? ['El lector rechazó el alta', 'text-red-300']
                        : u.has_bio
                          ? ['Cargado · puede entrar', 'text-emerald-300']
                          : ['Cargado · falta registrar cara', 'text-amber-300']
                  return (
                    <li key={d.id} className="flex justify-between gap-2">
                      <span className="text-zinc-300">{d.name}</span>
                      <span className={label[1]}>{label[0]}</span>
                    </li>
                  )
                })}
              </ul>
              {lastEnroll?.status === 'error' && (
                <p className="mt-2 text-xs text-amber-300">
                  El lector no aceptó el registro a distancia: registralo desde el lector (Menú → Usuarios → buscar {accessPin} → Cara).
                </p>
              )}
              {localDevices.length > 0 && (
                <div className="mt-3 space-y-2 border-t border-zinc-900 pt-3 text-sm text-zinc-300">
                  <p className="font-semibold text-white">Registrar la cara en el lector ({localDevices.map((d) => d.name).join(', ')})</p>
                  <p className="text-xs text-zinc-400">Este lector registra la cara en el propio equipo (no se puede hacer a distancia):</p>
                  <ol className="list-decimal space-y-1 pl-5">
                    {localDevices.some(
                      (d) =>
                        !(onDevices ?? []).some((x) => x.device_id === d.id && x.state === 'present') ||
                        (pendingPuts ?? []).some((x) => x.device_id === d.id),
                    ) ? (
                      <>
                        <li>
                          En el lector: <strong>Menú → Usuarios → Nuevo usuario</strong>.
                        </li>
                        <li>
                          N° de usuario (ID): <strong className="font-mono text-white">{accessPin}</strong> · Nombre: {m.first_name} {m.last_name}.
                        </li>
                      </>
                    ) : (
                      <li>
                        En el lector: <strong>Menú → Usuarios</strong> → buscar <strong className="font-mono text-white">{accessPin}</strong>.
                      </li>
                    )}
                    <li>
                      Tocá <strong>Cara</strong>, que el socio mire la pantalla del lector, y <strong>Guardar</strong>.
                    </li>
                  </ol>
                  <p className="text-xs text-zinc-500">En 1 o 2 minutos el intermediario lo informa y acá pasa a “Cargado · puede entrar”.</p>
                </div>
              )}
              {ctx.can('checkins.manage') && remoteDevices.length > 0 && (
                <div className="mt-3 border-t border-zinc-900 pt-3">
                  <EnrollForm action={enrollMember.bind(null, slug, memberId)} devices={remoteDevices} />
                </div>
              )}
            </Card>
          )}

          <Card
            title="Grupo familiar"
            action={
              <span className="flex items-center gap-3">
                {canWrite && m.is_payer && (
                  <Link
                    href={`/${slug}/admin/socios/nuevo?titular=${memberId}` as Route}
                    className="inline-flex items-center gap-1 text-xs font-semibold text-[#edcc36]"
                  >
                    <UserPlus className="h-3.5 w-3.5" aria-hidden="true" /> Agregar integrante
                  </Link>
                )}
                <InfoTip label="Grupo familiar y titular">
                  <p>
                    El <strong>titular</strong> (la corona) es quien paga: los cobros se registran a su nombre y su plan cubre a todos los
                    integrantes, hasta la cantidad de personas que permite el plan.
                  </p>
                  <p>Si la cuenta del titular queda vencida o con deuda, ningún integrante del grupo puede entrar.</p>
                  <p>«Agregar integrante» da de alta a un socio nuevo (hijo, pareja) dentro de este grupo.</p>
                </InfoTip>
              </span>
            }
          >
            {(family.data ?? []).length > 1 ? (
              <ul className="divide-y divide-zinc-900">
                {(family.data ?? []).map((f) => (
                  <li key={f.id}>
                    <Link
                      href={`/${slug}/admin/socios/${f.id}` as Route}
                      aria-current={f.id === memberId ? 'page' : undefined}
                      className={`flex items-center justify-between gap-2 py-2 text-sm ${f.id === memberId ? 'text-[#edcc36]' : 'text-zinc-200 hover:text-white'}`}
                    >
                      <span className="truncate">
                        {f.first_name} {f.last_name}
                      </span>
                      {f.is_payer && (
                        <span className="inline-flex items-center gap-1 text-xs text-zinc-400">
                          <Crown className="h-3 w-3" aria-hidden="true" /> Titular
                        </span>
                      )}
                    </Link>
                  </li>
                ))}
              </ul>
            ) : (
              <p className="text-sm text-zinc-500">
                {m.is_payer ? 'Sin integrantes. Con un plan familiar podés sumar hijos o pareja.' : 'No pertenece a un grupo familiar.'}
              </p>
            )}
          </Card>

          <Card title="Últimas entradas">
            {checkins.data?.length ? (
              <ul className="space-y-1.5 text-sm">
                {checkins.data.map((c) => (
                  <li key={c.id} className="flex justify-between gap-2">
                    <span className="tabular-nums text-zinc-300">{fmtDateTime(c.created_at)}</span>
                    <span className={c.allowed ? 'text-emerald-300' : 'text-red-300'}>{c.allowed ? 'Ingresó' : `Rechazado${c.reason && CHECKIN_REASON[c.reason] ? ` · ${CHECKIN_REASON[c.reason]}` : ''}`}</span>
                  </li>
                ))}
              </ul>
            ) : (
              <p className="text-sm text-zinc-500">Sin entradas registradas.</p>
            )}
          </Card>

          {ctx.can('org.manage') && (
            <Card title="Eliminar">
              <DeleteMemberButton
                action={deleteMember.bind(null, slug, memberId)}
                name={`${m.first_name ?? ''} ${m.last_name ?? ''}`.trim()}
              />
            </Card>
          )}
        </div>
      </div>
    </div>
  )
}
