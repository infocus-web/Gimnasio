import 'server-only'
import { createAdminClient } from '@/lib/supabase/admin'
import { getPayment, type MpPayment } from './mercadopago'
import { sendDayPassEmailOnce } from './day-pass'
import { sendSignupAccessOnce } from './signup'
import { settleSubscriptionMpPayment } from './subscriptions'

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i

export type SyncResult =
  | { ok: true; intentId: string; status: string; duplicate?: boolean; periodEnd?: string | null; dayPass?: boolean; signup?: boolean }
  | { ok: false; reason: 'NOT_FOUND' | 'NOT_OURS' | 'ERROR' }

/**
 * Trae el pago de la API de Mercado Pago y lo aplica a su intención (payment_intent_settle).
 * Lo usan el webhook y la pantalla de vuelta (así el plan queda renovado aunque el aviso tarde).
 * Idempotente: la base no registra dos veces el mismo pago.
 */
export async function syncMpPayment(paymentId: string): Promise<SyncResult> {
  const p = await getPayment(paymentId)
  if (!p) return { ok: false, reason: 'NOT_FOUND' }
  const intentId = p.external_reference ?? ''
  if (!UUID.test(intentId)) return subscriptionFallback(p)

  const { data, error } = await createAdminClient().rpc('payment_intent_settle', {
    p_intent: intentId,
    p_mp_payment_id: String(p.id),
    p_mp_status: p.status,
    p_status_detail: p.status_detail ?? '',
    p_amount_cents: Math.round(Number(p.transaction_amount) * 100),
    p_currency: p.currency_id,
  })
  if (error) {
    if (error.message.includes('INTENT_NOT_FOUND')) return subscriptionFallback(p)
    console.error('[mercadopago] settle', error.message)
    return { ok: false, reason: 'ERROR' }
  }
  const r = (data ?? {}) as {
    status?: string
    duplicate?: boolean
    result?: { period_end?: string; code?: string; member_id?: string; new_member?: boolean } | null
  }
  const dayPass = r.status === 'approved' && !!r.result?.code
  if (dayPass) {
    // Pase comprado en la web: se le manda el link por email (una sola vez)
    await sendDayPassEmailOnce(intentId).catch((e) => console.error('[pase online]', e instanceof Error ? e.message : e))
  }
  const signup = r.status === 'approved' && typeof r.result?.new_member === 'boolean'
  if (signup) {
    // Inscripción desde la web: email para entrar a la app (una sola vez)
    await sendSignupAccessOnce(intentId).catch((e) => console.error('[inscripción]', e instanceof Error ? e.message : e))
  }
  return { ok: true, intentId, status: r.status ?? 'pending', duplicate: r.duplicate, periodEnd: r.result?.period_end ?? null, dayPass, signup }
}

/** Cobro de un débito automático (no es de una intención de pago): se registra en su suscripción. */
async function subscriptionFallback(p: MpPayment): Promise<SyncResult> {
  const r = await settleSubscriptionMpPayment(p)
  if (!r.ok) return { ok: false, reason: r.reason }
  return { ok: true, intentId: r.subscriptionId, status: r.status }
}
