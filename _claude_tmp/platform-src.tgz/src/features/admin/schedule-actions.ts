'use server'

import { revalidatePath } from 'next/cache'
import { z } from 'zod'
import { createClient } from '@/lib/supabase/server'
import { getAdminContext } from './context'
import { dbMessage, ERRORS, formObject, type ActionState } from './errors'
import { WEEKDAYS } from './format'

async function guard(slug: string, perm: 'schedule.manage' | 'bookings.manage' = 'schedule.manage') {
  const ctx = await getAdminContext(slug)
  return ctx?.can(perm) ? ctx : null
}

/**
 * Acciones sobre UNA clase u horario: administración, o el profe en lo suyo (schedule.own).
 * La base verifica que la clase sea del profe (private.can_edit_class); acá solo filtramos quién puede intentarlo.
 */
async function classGuard(slug: string, perm: 'schedule.manage' | 'bookings.manage' = 'schedule.manage') {
  const ctx = await getAdminContext(slug)
  return ctx && (ctx.can(perm) || ctx.can('schedule.own')) ? ctx : null
}

function done(slug: string, message: string): ActionState {
  revalidatePath(`/${slug}/admin/agenda`, 'layout')
  revalidatePath(`/${slug}/admin/mis-clases`, 'layout')
  revalidatePath(`/${slug}`)
  return { ok: true, message }
}

/** Días tildados en el formulario (1 = lunes … 7 = domingo), sin repetir y en orden */
function weekdaysOf(form: FormData): number[] {
  const days = form
    .getAll('weekday')
    .map((v) => Number(v))
    .filter((n) => Number.isInteger(n) && n >= 1 && n <= 7)
  return [...new Set(days)].sort((a, b) => a - b)
}

function issues(err: z.ZodError): ActionState {
  const fe: Record<string, string> = {}
  for (const i of err.issues) fe[String(i.path[0])] ??= i.message
  return { fieldErrors: fe }
}

// ---------------------------------------------------------------------
// Clases (sesiones)
// ---------------------------------------------------------------------

export async function generateSessions(slug: string, _prev: ActionState): Promise<ActionState> {
  const ctx = await guard(slug)
  if (!ctx) return { message: ERRORS.FORBIDDEN }
  const supabase = await createClient()
  const { data, error } = await supabase.rpc('generate_sessions', { p_org: ctx.org.id, p_weeks: 4 })
  if (error) return { message: dbMessage(error) }
  const r = data as { created: number; skipped: number }
  const extra = r.skipped ? ` ${r.skipped} fechas se saltearon por choque de sala o profesor.` : ''
  return done(slug, r.created ? `Se crearon ${r.created} clases de las próximas 4 semanas.${extra}` : `Las próximas 4 semanas ya estaban al día.${extra}`)
}

export async function cancelSession(slug: string, sessionId: string, _prev: ActionState, form: FormData): Promise<ActionState> {
  const ctx = await classGuard(slug)
  if (!ctx) return { message: ERRORS.FORBIDDEN }
  const supabase = await createClient()
  const { data, error } = await supabase.rpc('cancel_session', {
    p_session: sessionId,
    p_reason: String(form.get('reason') ?? '').trim() || undefined,
  })
  if (error) return { message: dbMessage(error) }
  return done(slug, data ? `Clase cancelada. Se liberaron ${data} reservas.` : 'Clase cancelada.')
}

export async function bookForMember(slug: string, sessionId: string, _prev: ActionState, form: FormData): Promise<ActionState> {
  const ctx = await classGuard(slug, 'bookings.manage')
  if (!ctx) return { message: ERRORS.FORBIDDEN }
  const memberId = String(form.get('memberId') ?? '')
  if (!memberId) return { fieldErrors: { memberId: 'Elegí un socio de la lista' } }
  const supabase = await createClient()
  const { data, error } = await supabase.rpc('book_class', {
    p_session_id: sessionId,
    p_member_id: memberId,
    p_idempotency_key: `desk:${sessionId}:${memberId}:${String(form.get('nonce') ?? Date.now())}`,
  })
  if (error) return { message: dbMessage(error) }
  const status = (data as { status?: string } | null)?.status
  return done(slug, status === 'waitlisted' ? 'Clase llena: quedó en lista de espera.' : 'Reserva confirmada.')
}

export async function cancelBookingDesk(slug: string, bookingId: string, _prev?: ActionState): Promise<ActionState> {
  const ctx = await classGuard(slug, 'bookings.manage')
  if (!ctx) return { message: ERRORS.FORBIDDEN }
  const supabase = await createClient()
  const { data, error } = await supabase.rpc('cancel_booking', { p_booking_id: bookingId })
  if (error) {
    if (error.message.trim() === 'BOOKING_NOT_FOUND') return { message: 'Esa reserva ya no existe. Recargá la página.' }
    return { message: dbMessage(error) }
  }
  const status = (data as { status?: string } | null)?.status
  return done(slug, status === 'late_canceled' ? 'Reserva cancelada (fuera de término: no se devuelve la clase del pack).' : 'Reserva cancelada.')
}

// ---------------------------------------------------------------------
// Grilla semanal
// ---------------------------------------------------------------------

const seriesSchema = z.object({
  classTypeId: z.uuid('Elegí la actividad'),
  roomId: z.uuid('Elegí la sala'),
  instructorId: z.uuid('Elegí el profesor'),
  weekday: z.coerce.number().int().min(1).max(7),
  startTime: z.string().regex(/^\d{2}:\d{2}$/, 'Hora inválida'),
  durationMin: z.coerce.number().int().min(5, 'Mínimo 5 minutos').max(480),
  capacity: z.coerce.number().int().min(1, 'Mínimo 1 lugar').max(500),
  validFrom: z.string().optional(),
})

export async function createSeries(slug: string, _prev: ActionState, form: FormData): Promise<ActionState> {
  const ctx = await guard(slug)
  if (!ctx) return { message: ERRORS.FORBIDDEN }
  const days = weekdaysOf(form)
  if (!days.length) return { fieldErrors: { weekday: 'Elegí al menos un día' } }
  const parsed = seriesSchema.safeParse({ ...formObject(form), weekday: days[0] })
  if (!parsed.success) return issues(parsed.error)
  const s = parsed.data
  const supabase = await createClient()
  // Misma clase en varios días: un horario fijo por cada día tildado
  const { error } = await supabase.from('class_series').insert(
    days.map((weekday) => ({
      org_id: ctx.org.id,
      class_type_id: s.classTypeId,
      room_id: s.roomId,
      instructor_id: s.instructorId,
      weekday,
      start_time: s.startTime,
      duration_min: s.durationMin,
      capacity: s.capacity,
      ...(s.validFrom ? { valid_from: s.validFrom } : {}),
    })),
  )
  if (error) return { message: dbMessage(error) }
  const gen = await supabase.rpc('generate_sessions', { p_org: ctx.org.id, p_weeks: 4 })
  const r = (gen.data ?? { created: 0, skipped: 0 }) as { created: number; skipped: number }
  const warn = r.skipped ? ` Atención: ${r.skipped} fechas chocan con otra clase (misma sala o profe) y no se crearon.` : ''
  const label = days.length > 1 ? `${days.length} horarios agregados (${days.map((d) => WEEKDAYS[d - 1]).join(', ')})` : 'Horario agregado'
  return done(slug, `${label}. Se crearon ${r.created} clases.${warn}`)
}

export async function updateSeries(slug: string, seriesId: string, _prev: ActionState, form: FormData): Promise<ActionState> {
  const ctx = await guard(slug)
  if (!ctx) return { message: ERRORS.FORBIDDEN }
  const raw = formObject(form)
  const parsed = z
    .object({ roomId: z.uuid(), instructorId: z.uuid(), capacity: z.coerce.number().int().min(1).max(500) })
    .safeParse(raw)
  if (!parsed.success) return issues(parsed.error)
  const supabase = await createClient()
  const { error } = await supabase
    .from('class_series')
    .update({ room_id: parsed.data.roomId, instructor_id: parsed.data.instructorId, capacity: parsed.data.capacity })
    .eq('id', seriesId)
    .eq('org_id', ctx.org.id)
  if (error) return { message: dbMessage(error) }
  const { data } = await supabase.rpc('apply_series_to_future', { p_series: seriesId })
  return done(slug, `Guardado. Se actualizaron ${data ?? 0} clases futuras.`)
}

export async function endSeries(slug: string, seriesId: string, _prev: ActionState): Promise<ActionState> {
  const ctx = await classGuard(slug)
  if (!ctx) return { message: ERRORS.FORBIDDEN }
  const supabase = await createClient()
  const { data, error } = await supabase.rpc('end_series', { p_series: seriesId })
  if (error) return { message: dbMessage(error) }
  const r = data as { deleted: number; kept_with_bookings: number }
  const kept = r.kept_with_bookings
    ? ` ${r.kept_with_bookings} clases ya tenían reservas y se mantienen (cancelalas desde la agenda si hace falta).`
    : ''
  return done(slug, `Horario dado de baja. Se borraron ${r.deleted} clases futuras.${kept}`)
}

// ---------------------------------------------------------------------
// Salas, equipos y actividades
// ---------------------------------------------------------------------

export async function saveRoom(slug: string, roomId: string | null, _prev: ActionState, form: FormData): Promise<ActionState> {
  const ctx = await guard(slug)
  if (!ctx || !ctx.org.locationId) return { message: ERRORS.FORBIDDEN }
  const parsed = z
    .object({ name: z.string().trim().min(1, 'Poné un nombre'), capacity: z.coerce.number().int().min(1).max(1000) })
    .safeParse(formObject(form))
  if (!parsed.success) return issues(parsed.error)
  const supabase = await createClient()
  const row = { name: parsed.data.name, capacity: parsed.data.capacity, active: roomId ? form.get('active') === 'on' : true }
  const { error } = roomId
    ? await supabase.from('rooms').update(row).eq('id', roomId).eq('org_id', ctx.org.id)
    : await supabase.from('rooms').insert({ ...row, org_id: ctx.org.id, location_id: ctx.org.locationId })
  if (error) return { message: dbMessage(error) }
  return done(slug, roomId ? 'Sala guardada.' : 'Sala creada.')
}

export async function addEquipment(slug: string, roomId: string, _prev: ActionState, form: FormData): Promise<ActionState> {
  const ctx = await guard(slug)
  if (!ctx || !ctx.org.locationId) return { message: ERRORS.FORBIDDEN }
  const parsed = z
    .object({
      kind: z.string().trim().toLowerCase().min(1, 'Indicá el tipo (ej. bike)').max(30),
      count: z.coerce.number().int().min(1).max(100),
      startAt: z.coerce.number().int().min(1).max(999).default(1),
    })
    .safeParse(formObject(form))
  if (!parsed.success) return issues(parsed.error)
  const { kind, count, startAt } = parsed.data
  const rows = Array.from({ length: count }, (_, i) => ({
    org_id: ctx.org.id,
    location_id: ctx.org.locationId!,
    room_id: roomId,
    kind,
    label: `#${startAt + i}`,
  }))
  const supabase = await createClient()
  const { error } = await supabase.from('equipment').upsert(rows, { onConflict: 'location_id,kind,label', ignoreDuplicates: true })
  if (error) return { message: dbMessage(error) }
  return done(slug, `Se agregaron ${count} equipos "${kind}".`)
}

export async function setEquipmentStatus(
  slug: string,
  equipmentId: string,
  status: 'active' | 'maintenance' | 'retired',
  _prev?: ActionState,
): Promise<ActionState> {
  const ctx = await guard(slug)
  if (!ctx) return { message: ERRORS.FORBIDDEN }
  const supabase = await createClient()
  const { error } = await supabase.from('equipment').update({ status }).eq('id', equipmentId).eq('org_id', ctx.org.id)
  if (error) return { message: dbMessage(error) }
  return done(slug, status === 'active' ? 'Equipo activo de nuevo.' : status === 'maintenance' ? 'Equipo en mantenimiento.' : 'Equipo dado de baja.')
}

const typeSchema = z.object({
  name: z.string().trim().min(1, 'Poné un nombre'),
  description: z.string().trim().optional(),
  color: z.string().regex(/^#[0-9a-fA-F]{6}$/).default('#edcc36'),
  durationMin: z.coerce.number().int().min(5).max(480),
  capacity: z.coerce.number().int().min(1).max(500),
  equipmentKind: z.string().trim().toLowerCase().optional(),
})

export async function saveClassType(slug: string, typeId: string | null, _prev: ActionState, form: FormData): Promise<ActionState> {
  const ctx = await guard(slug)
  if (!ctx) return { message: ERRORS.FORBIDDEN }
  const parsed = typeSchema.safeParse(formObject(form))
  if (!parsed.success) return issues(parsed.error)
  const t = parsed.data
  const row = {
    name: t.name,
    description: t.description || null,
    color: t.color,
    default_duration_min: t.durationMin,
    default_capacity: t.capacity,
    equipment_kind: t.equipmentKind || null,
    active: typeId ? form.get('active') === 'on' : true,
  }
  const supabase = await createClient()
  const { error } = typeId
    ? await supabase.from('class_types').update(row).eq('id', typeId).eq('org_id', ctx.org.id)
    : await supabase.from('class_types').insert({ ...row, org_id: ctx.org.id })
  if (error) return { message: dbMessage(error) }
  return done(slug, typeId ? 'Actividad guardada.' : 'Actividad creada.')
}

// ---------------------------------------------------------------------
// 0040 · Editar una clase y la grilla (profe en lo suyo / administración)
// ---------------------------------------------------------------------

const sessionEditSchema = z.object({
  date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, 'Elegí el día'),
  time: z.string().regex(/^\d{2}:\d{2}$/, 'Elegí la hora'),
  durationMin: z.coerce.number().int().min(5, 'Mínimo 5 minutos').max(480, 'Máximo 8 horas'),
  capacity: z.coerce.number().int().min(1, 'Mínimo 1 lugar').max(500),
  roomId: z.uuid('Elegí la sala'),
})

/** Cambiar día/hora, duración, cupo o sala de UNA clase. Si cambia el horario se avisa por email a los anotados. */
export async function editSession(slug: string, sessionId: string, _prev: ActionState, form: FormData): Promise<ActionState> {
  const ctx = await classGuard(slug)
  if (!ctx) return { message: ERRORS.FORBIDDEN }
  const parsed = sessionEditSchema.safeParse(formObject(form))
  if (!parsed.success) return issues(parsed.error)
  const v = parsed.data
  const supabase = await createClient()
  const { data, error } = await supabase.rpc('update_session', {
    p_session: sessionId,
    // Postgres interpreta la hora en la zona del gimnasio
    p_starts_at: `${v.date} ${v.time}:00 ${ctx.org.timezone}`,
    p_duration_min: v.durationMin,
    p_capacity: v.capacity,
    p_room: v.roomId,
    p_notify: form.getAll('notify').includes('on'),
  })
  if (error) return { message: dbMessage(error) }
  const r = (data ?? {}) as { moved?: boolean; notified?: number; promoted?: number }
  const parts = ['Clase actualizada.']
  if (r.moved) parts.push(r.notified ? `Se avisó por email a ${r.notified} anotado${r.notified === 1 ? '' : 's'}.` : 'No había anotados con email para avisar.')
  if (r.promoted) parts.push(`Entraron ${r.promoted} de la lista de espera.`)
  return done(slug, parts.join(' '))
}

const ownSeriesSchema = z.object({
  classTypeId: z.uuid('Elegí la actividad'),
  roomId: z.uuid('Elegí la sala'),
  instructorId: z.uuid().optional().or(z.literal('')),
  weekday: z.coerce.number().int().min(1).max(7),
  startTime: z.string().regex(/^\d{2}:\d{2}$/, 'Hora inválida'),
  durationMin: z.coerce.number().int().min(5, 'Mínimo 5 minutos').max(480),
  capacity: z.coerce.number().int().min(1, 'Mínimo 1 lugar').max(500),
  validFrom: z.string().optional(),
})

/** Agregar un horario fijo (el profe para él mismo; administración puede elegir el profe). */
export async function createSeriesRpc(slug: string, _prev: ActionState, form: FormData): Promise<ActionState> {
  const ctx = await classGuard(slug)
  if (!ctx) return { message: ERRORS.FORBIDDEN }
  const days = weekdaysOf(form)
  if (!days.length) return { fieldErrors: { weekday: 'Elegí al menos un día' } }
  const parsed = ownSeriesSchema.safeParse({ ...formObject(form), weekday: days[0] })
  if (!parsed.success) return issues(parsed.error)
  const s = parsed.data
  const supabase = await createClient()
  // Misma clase en varios días: se crea un horario fijo por cada día tildado.
  // Cada día se valida por separado (sala o profe ocupados): los que chocan se informan y el resto se crea igual.
  let created = 0
  const ok: string[] = []
  const failed: string[] = []
  for (const weekday of days) {
    const { data, error } = await supabase.rpc('create_series', {
      p_org: ctx.org.id,
      p_class_type: s.classTypeId,
      p_room: s.roomId,
      p_weekday: weekday,
      p_start_time: s.startTime,
      p_duration_min: s.durationMin,
      p_capacity: s.capacity,
      ...(s.validFrom ? { p_valid_from: s.validFrom } : {}),
      ...(s.instructorId && ctx.can('schedule.manage') ? { p_instructor: s.instructorId } : {}),
    })
    if (error) {
      failed.push(`${WEEKDAYS[weekday - 1]}: ${dbMessage(error) ?? 'no se pudo agregar'}`)
      continue
    }
    ok.push(WEEKDAYS[weekday - 1]!)
    created += (data as { created?: number } | null)?.created ?? 0
  }
  if (!ok.length) return { message: failed.join(' · ') }
  const label = ok.length > 1 ? `Horarios agregados: ${ok.join(', ')}` : `Horario agregado (${ok[0]})`
  const warn = failed.length ? ` No se agregaron: ${failed.join(' · ')}.` : ''
  return done(slug, `${label}. Se crearon ${created} clases de las próximas 4 semanas.${warn}`)
}

const seriesEditSchema = z.object({
  weekday: z.coerce.number().int().min(1).max(7),
  startTime: z.string().regex(/^\d{2}:\d{2}$/, 'Hora inválida'),
  durationMin: z.coerce.number().int().min(5, 'Mínimo 5 minutos').max(480),
  capacity: z.coerce.number().int().min(1, 'Mínimo 1 lugar').max(500),
  roomId: z.uuid('Elegí la sala'),
  instructorId: z.uuid().optional().or(z.literal('')),
})

/** Cambiar día, hora, duración, sala o cupo de un horario fijo (y el profe, solo administración). */
export async function editSeries(slug: string, seriesId: string, _prev: ActionState, form: FormData): Promise<ActionState> {
  const ctx = await classGuard(slug)
  if (!ctx) return { message: ERRORS.FORBIDDEN }
  const parsed = seriesEditSchema.safeParse(formObject(form))
  if (!parsed.success) return issues(parsed.error)
  const v = parsed.data
  const supabase = await createClient()
  const { data, error } = await supabase.rpc('update_series', {
    p_series: seriesId,
    p_weekday: v.weekday,
    p_start_time: v.startTime,
    p_duration_min: v.durationMin,
    p_capacity: v.capacity,
    p_room: v.roomId,
    ...(v.instructorId && ctx.can('schedule.manage') ? { p_instructor: v.instructorId } : {}),
    p_move_booked: form.getAll('moveBooked').includes('on'),
  })
  if (error) return { message: dbMessage(error) }
  const r = (data ?? {}) as { moved?: number; kept_with_bookings?: number; notified?: number; created?: number; deleted?: number }
  const parts = ['Horario guardado.']
  if (r.moved) parts.push(`Se movieron ${r.moved} clases que ya tenían anotados${r.notified ? ` y se avisó por email a ${r.notified}` : ''}.`)
  if (r.kept_with_bookings)
    parts.push(`${r.kept_with_bookings} clases con anotados quedaron en el horario anterior: movelas o cancelalas desde la clase.`)
  return done(slug, parts.join(' '))
}
